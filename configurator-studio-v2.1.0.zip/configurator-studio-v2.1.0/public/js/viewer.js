import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

export class ProductViewer {
  constructor(container,{onSelect=()=>{},onReady=()=>{},onError=()=>{}}={}) {
    this.container=container; this.onSelect=onSelect; this.onReady=onReady; this.onError=onError;
    this.abort=new AbortController(); this.meshes=[]; this.materialBackups=new Map(); this.model=null; this.ground=null; this.animation=null;
    this.scene=new THREE.Scene(); this.scene.background=new THREE.Color(0xf2ede5);
    this.camera=new THREE.PerspectiveCamera(38,1,.01,200);
    this.renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2)); this.renderer.outputColorSpace=THREE.SRGBColorSpace; this.renderer.toneMapping=THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure=1.08;
    this.renderer.shadowMap.enabled=true; this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    container.replaceChildren(this.renderer.domElement);
    this.controls=new OrbitControls(this.camera,this.renderer.domElement); this.controls.enableDamping=true; this.controls.dampingFactor=.06; this.controls.enablePan=false; this.controls.minDistance=.35; this.controls.maxDistance=12;
    this.scene.add(new THREE.HemisphereLight(0xfffdf8,0x8e8273,2.4));
    const key=new THREE.DirectionalLight(0xffffff,3.2); key.position.set(3.5,5,4); key.castShadow=true; this.scene.add(key);
    const fill=new THREE.DirectionalLight(0xc8d8d1,1.3); fill.position.set(-4,2,-2); this.scene.add(fill);
    const rim=new THREE.DirectionalLight(0xffdfbd,1.2); rim.position.set(0,3,-5); this.scene.add(rim);
    this.raycaster=new THREE.Raycaster(); this.pointer=new THREE.Vector2();
    this.renderer.domElement.addEventListener('pointerdown',e=>this.#pick(e),{signal:this.abort.signal,passive:true});
    this.resizeObserver=new ResizeObserver(()=>this.resize()); this.resizeObserver.observe(container);
    this.resize(); this.#animate();
  }
  async load(url) {
    this.#clearModel();
    try {
      const loader=new GLTFLoader();
      const gltf=await loader.loadAsync(`${url}${url.includes('?')?'&':'?'}v=${Date.now()}`);
      this.model=gltf.scene; this.meshes=[];
      this.model.traverse(object=>{
        if(!object.isMesh)return;
        object.castShadow=true; object.receiveShadow=true;
        if(Array.isArray(object.material)) object.material=object.material.map(m=>m.clone()); else object.material=(object.material||new THREE.MeshStandardMaterial({color:0xb98b60,roughness:.55})).clone();
        const mats=Array.isArray(object.material)?object.material:[object.material]; mats.forEach(m=>{m.side=THREE.DoubleSide;m.needsUpdate=true});
        this.meshes.push(object); this.materialBackups.set(object.uuid,mats.map(m=>({emissive:m.emissive?.clone(),emissiveIntensity:m.emissiveIntensity||0})));
      });
      this.scene.add(this.model); this.fit(); this.onReady({meshes:this.meshes.map(m=>m.name)}); return true;
    } catch(error){this.onError(error);return false;}
  }
  fit() {
    if(!this.model)return;

    // Normalize every asset to a real studio floor and center it horizontally.
    // This prevents tall products such as chairs from being cropped on narrow mobile previews.
    let box=new THREE.Box3().setFromObject(this.model);
    const initialCenter=box.getCenter(new THREE.Vector3());
    this.model.position.x-=initialCenter.x;
    this.model.position.z-=initialCenter.z;
    this.model.position.y-=box.min.y;
    box=new THREE.Box3().setFromObject(this.model);

    const size=box.getSize(new THREE.Vector3());
    const center=box.getCenter(new THREE.Vector3());
    const maxSize=Math.max(size.x,size.y,size.z,.1);
    const target=new THREE.Vector3(center.x,box.min.y+size.y*.47,center.z);

    this.#setGround(Math.max(size.x,size.z,maxSize*.7));

    const verticalFov=THREE.MathUtils.degToRad(this.camera.fov);
    const fitHeight=size.y/(2*Math.tan(verticalFov/2));
    const fitWidth=size.x/(2*Math.tan(verticalFov/2)*Math.max(this.camera.aspect,.35));
    const depthDistance=size.z*1.65;
    const distance=Math.max(fitHeight,fitWidth,depthDistance,maxSize*.9)*1.22;
    const direction=new THREE.Vector3(1.18,.62,1.68).normalize();

    this.controls.target.copy(target);
    this.camera.position.copy(target).addScaledVector(direction,distance);
    this.camera.near=Math.max(distance/200,.005);
    this.camera.far=Math.max(distance*30,50);
    this.controls.minDistance=Math.max(maxSize*.45,.2);
    this.controls.maxDistance=Math.max(maxSize*8,4);
    this.camera.updateProjectionMatrix();
    this.controls.update();
  }
  reset(){this.fit()}
  highlight(targetNames=[]) {
    const names=new Set(Array.isArray(targetNames)?targetNames:[targetNames]);
    for(const mesh of this.meshes){
      const selected=names.has(mesh.name); const materials=Array.isArray(mesh.material)?mesh.material:[mesh.material]; const backups=this.materialBackups.get(mesh.uuid)||[];
      materials.forEach((m,i)=>{if(!m.emissive)return;m.emissive.copy(selected?new THREE.Color(0x4d8b6c):(backups[i]?.emissive||new THREE.Color(0)));m.emissiveIntensity=selected?.22:(backups[i]?.emissiveIntensity||0)});
    }
  }
  applyMaterial(targetNames,material={}) {
    const names=new Set(targetNames||[]); for(const mesh of this.meshes){if(!names.has(mesh.name))continue;const mats=Array.isArray(mesh.material)?mesh.material:[mesh.material];for(const m of mats){if(material.color)m.color.set(material.color);if(Number.isFinite(Number(material.roughness)))m.roughness=Number(material.roughness);if(Number.isFinite(Number(material.metalness)))m.metalness=Number(material.metalness);m.needsUpdate=true}}
  }
  resize(){const w=Math.max(1,this.container.clientWidth),h=Math.max(1,this.container.clientHeight);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.renderer.setSize(w,h,false)}
  async fullscreen(){if(!document.fullscreenElement)await this.container.parentElement.requestFullscreen?.();else await document.exitFullscreen?.()}
  dispose(){this.abort.abort();this.resizeObserver?.disconnect();cancelAnimationFrame(this.animation);this.#clearModel();this.controls?.dispose();this.renderer?.dispose();this.renderer?.forceContextLoss();this.container.replaceChildren()}
  #clearModel(){if(this.ground){this.scene.remove(this.ground);this.ground.geometry?.dispose?.();this.ground.material?.dispose?.();this.ground=null}if(!this.model)return;this.scene.remove(this.model);this.model.traverse(o=>{o.geometry?.dispose?.();const mats=Array.isArray(o.material)?o.material:[o.material];mats.filter(Boolean).forEach(m=>{for(const key of Object.keys(m)){if(m[key]?.isTexture)m[key].dispose()}m.dispose?.()})});this.model=null;this.meshes=[];this.materialBackups.clear()}
  #setGround(radius){
    if(this.ground){this.scene.remove(this.ground);this.ground.geometry?.dispose?.();this.ground.material?.dispose?.()}
    const geometry=new THREE.CircleGeometry(Math.max(radius*2.25,1),96);
    const material=new THREE.ShadowMaterial({color:0x5b5149,opacity:.16});
    this.ground=new THREE.Mesh(geometry,material);
    this.ground.rotation.x=-Math.PI/2;
    this.ground.position.y=-.004;
    this.ground.receiveShadow=true;
    this.scene.add(this.ground);
  }
  #pick(event){if(!this.meshes.length)return;const rect=this.renderer.domElement.getBoundingClientRect();this.pointer.x=((event.clientX-rect.left)/rect.width)*2-1;this.pointer.y=-((event.clientY-rect.top)/rect.height)*2+1;this.raycaster.setFromCamera(this.pointer,this.camera);const hit=this.raycaster.intersectObjects(this.meshes,true)[0];if(hit)this.onSelect(hit.object.name)}
  #animate(){this.controls.update();this.renderer.render(this.scene,this.camera);this.animation=requestAnimationFrame(()=>this.#animate())}
}
