export function createInitialSelections(optionGroups = []) {
  return Object.fromEntries(optionGroups.map(group => [group.option_group_id, group.default_option_id || group.options?.[0]?.option_id || null]));
}

export function selectedOptionIds(selections = {}) {
  return Object.values(selections).filter(Boolean);
}

export function optionIndex(optionGroups = []) {
  const groups = new Map();
  const options = new Map();
  for (const group of optionGroups) {
    groups.set(group.option_group_id, group);
    for (const option of group.options || []) options.set(option.option_id, { ...option, group });
  }
  return { groups, options };
}

export function evaluateConfiguration({ optionGroups = [], rules = [], selections = {}, facts = [] }) {
  const { options } = optionIndex(optionGroups);
  const configuration = { ...selections };
  for (const optionId of selectedOptionIds(selections)) configuration[optionId] = true;
  const factValues = Object.fromEntries((facts || []).map(fact => [fact.key, fact.value]));
  const result = {
    hidden_options: new Set(),
    disabled_options: new Set(),
    required_options: new Set(),
    warnings: [],
    lead_time_days: 0,
    order_fields: {},
    invalid: false,
    conflicts: []
  };

  for (const rule of (rules || []).filter(rule => rule.enabled !== false)) {
    const matches = (rule.if || []).every(condition => {
      const source = condition.source === 'fact' ? factValues : configuration;
      return compare(source[condition.field], condition.operator || 'eq', condition.value);
    });
    if (!matches) continue;
    for (const effect of rule.then || []) {
      const value = effect.value ?? effect.option_id ?? effect.rule_id;
      if (effect.action === 'hide_option') result.hidden_options.add(value);
      if (effect.action === 'disable_option') result.disabled_options.add(value);
      if (effect.action === 'require_option') result.required_options.add(value);
      if (effect.action === 'show_warning') result.warnings.push(effect.message || String(value || 'Controleer deze configuratie.'));
      if (effect.action === 'add_lead_time') result.lead_time_days += Number(effect.days || effect.value || 0);
      if (effect.action === 'set_order_field' && effect.field) result.order_fields[effect.field] = effect.value;
    }
  }

  for (const optionId of result.required_options) {
    if (result.hidden_options.has(optionId) || result.disabled_options.has(optionId)) {
      result.invalid = true;
      result.conflicts.push({ option_id: optionId, message: 'Een verplichte keuze is tegelijk verborgen of uitgeschakeld.' });
    }
  }

  for (const [groupId, optionId] of Object.entries(selections)) {
    if (optionId && !options.has(optionId)) {
      result.invalid = true;
      result.conflicts.push({ group_id: groupId, option_id: optionId, message: 'De geselecteerde optie bestaat niet meer.' });
    }
  }
  return result;
}

export function calculateConfigurationPrice({ pricing = {}, selections = {}, facts = [], quantity = 1 }) {
  const selected = selectedOptionIds(selections);
  const base = number(pricing.base_price?.amount, 0);
  let running = base;
  const breakdown = [{ id: 'base', label: pricing.base_price?.label || 'Basisprijs', amount: base }];

  for (const rule of (pricing.rules || []).filter(rule => rule.enabled !== false)) {
    if (rule.option_id && !selected.includes(rule.option_id)) continue;
    let delta = 0;
    if (rule.type === 'fixed_delta') delta = number(rule.amount, 0);
    else if (rule.type === 'percentage_delta') delta = running * number(rule.percent, 0) / 100;
    else if (rule.type === 'area_based') {
      const length = authoritative(facts, rule.length_key || 'dimensions.length_mm');
      const width = authoritative(facts, rule.width_key || 'dimensions.width_mm');
      delta = (length / 1000) * (width / 1000) * number(rule.rate_per_m2, 0);
    } else if (rule.type === 'perimeter_based') {
      const length = authoritative(facts, rule.length_key || 'dimensions.length_mm');
      const width = authoritative(facts, rule.width_key || 'dimensions.width_mm');
      delta = ((length + width) * 2 / 1000) * number(rule.rate_per_meter, 0);
    } else if (rule.type === 'quantity_tier') {
      const tier = [...(rule.tiers || [])].sort((a, b) => number(a.min, 0) - number(b.min, 0)).filter(item => quantity >= number(item.min, 0)).at(-1);
      delta = tier ? number(tier.amount, 0) : 0;
    }
    delta = round(delta);
    running += delta;
    breakdown.push({ id: rule.rule_id, label: rule.label || 'Meerprijs', amount: delta });
  }
  const unitTotal = round(running);
  return { currency: pricing.currency || 'EUR', unit_total: unitTotal, quantity, total: round(unitTotal * quantity), breakdown };
}

export function buildOrderPayload({ runtime, selections, price, ruleState, previewUrl = null }) {
  const configurationId = `cfg_${crypto.randomUUID()}`;
  const { groups } = optionIndex(runtime.option_groups || []);
  const sourceValues = {
    'system.configuration_id': configurationId,
    'system.runtime_config_id': runtime.runtime_config_id,
    'system.runtime_version': runtime.version,
    'system.preview_url': previewUrl,
    'system.created_at': new Date().toISOString(),
    'product.name': runtime.product?.name,
    'product.price': price?.total,
    'product.currency': price?.currency
  };
  for (const [groupId, optionId] of Object.entries(selections || {})) {
    const group = groups.get(groupId);
    const option = group?.options?.find(item => item.option_id === optionId);
    sourceValues[`selection.${groupId}`] = optionId;
    sourceValues[`selection_label.${groupId}`] = option?.label || optionId;
  }
  const fields = {};
  for (const field of runtime.order_output?.fields || []) {
    fields[field.field_id] = String(field.source || '').startsWith('static.')
      ? String(field.source).slice('static.'.length)
      : sourceValues[field.source] ?? null;
  }
  Object.assign(fields, ruleState?.order_fields || {});
  return {
    configuration_id: configurationId,
    runtime_config_id: runtime.runtime_config_id,
    runtime_version: runtime.version,
    selections: structuredClone(selections),
    price,
    lead_time_days: ruleState?.lead_time_days || 0,
    fields,
    created_at: new Date().toISOString()
  };
}

function compare(actual, operator, expected) {
  if (operator === 'eq') return actual === expected;
  if (operator === 'neq') return actual !== expected;
  if (operator === 'in') return Array.isArray(expected) && expected.includes(actual);
  if (operator === 'gt') return Number(actual) > Number(expected);
  if (operator === 'gte') return Number(actual) >= Number(expected);
  if (operator === 'lt') return Number(actual) < Number(expected);
  if (operator === 'lte') return Number(actual) <= Number(expected);
  if (operator === 'contains') return Array.isArray(actual) ? actual.includes(expected) : String(actual || '').includes(String(expected));
  return false;
}

function authoritative(facts, key) {
  const fact = (facts || []).find(item => item.key === key);
  if (!fact?.pricing_allowed) throw new Error(`${key} moet eerst worden bevestigd.`);
  return number(fact.value, 0);
}

function number(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function round(value) { return Math.round(value * 100) / 100; }
