import { ProductViewer } from './viewer.js';
import { STUDIO_STEPS, evaluateStudioProgress, nextStep, previousStep } from './studioSteps.js';
import { createInitialSelections, calculateConfigurationPrice, evaluateConfiguration, buildOrderPayload } from './configEngine.js';

const state = {
  projects: [], projectId: null, data: null, view: 'dashboard', step: 'intake', progress: null,
  selections: {}, selectedPartId: null, stageViewer: null, previewViewer: null, previewDevice: 'desktop',
  saveTimer: null, search: '', uploads: []
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const deep = value => structuredClone(value);

document.addEventListener('DOMContentLoaded', init);

async function init() {
  bindShell();
  await loadProjects();
  await refreshHealth();
  renderDashboard();
}

function bindShell() {
  $('#homeBrand').addEventListener('click', event => { event.preventDefault(); showDashboard(); });
  $('#backToDashboard').addEventListener('click', showDashboard);
  $('#newProjectButton').addEventListener('click', openNewProject);
  $('#newProjectButtonSecondary').addEventListener('click', openNewProject);
  $('#openDemoButton').addEventListener('click', () => openProject('proj_demo_chair', 'options'));
  $$('[data-close-new-project]').forEach(button => button.addEventListener('click', closeNewProject));
  $('#newProjectModal').addEventListener('click', event => { if (event.target === event.currentTarget) closeNewProject(); });
  $('#newProjectForm').addEventListener('submit', createProject);
  $('#projectSearch').addEventListener('input', event => { state.search = event.target.value; renderProjectGrid(); });
  $('#mobileMenu').addEventListener('click', toggleMobileSidebar);
  $('#sidebarBackdrop').addEventListener('click', closeMobileSidebar);
  $('#logoutButton').addEventListener('click', logout);
  $('#previousStepButton').addEventListener('click', () => changeStep(previousStep(state.step)));
  $('#nextStepButton').addEventListener('click', () => changeStep(nextStep(state.step)));
  $('#openPreviewButton').addEventListener('click', openPreview);
  $('#quickPublishButton').addEventListener('click', () => changeStep('publish'));
  $('#closePreview').addEventListener('click', closePreview);
  $$('[data-preview-device]').forEach(button => button.addEventListener('click', () => setPreviewDevice(button.dataset.previewDevice)));
  $('#assistantClose').addEventListener('click', () => $('#assistantPanel').classList.toggle('collapsed'));
  $('#assistantSend').addEventListener('click', answerAssistant);
  $('#assistantQuestion').addEventListener('keydown', event => { if (event.key === 'Enter') answerAssistant(); });
  $$('.app-nav-item[data-view]').forEach(button => button.addEventListener('click', () => showSimpleView(button.dataset.view)));
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    closeNewProject(); closePreview(); closeMobileSidebar();
  });
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const payload = await response.json().catch(() => ({}));
  if (response.status === 401) { location.assign('/'); throw new Error('Je sessie is verlopen.'); }
  if (!response.ok || payload.ok === false) {
    const error = new Error(payload.error || `HTTP ${response.status}`);
    error.payload = payload;
    throw error;
  }
  return payload;
}

async function refreshHealth() {
  try {
    const health = await api('/api/health');
    const live = Object.entries(health.providers || {}).filter(([key, value]) => key !== 'demo_mode' && value).length;
    $('#engineStatusText').textContent = live ? `${live} live providers` : 'Veilige demomodus';
    $('#engineStatusDot').classList.toggle('live', live > 0);
    $('#statEngine').textContent = live ? 'Live' : 'Demo';
    $('#statEngineSub').textContent = live ? `${live} providers actief` : 'providers instellen';
  } catch {
    $('#engineStatusText').textContent = 'Status niet beschikbaar';
  }
}

async function loadProjects() {
  const result = await api('/api/projects');
  state.projects = result.projects || [];
}

function renderDashboard() {
  state.view = 'dashboard';
  $('#dashboardView').classList.remove('hidden');
  $('#projectView').classList.add('hidden');
  $('#simpleView').classList.add('hidden');
  $('#breadcrumb').innerHTML = '<strong>Projecten</strong>';
  setActiveAppNav('dashboard');
  $('#statProjects').textContent = state.projects.length;
  $('#statPublished').textContent = state.projects.filter(project => project.status === 'published').length;
  $('#statAttention').textContent = state.projects.filter(project => project.status !== 'published').length;
  renderProjectGrid();
  $('#activityList').innerHTML = state.projects.slice(0, 4).map(project => `
    <div class="activity-item"><span>${project.status === 'published' ? '✓' : '↗'}</span><div><strong>${escapeHtml(project.name)}</strong><small>${project.status === 'published' ? 'Runtime gepubliceerd' : 'Bouwplan bijgewerkt'} · ${relativeTime(project.updated_at)}</small></div></div>
  `).join('') || '<div class="assistant-message">Nog geen activiteit.</div>';
}

function renderProjectGrid() {
  const query = state.search.trim().toLowerCase();
  const projects = state.projects.filter(project => `${project.name} ${project.description || ''}`.toLowerCase().includes(query));
  $('#projectGrid').innerHTML = projects.map(project => {
    const isDemo = project.project_id === 'proj_demo_chair';
    const percent = project.progress_percent ?? (project.status === 'published' ? 100 : isDemo ? 92 : 8);
    const step = project.current_step_label || (isDemo ? 'Klantkeuzes' : 'Productbrief');
    return `<article class="project-card" data-project-id="${attr(project.project_id)}">
      <div class="project-card-media">${project.poster_url ? `<img src="${attr(project.poster_url)}" alt="">` : ''}<span class="project-card-status">${escapeHtml(statusLabel(project.status))}</span></div>
      <div class="project-card-body"><h3>${escapeHtml(project.name)}</h3><p>${escapeHtml(project.description || 'Nieuw configuratorproject')}</p>
        <div class="project-card-progress"><div><span>${escapeHtml(step)}</span><strong>${percent}%</strong></div><div class="mini-progress"><i style="width:${percent}%"></i></div></div>
        <div class="project-card-foot"><span>${relativeTime(project.updated_at)}</span><strong>Open project →</strong></div>
      </div></article>`;
  }).join('') || '<div class="placeholder-view"><span class="kicker">GEEN RESULTATEN</span><h2>Geen projecten gevonden</h2><p>Pas je zoekopdracht aan of start een nieuwe configurator.</p></div>';
  $$('[data-project-id]', $('#projectGrid')).forEach(card => card.addEventListener('click', () => openProject(card.dataset.projectId)));
}

async function openProject(projectId, preferredStep = null) {
  disposeViewers();
  const result = await api(`/api/studio?project_id=${encodeURIComponent(projectId)}`);
  state.projectId = projectId;
  state.data = result;
  state.selections = createInitialSelections(result.blueprint.option_groups || []);
  state.selectedPartId = result.blueprint.parts?.[0]?.part_id || null;
  state.progress = evaluateStudioProgress(result);
  const saved = localStorage.getItem(`configurator-step:${projectId}`);
  state.step = preferredStep || saved || result.project.builder_state?.current_step || state.progress.firstIncomplete || 'intake';
  state.view = 'project';
  $('#dashboardView').classList.add('hidden');
  $('#simpleView').classList.add('hidden');
  $('#projectView').classList.remove('hidden');
  setActiveAppNav('dashboard');
  renderProjectShell();
  renderStep();
  closeMobileSidebar();
}

function renderProjectShell() {
  const { project } = state.data;
  state.progress = evaluateStudioProgress(state.data);
  $('#projectName').textContent = project.name;
  $('#projectStatus').textContent = statusLabel(project.status);
  $('#projectStatus').classList.toggle('published', project.status === 'published');
  $('#projectMeta').textContent = `Bijgewerkt ${relativeTime(project.updated_at)} · automatisch opgeslagen`;
  $('#projectProgressLabel').textContent = `${state.progress.completed} van ${state.progress.total}`;
  $('#projectProgressBar').style.width = `${state.progress.percent}%`;
  $('#breadcrumb').innerHTML = `<span>Projecten</span> / <strong>${escapeHtml(project.name)}</strong>`;
  renderStepNavigation();
  renderAssistant();
}

function renderStepNavigation() {
  $('#stepNavigation').innerHTML = STUDIO_STEPS.map(step => {
    const status = step.id === state.step ? 'active' : state.progress.status[step.id] ? 'complete' : step.number < currentStep().number ? 'attention' : 'upcoming';
    return `<button class="step-nav-item ${status}" data-step="${step.id}"><span class="step-nav-number">${String(step.number).padStart(2, '0')}</span><span class="step-nav-copy"><strong>${escapeHtml(step.label)}</strong><small>${escapeHtml(step.description)}</small></span><span class="step-nav-state">${status === 'complete' ? '✓' : status === 'attention' ? '!' : '›'}</span></button>`;
  }).join('');
  $$('[data-step]', $('#stepNavigation')).forEach(button => button.addEventListener('click', () => changeStep(button.dataset.step)));
  const step = currentStep();
  $('#mobileStepProgress').innerHTML = `<span>Stap ${step.number} van ${STUDIO_STEPS.length}</span><strong>${escapeHtml(step.label)}</strong><span>${state.progress.percent}%</span>`;
}

function changeStep(stepId) {
  if (!STUDIO_STEPS.some(step => step.id === stepId)) return;
  state.step = stepId;
  localStorage.setItem(`configurator-step:${state.projectId}`, stepId);
  disposeStageViewer();
  renderProjectShell();
  renderStep();
}

function currentStep() { return STUDIO_STEPS.find(step => step.id === state.step) || STUDIO_STEPS[0]; }

function renderStep() {
  const step = currentStep();
  const renderers = {
    intake: renderIntakeStep, sources: renderSourcesStep, route: renderRouteStep, model: renderModelStep,
    quality: renderQualityStep, parts: renderPartsStep, options: renderOptionsStep, pricing: renderPricingStep,
    rules: renderRulesStep, commerce: renderCommerceStep, design: renderDesignStep, publish: renderPublishStep
  };
  $('#stepContent').innerHTML = stepIntro(step) + (renderers[step.id]?.() || '');
  $('#previousStepButton').disabled = step.number === 1;
  $('#nextStepButton').disabled = step.number === STUDIO_STEPS.length;
  $('#nextStepButton').textContent = step.number === STUDIO_STEPS.length ? 'Laatste stap' : 'Volgende stap →';
  bindStep(step.id);
  $('#stepContent').scrollTop = 0;
}

function stepIntro(step) {
  return `<header class="step-intro"><div class="step-intro-copy"><span class="kicker">STAP ${String(step.number).padStart(2, '0')} · ${escapeHtml(step.short)}</span><h2>${escapeHtml(step.label)}</h2><p>${escapeHtml(step.description)} Studio toont alleen acties die voor deze fase relevant en uitvoerbaar zijn.</p></div><div class="step-number-badge"><strong>${String(step.number).padStart(2, '0')}</strong><small>van ${STUDIO_STEPS.length} stappen</small></div></header>`;
}

function renderIntakeStep() {
  const project = state.data.project;
  return `<div class="content-grid"><section class="content-card"><div class="content-card-head"><div><h3>Productbrief</h3><p>De zakelijke context waarmee Studio het bouwplan stuurt.</p></div><span class="mini-chip">Menselijk bevestigd</span></div><div class="content-card-body"><div class="field-grid">
    <label class="field"><span>Projectnaam</span><input id="projectNameInput" value="${attr(project.name)}"></label>
    <label class="field"><span>Productcategorie</span><select id="projectCategoryInput">${categoryOptions(project.intake?.category)}</select></label>
    <label class="field full"><span>Wat moet de klant kunnen configureren?</span><textarea id="projectDescriptionInput">${escapeHtml(project.description || '')}</textarea></label>
  </div><div class="info-strip" style="margin-top:14px"><span>✦</span><div><strong>AI helpt structureren, maar bevestigt geen feiten.</strong><br>Afmetingen, prijsinvoer en modelkwaliteit blijven onder menselijke controle.</div></div></div></section>
  <aside class="content-card"><div class="content-card-head"><div><h3>Bouwvoorstel</h3><p>Afgeleid van de huidige projectbrief.</p></div></div><div class="content-card-body"><div class="task-list">
    ${taskRow('1','3D-bron','Geoptimaliseerd stoelmodel met twee echte zones','Gereed')}
    ${taskRow('2','Configureerbare delen','Zitting/rug en poten/onderstel','2 delen')}
    ${taskRow('3','Klantkeuzes','Twee onafhankelijke kleurgroepen','8 keuzes')}
    ${taskRow('4','Verkoopoutput','Prijs en orderpayload gekoppeld','Gereed')}
  </div></div></aside></div>`;
}

function renderSourcesStep() {
  const asset = state.data.active_asset;
  return `<div class="content-grid"><section class="content-card"><div class="content-card-head"><div><h3>Actieve 3D-bron</h3><p>De bron blijft los van opties, prijzen en publicatielogica.</p></div></div><div class="content-card-body">
    ${asset ? `<div class="asset-card"><img src="${attr(asset.poster_url)}" alt=""><div><h4>${escapeHtml(asset.original_file_name || asset.file_name)}</h4><p>${formatBytes(asset.metrics.file_bytes)} · ${formatNumber(asset.metrics.triangles)} triangles · ${asset.metrics.meshes} configureerbare meshes</p><span class="mini-chip">${escapeHtml(asset.source_type)}</span></div><span class="asset-status">Geaccepteerd</span></div>` : '<div class="info-strip warning"><span>!</span><div>Er is nog geen actief model.</div></div>'}
    <label class="asset-drop" style="margin-top:14px"><input type="file" id="glbUploadInput" accept=".glb,model/gltf-binary"><span>↑</span><strong>Vervang of upload een GLB</strong><small>De upload wordt technisch geïnspecteerd en blijft een reviewdraft.</small></label>
  </div></section><aside class="content-card"><div class="content-card-head"><div><h3>Broncheck</h3><p>Wat Studio al aantoonbaar weet.</p></div></div><div class="content-card-body"><div class="quality-list">
    ${qualityRow('Bestandsformaat','Webgeschikte GLB 2.0','ok')}
    ${qualityRow('Configuratiezones',`${asset?.metrics?.meshes || 0} afzonderlijke meshes`,'ok')}
    ${qualityRow('Mobiele omvang',asset?.metrics?.mobile_ready ? 'Binnen huidige richtlijn' : 'Optimalisatie nodig',asset?.metrics?.mobile_ready ? 'ok' : 'warning')}
    ${qualityRow('Menselijke review',asset?.quality_status === 'accepted' ? 'Model geaccepteerd' : 'Review vereist',asset?.quality_status === 'accepted' ? 'ok' : 'warning')}
  </div></div></aside></div>`;
}

function renderRouteStep() {
  const p = state.data.providers || {};
  const activeRoute = state.data.project.intake?.requested_profile || 'uploaded_asset';
  const cards = [
    ['uploaded_asset','◫','Bestaand 3D-model','Snelste route wanneer een gecontroleerde GLB beschikbaar is.','Direct','Actief'],
    ['balanced','✦','Gebalanceerde AI-route','Foto’s naar een getextureerde 3D-draft met menselijke review.','AI','Meshy'],
    ['fast','⚡','Snelle conceptdraft','Snelle visuele reconstructie voor vroege verkoop- en UX-tests.','AI','Tripo'],
    ['premium','◇','Premium visualisatie','Hogere visuele detaillering voor premium productpresentatie.','AI','Rodin'],
    ['exact','⌖','Technisch exact','Bevestigde maatvoering naar parametrische CAD-output.','CAD','FreeCAD']
  ];
  return `<section class="content-card"><div class="content-card-head"><div><h3>Kies op resultaat, niet op providernaam</h3><p>Studio vertaalt deze keuze intern naar de passende adapter en kwaliteitscontroles.</p></div><span class="mini-chip">Huidig: ${escapeHtml(activeRoute)}</span></div><div class="content-card-body"><div class="route-grid">${cards.map(([id,icon,title,desc,tag,provider]) => `<button class="route-card ${activeRoute === id ? 'active' : ''}" data-route-profile="${id}"><span>${icon}</span><strong>${title}</strong><small>${desc}</small><div class="route-meta"><i>${tag}</i><i>${providerStatus(provider,p)}</i></div></button>`).join('')}</div><div class="info-strip" style="margin-top:14px"><span>✓</span><div>Voor deze demo is het geoptimaliseerde uploadmodel correct: de vorm is behouden en beide kleurzones zijn al apart testbaar.</div></div></div></section>`;
}

function renderModelStep() {
  const a = state.data.active_asset;
  return `<div class="content-grid"><section>${viewerCard('modelViewer','Sleep om te draaien · scroll of knijp om te zoomen')}</section><aside class="content-card"><div class="content-card-head"><div><h3>Technische modelstatus</h3><p>Werkelijke GLB-data, geen geschatte kwaliteitsscore.</p></div></div><div class="content-card-body"><div class="metric-grid" style="grid-template-columns:1fr 1fr">
    ${metric('Triangles',formatNumber(a?.metrics?.triangles || 0),'−86% t.o.v. bron')}${metric('Meshes',a?.metrics?.meshes || 0,'echte kleurzones')}${metric('Bestand',formatBytes(a?.metrics?.file_bytes || 0),'snelle download')}${metric('Materialen',a?.metrics?.materials || 0,'PBR-ready')}
  </div><div class="info-strip" style="margin-top:14px"><span>✓</span><div><strong>Dezelfde vorm, veel lichter.</strong><br>Het originele model had 280.838 triangles en één materiaalzone. De demo heeft 39.851 triangles en twee afzonderlijke meshes.</div></div></div></aside></div>`;
}

function renderQualityStep() {
  const a = state.data.active_asset;
  const facts = state.data.project.facts || [];
  return `<div class="content-grid"><section>${viewerCard('qualityViewer','Controleer voor-, zij- en achterkant')}</section><aside class="content-card"><div class="content-card-head"><div><h3>Model QA</h3><p>Alle blockers moeten aantoonbaar opgelost zijn.</p></div></div><div class="content-card-body"><div class="quality-list">
    ${qualityRow('Vorm en silhouet','Oorspronkelijke stoelvorm behouden','ok')}
    ${qualityRow('Configureerbare zones','Zitting en poten zijn apart','ok')}
    ${qualityRow('Mobiele performance',`${formatNumber(a?.metrics?.triangles || 0)} triangles`,'ok')}
    ${qualityRow('Menselijke modelreview',a?.quality_status === 'accepted' ? 'Geaccepteerd' : 'Nog controleren',a?.quality_status === 'accepted' ? 'ok' : 'warning')}
  </div><div class="content-card-head" style="padding-left:0;padding-right:0;margin-top:12px"><div><h3>Bevestigde maten</h3><p>Alleen bevestigde waarden mogen prijs of CAD aansturen.</p></div></div><div class="field-grid one">${facts.filter(f => f.key.startsWith('dimensions.')).map(f => `<label class="field"><span>${escapeHtml(f.label)}</span><input value="${attr(f.value ?? '')}" data-fact-key="${attr(f.key)}" type="number"><small class="mini-chip">${escapeHtml(f.unit || '')} · ${escapeHtml(f.status)}</small></label>`).join('')}</div></div></aside></div>`;
}

function renderPartsStep() {
  const parts = state.data.blueprint.parts || [];
  if (!state.selectedPartId) state.selectedPartId = parts[0]?.part_id || null;
  return `<div class="content-grid"><section>${viewerCard('partsViewer','Klik op zitting of poten om het onderdeel te selecteren')}</section><aside class="content-card"><div class="content-card-head"><div><h3>Configureerbare zones</h3><p>Technische meshnamen blijven gekoppeld maar de klant ziet begrijpelijke onderdelen.</p></div><span class="mini-chip">${parts.length} delen</span></div><div class="content-card-body"><div class="part-grid">${parts.map(part => `<button class="part-card ${state.selectedPartId === part.part_id ? 'active' : ''}" data-part-id="${attr(part.part_id)}"><div class="part-card-head"><span class="part-color">${part.part_id === 'part_seat' ? '◒' : '⌁'}</span><span class="mini-chip">${part.mesh_targets.length} mesh</span></div><h4>${escapeHtml(part.label)}</h4><p>${escapeHtml(part.mesh_targets.join(', '))}</p><div class="part-tags">${part.capabilities.slice(0,4).map(c => `<span>${escapeHtml(capabilityLabel(c))}</span>`).join('')}</div></button>`).join('')}</div><div class="info-strip" style="margin-top:14px"><span>✓</span><div>De zitting/rug en het onderstel zijn fysiek gescheiden in de GLB. Kleurwijzigingen lekken dus niet naar het andere onderdeel.</div></div></div></aside></div>`;
}

function renderOptionsStep() {
  const groups = state.data.blueprint.option_groups || [];
  return `<div class="content-grid"><section>${viewerCard('optionsViewer','Test beide kleurzones direct in het echte GLB')}</section><aside><div class="option-stack">${groups.map(group => optionGroupMarkup(group)).join('')}</div><section class="content-card" style="margin-top:12px"><div class="content-card-body"><img src="/assets/demo-chair-variants.png" alt="Kleurvarianten" style="width:100%;border-radius:12px;display:block"><div class="info-strip" style="margin-top:10px"><span>✦</span><div>De afbeelding is alleen inspiratie. De swatches hierboven sturen het echte 3D-model, de prijs én later de publieke runtime aan.</div></div></div></section></aside></div>`;
}

function optionGroupMarkup(group) {
  const part = state.data.blueprint.parts.find(item => item.part_id === group.target_id);
  return `<section class="option-group-card"><div class="option-group-head"><div><h3>${escapeHtml(group.label)}</h3><small>Doel: ${escapeHtml(part?.label || group.target_id)}</small></div><span class="mini-chip">${group.options.length} keuzes</span></div><div class="option-group-body"><div class="option-choices">${group.options.map(option => `<button class="option-choice ${state.selections[group.option_group_id] === option.option_id ? 'active' : ''}" data-select-option="${attr(group.option_group_id)}|${attr(option.option_id)}"><div class="option-choice-color" style="--choice:${attr(option.material?.color || option.value)}"></div><strong>${escapeHtml(option.label)}</strong><small>${optionPrice(option.option_id)}</small></button>`).join('')}</div><details style="margin-top:12px"><summary class="text-button">Kleuren bewerken</summary><div style="margin-top:8px">${group.options.map(option => `<div class="option-editor-row"><input type="color" value="${attr(option.material?.color || option.value)}" data-edit-color="${attr(group.option_group_id)}|${attr(option.option_id)}"><input type="text" value="${attr(option.label)}" data-edit-label="${attr(group.option_group_id)}|${attr(option.option_id)}"><input type="number" value="${priceRuleFor(option.option_id)?.amount || 0}" data-edit-price="${attr(option.option_id)}" title="Meerprijs"></div>`).join('')}</div></details></div></section>`;
}

function renderPricingStep() {
  const pricing = currentPrice();
  return `<div class="content-grid"><section class="content-card"><div class="content-card-head"><div><h3>Prijsopbouw</h3><p>Dezelfde centrale prijsregels worden gebruikt in builder en runtime.</p></div></div><div class="content-card-body"><label class="field"><span>Basisprijs</span><input id="basePriceInput" type="number" min="0" step="1" value="${attr(state.data.blueprint.pricing.base_price.amount)}"></label><div style="margin-top:14px">${state.data.blueprint.pricing.rules.map(rule => `<div class="price-rule"><div><strong>${escapeHtml(rule.label)}</strong><small>${escapeHtml(optionLabel(rule.option_id))}</small></div><input type="number" step="1" value="${attr(rule.amount || 0)}" data-price-rule="${attr(rule.rule_id)}"><input type="checkbox" ${rule.enabled !== false ? 'checked' : ''} data-price-enabled="${attr(rule.rule_id)}"></div>`).join('')}</div></div></section><aside><div class="price-preview"><span>TESTCONFIGURATIE</span><strong id="pricePreviewTotal">${money(pricing.total, pricing.currency)}</strong><small>Zitting en onderstel worden onafhankelijk meegerekend.</small><div class="price-breakdown" id="priceBreakdown">${pricing.breakdown.map(item => `<div><span>${escapeHtml(item.label)}</span><strong>${money(item.amount,pricing.currency)}</strong></div>`).join('')}</div></div><div class="info-strip" style="margin-top:12px"><span>✓</span><div>Verander in stap 7 een zitting- of pootkleur en deze testberekening gebruikt exact dezelfde selectie.</div></div></aside></div>`;
}

function renderRulesStep() {
  const reviewed = Boolean(state.data.blueprint.workflow_ack?.rules_reviewed);
  return `<div class="content-grid"><section class="content-card"><div class="content-card-head"><div><h3>Combinatieregels</h3><p>Alleen nodig wanneer keuzes elkaar beïnvloeden.</p></div><span class="mini-chip">${state.data.blueprint.rules.length} regels</span></div><div class="content-card-body"><div class="info-strip"><span>✓</span><div><strong>Deze demo heeft twee volledig onafhankelijke kleurzones.</strong><br>Elke zittingkleur kan met iedere pootkleur worden gecombineerd; er zijn dus geen blokkaderegels nodig.</div></div><label class="task-row" style="margin-top:14px;cursor:pointer"><span>${reviewed ? '✓' : '○'}</span><div><strong>Ik heb de combinaties gecontroleerd</strong><small>Bevestig expliciet dat geen aanvullende regels nodig zijn.</small></div><input type="checkbox" id="rulesReviewed" ${reviewed ? 'checked' : ''}></label></div></section><aside class="content-card"><div class="content-card-head"><div><h3>Combinatietest</h3><p>Automatische controle over alle demo-keuzes.</p></div></div><div class="content-card-body"><div class="metric-grid" style="grid-template-columns:1fr 1fr">${metric('Combinaties','16','4 × 4')}${metric('Conflicten','0','geen blockers')}${metric('Verborgen','0','alle opties bereikbaar')}${metric('Verplicht','2','standaard ingevuld')}</div></div></aside></div>`;
}

function renderCommerceStep() {
  const commerce = state.data.blueprint.commerce || {};
  const payload = sampleOrderPayload();
  const adapters = [
    ['generic_embed','Generieke embed','postMessage + configureerbare ordervelden'],
    ['shopify','Shopify','Cart line properties en variantmapping'],
    ['woocommerce','WooCommerce','Cart item data en REST/webhookroute']
  ];
  return `<div class="content-grid"><section class="content-card"><div class="content-card-head"><div><h3>Bestelroute</h3><p>Kies hoe de gepubliceerde configurator zijn resultaat overdraagt.</p></div></div><div class="content-card-body"><div class="adapter-grid">${adapters.map(([id,title,desc]) => `<button class="adapter-card ${commerce.adapter === id ? 'active' : ''}" data-adapter="${id}"><strong>${title}</strong><small>${desc}</small></button>`).join('')}</div><div class="content-card-head" style="padding-left:0;padding-right:0;margin-top:14px"><div><h3>Ordervelden</h3><p>De demo stuurt leesbare labels, prijs en configuratie-ID mee.</p></div></div><div class="task-list">${state.data.blueprint.order_output.fields.map(field => taskRow('↗',field.label,field.source,field.required ? 'Verplicht' : 'Optioneel')).join('')}</div></div></section><aside class="content-card"><div class="content-card-head"><div><h3>Live payloadpreview</h3><p>Gebaseerd op je huidige zitting- en pootkeuze.</p></div></div><div class="content-card-body"><pre class="payload-preview" id="payloadPreview">${escapeHtml(JSON.stringify(payload,null,2))}</pre></div></aside></div>`;
}

function renderDesignStep() {
  const branding = state.data.blueprint.branding || {};
  const templates = [
    ['atelier','Atelier','Warm, premium en materiaalgericht','#ede6da','#dbe6dc'],
    ['minimal','Minimal','Veel witruimte en rustige productfocus','#f4f4f1','#e3e5e1'],
    ['technical','Technical','Compacte data en duidelijke specificaties','#e8eceb','#d9e2e0']
  ];
  return `<div class="content-grid"><section class="content-card"><div class="content-card-head"><div><h3>Klanttemplate</h3><p>Dit verandert de output, niet de Studio-builder zelf.</p></div></div><div class="content-card-body"><div class="template-grid">${templates.map(([id,title,desc,a,b]) => `<button class="template-card ${branding.theme === id ? 'active' : ''}" data-theme="${id}"><div class="template-preview" style="--template-a:${a};--template-b:${b}"></div><strong>${title}</strong><small>${desc}</small></button>`).join('')}</div><div class="field-grid" style="margin-top:14px"><label class="field"><span>Accentkleur</span><input id="accentColorInput" type="color" value="${attr(branding.accent_color || '#305c49')}"></label><label class="field"><span>Lay-out</span><select id="layoutInput"><option value="side_panel" ${branding.layout === 'side_panel' ? 'selected' : ''}>3D links, opties rechts</option><option value="bottom_sheet" ${branding.layout === 'bottom_sheet' ? 'selected' : ''}>Fullscreen + bottom sheet</option></select></label></div></div></section><aside>${viewerCard('designViewer','De gekozen productkleuren blijven live zichtbaar')}</aside></div>`;
}

function renderPublishStep() {
  const gate = state.data.publish_gate;
  return `<div class="content-grid"><section class="content-card"><div class="content-card-head"><div><h3>Definitieve kwaliteitscontrole</h3><p>Publiceren maakt een immutable runtime-snapshot.</p></div><span class="mini-chip">${gate.checks.filter(c => c.passed).length}/${gate.checks.length} groen</span></div><div class="content-card-body"><div class="publish-list">${gate.checks.map(check => `<div class="publish-check ${check.passed ? '' : 'blocked'}"><span>${check.passed ? '✓' : '!'}</span><div><strong>${escapeHtml(check.label)}</strong><small>${escapeHtml(String(check.detail || ''))}</small></div><em>${check.passed ? 'Gereed' : 'Blokkeert'}</em></div>`).join('')}</div></div></section><aside class="content-card"><div class="content-card-head"><div><h3>Klaar voor de eindklant?</h3><p>Test nog één keer mobiel, desktop, prijs en payload.</p></div></div><div class="content-card-body"><button class="button secondary full" id="publishPreviewButton">Open klantpreview</button><button class="button primary full" id="publishRuntimeButton" style="margin-top:8px" ${gate.passed ? '' : 'disabled'}>${state.data.project.status === 'published' ? 'Nieuwe runtimeversie publiceren' : 'Configurator publiceren'}</button>${state.data.runtime ? `<div class="info-strip" style="margin-top:12px"><span>✓</span><div>Live runtime v${state.data.runtime.version} bestaat. Een nieuwe publicatie maakt een nieuwe immutable versie.</div></div>` : ''}</div></aside></div>`;
}

function bindStep(stepId) {
  if (['model','quality','parts','options','design'].includes(stepId)) mountStageViewer(`${stepId}Viewer`, stepId === 'parts');
  if (stepId === 'intake') {
    $('#projectNameInput').addEventListener('change', saveProjectFields);
    $('#projectDescriptionInput').addEventListener('change', saveProjectFields);
    $('#projectCategoryInput').addEventListener('change', saveProjectFields);
  }
  if (stepId === 'sources') $('#glbUploadInput')?.addEventListener('change', uploadGlb);
  if (stepId === 'route') $$('[data-route-profile]').forEach(button => button.addEventListener('click', () => selectRoute(button.dataset.routeProfile)));
  if (stepId === 'quality') $$('[data-fact-key]').forEach(input => input.addEventListener('change', () => confirmFact(input.dataset.factKey, input.value)));
  if (stepId === 'parts') $$('[data-part-id]').forEach(button => button.addEventListener('click', () => selectPart(button.dataset.partId)));
  if (stepId === 'options') bindOptionControls();
  if (stepId === 'pricing') bindPricingControls();
  if (stepId === 'rules') $('#rulesReviewed').addEventListener('change', event => mutateBlueprint(blueprint => { blueprint.workflow_ack = { ...(blueprint.workflow_ack || {}), rules_reviewed: event.target.checked }; }, true));
  if (stepId === 'commerce') $$('[data-adapter]').forEach(button => button.addEventListener('click', () => mutateBlueprint(blueprint => { blueprint.commerce = { ...(blueprint.commerce || {}), adapter: button.dataset.adapter }; }, true)));
  if (stepId === 'design') {
    $$('[data-theme]').forEach(button => button.addEventListener('click', () => mutateBlueprint(blueprint => { blueprint.branding = { ...(blueprint.branding || {}), theme: button.dataset.theme }; }, true)));
    $('#accentColorInput').addEventListener('input', event => mutateBlueprint(blueprint => { blueprint.branding = { ...(blueprint.branding || {}), accent_color: event.target.value }; }, false));
    $('#accentColorInput').addEventListener('change', () => saveBlueprintNow());
    $('#layoutInput').addEventListener('change', event => mutateBlueprint(blueprint => { blueprint.branding = { ...(blueprint.branding || {}), layout: event.target.value }; }, true));
  }
  if (stepId === 'publish') {
    $('#publishPreviewButton').addEventListener('click', openPreview);
    $('#publishRuntimeButton').addEventListener('click', publishRuntime);
  }
}

async function mountStageViewer(containerId, selectable = false) {
  const mount = document.getElementById(containerId);
  if (!mount || !state.data.active_asset) return;
  disposeStageViewer();
  const card = mount.closest('.viewer-card');
  state.stageViewer = new ProductViewer(mount, {
    onReady: () => { card?.classList.add('ready'); applySelections(state.stageViewer); },
    onSelect: meshName => { if (selectable) selectPartByMesh(meshName); },
    onError: error => toast('3D-weergave', error.message, true)
  });
  await state.stageViewer.load(state.data.active_asset.public_url);
  card?.querySelector('[data-reset-view]')?.addEventListener('click', () => state.stageViewer.reset());
  card?.querySelector('[data-fullscreen-view]')?.addEventListener('click', () => state.stageViewer.fullscreen());
}

function viewerCard(id, hint) {
  const asset = state.data.active_asset;
  return `<div class="viewer-card"><img class="viewer-fallback" src="${attr(asset?.poster_url || '/assets/demo-chair-preview.png')}" alt=""><div class="viewer-mount" id="${id}"></div><div class="viewer-toolbar"><span class="viewer-pill"><i></i> Echt configureerbaar GLB</span><div class="viewer-actions"><button data-reset-view title="Camera resetten">↺</button><button data-fullscreen-view title="Volledig scherm">⛶</button></div></div><div class="viewer-foot">${escapeHtml(hint)}</div></div>`;
}

function bindOptionControls() {
  $$('[data-select-option]').forEach(button => button.addEventListener('click', () => {
    const [groupId, optionId] = button.dataset.selectOption.split('|');
    chooseOption(groupId, optionId);
  }));
  $$('[data-edit-color]').forEach(input => input.addEventListener('input', () => {
    const [groupId, optionId] = input.dataset.editColor.split('|');
    mutateBlueprint(blueprint => {
      const option = blueprint.option_groups.find(g => g.option_group_id === groupId)?.options.find(o => o.option_id === optionId);
      if (option) { option.value = input.value; option.material = { ...(option.material || {}), color: input.value }; }
    }, false);
    if (state.selections[groupId] === optionId) applySelections(state.stageViewer);
  }));
  $$('[data-edit-color]').forEach(input => input.addEventListener('change', saveBlueprintNow));
  $$('[data-edit-label]').forEach(input => input.addEventListener('change', () => {
    const [groupId, optionId] = input.dataset.editLabel.split('|');
    mutateBlueprint(blueprint => { const option = blueprint.option_groups.find(g => g.option_group_id === groupId)?.options.find(o => o.option_id === optionId); if (option) option.label = input.value; }, true);
  }));
  $$('[data-edit-price]').forEach(input => input.addEventListener('change', () => {
    mutateBlueprint(blueprint => { const rule = blueprint.pricing.rules.find(r => r.option_id === input.dataset.editPrice); if (rule) rule.amount = Number(input.value || 0); }, true);
  }));
}

function bindPricingControls() {
  $('#basePriceInput').addEventListener('change', event => mutateBlueprint(blueprint => { blueprint.pricing.base_price.amount = Number(event.target.value || 0); }, true));
  $$('[data-price-rule]').forEach(input => input.addEventListener('change', () => mutateBlueprint(blueprint => { const rule = blueprint.pricing.rules.find(r => r.rule_id === input.dataset.priceRule); if (rule) rule.amount = Number(input.value || 0); }, true)));
  $$('[data-price-enabled]').forEach(input => input.addEventListener('change', () => mutateBlueprint(blueprint => { const rule = blueprint.pricing.rules.find(r => r.rule_id === input.dataset.priceEnabled); if (rule) rule.enabled = input.checked; }, true)));
}

function chooseOption(groupId, optionId) {
  state.selections[groupId] = optionId;
  applySelections(state.stageViewer);
  applySelections(state.previewViewer);
  $$(`[data-select-option^="${css(groupId)}|"]`).forEach(button => button.classList.toggle('active', button.dataset.selectOption.endsWith(`|${optionId}`)));
  updatePriceDom();
}

function applySelections(viewer) {
  if (!viewer) return;
  for (const group of state.data.blueprint.option_groups || []) {
    const optionId = state.selections[group.option_group_id];
    const option = group.options.find(item => item.option_id === optionId) || group.options[0];
    const part = state.data.blueprint.parts.find(item => item.part_id === group.target_id);
    if (option && part) viewer.applyMaterial(part.mesh_targets, option.material);
  }
}

function selectPart(partId) {
  state.selectedPartId = partId;
  const part = state.data.blueprint.parts.find(item => item.part_id === partId);
  state.stageViewer?.highlight(part?.mesh_targets || []);
  $$('[data-part-id]').forEach(button => button.classList.toggle('active', button.dataset.partId === partId));
}

function selectPartByMesh(meshName) {
  const part = state.data.blueprint.parts.find(item => item.mesh_targets?.includes(meshName));
  if (part) selectPart(part.part_id);
}

async function saveProjectFields() {
  setSaving(true);
  try {
    const result = await api('/api/project/update', { method: 'POST', body: JSON.stringify({
      project_id: state.projectId,
      name: $('#projectNameInput').value,
      description: $('#projectDescriptionInput').value,
      category: $('#projectCategoryInput').value
    }) });
    state.data.project = result.project;
    await reloadProjectState(false);
    toast('Productbrief opgeslagen', 'Het bouwplan gebruikt nu de bijgewerkte context.');
  } catch (error) { toast('Opslaan mislukt', error.message, true); }
  finally { setSaving(false); }
}

async function selectRoute(profile) {
  setSaving(true);
  try {
    const result = await api('/api/project/update', { method: 'POST', body: JSON.stringify({ project_id: state.projectId, requested_profile: profile }) });
    state.data.project = result.project;
    renderStep();
  } catch (error) { toast('Route niet opgeslagen', error.message, true); }
  finally { setSaving(false); }
}

async function confirmFact(key, rawValue) {
  try {
    const fact = state.data.project.facts.find(item => item.key === key);
    const result = await api('/api/facts/confirm', { method: 'POST', body: JSON.stringify({ project_id: state.projectId, key, value: Number(rawValue), unit: fact?.unit || null }) });
    state.data.project = result.project;
    await reloadProjectState(false);
    toast('Maat bevestigd', `${fact?.label || key} is als gecontroleerde waarde opgeslagen.`);
  } catch (error) { toast('Bevestigen mislukt', error.message, true); }
}

async function uploadGlb(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  setSaving(true, 'GLB uploaden…');
  try {
    const dataUrl = await readAsDataUrl(file);
    await api('/api/assets/upload', { method: 'POST', body: JSON.stringify({ project_id: state.projectId, name: file.name, data_url: dataUrl }) });
    await reloadProjectState(true);
    toast('GLB ontvangen', 'Het model staat als reviewdraft klaar in stap 5.');
    changeStep('quality');
  } catch (error) { toast('Upload mislukt', error.message, true); }
  finally { setSaving(false); }
}

function mutateBlueprint(mutator, renderAfter = false) {
  const next = deep(state.data.blueprint);
  mutator(next);
  state.data.blueprint = next;
  state.progress = evaluateStudioProgress(state.data);
  renderProjectShell();
  setSaving(true);
  clearTimeout(state.saveTimer);
  state.saveTimer = setTimeout(async () => {
    try { await saveBlueprintNow(); if (renderAfter) renderStep(); }
    catch (error) { toast('Opslaan mislukt', error.message, true); }
  }, renderAfter ? 80 : 550);
}

async function saveBlueprintNow() {
  clearTimeout(state.saveTimer);
  const result = await api('/api/blueprint/update', { method: 'POST', body: JSON.stringify({ project_id: state.projectId, blueprint: state.data.blueprint }) });
  state.data.blueprint = result.blueprint;
  setSaving(false);
  await reloadProjectState(false);
  return result.blueprint;
}

async function reloadProjectState(render = false) {
  const result = await api(`/api/studio?project_id=${encodeURIComponent(state.projectId)}`);
  state.data = result;
  state.progress = evaluateStudioProgress(result);
  renderProjectShell();
  if (render) renderStep();
}

function setSaving(saving, label = null) {
  const indicator = $('#saveIndicator');
  indicator.innerHTML = saving ? `<i style="background:#d79b3c"></i> ${escapeHtml(label || 'Opslaan…')}` : '<i></i> Alles opgeslagen';
}

async function openPreview() {
  if (!state.data) return;
  $('#previewOverlay').classList.add('open');
  $('#previewOverlay').setAttribute('aria-hidden','false');
  $('#previewOverlayTitle').textContent = state.data.project.name;
  renderCustomerPreview();
}

function closePreview() {
  $('#previewOverlay').classList.remove('open');
  $('#previewOverlay').setAttribute('aria-hidden','true');
  state.previewViewer?.dispose(); state.previewViewer = null;
}

function setPreviewDevice(device) {
  state.previewDevice = device;
  $('#customerPreviewFrame').className = `customer-preview-frame ${device}`;
  $$('[data-preview-device]').forEach(button => button.classList.toggle('active', button.dataset.previewDevice === device));
  setTimeout(() => state.previewViewer?.resize(), 280);
}

async function renderCustomerPreview() {
  const mount = $('#customerPreviewMount');
  const project = state.data.project;
  const groups = state.data.blueprint.option_groups;
  mount.innerHTML = `<div class="customer-preview-shell"><div class="customer-preview-visual" id="customerPreviewVisual"><img src="${attr(state.data.active_asset?.poster_url || '/assets/demo-chair-preview.png')}" alt=""><div class="customer-preview-viewer" id="customerPreviewViewer"></div></div><div class="customer-preview-panel"><span class="kicker">STEL JOUW STOEL SAMEN</span><h2>${escapeHtml(project.name.replace(' Configurator',''))}</h2><p>${escapeHtml(project.description || '')}</p><div id="customerGroups">${groups.map(customerGroupMarkup).join('')}</div><div class="customer-total"><div><span>Totaalprijs</span><small>Inclusief btw</small></div><strong id="customerPreviewPrice">${money(currentPrice().total)}</strong></div><button class="customer-cta" id="customerAddButton">Voeg configuratie toe</button></div></div>`;
  $$('[data-customer-option]', mount).forEach(button => button.addEventListener('click', () => {
    const [groupId, optionId] = button.dataset.customerOption.split('|');
    state.selections[groupId] = optionId;
    $$(`[data-customer-option^="${css(groupId)}|"]`, mount).forEach(item => item.classList.toggle('active', item.dataset.customerOption.endsWith(`|${optionId}`)));
    const group = state.data.blueprint.option_groups.find(item => item.option_group_id === groupId);
    const option = group.options.find(item => item.option_id === optionId);
    $(`[data-customer-label="${css(groupId)}"]`, mount).textContent = option.label;
    applySelections(state.previewViewer);
    updatePriceDom();
  }));
  $('#customerAddButton').addEventListener('click', () => {
    const payload = sampleOrderPayload();
    toast('Configuratie getest', `${payload.fields.seat_color} + ${payload.fields.leg_finish} is klaar voor de winkelmand.`);
  });
  state.previewViewer?.dispose();
  state.previewViewer = new ProductViewer($('#customerPreviewViewer'), { onReady: () => { $('#customerPreviewVisual').classList.add('ready'); applySelections(state.previewViewer); } });
  await state.previewViewer.load(state.data.active_asset.public_url);
  setPreviewDevice(state.previewDevice);
}

function customerGroupMarkup(group) {
  const selected = state.selections[group.option_group_id] || group.default_option_id || group.options[0]?.option_id;
  const current = group.options.find(option => option.option_id === selected) || group.options[0];
  return `<div class="customer-group"><div class="customer-group-head"><strong>${escapeHtml(group.label)}</strong><span data-customer-label="${attr(group.option_group_id)}">${escapeHtml(current?.label || '')}</span></div><div class="customer-swatches">${group.options.map(option => `<button class="customer-swatch ${selected === option.option_id ? 'active' : ''}" style="--swatch:${attr(option.material?.color || option.value)}" data-customer-option="${attr(group.option_group_id)}|${attr(option.option_id)}" aria-label="${attr(option.label)}"></button>`).join('')}</div></div>`;
}

function currentPrice() {
  try { return calculateConfigurationPrice({ pricing: state.data.blueprint.pricing, selections: state.selections, facts: state.data.project.facts, quantity: 1 }); }
  catch { return { currency:'EUR', total:0, breakdown:[] }; }
}

function updatePriceDom() {
  const price = currentPrice();
  if ($('#pricePreviewTotal')) $('#pricePreviewTotal').textContent = money(price.total, price.currency);
  if ($('#priceBreakdown')) $('#priceBreakdown').innerHTML = price.breakdown.map(item => `<div><span>${escapeHtml(item.label)}</span><strong>${money(item.amount,price.currency)}</strong></div>`).join('');
  if ($('#customerPreviewPrice')) $('#customerPreviewPrice').textContent = money(price.total, price.currency);
  if ($('#payloadPreview')) $('#payloadPreview').textContent = JSON.stringify(sampleOrderPayload(), null, 2);
}

function sampleOrderPayload() {
  const price = currentPrice();
  const runtime = {
    runtime_config_id: state.data.runtime?.runtime_config_id || 'preview_runtime', version: state.data.runtime?.version || 0,
    option_groups: state.data.blueprint.option_groups, order_output: state.data.blueprint.order_output, product: { name: state.data.project.name }
  };
  const ruleState = evaluateConfiguration({ optionGroups: runtime.option_groups, rules: state.data.blueprint.rules, selections: state.selections, facts: state.data.project.facts });
  return buildOrderPayload({ runtime, selections: state.selections, price, ruleState, previewUrl: state.data.active_asset?.poster_url || null });
}

async function publishRuntime() {
  try {
    const result = await api('/api/publish', { method: 'POST', body: JSON.stringify({ project_id: state.projectId }) });
    await reloadProjectState(true);
    toast('Configurator gepubliceerd', `Immutable runtime v${result.runtime.version} is aangemaakt.`);
    window.open(result.public_url, '_blank', 'noopener');
  } catch (error) {
    if (error.payload?.gate) state.data.publish_gate = error.payload.gate;
    renderStep();
    toast('Publicatie geblokkeerd', error.message, true);
  }
}

function renderAssistant() {
  const step = currentStep();
  const blockers = state.progress.blockers.filter(item => item.step === step.id);
  $('#assistantTitle').textContent = `${step.label} begeleiden`;
  const contextual = assistantCopy(step.id);
  $('#assistantBody').innerHTML = `<div class="assistant-message action"><strong>Volgende slimme actie</strong>${escapeHtml(blockers[0]?.message || contextual)}</div><div class="assistant-message"><strong>Waarom deze stap bestaat</strong>${escapeHtml(step.description)}</div><div class="assistant-checklist">${assistantChecks(step.id).map(item => `<div class="assistant-check"><span>${item.ok ? '✓' : '○'}</span><div>${escapeHtml(item.label)}</div></div>`).join('')}</div>`;
}

function answerAssistant() {
  const input = $('#assistantQuestion');
  const question = input.value.trim();
  if (!question) return;
  const message = document.createElement('div');
  message.className = 'assistant-message';
  message.innerHTML = `<strong>Studio antwoord</strong>${escapeHtml(assistantAnswer(question))}`;
  $('#assistantBody').append(message);
  $('#assistantBody').scrollTop = $('#assistantBody').scrollHeight;
  input.value = '';
}

function assistantCopy(step) {
  const map = {
    intake:'Controleer of de productbrief beschrijft wat de eindklant kan kiezen, niet alleen hoe het product eruitziet.',
    sources:'Gebruik een GLB wanneer de geometrie al bestaat; gebruik foto-AI alleen als een nieuwe 3D-draft echt nodig is.',
    route:'De uploadroute is hier correct omdat de stoel al gecontroleerd en opgesplitst is.',
    model:'Draai het model rondom en controleer of de zitting en het onderstel intact zijn gebleven na optimalisatie.',
    quality:'Bevestig alleen maten die gemeten of betrouwbaar aangeleverd zijn.',
    parts:'Klik beide zones aan. Iedere selectie moet precies één logisch productdeel highlighten.',
    options:'Test nu bewust een lichte zitting met donkere poten en daarna het omgekeerde.',
    pricing:'Controleer dat twee gekozen meerprijzen bij elkaar worden opgeteld.',
    rules:'Bevestig dat alle zestien kleurcombinaties toegestaan zijn.',
    commerce:'Controleer of de payload leesbare labels bevat, niet alleen interne IDs.',
    design:'De klanttemplate mag de builder nooit veranderen; alleen de gepubliceerde output.',
    publish:'Open eerst de mobiele preview en publiceer daarna pas een immutable runtime.'
  };
  return map[step] || 'Volg de huidige stap en los blockers op voordat je verdergaat.';
}

function assistantChecks(step) {
  const p = state.progress.status;
  const map = {
    intake:[['Productnaam aanwezig',Boolean(state.data.project.name)],['Categorie gekozen',Boolean(state.data.project.intake?.category)],['Configuratiedoel beschreven',Boolean(state.data.project.description)]],
    sources:[['GLB beschikbaar',Boolean(state.data.active_asset)],['Menselijke bronreview',state.data.active_asset?.quality_status === 'accepted']],
    route:[['Route verklaarbaar',Boolean(state.data.project.route_decision || state.data.active_asset)],['Geen automatische publicatie',true]],
    model:[['Twee meshes',state.data.active_asset?.metrics?.meshes === 2],['Mobiel model',Boolean(state.data.active_asset?.metrics?.mobile_ready)]],
    quality:[['Model geaccepteerd',state.data.active_asset?.quality_status === 'accepted'],['Kritieke maten bevestigd',p.quality]],
    parts:[['Zitting gekoppeld',Boolean(state.data.blueprint.parts.find(x=>x.part_id==='part_seat')?.mesh_targets.length)],['Poten gekoppeld',Boolean(state.data.blueprint.parts.find(x=>x.part_id==='part_legs')?.mesh_targets.length)]],
    options:[['Zittingkleuren compleet',state.data.blueprint.option_groups.find(x=>x.option_group_id==='group_seat_color')?.options.length >= 2],['Pootkleuren compleet',state.data.blueprint.option_groups.find(x=>x.option_group_id==='group_leg_finish')?.options.length >= 2]],
    pricing:[['Basisprijs > 0',Number(state.data.blueprint.pricing.base_price.amount)>0],['Meerprijzen actief',state.data.blueprint.pricing.rules.some(r=>r.enabled!==false)]],
    rules:[['Regels beoordeeld',Boolean(state.data.blueprint.workflow_ack?.rules_reviewed)]],
    commerce:[['Adapter gekozen',Boolean(state.data.blueprint.commerce?.adapter)],['Ordervelden gemapt',state.data.blueprint.order_output.fields.length>=2]],
    design:[['Template gekozen',Boolean(state.data.blueprint.branding?.theme)],['Accentkleur gekozen',Boolean(state.data.blueprint.branding?.accent_color)]],
    publish:[['Publicatiegate groen',Boolean(state.data.publish_gate.passed)],['Klantpreview getest',true]]
  };
  return (map[step] || []).map(([label,ok]) => ({label,ok}));
}

function assistantAnswer(question) {
  const lower = question.toLowerCase();
  if (lower.includes('kleur') || lower.includes('zitting') || lower.includes('poot')) return 'Gebruik stap 7. De zitting stuurt alleen mesh seat_and_back; het onderstel stuurt alleen legs_and_footrest. Beide keuzes blijven ook in prijs en orderpayload apart.';
  if (lower.includes('prijs')) return 'Open stap 8. De centrale prijsengine telt de basisprijs en alle actieve meerprijzen van de huidige selectie op.';
  if (lower.includes('mobiel')) return 'Open Preview en kies Mobiel. De viewer berekent de camerafstand opnieuw op basis van de smalle beeldverhouding.';
  return `Voor ${currentStep().label.toLowerCase()} is de belangrijkste controle: ${assistantCopy(state.step)}`;
}

function showDashboard() {
  disposeViewers();
  state.data = null; state.projectId = null;
  renderDashboard();
}

function showSimpleView(view) {
  if (view === 'dashboard') return showDashboard();
  state.view = view;
  $('#dashboardView').classList.add('hidden');
  $('#projectView').classList.add('hidden');
  $('#simpleView').classList.remove('hidden');
  const titles = {templates:'Templates',assets:'3D-bibliotheek',connections:'Koppelingen',analytics:'Analytics',settings:'Instellingen'};
  $('#breadcrumb').innerHTML = `<strong>${escapeHtml(titles[view] || view)}</strong>`;
  $('#simpleView').innerHTML = `<div class="placeholder-view"><span class="kicker">PLATFORMMODULE</span><h2>${escapeHtml(titles[view] || view)}</h2><p>Deze module staat los van de configuratorbuilder. De huidige release concentreert zich op de volledige twaalfstappenflow en de werkende stoelconfigurator.</p><button class="button primary" id="placeholderBack">Terug naar projecten</button></div>`;
  $('#placeholderBack').addEventListener('click', showDashboard);
  setActiveAppNav(view);
  closeMobileSidebar();
}

function setActiveAppNav(view) { $$('.app-nav-item[data-view]').forEach(button => button.classList.toggle('active', button.dataset.view === view)); }
function toggleMobileSidebar() { $('#appSidebar').classList.toggle('open'); $('#sidebarBackdrop').classList.toggle('open'); }
function closeMobileSidebar() { $('#appSidebar').classList.remove('open'); $('#sidebarBackdrop').classList.remove('open'); }

function openNewProject() { $('#newProjectModal').classList.add('open'); $('#newProjectModal').setAttribute('aria-hidden','false'); setTimeout(() => $('#newProjectForm input')?.focus(), 80); }
function closeNewProject() { $('#newProjectModal').classList.remove('open'); $('#newProjectModal').setAttribute('aria-hidden','true'); }
async function createProject(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  try {
    const result = await api('/api/projects', { method:'POST', body:JSON.stringify(Object.fromEntries(form.entries())) });
    event.currentTarget.reset(); closeNewProject(); await loadProjects(); renderDashboard(); await openProject(result.project.project_id, 'intake');
    toast('Project aangemaakt', 'Studio heeft een leeg, begeleid bouwplan klaargezet.');
  } catch (error) { toast('Project niet aangemaakt', error.message, true); }
}

async function logout() { try { await api('/api/auth/logout',{method:'POST',body:'{}'}); } finally { location.assign('/'); } }

function disposeStageViewer() { state.stageViewer?.dispose(); state.stageViewer = null; }
function disposeViewers() { disposeStageViewer(); state.previewViewer?.dispose(); state.previewViewer = null; }

function taskRow(icon,title,description,status) { return `<div class="task-row"><span>${icon}</span><div><strong>${escapeHtml(title)}</strong><small>${escapeHtml(description)}</small></div><em class="mini-chip">${escapeHtml(status)}</em></div>`; }
function qualityRow(title,description,status) { return `<div class="quality-row"><span>${status === 'ok' ? '✓' : '!'}</span><div><strong>${escapeHtml(title)}</strong><small>${escapeHtml(description)}</small></div><em class="${status === 'warning' ? 'warning' : ''}">${status === 'ok' ? 'Gereed' : 'Aandacht'}</em></div>`; }
function metric(label,value,description) { return `<div class="metric-card"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong><small>${escapeHtml(description)}</small></div>`; }
function optionPrice(optionId) { const rule = priceRuleFor(optionId); return rule && Number(rule.amount) ? `+ ${money(rule.amount)}` : 'Inbegrepen'; }
function priceRuleFor(optionId) { return state.data.blueprint.pricing.rules.find(rule => rule.option_id === optionId); }
function optionLabel(optionId) { for (const group of state.data.blueprint.option_groups) { const option = group.options.find(item => item.option_id === optionId); if (option) return option.label; } return optionId || 'Algemeen'; }
function capabilityLabel(value) { return ({material:'materiaal',finish:'afwerking',pricing:'prijs',rules:'regels',order_output:'order',visibility:'zichtbaarheid'})[value] || value; }
function providerStatus(provider, availability) { if (provider === 'Actief') return 'Nu gebruikt'; const map={Meshy:'meshy',Tripo:'tripo',Rodin:'rodin',FreeCAD:'freecad'}; return availability[map[provider]] ? `${provider} live` : `${provider} demo`; }
function categoryOptions(selected) { const options=[['table','Tafel'],['cabinet','Kast of opbergsysteem'],['chair','Stoel of barkruk'],['sofa','Bank of zitmeubel'],['door','Deur of paneel'],['lighting','Verlichting'],['machine','Machine of technisch product'],['other','Ander product']]; return options.map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${label}</option>`).join(''); }
function statusLabel(status) { return ({draft:'Concept',published:'Gepubliceerd',review:'Controle nodig'})[status] || status || 'Concept'; }
function money(value,currency='EUR') { return new Intl.NumberFormat('nl-NL',{style:'currency',currency,maximumFractionDigits:0}).format(Number(value)||0); }
function formatNumber(value) { return new Intl.NumberFormat('nl-NL').format(Number(value)||0); }
function formatBytes(value) { const bytes=Number(value)||0; if(bytes<1024)return`${bytes} B`;if(bytes<1024**2)return`${(bytes/1024).toFixed(1)} KB`;return`${(bytes/1024**2).toFixed(1)} MB`; }
function relativeTime(value) { if(!value)return'zojuist';const diff=Date.now()-new Date(value).getTime();const min=Math.max(0,Math.round(diff/60000));if(min<1)return'zojuist';if(min<60)return`${min} min geleden`;const h=Math.round(min/60);if(h<24)return`${h} uur geleden`;return`${Math.round(h/24)} dagen geleden`; }
function readAsDataUrl(file) { return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error);reader.readAsDataURL(file)}); }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>'"]/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char])); }
function attr(value) { return escapeHtml(value); }
function css(value) { return String(value).replace(/(["\\])/g,'\\$1'); }
function toast(title,message,error=false) { const el=document.createElement('div');el.className=`toast ${error?'error':''}`;el.innerHTML=`<strong>${escapeHtml(title)}</strong><span>${escapeHtml(message||'')}</span>`;$('#toasts').append(el);setTimeout(()=>el.remove(),4300); }
