export const STUDIO_STEPS = [
  { id: 'intake', number: 1, label: 'Productbrief', short: 'Brief', icon: '01', description: 'Doel, producttype en gewenste keuzes vastleggen.' },
  { id: 'sources', number: 2, label: 'Bronmateriaal', short: 'Bronnen', icon: '02', description: 'Foto’s, 3D-bestanden, tekeningen en maatvoering verzamelen.' },
  { id: 'route', number: 3, label: 'Studio Engine', short: 'Route', icon: '03', description: 'De beste AI-, upload- of CAD-route kiezen.' },
  { id: 'model', number: 4, label: '3D-model', short: 'Model', icon: '04', description: 'Het model genereren, importeren en technisch voorbereiden.' },
  { id: 'quality', number: 5, label: 'Modelcontrole', short: 'Controle', icon: '05', description: 'Vorm, schaal, prestaties en kwaliteit menselijk goedkeuren.' },
  { id: 'parts', number: 6, label: 'Onderdelen', short: 'Delen', icon: '06', description: 'Geometrie indelen en configureerbare zones bepalen.' },
  { id: 'options', number: 7, label: 'Klantkeuzes', short: 'Opties', icon: '07', description: 'Materialen, kleuren, varianten en standaardkeuzes maken.' },
  { id: 'pricing', number: 8, label: 'Prijzen', short: 'Prijs', icon: '08', description: 'Basisprijs, toeslagen en formules instellen en testen.' },
  { id: 'rules', number: 9, label: 'Regels', short: 'Regels', icon: '09', description: 'Combinaties, afhankelijkheden en waarschuwingen bouwen.' },
  { id: 'commerce', number: 10, label: 'Webshop & order', short: 'Order', icon: '10', description: 'Checkout, velden, SKU’s en payloads koppelen.' },
  { id: 'design', number: 11, label: 'Vormgeving', short: 'Design', icon: '11', description: 'De uiteindelijke klantconfigurator vormgeven.' },
  { id: 'publish', number: 12, label: 'Testen & live', short: 'Live', icon: '12', description: 'Desktop, mobiel, output en publicatie volledig controleren.' }
];

export function evaluateStudioProgress(data) {
  const project = data?.project || {};
  const blueprint = data?.blueprint || {};
  const active = data?.active_asset;
  const candidate = data?.candidate_asset;
  const facts = project.facts || [];
  const category = project.intake?.category;
  const parts = blueprint.parts || [];
  const groups = blueprint.option_groups || [];
  const price = Number(blueprint.pricing?.base_price?.amount || 0);
  const orderFields = blueprint.order_output?.fields || [];
  const commerce = blueprint.commerce || {};
  const branding = blueprint.branding || {};
  const model = candidate || active;
  const confirmedCritical = (project.required_fact_keys || []).every(key => facts.some(f => f.key === key && f.status === 'confirmed'));
  const mappedParts = parts.length > 0 && parts.filter(part => part.configurable !== false).every(part => (part.mesh_targets || []).length > 0);
  const validGroups = groups.length > 0 && groups.every(group => (group.options || []).length >= 2 && group.target_id);
  const outputReady = orderFields.length >= 2 && Boolean(commerce.adapter);
  const designReady = Boolean(branding.theme && branding.accent_color && branding.layout);
  const status = {
    intake: Boolean(project.name && project.description && category),
    sources: Boolean((data?.assets || []).length || model),
    route: Boolean(project.route_decision || active?.source_type === 'verified_upload'),
    model: Boolean(model?.public_url),
    quality: Boolean(active?.quality_status === 'accepted' && confirmedCritical),
    parts: mappedParts,
    options: validGroups,
    pricing: Number.isFinite(price) && price > 0,
    rules: Boolean(blueprint.workflow_ack?.rules_reviewed || (blueprint.rules || []).length),
    commerce: outputReady,
    design: designReady,
    publish: Boolean(data?.publish_gate?.passed && outputReady && designReady)
  };
  const firstIncomplete = STUDIO_STEPS.find(step => !status[step.id])?.id || 'publish';
  const completed = STUDIO_STEPS.filter(step => status[step.id]).length;
  return {
    status,
    completed,
    total: STUDIO_STEPS.length,
    percent: Math.round(completed / STUDIO_STEPS.length * 100),
    firstIncomplete,
    blockers: buildBlockers({ project, blueprint, active, candidate, confirmedCritical, mappedParts, validGroups, price, outputReady, designReady, data })
  };
}

export function stepState(stepId, progress, currentStep) {
  if (stepId === currentStep) return 'active';
  if (progress.status[stepId]) return 'complete';
  const currentIndex = STUDIO_STEPS.findIndex(step => step.id === currentStep);
  const stepIndex = STUDIO_STEPS.findIndex(step => step.id === stepId);
  return stepIndex < currentIndex ? 'attention' : 'upcoming';
}

export function nextStep(stepId) {
  const index = STUDIO_STEPS.findIndex(step => step.id === stepId);
  return STUDIO_STEPS[Math.min(index + 1, STUDIO_STEPS.length - 1)]?.id;
}

export function previousStep(stepId) {
  const index = STUDIO_STEPS.findIndex(step => step.id === stepId);
  return STUDIO_STEPS[Math.max(index - 1, 0)]?.id;
}

function buildBlockers({ project, blueprint, active, candidate, confirmedCritical, mappedParts, validGroups, price, outputReady, designReady, data }) {
  const blockers = [];
  if (!project.description) blockers.push({ step: 'intake', severity: 'blocking', message: 'Beschrijf wat de eindklant aan dit product moet kunnen kiezen.' });
  if (!project.intake?.category) blockers.push({ step: 'intake', severity: 'blocking', message: 'Kies een productcategorie voor een betrouwbare 3D-route.' });
  if (!(active || candidate)) blockers.push({ step: 'sources', severity: 'blocking', message: 'Voeg een bestaand 3D-model of voldoende productbeelden toe.' });
  if (candidate?.quality_status === 'pending_review') blockers.push({ step: 'quality', severity: 'blocking', message: 'Er staat een nieuwe 3D-draft klaar voor menselijke controle.' });
  if (active && active.quality_status !== 'accepted') blockers.push({ step: 'quality', severity: 'blocking', message: 'Het actieve model is nog niet geaccepteerd.' });
  if (!confirmedCritical) blockers.push({ step: 'quality', severity: 'blocking', message: 'Kritieke afmetingen moeten worden gemeten of bevestigd.' });
  if (!mappedParts) blockers.push({ step: 'parts', severity: 'blocking', message: 'Niet ieder configureerbaar onderdeel is aan geometrie gekoppeld.' });
  if (!validGroups) blockers.push({ step: 'options', severity: 'blocking', message: 'Maak minimaal één volledige optiegroep met twee keuzes.' });
  if (!(Number.isFinite(price) && price > 0)) blockers.push({ step: 'pricing', severity: 'blocking', message: 'Stel een basisprijs hoger dan nul in.' });
  if (!blueprint.workflow_ack?.rules_reviewed && !(blueprint.rules || []).length) blockers.push({ step: 'rules', severity: 'attention', message: 'Bevestig dat er geen combinatieregels nodig zijn, of maak een regel.' });
  if (!outputReady) blockers.push({ step: 'commerce', severity: 'blocking', message: 'Kies een orderroute en map minimaal twee uitvoervelden.' });
  if (!designReady) blockers.push({ step: 'design', severity: 'blocking', message: 'Kies een klanttemplate, accentkleur en lay-out.' });
  for (const item of data?.publish_gate?.blocking || []) blockers.push({ step: gateStep(item.id), severity: 'blocking', message: item.label });
  return dedupe(blockers);
}

function gateStep(id = '') {
  if (id.startsWith('fact:')) return 'quality';
  if (id === 'configurability') return 'parts';
  if (id === 'base_price') return 'pricing';
  if (id === 'rules') return 'rules';
  if (id === 'order_output') return 'commerce';
  if (id === 'human_review') return 'quality';
  return 'publish';
}

function dedupe(items) {
  const seen = new Set();
  return items.filter(item => {
    const key = `${item.step}:${item.message}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
