import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import path from 'node:path';

const root=path.resolve(new URL('..',import.meta.url).pathname);

test('FreeCAD worker requires all confirmed dimensions and exposes App explicitly', () => {
  const script=String.raw`
import importlib.util, inspect, json, pathlib, sys
sys.dont_write_bytecode=True
p=pathlib.Path(sys.argv[1])
spec=importlib.util.spec_from_file_location('cfg_worker',p)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
assert 'App' in inspect.signature(m.add_box).parameters
ok=m.dimensions_from_params({'dimensions.length_mm':1800,'dimensions.width_mm':900,'dimensions.height_mm':760})
assert ok['height_mm']==760
m.validate_template_dimensions('table',ok)
try:
    m.validate_template_dimensions('table',{'length_mm':500,'width_mm':300,'height_mm':200})
except ValueError as e:
    assert 'safe template minima' in str(e)
else:
    raise AssertionError('unsafe table dimensions passed template validation')
try:
    m.dimensions_from_params({'dimensions.length_mm':1800,'dimensions.width_mm':900})
except ValueError as e:
    assert 'height_mm' in str(e)
else:
    raise AssertionError('missing confirmed dimension was silently replaced')
print(json.dumps(ok))
`;
  const result=spawnSync('python3',['-c',script,path.join(root,'server/freecad_worker/worker.py')],{encoding:'utf8'});
  assert.equal(result.status,0,result.stderr||result.stdout);
  assert.match(result.stdout,/"length_mm": 1800/);
});
