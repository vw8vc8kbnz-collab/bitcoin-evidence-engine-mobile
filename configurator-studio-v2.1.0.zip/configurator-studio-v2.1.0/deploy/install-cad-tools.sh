#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/configurator-studio}"
ENV_FILE="$APP_DIR/.env"

[ "$(id -u)" -eq 0 ] || { echo "Voer dit script uit met sudo/root." >&2; exit 1; }
command -v apt-get >/dev/null || { echo "Deze helper ondersteunt Debian/Ubuntu met apt-get." >&2; exit 1; }
[ -d "$APP_DIR" ] || { echo "App-map niet gevonden: $APP_DIR" >&2; exit 1; }

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends freecad blender

FREECAD_BIN=""
for candidate in freecadcmd FreeCADCmd freecad; do
  if command -v "$candidate" >/dev/null 2>&1; then FREECAD_BIN="$(command -v "$candidate")"; break; fi
done
BLENDER_BIN="$(command -v blender || true)"

[ -n "$FREECAD_BIN" ] || { echo "FreeCAD commandline-tool is na installatie niet gevonden." >&2; exit 1; }
[ -n "$BLENDER_BIN" ] || { echo "Blender is na installatie niet gevonden." >&2; exit 1; }
[ -f "$ENV_FILE" ] || cp "$APP_DIR/.env.example" "$ENV_FILE"

python3 - "$ENV_FILE" "$FREECAD_BIN" "$BLENDER_BIN" <<'PY'
from pathlib import Path
import sys
path=Path(sys.argv[1]); values={"FREECAD_CMD":sys.argv[2],"BLENDER_CMD":sys.argv[3]}
lines=path.read_text(encoding="utf-8").splitlines(); seen=set(); out=[]
for line in lines:
    if "=" in line and not line.lstrip().startswith("#"):
        key=line.split("=",1)[0].strip()
        if key in values:
            out.append(f"{key}={values[key]}"); seen.add(key); continue
    out.append(line)
for key,value in values.items():
    if key not in seen: out.append(f"{key}={value}")
path.write_text("\n".join(out).rstrip()+"\n",encoding="utf-8")
PY

chown root:www-data "$ENV_FILE"
chmod 0640 "$ENV_FILE"
systemctl restart configurator-studio.service
sleep 2

echo "FreeCAD: $FREECAD_BIN"
"$FREECAD_BIN" --version 2>/dev/null | head -n 2 || true
echo "Blender: $BLENDER_BIN"
"$BLENDER_BIN" --version | head -n 2
curl -fsS http://127.0.0.1:9999/api/health | python3 -m json.tool

echo "CAD-tooling is geïnstalleerd en de service is herstart."
