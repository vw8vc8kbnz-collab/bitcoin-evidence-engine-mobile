#!/usr/bin/env bash
set -Eeuo pipefail
ZIP_NAME="${1:-configurator-studio-v2.1.0.zip}"
REPO_RAW="https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main"
TMP_DIR="$(mktemp -d /tmp/configurator-studio-v2.1.XXXXXX)"
trap 'rm -rf "$TMP_DIR"' EXIT
curl --fail --location --retry 3 "$REPO_RAW/$ZIP_NAME" -o "$TMP_DIR/release.zip"
unzip -q "$TMP_DIR/release.zip" -d "$TMP_DIR/unpacked"
SOURCE_DIR="$TMP_DIR/unpacked/configurator-studio-v2.1.0"
[ -f "$SOURCE_DIR/server.mjs" ] || { echo "Releasemap ontbreekt in ZIP" >&2; exit 1; }
sudo bash "$SOURCE_DIR/deploy/install-release.sh" "$SOURCE_DIR" /var/www/configurator-studio
