#!/usr/bin/env bash
set -Eeuo pipefail
SOURCE_DIR="${1:-}"
APP_DIR="${2:-/var/www/configurator-studio}"
STAMP="$(date +%Y%m%d-%H%M%S)"
NEW_DIR="${APP_DIR}.release-${STAMP}"
ROLLBACK_DIR="${APP_DIR}.rollback"
SWAPPED=0

[ "$(id -u)" -eq 0 ] || { echo "Voer dit script uit met sudo/root." >&2; exit 1; }
[ -n "$SOURCE_DIR" ] && [ -f "$SOURCE_DIR/package.json" ] && [ -f "$SOURCE_DIR/server.mjs" ] || { echo "Ongeldige releasebron: $SOURCE_DIR" >&2; exit 1; }
cleanup(){ rm -rf "$NEW_DIR"; }
rollback(){ local code=$?; if [ "$SWAPPED" -eq 1 ]; then echo "Deploy mislukt; vorige release wordt hersteld." >&2; systemctl stop configurator-studio.service 2>/dev/null || true; rm -rf "$APP_DIR"; [ -d "$ROLLBACK_DIR" ] && mv "$ROLLBACK_DIR" "$APP_DIR"; systemctl daemon-reload 2>/dev/null || true; systemctl restart configurator-studio.service 2>/dev/null || true; fi; cleanup; exit "$code"; }
trap rollback ERR INT TERM

cd "$SOURCE_DIR"
node -e 'const p=require("./package.json");if(p.version!=="2.1.0")throw new Error(`Onverwachte releaseversie: ${p.version}`)'
# De onbeveiligde API-contracttest draait geïsoleerd van een bestaande productie-.env.
ADMIN_USERNAME= ADMIN_PASSWORD= SESSION_SECRET= npm run check

rm -rf "$NEW_DIR" "$ROLLBACK_DIR"; mkdir -p "$NEW_DIR"; cp -a "$SOURCE_DIR/." "$NEW_DIR/"
if [ -d "$APP_DIR" ]; then
  [ -f "$APP_DIR/.env" ] && cp -a "$APP_DIR/.env" "$NEW_DIR/.env"
  for dir in data runtime_uploads runtime_assets runtime_outputs; do mkdir -p "$NEW_DIR/$dir"; [ -d "$APP_DIR/$dir" ] && cp -a "$APP_DIR/$dir/." "$NEW_DIR/$dir/" || true; done
  mv "$APP_DIR" "$ROLLBACK_DIR"
fi
mv "$NEW_DIR" "$APP_DIR"; SWAPPED=1
APP_DIR="$APP_DIR" bash "$APP_DIR/deploy/deploy-v2.sh"
SWAPPED=0; rm -rf "$ROLLBACK_DIR"; trap - ERR INT TERM; cleanup
echo "Configurator Studio v2.1.0 is veilig geïnstalleerd in $APP_DIR"
