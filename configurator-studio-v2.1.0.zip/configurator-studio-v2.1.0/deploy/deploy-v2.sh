#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${APP_DIR:-/var/www/configurator-studio}"
SERVICE="configurator-studio.service"
NGINX_SITE="/etc/nginx/sites-available/configurator-studio-9999"
NGINX_ENABLED="/etc/nginx/sites-enabled/configurator-studio-9999"

[ "$(id -u)" -eq 0 ] || { echo "Voer dit script uit met sudo/root." >&2; exit 1; }
cd "$APP_DIR"
command -v node >/dev/null || { echo "Node.js 20+ ontbreekt" >&2; exit 1; }
[ "$(node -p 'Number(process.versions.node.split(`.`)[0])')" -ge 20 ] || { echo "Node.js 20+ vereist" >&2; exit 1; }
command -v nginx >/dev/null || { echo "nginx ontbreekt" >&2; exit 1; }
command -v curl >/dev/null || { echo "curl ontbreekt" >&2; exit 1; }
[ -f .env ] || cp .env.example .env
mkdir -p data runtime_uploads runtime_assets runtime_outputs

set_env(){ local key="$1" value="$2"; if grep -qE "^${key}=" .env; then sed -i "s|^${key}=.*|${key}=${value}|" .env; else printf '%s=%s\n' "$key" "$value" >> .env; fi; }
set_env PORT 10000
set_env HOST 127.0.0.1
set_env PUBLIC_BASE_URL http://51.195.102.180:9999

GENERATED_LOGIN="$(node - "$APP_DIR/.env" <<'NODE'
const fs=require('node:fs'),crypto=require('node:crypto');const file=process.argv[2];const lines=fs.readFileSync(file,'utf8').split(/\r?\n/),v={};
for(const line of lines){if(line.includes('=')&&!line.trimStart().startsWith('#')){const i=line.indexOf('=');v[line.slice(0,i).trim()]=line.slice(i+1).trim()}}
const username=v.ADMIN_USERNAME||'stijn';let generated=false;if(!v.ADMIN_PASSWORD){v.ADMIN_PASSWORD=crypto.randomBytes(18).toString('base64url');generated=true}if(!v.SESSION_SECRET)v.SESSION_SECRET=crypto.randomBytes(48).toString('base64url');v.ADMIN_USERNAME=username;v.SESSION_TTL_SECONDS=v.SESSION_TTL_SECONDS||'43200';v.COOKIE_SECURE=v.COOKIE_SECURE||'false';
const keys=['ADMIN_USERNAME','ADMIN_PASSWORD','SESSION_SECRET','SESSION_TTL_SECONDS','COOKIE_SECURE'],seen=new Set();const out=lines.map(line=>{if(line.includes('=')&&!line.trimStart().startsWith('#')){const key=line.slice(0,line.indexOf('=')).trim();if(keys.includes(key)){seen.add(key);return `${key}=${v[key]}`}}return line});for(const key of keys)if(!seen.has(key))out.push(`${key}=${v[key]}`);fs.writeFileSync(file,out.join('\n').replace(/\n+$/,'')+'\n');if(generated)process.stdout.write(`${username}\t${v.ADMIN_PASSWORD}`);
NODE
)"

node server/scripts/migrate-v2.1.mjs "$APP_DIR"
chown -R root:root "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 0755 {} +
find "$APP_DIR" -type f -exec chmod 0644 {} +
chmod 0755 deploy/*.sh server/scripts/*.sh server/scripts/*.mjs server/freecad_worker/*.py server/asset_pipeline/*.py 2>/dev/null || true
chown root:www-data .env; chmod 0640 .env
for dir in data runtime_uploads runtime_assets runtime_outputs; do chown -R www-data:www-data "$dir"; chmod 0750 "$dir"; done

install -m 0644 deploy/configurator-studio.service "/etc/systemd/system/$SERVICE"
install -m 0644 deploy/nginx-configurator-studio.conf "$NGINX_SITE"
ln -sfn "$NGINX_SITE" "$NGINX_ENABLED"
nginx -t
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null
systemctl restart "$SERVICE"
systemctl reload nginx

ok=0
for _ in {1..30}; do if curl -fsS http://127.0.0.1:10000/api/health >/tmp/configurator-health-internal.json 2>/dev/null; then ok=1; break; fi; sleep 1; done
[ "$ok" -eq 1 ] || { echo "Interne healthcheck mislukt" >&2; systemctl --no-pager --full status "$SERVICE" >&2 || true; journalctl -u "$SERVICE" -n 120 --no-pager >&2 || true; exit 1; }
curl -fsS http://127.0.0.1:9999/api/health >/tmp/configurator-health-public.json
python3 -m json.tool </tmp/configurator-health-public.json
systemctl --no-pager --full status "$SERVICE" | sed -n '1,22p'
if [ -n "$GENERATED_LOGIN" ]; then USERNAME="${GENERATED_LOGIN%%$'\t'*}"; PASSWORD="${GENERATED_LOGIN#*$'\t'}"; printf '\nEerste Studio-login:\n  gebruikersnaam: %s\n  wachtwoord: %s\n' "$USERNAME" "$PASSWORD"; fi
printf '\nConfigurator Studio: http://51.195.102.180:9999\nInterne Node-poort: 127.0.0.1:10000\n'
