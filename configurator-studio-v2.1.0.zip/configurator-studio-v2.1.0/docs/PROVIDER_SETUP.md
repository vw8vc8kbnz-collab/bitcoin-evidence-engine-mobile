# Provider setup en contracten — v2.1.0

## 1. Hoofdregel

OpenAI, Meshy, Tripo, Rodin, FreeCAD en Blender zijn interne adapters. De klant ziet één Studio Engine. Een adapter mag uitsluitend een draft of kandidaat leveren.

Provider-output mag nooit rechtstreeks:

- een fact bevestigen;
- een prijsveld autoriseren;
- een model accepteren;
- een runtime publiceren.

## 2. OpenAI Product Architect

Bestand: `src/providers/openaiProductArchitect.mjs`

Contract:

```text
tekst + maximaal vijf beelden
→ Responses API
→ strict JSON schema
→ summary/category/candidate_facts/questions/configuration_plan/risk_notes
```

Belangrijk:

- `input_image` gebruikt high detail;
- output wordt als JSON-schema afgedwongen;
- measurement candidates blijven inferred;
- capabilitynamen worden later gesanitized door `architectPlan.mjs`;
- mesh targets blijven leeg totdat een echt asset is geïnspecteerd/gemapt.

Configuratie:

```dotenv
OPENAI_API_KEY=
OPENAI_MODEL=gpt-5.6
```

## 3. Meshy — volledige reconstructie

Bestand: `src/providers/meshy.mjs`

Meshy is in v2.1.0 niet beperkt tot texturen. De adapter ondersteunt:

- één foto → volledige 3D-reconstructiedraft;
- twee tot vier aanzichten → multi-image reconstructiedraft;
- getextureerde GLB;
- PBR;
- high-definition texture;
- remesh en target polycount;
- image enhancement;
- lighting removal;
- alpha/multiview previews;
- auto sizing en bottom origin.

Endpoints:

```text
POST /openapi/v1/image-to-3d
GET  /openapi/v1/image-to-3d/:task_id
POST /openapi/v1/multi-image-to-3d
GET  /openapi/v1/multi-image-to-3d/:task_id
```

De provider-GLB wordt direct naar `runtime_outputs` gekopieerd. Tijdelijke provider-URL’s komen niet in de gepubliceerde runtime.

## 4. Meshy — AI Material Lab / retexture

De expliciete materiaalroute gebruikt:

```text
accepted source GLB
+ text style prompt of material reference image
→ /openapi/v1/retexture
→ PBR GLB candidate
→ inspectie
→ menselijke review
```

Payloadregels:

- bronmodel als data URI;
- originele UV behouden;
- PBR en HD texture;
- lighting removal;
- GLB output;
- tekst en stijlbeeld worden niet tegelijk als concurrerende style controls verstuurd;
- bij stijlbeeld heeft `image_style_url` voorrang;
- bij tekst gebruikt de adapter `text_style_prompt`.

Een materiaaldraft is whole-model visual output. Configureerbare part-swatches blijven in de blueprint en worden niet automatisch herschreven.

Configuratie:

```dotenv
MESHY_API_KEY=
```

## 5. Tripo — snelle route

Bestand: `src/providers/tripo.mjs`

Flow:

```text
beeld/data URI
→ Tripo upload
→ file token
→ image_to_model of multiview_to_model
→ polling
→ GLB download
→ inspectie/review
```

P1-contract:

- standaard `P1-20260311`;
- type van iedere afbeelding blijft behouden;
- multiview heeft exact vier posities: front, left, back, right;
- lege posities blijven zonder `file_token` bestaan;
- PBR en detailed texture;
- face limit 20.000;
- auto-size;
- geometry compression;
- geometry-prioritized alignment;
- H-series-only controls worden niet naar P1 gestuurd.

Configuratie:

```dotenv
TRIPO_API_KEY=
TRIPO_MODEL_VERSION=P1-20260311
```

## 6. Hyper3D Rodin — premium route

Bestand: `src/providers/rodin.mjs`

Flow:

```text
multipart images + prompt
→ /api/v2/rodin
→ subscription_key + task_uuid
→ /api/v2/status polling
→ wacht tot alle subjobs Done zijn
→ fail wanneer één subjob Failed/Canceled/Expired is
→ /api/v2/download met task_uuid
→ GLB lokaal opslaan
```

Instellingen:

- Gen-2 tier;
- Raw mesh;
- hoge quality override;
- PBR material;
- GLB output.

Configuratie:

```dotenv
HYPER3D_API_KEY=
RODIN_TIER=Gen-2
```

## 7. FreeCAD + Blender — exacte route

Bestanden:

- `src/providers/freecad.mjs`
- `server/freecad_worker/worker.py`
- `server/asset_pipeline/convert_to_glb.py`

Flow:

```text
confirmed length/width/height
→ template safety validation
→ named FreeCAD objects
→ STEP + OBJ
→ Blender headless
→ GLB
→ inspectie/review
```

Ondersteunde templatefamilies in deze release:

- tafel/bureau;
- kast/wardrobe;
- paneel/deur/plank.

Veilige minima voorkomen dat voorbeeldgeometrie of onrealistische afmetingen stilzwijgend worden gebruikt. Ontbrekende hoofdmaatvoering veroorzaakt een harde fout.

Installatie op Debian/Ubuntu:

```bash
sudo bash /var/www/configurator-studio/deploy/install-cad-tools.sh
```

Het script installeert FreeCAD en Blender, detecteert de echte binaries, schrijft die naar `.env`, herstart de service en voert een healthcheck uit.

## 8. Demo- en productiemodus

### DEMO_MODE=true

- live route bij aanwezige sleutel/tooling;
- geïntegreerde demo-output bij ontbrekende route;
- volledig bruikbaar voor UX- en flowtests;
- provideroutput blijft reviewplichtig.

### DEMO_MODE=false

- ontbrekende auth is een startupfout;
- ontbrekende provider/tooling blokkeert de betreffende route;
- geschikt na live stagingcontracttests.

## 9. Verplichte live contracttest

Voer voor iedere externe provider minimaal uit:

1. één single-image job;
2. één multi-image job waar ondersteund;
3. polling tot success;
4. expliciete failure/cancel/timeout test;
5. GLB-download vóór URL-expiry;
6. GLB-inspectie;
7. menselijke accept/reject;
8. publish gate;
9. credit-/quota-fout;
10. logging zonder beeld/base64/secrets in statusresponse.

De release bevat contracttests voor payloads en control flow, maar geen echte betaalde providercalls omdat er in de buildomgeving geen API-sleutels aanwezig waren.
