# Releaseverslag — Configurator Studio v2.1.0

**Releasedatum:** 10 juli 2026  
**Releasekarakter:** Foundation Reset + werkende twee-zone Arc Chair-demo

## 1. Hoofdcorrectie

De oude interface voelde als één configurator met een editor eromheen. v2.1.0 draait deze hiërarchie om:

- de Studio is de webapp/configuratorfabriek;
- een project doorloopt twaalf begeleide stappen;
- de uiteindelijke klantconfigurator is een aparte preview/runtime-output.

## 2. Nieuwe builderflow

De release bevat:

- projectdashboard;
- projectkaarten met voortgang en status;
- nieuw-projectmodal;
- vaste twaalfstappen-navigatie;
- taakgerichte content per stap;
- contextuele assistent en blockers;
- aparte klantpreview met desktop- en mobiele stand;
- publicatie naar een immutable runtime.

Niet-gerelateerde platformmodules worden eerlijk als nog niet uitgewerkte modules weergegeven; ze doen niet alsof ze al volledig bestaan.

## 3. Arc Chair-implementatie

### Bron

Het aangeleverde stoelmodel bevatte:

- 280.838 triangles;
- één gecombineerde mesh/material zone;
- circa 29 MB bronbestand.

### Nieuwe demo-asset

De nieuwe `public/assets/demo-chair.glb` bevat:

- 39.851 triangles;
- 2 meshes;
- 2 materialen;
- 0 ingebakken textures;
- circa 0,88 MB;
- mobiele status: geschikt volgens de huidige polycount/file-size gate.

Meshindeling:

```text
seat_and_back         30.000 triangles
legs_and_footrest      9.851 triangles
```

De geometrie is vereenvoudigd met silhouette-preserving decimation. De oorspronkelijke vorm en verhoudingen blijven daardoor herkenbaar, maar het bestand is niet byte- of vertex-identiek aan de bron.

### Configureerbare werking

De zitting/rug en het onderstel hebben ieder:

- een eigen onderdeelrecord;
- een eigen mesh target;
- een eigen optiegroep;
- vier materiaalkeuzes;
- eigen meerprijsregels;
- eigen orderoutputveld.

Dezelfde selectie wordt doorgegeven aan:

- builderviewer;
- klantpreview;
- centrale prijsengine;
- runtimeviewer;
- orderpayload.

Geteste combinatie:

```text
seat_terracotta + legs_white
basisprijs €429 + €20 + €15 = €464
orderlabels: Terracotta / Poederwit
```

## 4. Viewerfix

De camera gebruikt nu de werkelijke bounding box en houdt rekening met:

- modelhoogte;
- modelbreedte;
- schermverhouding;
- echte vloerpositie;
- extra diepte voor een driekwartaanzicht.

Hierdoor wordt een hoge stoel niet langer gecentreerd alsof het een brede tafel is. Het model wordt horizontaal gecentreerd, op de vloer gezet en opnieuw gefit wanneer het viewervlak wijzigt.

## 5. Runtime parity

`public/js/configEngine.js` wordt zowel door de builderpreview als door `runtime.html` gebruikt voor:

- standaardselecties;
- rule evaluation;
- pricing;
- orderpayload.

De runtimecompiler neemt daarnaast commerce, branding en uitsluitend bevestigde facts mee.

## 6. Data en migratie

`server/scripts/migrate-v2.1.mjs`:

- zet de schema-versie op 2.1.0;
- vervangt alleen het vaste demoproject door Arc Chair;
- installeert het twee-zone blueprint;
- koppelt het nieuwe demo-GLB;
- laat andere projecten en runtimegegevens bestaan.

Nieuwe projecten starten met een leeg bouwplan en niet met verborgen stoelopties.

## 7. Deploymentcorrectie

De release legt de VPS-poorten nu expliciet vast:

```text
nginx 0.0.0.0:9999
→ Node 127.0.0.1:10000
```

De systemd-unit vermijdt de sandboxinstellingen die eerder `226/NAMESPACE` veroorzaakten. De installer draait tests vóór de swap, bewaart data en `.env`, maakt een rollback en voert interne én publieke healthchecks uit.

## 8. Validatie

Automatisch uitgevoerd:

- JavaScript-, Python-, shell- en JSON-syntaxcontrole;
- echte GLB-inspectie;
- v2.1-migratiecontract;
- HTTP-serverflow;
- upload/review/retexture/generation/publish;
- authenticatie;
- preview/runtime pricing- en orderpariteit.

Resultaat:

```text
tests: 23
passed: 23
failed: 0
```

De browserbinary in deze bouwomgeving blokkeerde lokale URL-navigatie administratief, waardoor geen betrouwbare nieuwe Chromium-screenshotaudit kon worden uitgevoerd. Daarom claimt dit verslag geen browserrender-audit die niet is uitgevoerd. De VPS-smoketest na deployment moet de echte Safari/Chrome-layout en WebGL-output bevestigen.

## 9. Go/no-go

**Go voor:**

- deployment op de bestaande single-workspace VPS;
- testen van de echte twee-zone stoelconfigurator;
- verdere UX- en providerontwikkeling;
- demo aan interne gebruikers.

**Nog geen commerciële multi-tenant go-live voor:**

- abonnementen en credits;
- tenantisolatie;
- object storage/CDN;
- robuuste distributed jobqueue;
- volwaardige Shopify/WooCommerce-appdistributie;
- analytics en billing.
