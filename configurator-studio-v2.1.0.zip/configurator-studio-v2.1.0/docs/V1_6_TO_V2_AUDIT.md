# Diepe audit v1.6 → v2.0.0

## 1. Input die is beoordeeld

- `configurator-studio-v1.6(1).zip`
- `CLAUDE_OVERDRACHT_CONFIGURATOR_STUDIO_v1_6(1).md`
- `CLAUDE_ROADMAP_EINDDOEL_PROBLEMEN_CONFIGURATOR_STUDIO_v1_6(1).md`

De twee overdrachten bevatten de juiste strategische correctie: Reliable Configurator Core eerst; AI als gecontroleerde laag; FreeCAD voor exacte geometrie; providermerken uit de klant-UI; product- en partscope scheiden; pricing niet op AI-schattingen.

## 2. Belangrijkste v1.6-problemen

### Monolithische frontend

- bijna 95 KB inline HTML/JS/CSS;
- state, UI, viewer en tijdelijke fixes door elkaar;
- moeilijk testbaar en risicovol om uit te breiden.

### Viewer lifecycle

- animation loop werd niet vernietigd;
- listeners en ResizeObserver konden blijven bestaan;
- nieuwe loads konden oude resources laten staan;
- verhoogd risico op iPhone-instabiliteit en steeds zwaardere sessies.

### Versie- en productidentiteit

- package, titel, code en documentatie liepen niet overal gelijk;
- fundament en demo werden soms gepresenteerd alsof integraties live af waren.

### Engine-integratie

- Truth Graph-idee was sterk, maar nog niet gekoppeld aan echte serverjobs;
- FreeCAD/providerbestanden waren foundation, geen end-to-end builderflow;
- geen persistente asset lifecycle;
- geen harde human-review gate voor ieder assettype;
- geen immutable runtimepublicatie.

### Builder UX

- product-, part- en surfaceacties liepen te veel door elkaar;
- context kon acties tonen die geometry/capability niet ondersteunde;
- projectbeheer was onvoldoende professioneel;
- mobile overlay/navigation had nog instabiliteit.

## 3. Wat v2.0.0 structureel vervangt

### Modulaire kern

- pure coremodules voor truth, routes, pricing, rules, gates en runtime;
- provideradapters achter één jobrunner;
- afzonderlijke auth, config, store en GLB-inspector;
- tests op contractniveau.

### Nieuwe builder

- premium light design;
- projectmanager;
- vaste live klantpreview;
- product/onderdeel toggle;
- capability-aware inspector;
- desktop/mobile preview;
- Product Architect drawer;
- options, prices, rules, order en diagnostics;
- publicatiecontrole.

### Nieuwe 3D-engine

- lokaal gebundelde Three.js;
- GLB load/fit/select/highlight/material;
- resize/orientation-respons;
- dispose van resources;
- 2D-fallback als WebGL niet beschikbaar is.

### Echte orchestration

- OpenAI vision + strict schema;
- Meshy full single/multi-image reconstruction;
- Meshy text/image-guided retexture;
- Tripo P1 fast route;
- Rodin premium route;
- FreeCAD + Blender exact route;
- demo fallback via hetzelfde jobcontract.

### Waarheids- en publicatiecontrole

- AI blijft inferred;
- conflicts zijn first-class;
- measurements vereisen menselijke verificatie;
- upload/CAD/AI/retexture allemaal pending review;
- runtime compileert alleen na boolean gates;
- runtime is recursief immutable;
- provider metadata en kandidaatfeiten worden verwijderd.

### Security en deployment

- HMAC HttpOnly sessie;
- rate limiting;
- private management API;
- geharde systemd unit;
- atomic release swap;
- data/.env behoud;
- automatische rollback;
- eerste login generatie;
- CAD installer.

## 4. Bugs die tijdens v2-audit zijn gevonden en opgelost

- FreeCAD worker gebruikte een lokaal geïmporteerd `App` buiten scope.
- Ontbrekende CAD-maten kregen impliciet voorbeeldwaarden.
- Exacte route probeerde FreeCAD te starten wanneer tooling niet bestond.
- Rodin download gebruikte niet overal de juiste taakreferentie en wachtte onvoldoende expliciet op alle subjobs.
- Tripo-contract gebruikte verouderde generatieaannames.
- Material prompt kon ten onrechte productreconstructierouting beïnvloeden.
- Een geüpload GLB kon te snel als betrouwbare bron worden geïnterpreteerd.
- Projectstatus werd na publish niet consequent op `published` gezet.
- Runtime was alleen oppervlakkig immutable.
- Mobile rail bleef na sectiekeuze boven de inspector liggen.
- Providernaam stond kort in de Material Lab-copy.
- Materiaalstijlbeeld kon in een ongesaniteerde jobrespons blijven staan; jobstatus toont nu alleen een boolean.

## 5. Niet als voltooid geclaimd

De oorspronkelijke roadmap bevat een volledige internationale SaaS met paywall, credits, Shopify, WooCommerce, multi-tenant auth, storage/CDN en billing. Die bedrijfslaag is niet geveinsd in v2.0.0.

Nog niet gebouwd:

- tenantisolatie en rollen;
- Starter/Growth/Scale abonnementen;
- credit reservation/capture/refund;
- Stripe/Shopify Billing;
- echte Shopify Theme App Extension;
- WooCommerce-plugin;
- Postgres/object storage/Redis;
- provider webhooks en distributed workers;
- analytics/usage metering;
- white-label enterprise tooling.

v2.0.0 levert de betrouwbare productkern waarop die fase verantwoord kan worden gebouwd.
