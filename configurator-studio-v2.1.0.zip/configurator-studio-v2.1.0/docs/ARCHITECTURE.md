# Architectuur — Configurator Studio v2.1.0

## 1. Definitieve productfilosofie

Configurator Studio is geen “foto erin, perfecte verkoopklare configurator eruit”-systeem. Het is een **Reliable Configurator Core** waarin AI, CAD en 3D-providers werk versnellen, maar nooit de waarheid, prijs of publicatie autoriseren.

De eindflow is:

```text
intake
→ kandidaatkennis
→ verificatie
→ assetroute
→ technische inspectie
→ menselijke modelreview
→ onderdelen/opties/pricing/rules/order
→ boolean publish gates
→ immutable runtime
```

## 2. Laagmodel

### 2.1 Studio UX

Verantwoordelijk voor:

- projectbeheer;
- productintake;
- product- en onderdeelscope;
- capability-aware acties;
- desktop/mobile klantpreview;
- facts bevestigen;
- asset review;
- pricing/rules/order instellen;
- publicatiecontrole.

De UI toont geen providermerken. Zij spreekt over Product Architect, Studio Engine, snelle route, gebalanceerde route, premium route en exacte CAD-route.

### 2.2 Product Architect

`src/providers/openaiProductArchitect.mjs` verwerkt tekst en beelden via de OpenAI Responses API en een strict JSON schema.

Uitvoer:

- samenvatting en categorie;
- kandidaatfeiten;
- gerichte verduidelijkingsvragen;
- onderdelenvoorstel;
- option-group voorstel;
- aanbevolen routeprofiel;
- risiconotities.

Het voorstel wordt via `architectPlan.mjs` omgezet in een **bewerkbare draft**. Mesh mappings worden nooit verzonnen.

### 2.3 Truth Graph v2

`src/core/truthGraph.mjs` houdt waarde, kandidaten, provenance, conflict en verificatie apart.

Status is afgeleid:

```text
missing | inferred | conflicting | confirmed
```

Belangrijke invarianten:

- AI mag alleen candidates leveren.
- Confidence is geen bewijs.
- Measurements worden pas prijsbaar na expliciete verificatie.
- Conflicten blijven open tot een mens ze oplost.
- `pricing_allowed` wordt door pure logica afgeleid.

### 2.4 Asset Orchestrator

`src/core/routeEngine.mjs` kiest op basis van bronmateriaal, categorie, bevestigde facts, kwaliteitsprofiel en providerbeschikbaarheid.

Productroutes:

- `uploaded_asset`
- `parametric_cad`
- `photo_reconstruction_balanced`
- `photo_reconstruction_fast`
- `photo_reconstruction_premium`
- `clarification_required`

De materiaalroute is bewust **geen automatische productroute**. `material_studio` kan uitsluitend expliciet worden gestart op een reeds geaccepteerd actief model.

### 2.5 Jobrunner

`src/server/jobRunner.mjs` maakt persistente jobs en voert provider-/CAD-taken buiten de HTTP-respons af.

Jobstatus:

```text
queued → running → succeeded | failed
```

Assetstatus staat daar los van:

```text
technical_status: succeeded | failed
quality_status: pending_review | accepted | rejected
```

Een technisch geslaagde job kan dus nog steeds niet publiceerbaar zijn.

### 2.6 Configurator Core

De blueprint bevat:

- parts/components;
- capabilities;
- mesh targets;
- option groups en options;
- materials;
- pricing;
- rules;
- order output.

Productscope bevat globale instellingen. Partscope bevat alleen acties die in `part.capabilities` staan, bijvoorbeeld material, finish, visibility, pricing, rules of order output.

### 2.7 Pricing Engine

`src/core/pricing.mjs` is de enige prijsbron.

De engine ondersteunt in de huidige kern:

- basisprijs;
- vaste option deltas;
- quantity;
- area-based regels op bevestigde maten.

Een onbevestigde measurement veroorzaakt een harde fout in plaats van een stille schatting.

### 2.8 Rules Engine

`src/core/rules.mjs` valideert conditionele configuratieregels. Rules mogen prijsregels activeren/deactiveren, maar berekenen geen parallelle prijs.

### 2.9 Publish gates

`src/core/gates.mjs` controleert:

- elk vereist kritisch fact afzonderlijk;
- geen open conflicten;
- configureerbaarheid en mesh mappings;
- basisprijs;
- geldige rules;
- order output;
- geaccepteerde modelreview.

Er is geen samengevoegde AI-readinessscore die blokkades kan maskeren.

### 2.10 Runtime compiler

`src/core/runtimeCompiler.mjs` produceert een recursief gefreezede runtime met:

- publiek asset-id, GLB en poster;
- productdata;
- parts en options;
- pricing;
- rules;
- order output;
- verplichte kleine Configurator Studio-branding.

Niet opgenomen:

- prompts;
- provider metadata;
- kandidaatfeiten;
- confidence;
- interne notities;
- open conflicten.

Elke publicatie krijgt een eigen runtime-id en versionering. De bronprojectstatus wordt `published`.

## 3. Asset lifecycle

### 3.1 Upload

```text
GLB upload
→ bestandsgroottecontrole
→ GLB container/JSON parse
→ mesh/material/triangle inventory
→ mappingvoorstel op naam
→ pending_review
```

Een upload is niet automatisch “geverifieerd”; ook een eigen bestand moet inhoudelijk worden geaccepteerd.

### 3.2 AI/CAD-output

```text
job succeeded
→ GLB lokaal opslaan
→ inspectGlb
→ mesh inventory
→ bestaande mappings hergebruiken waar verantwoord
→ candidate asset
→ pending_review
```

### 3.3 Materiaalretexture

```text
accepted active asset
→ tekst of stijlbeeld
→ kopie naar retexture provider
→ nieuwe GLB
→ mesh mappings op naam/index behouden
→ ai_retextured candidate
→ pending_review
```

Het bronmodel blijft onaangetast. Een materiaaldraft verandert niet stilzwijgend options of prijzen.

## 4. Viewer lifecycle

`public/js/viewer.js` beheert:

- één renderer;
- één animation frame-loop;
- één ResizeObserver;
- één AbortController voor listeners;
- disposal van geometry, material en textures;
- WebGL-context cleanup.

Daarmee verdwijnen de cumulatieve listener-/renderloopproblemen uit v1.6.

## 5. Persistente store

De huidige single-workspace release gebruikt `data/store.json` met atomic temp-file rename.

Collecties:

- workspaces;
- projects;
- blueprints;
- assets;
- jobs;
- runtimes;
- audit log.

De store is bewust achter methodes geïsoleerd. Migratie naar Postgres/Supabase hoort de corefuncties niet te wijzigen.

## 6. Authenticatie en security

`src/server/auth.mjs` levert:

- timing-safe credential comparison;
- HMAC-SHA256 ondertekende sessietokens;
- vervaltijd en nonce;
- HttpOnly cookie;
- SameSite=Strict;
- optionele Secure-cookie;
- login rate limiting in `server.mjs`.

Publiek:

- health;
- auth status/login/logout;
- gepubliceerde runtime API;
- runtime viewer/assets.

Privé:

- projecten;
- facts;
- jobs;
- generatie;
- uploads;
- blueprint;
- pricingbeheer;
- review;
- publish.

De systemd-service draait als `www-data`, heeft een read-only bestandssysteem buiten vier runtimepaden en gebruikt hardening zoals `NoNewPrivileges`, `ProtectSystem=strict` en `PrivateDevices`.

## 7. API-overzicht

Belangrijkste private endpoints:

```text
GET  /api/studio
GET  /api/projects
POST /api/projects
POST /api/project/update
POST /api/architect/analyze
POST /api/architect/apply-plan
POST /api/facts/confirm
POST /api/assets/upload
POST /api/generation/start
POST /api/material/retexture
GET  /api/jobs/:id
POST /api/assets/:id/map
POST /api/assets/:id/review
POST /api/blueprint/update
POST /api/price/calculate
GET  /api/publish/gate
POST /api/publish
```

Publieke runtime:

```text
GET /runtime/:runtime_id
GET /api/runtime/:runtime_id
```

## 8. Productie-uitbouw zonder kernbreuk

De volgende SaaS-laag moet als adapters/infra worden toegevoegd:

- Postgres/Supabase repository;
- object storage/CDN;
- echte queue/worker;
- tenant-auth en rollen;
- subscriptions, credits en budget caps;
- Shopify/WooCommerce connectors;
- analytics;
- usage metering;
- screenshots/visual QA worker.

Niet verplaatsen naar database triggers:

- Truth Graph statusafleiding;
- pricinglogica;
- rulesvalidatie;
- publish gates;
- runtime compilation.
