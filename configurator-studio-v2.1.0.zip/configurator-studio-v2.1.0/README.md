# Configurator Studio v2.1.0 — Guided Builder & Arc Chair Demo

Configurator Studio is de **webapp waarin een bedrijf zijn eigen configurator bouwt**. De Studio zelf is dus niet de klantconfigurator. De klantconfigurator is een aparte, publiceerbare runtime die pas aan het einde van de begeleide workflow ontstaat.

v2.1.0 is de Foundation Reset van de interface en bevat een werkend Arc Chair-demoproject waarmee de volledige kernflow direct kan worden getest.

## Wat v2.1.0 toevoegt

- echt projectdashboard in plaats van direct openen in één configurator;
- begeleide workflow met twaalf stappen;
- duidelijke scheiding tussen Studio-builder en klantpreview/runtime;
- contextuele Studio Assistent per stap;
- nieuw-projectflow met leeg bouwplan;
- vernieuwde desktop- en mobiele navigatiestructuur;
- echte stoel-GLB als demo in plaats van de oude tafel;
- geoptimaliseerde stoel van 280.838 naar 39.851 triangles;
- twee fysieke GLB-meshes:
  - `seat_and_back`;
  - `legs_and_footrest`;
- twee onafhankelijke kleurkeuzes in builder én runtime;
- gedeelde prijs-, regels- en orderengine voor preview en publicatie;
- werkende meerprijzen en leesbare orderpayload;
- verbeterde viewerframing voor hoge producten en smalle schermen;
- migratie van het bestaande demo-project zonder andere projecten te verwijderen;
- gecorrigeerde VPS-architectuur: nginx `:9999` → Node `127.0.0.1:10000`;
- 23 geslaagde regressie- en contracttests.

## De twaalf bouwstappen

1. Productbrief
2. Bronmateriaal
3. Studio Engine-route
4. 3D-model
5. Modelcontrole
6. Onderdelen
7. Klantkeuzes
8. Prijzen
9. Regels
10. Webshop & order
11. Vormgeving
12. Testen & live

Elke stap toont alleen de relevante taak, status, blockers en vervolghandelingen. De live 3D-preview verschijnt waar deze nodig is, maar is niet langer de complete applicatiestructuur.

## Werkende stoelconfigurator

Het Arc Chair-demoproject gebruikt een echt GLB-bestand van ongeveer 0,88 MB. De oorspronkelijke vorm en verhoudingen zijn onder decimatie behouden, terwijl de geometrie veel lichter is gemaakt.

De twee configureerbare zones zijn technisch gescheiden:

```text
Arc Chair
├── Zitting en rug      → seat_and_back
└── Poten en onderstel  → legs_and_footrest
```

Beschikbare demokeuzes:

- zitting: warm beige, terracotta, saliegroen, antraciet;
- onderstel: mat zwart, walnootbruin, poederwit, geborsteld staal.

Een keuze wijzigt:

1. het materiaal op uitsluitend de juiste mesh;
2. de actuele testprijs;
3. de klantpreview;
4. de gepubliceerde runtime;
5. de leesbare orderpayload.

Voorbeeld:

```text
Zitting: Terracotta       + €20
Onderstel: Poederwit      + €15
Basisprijs:                 €429
Totaal:                     €464
```

## Architectuur

De belangrijkste scheiding is:

```text
Studio webapp
└── project + begeleid bouwplan
    ├── facts / Truth Graph
    ├── assets en modelreview
    ├── onderdelen en opties
    ├── pricing en rules
    ├── commerce/output
    └── immutable publicatie
        └── losse klantconfigurator/runtime
```

Builderpreview en publieke runtime gebruiken dezelfde browserengine voor:

- initial selections;
- rule evaluation;
- pricing;
- orderoutput.

Daardoor wordt een stoelcombinatie niet anders berekend in de Studio dan in de gepubliceerde configurator.

## AI/CAD-kern

De bestaande betrouwbare kern blijft aanwezig:

- OpenAI Product Architect;
- Meshy single- en multi-image reconstructie;
- Meshy retexture via tekst of stijlbeeld;
- Tripo snelle route;
- Rodin premiumroute;
- FreeCAD/Blender parametrische route;
- Truth Graph waarin AI nooit zelfstandig feiten bevestigt;
- menselijke review vóór publicatie;
- immutable runtime compiler.

Zonder API-sleutels draait de app in expliciete demomodus. Dat betekent niet dat externe AI-providers live zijn.

## Testen

```bash
npm run check
```

De suite controleert onder meer:

- Truth Graph en conflicten;
- pricing en geverifieerde maten;
- routekeuze;
- publish gates;
- immutable runtime;
- GLB-meshinventaris en mobiele metrics;
- de twee onafhankelijke stoelzones;
- builder/runtime prijs- en orderpariteit;
- Meshy, Tripo en Rodin-providercontracten;
- FreeCAD-validatie;
- upload, review, material job, generation en publish via HTTP;
- projectdashboard/wizardstructuur;
- authenticatie en sessiecookies.

Huidige stand: **23/23 tests geslaagd**.

## VPS-deployment

De productieopstelling is:

```text
Internet / browser
       ↓
nginx :9999
       ↓
Node 127.0.0.1:10000
```

De veilige installer bewaart:

- `.env`;
- `data/`;
- `runtime_uploads/`;
- `runtime_assets/`;
- `runtime_outputs/`.

Daarnaast draait de v2.1-migratie alleen op het vaste demoproject en blijven andere projecten bestaan.

```bash
sudo bash deploy/install-release.sh /pad/naar/configurator-studio-v2.1.0 /var/www/configurator-studio
```

## Belangrijke productgrens

v2.1.0 is een deploybare **single-workspace builder core** en een werkende twee-zone stoelconfigurator. De volgende commerciële SaaS-laag is nog niet aanwezig: multi-tenant organisaties, abonnementen, credits, object storage, distributed workers, analytics en volwaardige Shopify/WooCommerce-apps. Die onderdelen worden niet als voltooid voorgesteld.
