(function(root){
  'use strict';

  const BUILD = 'FIX660R8S_VISIBLE_MOBILE_CART_REMOVAL';
  let initialized = false;
  let restoreFocus = null;
  let pendingRemoveKey = '';

  function text(value){ return String(value == null ? '' : value).trim(); }
  function escapeHtml(value){
    return text(value)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#39;');
  }

  function titleForMaterial(material, fallback){
    const mat = material || {};
    return text(mat.publicName || mat.displayName || mat.productName || mat.decorName || fallback || 'Materiaal');
  }

  function metaForMaterial(material){
    const mat = material || {};
    const bits = [];
    const family = text(mat.primaryVisualFamily || mat.visualFamily || mat.decorType || '');
    const thickness = Number(mat.thicknessMm);
    const width = Number(mat.sheetSizeMm && mat.sheetSizeMm.width);
    const height = Number(mat.sheetSizeMm && mat.sheetSizeMm.height);
    if(family) bits.push(family);
    if(Number.isFinite(thickness) && thickness > 0) bits.push(`${thickness} mm`);
    if(Number.isFinite(width) && width > 0 && Number.isFinite(height) && height > 0) bits.push(`${width} × ${height} mm`);
    return bits.join(' · ') || 'Gekozen materiaal';
  }

  function getModels(state){
    const st = state && typeof state === 'object' ? state : {};
    const activeKey = text(st.activeMaterialKey);
    return (Array.isArray(st.materialBatches) ? st.materialBatches : [])
      .filter(batch => batch && text(batch.key))
      .map(batch => ({
        key: text(batch.key),
        title: titleForMaterial(batch.mat, batch.key),
        meta: metaForMaterial(batch.mat),
        material: batch.mat || null,
        active: text(batch.key) === activeKey,
        panelCount: (Array.isArray(st.cart) ? st.cart : []).filter(item => text(item && item.materialKey) === text(batch.key)).length
          + (Array.isArray(st.extraPanels) ? st.extraPanels : []).filter(item => text(item && item.materialKey) === text(batch.key)).reduce((sum,item)=>sum + Math.max(1, Number(item && item.qty) || 1), 0)
      }));
  }

  function nodes(){
    const doc = root.document;
    if(!doc) return {};
    return {
      trigger: doc.getElementById('mobileMaterialCartTrigger'),
      triggerSwatch: doc.getElementById('mobileMaterialCartTriggerSwatch'),
      triggerTitle: doc.getElementById('mobileMaterialCartTriggerTitle'),
      triggerMeta: doc.getElementById('mobileMaterialCartTriggerMeta'),
      triggerCount: doc.getElementById('mobileMaterialCartTriggerCount'),
      backdrop: doc.getElementById('mobileMaterialCartBackdrop'),
      sheet: doc.getElementById('mobileMaterialCartSheet'),
      handle: doc.getElementById('mobileMaterialCartHandle'),
      close: doc.getElementById('mobileMaterialCartClose'),
      subtitle: doc.getElementById('mobileMaterialCartSubtitle'),
      list: doc.getElementById('mobileMaterialCartList'),
      continueBtn: doc.getElementById('mobileMaterialCartContinue')
    };
  }

  function isMobile(){
    try{ return !!(root.matchMedia && root.matchMedia('(max-width:700px)').matches); }
    catch(_){ return Number(root.innerWidth || 9999) <= 700; }
  }

  function applySwatch(element, key, material, state){
    if(!element) return;
    try{
      if(root.ToolAMaterialSwatchRenderer && typeof root.ToolAMaterialSwatchRenderer.applyDomSwatch === 'function'){
        root.ToolAMaterialSwatchRenderer.applyDomSwatch(element, { materialKey:key, material, state, panelGrainAxis:'V' });
        return;
      }
    }catch(_){ }
    const url = text(material && (material.imageThumbUrl || material.imagePreviewUrl));
    if(url) element.style.backgroundImage = `url("${url.replace(/"/g, '%22')}")`;
  }

  function close(options){
    const n = nodes();
    const wasOpen = !!(root.document && root.document.body && root.document.body.classList.contains('mobileMaterialCartOpen'));
    try{ root.document.body.classList.remove('mobileMaterialCartOpen'); }catch(_){ }
    if(n.trigger) n.trigger.setAttribute('aria-expanded','false');
    if(n.sheet) n.sheet.setAttribute('aria-hidden','true');
    if(n.backdrop){
      root.setTimeout(function(){
        try{ if(!root.document.body.classList.contains('mobileMaterialCartOpen')) n.backdrop.hidden = true; }catch(_){ }
      }, 260);
    }
    if(wasOpen && !(options && options.restoreFocus === false)){
      const target = restoreFocus && root.document && root.document.contains(restoreFocus) ? restoreFocus : n.trigger;
      try{ target && target.focus({preventScroll:true}); }catch(_){ try{ target && target.focus(); }catch(__){ } }
    }
    restoreFocus = null;
    if(!(options && options.keepPendingRemoval)) pendingRemoveKey = '';
  }

  function open(){
    const st = root.state || {};
    const models = getModels(st);
    const n = nodes();
    if(!isMobile() || !models.length || !n.sheet || !n.backdrop) return false;
    render(st);
    restoreFocus = root.document.activeElement || n.trigger;
    n.backdrop.hidden = false;
    n.sheet.setAttribute('aria-hidden','false');
    if(n.trigger) n.trigger.setAttribute('aria-expanded','true');
    root.requestAnimationFrame(function(){
      try{ root.document.body.classList.add('mobileMaterialCartOpen'); }catch(_){ }
      try{ n.close && n.close.focus({preventScroll:true}); }catch(_){ }
    });
    return true;
  }

  function render(state){
    const st = state && typeof state === 'object' ? state : (root.state || {});
    const models = getModels(st);
    const n = nodes();
    if(!n.trigger || !n.list) return models;

    const active = models.find(model => model.active) || models[0] || null;
    try{ root.document.body.classList.toggle('hasMobileMaterialCart', models.length > 0); }catch(_){ }
    n.trigger.hidden = models.length === 0;
    if(n.triggerTitle) n.triggerTitle.textContent = models.length === 1 ? 'Jouw materiaal' : 'Jouw materialen';
    if(n.triggerMeta) n.triggerMeta.textContent = models.length === 1 ? '1 gekozen · open' : `${models.length} gekozen · open`;
    if(n.triggerCount) n.triggerCount.textContent = String(models.length);
    if(n.subtitle) n.subtitle.textContent = models.length === 1 ? '1 materiaal gekozen' : `${models.length} materialen gekozen`;
    if(n.continueBtn) n.continueBtn.disabled = models.length === 0;

    if(pendingRemoveKey && !models.some(model => model.key === pendingRemoveKey)) pendingRemoveKey = '';
    n.list.innerHTML = models.map(model => `
      <div class="mobileMaterialCartRow ${model.active ? 'isActive' : ''}" data-mobile-material-row="${escapeHtml(model.key)}">
        <button class="mobileMaterialCartSelect" type="button" data-mobile-material-select="${escapeHtml(model.key)}" aria-pressed="${model.active ? 'true' : 'false'}">
          <span class="mobileMaterialCartSwatch" data-mobile-material-swatch="${escapeHtml(model.key)}" aria-hidden="true"></span>
          <span class="mobileMaterialCartRowCopy">
            <span class="mobileMaterialCartRowTitle">${escapeHtml(model.title)}</span>
            <span class="mobileMaterialCartRowMeta">${escapeHtml(model.meta)}</span>
          </span>
          <span class="mobileMaterialCartActiveMark" aria-hidden="true">✓</span>
        </button>
        <button class="mobileMaterialCartRemove" type="button" data-mobile-material-remove="${escapeHtml(model.key)}" aria-label="${escapeHtml(model.title)} verwijderen">🗑️</button>
        ${pendingRemoveKey === model.key ? `<div class="mobileMaterialCartConfirm" role="group" aria-label="Verwijderen bevestigen">
          <span>${model.panelCount > 0 ? `Verwijder ook ${model.panelCount} gekoppelde pane${model.panelCount === 1 ? 'el' : 'len'}?` : 'Dit materiaal verwijderen?'}</span>
          <span class="mobileMaterialCartConfirmActions">
            <button type="button" data-mobile-material-remove-cancel="${escapeHtml(model.key)}">Behouden</button>
            <button type="button" class="isDanger" data-mobile-material-remove-confirm="${escapeHtml(model.key)}">Verwijderen</button>
          </span>
        </div>` : ''}
      </div>`).join('');

    if(active && n.triggerSwatch) applySwatch(n.triggerSwatch, active.key, active.material, st);
    models.forEach(model => {
      const swatch = Array.from(n.list.querySelectorAll('[data-mobile-material-swatch]'))
        .find(el => text(el.getAttribute('data-mobile-material-swatch')) === model.key);
      applySwatch(swatch, model.key, model.material, st);
    });
    if(!models.length) close({restoreFocus:false});
    return models;
  }

  function activate(key){
    try{
      if(root.ToolAPanelsEntry && typeof root.ToolAPanelsEntry.activateMaterial === 'function') root.ToolAPanelsEntry.activateMaterial(key);
      else if(typeof root.__setActiveMaterial === 'function') root.__setActiveMaterial(key);
    }catch(_){ }
    render(root.state || {});
  }

  function remove(key){
    const cleanKey = text(key);
    const model = getModels(root.state || {}).find(item => item.key === cleanKey);
    if(!model) return false;
    /* Reuse the application's canonical removal transaction. It owns removal
       of the material plus all linked normal/extra panels and opens the shared
       confirmation dialog when that is destructive. The dialog is lifted
       above this mobile sheet by the R8S CSS contract. */
    try{
      if(root.ToolAPanelsEntry && typeof root.ToolAPanelsEntry.removeMaterial === 'function'){
        root.ToolAPanelsEntry.removeMaterial(cleanKey);
        return true;
      }
      if(typeof root.__removeMaterialBatch === 'function'){
        root.__removeMaterialBatch(cleanKey);
        return true;
      }
    }catch(_){ }
    return false;
  }

  function cancelRemove(){
    pendingRemoveKey = '';
    render(root.state || {});
    return true;
  }

  function confirmRemove(key){
    const cleanKey = text(key || pendingRemoveKey);
    if(!cleanKey) return false;
    pendingRemoveKey = '';
    let handled = false;
    try{
      if(root.ToolAPanelsEntry && typeof root.ToolAPanelsEntry.removeMaterialConfirmed === 'function'){
        root.ToolAPanelsEntry.removeMaterialConfirmed(cleanKey);
        handled = true;
      }else if(typeof root.__removeMaterialBatchConfirmed === 'function'){
        root.__removeMaterialBatchConfirmed(cleanKey);
        handled = true;
      }else if(root.ToolAPanelsEntry && typeof root.ToolAPanelsEntry.removeMaterial === 'function'){
        root.ToolAPanelsEntry.removeMaterial(cleanKey);
        handled = true;
      }else if(typeof root.__removeMaterialBatch === 'function'){
        root.__removeMaterialBatch(cleanKey);
        handled = true;
      }
    }catch(_){ handled = false; }
    render(root.state || {});
    return handled;
  }

  function init(){
    if(initialized) return;
    const n = nodes();
    if(!n.trigger || !n.sheet) return;
    initialized = true;
    n.trigger.addEventListener('click', open);
    n.backdrop && n.backdrop.addEventListener('click', function(){ close(); });
    n.close && n.close.addEventListener('click', function(){ close(); });
    n.handle && n.handle.addEventListener('click', function(){ close(); });
    n.continueBtn && n.continueBtn.addEventListener('click', function(){
      close({restoreFocus:false});
      try{
        if(typeof root.__showWizardStep === 'function') root.__showWizardStep('panels');
        else if(typeof root.showStep === 'function') root.showStep('panels');
      }catch(_){ }
    });
    n.list.addEventListener('click', function(event){
      const confirmBtn = event.target && event.target.closest ? event.target.closest('[data-mobile-material-remove-confirm]') : null;
      if(confirmBtn){ event.preventDefault(); event.stopPropagation(); confirmRemove(text(confirmBtn.getAttribute('data-mobile-material-remove-confirm'))); return; }
      const keepBtn = event.target && event.target.closest ? event.target.closest('[data-mobile-material-remove-cancel]') : null;
      if(keepBtn){ event.preventDefault(); event.stopPropagation(); cancelRemove(); return; }
      const removeBtn = event.target && event.target.closest ? event.target.closest('[data-mobile-material-remove]') : null;
      if(removeBtn){ event.preventDefault(); event.stopPropagation(); remove(text(removeBtn.getAttribute('data-mobile-material-remove'))); return; }
      const selectBtn = event.target && event.target.closest ? event.target.closest('[data-mobile-material-select]') : null;
      if(selectBtn){ event.preventDefault(); activate(text(selectBtn.getAttribute('data-mobile-material-select'))); }
    });
    root.document.addEventListener('keydown', function(event){
      if(event.key === 'Escape' && root.document.body.classList.contains('mobileMaterialCartOpen')){
        event.preventDefault(); close();
      }
    });
    root.document.addEventListener('adzaagt-material-selection-updated', function(){ render(root.state || {}); });
    root.addEventListener('resize', function(){ if(!isMobile()) close({restoreFocus:false}); }, {passive:true});
    render(root.state || {});
  }

  root.ToolAMobileMaterialCart = Object.freeze({ BUILD, getModels, init, render, open, close, remove, confirmRemove, cancelRemove });
  root.__TOOLA_MOBILE_MATERIAL_CART_BUILD = BUILD;
  if(root.document){
    if(root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', init, {once:true});
    else init();
  }
})(typeof window !== 'undefined' ? window : globalThis);
