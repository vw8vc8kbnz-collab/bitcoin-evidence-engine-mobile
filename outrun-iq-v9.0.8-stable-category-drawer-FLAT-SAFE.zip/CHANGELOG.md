# Outrun IQ v9.0.8 — Stable Category Drawer

## Focus
Deze release vervangt de v9.0.7 categorie-overlay door een stabiele iOS-style drawer.

## Aangepakt
- Category drawer opent nu via echte `translate3d` slide vanaf links.
- Backdrop fade en drawer slide zijn gescheiden en synchroon.
- Sluiten heeft nu een echte exit-animatie in plaats van direct verdwijnen.
- Hamburger linksboven stopt met de zoekbalk triggeren en opent de drawer betrouwbaar.
- `Alle categorieën` in de feedbar opent dezelfde drawer.
- Horizontale scroll/lekkage in de drawer is geblokkeerd.
- Categorie-items staan nu als vaste settings/list structuur, niet meer als losse verschuifbare tegels.
- Populair/Voor jou/Nieuw/Beste deals chips zijn opnieuw uitgelijnd.
- Drawer ondersteunt tik buiten sluiten, X sluiten, Escape sluiten en swipe naar links sluiten.

## Validatie
- TypeScript `tsc --noEmit`: OK.
- Next build start/compile: gestart; sandbox timeoutte tijdens build zoals bij eerdere releases.
