# Outrun IQ v9.0.8

Stable category drawer release.

Deze build focust alleen op de categoriepagina/drawer-stabiliteit:
- geen springende overlay meer;
- geen horizontaal verschuivende drawer-content;
- hamburger werkt als category/menu trigger;
- feedbar chips zijn compact en netjes uitgelijnd;
- centrale taxonomie blijft beschikbaar voor buyer en toekomstige partner-categorisering.
