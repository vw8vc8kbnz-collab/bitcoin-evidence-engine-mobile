"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState, type TouchEvent } from "react";
import { TAXONOMY, POPULAR_TAXONOMY_ITEMS, parentLabel } from "@/lib/taxonomy";

function urlFor(parent?: string, q?: string, extra = "") {
  const p = new URLSearchParams();
  if (q) p.set("q", q);
  if (parent) p.set("cat", parent);
  p.set("sort", extra || "ai");
  return `/zoeken?${p.toString()}`;
}

type DrawerButtonProps = {
  variant?: "menu" | "pill";
  label?: string;
};

export function CategoryDrawerButton({ variant = "menu", label = "Alle categorieën" }: DrawerButtonProps) {
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [q, setQ] = useState("");
  const [min, setMin] = useState("");
  const [max, setMax] = useState("");
  const [distance, setDistance] = useState("nl");
  const panelRef = useRef<HTMLElement | null>(null);
  const startX = useRef<number | null>(null);
  const currentX = useRef<number | null>(null);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return TAXONOMY;
    return TAXONOMY
      .map((g) => ({
        ...g,
        items: g.items.filter((i) => `${i.label} ${i.keywords.join(" ")} ${g.title}`.toLowerCase().includes(s)),
      }))
      .filter((g) => g.items.length);
  }, [q]);

  const filterHref = `/zoeken?${new URLSearchParams({
    ...(max ? { max } : {}),
    ...(q ? { q } : {}),
    sort: "ai",
    ...(distance ? { afstand: distance } : {}),
    ...(min ? { min } : {}),
  }).toString()}`;

  function show() {
    setMounted(true);
    requestAnimationFrame(() => setOpen(true));
  }

  function hide() {
    setOpen(false);
    window.setTimeout(() => setMounted(false), 360);
  }

  useEffect(() => {
    if (!mounted) return;
    const oldOverflow = document.body.style.overflow;
    const oldTouchAction = document.body.style.touchAction;
    document.body.style.overflow = "hidden";
    document.body.style.touchAction = "none";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") hide();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = oldOverflow;
      document.body.style.touchAction = oldTouchAction;
      window.removeEventListener("keydown", onKey);
    };
  }, [mounted]);

  function onTouchStart(event: TouchEvent<HTMLElement>) {
    startX.current = event.touches[0]?.clientX ?? null;
    currentX.current = startX.current;
    if (panelRef.current) panelRef.current.style.transition = "none";
  }

  function onTouchMove(event: TouchEvent<HTMLElement>) {
    if (startX.current == null || !panelRef.current) return;
    currentX.current = event.touches[0]?.clientX ?? startX.current;
    const delta = Math.min(0, currentX.current - startX.current);
    panelRef.current.style.transform = `translate3d(${delta}px,0,0)`;
  }

  function onTouchEnd() {
    if (!panelRef.current || startX.current == null || currentX.current == null) return;
    const delta = currentX.current - startX.current;
    panelRef.current.style.transition = "";
    panelRef.current.style.transform = "";
    startX.current = null;
    currentX.current = null;
    if (delta < -74) hide();
  }

  return (
    <>
      <button
        type="button"
        className={variant === "menu" ? "catMenuButton" : "catFeedPill"}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          show();
        }}
        aria-label="Open categorieën en filters"
        aria-haspopup="dialog"
      >
        {variant === "menu" ? <><span /><span /><span /></> : label}
      </button>
      {mounted && (
        <div className={`catDrawerLayer ${open ? "isOpen" : "isClosing"}`} role="dialog" aria-modal="true" aria-label="Categorieën en filters">
          <button className="catDrawerBackdrop" type="button" onClick={hide} aria-label="Sluiten" />
          <aside
            className="catDrawerPanel"
            ref={panelRef}
            onTouchStart={onTouchStart}
            onTouchMove={onTouchMove}
            onTouchEnd={onTouchEnd}
          >
            <header className="catDrawerHead">
              <div>
                <span>OUTRUN EXPLORER</span>
                <b>Categorieën & filters</b>
              </div>
              <button type="button" onClick={hide} aria-label="Sluiten">×</button>
            </header>

            <label className="catDrawerSearch">
              <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Zoek categorie, merk of productsoort" />
            </label>

            <section className="catDrawerQuick" aria-label="Snelle feeds">
              <Link href="/zoeken?sort=ai" onClick={hide}><span>🔥</span><b>Populair</b></Link>
              <Link href="/zoeken?sort=waarde" onClick={hide}><span>⭐</span><b>Voor jou</b></Link>
              <Link href="/zoeken?sort=nieuw" onClick={hide}><span>🆕</span><b>Nieuw</b></Link>
              <Link href="/zoeken?sort=korting" onClick={hide}><span>💰</span><b>Beste deals</b></Link>
            </section>

            <section className="catDrawerPopular">
              <h3>Vaak gezocht</h3>
              <div>
                {POPULAR_TAXONOMY_ITEMS.map((item) => (
                  <Link key={item.id} href={urlFor(item.parent, item.label)} onClick={hide}>{item.label}</Link>
                ))}
              </div>
            </section>

            <section className="catDrawerGroups" aria-label="Alle categorieën">
              {filtered.map((group) => (
                <details key={group.id} open className="catDrawerGroup">
                  <summary><span>{group.icon}</span><b>{group.title}</b><em>{group.items.length}</em></summary>
                  <div>
                    <Link className="catAll" href={`/zoeken?cat=${group.parent}&sort=ai`} onClick={hide}>Alles in {parentLabel(group.parent)}</Link>
                    {group.items.map((item) => (
                      <Link key={item.id} href={urlFor(item.parent, item.label)} onClick={hide}>{item.label}</Link>
                    ))}
                  </div>
                </details>
              ))}
            </section>

            <section className="catDrawerFilters">
              <h3>Filters</h3>
              <div className="catFilterGrid">
                <label><span>Min prijs</span><input inputMode="numeric" value={min} onChange={(e) => setMin(e.target.value.replace(/\D/g, ""))} placeholder="€ min" /></label>
                <label><span>Max prijs</span><input inputMode="numeric" value={max} onChange={(e) => setMax(e.target.value.replace(/\D/g, ""))} placeholder="€ max" /></label>
                <label className="wide"><span>Afstand</span><select value={distance} onChange={(e) => setDistance(e.target.value)}><option value="nl">Heel Nederland</option><option value="25">25 km</option><option value="50">50 km</option><option value="100">100 km</option></select></label>
              </div>
              <div className="catFilterChips">
                <Link href="/zoeken?sort=ai" onClick={hide}>AI score 70+</Link>
                <Link href="/zoeken?sort=korting" onClick={hide}>Hoge korting</Link>
                <Link href="/zoeken?sort=nieuw" onClick={hide}>Nieuw binnen</Link>
                <Link href="/zoeken?sort=waarde" onClick={hide}>Beste waarde</Link>
              </div>
              <Link className="catApply" href={filterHref} onClick={hide}>Toon resultaten</Link>
            </section>
          </aside>
        </div>
      )}
    </>
  );
}
