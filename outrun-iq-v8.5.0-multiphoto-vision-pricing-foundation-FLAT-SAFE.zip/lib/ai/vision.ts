/** Vision-taakroute van de AI Model Abstraction Layer.
 *
 * Belangrijk: vision wordt bewust NIET meer stil naar DeepSeek-text teruggezet.
 * Zet expliciet VISION_API_KEY + VISION_MODEL op een multimodaal model
 * (bijv. OpenAI gpt-4o-mini of een EU multimodaal model). Zonder die env-vars
 * blijft vision uit en vult de partner de velden handmatig in.
 */

export type VisionFields = {
  title: string;
  brand: string;
  model: string;
  category: "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
  color: string;
  condition: string;
  conditionScore: number;     // 1-10
  conditionReason: string;    // korte verdedigbare motivatie
  defect: string;             // leeg = geen zichtbaar gebrek
  defects: string[];          // per-foto schade/gebrek observaties
  accessories: string[];
  energyLabel: string;
  newPriceEstimate: number;   // geschatte adviesprijs in hele euro's, 0 = onbekend
  sellingPoints: string[];
  uncertainty: boolean;
  source: string;
};

const CATS = ["witgoed", "meubels", "keukens", "tuin", "overig"] as const;

function num(x: unknown): number {
  if (typeof x === "number" && isFinite(x)) return Math.round(x);
  if (typeof x === "string") {
    const v = parseFloat(x.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", "."));
    if (isFinite(v)) return Math.round(v);
  }
  return 0;
}
function str(x: unknown, max = 160): string { return String(x ?? "").slice(0, max).trim(); }
function arr(x: unknown, maxItems = 5, maxLen = 90): string[] {
  return Array.isArray(x) ? x.map(v => str(v, maxLen)).filter(Boolean).slice(0, maxItems) : [];
}

export function isVisionConfigured() {
  return Boolean(process.env.VISION_API_KEY && process.env.VISION_MODEL);
}

export async function analyzeProductPhotos(dataUrls: string[]): Promise<VisionFields | null> {
  const key = process.env.VISION_API_KEY;
  const model = process.env.VISION_MODEL;
  if (!key || !model) {
    console.error("[ai-vision] uitgeschakeld: VISION_API_KEY en VISION_MODEL zijn verplicht voor beeldherkenning.");
    return null;
  }
  const api = process.env.VISION_BASE_URL || "https://api.openai.com/v1/chat/completions";
  const images = dataUrls.filter(Boolean).slice(0, 6);
  if (!images.length) return null;

  const sys = `Je bent de productherkenning van Outrun IQ, een Nederlandse outlet-marketplace. Je krijgt meerdere foto's van hetzelfde product. Foto 1 is meestal de hoofdproductfoto; latere foto's kunnen zijkant, verpakking, label, serienummer of schade tonen. Beoordeel conditie en gebreken op basis van ALLE foto's. Antwoord UITSLUITEND met geldige JSON, exact deze sleutels:
{"title":"","brand":"","model":"","category":"","color":"","condition":"","conditionScore":0,"conditionReason":"","defect":"","defects":[],"accessories":[],"energyLabel":"","newPriceEstimate":0,"sellingPoints":[],"uncertainty":false}
Regels: title = korte Nederlandse producttitel incl. merk/type indien zichtbaar, max 70 tekens. brand/model alleen als zichtbaar of zeer waarschijnlijk. category = precies één uit: witgoed, meubels, keukens, tuin, overig. condition = korte NL conditietekst van wat je ziet. conditionScore 1-10; onzeker = 7. conditionReason = verdedigbare motivatie in één zin. defect = belangrijkste zichtbaar gebrek of leeg. defects = max 5 bullets met per foto wat opvalt, bijv. "foto 3: kras rechts". accessories = zichtbare accessoires/verpakking. energyLabel = energielabel indien zichtbaar, anders leeg. newPriceEstimate = realistische Nederlandse nieuwprijs in hele euro's, 0 = onbekend. sellingPoints = 2-3 korte verkoopargumenten. Verzin geen typenummers, labels of schade die je niet ziet.`;

  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 30_000);
  try {
    const content: any[] = [
      { type: "text", text: `Analyseer deze ${images.length} foto('s) als één product. Gebruik alle foto's, inclusief schade/detailfoto's.` },
      ...images.flatMap((url, idx) => ([
        { type: "text", text: `Foto ${idx + 1}` },
        { type: "image_url", image_url: { url } },
      ])),
    ];
    const res = await fetch(api, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        temperature: 0.1,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content },
        ],
      }),
    });
    if (!res.ok) {
      console.error("[ai-vision] provider weigerde:", res.status, (await res.text().catch(() => "")).slice(0, 400));
      return null;
    }
    const data = await res.json();
    const raw = String(data?.choices?.[0]?.message?.content ?? "");
    const p = JSON.parse(raw.replace(/```json|```/g, "").trim());
    const cat = CATS.includes(p.category) ? p.category : "overig";
    const score = Math.min(10, Math.max(1, num(p.conditionScore) || 7));
    const defects = arr(p.defects, 5, 100);
    const out: VisionFields = {
      title: str(p.title, 70),
      brand: str(p.brand, 40),
      model: str(p.model, 50),
      category: cat,
      color: str(p.color, 30),
      condition: str(p.condition, 140),
      conditionScore: score,
      conditionReason: str(p.conditionReason, 180),
      defect: str(p.defect, 120) || defects[0] || "",
      defects,
      accessories: arr(p.accessories, 5, 60),
      energyLabel: str(p.energyLabel, 20),
      newPriceEstimate: Math.max(0, num(p.newPriceEstimate)),
      sellingPoints: arr(p.sellingPoints, 3, 70),
      uncertainty: Boolean(p.uncertainty),
      source: String(data?.model ?? model),
    };
    return out.title ? out : null;
  } catch (e) {
    console.error("[ai-vision] fout:", e);
    return null;
  } finally { clearTimeout(t); }
}

export async function analyzeProductPhoto(dataUrl: string): Promise<VisionFields | null> {
  return analyzeProductPhotos([dataUrl]);
}
