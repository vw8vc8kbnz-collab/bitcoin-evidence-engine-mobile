# Changelog — Outrun IQ v8.5.0

## v8.5.0 — Multi-photo Vision & Pricing Foundation

Eerste AI-fundament-update op basis van de v8.4.13 audit.

### Gebouwd
- Multi-foto productherkenning: de partner uploadflow stuurt nu maximaal 6 foto's tegelijk naar vision.
- Vision beoordeelt hoofdproduct, detailfoto's, verpakking, labels en schadefoto's als één productset.
- Vision geeft nu naast basisvelden ook conditie-motivatie, zichtbare gebreken, accessoires, energielabel, verkoopargumenten en onzekerheid terug.
- Vision valt niet meer stil terug op `deepseek-chat`; `VISION_API_KEY` en `VISION_MODEL` zijn expliciet verplicht voor beeldherkenning.
- Pricing krijgt nu de vision-observaties mee: conditie-motivatie, schade/details, accessoires en energielabel tellen mee in het prijsadvies.
- AI-herkenning en pricing endpoints hebben rate-limits tegen misbruik of loops.
- UI-labels rond prijsbewijs zijn eerlijker gemaakt: `AI-prijssignalen` / `modelkennis` in plaats van harde marktclaim.
- `.env.example` verduidelijkt dat vision een echt multimodaal model nodig heeft.

### Checks
- `npx tsc --noEmit` OK.
- `npm run build` compile OK; timeout daarna op bekende Next `Collecting page data` fase.
