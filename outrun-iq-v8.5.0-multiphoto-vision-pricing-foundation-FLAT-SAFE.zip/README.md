# Outrun IQ v8.5.0 — Multi-photo Vision & Pricing Foundation

Deze versie bouwt de eerste auditstap in: product toevoegen met AI gebruikt nu niet meer alleen de eerste foto, maar analyseert meerdere productfoto's samen.

## Belangrijk
Vision staat alleen aan wanneer de server expliciet is geconfigureerd met een multimodale provider:

```env
VISION_MODEL=gpt-4o-mini
VISION_BASE_URL=https://api.openai.com/v1/chat/completions
VISION_API_KEY=...
```

Zonder deze waarden blijft fotoherkenning netjes uit en vult de partner de listing handmatig in. Er is geen stille fallback meer naar `deepseek-chat`, omdat dat geen beeldmodel is.

## Deploy
Flat ZIP: package.json staat in de root. Gebruik de Termius update-regel uit de chat.
