#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/home/ubuntu/stock-gem-engine"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo "Installing Stock Gem Evidence Engine from $SRC_DIR -> $APP_DIR"
mkdir -p "$APP_DIR"
rsync -a --delete --exclude '.venv' --exclude 'data' --exclude 'logs' "$SRC_DIR/" "$APP_DIR/"
mkdir -p "$APP_DIR/data" "$APP_DIR/logs"
if [ ! -f "$APP_DIR/.env" ]; then cp "$APP_DIR/.env.example" "$APP_DIR/.env"; fi
PYBIN="python3"
if command -v python3.12 >/dev/null 2>&1; then PYBIN="python3.12"; fi
cd "$APP_DIR"
if [ ! -d .venv ]; then "$PYBIN" -m venv .venv; fi
.venv/bin/python -m pip install --upgrade pip wheel setuptools
.venv/bin/pip install --only-binary=:all: -r requirements.txt
cat >/tmp/stock-gem.service <<SERVICE
[Unit]
Description=Stock Gem Evidence Engine
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8791
Restart=always
RestartSec=4

[Install]
WantedBy=multi-user.target
SERVICE
sudo mv /tmp/stock-gem.service /etc/systemd/system/stock-gem.service
sudo systemctl daemon-reload
sudo systemctl enable stock-gem.service
sudo systemctl restart stock-gem.service
sleep 2
sudo systemctl status stock-gem.service --no-pager -l || true
echo "Klaar: ${SERVER_PUBLIC_URL:-http://SERVER-IP:8791}"
echo "Logs: tail -n 100 $APP_DIR/logs/app.log"
