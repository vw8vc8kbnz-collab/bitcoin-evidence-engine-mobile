#!/usr/bin/env bash
cd /home/ubuntu
rm -f Stijn-Tradifi-2026_Stock_Gem_Engine_v0_3_0.zip
rm -rf stock_gem_update
wget -O Stijn-Tradifi-2026_Stock_Gem_Engine_v0_3_0.zip https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/Stijn-Tradifi-2026_Stock_Gem_Engine_v0_3_0.zip
ls -lh Stijn-Tradifi-2026_Stock_Gem_Engine_v0_3_0.zip
mkdir -p stock_gem_update
unzip -o Stijn-Tradifi-2026_Stock_Gem_Engine_v0_3_0.zip -d stock_gem_update
cd stock_gem_update/stock-gem-engine
bash scripts/install_or_update.sh
systemctl status stock-gem.service
tail -n 100 /home/ubuntu/stock-gem-engine/logs/app.log
ss -tulpn | grep 8791
