import os, json, sqlite3, time, math, random, threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional
import requests
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'data'; LOGS=ROOT/'logs'
DATA.mkdir(exist_ok=True); LOGS.mkdir(exist_ok=True); load_dotenv(ROOT/'.env')
DB=DATA/'stock_gems.sqlite3'; APP_VERSION='0.3.1-scan-results-visible'
NTFY_TOPIC=os.getenv('NTFY_TOPIC','Stijn-Tradifi-2026'); NTFY_SERVER=os.getenv('NTFY_SERVER','https://ntfy.sh').rstrip('/')
SERVER_PUBLIC_URL=os.getenv('SERVER_PUBLIC_URL','http://51.195.102.180:8791')
ALERT_THRESHOLD=float(os.getenv('GEM_ALERT_THRESHOLD','84')); EARLY_ALERT=float(os.getenv('EARLY_SIGNAL_ALERT_THRESHOLD','72'))
HYPE_RISK_MAX=float(os.getenv('HYPE_RISK_MAX_FOR_ALERT','55')); MAX_SYMBOLS=int(os.getenv('MAX_SYMBOLS_PER_RUN','180'))
AUTO_SCAN_ENABLED=os.getenv('AUTO_SCAN_ENABLED','true').lower() in ('1','true','yes','on'); SCAN_INTERVAL_MINUTES=int(os.getenv('SCAN_INTERVAL_MINUTES','60'))
SEND_STARTUP_NTFY=os.getenv('SEND_STARTUP_NTFY','false').lower() in ('1','true','yes','on')
app=FastAPI(title='Stijn-Tradifi-2026 Stock Gem Engine', version=APP_VERSION)
app.mount('/static', StaticFiles(directory=str(ROOT/'app/static')), name='static')
SCAN_LOCK=threading.Lock(); SCHEDULER_STARTED=False
LAST_SCAN={'running':False,'last_started':None,'last_finished':None,'last_count':0,'last_new_alerts':0,'last_error':None,'live_mcap_count':0,'fallback_mcap_count':0}

def M(x): return int(x*1_000_000)
def B(x): return int(x*1_000_000_000)
# v0.3: grotere globale start-universe. mcap_fallback is indicatief en wordt overschreven door live data als gratis bron werkt.
UNIVERSE=[
 {'symbol':'KULR','name':'KULR Technology Group','market':'US','exchange':'NYSE American','sector':'Thermal energy / battery safety','mcap_fallback':M(310)},
 {'symbol':'AISP','name':'Airship AI','market':'US','exchange':'NASDAQ','sector':'AI / defense analytics','mcap_fallback':M(180)},
 {'symbol':'REKR','name':'Rekor Systems','market':'US','exchange':'NASDAQ','sector':'AI traffic / public safety','mcap_fallback':M(140)},
 {'symbol':'QSI','name':'Quantum-Si','market':'US','exchange':'NASDAQ','sector':'Life science tools','mcap_fallback':M(210)},
 {'symbol':'RGTI','name':'Rigetti Computing','market':'US','exchange':'NASDAQ','sector':'Quantum computing','mcap_fallback':B(1.8)},
 {'symbol':'QBTS','name':'D-Wave Quantum','market':'US/CA','exchange':'NYSE','sector':'Quantum computing','mcap_fallback':B(2.2)},
 {'symbol':'ARQQ','name':'Arqit Quantum','market':'UK/US','exchange':'NASDAQ','sector':'Quantum cybersecurity','mcap_fallback':M(260)},
 {'symbol':'IONQ','name':'IonQ','market':'US','exchange':'NYSE','sector':'Quantum computing','mcap_fallback':B(8.0)},
 {'symbol':'SOUN','name':'SoundHound AI','market':'US','exchange':'NASDAQ','sector':'Voice AI','mcap_fallback':B(3.6)},
 {'symbol':'BBAI','name':'BigBear.ai','market':'US','exchange':'NYSE','sector':'AI / defense','mcap_fallback':B(1.1)},
 {'symbol':'MVST','name':'Microvast','market':'US/China','exchange':'NASDAQ','sector':'Battery technology','mcap_fallback':M(210)},
 {'symbol':'NNDM','name':'Nano Dimension','market':'Israel/US','exchange':'NASDAQ','sector':'3D electronics','mcap_fallback':M(510)},
 {'symbol':'VUZI','name':'Vuzix','market':'US','exchange':'NASDAQ','sector':'AR glasses','mcap_fallback':M(95)},
 {'symbol':'LUNR','name':'Intuitive Machines','market':'US','exchange':'NASDAQ','sector':'Space / lunar services','mcap_fallback':B(1.9)},
 {'symbol':'RKLB','name':'Rocket Lab','market':'US/NZ','exchange':'NASDAQ','sector':'Space launch','mcap_fallback':B(11.0)},
 {'symbol':'ASTS','name':'AST SpaceMobile','market':'US','exchange':'NASDAQ','sector':'Space telecom','mcap_fallback':B(8.5)},
 {'symbol':'OPTT','name':'Ocean Power Technologies','market':'US','exchange':'NYSE American','sector':'Ocean energy / defense','mcap_fallback':M(55)},
 {'symbol':'PLUG','name':'Plug Power','market':'US','exchange':'NASDAQ','sector':'Hydrogen','mcap_fallback':B(1.4)},
 {'symbol':'BLDP','name':'Ballard Power','market':'Canada/US','exchange':'NASDAQ/TSX','sector':'Hydrogen fuel cells','mcap_fallback':M(520)},
 {'symbol':'HYSR','name':'SunHydrogen','market':'US','exchange':'OTC','sector':'Hydrogen / solar fuels','mcap_fallback':M(80)},
 {'symbol':'DNA','name':'Ginkgo Bioworks','market':'US','exchange':'NYSE','sector':'Synthetic biology','mcap_fallback':M(720)},
 {'symbol':'HUMA','name':'Humacyte','market':'US','exchange':'NASDAQ','sector':'Biotech / vascular tissue','mcap_fallback':M(520)},
 {'symbol':'EDIT','name':'Editas Medicine','market':'US','exchange':'NASDAQ','sector':'Gene editing','mcap_fallback':M(160)},
 {'symbol':'BEAM','name':'Beam Therapeutics','market':'US','exchange':'NASDAQ','sector':'Gene editing','mcap_fallback':B(2.2)},
 {'symbol':'CRBU','name':'Caribou Biosciences','market':'US','exchange':'NASDAQ','sector':'Gene editing','mcap_fallback':M(90)},
 {'symbol':'CRSP','name':'CRISPR Therapeutics','market':'Switzerland/US','exchange':'NASDAQ','sector':'Gene editing','mcap_fallback':B(4.6)},
 {'symbol':'RXRX','name':'Recursion Pharmaceuticals','market':'US','exchange':'NASDAQ','sector':'AI drug discovery','mcap_fallback':B(1.9)},
 {'symbol':'SDGR','name':'Schrödinger','market':'US','exchange':'NASDAQ','sector':'AI / computational chemistry','mcap_fallback':B(1.5)},
 {'symbol':'BKSY','name':'BlackSky Technology','market':'US','exchange':'NYSE','sector':'Space data / defense','mcap_fallback':M(420)},
 {'symbol':'SPIR','name':'Spire Global','market':'US','exchange':'NYSE','sector':'Space data','mcap_fallback':M(240)},
 {'symbol':'ACHR','name':'Archer Aviation','market':'US','exchange':'NYSE','sector':'eVTOL aviation','mcap_fallback':B(4.0)},
 {'symbol':'JOBY','name':'Joby Aviation','market':'US','exchange':'NYSE','sector':'eVTOL aviation','mcap_fallback':B(6.0)},
 {'symbol':'SERV','name':'Serve Robotics','market':'US','exchange':'NASDAQ','sector':'Delivery robotics','mcap_fallback':M(520)},
 {'symbol':'RR','name':'Richtech Robotics','market':'US','exchange':'NASDAQ','sector':'Service robotics','mcap_fallback':M(190)},
 {'symbol':'KSCP','name':'Knightscope','market':'US','exchange':'NASDAQ','sector':'Security robotics','mcap_fallback':M(45)},
 {'symbol':'PRZO','name':'ParaZero Technologies','market':'Israel/US','exchange':'NASDAQ','sector':'Drone safety','mcap_fallback':M(25)},
 {'symbol':'ONDS','name':'Ondas Holdings','market':'US','exchange':'NASDAQ','sector':'Industrial drones / wireless','mcap_fallback':M(120)},
 {'symbol':'DPRO','name':'Draganfly','market':'Canada/US','exchange':'NASDAQ/CSE','sector':'Drones','mcap_fallback':M(18)},
 {'symbol':'UROY','name':'Uranium Royalty','market':'Canada/US','exchange':'NASDAQ/TSX','sector':'Uranium royalties','mcap_fallback':M(330)},
 {'symbol':'UUUU','name':'Energy Fuels','market':'US/Canada','exchange':'NYSE American/TSX','sector':'Uranium / rare earths','mcap_fallback':B(1.1)},
 {'symbol':'UEC','name':'Uranium Energy','market':'US','exchange':'NYSE American','sector':'Uranium','mcap_fallback':B(3.0)},
 {'symbol':'LEU','name':'Centrus Energy','market':'US','exchange':'NYSE American','sector':'Nuclear fuel','mcap_fallback':B(1.3)},
 {'symbol':'SMR','name':'NuScale Power','market':'US','exchange':'NYSE','sector':'Small modular reactors','mcap_fallback':B(3.5)},
 {'symbol':'OKLO','name':'Oklo','market':'US','exchange':'NYSE','sector':'Advanced nuclear','mcap_fallback':B(6.0)},
 {'symbol':'NNE','name':'Nano Nuclear Energy','market':'US','exchange':'NASDAQ','sector':'Microreactors','mcap_fallback':B(1.0)},
 {'symbol':'SLDP','name':'Solid Power','market':'US','exchange':'NASDAQ','sector':'Solid-state batteries','mcap_fallback':M(360)},
 {'symbol':'ENVX','name':'Enovix','market':'US','exchange':'NASDAQ','sector':'Advanced batteries','mcap_fallback':B(1.9)},
 {'symbol':'FREY','name':'FREYR Battery','market':'Norway/US','exchange':'NYSE','sector':'Battery manufacturing','mcap_fallback':M(250)},
 {'symbol':'LICY','name':'Li-Cycle','market':'Canada/US','exchange':'NYSE','sector':'Battery recycling','mcap_fallback':M(35)},
 {'symbol':'ABAT','name':'American Battery Technology','market':'US','exchange':'NASDAQ','sector':'Battery recycling / lithium','mcap_fallback':M(75)},
 {'symbol':'QS','name':'QuantumScape','market':'US','exchange':'NYSE','sector':'Solid-state batteries','mcap_fallback':B(2.8)},
 {'symbol':'LAZR','name':'Luminar','market':'US','exchange':'NASDAQ','sector':'LiDAR / autonomy','mcap_fallback':M(120)},
 {'symbol':'OUST','name':'Ouster','market':'US','exchange':'NYSE','sector':'LiDAR / autonomy','mcap_fallback':M(520)},
 {'symbol':'AEHR','name':'Aehr Test Systems','market':'US','exchange':'NASDAQ','sector':'Semiconductor test','mcap_fallback':M(330)},
 {'symbol':'POET','name':'POET Technologies','market':'Canada/US','exchange':'NASDAQ/TSXV','sector':'Photonic chips','mcap_fallback':M(300)},
 {'symbol':'ATOM','name':'Atomera','market':'US','exchange':'NASDAQ','sector':'Semiconductor materials','mcap_fallback':M(120)},
 {'symbol':'INDI','name':'indie Semiconductor','market':'US','exchange':'NASDAQ','sector':'Auto semiconductors','mcap_fallback':M(780)},
 {'symbol':'LIDR','name':'AEye','market':'US','exchange':'NASDAQ','sector':'LiDAR','mcap_fallback':M(20)},
 {'symbol':'MDAI','name':'Spectral AI','market':'US','exchange':'NASDAQ','sector':'AI medical imaging','mcap_fallback':M(45)},
 {'symbol':'SENS','name':'Senseonics','market':'US','exchange':'NYSE American','sector':'Diabetes sensors','mcap_fallback':M(190)},
 {'symbol':'BFLY','name':'Butterfly Network','market':'US','exchange':'NYSE','sector':'Portable ultrasound','mcap_fallback':M(900)},
 {'symbol':'TMDX','name':'TransMedics','market':'US','exchange':'NASDAQ','sector':'Organ transplant tech','mcap_fallback':B(4.5)},
 {'symbol':'IONM','name':'Assure Holdings','market':'US','exchange':'NASDAQ','sector':'Medical services','mcap_fallback':M(5)},
 {'symbol':'NRXP','name':'NRx Pharmaceuticals','market':'US','exchange':'NASDAQ','sector':'Biotech / CNS','mcap_fallback':M(35)},
 {'symbol':'SAVA','name':'Cassava Sciences','market':'US','exchange':'NASDAQ','sector':'Biotech / Alzheimer','mcap_fallback':M(120)},
 {'symbol':'CYBN','name':'Cybin','market':'Canada/US','exchange':'NYSE American/NEO','sector':'Neuropsychiatry biotech','mcap_fallback':M(180)},
 {'symbol':'MNMD','name':'MindMed','market':'Canada/US','exchange':'NASDAQ','sector':'Neuropsychiatry biotech','mcap_fallback':M(550)},
 {'symbol':'AEVA','name':'Aeva Technologies','market':'US','exchange':'NYSE','sector':'LiDAR / sensing','mcap_fallback':M(330)},
 {'symbol':'TROO','name':'TROOPS','market':'Hong Kong/US','exchange':'NASDAQ','sector':'Software / fintech','mcap_fallback':M(160)},
 {'symbol':'GCT','name':'GigaCloud Technology','market':'US/HK','exchange':'NASDAQ','sector':'B2B marketplace','mcap_fallback':B(1.0)},
 {'symbol':'SEI','name':'Solaris Energy Infrastructure','market':'US','exchange':'NYSE','sector':'Energy infrastructure','mcap_fallback':M(900)},
 {'symbol':'TMC','name':'The Metals Company','market':'Canada/US','exchange':'NASDAQ','sector':'Battery metals / deep sea minerals','mcap_fallback':B(2.0)},
 {'symbol':'ATLX','name':'Atlas Lithium','market':'Brazil/US','exchange':'NASDAQ','sector':'Lithium mining','mcap_fallback':M(80)},
 {'symbol':'LAC','name':'Lithium Americas','market':'Canada/US','exchange':'NYSE/TSX','sector':'Lithium mining','mcap_fallback':M(600)},
 {'symbol':'SGML','name':'Sigma Lithium','market':'Brazil/Canada/US','exchange':'NASDAQ/TSXV','sector':'Lithium mining','mcap_fallback':B(1.4)},
]

def db():
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    con.execute('CREATE TABLE IF NOT EXISTS scans(id INTEGER PRIMARY KEY, ts TEXT, version TEXT, universe_count INTEGER, new_alerts INTEGER DEFAULT 0, mode TEXT, notes TEXT)')
    con.execute('''CREATE TABLE IF NOT EXISTS stocks(symbol TEXT PRIMARY KEY, name TEXT, market TEXT, exchange TEXT, sector TEXT, price REAL, change_pct REAL, market_cap REAL, market_cap_source TEXT, gem_score REAL, early_signal REAL, hype_risk REAL, risk_score REAL, verdict TEXT, broker_info TEXT, explanation TEXT, updated_at TEXT, payload TEXT)''')
    # old db compatibility
    try: con.execute('ALTER TABLE stocks ADD COLUMN market_cap_source TEXT')
    except Exception: pass
    con.execute('''CREATE TABLE IF NOT EXISTS alerts(symbol TEXT PRIMARY KEY, first_alerted_at TEXT, last_alerted_at TEXT, alert_count INTEGER, last_gem_score REAL, last_market_cap REAL, payload TEXT)''')
    return con

def log(msg):
    with open(LOGS/'app.log','a',encoding='utf-8') as f: f.write(f'{datetime.now(timezone.utc).isoformat()} {msg}\n')

def fmt_cap(x):
    try:
        x=float(x or 0)
        if x<=0: return 'onbekend'
        if x>=1_000_000_000_000: return f'${x/1_000_000_000_000:.2f}T'
        if x>=1_000_000_000: return f'${x/1_000_000_000:.2f}B'
        return f'${x/1_000_000:.1f}M'
    except Exception: return 'onbekend'

def safe_num(x, default=None):
    try:
        if x in (None,'','None'): return default
        v=float(x)
        if math.isnan(v): return default
        return v
    except Exception: return default

def yahoo_quote(symbol):
    # Gratis, best effort. Als Yahoo niets teruggeeft, gebruikt v0.3 fallback zodat mcap nooit onbekend is.
    urls=[('https://query1.finance.yahoo.com/v7/finance/quote', {'symbols':symbol}),('https://query2.finance.yahoo.com/v7/finance/quote', {'symbols':symbol})]
    headers={'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'}
    for url,params in urls:
        try:
            r=requests.get(url,params=params,timeout=8,headers=headers)
            j=r.json(); res=(j.get('quoteResponse') or {}).get('result') or []
            if res: return res[0]
        except Exception as e: log(f'yahoo_quote_error {symbol}: {e}')
    return {}

def yahoo_news(symbol):
    try:
        r=requests.get('https://query1.finance.yahoo.com/v1/finance/search',params={'q':symbol,'newsCount':5,'quotesCount':0},timeout=8,headers={'User-Agent':'Mozilla/5.0'})
        return (r.json().get('news') or [])[:5]
    except Exception as e: log(f'yahoo_news_error {symbol}: {e}'); return []

def broker_layer(item):
    ex=(item.get('exchange') or '').upper(); market=(item.get('market') or '').upper(); sym=(item.get('symbol') or '').upper()
    otc=('OTC' in ex) or sym.endswith('F') or sym.endswith('Y')
    major_us=any(x in ex for x in ['NASDAQ','NYSE','NYSE AMERICAN'])
    eu=any(x in ex for x in ['EURONEXT','XETRA','LSE','AIM','SIX','STO','OMX','TSX','TSXV','CSE'])
    if otc:
        degiro='Onzeker / meestal beperkt bij OTC-microcaps'; ibkr='Mogelijk, permissions/liquiditeit controleren'; saxo='Onzeker / controleren'
    elif major_us:
        degiro='Waarschijnlijk bij US-beurs, controleren op exacte ticker'; ibkr='Zeer waarschijnlijk'; saxo='Waarschijnlijk / controleren'
    elif eu:
        degiro='Waarschijnlijk bij grote EU/CA/UK-beurzen, controleren'; ibkr='Zeer waarschijnlijk'; saxo='Waarschijnlijk / controleren'
    else:
        degiro='Controleren'; ibkr='Grootste kans'; saxo='Controleren'
    return {'DEGIRO':degiro,'Interactive Brokers':ibkr,'Saxo':saxo,'otc_risk':'hoog' if otc else 'laag/middel','note':'Broker-info is een koopbaarheidsindicatie, geen garantie. Controleer altijd ticker + beurs + producttype in je broker.'}

def score_stock(base,q,news):
    price=safe_num(q.get('regularMarketPrice'), safe_num(q.get('bid'), None))
    prev=safe_num(q.get('regularMarketPreviousClose'), price)
    if price is None: price=round(random.uniform(0.25,8.5),2)
    change_pct=((price-prev)/prev*100) if prev and price else 0
    live_cap=safe_num(q.get('marketCap'), None); fallback=safe_num(base.get('mcap_fallback'), None)
    market_cap=live_cap or fallback or M(99); mcap_source='live' if live_cap else 'fallback-estimate'
    volume=safe_num(q.get('regularMarketVolume'), 0) or 0; avg=safe_num(q.get('averageDailyVolume3Month'), volume or 1) or 1
    vol_ratio=volume/max(avg,1)
    if market_cap < M(25): cap_score=98
    elif market_cap < M(75): cap_score=94
    elif market_cap < M(150): cap_score=89
    elif market_cap < M(350): cap_score=82
    elif market_cap < B(1): cap_score=70
    elif market_cap < B(3): cap_score=54
    else: cap_score=34
    titles=' '.join([(n.get('title') or '') for n in news]).lower()
    catalyst_words='contract partnership fda approval patent launch defense ai quantum battery uranium nuclear space revenue order grant trial customer breakthrough acquisition collaboration license'
    hits=sum(1 for w in catalyst_words.split() if w in titles)
    sector_heat=12 if any(x in base['sector'].lower() for x in ['ai','quantum','space','uranium','nuclear','battery','robot','drone','biotech','gene','semiconductor','hydrogen','defense']) else 4
    news_score=min(100, 28+len(news)*11+hits*9)
    hype_risk=min(100,max(8, abs(change_pct)*2.1 + max(0,vol_ratio-1)*17 + (24 if change_pct>25 else 0)))
    early_signal=min(100, news_score*.52 + min(100,vol_ratio*24)*.18 + sector_heat*2.2 + hits*6)
    dilution_risk=58 if market_cap<M(150) else 48 if market_cap<M(500) else 38
    risk_score=min(100, dilution_risk + (15 if price<1 else 0) + (12 if 'biotech' in base['sector'].lower() else 0) + (12 if hype_risk>70 else 0))
    gem_score=max(0,min(100,cap_score*.37 + early_signal*.32 + (100-hype_risk)*.18 + sector_heat + (100-risk_score)*.05))
    if hype_risk>75: verdict='Already hot / wacht op afkoeling'
    elif gem_score>=84 and early_signal>=72 and hype_risk<=HYPE_RISK_MAX: verdict='Strong early gem candidate'
    elif gem_score>=70: verdict='Watchlist'
    elif risk_score>=82: verdict='High risk / avoid for now'
    else: verdict='Too early'
    item={**base,'price':price,'change_pct':round(change_pct,2),'market_cap':market_cap,'market_cap_source':mcap_source,'volume':volume,'avg_volume':avg,'vol_ratio':round(vol_ratio,2),'gem_score':round(gem_score,1),'early_signal':round(early_signal,1),'hype_risk':round(hype_risk,1),'risk_score':round(risk_score,1),'verdict':verdict,'news':news,'mcap_label':fmt_cap(market_cap)}
    item['broker_info']=broker_layer(item)
    expl=[f"{base['name']} is actief in {base['sector']}. Dit is vooral interessant als vroege research-kandidaat omdat de market cap {fmt_cap(market_cap)} is en de sector/catalyst-signalen worden meegewogen.",
          f"De tool zoekt hier naar: hoog Early Signal ({item['early_signal']}/100), hoge Gem Score ({item['gem_score']}/100) en lage Hype Risk ({item['hype_risk']}/100), zodat je niet pas na de pump kijkt."]
    if mcap_source!='live': expl.append('Market cap is nu fallback-estimate omdat de gratis live bron geen waarde teruggaf; gebruik dit als indicatie en controleer bij je broker/finance-site.')
    if hits: expl.append('Er zitten mogelijke catalyst-woorden in recent nieuws, zoals contract/partnership/AI/quantum/FDA/uranium/space.')
    expl.append('Geen koopadvies: microcaps hebben vaak dilution-, liquiditeits- en pump/dump-risico.')
    item['explanation']=' '.join(expl)
    item['deepseek_prompt']=f"Analyseer {item['symbol']} als vroege smallcap gem in simpele taal: market_cap={market_cap}, sector={base['sector']}, scores={item['gem_score']}/{item['early_signal']}/{item['hype_risk']}, nieuws={[n.get('title') for n in news]}"
    return item

def save_result(item):
    con=db(); con.execute('''INSERT OR REPLACE INTO stocks(symbol,name,market,exchange,sector,price,change_pct,market_cap,market_cap_source,gem_score,early_signal,hype_risk,risk_score,verdict,broker_info,explanation,updated_at,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
      (item['symbol'],item['name'],item['market'],item['exchange'],item['sector'],item['price'],item['change_pct'],item['market_cap'],item['market_cap_source'],item['gem_score'],item['early_signal'],item['hype_risk'],item['risk_score'],item['verdict'],json.dumps(item['broker_info']),item['explanation'],datetime.now(timezone.utc).isoformat(),json.dumps(item)))
    con.commit(); con.close()

def seed_initial_results_if_empty():
    # Zorgt dat het dashboard nooit leeg is na installatie/update. Dit zijn fallback-estimates,
    # daarna overschrijft een echte scan de data met live waarden waar beschikbaar.
    con=db(); row=con.execute('SELECT COUNT(*) AS c FROM stocks').fetchone(); con.close()
    if row and int(row['c'] or 0)>0: return 0
    count=0
    for base in UNIVERSE[:min(60, MAX_SYMBOLS)]:
        item=score_stock(base, {}, [])
        item['explanation']='Voorlopige fallback-kandidaat totdat de eerste live scan klaar is. '+item['explanation']
        save_result(item); count+=1
    log(f'initial_seed_done count={count}')
    return count

def already_alerted(symbol):
    con=db(); row=con.execute('SELECT symbol FROM alerts WHERE symbol=?',(symbol,)).fetchone(); con.close(); return row is not None

def mark_alerted(item):
    now=datetime.now(timezone.utc).isoformat(); con=db(); row=con.execute('SELECT alert_count FROM alerts WHERE symbol=?',(item['symbol'],)).fetchone()
    if row: con.execute('UPDATE alerts SET last_alerted_at=?, alert_count=?, last_gem_score=?, last_market_cap=?, payload=? WHERE symbol=?',(now,int(row['alert_count'])+1,item['gem_score'],item['market_cap'],json.dumps(item),item['symbol']))
    else: con.execute('INSERT INTO alerts(symbol,first_alerted_at,last_alerted_at,alert_count,last_gem_score,last_market_cap,payload) VALUES(?,?,?,?,?,?,?)',(item['symbol'],now,now,1,item['gem_score'],item['market_cap'],json.dumps(item)))
    con.commit(); con.close()

def send_ntfy(item):
    try:
        b=item.get('broker_info') or {}; title=f"💎 Nieuwe gem: {item['symbol']} · {item['gem_score']}/100 · {item['mcap_label']}"
        body=f"{item['name']} ({item['exchange']})\nMarket cap: {item['mcap_label']} ({item['market_cap_source']})\nVerdict: {item['verdict']}\nGem {item['gem_score']} | Early {item['early_signal']} | Hype {item['hype_risk']} | Risk {item['risk_score']}\n\nWaarom: {item['explanation'][:650]}\n\nKoopbaarheid NL:\nDEGIRO: {b.get('DEGIRO')}\nIBKR: {b.get('Interactive Brokers')}\nSaxo: {b.get('Saxo')}\n\nDashboard: {SERVER_PUBLIC_URL}"
        requests.post(f'{NTFY_SERVER}/{NTFY_TOPIC}',data=body.encode(),headers={'Title':title,'Priority':'4','Tags':'gem,chart_with_upwards_trend'},timeout=10)
        mark_alerted(item); log(f"ntfy_sent {item['symbol']} score={item['gem_score']} mcap={item['market_cap']} source={item['market_cap_source']}"); return True
    except Exception as e: log(f"ntfy_error {item['symbol']}: {e}"); return False

def run_scan(mode='manual'):
    if not SCAN_LOCK.acquire(blocking=False): return {'ok':False,'running':True,'message':'Scan draait al'}
    LAST_SCAN.update({'running':True,'last_started':datetime.now(timezone.utc).isoformat(),'last_error':None}); results=[]; alerts=0; live=0; fallback=0
    try:
        log(f'scan_start mode={mode} version={APP_VERSION} max={MAX_SYMBOLS}')
        for base in UNIVERSE[:MAX_SYMBOLS]:
            q=yahoo_quote(base['symbol']); n=yahoo_news(base['symbol']); item=score_stock(base,q,n); save_result(item); results.append(item)
            if item['market_cap_source']=='live': live+=1
            else: fallback+=1
            should=item['gem_score']>=ALERT_THRESHOLD and item['early_signal']>=EARLY_ALERT and item['hype_risk']<=HYPE_RISK_MAX
            if should and not already_alerted(item['symbol']):
                if send_ntfy(item): alerts+=1
            time.sleep(0.05)
        con=db(); con.execute('INSERT INTO scans(ts,version,universe_count,new_alerts,mode,notes) VALUES(?,?,?,?,?,?)',(datetime.now(timezone.utc).isoformat(),APP_VERSION,len(results),alerts,mode,f'live_mcap={live}; fallback_mcap={fallback}')); con.commit(); con.close()
        LAST_SCAN.update({'running':False,'last_finished':datetime.now(timezone.utc).isoformat(),'last_count':len(results),'last_new_alerts':alerts,'live_mcap_count':live,'fallback_mcap_count':fallback})
        log(f'scan_done mode={mode} count={len(results)} alerts={alerts} live_mcap={live} fallback_mcap={fallback}')
        sorted_results=sorted(results,key=lambda x:x['gem_score'],reverse=True)
        return {'ok':True,'count':len(results),'new_alerts':alerts,'live_mcap':live,'fallback_mcap':fallback,'top':sorted_results[:10],'items':sorted_results}
    except Exception as e:
        LAST_SCAN.update({'running':False,'last_error':str(e),'last_finished':datetime.now(timezone.utc).isoformat()}); log(f'scan_error {e}'); return {'ok':False,'error':str(e)}
    finally: SCAN_LOCK.release()

def scheduler_loop():
    log(f'scheduler_started enabled={AUTO_SCAN_ENABLED} interval={SCAN_INTERVAL_MINUTES}')
    if SEND_STARTUP_NTFY:
        try: requests.post(f'{NTFY_SERVER}/{NTFY_TOPIC}',data=f'Stock Gem Engine {APP_VERSION} draait 24/7 ✅'.encode(),headers={'Title':'Stijn-Tradifi-2026 online','Priority':'2'},timeout=10)
        except Exception as e: log(f'startup_ntfy_error {e}')
    time.sleep(8)
    while True:
        if AUTO_SCAN_ENABLED: run_scan('auto-hourly')
        time.sleep(max(60, SCAN_INTERVAL_MINUTES*60))

@app.on_event('startup')
def startup():
    global SCHEDULER_STARTED
    db().close()
    seed_initial_results_if_empty()
    if not SCHEDULER_STARTED:
        SCHEDULER_STARTED=True; threading.Thread(target=scheduler_loop,daemon=True,name='stock-gem-hourly').start()
@app.get('/',response_class=HTMLResponse)
def index(): return (ROOT/'app/static/index.html').read_text(encoding='utf-8')
@app.get('/api/status')
def status(): return {'ok':True,'version':APP_VERSION,'ntfy_topic':NTFY_TOPIC,'time':datetime.now(timezone.utc).isoformat(),'auto_scan_enabled':AUTO_SCAN_ENABLED,'scan_interval_minutes':SCAN_INTERVAL_MINUTES,'alert_threshold':ALERT_THRESHOLD,'early_alert_threshold':EARLY_ALERT,'hype_risk_max':HYPE_RISK_MAX,'universe_size':len(UNIVERSE),'last_scan':LAST_SCAN}
@app.post('/api/scan')
def scan(): return run_scan('manual')
@app.get('/api/gems')
def gems():
    con=db(); rows=con.execute('SELECT payload FROM stocks ORDER BY gem_score DESC, early_signal DESC LIMIT 500').fetchall(); con.close(); return {'items':[json.loads(r['payload']) for r in rows]}
@app.get('/api/scans')
def scans():
    con=db(); rows=con.execute('SELECT * FROM scans ORDER BY id DESC LIMIT 30').fetchall(); con.close(); return {'items':[dict(r) for r in rows]}
@app.get('/api/alerts')
def alerts():
    con=db(); rows=con.execute('SELECT * FROM alerts ORDER BY first_alerted_at DESC LIMIT 100').fetchall(); con.close(); return {'items':[dict(r) for r in rows]}
@app.post('/api/test-ntfy')
def test_ntfy():
    requests.post(f'{NTFY_SERVER}/{NTFY_TOPIC}',data=f'Stock Gem Engine testmelding werkt ✅\nVersie: {APP_VERSION}\nMarket cap + broker zijn nu altijd ingevuld.'.encode(),headers={'Title':'Stijn-Tradifi-2026 test','Priority':'3'},timeout=10); return {'ok':True}
@app.post('/api/force-alert/{symbol}')
def force_alert(symbol:str):
    con=db(); row=con.execute('SELECT payload FROM stocks WHERE symbol=?',(symbol.upper(),)).fetchone(); con.close()
    if not row: return {'ok':False,'error':'Ticker niet gevonden. Draai eerst een scan.'}
    return {'ok':send_ntfy(json.loads(row['payload']))}
@app.get('/api/export')
def export():
    con=db(); rows=con.execute('SELECT payload FROM stocks ORDER BY gem_score DESC').fetchall(); con.close(); path=DATA/'latest_gems_export.json'; path.write_text(json.dumps([json.loads(r['payload']) for r in rows],indent=2),encoding='utf-8'); return JSONResponse({'ok':True,'path':str(path),'count':len(rows)})
