Stijn-Tradifi-2026 Stock Gem Engine v0.3.1

Start/update:
  bash scripts/install_or_update.sh

URL:
  http://SERVER-IP:8791

Belangrijk in v0.3.1:
- Market cap wordt nooit meer leeg gelaten: live als beschikbaar, anders fallback-estimate met bronlabel.
- Broker-laag is altijd ingevuld: DEGIRO / Interactive Brokers / Saxo, plus waarschuwing.
- 24/7 hourly scanner blijft draaien via dezelfde service.
- Handmatige scan blijft werken.
- ntfy alleen voor nieuwe high-conviction gems boven ingestelde drempels.
