#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="${ROOMARC_TARGET:-$HOME/roomarc}"
echo "============================================================"
echo "ROOMARC v1.4.0 — Clean Scandinavian redesign"
echo "============================================================"
if [ ! -d "$SRC_DIR/roomarc" ]; then
  echo "ERROR: verwacht $SRC_DIR/roomarc in de uitgepakte ZIP." >&2
  exit 1
fi
rm -rf "$TARGET"; mkdir -p "$TARGET"
cp -a "$SRC_DIR/roomarc" "$TARGET/roomarc"
cd "$TARGET/roomarc"
chmod +x scripts/*.sh
./scripts/install.sh
echo "============================================================"
echo "Klaar. Start Roomarc..."
echo "URL: http://SERVER-IP:8899   Demo: demo@roomarc.local / demo123"
echo "============================================================"
exec ./scripts/run_dev.sh
