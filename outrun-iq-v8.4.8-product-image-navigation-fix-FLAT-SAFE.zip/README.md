# Outrun IQ v8.4.8

Correctiebuild bovenop v8.4.6/v8.4.7 voor productfoto's en navigatie.

Belangrijk:
- v8.4.7 had visuele regressies in productfoto's en de bottom navigation.
- v8.4.8 corrigeert dit gericht zonder nieuwe businesslogica of finance-logica te wijzigen.
- ZIP blijft flat deployable: `package.json` staat in de root.
