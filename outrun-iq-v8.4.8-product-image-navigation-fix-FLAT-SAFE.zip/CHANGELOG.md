# v8.4.8 — Product Image & Navigation Correction

- Herstelt de v8.4.7 beeldproblemen: fallback-illustraties worden niet meer achter echte productfoto's getoond.
- Productfoto's in lijsten, compacte rails en AI-resultaten worden gecentreerd en met `contain` getoond zonder rommelige overlap.
- Home-rails krijgen hogere, rustigere productkaarten zodat titel, score en prijs niet door elkaar lopen.
- AI Picks tonen productfoto's volledig in plaats van hard afgesneden.
- Productdetailfoto's tonen de volledige foto en krijgen een fullscreen viewer met dubbel-tik zoom en thumbnails.
- Bottom navigation is teruggezet naar een stabiele compacte vorm: geen grote actieve pill/overlay die content of taps verstoort.
- Navigatie-links prefetch'en opnieuw, maar zonder extra hit-area pseudo-overlays die taps konden onderscheppen.
