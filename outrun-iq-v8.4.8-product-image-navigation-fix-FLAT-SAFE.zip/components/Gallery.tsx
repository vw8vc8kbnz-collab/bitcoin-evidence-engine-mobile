"use client";
import { useRef, useState } from "react";
import { Illu, type IlluKind } from "./icons";

export function Gallery({ photos, fallback, defect, title }:{
  photos: string[]; fallback: IlluKind; defect?: string; title: string;
}) {
  const [i, setI] = useState(0);
  const [open, setOpen] = useState(false);
  const [zoom, setZoom] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  function onScroll() {
    const el = ref.current;
    if (el) setI(Math.round(el.scrollLeft / el.clientWidth));
  }
  if (photos.length === 0) {
    return (
      <>
        <button type="button" className="galleryOpen empty" aria-label="Geen foto beschikbaar">
          <span style={{ width: 130 }}><Illu kind={fallback} /></span>
        </button>
        {defect && <span className="gebrek"><i />{defect}</span>}
      </>
    );
  }
  const active = Math.min(i, photos.length - 1);
  return (
    <>
      <div className="gal" ref={ref} onScroll={onScroll}>
        {photos.map((u, idx) => (
          /* eslint-disable-next-line @next/next/no-img-element */
          <img key={`${u}-${idx}`} src={u} alt={title} loading={idx === 0 ? "eager" : "lazy"} decoding="async" />
        ))}
      </div>
      <button type="button" className="galleryOpen" onClick={() => setOpen(true)} aria-label="Open foto volledig">
        <span>Bekijk volledig</span>
      </button>
      {defect && <span className="gebrek"><i />{defect}</span>}
      <span className="cnt">{active + 1} / {photos.length}</span>
      {photos.length > 1 && <span className="galleryDots">{photos.map((_, idx) => <i key={idx} className={idx === active ? "on" : ""} />)}</span>}
      {open && (
        <div className="photoLightbox" role="dialog" aria-modal="true" aria-label="Productfoto">
          <button className="photoClose" type="button" onClick={() => setOpen(false)} aria-label="Sluiten">×</button>
          <div className="photoStage" onDoubleClick={() => setZoom(v => !v)}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={photos[active]} alt={title} className={zoom ? "zoom" : ""} />
          </div>
          <div className="photoTools">
            <button type="button" onClick={() => setI(Math.max(0, active - 1))} disabled={active === 0}>Vorige</button>
            <span>{active + 1} / {photos.length} · dubbeltik om te zoomen</span>
            <button type="button" onClick={() => setI(Math.min(photos.length - 1, active + 1))} disabled={active === photos.length - 1}>Volgende</button>
          </div>
          {photos.length > 1 && <div className="photoThumbs">{photos.map((u, idx) => (
            <button key={`${u}-thumb-${idx}`} type="button" className={idx === active ? "on" : ""} onClick={() => { setI(idx); setZoom(false); }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}<img src={u} alt="" />
            </button>
          ))}</div>}
        </div>
      )}
    </>
  );
}
