from __future__ import annotations
import json
from app.db.database import db
from app.core.config import settings
from app.core.time_utils import utc_now, to_ms, horizon_delta
from app.engine.feature_engine import FeatureEngine
from app.engine.model_arena import ModelArena
from app.engine.meta_judge import MetaJudge
from app.engine.risk_rules import invalidation_price as calc_invalidation_price



def _clamp(v, lo, hi, default=0.0):
    try:
        import math
        x = float(v)
        if not math.isfinite(x):
            return default
        return max(lo, min(hi, x))
    except Exception:
        return default

def _normalise_forecast_item(combined: dict, current_price: float, horizon: str) -> dict:
    """V10.16.44: keep live forecast output human-scale and safe.

    Internal models use percent points for expected_move_pct and 0-100 for
    confidence. Older UI bugs multiplied those values by 100. This function also
    prevents absurd live targets or fake 90% confidence when evidence is weak.
    """
    out = dict(combined or {})
    bull = _clamp(out.get('bullish_probability', 0.5), 0.01, 0.99, 0.5)
    if bull > 1.0:  # tolerate accidental 0-100 probability payloads
        bull = _clamp(bull / 100.0, 0.01, 0.99, 0.5)
    out['bullish_probability'] = bull
    out['bearish_probability'] = _clamp(1.0 - bull, 0.01, 0.99, 0.5)
    conf = _clamp(out.get('confidence', 0.0), 0.0, 100.0, 0.0)
    evidence = int(out.get('evidence_count') or 0)
    edge = abs(bull - 0.5) * 2.0
    # Confidence needs both model edge and historical evidence. A neutral stack
    # must not display as a strong signal just because many weak models voted.
    evidence_cap = 38.0 + min(32.0, evidence / 35.0)
    edge_cap = 35.0 + edge * 75.0
    out['confidence'] = round(min(conf, evidence_cap, edge_cap, 88.0), 2)
    move = _clamp(out.get('expected_move_pct', 0.0), -80.0, 80.0, 0.0)
    horizon_caps = {'1h': 3.5, '4h': 6.0, '8h': 8.5, '24h': 13.0, '7d': 24.0, '30d': 45.0, '90d': 75.0}
    cap = horizon_caps.get(str(horizon), 20.0)
    move = _clamp(move, -cap, cap, 0.0)
    out['expected_move_pct'] = round(move, 6)
    if current_price and current_price > 0:
        out['expected_price'] = float(current_price) * (1 + move / 100.0)
    return out

class ForecastService:
    def __init__(self):
        self.features = FeatureEngine()
        self.arena = ModelArena()
        self.judge = MetaJudge()

    def maybe_create_run(self, force: bool = False) -> dict:
        now=utc_now()
        latest = db.fetchone("SELECT created_at_ms FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1")
        if latest and not force:
            age_min = (to_ms(now) - int(latest[0])) / 60000
            if age_min < settings.min_forecast_gap_minutes:
                return {"created": False, "reason": f"Laatste forecast is {age_min:.1f} minuten oud"}
        return self.create_run()

    def create_run(self) -> dict:
        rebuilt = self.features.rebuild()
        price_row = db.fetchone("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
        if not price_row:
            return {"created": False, "reason": "Geen candledata beschikbaar"}
        current_price = float(price_row[0])
        now=utc_now(); now_ms=to_ms(now)
        run_id = db.fetchone("SELECT nextval('seq_forecast_runs')")[0]
        data_points = db.fetchone("SELECT COUNT(*) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])[0]
        db.execute("INSERT INTO forecast_runs VALUES (?, ?, ?, ?, ?, 'open', ?, ?)", [run_id, now, now_ms, current_price, data_points, settings.engine_version, f"features_rebuilt={rebuilt}"])
        items=[]
        for horizon in settings.horizons:
            models = self.arena.run_models(horizon, current_price)
            combined = self.judge.combine(models, current_price)
            combined = _normalise_forecast_item(combined, current_price, horizon)
            due = now + horizon_delta(horizon)
            item_id = f"{run_id}_{horizon}"
            target_distance_pct = abs((float(combined['expected_price']) / current_price - 1) * 100) if current_price else abs(float(combined['expected_move_pct']))
            inv_price_value, invalidation_distance_pct = calc_invalidation_price(current_price, float(combined['expected_move_pct']), horizon, target_distance_pct)
            # V9.3: live forecasts store a wider practical invalidation line,
            # not a mirror of the target. Small targets caused too many wick fails.
            db.execute("""
                INSERT INTO forecast_items (
                    item_id, run_id, horizon, due_at, due_at_ms, start_price,
                    bullish_probability, bearish_probability, expected_move_pct, expected_price,
                    invalidation_price, invalidation_distance_pct,
                    bullish_range_low, bullish_range_high, bearish_risk_low, bearish_risk_high,
                    confidence, evidence_count, contributions_json, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open')
            """, [item_id, run_id, horizon, due, to_ms(due), current_price, combined['bullish_probability'], combined['bearish_probability'], combined['expected_move_pct'], combined['expected_price'], inv_price_value, invalidation_distance_pct, combined['bullish_range_low'], combined['bullish_range_high'], combined['bearish_risk_low'], combined['bearish_risk_high'], combined['confidence'], combined['evidence_count'], json.dumps(combined['contributions'])])
            items.append({"horizon": horizon, **combined, "invalidation_price": inv_price_value, "invalidation_distance_pct": invalidation_distance_pct})
        return {"created": True, "run_id": run_id, "items": items}
