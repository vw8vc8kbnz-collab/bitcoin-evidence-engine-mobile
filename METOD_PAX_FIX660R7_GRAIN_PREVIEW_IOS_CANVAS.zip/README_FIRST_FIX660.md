# METOD/PAX FIX660 Grain Studio

Huidige revisie in dit pakket: **FIX660R7_MOBILE_PREVIEW_CANVAS**.

Lees eerst `README_FIRST_FIX660R7.md` en `TECHNISCHE_OVERDRACHT_FIX660R7.md`.

De FIX660-familie behoudt de bestaande productie-, pricing-, library-, security- en infrastructuurcontracten. R7 corrigeert uitsluitend de mobiele preview-canvaslayout/rendertrigger bovenop de in R6 herstelde Grain Bridge en compacte editor.
