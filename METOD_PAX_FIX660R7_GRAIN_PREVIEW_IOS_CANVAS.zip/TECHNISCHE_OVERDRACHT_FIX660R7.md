# TECHNISCHE OVERDRACHT — FIX660R7 MOBILE GRAIN PREVIEW CANVAS

## Baseline
FIX660R7 is een chirurgische patch op de exact gehashte FIX660R6 live baseline. De familie blijft `FIX660_GRAIN_STUDIO`; de UI-revisie is `FIX660R7_MOBILE_PREVIEW_CANVAS`.

## Live feedback / root cause
Na FIX660R6 werden groep G01, 2 panelen, 197 mm breed en 1594 mm totaal correct opgelost. De inhoud van de preview bleef op iOS echter leeg. Daarmee waren bridge, selectedGroupId en paneelresolutie aantoonbaar goed. De resterende fout zat in de viewport/renderlaag: `#grainPreview` stond mobiel op `height:auto/min-height:0` als flexkind in een getransformeerde fixed drawer. iOS Safari kan die combinatie met een nulhoogte meten/clippen. De samenvatting werd vóór canvascreatie bijgewerkt, waardoor een correcte summary boven een leeg wit vlak ontstond.

## R7-contract
1. `ToolAGrainStudioRenderer.prepareHost(container)` meet de parent drawer en reserveert een expliciete mobiele hosthoogte vóór `canvasSize()`.
2. CSS zet de drawer expliciet op flex-column en geeft `#grainPreview` een niet-collapsende fallbackhoogte van 280–520px.
3. Mobiele drawer opent eerst, daarna renderen we na twee RAFs; na `transitionend(transform)` renderen we opnieuw en er is een 340ms fallback.
4. ResizeObserver observeert zowel `#grainPreview` als `.grainPreviewCard`.
5. DPR blijft maximaal 2; de echte mm-verhoudingen en één uniforme groepsschaal blijven behouden.
6. `g.items` blijft BOTTOM→TOP: index 0/positie 1 is fysiek onderaan.
7. Exacte `widthMm` blijft hard verplicht.
8. Materials/CNC worden via de bestaande FIX659 swatch- en DXF-contracten getekend.

## Nieuwe regressietest
Een headless Node canvas/DOM mock start expres met een mobiele `grainPreview`-host van 0px hoogte, een drawer van 520px en G01 met 197×797 + 197×797. R7 moet de host naar 400px pinnen, een 700×800 backing canvas maken (DPR capped op 2), werkelijk pixels tekenen en de summary `G01 / 197 mm / 1594 mm` behouden.

## Deploy
`INSTALL_FIX660R7_FROM_STAGE.sh` accepteert uitsluitend de exact gehashte FIX660R6 UI-baseline of een idempotente exacte R7-doelbuild. Preflight/tests/backups vinden plaats vóór de live switch; rollback blijft actief.
