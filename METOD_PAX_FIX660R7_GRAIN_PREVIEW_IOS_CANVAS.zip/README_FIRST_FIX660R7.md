# METOD/PAX FIX660R7 — Mobile Grain Preview Canvas

Doel van R7: de Grain Studio preview op iOS/mobile daadwerkelijk zichtbaar renderen, zonder de in R6 herstelde bridge, compacte editor, bottom-to-top volgorde of productiecontracten te wijzigen.

## Root cause
In FIX660R6 werkte groepsresolutie weer correct en werd G01 goed geselecteerd, maar de mobiele preview-host kon in iOS Safari binnen de getransformeerde fixed bottom drawer naar 0px effectieve hoogte collapsen. De renderer update daardoor wel de samenvatting, terwijl het canvas in een geclipte 0px host zat. Dit verklaart de live situatie waarin `G01 · 2 panelen · 197 mm · 1594 mm` zichtbaar was maar het paneelcanvas niet.

## Correctie
- mobiele preview-host krijgt vóór canvas sizing een expliciete hoogte uit de echte drawerhoogte;
- renderer gebruikt nooit meer alleen een flex remainder/`height:auto` als mobiele canvaswaarheid;
- drawer render vindt plaats na twee `requestAnimationFrame`s, na de transform transition en nogmaals met een 340ms fallback;
- ResizeObserver volgt zowel preview-host als drawer;
- canvas context/foutstatus faalt zichtbaar in plaats van stil;
- Grain Studio assets hebben cachebuster `v=660r7`.

## Niet gewijzigd
Pricing/mixed VAT, CSV-library/taxonomy, optimizer, submit-idempotency, security, materiaal-swatchcontract, exacte widthMm-regel en URL/poortarchitectuur blijven ongewijzigd.
