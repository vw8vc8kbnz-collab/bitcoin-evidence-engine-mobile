# METOD/PAX FIX657 — lees dit eerst

**Build:** `FIX657_PRODUCTION_HARDENING_VAT_TRUTH`  
**Basis:** de exact geverifieerde FIX656 golden build.

FIX657 combineert drie gerichte correcties zonder de geaccepteerde productielogica te
herschrijven:

1. **Plaatprijs-BTW is nu expliciet correct.** De website-CSV is autoritatief en de kolom
   `Prijs per plaat inclusief BTW` blijft exact de bruto verkoopprijs per plaat. Alleen
   kantenband, CNC, tekenwerk en transport krijgen daarna 21% BTW op hun Admin-prijs excl.
   BTW.
2. **Production hardening.** HTTPS-only origins, fail-closed productieconfig, Secure
   Admin-cookie, header-only jobtokens, kleinere requestlimieten, SSE-privacy en een
   loopback-only backend achter Nginx.
3. **Geen dubbele optimalisatie meer bij verzenden.** De finale aanvraag koppelt de reeds
   afgeronde/finalized berekening en is idempotent per parent-job.

## Heel belangrijk voor deploy

De ZIP bevat **geen echte credentials, geen website-CSV en geen runtime-orders/jobs**.
Een release-update moet de bestaande VPS-state behouden:

- `app/jobs/`
- `app/requests/`
- `app/queue/`
- `app/archive/`
- `app/backups/`
- `app/drafts/`
- `app/system/`
- `app/decor_media/`
- `app/material_library.json`
- `app/config/pricing_active.json`
- `app/config/pricing_versions/`
- `app/config/pricing_audit.jsonl`
- `app/embedded_dxfs/`
- `app/embedded_dxfs_manifest.json`

`DEPLOY_FIX657.sh` verwacht een echte HTTPS-host en een reeds bestaand certificaat. Het
script moet niet worden aangepast naar development/HTTP om deze gate te omzeilen.

Zie `FIX657_RELEASE_NOTES.txt`, `FIX657_TEST_REPORT.txt` en
`TECHNISCHE_OVERDRACHT_FIX657.md` voor de volledige contracten.
