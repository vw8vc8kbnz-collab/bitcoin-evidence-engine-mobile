#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="FIX657"
APP_DIR="${METOD_PAX_APP_DIR:-/opt/adzaagt/metod-pax}"
ENV_DIR="${METOD_PAX_ENV_DIR:-/etc/adzaagt/metod-pax}"
ENV_FILE="$ENV_DIR/metod-pax.env"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-$ENV_DIR/admin_credentials.live.json}"
SERVICE_FILE="/etc/systemd/system/metod-pax.service"
NGINX_SITE="/etc/nginx/sites-available/metod-pax-https"
NGINX_LINK="/etc/nginx/sites-enabled/metod-pax-https"
BACKUP_ROOT="${METOD_CONFIG_BACKUP_ROOT:-/var/backups/metod-pax}"
PUBLIC_ORIGIN="${PUBLIC_ORIGIN:-}"
ADMIN_ORIGIN="${ADMIN_ORIGIN:-${PUBLIC_ORIGIN:-}}"
TLS_CERT_FILE="${TLS_CERT_FILE:-}"
TLS_KEY_FILE="${TLS_KEY_FILE:-}"

fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }
info(){ echo "[$VERSION] $*"; }

[[ "$EUID" -eq 0 ]] || fail "Voer DEPLOY_FIX657.sh met sudo/root uit."
for cmd in python3 nginx systemctl rsync curl grep sha256sum; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
[[ -d "$APP_DIR/app" ]] || fail "APP_DIR ontbreekt: $APP_DIR"
[[ -n "$PUBLIC_ORIGIN" ]] || fail "PUBLIC_ORIGIN is verplicht, bijvoorbeeld https://tool.example.nl"
[[ -n "$ADMIN_ORIGIN" ]] || fail "ADMIN_ORIGIN is verplicht"
[[ -n "$TLS_CERT_FILE" && -f "$TLS_CERT_FILE" && -r "$TLS_CERT_FILE" ]] || fail "TLS_CERT_FILE ontbreekt/onleesbaar"
[[ -n "$TLS_KEY_FILE" && -f "$TLS_KEY_FILE" && -r "$TLS_KEY_FILE" ]] || fail "TLS_KEY_FILE ontbreekt/onleesbaar"
[[ -f "$CREDS_FILE" && -r "$CREDS_FILE" ]] || fail "Bestaande hash-only Admin credentials ontbreken: $CREDS_FILE"

readarray -t ORIGIN_INFO < <(python3 - "$PUBLIC_ORIGIN" "$ADMIN_ORIGIN" <<'PY'
import sys
from urllib.parse import urlparse
out=[]
for label, raw in [('PUBLIC_ORIGIN',sys.argv[1]),('ADMIN_ORIGIN',sys.argv[2])]:
    u=urlparse(raw)
    if u.scheme.lower()!='https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ('','/') or '*' in raw:
        raise SystemExit(f'{label} moet exact een HTTPS-origin zijn zonder pad/query/wildcard: {raw!r}')
    if u.port not in (None,443):
        raise SystemExit(f'{label} gebruikt een niet-standaard HTTPS-poort; FIX657 accepteert alleen 443')
    out.append(f'{u.scheme.lower()}://{u.hostname.lower()}')
print(out[0]); print(out[1]); print(urlparse(out[0]).hostname)
PY
) || fail "Ongeldige productie-origin"
PUBLIC_ORIGIN="${ORIGIN_INFO[0]}"
ADMIN_ORIGIN="${ORIGIN_INFO[1]}"
SERVER_NAME="${ORIGIN_INFO[2]}"

# Credentials must be private and hash-only before any config/service change.
python3 - "$CREDS_FILE" "$APP_DIR" <<'PY'
import json, os, sys
from pathlib import Path
p=Path(sys.argv[1]); app=Path(sys.argv[2]).resolve(); rp=p.resolve()
if rp==app or app in rp.parents: raise SystemExit('Admin credentials mogen niet in APP_DIR staan')
obj=json.loads(p.read_text(encoding='utf-8'))
h=str(obj.get('password_hash') or '')
if not h.startswith('pbkdf2_sha256$') or str(obj.get('password') or '').strip():
    raise SystemExit('Admin credentials moeten hash-only PBKDF2-SHA256 zijn')
if os.name!='nt' and (p.stat().st_mode & 0o777)!=0o600:
    raise SystemExit(f'Admin credentials permissies moeten 0600 zijn, nu {oct(p.stat().st_mode & 0o777)}')
print('Admin credentials contract OK.')
PY

TS="$(date +%Y%m%d_%H%M%S)"
CFG_BACKUP="$BACKUP_ROOT/${VERSION}_$TS"
mkdir -p "$CFG_BACKUP" "$ENV_DIR"
for f in "$ENV_FILE" "$SERVICE_FILE" "$NGINX_SITE" /etc/nginx/sites-available/metod-pax-8790; do
  if [[ -e "$f" ]]; then cp -a "$f" "$CFG_BACKUP/$(echo "$f" | sed 's#/#__#g')"; fi
done
info "Externe configbackup: $CFG_BACKUP"

# Preserve the four Admin business-cost values from the existing live config exactly;
# only remove the obsolete general material factor and mark the mixed-VAT model.
python3 - "$APP_DIR/app/config/pricing_active.json" <<'PY'
import json, os, sys
p=sys.argv[1]
try: obj=json.load(open(p,encoding='utf-8'))
except Exception: obj={}
if not isinstance(obj,dict): obj={}
sp=obj.get('sellPricing') if isinstance(obj.get('sellPricing'),dict) else {}
sp.pop('sheetPriceFactor',None)
for key,default in (('edgeBandPricePerM',4.5),('cncCostPerSheet',0.0),('drawingCostFixed',0.0),('transportCostFixed',0.0)):
    try: sp[key]=float(sp[key]) if key in sp and sp[key] is not None else float(default)
    except Exception: sp[key]=float(default)
obj['sellPricing']=sp
obj['pricingModel']='catalog_sell_price_incl_vat_v2'
tmp=p+'.fix657.tmp'
with open(tmp,'w',encoding='utf-8') as f:
    json.dump(obj,f,ensure_ascii=False,indent=2); f.flush(); os.fsync(f.fileno())
os.replace(tmp,p)
print('Pricingcontract genormaliseerd: plaat=CSV incl. BTW; overige Admin-kosten excl. BTW.')
PY

# Keep the existing published CSV catalog; quarantine only legacy/non-CSV active records.
mkdir -p "$APP_DIR/app/system/catalog_legacy_archive" "$APP_DIR/app/system/catalog_imports/history" "$APP_DIR/app/decor_media" "$APP_DIR/app/backups"
python3 "$APP_DIR/tools/fix652_catalog_only_migrate.py" \
  --library "$APP_DIR/app/material_library.json" \
  --archive-dir "$APP_DIR/app/system/catalog_legacy_archive" \
  --registry "$APP_DIR/app/system/catalog_public_ids.json"
python3 "$APP_DIR/tools/fix654_prepare_catalog_media.py" --app-dir "$APP_DIR/app" || true

# Write production runtime config atomically. Backend remains loopback-only in source.
ENV_TMP="$ENV_FILE.tmp.$TS"
cat > "$ENV_TMP" <<EOF
METOD_PORT=8792
PRODUCTION_HARDENING=1
ADMIN_HASH_ONLY=1
APP_ENV=production
ADMIN_CREDENTIALS_FILE=$CREDS_FILE
ADMIN_STAGING_OPEN=0
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
PUBLIC_JSON_MAX_BYTES=16777216
SUBMIT_MAX_BYTES=8388608
PUBLIC_DXF_BLOB_MAX_BYTES=2097152
PUBLIC_JOB_TOTAL_QTY_LIMIT=250
PUBLIC_JOB_MAX_AREA_LB=250
JOB_OUTPUT_MAX_BYTES=536870912
CATALOG_IMAGE_WORKERS=4
ALLOWED_ORIGINS=$PUBLIC_ORIGIN
ALLOWED_ADMIN_ORIGINS=$ADMIN_ORIGIN
EOF
chmod 0640 "$ENV_TMP"
mv "$ENV_TMP" "$ENV_FILE"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=METOD PAX Tool FIX657
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR/app
EnvironmentFile=$ENV_FILE
ExecStart=/usr/bin/python3 $APP_DIR/app/server_py.py
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
UMask=0027

[Install]
WantedBy=multi-user.target
EOF

cat > "$NGINX_SITE" <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name $SERVER_NAME;
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $SERVER_NAME;

    ssl_certificate $TLS_CERT_FILE;
    ssl_certificate_key $TLS_KEY_FILE;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_session_cache shared:METODSSL:10m;
    ssl_session_timeout 10m;

    client_max_body_size 20m;

    location / {
        proxy_pass http://127.0.0.1:8792;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Forwarded-Host \$host;
        proxy_set_header X-Forwarded-Port 443;
        proxy_connect_timeout 30s;
        proxy_send_timeout 1800s;
        proxy_read_timeout 1800s;
        proxy_buffering off;
    }
}
EOF
ln -sfn "$NGINX_SITE" "$NGINX_LINK"
# Retire the old public HTTP acceptance listener on :8790.
rm -f /etc/nginx/sites-enabled/metod-pax-8790

# Release integrity / static contracts before restart.
python3 -m py_compile "$APP_DIR"/app/*.py "$APP_DIR"/tools/*.py
bash -n "$APP_DIR/DEPLOY_FIX657.sh"
python3 "$APP_DIR/tools/fix657_regression.py"
APP_DIR="$APP_DIR" METOD_ENV_FILE="$ENV_FILE" python3 "$APP_DIR/tools/final_preflight.py"
nginx -t

systemctl daemon-reload
systemctl enable metod-pax.service >/dev/null
systemctl restart metod-pax.service
systemctl reload nginx
sleep 2
systemctl is-active --quiet metod-pax.service || { journalctl -u metod-pax.service -n 80 --no-pager >&2; fail "metod-pax.service startte niet"; }

# Backend smoke is intentionally loopback-only; public smoke validates HTTPS + hostname.
TMP_HTML="$(mktemp)"; TMP_LIB="$(mktemp)"; TMP_HDR="$(mktemp)"
trap 'rm -f "$TMP_HTML" "$TMP_LIB" "$TMP_HDR"' EXIT
curl -fsS http://127.0.0.1:8792/toolA.html?v=657 -o "$TMP_HTML"
curl -fsS --compressed -D "$TMP_HDR" http://127.0.0.1:8792/api/materials/library -o "$TMP_LIB"
grep -Fq 'FIX657_PRODUCTION_HARDENING_VAT_TRUTH' "$TMP_HTML"
grep -Fq 'decor_library.js?v=657' "$TMP_HTML"
python3 - "$TMP_LIB" "$APP_DIR/app/material_library.json" <<'PY'
import json,re,sys
pub=json.load(open(sys.argv[1],encoding='utf-8')); internal=json.load(open(sys.argv[2],encoding='utf-8'))
assert pub.get('ok') is True
records=pub.get('records') or []; active=internal.get('records') or []
assert internal.get('source')=='CSV_CATALOG_ONLY'
assert len(records)==len(active),(len(records),len(active))
allowed={'publicMaterialId','publicName','brand','decorType','visualFamily','visualTags','colorGroup','searchTags','thicknessMm','sheetSizeMm','hasGrain','grainDefaultOn','active','published','isPopular','isNew','imageAvailable','imageThumbUrl','imagePreviewUrl'}
for r in records:
    assert set(r).issubset(allowed), set(r)-allowed
    assert re.fullmatch(r'decor_[a-f0-9]{20,40}',str(r.get('publicMaterialId') or ''))
    assert float(r.get('thicknessMm') or 0) in (18.0,19.0,20.0)
forbidden={'articleNumber','articleNo','materialCode','purchasePrice','purchasePricePerSheet','supplier','supplierName','leverancier','imageSourceUrl','imageSourceUrls','sellPriceInclVatPerSheet','sellPriceExVatPerSheet'}
assert not any(forbidden.intersection(r) for r in records)
print(f'Publieke library privacy OK: {len(records)} records.')
PY

# Use --resolve so certificate hostname is verified against the production host while
# testing locally on the VPS, independent of DNS propagation/caching.
curl --fail --silent --show-error --resolve "$SERVER_NAME:443:127.0.0.1" "$PUBLIC_ORIGIN/toolA.html?v=657" -o /dev/null
curl --fail --silent --show-error --resolve "$SERVER_NAME:443:127.0.0.1" "$PUBLIC_ORIGIN/api/materials/library" -o /dev/null

info "ACTIEF en productie-preflight geslaagd."
info "Tool A: $PUBLIC_ORIGIN/toolA.html?v=657"
info "Admin:  $ADMIN_ORIGIN/admin/?v=657"
