#!/usr/bin/env python3
"""Deterministic FIX657 regression checks (no network, no live-state mutation)."""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import queue
import sys
import tempfile
from pathlib import Path

RELEASE_ROOT = Path(__file__).resolve().parents[1]
APP = RELEASE_ROOT / 'app'
sys.path.insert(0, str(APP))

import catalog_importer
import pricing_helpers
import server_helpers


def load_server():
    spec = importlib.util.spec_from_file_location('fix657_server_regression', APP / 'server_py.py')
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def check(condition: bool, label: str) -> None:
    if not condition:
        raise AssertionError(label)
    print('PASS:', label)


def csv_fixture() -> str:
    headers = ','.join(f'""{x}""' for x in catalog_importer.EXPECTED_HEADERS)
    row = ','.join([
        'TEST001',
        '""https://example.invalid/test-panel-2440x1220x18mm.jpg""',
        '""Test plaat""',
        '""18""',
        '""2440""',
        '""1220""',
        '""69.57""',
    ])
    return f'"{headers}"\n"{row}"\n'


def test_catalog_parser(optional_csv: Path | None = None) -> None:
    parsed = catalog_importer.parse_catalog_csv(csv_fixture())
    check(parsed.get('summary', {}).get('blockingErrors') == 0, 'synthetic website CSV accepted')
    rec = (parsed.get('records') or [None])[0]
    check(isinstance(rec, dict), 'synthetic catalog record created')
    check(rec.get('sellPriceInclVatPerSheet') == 69.57, 'CSV gross sheet cents preserved exactly')
    check(rec.get('priceSource') == 'CSV_SALE_PRICE_INCL_VAT', 'CSV price basis marked incl-VAT')
    if optional_csv:
        text = optional_csv.read_text(encoding='utf-8-sig')
        real = catalog_importer.parse_catalog_csv(text)
        summary = real.get('summary') or {}
        check(summary.get('blockingErrors') == 0, 'provided current CSV has no blocking import errors')
        check(int(summary.get('eligible') or 0) > 0, 'provided current CSV contains eligible 18/19/20 mm records')
        records = real.get('records') or []
        check(bool(records) and all(float(r.get('sellPriceInclVatPerSheet') or 0) > 0 for r in records), 'every eligible CSV record has gross sheet price')
        check(any(abs(float(r.get('sellPriceInclVatPerSheet') or 0) - 69.57) < 1e-9 for r in records), 'provided current CSV preserves the observed EUR 69.57 sheet price as gross')
        print('INFO: current CSV summary', json.dumps(summary, ensure_ascii=False, sort_keys=True))


def test_material_mapping(server) -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        (root / 'material_library.json').write_text(json.dumps({
            'source': 'CSV_CATALOG_ONLY',
            'records': [{
                'articleNo': 'TEST001',
                'sourceKind': 'CATALOG_IMPORT',
                'active': True,
                'archived': False,
                'published': True,
                'catalogExcluded': False,
                'thicknessMm': 18,
                'sheetWid': 1220,
                'sheetLen': 2440,
                'productName': 'Test plaat',
                'sellPriceInclVatPerSheet': 69.57,
                'priceSource': 'CSV_SALE_PRICE_INCL_VAT',
            }],
        }), encoding='utf-8')
        old_root = server.ROOT
        server.ROOT = root
        try:
            pricing = {'defaults': {}}
            out = server._ensure_pricing_materials(
                pricing,
                'PartId;MaterialCode;ThicknessMm;LengthMm;WidthMm;Qty;H1;H2;W1;W2\nP1;TEST001;18;500;500;1;0;0;0;0\n',
            )
        finally:
            server.ROOT = old_root
        mat = out['materials'][0]
        check(mat['sellPriceInclVatPerSheet'] == 69.57, 'pricing material keeps exact gross CSV price')
        check(abs(mat['purchasePricePerSheet'] - (69.57 / 1.21)) < 1e-9, 'legacy optimizer field is accounting net equivalent only')
        check(mat['materialPriceBasis'] == 'CSV_SELL_PRICE_INCL_VAT', 'material basis explicit in pricing payload')


def test_mixed_vat_quote(server) -> None:
    original = server._load_pricing_config
    server._load_pricing_config = lambda: {'sellPricing': {
        'edgeBandPricePerM': 4.5,
        'cncCostPerSheet': 10.0,
        'drawingCostFixed': 20.0,
        'transportCostFixed': 30.0,
    }}
    try:
        quote = {
            'materials': [{
                'materialCode': 'TEST001', 'thicknessMm': 18, 'sheetCount': 1,
                'sheetUnitCost': 69.57 / 1.21,
                'sellPriceExVatPerSheet': 69.57 / 1.21,
                'sellPriceInclVatPerSheet': 69.57,
            }],
            'edgeBanding': {'byCodeMetersWithLoss': {'1': 2.0}},
            'totals': {},
        }
        out = server._apply_sell_pricing_to_quote(quote)
    finally:
        server._load_pricing_config = original
    totals = out['totals']
    check(out['materials'][0]['sheetCostTotalInclVat'] == 69.57, 'one sheet remains EUR 69.57 incl-VAT')
    check(totals['sheetCostTotalInclVat'] == 69.57, 'material total is gross CSV truth')
    check(totals['otherCostsExVat'] == 69.00, 'other Admin costs remain ex-VAT')
    check(totals['otherCostsVat'] == 14.49, '21% VAT is added only to other costs')
    check(totals['totalInclVat'] == 153.06, 'mixed VAT final total is exact')


def test_summary_parser() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        (root / 'calculation_summary.txt').write_text(
            'Kostenopbouw\n----------------------------------------\n'
            'Plaatmateriaal incl. btw: €69,57\n'
            'Kantenband excl. btw:      €9,00\n'
            'CNC excl. btw:             €10,00\n'
            'Tekenen excl. btw:         €20,00\n'
            'Transport excl. btw:       €30,00\n\n'
            'Fiscale uitsplitsing\n----------------------------------------\n'
            'Plaatmateriaal netto-equivalent: €57,50\n'
            'BTW reeds in plaatprijs:          €12,07\n'
            'Overige kosten excl. btw:         €69,00\n'
            'BTW over overige kosten:          €14,49\n'
            'Subtotaal excl. btw: €126,50\n'
            'BTW (21%):          €26,56\n'
            'Totaal incl. btw:    €153,06\n',
            encoding='utf-8',
        )
        parsed = pricing_helpers.parse_calculation_summary_totals(root)
    expected = {
        'materialsTotalInclVat': 69.57, 'materialsTotal': 57.50,
        'materialsVatIncluded': 12.07, 'edgeBandTotal': 9.0, 'cncTotal': 10.0,
        'drawingTotal': 20.0, 'transportTotal': 30.0, 'otherCostsExVat': 69.0,
        'otherCostsVat': 14.49, 'subtotalExVat': 126.50, 'vatAmount': 26.56,
        'totalInclVat': 153.06,
    }
    check(parsed == expected, 'human summary parser retains full mixed-VAT breakdown')


class DummyHeaders(dict):
    def get(self, key, default=None):
        return super().get(key, default)


class DummyHandler:
    def __init__(self, headers=None):
        self.headers = DummyHeaders(headers or {})


def test_header_only_job_token() -> None:
    check(server_helpers.extract_request_token(DummyHandler({'Authorization': 'Bearer abc'})) == 'abc', 'Bearer job token accepted')
    check(server_helpers.extract_request_token(DummyHandler({'X-Job-Token': 'abc'})) == '', 'X-Job-Token retired')
    check(server_helpers.extract_request_token(DummyHandler({}), parsed='?token=abc', body={'accessToken': 'abc'}) == '', 'query/body job token rejected')


def test_sse_privacy(server) -> None:
    q = queue.Queue()
    server._SSE_CLIENTS[:] = [q]
    server._sse_broadcast('request_submitted', {'requestId': 'SECRET'})
    check(q.empty(), 'public SSE drops request lifecycle events')
    server._sse_broadcast('dxf_changed', {'dxfVersion': 'v123', 'category': 'private', 'filename': 'x.dxf'})
    item = q.get_nowait()
    check(item['event'] == 'dxf_changed', 'public SSE still carries DXF freshness')
    check(item['data'] == {'dxfVersion': 'v123'}, 'public SSE strips filename/category metadata')
    server._SSE_CLIENTS[:] = []


def test_queue_no_optimizer(server) -> None:
    src = (APP / 'server_py.py').read_text(encoding='utf-8')
    a = src.index('def process_one_queue_item')
    b = src.index('def _recover_processing_queue_items_fix657', a)
    check('_create_job_from_payload(' not in src[a:b], 'queue worker can no longer launch optimization')
    check('LEGACY_QUEUE_ITEM_REQUIRES_REVIEW' in src[a:b], 'unsafe legacy queue work fails closed')


def test_production_source_contract() -> None:
    src = (APP / 'server_py.py').read_text(encoding='utf-8')
    helper = (APP / 'server_helpers.py').read_text(encoding='utf-8')
    html = (APP / 'toolA.html').read_text(encoding='utf-8')
    check("_PUBLIC_SSE_EVENT_ALLOWLIST = frozenset({'dxf_changed'})" in src, 'SSE allowlist source contract')
    check("'; Secure' if _is_production_hardening_enabled()" in src, 'Secure admin cookie source contract')
    check('if production:\n                return False' in helper, 'Admin same-origin host fallback disabled in production')
    check('if _is_production_runtime():\n                    return False' in src, 'Public same-origin host fallback disabled in production')
    check("buildJobTokenHeaders(state?.lastJobAccessToken" in html, 'final submit transmits bearer header')
    check("sessionStorage.setItem('metod_last_job_access_token'" in html and "localStorage.setItem('metod_last_job_access_token'" not in html, 'job bearer token is session-scoped, not durable localStorage')



def test_submission_idempotency(server) -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        old_requests = server.REQUESTS
        old_markers = server.SUBMISSION_IDEMPOTENCY_DIR
        server.REQUESTS = root / 'requests'
        server.SUBMISSION_IDEMPOTENCY_DIR = root / 'markers'
        try:
            claimed, rid = server._reserve_submission_claim('job_parent_1', 'REQ_A')
            check(claimed and rid == 'REQ_A', 'first final submission atomically claims parent job')
            claimed2, rid2 = server._reserve_submission_claim('job_parent_1', 'REQ_B')
            check((not claimed2) and rid2 == 'REQ_A', 'duplicate final submission reuses existing claim instead of duplicating work')
            (server.REQUESTS / 'REQ_A').mkdir(parents=True, exist_ok=True)
            (server.REQUESTS / 'REQ_A' / 'status.json').write_text('{}', encoding='utf-8')
            check(server._read_submission_claim('job_parent_1') == 'REQ_A', 'submission claim survives after request status persistence')
        finally:
            server.REQUESTS = old_requests
            server.SUBMISSION_IDEMPOTENCY_DIR = old_markers


def test_production_runtime_guard(server) -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        creds = root / 'admin.json'
        # Structurally valid PBKDF2 record; no real credential is shipped or exposed.
        creds.write_text(json.dumps({'username':'admin','password_hash':'pbkdf2_sha256$260000$testsalt$' + ('a'*64)}), encoding='utf-8')
        os.chmod(creds, 0o600)
        keys = {
            'APP_ENV':'production', 'PRODUCTION_HARDENING':'1', 'ADMIN_HASH_ONLY':'1', 'ADMIN_STAGING_OPEN':'0',
            'ALLOWED_ORIGINS':'https://example.invalid', 'ALLOWED_ADMIN_ORIGINS':'https://example.invalid',
            'PUBLIC_JSON_MAX_BYTES':str(16*1024*1024), 'SUBMIT_MAX_BYTES':str(8*1024*1024),
            'PUBLIC_DXF_BLOB_MAX_BYTES':str(2*1024*1024), 'PUBLIC_JOB_MAX_CONCURRENT':'1',
            'PUBLIC_JOB_MAX_CONCURRENT_PER_IP':'1', 'ADMIN_CREDENTIALS_FILE':str(creds),
            'ADMIN_PASSWORD_RESET_ACTIVATION_FILE':str(root / 'reset-disabled.json'),
        }
        old = {k: os.environ.get(k) for k in keys}
        try:
            os.environ.update(keys)
            server._validate_production_runtime_or_die()
            check(True, 'production runtime guard accepts a fully hardened configuration')
        finally:
            for k, v in old.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--csv', type=Path, help='Optional real current CSV to validate without copying it into the release.')
    args = parser.parse_args()
    server = load_server()
    test_catalog_parser(args.csv)
    test_material_mapping(server)
    test_mixed_vat_quote(server)
    test_summary_parser()
    test_header_only_job_token()
    test_sse_privacy(server)
    test_queue_no_optimizer(server)
    test_submission_idempotency(server)
    test_production_runtime_guard(server)
    test_production_source_contract()
    print('\nFIX657 REGRESSION: PASS')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
