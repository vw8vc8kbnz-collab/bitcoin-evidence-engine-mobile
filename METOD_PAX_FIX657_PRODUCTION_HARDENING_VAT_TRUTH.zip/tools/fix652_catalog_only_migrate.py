#!/usr/bin/env python3
"""One-time safe migration to the FIX652 CSV-only active Decor Library.

The old library is never destroyed without a timestamped archive copy.  The active
material_library.json is then reduced to records that were already produced by a CSV
catalog import. Legacy/manual/seed records are not active anymore. Their opaque IDs are
kept in a private registry so future CSV imports can reuse stable public IDs when the
same article returns.
"""
from __future__ import annotations
import argparse, json, os, re, shutil, time
from pathlib import Path

PID_RE = re.compile(r'^decor_[a-f0-9]{20,40}$')
ALLOWED = {18.0, 19.0, 20.0}

def atomic_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--library', required=True)
    ap.add_argument('--archive-dir', required=True)
    ap.add_argument('--registry', required=True)
    args=ap.parse_args()
    libp=Path(args.library)
    archive=Path(args.archive_dir)
    registryp=Path(args.registry)
    archive.mkdir(parents=True, exist_ok=True)
    registryp.parent.mkdir(parents=True, exist_ok=True)

    if libp.exists():
        raw=json.loads(libp.read_text(encoding='utf-8'))
    else:
        raw={'source':'CSV_CATALOG_ONLY','records':[]}
    if isinstance(raw,list): raw={'source':'legacy','records':raw}
    if not isinstance(raw,dict): raise SystemExit('Ongeldige material_library.json')
    recs=raw.get('records') or []
    if not isinstance(recs,list): raise SystemExit('records is geen lijst')

    stamp=time.strftime('%Y%m%d_%H%M%S', time.localtime())
    backup=archive/f'pre_fix652_material_library_{stamp}.json'
    if libp.exists(): shutil.copy2(libp,backup)

    reg={}
    if registryp.exists():
        try:
            old=json.loads(registryp.read_text(encoding='utf-8'))
            vals=old.get('byArticle') if isinstance(old,dict) and isinstance(old.get('byArticle'),dict) else old
            if isinstance(vals,dict):
                for k,v in vals.items():
                    if str(k).strip() and PID_RE.fullmatch(str(v).strip().lower()): reg[str(k).strip()]=str(v).strip().lower()
        except Exception: pass
    for r in recs:
        if not isinstance(r,dict): continue
        art=str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip()
        pid=str(r.get('publicMaterialId') or '').strip().lower()
        if art and PID_RE.fullmatch(pid): reg.setdefault(art,pid)

    active=[]
    for r in recs:
        if not isinstance(r,dict) or str(r.get('sourceKind') or '').upper()!='CATALOG_IMPORT': continue
        if r.get('catalogMissing') is True or r.get('catalogExcluded') is True: continue
        try: t=float(r.get('thicknessMm') or r.get('thickness') or 0)
        except Exception: continue
        if t not in ALLOWED: continue
        rr=dict(r)
        rr['active']=True; rr['published']=True; rr['archived']=False
        rr['catalogMissing']=False; rr['catalogExcluded']=False; rr['sourceKind']='CATALOG_IMPORT'
        active.append(rr)

    last=raw.get('lastCatalogImport') if active and isinstance(raw.get('lastCatalogImport'),dict) else None
    out={
        'source':'CSV_CATALOG_ONLY',
        'pricingModel':'catalog_sell_price_incl_vat_v2',
        'decorLibrarySchemaVersion':3,
        'records':active,
        'recordCountOriginal':len(active),
        'recordCountFiltered':len(active),
    }
    if last: out['lastCatalogImport']=last
    atomic_json(libp,out)
    atomic_json(registryp,{'schemaVersion':1,'updatedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'byArticle':dict(sorted(reg.items()))})
    print(json.dumps({'ok':True,'archivedTo':str(backup),'oldRecords':len(recs),'activeCsvRecords':len(active),'quarantined':len(recs)-len(active),'registryIds':len(reg)},ensure_ascii=False))
    return 0

if __name__=='__main__': raise SystemExit(main())
