#!/usr/bin/env python3
"""FIX654 one-time/catalog-cache preparation.

Build lightweight local Tool A image variants from already cached, sanitized catalog
images. This performs no network requests and never changes the active catalog records.
It is safe to re-run: prepared current images are skipped.
"""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--app-dir', required=True)
    args = ap.parse_args()
    app = Path(args.app_dir).resolve()
    sys.path.insert(0, str(app))
    import catalog_importer as ci

    lib_path = app / 'material_library.json'
    media_root = app / 'decor_media'
    try:
        lib = json.loads(lib_path.read_text(encoding='utf-8'))
    except Exception as e:
        print(f'FIX654 media prep: library unreadable: {e}', file=sys.stderr)
        return 2
    records = lib.get('records') if isinstance(lib, dict) else []
    if not isinstance(records, list):
        print('FIX654 media prep: invalid records list', file=sys.stderr)
        return 2

    stats = {'eligible': 0, 'alreadyPrepared': 0, 'preparedWebp': 0, 'rawFallback': 0, 'missingCache': 0, 'errors': 0}
    for rec in records:
        if not isinstance(rec, dict):
            continue
        if str(rec.get('sourceKind') or '').upper() != 'CATALOG_IMPORT':
            continue
        if rec.get('active') is False or rec.get('published') is False or rec.get('archived') is True or rec.get('catalogMissing') is True or rec.get('catalogExcluded') is True:
            continue
        pid = str(rec.get('publicMaterialId') or '').strip().lower()
        if not pid.startswith('decor_'):
            continue
        stats['eligible'] += 1
        folder = media_root / pid
        raw = folder / 'catalog.img'
        meta_path = folder / 'catalog.meta.json'
        if not raw.exists() or not meta_path.exists():
            stats['missingCache'] += 1
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding='utf-8') or '{}')
        except Exception:
            meta = {}
        variants = meta.get('variants') if isinstance(meta.get('variants'), dict) else {}
        if (folder / 'thumb.webp').exists() and (folder / 'preview.webp').exists() and 'thumb.webp' in variants and 'preview.webp' in variants:
            stats['alreadyPrepared'] += 1
            continue
        try:
            data = raw.read_bytes()
            mime = str(meta.get('mime') or '').strip().lower()
            if mime not in ('image/jpeg', 'image/png', 'image/webp'):
                mime = ci._detect_image_type(data)
            payload = {
                'data': data,
                'mime': mime,
                'sha256': hashlib.sha256(data).hexdigest(),
                'bytes': len(data),
            }
            out = ci.atomic_write_cached_image(folder, payload)
            if out.get('variantGenerator') == 'pillow-webp' and (folder / 'thumb.webp').exists() and (folder / 'preview.webp').exists():
                stats['preparedWebp'] += 1
            else:
                stats['rawFallback'] += 1
        except Exception as e:
            stats['errors'] += 1
            print(f'WARN {pid}: {e}', file=sys.stderr)

    print('FIX654 catalog media prep:', json.dumps(stats, ensure_ascii=False, sort_keys=True))
    # Missing caches are not deployment failures: the next Admin CSV preview can fetch them.
    # Actual conversion errors are surfaced but also remain non-fatal because catalog.img is
    # still the safe functional fallback.
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
