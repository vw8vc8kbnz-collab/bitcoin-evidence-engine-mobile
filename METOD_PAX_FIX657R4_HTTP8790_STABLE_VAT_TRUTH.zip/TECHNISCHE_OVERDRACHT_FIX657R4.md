# METOD/PAX — TECHNISCHE OVERDRACHT FIX657R4

## 1. Status in one sentence

FIX657R4 is the stable same-URL release on top of the exact FIX656 golden functional
baseline: it fixes the CSV sheet-price VAT truth, makes final submit idempotent/link-only,
retains application hardening, and deliberately keeps Tool A at
`http://51.195.102.180:8790/`.

## 2. Why R2 was necessary

FIX656 was functionally golden but not production-hardened. FIX657 fixed the relevant
application/security surfaces and the reported VAT ambiguity/bug, but its deploy contract
also forced an HTTPS migration. FIX657R1 attempted IP-certificate bootstrap. That attempt
successfully reached certificate creation but the wrapper then failed its TLS-file gate
and exited before the live application switch. A subsequent operator check proved the
old runtime remained healthy:

- `http://127.0.0.1:8790/` -> HTTP 200
- `metod-pax.service` -> active
- backend -> `127.0.0.1:8792`
- nginx -> public `0.0.0.0:8790` and `[::]:8790`

R2 therefore separates application stabilization from transport migration.

## 3. Golden baseline and non-negotiable invariants

Do not regress these contracts:

1. FIX656 is the functional baseline.
2. Decor Library has one active source: last Admin-reviewed/published website CSV.
3. Active thicknesses are only 18/19/20 mm.
4. CSV publish is exact replacement.
5. Internal article numbers never enter public Tool A/API/DOM/errors/downloads.
6. Public material IDs are opaque `decor_<hex>` IDs backed by a private stable registry.
7. Optimizer primary objective is minimum sheet count.
8. Performance shortcuts may not add a sheet.
9. Grain/composite constraints remain authoritative.
10. `returncode == 0` is not completion; finalization.json must be COMPLETE and all
    required production outputs must exist.
11. Runtime state is preserved on updates.

## 4. Price model — authoritative contract

The current website CSV explicitly labels its field:

`Prijs per plaat inclusief BTW`

That field is the business truth.

For each active material the internal catalog keeps:
- `sellPriceInclVatPerSheet`: exact CSV gross price.
- `sellPriceExVatPerSheet`: derived accounting value where needed.
- `purchasePricePerSheet`: legacy optimizer compatibility net equivalent only.
- `priceSource = CSV_SALE_PRICE_INCL_VAT`.

The quote model is mixed VAT:

`totalInclVat = sheetMaterialInclVat + otherCostsExVat + 0.21 * otherCostsExVat`

where `otherCostsExVat` contains edge banding + CNC + drawing + transport.

Do NOT multiply the CSV sheet price by 1.21. Do NOT reintroduce a global material factor.

Concrete regression:
- sheet gross = 69.57
- other costs ex VAT = 69.00
- other VAT = 14.49
- total incl VAT = 153.06

## 5. Submit / worker architecture

FIX657/R2 changes the old double-work behavior.

### Calculation
`POST /api/jobs`
- validates payload
- creates parent/subjobs
- runs optimizer
- produces required files
- finalizes job
- returns parent job identity + bearer access token

### Final request
`POST /api/submit_config`
- requires `Authorization: Bearer <parent-job-token>`
- verifies the referenced parent job
- requires `finalization.json` COMPLETE
- derives subjobs server-side
- reserves an atomic idempotency claim per parent job
- persists/links the final request
- does not call optimizer again

### Queue
The queue worker is link/status processing only. It may not call
`_create_job_from_payload()` for new final submissions. Legacy unsafe queue items fail
closed with `LEGACY_QUEUE_ITEM_REQUIRES_REVIEW`.

## 6. Security contracts retained

### Public job access token
Canonical transport only:
`Authorization: Bearer <token>`

Rejected/retired:
- `X-Job-Token`
- `?token=`
- JSON/body `accessToken`

Tool A stores the current token in `sessionStorage`, not persistent `localStorage`.

### Public SSE
`/api/events` is public, therefore its allowlist is deliberately tiny:
- allowed event: `dxf_changed`
- allowed payload: `dxfVersion`

No request IDs, order status, filename/category metadata or technical errors.

### Admin
- external credentials file
- PBKDF2-SHA256 hash only
- file mode 0600
- no plaintext password in live credentials
- Admin staging-open disabled
- production Host-header fallback disabled
- exact origin/referer validation for writes

## 7. FIX657R4 HTTP compatibility bridge

The application is still in production hardening mode. R2 does NOT simply turn hardening
off. Instead it introduces two explicit runtime values:

`LEGACY_HTTP_COMPAT=1`
`LEGACY_HTTP_ORIGIN=http://51.195.102.180:8790`

Both public and Admin allowlists must contain exactly that one origin in this mode.
Startup fails closed if a different HTTP origin is configured.

Admin login transport over the bridge is accepted only if:
- direct TCP peer is in `TRUSTED_PROXY_IPS` (default live value: loopback only),
- `X-Forwarded-Proto == http`,
- `X-Forwarded-Host == 51.195.102.180:8790`.

The public Nginx listener sets those headers. A direct remote backend connection is
impossible in the intended layout because Python binds only `127.0.0.1:8792`.

The Admin session cookie sets `Secure` only when the actual trusted-proxy transport is
HTTPS. On the current HTTP bridge it remains HttpOnly + SameSite=Lax but non-Secure, which
is required for browser compatibility on HTTP.

This is a transitional compatibility profile, not a claim that HTTP is encrypted.

## 8. Network topology after successful R2 deploy

Exactly:

- Browser URL: `http://51.195.102.180:8790/`
- Admin URL: `http://51.195.102.180:8790/admin/`
- Nginx public listener: `0.0.0.0:8790` + `[::]:8790`
- Nginx upstream: `http://127.0.0.1:8792`
- Python server: `127.0.0.1:8792`

No TLS variables are required for R2.

## 9. What happens to FIX657R1 leftovers

R1 may have left:
- `/etc/nginx/sites-available/metod-pax-acme-ip`
- `/etc/nginx/sites-enabled/metod-pax-acme-ip`
- `metod-pax-certbot-renew.service`
- `metod-pax-certbot-renew.timer`
- a Certbot venv/symlink
- certificate material under `/etc/letsencrypt`

R2 backs up the R1-specific Nginx/systemd files first, then disables/removes only the
METOD/PAX R1 site/timer/service so they cannot create confusing background behavior.
R2 deliberately leaves the certificate files and Certbot environment alone. It also does
not reverse generic firewall changes because those could affect other VPS services.

## 10. State-preserving deployment

The outer installer:
1. validates the currently running :8790 and :8792 services before touching files;
2. verifies release SHA256SUMS;
3. rejects CSV/bak/pyc/cache contamination in the staged release;
4. runs Python/JS/bash/regression/preflight checks;
5. makes a full copy of `/opt/adzaagt/metod-pax`;
6. creates a tar of external env/systemd/Nginx state;
7. rsyncs the release while excluding runtime state;
8. runs `DEPLOY_FIX657R4.sh`;
9. smoke-tests backend + unchanged :8790 proxy + privacy/origin behavior;
10. automatically rolls back app/config if anything fails after live touch.

State exclusions during rsync:
- app/jobs/
- app/requests/
- app/queue/
- app/archive/
- app/backups/
- app/drafts/
- app/system/
- app/decor_media/
- app/material_library.json
- app/config/pricing_active.json
- app/config/pricing_versions/
- app/config/pricing_audit.jsonl
- app/embedded_dxfs/
- app/embedded_dxfs_manifest.json

## 11. Current CSV test evidence

The user-supplied current CSV was analyzed directly during R2 build validation. It is not
included in the ZIP.

Result:
- 606 rows read
- 597 eligible records
- 9 excluded because thickness is not 18/19/20
- 0 blocking errors
- 18 warnings
- EUR 69.57 observed and retained exactly as gross sheet price

## 12. Regression / acceptance gates

Before accepting R2 live, require all of these:

- installer prints `FIX657R4 ACTIEF en alle checks groen.`
- service active
- nginx -t green
- `http://51.195.102.180:8790/` opens Tool A
- build marker is R2
- current CSV catalog still populated
- material selection still works
- one known material calculation proves gross sheet price is not taxed again
- calculate one real/simple test job
- verify report/quote/finalization outputs
- submit once, then ensure a duplicate click does not trigger a second optimizer run
- Admin login works through the existing URL
- Admin catalog/pricing pages still show the expected live values

## 13. Deferred work

HTTPS is still recommended because HTTP does not protect credentials/session/data in
transit. It must be done as a separate transport migration after R2 is functionally
accepted. Do not combine that future TLS migration with optimizer/pricing/catalog rewrites.

## 14. Files to use

Live deploy entry point:
`INSTALL_FIX657R4_FROM_STAGE.sh`

Inner deploy:
`DEPLOY_FIX657R4.sh`

Regression:
`tools/fix657r4_regression.py`

Preflight:
`tools/final_preflight.py`

Build marker:
`FIX657R4_HTTP8790_STABLE_VAT_TRUTH`


## FIX657R4 deployment correction
The first FIX657R2 VPS attempt stopped safely during the staged preflight with `Permission denied` on `/etc/adzaagt/metod-pax/admin_credentials.live.json`. That is an installer privilege bug, not a credentials defect: the live credential is intentionally root-only chmod 0600. FIX657R4 keeps 0600 intact, validates root readability, and executes only the staged production preflight via `sudo env`. This still happens before `LIVE_TOUCHED=1`, so failure cannot partially replace the live app.
