#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/adzaagt/metod-pax"
ENV_DIR="/etc/adzaagt/metod-pax"
ENV_FILE="$ENV_DIR/metod-pax.env"
SERVICE_FILE="/etc/systemd/system/metod-pax.service"
NGINX_SITE="/etc/nginx/sites-available/metod-pax-8790"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Voer dit script met sudo uit." >&2
  exit 1
fi

mkdir -p "$ENV_DIR" "$APP_DIR/app/backups" "$APP_DIR/app/decor_media" "$APP_DIR/app/system/catalog_imports/history" "$APP_DIR/app/system/catalog_legacy_archive"
touch "$ENV_FILE" "$APP_DIR/app/backups/.keep" "$APP_DIR/app/decor_media/.keep"

# FIX653 blijft bewust in dezelfde acceptatie-/HTTP-modus als FIX650. De eerder
# afgesproken productie-hardening volgt pas na functionele acceptatie.
sed -i \
  '/^METOD_PORT=/d;/^PRODUCTION_HARDENING=/d;/^ADMIN_HASH_ONLY=/d;/^APP_ENV=/d;/^ADMIN_CREDENTIALS_FILE=/d;/^ADMIN_STAGING_OPEN=/d;/^PUBLIC_JOB_MAX_CONCURRENT=/d;/^PUBLIC_JOB_MAX_CONCURRENT_PER_IP=/d;/^ALLOWED_ADMIN_ORIGINS=/d;/^ALLOWED_ORIGINS=/d;/^PUBLIC_JSON_MAX_BYTES=/d;/^PUBLIC_JOB_TOTAL_QTY_LIMIT=/d;/^PUBLIC_JOB_MAX_AREA_LB=/d;/^JOB_OUTPUT_MAX_BYTES=/d' \
  "$ENV_FILE"
cat >> "$ENV_FILE" <<'ENVEOF'
METOD_PORT=8792
PRODUCTION_HARDENING=0
ADMIN_HASH_ONLY=0
APP_ENV=development
ADMIN_CREDENTIALS_FILE=/etc/adzaagt/metod-pax/admin_credentials.live.json
ADMIN_STAGING_OPEN=0
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
PUBLIC_JSON_MAX_BYTES=134217728
PUBLIC_JOB_TOTAL_QTY_LIMIT=250
PUBLIC_JOB_MAX_AREA_LB=250
JOB_OUTPUT_MAX_BYTES=536870912
ALLOWED_ADMIN_ORIGINS=http://51.195.102.180:8790
ALLOWED_ORIGINS=http://51.195.102.180:8790
ENVEOF

cat > "$SERVICE_FILE" <<'SVCEOF'
[Unit]
Description=METOD PAX Tool
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/adzaagt/metod-pax/app
EnvironmentFile=/etc/adzaagt/metod-pax/metod-pax.env
ExecStart=/usr/bin/python3 /opt/adzaagt/metod-pax/app/server_py.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVCEOF
rm -f /etc/systemd/system/metod-pax.service.d/10-http-test.conf

cat > "$NGINX_SITE" <<'NGINXEOF'
server {
    listen 8790;
    listen [::]:8790;
    server_name 51.195.102.180 _;
    client_max_body_size 160m;

    location / {
        proxy_pass http://127.0.0.1:8792;
        proxy_http_version 1.1;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $http_host;
        proxy_set_header X-Forwarded-Port $server_port;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 30s;
        proxy_send_timeout 1800s;
        proxy_read_timeout 1800s;
        proxy_buffering off;
    }
}
NGINXEOF
ln -sfn "$NGINX_SITE" /etc/nginx/sites-enabled/metod-pax-8790

# FIX653: oude seed/handmatige/JSON-library wordt eerst veilig gearchiveerd en
# daarna uit de ACTIEVE library verwijderd. Alleen reeds gepubliceerde CSV-records
# mogen actief blijven. Opaque public IDs worden apart intern bewaard voor stabiliteit.
python3 "$APP_DIR/tools/fix652_catalog_only_migrate.py" \
  --library "$APP_DIR/app/material_library.json" \
  --archive-dir "$APP_DIR/app/system/catalog_legacy_archive" \
  --registry "$APP_DIR/app/system/catalog_public_ids.json"

python3 -m py_compile \
  "$APP_DIR/app/server_py.py" \
  "$APP_DIR/app/catalog_importer.py" \
  "$APP_DIR/app/pricing_helpers.py" \
  "$APP_DIR/tools/migrate_decor_library.py" \
  "$APP_DIR/tools/fix652_catalog_only_migrate.py"

grep -Fq "FIX652_CSV_ONLY_LIBRARY_RESET" "$APP_DIR/app/server_py.py"
grep -Fq "FIX652_CSV_ONLY_ADMIN" "$APP_DIR/app/server_py.py"
grep -Fq "FIX653_LIBRARY_UX_CLASSIFICATION" "$APP_DIR/app/server_py.py"
grep -Fq "classify_catalog_presentation" "$APP_DIR/app/catalog_importer.py"
grep -Fq "visualTags" "$APP_DIR/app/catalog_importer.py"
grep -Fq "visualFamily" "$APP_DIR/app/decor_library.js"
grep -Fq "decorInfiniteSentinel" "$APP_DIR/app/decor_library.js"
! grep -Fq "Meer decors laden" "$APP_DIR/app/decor_library.js"
grep -Fq 'decor_library.js?v=653' "$APP_DIR/app/toolA.html"
grep -Fq 'FIX653_LIBRARY_UX_CLASSIFICATION' "$APP_DIR/app/toolA.html"
! grep -Fq "Upload hele JSON" "$APP_DIR/app/server_py.py"
! grep -Fq ">Nieuw decor<" "$APP_DIR/app/server_py.py"
grep -Fq "catalog_preview" "$APP_DIR/app/server_py.py"
grep -Fq "catalog_publish" "$APP_DIR/app/server_py.py"
grep -Fq "ALLOWED_THICKNESSES_MM = (18.0, 19.0, 20.0)" "$APP_DIR/app/catalog_importer.py"
grep -Fq "decolegno_18_fallback" "$APP_DIR/app/catalog_importer.py"
grep -Fq "CSV_CATALOG_ONLY" "$APP_DIR/tools/fix652_catalog_only_migrate.py"
grep -Fq "catalog_sell_price_v1" "$APP_DIR/app/server_py.py"
! grep -Fq 'id="priceSheetFactor"' "$APP_DIR/app/server_py.py"

grep -Fq "FIX644_STEP2_KEYBOARD_STABILITY_ALL_FIELDS" "$APP_DIR/app/toolA.html"
grep -Fq "FIX645_STEP2_KEYBOARD_FOOTER_HIDE" "$APP_DIR/app/toolA.html"
grep -Fq "FIX648_VERTICAL_GRAIN_RESTORE" "$APP_DIR/app/toolA.html"
grep -Fq "FIX650_MOBILE_GRAIN_PREVIEW_REVEAL" "$APP_DIR/app/toolA.html"
grep -Fq "FIX650_PREVIEW_BUTTON_RELIABLE" "$APP_DIR/app/toolA.html"
test -f "$APP_DIR/app/toolA_grain_mobile_scale.js"
test -f "$APP_DIR/app/toolA_grain_mobile_scale.css"

# Normalize the persisted live pricing config BEFORE validation. Only the obsolete
# general material factor is removed; all other Admin-configurable costs are preserved.
python3 - "$APP_DIR/app/config/pricing_active.json" <<'PY'
import json,os,sys
p=sys.argv[1]
try:
    obj=json.load(open(p,encoding='utf-8'))
except Exception:
    obj={}
if not isinstance(obj,dict): obj={}
sp=obj.get('sellPricing') if isinstance(obj.get('sellPricing'),dict) else {}
sp.pop('sheetPriceFactor',None)
for key,default in (('edgeBandPricePerM',0.0),('cncCostPerSheet',0.0),('drawingCostFixed',0.0),('transportCostFixed',0.0)):
    try: sp[key]=float(sp.get(key,default))
    except Exception: sp[key]=float(default)
obj['sellPricing']=sp
obj['pricingModel']='catalog_sell_price_v1'
tmp=p+'.fix653.tmp'
with open(tmp,'w',encoding='utf-8') as f:
    json.dump(obj,f,ensure_ascii=False,indent=2); f.flush(); os.fsync(f.fileno())
os.replace(tmp,p)
print('Persisted pricing genormaliseerd naar catalog_sell_price_v1; overige Admin-kosten behouden.')
PY

# Active pricing schema must no longer contain a general sheet factor, while all
# existing Admin-adjustable costs stay available.
python3 - "$APP_DIR/app/config/pricing_active.json" <<'PY'
import json,sys
p=sys.argv[1]
obj=json.load(open(p,encoding='utf-8'))
sp=obj.get('sellPricing') or {}
assert 'sheetPriceFactor' not in sp, 'sheetPriceFactor staat nog in actieve pricing'
for key in ('edgeBandPricePerM','cncCostPerSheet','drawingCostFixed','transportCostFixed'):
    assert key in sp, f'ontbrekende bestaande Admin-kostenpost: {key}'
assert obj.get('pricingModel') == 'catalog_sell_price_v1'
print('Actieve pricing: directe catalogusprijs + bestaande Admin-kosten OK')
PY

systemctl daemon-reload
systemctl enable metod-pax.service >/dev/null
systemctl restart metod-pax.service
nginx -t
systemctl reload nginx
sleep 3

HTML_CHECK="$(mktemp /tmp/fix653_html_XXXXXX)"
ADMIN_CHECK="$(mktemp /tmp/fix653_admin_XXXXXX)"
PUBLIC_CHECK="$(mktemp /tmp/fix653_public_XXXXXX)"
trap 'rm -f "$HTML_CHECK" "$ADMIN_CHECK" "$PUBLIC_CHECK"' EXIT
curl -fsS "http://127.0.0.1:8792/toolA.html?v=653" -o "$HTML_CHECK"
curl -fsS "http://127.0.0.1:8792/admin/?v=653" -o "$ADMIN_CHECK"
curl -fsS "http://127.0.0.1:8792/api/materials/library" -o "$PUBLIC_CHECK"
grep -Fq "FIX650_PREVIEW_BUTTON_RELIABLE" "$HTML_CHECK"
grep -Fq "FIX653_LIBRARY_UX_CLASSIFICATION" "$HTML_CHECK"
grep -Eq "Admin|login|METOD" "$ADMIN_CHECK"

python3 - "$PUBLIC_CHECK" "$APP_DIR/app/material_library.json" <<'PY'
import json,re,sys
pub=json.load(open(sys.argv[1],encoding='utf-8'))
internal=json.load(open(sys.argv[2],encoding='utf-8'))
assert pub.get('ok') is True
records=pub.get('records') or []
active=internal.get('records') or []
assert internal.get('source') == 'CSV_CATALOG_ONLY', internal.get('source')
assert int(internal.get('decorLibrarySchemaVersion') or 0) == 3
assert len(records) == len(active), (len(records),len(active))
allowed={"publicMaterialId","publicName","brand","decorType","visualFamily","visualTags","colorGroup","searchTags","thicknessMm","sheetSizeMm","hasGrain","grainDefaultOn","active","published","isPopular","isNew","imageAvailable","imageThumbUrl","imagePreviewUrl"}
for r in active:
    assert str(r.get('sourceKind') or '').upper() == 'CATALOG_IMPORT'
    assert not r.get('catalogMissing') and not r.get('catalogExcluded')
    assert float(r.get('thicknessMm') or 0) in (18.0,19.0,20.0)
    assert float(r.get('sellPriceInclVatPerSheet') or 0) > 0
for r in records:
    assert set(r).issubset(allowed), set(r)-allowed
    assert re.fullmatch(r"decor_[a-f0-9]{20,40}",str(r.get('publicMaterialId') or ''))
    assert float(r.get('thicknessMm') or 0) in (18.0,19.0,20.0)
    assert str(r.get('visualFamily') or '') in ('Hout','Uni','Steen','Metaal','Textiel','Overig')
    assert isinstance(r.get('visualTags'), list)
    assert isinstance(r.get('searchTags'), list)
forbidden={"articleNumber","articleNo","materialCode","purchasePrice","purchasePricePerSheet","supplier","supplierName","leverancier","imageSourceUrl","imageSourceUrls","sellPriceInclVatPerSheet","sellPriceExVatPerSheet"}
assert not any(forbidden.intersection(r) for r in records)
articles={str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '') for r in active if isinstance(r,dict)}
articles.discard('')
def walk(v):
    if isinstance(v,dict):
        for x in v.values(): yield from walk(x)
    elif isinstance(v,list):
        for x in v: yield from walk(x)
    elif isinstance(v,str): yield v
for value in walk(pub):
    assert value not in articles, f'intern artikelnummer gelekt: {value}'
print(f'FIX653 CSV-only/privacy OK: {len(records)} actieve CSV-producten; geen legacy/JSON/handmatige records actief')
PY

# Raw internal data/config/importstaging must not be statisch opvraagbaar.
for path in material_library.json config/pricing_active.json system/catalog_imports/test.json; do
  code="$(curl -sS -o /dev/null -w '%{http_code}' "http://127.0.0.1:8792/$path")"
  [[ "$code" == "404" ]] || { echo "Interne route publiek: $path -> $code" >&2; exit 31; }
done

curl -fsSI "http://51.195.102.180:8790/toolA.html?v=653" >/dev/null

echo "FIX653 actief. Open Tool A: http://51.195.102.180:8790/toolA.html?v=653"
echo "Admin catalogus: http://51.195.102.180:8790/admin/?v=653"
echo "Open Admin -> Websitecatalogus. Alleen CSV controleren + Catalogus publiceren is actief; oude seed/JSON/handmatige library is uit de actieve bron verwijderd."
