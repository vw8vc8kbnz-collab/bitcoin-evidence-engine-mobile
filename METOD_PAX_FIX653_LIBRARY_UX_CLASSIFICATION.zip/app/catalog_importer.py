#!/usr/bin/env python3
"""Catalog CSV import helpers for METOD/PAX Tool A.

This module is intentionally standard-library-only.  It parses the Adzaagt website
catalog export, validates the hard material rules, derives missing sheet dimensions
from image URLs, and safely caches remote catalog images without exposing the
source URL to Tool A.

Internal article numbers are handled only in Admin/backend data structures.
"""
from __future__ import annotations

import csv
import hashlib
import io
import ipaddress
import json
import os
import re
import socket
import struct
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import unquote, urlparse
from urllib.request import Request, build_opener, HTTPRedirectHandler

ALLOWED_THICKNESSES_MM = (18.0, 19.0, 20.0)
VAT_RATE = 0.21
EXPECTED_HEADERS = (
    'Product Reference Code',
    'Product Image Urls',
    'Product Name',
    'Feature Max. dikte (mm)',
    'Feature Max. lengte (mm)',
    'Feature Max. breedte (mm)',
    'Prijs per plaat inclusief BTW',
)


def _norm_header(v: Any) -> str:
    s = str(v or '').replace('\ufeff', '').strip().lower()
    s = re.sub(r'\s+', ' ', s)
    return s


def _to_number(value: Any) -> float | None:
    s = str(value or '').strip().replace('\xa0', '').replace('\u202f', '').replace(' ', '')
    if not s:
        return None
    s = re.sub(r'[^0-9,\.\-]', '', s)
    if not s or s in {'-', '.', ','}:
        return None
    # Support both 1.197,64 and 1,197.64 while keeping simple 140.22 intact.
    if ',' in s and '.' in s:
        if s.rfind(',') > s.rfind('.'):
            s = s.replace('.', '').replace(',', '.')
        else:
            s = s.replace(',', '')
    elif ',' in s:
        # A single comma is treated as decimal separator. Multiple commas are thousands
        # separators except the final one when it has 1-2 trailing digits.
        if s.count(',') == 1:
            s = s.replace(',', '.')
        else:
            parts = s.split(',')
            if len(parts[-1]) in (1, 2):
                s = ''.join(parts[:-1]) + '.' + parts[-1]
            else:
                s = ''.join(parts)
    try:
        n = float(s)
    except Exception:
        return None
    return n if n == n and abs(n) != float('inf') else None


def _split_outer_csv(text: str) -> list[list[str]]:
    """Parse both a normal CSV and the website export where each CSV row is itself quoted."""
    outer = list(csv.reader(io.StringIO(str(text or ''))))
    rows: list[list[str]] = []
    for row in outer:
        if not row or not any(str(x or '').strip() for x in row):
            continue
        if len(row) == 1 and ',' in str(row[0] or ''):
            try:
                inner = next(csv.reader([row[0]]))
            except Exception:
                inner = [row[0]]
            rows.append(inner)
        else:
            rows.append(row)
    return rows


def _image_urls(raw: Any) -> list[str]:
    s = str(raw or '').strip()
    if not s:
        return []
    # URLs in this export are comma separated within a quoted field. URLs themselves do
    # not contain literal commas in the path.  Tolerate markdown-style [url](url) too.
    found = re.findall(r'https://[^,\s\]\)"<>]+', s, flags=re.I)
    out: list[str] = []
    seen = set()
    for u in found:
        u = u.strip().rstrip('.,;')
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def extract_dimensions_from_image_url(url: str) -> tuple[float, float, float] | None:
    """Return (length, width, thickness) when the filename carries dimensions.

    Supports examples such as 2800-2070-18, 2800x2070x18mm,
    2800-x-2070-x-18mm and 3050-1300-19.
    """
    try:
        path = unquote(urlparse(str(url or '')).path or '').lower()
    except Exception:
        path = str(url or '').lower()
    base = path.rsplit('/', 1)[-1]
    # Normalise visual separators while retaining digits.  The first pattern handles
    # ordinary x; the second handles dash / -x- variations.
    patterns = (
        r'(?<!\d)(\d{3,4})\s*x\s*(\d{3,4})\s*x\s*(\d{1,2}(?:\.\d+)?)\s*mm?(?:\D|$)',
        r'(?<!\d)(\d{3,4})\s*(?:-x-|[-_])\s*(\d{3,4})\s*(?:-x-|[-_])\s*(\d{1,2}(?:\.\d+)?)\s*(?:mm?)?(?:\D|$)',
    )
    for pat in patterns:
        matches = list(re.finditer(pat, base, flags=re.I))
        if matches:
            m = matches[-1]
            try:
                return float(m.group(1)), float(m.group(2)), float(m.group(3))
            except Exception:
                return None
    return None


def _brand_hint(product_name: str) -> str:
    s = str(product_name or '').upper()
    if 'DECOLEGNO' in s or 'DECORLEGNO' in s:
        return 'DecoLegno'
    if 'UNILIN' in s:
        return 'Unilin'
    if 'SHINNOKI' in s:
        return 'Shinnoki'
    return ''


def _category_hint(product_name: str) -> str:
    s = str(product_name or '').lower()
    if 'gefineerd' in s or 'fineer' in s:
        return 'Gefineerd MDF'
    if 'mfc' in s or 'spaanplaat' in s:
        return 'Gemelamineerd spaanplaat'
    if 'hpl' in s:
        return 'MDF met HPL'
    if 'mdf' in s:
        return 'MDF'
    return ''



def _plain_text(value: str) -> str:
    text = unicodedata.normalize('NFKD', str(value or ''))
    text = ''.join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r'[^a-z0-9]+', ' ', text.lower()).strip()


def _product_code_hint(product_name: str, brand: str = '') -> str:
    name = str(product_name or '')
    b = str(brand or _brand_hint(name) or '')
    if b == 'DecoLegno':
        m = re.search(r'\bDecoLegno\s+([A-Z]{1,3}\d{2,4})\b', name, re.I)
        return (m.group(1).upper() if m else '')
    if b == 'Unilin':
        # The Evola catalog code is the token directly following an optional MDF/V313 marker.
        m = re.search(r'\b(?:V313\s+)?(0?[A-Z]?[A-Z0-9]{2,5})\b', name.replace('Unilin Evola', '', 1), re.I)
        return (m.group(1).upper() if m else '')
    return ''


def classify_catalog_presentation(product_name: str, brand: str = '', category_name: str = '', image_urls: Iterable[str] | None = None) -> dict[str, Any]:
    """Deterministic public presentation metadata for search/filtering.

    This intentionally uses only public-facing catalog text. Article/reference numbers are
    never included in search tags or returned presentation metadata. The result may be
    recomputed on every import, so future CSV uploads follow the same rules automatically.
    """
    brand = str(brand or _brand_hint(product_name) or '').strip()
    category_name = str(category_name or _category_hint(product_name) or '').strip()
    text = _plain_text(f'{product_name} {category_name}')
    code = _product_code_hint(product_name, brand)

    wood_terms = {
        'hout','wood','oak','eiken','eik','walnut','noten','noce','beech','beuken','ash','essen',
        'spruce','vuren','pine','grenen','teak','sapele','sapeli','mahogany','mahonie','wenge',
        'eucalyptus','bamboe','bamboo','elm','iepen','maple','esdoorn','cherry','kersen','acacia',
        'cedar','ceder','larch','larix','zebrano','amazakoue','yaya','triba','quercia','sherwood',
        'barnwood','flakewood','corteccia','fronda','maloja','fineer','gefineerd','veneer'
    }
    stone_terms = {
        'steen','stone','marble','marmer','travertin','travertine','graniet','granite','terrazzo',
        'carrara','ceppo','cement','mineral','concrete','beton','concreta','lime','granulo','leisteen','slate'
    }
    metal_terms = {
        'metaal','metal','metallic','alu','aluminium','aluminum','steel','staal','copper','koper',
        'bronze','brons','gold','goud','oxid','oxide','brushed alu','brushed bronze','brushed gold'
    }
    textile_terms = {
        'textiel','textile','stof','fabric','woven','linnen','linen','alpaca','ovatta','penelope',
        'taranta','fiocco','talco','mosaico','sable'
    }
    uni_terms = {
        'uni','effen','solid','front white','elegant black','supermat','grondeerfolie','wit','white',
        'zwart','black','colour','color'
    }

    words = set(text.split())
    def has_terms(terms):
        for term in terms:
            t = _plain_text(term)
            if ' ' in t:
                if t in text:
                    return True
            elif t in words:
                return True
        return False

    # Brand/code families are valuable because many commercial decor names do not contain
    # literal words such as "wood". Explicit visual keywords still take priority where safe.
    if brand == 'Shinnoki' or 'gefineerd' in text or 'fineer' in text or 'veneer' in text:
        family = 'Hout'
    elif brand == 'DecoLegno' and code.startswith(('U','UA','UB')):
        family = 'Uni'
    elif has_terms(wood_terms):
        family = 'Hout'
    elif brand == 'Unilin' and code.startswith('0H'):
        family = 'Hout'
    elif brand == 'DecoLegno' and code.startswith(('S','L')):
        family = 'Hout'
    elif has_terms(stone_terms):
        family = 'Steen'
    elif has_terms(metal_terms):
        family = 'Metaal'
    elif has_terms(textile_terms) or (brand == 'DecoLegno' and code.startswith('FD')):
        family = 'Textiel'
    elif has_terms(uni_terms) or brand == 'Unilin':
        family = 'Uni'
    else:
        family = 'Overig'

    visual_tags = {family}
    # Secondary visual tags keep filters inclusive. A solid-colour decor with a clear
    # woodgrain texture (for example a U-code in Quercia/Maloja) still belongs in Hout.
    if has_terms(wood_terms) or brand == 'Shinnoki' or (brand == 'Unilin' and code.startswith('0H')) or (brand == 'DecoLegno' and code.startswith(('S','L'))):
        visual_tags.add('Hout')
    if has_terms(stone_terms): visual_tags.add('Steen')
    if has_terms(metal_terms): visual_tags.add('Metaal')
    if has_terms(textile_terms) or (brand == 'DecoLegno' and code.startswith('FD')): visual_tags.add('Textiel')
    if has_terms(uni_terms) or (brand == 'DecoLegno' and code.startswith(('U','UA','UB'))): visual_tags.add('Uni')

    color_rules = (
        ('Zwart', ('zwart','black','nero','noir','antraciet','anthracite')),
        ('Wit', ('wit','white','blanc','chalk')),
        ('Grijs', ('grijs','grey','gray','quartz','silicon','silver')),
        ('Beige', ('beige','cream','creamy','ivory','sand','sahara','greige','fondant','linen')),
        ('Bruin', ('bruin','brown','chocolat','caramel','walnut','noten','noce','wenge','teak','sapele','mahogany','mahonie')),
        ('Groen', ('groen','green','olive','sage')),
        ('Blauw', ('blauw','blue','navy')),
        ('Rood', ('rood','red','bordeaux')),
        ('Roze', ('roze','pink','blush')),
        ('Geel', ('geel','yellow','oker','ochre')),
        ('Oranje', ('oranje','orange','terracotta')),
    )
    color_group = 'Overig'
    for label, terms in color_rules:
        if any(_plain_text(t) in text for t in terms):
            color_group = label
            break

    tags = {brand, family, category_name, color_group, *visual_tags}
    family_synonyms = {
        'Hout': ('hout','houtlook','wood','woodlook'),
        'Uni': ('uni','effen','solid','kleur'),
        'Steen': ('steen','stone','beton','concrete','marmer','marble'),
        'Metaal': ('metaal','metal','metallic'),
        'Textiel': ('textiel','stof','fabric','woven'),
        'Overig': ('decor',),
    }
    tags.update(family_synonyms.get(family, ()))
    color_synonyms = {
        'Zwart': ('zwart','black'), 'Wit': ('wit','white'), 'Grijs': ('grijs','grey','gray'),
        'Beige': ('beige','cream','zand'), 'Bruin': ('bruin','brown'), 'Groen': ('groen','green'),
        'Blauw': ('blauw','blue'), 'Rood': ('rood','red'), 'Roze': ('roze','pink'),
        'Geel': ('geel','yellow'), 'Oranje': ('oranje','orange'),
    }
    tags.update(color_synonyms.get(color_group, ()))
    translations = {
        'oak':'eiken', 'eiken':'oak', 'walnut':'noten', 'noten':'walnut', 'beech':'beuken',
        'beuken':'beech', 'ash':'essen', 'essen':'ash', 'white':'wit', 'wit':'white',
        'black':'zwart', 'zwart':'black', 'grey':'grijs', 'gray':'grijs', 'grijs':'grey',
        'brown':'bruin', 'bruin':'brown', 'concrete':'beton', 'beton':'concrete',
        'marble':'marmer', 'marmer':'marble', 'metal':'metaal', 'metaal':'metal',
    }
    for w in words:
        if w in translations:
            tags.add(translations[w])
    clean_tags = sorted({_plain_text(x) for x in tags if _plain_text(x) and _plain_text(x) != 'overig'})
    return {
        'visualFamily': family,
        'visualTags': sorted(visual_tags),
        'colorGroup': color_group,
        'searchTags': clean_tags[:48],
    }

def parse_catalog_csv(text: str) -> dict[str, Any]:
    raw_text = str(text or '')
    rows = _split_outer_csv(raw_text)
    result: dict[str, Any] = {
        'schemaVersion': 1,
        'sourceType': 'ADZAAGT_WEBSITE_CSV',
        'csvSha256': hashlib.sha256(raw_text.encode('utf-8')).hexdigest(),
        'records': [],
        'excluded': [],
        'warnings': [],
        'errors': [],
        'summary': {},
    }
    if not rows:
        result['errors'].append({'row': 0, 'code': 'EMPTY_CSV', 'message': 'CSV bevat geen regels.'})
        result['summary'] = {'rowsRead': 0, 'eligible': 0, 'excludedThickness': 0, 'blockingErrors': 1, 'warnings': 0}
        return result

    header = [_norm_header(x) for x in rows[0]]
    expected = [_norm_header(x) for x in EXPECTED_HEADERS]
    if len(header) != len(expected) or header != expected:
        result['errors'].append({
            'row': 1,
            'code': 'HEADER_MISMATCH',
            'message': 'CSV-kolommen komen niet overeen met het ingestelde Adzaagt-catalogusformaat.',
            'expected': list(EXPECTED_HEADERS),
            'received': rows[0],
        })
        result['summary'] = {'rowsRead': max(0, len(rows)-1), 'eligible': 0, 'excludedThickness': 0, 'blockingErrors': 1, 'warnings': 0}
        return result

    seen_articles: set[str] = set()
    for idx, cols in enumerate(rows[1:], start=2):
        if len(cols) != 7:
            result['errors'].append({'row': idx, 'code': 'COLUMN_COUNT', 'message': f'Regel {idx} bevat {len(cols)} velden in plaats van 7.'})
            continue
        article, images_raw, product_name, thick_raw, len_raw, wid_raw, price_raw = [str(x or '').strip() for x in cols]
        if not article:
            result['errors'].append({'row': idx, 'code': 'ARTICLE_MISSING', 'message': f'Regel {idx}: artikelnummer ontbreekt.'})
            continue
        if article in seen_articles:
            result['errors'].append({'row': idx, 'code': 'ARTICLE_DUPLICATE', 'articleNo': article, 'message': f'Dubbel artikelnummer: {article}.'})
            continue
        seen_articles.add(article)

        thickness = _to_number(thick_raw)
        if thickness is None:
            result['errors'].append({'row': idx, 'code': 'THICKNESS_INVALID', 'articleNo': article, 'message': 'Dikte ontbreekt of is ongeldig.'})
            continue
        if not any(abs(thickness - allowed) < 1e-9 for allowed in ALLOWED_THICKNESSES_MM):
            result['excluded'].append({
                'row': idx,
                'articleNo': article,
                'productName': product_name,
                'thicknessMm': thickness,
                'reason': 'Dikte niet toegestaan; alleen 18, 19 of 20 mm komt in Tool A.',
            })
            continue

        price_inc = _to_number(price_raw)
        if price_inc is None or price_inc <= 0:
            result['errors'].append({'row': idx, 'code': 'PRICE_INVALID', 'articleNo': article, 'message': 'Verkoopprijs per plaat incl. BTW ontbreekt of is ongeldig.'})
            continue
        if not product_name:
            result['errors'].append({'row': idx, 'code': 'NAME_MISSING', 'articleNo': article, 'message': 'Productnaam ontbreekt.'})
            continue

        urls = _image_urls(images_raw)
        if not urls:
            result['errors'].append({'row': idx, 'code': 'IMAGE_URL_MISSING', 'articleNo': article, 'message': 'Afbeeldings-URL ontbreekt.'})
            continue

        length = _to_number(len_raw)
        width = _to_number(wid_raw)
        dimension_source = 'csv'
        url_dims = None
        for u in urls:
            dims = extract_dimensions_from_image_url(u)
            if dims:
                url_dims = dims
                break
        if url_dims:
            ul, uw, ut = url_dims
            if abs(float(ut) - float(thickness)) > 0.01:
                result['warnings'].append({
                    'row': idx,
                    'code': 'URL_THICKNESS_MISMATCH',
                    'articleNo': article,
                    'message': f'CSV-dikte {thickness:g} mm wijkt af van {ut:g} mm in afbeeldings-URL. CSV-dikte blijft leidend.',
                })
            if length is None or length <= 0:
                length = ul
                dimension_source = 'image_url'
            if width is None or width <= 0:
                width = uw
                dimension_source = 'image_url'
        if (length is None or length <= 0 or width is None or width <= 0):
            # Explicit business fallback confirmed by the user: only 18 mm DecoLegno
            # may use 2800x2070 when the image URL does not reveal a usable dimension.
            if _brand_hint(product_name) == 'DecoLegno' and abs(thickness - 18.0) < 1e-9:
                length = 2800.0 if length is None or length <= 0 else length
                width = 2070.0 if width is None or width <= 0 else width
                dimension_source = 'decolegno_18_fallback'
                result['warnings'].append({
                    'row': idx,
                    'code': 'DECOLEGNO_DIMENSION_FALLBACK',
                    'articleNo': article,
                    'message': 'Ontbrekende DecoLegno 18 mm plaatmaat aangevuld met gecontroleerde fallback 2800×2070 mm.',
                })
            else:
                result['errors'].append({
                    'row': idx,
                    'code': 'DIMENSIONS_MISSING',
                    'articleNo': article,
                    'message': 'Plaatlengte/breedte ontbreekt en kon niet veilig uit de afbeeldings-URL worden afgeleid.',
                })
                continue

        # If explicit CSV dimensions and URL dimensions both exist, only warn about a
        # clear mismatch. CSV remains authoritative.
        if url_dims and str(len_raw).strip() and str(wid_raw).strip():
            ul, uw, _ = url_dims
            if abs(float(length) - ul) > 1 or abs(float(width) - uw) > 1:
                result['warnings'].append({
                    'row': idx,
                    'code': 'URL_DIMENSION_MISMATCH',
                    'articleNo': article,
                    'message': f'CSV-plaatmaat {length:g}×{width:g} wijkt af van {ul:g}×{uw:g} in afbeeldings-URL. CSV blijft leidend.',
                })

        brand_hint = _brand_hint(product_name)
        category_hint = _category_hint(product_name)
        presentation = classify_catalog_presentation(product_name, brand_hint, category_hint, urls)
        result['records'].append({
            'articleNo': article,
            'materialCode': article,
            'productName': product_name[:220],
            'decorName': product_name[:220],
            'publicName': product_name[:180],
            'brand': brand_hint,
            'categoryName': category_hint,
            'visualFamily': presentation['visualFamily'],
            'visualTags': presentation['visualTags'],
            'colorGroup': presentation['colorGroup'],
            'searchTags': presentation['searchTags'],
            'thicknessMm': float(thickness),
            'sheetLen': float(length),
            'sheetWid': float(width),
            'sellPriceInclVatPerSheet': round(float(price_inc), 2),
            'sellPriceExVatPerSheet': round(float(price_inc) / (1.0 + VAT_RATE), 6),
            'priceVatRate': VAT_RATE,
            'priceSource': 'CSV_SALE_PRICE_INCL_VAT',
            'imageSourceUrls': urls[:12],
            'imageSourceUrl': urls[0],
            'dimensionSource': dimension_source,
            'sourceKind': 'CATALOG_IMPORT',
            'catalogSource': 'ADZAAGT_WEBSITE_CSV',
            'active': True,
            'published': True,
            'archived': False,
        })

    result['summary'] = {
        'rowsRead': max(0, len(rows)-1),
        'eligible': len(result['records']),
        'excludedThickness': len(result['excluded']),
        'blockingErrors': len(result['errors']),
        'warnings': len(result['warnings']),
    }
    return result


def comparable_catalog_fields(rec: dict[str, Any]) -> dict[str, Any]:
    """Fields for deterministic diffing of a staged catalog record."""
    return {
        'productName': str(rec.get('productName') or ''),
        'thicknessMm': float(rec.get('thicknessMm') or 0),
        'sheetLen': float(rec.get('sheetLen') or 0),
        'sheetWid': float(rec.get('sheetWid') or 0),
        'sellPriceInclVatPerSheet': round(float(rec.get('sellPriceInclVatPerSheet') or 0), 2),
        'imageSourceUrls': list(rec.get('imageSourceUrls') or []),
        'visualFamily': str(rec.get('visualFamily') or ''),
        'visualTags': list(rec.get('visualTags') or []),
        'colorGroup': str(rec.get('colorGroup') or ''),
        'searchTags': list(rec.get('searchTags') or []),
    }


def catalog_diff(staged_records: list[dict[str, Any]], existing_records: list[dict[str, Any]], excluded_records: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    existing_by_article = {}
    for r in existing_records or []:
        if not isinstance(r, dict):
            continue
        art = str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip()
        if art:
            existing_by_article[art] = r
    staged_by_article = {str(r.get('articleNo') or '').strip(): r for r in staged_records if isinstance(r, dict) and str(r.get('articleNo') or '').strip()}
    excluded_articles = {str(r.get('articleNo') or '').strip() for r in (excluded_records or []) if isinstance(r, dict) and str(r.get('articleNo') or '').strip()}
    new, changed, unchanged = [], [], []
    for art, rec in staged_by_article.items():
        old = existing_by_article.get(art)
        if old is None:
            new.append(art)
            continue
        old_cmp = comparable_catalog_fields({
            'productName': old.get('productName') or old.get('decorName') or old.get('publicName') or '',
            'thicknessMm': old.get('thicknessMm') or old.get('thickness') or 0,
            'sheetLen': old.get('sheetLen') or old.get('sheetHeight') or old.get('height') or 0,
            'sheetWid': old.get('sheetWid') or old.get('sheetWidth') or 0,
            'sellPriceInclVatPerSheet': old.get('sellPriceInclVatPerSheet') or old.get('salePriceInclVatPerSheet') or 0,
            'imageSourceUrls': old.get('imageSourceUrls') or ([old.get('imageSourceUrl')] if old.get('imageSourceUrl') else []),
        })
        if old_cmp == comparable_catalog_fields(rec):
            unchanged.append(art)
        else:
            changed.append(art)
    missing = []
    for art, old in existing_by_article.items():
        source_kind = str(old.get('sourceKind') or 'LEGACY_LIBRARY').upper()
        if source_kind == 'CATALOG_IMPORT' and art not in staged_by_article and art not in excluded_articles:
            missing.append(art)
    return {
        'new': new,
        'changed': changed,
        'unchanged': unchanged,
        'missingFromSource': missing,
        'counts': {
            'new': len(new),
            'changed': len(changed),
            'unchanged': len(unchanged),
            'missingFromSource': len(missing),
        },
    }


# ----------------------------- image cache ---------------------------------

def _allowed_image_hosts() -> set[str]:
    raw = os.environ.get('METOD_CATALOG_IMAGE_HOSTS', 'adzaagt.nl,www.adzaagt.nl')
    return {x.strip().lower().rstrip('.') for x in raw.split(',') if x.strip()}


def validate_remote_image_url(url: str) -> str:
    u = str(url or '').strip()
    parsed = urlparse(u)
    if parsed.scheme.lower() != 'https':
        raise ValueError('Alleen https-afbeeldingslinks zijn toegestaan.')
    host = str(parsed.hostname or '').lower().rstrip('.')
    if not host or host not in _allowed_image_hosts():
        raise ValueError('Afbeeldingshost is niet toegestaan.')
    if parsed.username or parsed.password:
        raise ValueError('Afbeeldings-URL met gebruikersgegevens is niet toegestaan.')
    port = parsed.port
    if port not in (None, 443):
        raise ValueError('Alleen standaard HTTPS-poort is toegestaan.')
    # Block SSRF through DNS rebinding / private network targets.
    infos = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
    if not infos:
        raise ValueError('Afbeeldingshost kon niet worden gevonden.')
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
            raise ValueError('Afbeeldingshost verwijst naar een niet-publiek netwerkadres.')
    return u


class _SafeRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: D401
        validate_remote_image_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _detect_image_type(data: bytes) -> str | None:
    if data.startswith(b'\xff\xd8\xff'):
        return 'image/jpeg'
    if data.startswith(b'\x89PNG\r\n\x1a\n'):
        return 'image/png'
    if len(data) >= 12 and data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return 'image/webp'
    return None


def _strip_jpeg_metadata(data: bytes) -> bytes:
    if not data.startswith(b'\xff\xd8'):
        return data
    out = bytearray(data[:2])
    pos = 2
    n = len(data)
    while pos < n:
        if data[pos] != 0xFF:
            # Scan data after SOS or malformed tail; copy rest.
            out.extend(data[pos:])
            break
        start = pos
        while pos < n and data[pos] == 0xFF:
            pos += 1
        if pos >= n:
            out.extend(data[start:])
            break
        marker = data[pos]
        pos += 1
        if marker in (0xD9,):
            out.extend(data[start:pos])
            break
        if marker in (0x01,) or 0xD0 <= marker <= 0xD8:
            out.extend(data[start:pos])
            continue
        if pos + 2 > n:
            out.extend(data[start:])
            break
        seglen = int.from_bytes(data[pos:pos+2], 'big')
        end = pos + seglen
        if seglen < 2 or end > n:
            out.extend(data[start:])
            break
        if marker == 0xDA:  # Start of Scan: segment header + compressed stream are required.
            out.extend(data[start:])
            break
        # Strip APP1-APP15 and COM. Keep APP0/JFIF for broad decoder compatibility.
        if marker == 0xE0 or not (0xE1 <= marker <= 0xEF or marker == 0xFE):
            out.extend(data[start:end])
        pos = end
    return bytes(out)


def _strip_png_metadata(data: bytes) -> bytes:
    sig = b'\x89PNG\r\n\x1a\n'
    if not data.startswith(sig):
        return data
    out = bytearray(sig)
    pos = len(sig)
    # Explicitly remove textual/EXIF/time chunks. Keep all other chunks untouched so
    # colour/transparency behaviour stays identical.
    remove = {b'tEXt', b'zTXt', b'iTXt', b'eXIf', b'tIME'}
    while pos + 12 <= len(data):
        length = int.from_bytes(data[pos:pos+4], 'big')
        end = pos + 12 + length
        if end > len(data):
            return data
        ctype = data[pos+4:pos+8]
        if ctype not in remove:
            out.extend(data[pos:end])
        pos = end
        if ctype == b'IEND':
            break
    return bytes(out)


def _strip_webp_metadata(data: bytes) -> bytes:
    if len(data) < 12 or data[:4] != b'RIFF' or data[8:12] != b'WEBP':
        return data
    chunks: list[tuple[bytes, bytes]] = []
    pos = 12
    while pos + 8 <= len(data):
        fourcc = data[pos:pos+4]
        size = int.from_bytes(data[pos+4:pos+8], 'little')
        start = pos + 8
        end = start + size
        if end > len(data):
            return data
        payload = bytearray(data[start:end])
        if fourcc not in (b'EXIF', b'XMP '):
            if fourcc == b'VP8X' and len(payload) >= 1:
                # Clear EXIF (bit 3) and XMP (bit 2) flags.
                payload[0] &= ~(1 << 3)
                payload[0] &= ~(1 << 2)
            chunks.append((fourcc, bytes(payload)))
        pos = end + (size & 1)
    body = bytearray(b'WEBP')
    for fourcc, payload in chunks:
        body.extend(fourcc)
        body.extend(len(payload).to_bytes(4, 'little'))
        body.extend(payload)
        if len(payload) & 1:
            body.extend(b'\x00')
    return b'RIFF' + len(body).to_bytes(4, 'little') + bytes(body)


def sanitize_image_bytes(data: bytes, mime: str) -> bytes:
    if mime == 'image/jpeg':
        return _strip_jpeg_metadata(data)
    if mime == 'image/png':
        return _strip_png_metadata(data)
    if mime == 'image/webp':
        return _strip_webp_metadata(data)
    raise ValueError('Niet-ondersteund afbeeldingsformaat.')


def download_catalog_image(url: str, *, max_bytes: int = 12 * 1024 * 1024, timeout: float = 12.0) -> dict[str, Any]:
    safe_url = validate_remote_image_url(url)
    req = Request(safe_url, headers={'User-Agent': 'AdzaagtCatalogImporter/1.0', 'Accept': 'image/avif,image/webp,image/png,image/jpeg,*/*;q=0.2'})
    opener = build_opener(_SafeRedirect())
    with opener.open(req, timeout=timeout) as resp:
        final_url = validate_remote_image_url(resp.geturl())
        content_length = resp.headers.get('Content-Length')
        if content_length:
            try:
                if int(content_length) > max_bytes:
                    raise ValueError('Afbeelding is groter dan de toegestane limiet.')
            except ValueError:
                raise
            except Exception:
                pass
        chunks = []
        total = 0
        while True:
            chunk = resp.read(min(65536, max_bytes + 1 - total))
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise ValueError('Afbeelding is groter dan de toegestane limiet.')
            chunks.append(chunk)
        data = b''.join(chunks)
    mime = _detect_image_type(data)
    if mime not in ('image/jpeg', 'image/png', 'image/webp'):
        raise ValueError('URL leverde geen ondersteunde JPG/PNG/WebP-afbeelding.')
    clean = sanitize_image_bytes(data, mime)
    return {
        'data': clean,
        'mime': mime,
        'sourceUrl': final_url,
        'sha256': hashlib.sha256(clean).hexdigest(),
        'bytes': len(clean),
    }


def atomic_write_cached_image(folder: Path, payload: dict[str, Any]) -> dict[str, Any]:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    data = bytes(payload['data'])
    meta = {
        'mime': str(payload['mime']),
        'sha256': str(payload['sha256']),
        'bytes': int(payload.get('bytes') or len(data)),
        'cachedAt': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    # Deliberately do not store the source URL in public media metadata.
    img_tmp = folder / 'catalog.img.tmp'
    img = folder / 'catalog.img'
    meta_tmp = folder / 'catalog.meta.json.tmp'
    meta_path = folder / 'catalog.meta.json'
    with open(img_tmp, 'wb') as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    with open(meta_tmp, 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2); f.flush(); os.fsync(f.fileno())
    os.replace(img_tmp, img)
    os.replace(meta_tmp, meta_path)
    return meta


def read_cached_image(folder: Path) -> tuple[Path, dict[str, Any]] | None:
    folder = Path(folder)
    img = folder / 'catalog.img'
    meta_path = folder / 'catalog.meta.json'
    if not img.exists() or not meta_path.exists():
        return None
    try:
        meta = json.loads(meta_path.read_text(encoding='utf-8'))
    except Exception:
        return None
    mime = str(meta.get('mime') or '')
    if mime not in ('image/jpeg', 'image/png', 'image/webp'):
        return None
    return img, meta
