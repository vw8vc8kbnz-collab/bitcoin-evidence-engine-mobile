# Technische overdracht FIX653

FIX653 bouwt uitsluitend voort op FIX652 CSV-only Library. Er is nog steeds precies één actieve catalogusbron: de laatst gepubliceerde Admin-CSV.

## Gewijzigd
- `app/catalog_importer.py`: deterministische `classify_catalog_presentation()` met `visualFamily`, `visualTags`, `colorGroup`, `searchTags`.
- `app/server_py.py`: normaliseert deze metadata ook voor reeds bestaande FIX652-records; publieke contract bevat alleen veilige presentatievelden.
- `app/decor_library.js`: tegelzoekfunctie, multi-tag filters, Textiel-filter, automatisch lazy-loaden, header/footer-overlap fixes.
- `app/toolA.html`: legacy suggestielijst uitgeschakeld, live public catalog normaliseert nieuwe velden, asset cache-bust `decor_library.js?v=653`.

## Belangrijke invarianten
- Interne artikelcodes blijven uitsluitend Admin/backend.
- Publieke materiaal-ID blijft `decor_<random>`.
- Alleen 18/19/20 mm.
- CSV verkoopprijs incl. BTW blijft autoritatief voor materiaal.
- Geen algemene materiaalprijsfactor.
- Overige Admin-kosten blijven apart instelbaar.
- Afbeeldings-URL blijft backend-bron en wordt niet publiek als bron-URL geleverd.
- CSV-update vervangt de actieve catalogus volgens FIX652-regels.

## Filtermodel
`visualFamily` is de primaire presentatiecategorie. `visualTags` mag meerdere families bevatten zodat een product bijvoorbeeld primair Uni is maar door een duidelijke Quercia/Sherwood/Maloja-structuur ook onder Hout gevonden kan worden. `searchTags` bevat alleen publieke termen/synoniemen, nooit SKU/artikelnummer.

## UX
Desktop gebruikt de bestaande rechter `#matSearch`, maar resultaten verschijnen uitsluitend als tegels links. `#matSuggest` wordt niet meer gerenderd. Mobiel blijft `#decorMobileSearch` gebruiken; beide inputs sturen dezelfde query. Lazy-loaden gebruikt IntersectionObserver en een scroll fallback. De grid krijgt extra bottom padding zodat de vaste wizard-footer de laatste rij niet afdekt.
