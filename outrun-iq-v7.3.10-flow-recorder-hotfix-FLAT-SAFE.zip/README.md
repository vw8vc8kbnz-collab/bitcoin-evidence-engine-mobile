Outrun IQ v7.3.10 Flow Recorder

Flat root ZIP: package.json staat direct in de ZIP-root.
Belangrijk: data/, .env, runtime_uploads/ en public/uploads/ niet overschrijven bij deploy.

Gebruik /beheer om een Flow Recorder testsessie te starten en daarna JSONL of Replay HTML te downloaden.
