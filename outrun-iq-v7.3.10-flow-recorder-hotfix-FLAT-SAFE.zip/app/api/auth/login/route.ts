import { NextResponse, type NextRequest } from "next/server";
import { read } from "@/lib/store";
import { verifyPassword, createSession, SESSION_COOKIE, rateLimit, isApprovedPartner } from "@/lib/auth";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const e = String(b.email ?? "").trim().toLowerCase();
  const pass = String(b.password ?? "");
  if (!rateLimit(`login:${e}`, 8, 10 * 60_000)) {
    return NextResponse.json({ error: "Te veel pogingen. Wacht 10 minuten." }, { status: 429 });
  }
  if (b.accountType !== "zakelijk" && b.accountType !== "persoonlijk") {
    return NextResponse.json({ error: "Kies eerst of je persoonlijk of zakelijk wilt inloggen. Ververs de app als je deze melding blijft zien." }, { status: 400 });
  }
  const requested = b.accountType === "zakelijk" ? "zakelijk" : "persoonlijk";
  const db = await read();
  const candidates = db.users.filter(x => x.email === e);

  // Gesloten werelden: dezelfde mail kan in oude testdata meerdere accounts hebben.
  // De login-keuze bepaalt daarom expliciet welk accounttype gebruikt mag worden.
  // Zakelijk mag nooit naar admin of consument vallen; persoonlijk mag nooit naar partner vallen.
  const u = requested === "zakelijk"
    ? candidates.find(x => x.role === "partner")
    : candidates.find(x => x.role !== "partner");

  if (!u || !verifyPassword(pass, u.salt, u.passHash)) {
    return NextResponse.json({
      error: requested === "zakelijk"
        ? "Geen zakelijk partneraccount gevonden met deze gegevens"
        : "E-mail of wachtwoord onjuist"
    }, { status: 401 });
  }

  const { token, expires } = await createSession(u.id);
  const res = NextResponse.json({ ok: true, role: u.role, partner: isApprovedPartner(u), partnerPending: u.partnerProfile?.status === "pending", name: u.name });
  res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", expires });
  return res;
}
