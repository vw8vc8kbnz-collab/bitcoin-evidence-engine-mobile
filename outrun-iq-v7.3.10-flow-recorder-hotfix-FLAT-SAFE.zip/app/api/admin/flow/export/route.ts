import { NextResponse, type NextRequest } from "next/server";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import type { FlowEvent } from "@/lib/types";
export const runtime = "nodejs";

const esc = (s: unknown) => String(s ?? "").replace(/[&<>\"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c] as string));
function jsonl(events: FlowEvent[]) { return events.map(e => JSON.stringify(e)).join("\n") + (events.length ? "\n" : ""); }
function replayHtml(events: FlowEvent[]) {
  const sessions = [...new Set(events.map(e => e.sessionId))];
  const snapshots = events.filter(e => e.type === "snapshot" && e.html);
  const first = snapshots[0]?.html || "<main style='padding:24px;font-family:sans-serif'>Geen snapshots gevonden. Download JSONL voor click/API-log.</main>";
  return `<!doctype html><html lang="nl"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>Outrun Flow Replay</title><style>body{margin:0;background:#0b1114;color:#f8f8f3;font-family:system-ui,-apple-system,sans-serif}.bar{position:sticky;top:0;z-index:3;background:#10191d;padding:14px 16px;border-bottom:1px solid #273238;display:flex;gap:12px;align-items:center;flex-wrap:wrap}button,select{border:1px solid #344247;background:#172328;color:#fff;border-radius:12px;padding:10px 12px;font-weight:700}.wrap{display:grid;grid-template-columns:1fr 360px;gap:0;height:calc(100vh - 66px)}iframe{width:100%;height:100%;border:0;background:#f3f1eb}.side{overflow:auto;border-left:1px solid #273238;background:#0e171b}.ev{padding:10px 12px;border-bottom:1px solid #202c31;cursor:pointer}.ev:hover{background:#172328}.t{color:#f1a632;font-size:11px;font-weight:800;letter-spacing:.08em}.m{font-size:13px;color:#cbd3d8}.dot{display:inline-block;width:8px;height:8px;border-radius:99px;background:#2dd4bf;margin-right:6px}@media(max-width:900px){.wrap{grid-template-columns:1fr}.side{height:42vh;border-left:0;border-top:1px solid #273238}}</style></head><body><div class="bar"><b>Outrun Flow Replay</b><span>${events.length} events · ${sessions.length} sessie(s)</span><select id="session">${sessions.map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join("")}</select><button id="prev">Vorige snapshot</button><button id="next">Volgende snapshot</button></div><div class="wrap"><iframe id="frame" sandbox="allow-same-origin"></iframe><div class="side" id="events"></div></div><script>const all=${JSON.stringify(events).replace(/<\//g,"<\\/")};let curSession=document.getElementById('session').value;let snaps=[];let idx=0;const f=document.getElementById('frame'), list=document.getElementById('events');function render(){const evs=all.filter(e=>e.sessionId===curSession);snaps=evs.filter(e=>e.type==='snapshot'&&e.html);if(!snaps.length)snaps=[{html:${JSON.stringify(first)},at:'',path:''}];idx=Math.max(0,Math.min(idx,snaps.length-1));f.srcdoc=snaps[idx].html;list.innerHTML=evs.map((e,i)=>'<div class="ev" data-i="'+i+'"><div class="t"><span class="dot"></span>'+e.type+' · '+(e.at||'').slice(11,19)+' · '+(e.path||'')+'</div><div class="m">'+(e.label||e.text||e.target||'').replace(/[&<>]/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[m]))+'</div></div>').join('');list.querySelectorAll('.ev').forEach(el=>el.onclick=()=>{const e=evs[+el.dataset.i];const j=snaps.findIndex(s=>s.at>=e.at);if(j>=0){idx=j;f.srcdoc=snaps[idx].html;}})}document.getElementById('session').onchange=e=>{curSession=e.target.value;idx=0;render()};document.getElementById('prev').onclick=()=>{idx=Math.max(0,idx-1);render()};document.getElementById('next').onclick=()=>{idx=Math.min(snaps.length-1,idx+1);render()};render();</script></body></html>`;
}

export async function GET(req: NextRequest) {
  const me = await getUser();
  const pin = req.nextUrl.searchParams.get("pin");
  const viaPin = !!process.env.ADMIN_PIN && pin === process.env.ADMIN_PIN;
  if (me?.role !== "admin" && !viaPin) return NextResponse.json({ error: "Geen toegang" }, { status: 401 });
  const format = req.nextUrl.searchParams.get("format") === "html" ? "html" : "jsonl";
  const session = req.nextUrl.searchParams.get("session");
  const db = await read();
  let events = [...(db.flowEvents ?? [])].sort((a, b) => a.at.localeCompare(b.at));
  if (session) events = events.filter(e => e.sessionId === session);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const body = format === "html" ? replayHtml(events) : jsonl(events);
  return new NextResponse(body, { headers: { "Content-Type": format === "html" ? "text/html; charset=utf-8" : "application/x-ndjson; charset=utf-8", "Content-Disposition": `attachment; filename="outrun-flow-${stamp}.${format === "html" ? "html" : "jsonl"}"`, "Cache-Control": "no-store" } });
}
