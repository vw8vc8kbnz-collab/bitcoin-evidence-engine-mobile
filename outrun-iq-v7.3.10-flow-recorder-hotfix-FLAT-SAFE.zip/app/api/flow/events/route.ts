import { NextResponse, type NextRequest } from "next/server";
import { mutate } from "@/lib/store";
import { getUser } from "@/lib/auth";
import type { FlowEvent } from "@/lib/types";
export const runtime = "nodejs";

const allowedTypes = new Set(["start", "stop", "route", "click", "submit", "error", "snapshot", "api", "visibility"]);
const text = (v: unknown, max = 300) => String(v ?? "").replace(/\s+/g, " ").trim().slice(0, max);
function clean(input: any, userId?: string, role?: any): FlowEvent | null {
  if (!input || typeof input !== "object") return null;
  const type = String(input.type || "");
  if (!allowedTypes.has(type)) return null;
  const sessionId = text(input.sessionId, 80);
  if (!sessionId) return null;
  const ev: FlowEvent = {
    id: text(input.id, 40) || Math.random().toString(36).slice(2, 10),
    sessionId,
    at: text(input.at, 40) || new Date().toISOString(),
    userId,
    role,
    path: text(input.path, 300) || "/",
    type: type as FlowEvent["type"],
    label: text(input.label, 240) || undefined,
    target: text(input.target, 300) || undefined,
    text: text(input.text, 300) || undefined,
    x: Number.isFinite(Number(input.x)) ? Math.round(Number(input.x)) : undefined,
    y: Number.isFinite(Number(input.y)) ? Math.round(Number(input.y)) : undefined,
    scrollY: Number.isFinite(Number(input.scrollY)) ? Math.round(Number(input.scrollY)) : undefined,
    viewport: input.viewport && typeof input.viewport === "object" ? { w: Math.round(Number(input.viewport.w) || 0), h: Math.round(Number(input.viewport.h) || 0), dpr: Number(input.viewport.dpr) || undefined } : undefined,
    ua: text(input.ua, 260) || undefined,
    html: typeof input.html === "string" ? input.html.slice(0, 60000) : undefined,
    meta: input.meta && typeof input.meta === "object" ? Object.fromEntries(Object.entries(input.meta).slice(0, 20).map(([k, v]) => [text(k, 40), typeof v === "string" ? text(v, 240) : (typeof v === "number" || typeof v === "boolean" || v == null ? v as any : text(String(v), 120))])) : undefined,
  };
  return ev;
}

export async function POST(req: NextRequest) {
  const me = await getUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false }, { status: 400 }); }
  const ev = clean(body, me?.id, me?.role);
  if (!ev) return NextResponse.json({ ok: false }, { status: 400 });
  await mutate(db => {
    (db.flowEvents ??= []).push(ev);
    if (db.flowEvents.length > 20000) db.flowEvents = db.flowEvents.slice(-20000);
  });
  return NextResponse.json({ ok: true });
}
