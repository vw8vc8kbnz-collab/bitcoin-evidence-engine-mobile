"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { usePathname } from "next/navigation";

type FlowEvent = {
  id: string;
  sessionId: string;
  at: string;
  path: string;
  type: "start" | "stop" | "route" | "click" | "submit" | "error" | "snapshot" | "api" | "visibility";
  label?: string;
  target?: string;
  text?: string;
  x?: number;
  y?: number;
  scrollY?: number;
  viewport?: { w: number; h: number; dpr?: number };
  ua?: string;
  html?: string;
  meta?: Record<string, string | number | boolean | null | undefined>;
};

const ACTIVE = "oiq_flow_active";
const SESSION = "oiq_flow_session";
const EVENTS = "oiq_flow_events";
const MAX_LOCAL = 1500;

function rid() { return Math.random().toString(36).slice(2, 10); }
function now() { return new Date().toISOString(); }
function safeText(s?: string | null) { return (s ?? "").replace(/\s+/g, " ").trim().slice(0, 180); }
function selectorFor(el: Element | null) {
  if (!el) return "";
  const parts: string[] = [];
  let n: Element | null = el;
  for (let i = 0; n && i < 4; i++, n = n.parentElement) {
    const id = n.id ? `#${n.id}` : "";
    const cls = n.className && typeof n.className === "string" ? "." + n.className.split(/\s+/).filter(Boolean).slice(0, 2).join(".") : "";
    parts.unshift(`${n.tagName.toLowerCase()}${id}${cls}`.slice(0, 80));
  }
  return parts.join(" > ");
}
function maskClone(root: HTMLElement) {
  const clone = root.cloneNode(true) as HTMLElement;
  clone.querySelectorAll("input, textarea, select").forEach((el: any) => {
    const type = String(el.getAttribute("type") || "").toLowerCase();
    const name = String(el.getAttribute("name") || el.getAttribute("id") || "").toLowerCase();
    const sensitive = ["password", "pin", "token", "secret", "key", "card", "iban", "email", "address", "postcode"].some(k => type.includes(k) || name.includes(k));
    if ("value" in el) el.setAttribute("value", sensitive ? "•••" : String(el.value ?? "").slice(0, 80));
    el.textContent = sensitive ? "•••" : safeText(el.textContent);
  });
  clone.querySelectorAll("script, style, noscript").forEach(el => el.remove());
  clone.querySelectorAll("[data-secret], [data-token]").forEach(el => { el.textContent = "•••"; });
  return clone.innerHTML.slice(0, 60000);
}
function viewport() { return { w: window.innerWidth, h: window.innerHeight, dpr: window.devicePixelRatio || 1 }; }

export function FlowRecorder() {
  const pathname = usePathname();
  const [active, setActive] = useState(false);
  const [count, setCount] = useState(0);
  const sessionRef = useRef<string>("");
  const lastSnapshot = useRef(0);

  const api = useMemo(() => ({
    loadEvents(): FlowEvent[] { try { return JSON.parse(localStorage.getItem(EVENTS) || "[]"); } catch { return []; } },
    saveEvents(events: FlowEvent[]) { localStorage.setItem(EVENTS, JSON.stringify(events.slice(-MAX_LOCAL))); setCount(events.length); },
  }), []);

  function persist(ev: FlowEvent) {
    const events = [...api.loadEvents(), ev].slice(-MAX_LOCAL);
    api.saveEvents(events);
    fetch("/api/flow/events", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(ev), keepalive: true }).catch(() => {});
  }

  function emit(type: FlowEvent["type"], extra: Partial<FlowEvent> = {}) {
    if (!sessionRef.current) return;
    persist({
      id: rid(), sessionId: sessionRef.current, at: now(), path: location.pathname + location.search,
      type, scrollY: Math.round(window.scrollY || 0), viewport: viewport(), ua: navigator.userAgent.slice(0, 220), ...extra,
    });
  }

  function snapshot(label = "snapshot") {
    const t = Date.now();
    if (t - lastSnapshot.current < 3000) return;
    lastSnapshot.current = t;
    emit("snapshot", { label, html: maskClone(document.body) });
  }

  useEffect(() => {
    const boot = () => {
      const on = localStorage.getItem(ACTIVE) === "1";
      let sid = localStorage.getItem(SESSION) || "";
      if (on && !sid) { sid = `flow-${Date.now()}-${rid()}`; localStorage.setItem(SESSION, sid); }
      sessionRef.current = sid;
      setActive(on);
      setCount(api.loadEvents().length);
    };
    boot();
    window.addEventListener("storage", boot);
    window.addEventListener("oiq-flow-toggle", boot as EventListener);
    return () => { window.removeEventListener("storage", boot); window.removeEventListener("oiq-flow-toggle", boot as EventListener); };
  }, [api]);

  useEffect(() => {
    if (!active) return;
    emit("route", { label: document.title || pathname });
    setTimeout(() => snapshot("route-snapshot"), 450);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname, active]);

  useEffect(() => {
    if (!active) return;
    const click = (e: MouseEvent | TouchEvent) => {
      const target = (e.target as Element | null)?.closest?.("button,a,input,textarea,select,[role='button'],.card,.orow") as Element | null || (e.target as Element | null);
      const point = "touches" in e && e.touches[0] ? e.touches[0] : ("changedTouches" in e && e.changedTouches[0] ? e.changedTouches[0] : e as MouseEvent);
      emit("click", { target: selectorFor(target), text: safeText(target?.textContent), x: Math.round((point as any).clientX || 0), y: Math.round((point as any).clientY || 0) });
      setTimeout(() => snapshot("after-click"), 700);
    };
    const submit = (e: SubmitEvent) => emit("submit", { target: selectorFor(e.target as Element), text: safeText((e.target as Element)?.textContent) });
    const err = (e: ErrorEvent) => emit("error", { label: e.message, meta: { source: e.filename?.slice(-80) || "", line: e.lineno || 0 } });
    const rej = (e: PromiseRejectionEvent) => emit("error", { label: "unhandledrejection", text: safeText(String(e.reason ?? "")) });
    const vis = () => emit("visibility", { label: document.visibilityState });
    document.addEventListener("click", click, true);
    document.addEventListener("submit", submit, true);
    window.addEventListener("error", err);
    window.addEventListener("unhandledrejection", rej);
    document.addEventListener("visibilitychange", vis);
    const timer = window.setInterval(() => snapshot("interval"), 10000);
    return () => {
      document.removeEventListener("click", click, true); document.removeEventListener("submit", submit, true);
      window.removeEventListener("error", err); window.removeEventListener("unhandledrejection", rej); document.removeEventListener("visibilitychange", vis); window.clearInterval(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  if (!active) return null;
  return (
    <div style={{ position: "fixed", right: 14, bottom: 92, zIndex: 99999, display: "flex", gap: 8, alignItems: "center", padding: "10px 12px", borderRadius: 999, background: "rgba(9,20,23,.88)", color: "#fff", boxShadow: "0 12px 30px rgba(0,0,0,.25)", fontFamily: "var(--mono)", fontSize: 11 }}>
      <span style={{ width: 8, height: 8, borderRadius: 99, background: "#ef4444", boxShadow: "0 0 0 5px rgba(239,68,68,.18)" }} />
      <b>FLOW REC</b><span>{count}</span>
      <button onClick={() => { emit("stop", { label: "handmatig gestopt" }); localStorage.setItem(ACTIVE, "0"); setActive(false); window.dispatchEvent(new Event("oiq-flow-toggle")); }} style={{ border: 0, borderRadius: 999, padding: "5px 8px", fontWeight: 800 }}>STOP</button>
    </div>
  );
}
