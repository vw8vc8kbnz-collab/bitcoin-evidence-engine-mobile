# v7.3.10 — Flow Recorder build hotfix

- Fix TypeScript build error in `lib/auth.ts`: personal buyer role is `consument`, not `buyer`.
- Preserves v7.3.9 Flow Recorder features.

# v7.3.10 — Flow Recorder

- Nieuwe Flow Recorder in Beheer.
- Start/stop testsessie vanuit `/beheer`.
- Floating `FLOW REC` indicator tijdens test.
- Registreert routes, clicks, submits, errors, zichtbaarheid en snapshots.
- Server-side opslag in `db.flowEvents` met max 20.000 events.
- Download vanuit Beheer als JSONL en Replay HTML.
- Lokale JSON-download vanuit beheer voor snelle mobiele test.
- Privacy masking voor wachtwoorden, pins, tokens, adressen/postcodes en gevoelige inputvelden.
- Service-worker cacheversie verhoogd naar v7.3.10.
