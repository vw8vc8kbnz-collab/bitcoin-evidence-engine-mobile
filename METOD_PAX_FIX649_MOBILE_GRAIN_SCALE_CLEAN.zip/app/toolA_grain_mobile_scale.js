(function(){
  'use strict';
  if(window.__FIX649_GRAIN_MOBILE_SCALE__) return;
  window.__FIX649_GRAIN_MOBILE_SCALE__='FIX649_MOBILE_GRAIN_SCALE';

  function mobile(){return !!(window.matchMedia&&window.matchMedia('(max-width:700px)').matches);}
  function esc(v){return typeof _esc==='function'?_esc(v):String(v==null?'':v).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];});}
  function selectedMaterialKey(){try{return grainOverlaySelectedMaterialKey();}catch(_){return '';}}
  function openWidthStore(){
    var key=String(selectedMaterialKey()||'default');
    window.__fix649OpenWidths=window.__fix649OpenWidths||{};
    window.__fix649OpenWidths[key]=window.__fix649OpenWidths[key]||{};
    return window.__fix649OpenWidths[key];
  }
  function refreshAll(){
    try{syncGroupOrders();}catch(_){ }
    try{rebuildGrainEligible();}catch(_){ }
    try{rebuildGrainGroups();}catch(_){ }
    try{renderCart();}catch(_){ }
    try{syncPanelDockChrome();}catch(_){ }
    try{renderExtraPanels();}catch(_){ }
    try{syncChecksFromSelect();}catch(_){ }
    try{drawExtraPreview();}catch(_){ }
    try{drawGrainPreview();}catch(_){ }
    try{setGrainMsg('');}catch(_){ }
  }
  function targetGroup(){
    try{
      ensureStateShape();
      syncSelectedGrainGroupForMaterial();
      var id=String(state&&state.grain&&state.grain.selectedGroupId||'');
      var mk=selectedMaterialKey();
      var g=(state.grain.groups||[]).find(function(x){return String(x&&x.id||'')===id&&String(x&&x.materialKey||'')===String(mk||'');});
      if(!g){
        g=(state.grain.groups||[]).find(function(x){return String(x&&x.materialKey||'')===String(mk||'');})||null;
      }
      if(!g){
        newGroup();
        id=String(state.grain.selectedGroupId||'');
        g=(state.grain.groups||[]).find(function(x){return String(x&&x.id||'')===id;})||null;
      }
      return g;
    }catch(_){return null;}
  }
  function addMany(refs,requested){
    try{
      var g=targetGroup();
      if(!g)return;
      var entries=(refs||[]).map(function(ref){return getGrainEntryByRef(ref);}).filter(Boolean).filter(function(e){return !e.grainGroupId;});
      if(!entries.length)return;
      var count=requested==='all'?entries.length:Math.max(1,Math.min(entries.length,Number(requested)||1));
      var added=0;
      for(var i=0;i<entries.length&&added<count;i++){
        var e=entries[i],w=Number(e.widthCm||0);
        if(!isGrainCapable(e.raw))continue;
        if(g.widthCm&&Number(g.widthCm)!==w){
          try{setGrainMsg('Dit paneel heeft een andere breedte dan de actieve nerf-set. Maak hiervoor een nieuwe nerf-set.');}catch(_){ }
          break;
        }
        if(!g.widthCm)g.widthCm=w;
        var ref=String(e.ref||'');
        if(!ref||g.items.map(String).indexOf(ref)!==-1)continue;
        g.items.push(ref);added++;
      }
      if(added){state.grain.selectedGroupId=g.id;refreshAll();}
    }catch(_){ }
  }

  var originalEligible=typeof rebuildGrainEligible==='function'?rebuildGrainEligible:null;
  var originalGroups=typeof rebuildGrainGroups==='function'?rebuildGrainGroups:null;
  var originalPreview=typeof drawGrainPreview==='function'?drawGrainPreview:null;

  function renderMobileEligible(){
    if(!grainEligible||!grainEligibleCount)return;
    grainEligible.innerHTML='';
    var eligible=getGrainEligibleEntries();
    grainEligibleCount.textContent=String(eligible.length);
    if(grainIncludeExtraToggle)grainIncludeExtraToggle.checked=!!grainExtrasEnabled();
    if(!eligible.length){
      var empty=document.createElement('div');empty.className='help';
      empty.textContent='Geen panelen beschikbaar. Zet nerfrichting aan en voeg minimaal twee panelen met dezelfde breedte toe.';
      grainEligible.appendChild(empty);return;
    }
    var byWidth=new Map();
    eligible.forEach(function(e){var w=Number(e.widthCm||0);if(!byWidth.has(w))byWidth.set(w,[]);byWidth.get(w).push(e);});
    var widths=Array.from(byWidth.keys()).sort(function(a,b){return a-b;});
    var fw=grainWidthSel?grainWidthSel.value:'all';
    if(fw&&fw!=='all')widths=widths.filter(function(w){return String(w)===String(fw);});
    var store=openWidthStore();
    if(widths.length&&!widths.some(function(w){return store[String(w)];}))store[String(widths[0])]=true;

    widths.forEach(function(w){
      var entries=byWidth.get(w)||[];
      var availableCount=entries.filter(function(e){return !e.grainGroupId;}).length;
      var wrap=document.createElement('section');
      wrap.className='fix649WidthAccordion'+(store[String(w)]?' is-open':'');
      var head=document.createElement('button');head.type='button';head.className='fix649WidthHeader';head.setAttribute('aria-expanded',store[String(w)]?'true':'false');
      head.innerHTML='<strong>Breedte '+esc(w)+' cm</strong><span class="fix649WidthCount">'+availableCount+'/'+entries.length+'</span><span class="fix649Chevron">⌄</span>';
      var body=document.createElement('div');body.className='fix649WidthBody';
      head.addEventListener('click',function(){store[String(w)]=!store[String(w)];wrap.classList.toggle('is-open',!!store[String(w)]);head.setAttribute('aria-expanded',store[String(w)]?'true':'false');});
      wrap.appendChild(head);wrap.appendChild(body);

      [{key:'cart',title:'METOD panelen'},{key:'extra',title:'Overige panelen'}].forEach(function(sec){
        var secEntries=entries.filter(function(e){return e.kind===sec.key;});if(!secEntries.length)return;
        var label=document.createElement('div');label.className='fix649SectionLabel';label.textContent=sec.title;body.appendChild(label);
        var displayGroups=_groupGrainDisplayEntries(secEntries).sort(function(a,b){return String(a&&a.rep&&a.rep.label||'').localeCompare(String(b&&b.rep&&b.rep.label||''));});
        displayGroups.forEach(function(group){
          var rep=group.rep,total=Math.max(1,group.items.length),available=group.items.filter(function(x){return !x.grainGroupId;});
          var row=document.createElement('div');row.className='fix649PanelRow';
          var main=document.createElement('div');main.className='fix649PanelMain';
          main.innerHTML='<div class="fix649PanelName">'+esc(rep.label)+'</div><div class="fix649PanelMeta">'+esc(rep.widthCm)+'×'+esc(rep.heightCm)+' cm'+esc(grainDoorDirectionLabel(rep.raw))+esc(grainExtLabel(rep.raw))+(rep.kind==='extra'?' · overig':'')+'</div><div class="fix649PanelAvailability">'+available.length+' van '+total+' beschikbaar</div>';
          var actions=document.createElement('div');actions.className='fix649AddActions';
          [['+1',1,true],['+5',5,false],['Alles','all',false]].forEach(function(spec){
            var btn=document.createElement('button');btn.type='button';btn.className='fix649AddBtn'+(spec[2]?' is-primary':'');btn.textContent=spec[0];btn.disabled=!available.length;
            btn.addEventListener('click',function(ev){ev.stopPropagation();addMany(available.map(function(x){return x.ref;}),spec[1]);});actions.appendChild(btn);
          });
          row.appendChild(main);row.appendChild(actions);body.appendChild(row);
        });
      });
      grainEligible.appendChild(wrap);
    });
  }

  function renderMobileGroups(){
    if(!grainGroups)return;
    grainGroups.innerHTML='';
    var mk=selectedMaterialKey();
    var list=(state.grain.groups||[]).filter(function(g){return !mk||String(g.materialKey||'')===String(mk);});
    syncSelectedGrainGroupForMaterial();
    if(!list.length){var no=document.createElement('div');no.className='help';no.textContent='Nog geen nerf-sets. Maak een set en voeg panelen toe.';grainGroups.appendChild(no);drawGrainPreview();return;}
    list.forEach(function(g){
      var selected=String(state.grain.selectedGroupId||'')===String(g.id||'');
      var wrap=document.createElement('section');wrap.className='fix649GroupAccordion'+(selected?' is-selected':'');wrap.dataset.groupId=g.id;
      var header=document.createElement('div');header.className='fix649GroupHeader';
      var select=document.createElement('button');select.type='button';select.className='fix649GroupSelect';
      select.innerHTML='<span class="fix649GroupTitle">Nerfgroep '+esc(g.id)+'</span><span class="fix649GroupMeta">'+(g.widthCm?('Breedte '+esc(g.widthCm)+' cm'):'Breedte nog niet bepaald')+' · '+g.items.length+' '+(g.items.length===1?'paneel':'panelen')+'</span>';
      var count=document.createElement('span');count.className='fix649WidthCount';count.textContent=String(g.items.length);
      var del=document.createElement('button');del.type='button';del.className='fix649GroupDelete';del.title='Verwijder nerf-set';del.textContent='🗑';
      header.appendChild(select);header.appendChild(count);header.appendChild(del);wrap.appendChild(header);
      var body=document.createElement('div');body.className='fix649GroupBody';
      var hint=document.createElement('div');hint.className='fix649GroupHint';hint.textContent='Tik boven op +1, +5 of Alles om panelen toe te voegen. Gebruik de pijlen voor de volgorde.';body.appendChild(hint);
      if(!g.items.length){var empty=document.createElement('div');empty.className='fix649GroupEmpty';empty.textContent='Nog geen panelen in deze nerf-set.';body.appendChild(empty);}
      else {
        window.__fix649ExpandedGroups=window.__fix649ExpandedGroups||{};
        var expanded=!!window.__fix649ExpandedGroups[String(g.id||'')];
        var visibleItems=expanded?g.items:g.items.slice(0,12);
        visibleItems.forEach(function(ref,order){
          var actualOrder=g.items.indexOf(ref);
          var e=getGrainEntryByRef(ref);if(!e)return;
          var item=document.createElement('div');item.className='fix649GroupItem';
          var main=document.createElement('div');main.innerHTML='<div class="fix649GroupItemName">'+esc(e.label)+'</div><div class="fix649GroupItemMeta">'+esc(e.widthCm)+'×'+esc(e.heightCm)+' cm'+esc(grainDoorDirectionLabel(e.raw))+esc(grainExtLabel(e.raw))+' · positie '+(actualOrder+1)+'/'+g.items.length+'</div>';
          var actions=document.createElement('div');actions.className='fix649GroupActions';
          [['↑','up'],['↓','down'],['×','rm']].forEach(function(spec){var b=document.createElement('button');b.type='button';b.className='miniBtn';b.textContent=spec[0];b.title=spec[1]==='up'?'Omhoog':spec[1]==='down'?'Omlaag':'Verwijderen';b.disabled=(spec[1]==='up'&&actualOrder===0)||(spec[1]==='down'&&actualOrder===g.items.length-1);b.addEventListener('click',function(ev){ev.stopPropagation();if(spec[1]==='up')moveInGroup(g.id,actualOrder,-1);else if(spec[1]==='down')moveInGroup(g.id,actualOrder,1);else removeFromGroup(g.id,ref);});actions.appendChild(b);});
          item.appendChild(main);item.appendChild(actions);body.appendChild(item);
        });
        if(g.items.length>12){
          var more=document.createElement('button');more.type='button';more.className='fix649GroupMore';
          more.textContent=expanded?'Toon minder':'Toon alle '+g.items.length+' panelen';
          more.addEventListener('click',function(ev){ev.stopPropagation();window.__fix649ExpandedGroups[String(g.id||'')]=!expanded;rebuildGrainGroups();});
          body.appendChild(more);
        }
      }
      wrap.appendChild(body);
      select.addEventListener('click',function(){state.grain.selectedGroupId=g.id;rebuildGrainGroups();drawGrainPreview();});
      del.addEventListener('click',function(ev){ev.stopPropagation();state.grain.groups=state.grain.groups.filter(function(x){return x.id!==g.id;});if(state.grain.selectedGroupId===g.id)state.grain.selectedGroupId=state.grain.groups[0]&&state.grain.groups[0].id||null;refreshAll();});
      grainGroups.appendChild(wrap);
    });
  }

  rebuildGrainEligible=function(){if(mobile())return renderMobileEligible();return originalEligible&&originalEligible();};
  rebuildGrainGroups=function(){if(mobile())return renderMobileGroups();return originalGroups&&originalGroups();};
  drawGrainPreview=function(){var out=originalPreview&&originalPreview();syncPreviewSummary();return out;};

  function syncPreviewSummary(){
    var summary=document.getElementById('fix649PreviewSummary');if(!summary)return;
    try{
      var g=(state.grain.groups||[]).find(function(x){return String(x.id||'')===String(state.grain.selectedGroupId||'');});
      summary.textContent=g?('Actieve set: '+g.id+' · '+g.items.length+' '+(g.items.length===1?'paneel':'panelen')+(g.widthCm?' · '+g.widthCm+' cm':'')):'Selecteer een nerf-set om de preview te bekijken.';
    }catch(_){summary.textContent='Selecteer een nerf-set om de preview te bekijken.';}
  }
  function initPreview(){
    var card=document.querySelector('#grainOverlay .grainPreviewCard'),btn=document.getElementById('fix649PreviewToggle');if(!card||!btn)return;
    var open=!!window.__fix649PreviewOpen;card.classList.toggle('fix649PreviewOpen',open);btn.textContent=open?'Verberg preview':'Toon preview';
    btn.addEventListener('click',function(){window.__fix649PreviewOpen=!window.__fix649PreviewOpen;card.classList.toggle('fix649PreviewOpen',!!window.__fix649PreviewOpen);btn.textContent=window.__fix649PreviewOpen?'Verberg preview':'Toon preview';if(window.__fix649PreviewOpen)drawGrainPreview();});
    syncPreviewSummary();
  }
  function rerenderOnViewport(){try{if(document.getElementById('grainOverlay')&&document.getElementById('grainOverlay').style.display!=='none'){rebuildGrainEligible();rebuildGrainGroups();drawGrainPreview();}}catch(_){}}
  function start(){initPreview();try{var mq=window.matchMedia('(max-width:700px)');if(mq.addEventListener)mq.addEventListener('change',rerenderOnViewport);else if(mq.addListener)mq.addListener(rerenderOnViewport);}catch(_){}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
