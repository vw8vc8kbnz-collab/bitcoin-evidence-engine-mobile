from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import math

VERSION = "v10.17.2_specialist_alpha_engines"

REGIME_MULTIPLIER = {
    "bear_trend": 1.3,
    "capitulation": 1.2,
    "bull_trend": 1.0,
    "post_halving_accumulation": 1.0,
    "euphoria_risk": 0.8,
    "transition": 0.6,
}

@dataclass
class AlphaSignal:
    name: str
    score: float
    direction: str
    applies: bool
    probability_hint: float
    ev_hint: float
    n_layers: int
    bucket: str
    contributions: dict = field(default_factory=dict)
    reason: str = ""

    @property
    def tradeable(self) -> bool:
        return self.applies and self.direction in ("LONG", "SHORT") and abs(self.score) > 2.0 and self.n_layers >= 3


def _finite(v, default: Optional[float] = None):
    try:
        x = float(v)
        if math.isfinite(x):
            return x
    except Exception:
        pass
    return default


def _bucket(score: float) -> str:
    if score > 2.0:
        return "strong_bull"
    if score > 0.5:
        return "light_bull"
    if score < -2.0:
        return "strong_bear"
    if score < -0.5:
        return "light_bear"
    return "neutral"


def reversal_alpha(*, regime: str, fear_greed, funding_rate, coinbase_premium_pct, rsi_14) -> AlphaSignal:
    """Claude confluentie-score, intentionally positioned as ReversalAlphaEngine.

    This is NOT the universal engine. It detects rare capitulation/reversal or
    exhaustion contexts where sentiment, leverage and spot-flow agree.
    """
    fg = _finite(fear_greed)
    funding = _finite(funding_rate)
    premium = _finite(coinbase_premium_pct)
    rsi = _finite(rsi_14)
    regime = str(regime or "transition")
    contrib = {}
    layers = 0
    if fg is not None:
        layers += 1
        c = 0.0
        if fg <= 20:
            c = 1.0
        elif fg >= 85:
            c = 1.0
        elif 55 <= fg < 85:
            c = -1.0
        contrib["sentiment"] = c
    if funding is not None:
        layers += 1
        c = 0.0
        if funding < -0.0001:
            c = 1.0
        elif funding > 0.0005:
            c = -1.0
        contrib["funding"] = c
    if premium is not None:
        layers += 1
        c = 0.0
        if regime in ("bear_trend", "capitulation"):
            if premium > 0.1:
                c = 1.5
            elif premium < -0.1:
                c = -0.5
        elif regime == "bull_trend":
            if premium > 0.1:
                c = 0.5
            elif premium < -0.1:
                c = -1.5
        else:
            if premium > 0.1:
                c = 0.3
            elif premium < -0.1:
                c = -0.3
        contrib["spot_flow"] = c
    if rsi is not None:
        layers += 1
        c = 0.0
        if rsi < 20 and regime in ("bear_trend", "transition"):
            c = -1.0
        elif rsi > 80:
            c = 0.5
        contrib["rsi_context"] = c
    raw = sum(contrib.values())
    mult = REGIME_MULTIPLIER.get(regime, 1.0)
    score = raw * mult
    bucket = _bucket(score)
    direction = "LONG" if score > 2.0 else "SHORT" if score < -2.0 else "NONE"
    prob_hint = 0.50 + min(0.18, abs(score) * 0.045)
    ev_hint = max(0.0, abs(score) - 2.0) * 0.75
    contrib["regime_multiplier"] = mult
    reason = "reversal confluence: sentiment/leverage/spot-flow agree" if direction != "NONE" else "no strong reversal confluence"
    return AlphaSignal("reversal", round(score, 3), direction, direction != "NONE", round(prob_hint, 4), round(ev_hint, 4), layers, bucket, {k: round(v, 3) for k, v in contrib.items()}, reason)


def trend_continuation_alpha(*, regime: str, fear_greed, funding_rate, coinbase_premium_pct, rsi_14, return_4=0, return_24=0, volatility_24=0, drawdown_from_ath=0) -> AlphaSignal:
    """TrendContinuationEngine v1.

    Purpose: cover the blind spot Claude identified for 2024/2025 style bull grind,
    healthy pullbacks and spot-led continuation. It is intentionally conservative
    and must be validated in Time Machine before production push alerts.
    """
    regime = str(regime or "transition")
    fg = _finite(fear_greed, 50.0)
    funding = _finite(funding_rate, 0.0)
    premium = _finite(coinbase_premium_pct, 0.0)
    rsi = _finite(rsi_14, 50.0)
    r4 = _finite(return_4, 0.0)
    r24 = _finite(return_24, 0.0)
    vol = abs(_finite(volatility_24, 0.0))
    dd = _finite(drawdown_from_ath, 0.0)
    contrib = {}
    layers = 0

    # Applies mainly to bull/post-halving/recovery-like states; in transition it can
    # only be a watch signal if price/flow are strong.
    regime_ok = regime in ("bull_trend", "post_halving_accumulation", "euphoria_risk")
    if regime_ok:
        contrib["regime_context"] = 1.0; layers += 1
    elif regime == "transition" and r24 > 1.2 and rsi >= 55 and premium > 0.05:
        contrib["regime_context"] = 0.35; layers += 1
    else:
        contrib["regime_context"] = -0.5; layers += 1

    # Trend structure: continuation wants 24h positive and short-term not collapsing.
    c = 0.0
    if r24 > 1.0 and r4 > -0.8:
        c = 1.0
    elif r24 > 0.25 and r4 > -1.5:
        c = 0.5
    elif r24 < -1.0:
        c = -1.0
    contrib["trend_structure"] = c; layers += 1

    # Pullback quality: healthy bull continuation often has RSI 45-72, not panic.
    c = 0.0
    if 48 <= rsi <= 72:
        c = 0.8
    elif rsi > 80:
        c = 0.35  # momentum can continue, but overheated
    elif rsi < 38:
        c = -0.6
    contrib["rsi_trend_context"] = c; layers += 1

    # Spot-led validation.
    c = 0.0
    if premium > 0.10:
        c = 1.1
    elif premium > 0.03:
        c = 0.45
    elif premium < -0.10:
        c = -1.2
    contrib["coinbase_spot_flow"] = c; layers += 1

    # Funding: neutral/light positive is fine, extreme positive is danger.
    c = 0.0
    if -0.00005 <= funding <= 0.00035:
        c = 0.7
    elif funding < -0.0001:
        c = 0.25
    elif funding > 0.00065:
        c = -1.0
    contrib["funding_health"] = c; layers += 1

    # Sentiment: continuation likes greed, but not mid fear. Extreme greed can be momentum.
    c = 0.0
    if fg >= 70:
        c = 0.6
    elif 40 <= fg < 70:
        c = 0.25
    elif 20 <= fg < 40:
        c = -0.55
    contrib["sentiment_trend"] = c; layers += 1

    # Penalize deep drawdown unless post-crash recovery is classified elsewhere.
    if dd < -55 and regime != "post_halving_accumulation":
        contrib["drawdown_penalty"] = -0.7

    # Volatility: very high vol often means reversal/trap, not clean continuation.
    if vol > 2.8 and regime == "bull_trend":
        contrib["volatility_overheat"] = -0.35

    score = sum(contrib.values())
    # Keep continuation score on similar scale to reversal, but never use raw max();
    # downstream selector must compare calibrated EV only.
    bucket = _bucket(score)
    direction = "LONG" if score > 2.0 else "NONE"
    prob_hint = 0.50 + min(0.16, max(0.0, score - 1.0) * 0.040)
    ev_hint = max(0.0, score - 2.0) * 0.55
    return AlphaSignal("trend_continuation", round(score,3), direction, direction == "LONG", round(prob_hint,4), round(ev_hint,4), layers, bucket, {k:round(v,3) for k,v in contrib.items()}, "healthy trend continuation / pullback confluence" if direction == "LONG" else "no strong continuation confluence")


def classify_setup(reversal: AlphaSignal, continuation: AlphaSignal) -> str:
    """Gating classifier: abstain unless a specialist truly applies.

    Do NOT max over raw scores. Prefer the specialist that applies with stronger
    calibrated EV hint; if neither applies, return none.
    """
    candidates = [s for s in (reversal, continuation) if s.applies and s.direction != "NONE" and s.ev_hint > 0]
    if not candidates:
        return "none"
    best = max(candidates, key=lambda s: s.ev_hint)
    return best.name
