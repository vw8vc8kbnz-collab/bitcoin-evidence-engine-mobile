from __future__ import annotations

import csv
import json
import time
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl
from app.db.database import db


def _safe(obj: Any) -> Any:
    try:
        import math
        if obj is None or isinstance(obj, (str, bool, int)):
            return obj
        if isinstance(obj, float):
            return obj if math.isfinite(obj) else None
        if isinstance(obj, dict):
            return {str(k): _safe(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [_safe(v) for v in obj]
        if hasattr(obj, 'item'):
            return _safe(obj.item())
    except Exception:
        pass
    return str(obj)


class RuntimePathAuditService:
    """v10.17.3 runtime + path audit.

    This service is deliberately diagnostic only: it does not change alpha logic,
    thresholds, native decisions, forecast results or Time Machine evaluation.
    It writes the A-D audit bundle Claude requested so the native/Python boundary
    can be decided from measurements instead of assumptions.
    """

    VERSION = "v10.17.3_runtime_path_audit"

    HOT_FEATURES_USED_BY_NATIVE = [
        "rsi_14", "funding_rate", "open_interest_change_24h", "long_short_ratio",
        "taker_buy_sell_ratio", "fear_greed", "spot_premium_coinbase_pct",
        "volume_zscore", "drawdown_from_ath", "data_completeness", "regime",
    ]

    MACRO_FEATURES = [
        "spx_close", "spx_ret_1d", "ndq_close", "ndq_ret_1d",
        "dxy_close", "dxy_ret_1d", "gold_close", "gold_ret_1d",
    ]

    def write_audit_bundle(self, d: Path, *, batch_id: str, count: int, native: dict, items: list[dict], summary: dict) -> None:
        d.mkdir(parents=True, exist_ok=True)
        started = time.perf_counter()
        runtime = self.runtime_profile(batch_id=batch_id, count=count, native=native, summary=summary)
        path = self.path_audit()
        datasets = self.dataset_audit()
        walk = self.walkforward_audit(batch_id=batch_id, items=items, native=native)
        twin = self.twin_audit(native=native, items=items)
        handoff = self.claude_handoff(runtime, path, datasets, walk, twin)

        (d / "runtime_profile.json").write_text(json.dumps(_safe(runtime), ensure_ascii=False, indent=2), encoding="utf-8")
        self._write_csv(d / "runtime_profile.csv", runtime.get("phase_rows", []))
        (d / "path_audit.json").write_text(json.dumps(_safe(path), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "path_audit_forecast.txt").write_text(path.get("forecast_text", ""), encoding="utf-8")
        (d / "path_audit_tm.txt").write_text(path.get("time_machine_text", ""), encoding="utf-8")
        (d / "dataset_audit.json").write_text(json.dumps(_safe(datasets), ensure_ascii=False, indent=2), encoding="utf-8")
        self._write_csv(d / "dataset_audit.csv", datasets.get("rows", []))
        (d / "walkforward_audit.json").write_text(json.dumps(_safe(walk), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "walkforward_audit.txt").write_text(walk.get("text", ""), encoding="utf-8")
        (d / "twin_audit.json").write_text(json.dumps(_safe(twin), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "CLAUDE_HANDOFF_RUNTIME_PATH_AUDIT.txt").write_text(handoff, encoding="utf-8")
        append_jsonl("runtime_path_audit.jsonl", {"event":"runtime_path_audit_written_v10173", "batch_id":batch_id, "duration_ms": int((time.perf_counter()-started)*1000)})

    def _write_csv(self, path: Path, rows: list[dict]) -> None:
        if not rows:
            path.write_text("", encoding="utf-8")
            return
        keys = []
        for r in rows:
            for k in r.keys():
                if k not in keys:
                    keys.append(k)
        with path.open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=keys)
            w.writeheader(); w.writerows([{k: _safe(r.get(k)) for k in keys} for r in rows])

    def runtime_profile(self, *, batch_id: str, count: int, native: dict, summary: dict) -> dict:
        tm = dict(native.get("python_runtime_profile") or native.get("runtime_profile") or {})
        native_prof = dict(native.get("native_runtime_profile") or {})
        rows = []
        def add(phase: str, ms: Any, source: str, notes: str = ""):
            try:
                v = float(ms or 0)
            except Exception:
                v = 0.0
            rows.append({"phase": phase, "elapsed_ms": round(v, 3), "source": source, "notes": notes})
        # Python-orchestration phases around Random1000.
        add("load_candles_from_duckdb", tm.get("load_candles_ms"), "python", "DuckDB read of Binance 1H candles")
        add("native_tm_random_total", tm.get("native_random_ms") or native.get("native_bridge_elapsed_ms") or native.get("elapsed_ms"), "native_bridge", "Entire native Time Machine call as seen by Python")
        add("native_candle_cache_csv", native_prof.get("candle_cache_ms"), "python/native_bridge", "Preparing cached candle CSV for native core")
        add("native_feature_state_export", native_prof.get("feature_cache_ms"), "python/native_bridge", "Exporting feature/state matrix for native core")
        add("native_weight_export", native_prof.get("weights_cache_ms"), "python/native_bridge", "Adaptive/trusted weight CSV export if active")
        add("native_exec", native_prof.get("native_exec_ms") or native.get("native_bridge_elapsed_ms") or native.get("elapsed_ms"), "c++/go", "Compiled native core process time")
        add("two_pass_enrichment", tm.get("enrichment_ms"), "python", "Walk-forward reliability/confidence enrichment")
        add("trade_setup_selector", tm.get("selector_ms"), "python", "TradeSetupSelector/alert-quality annotation")
        add("summary_reliability", tm.get("summary_ms"), "python", "Summary + OOS reliability calculation")
        add("persist_tests_learning", tm.get("persist_ms"), "python/duckdb", "Persist time_machine_tests + learning warehouse")
        add("export_zip", tm.get("export_ms"), "python", "ZIP/CSV export creation")
        add("total_random_call", tm.get("total_ms"), "python", "Full TimeMachineService.random_tests duration")
        total = max(float(tm.get("total_ms") or 0), sum(r["elapsed_ms"] for r in rows if r["phase"] != "total_random_call"), 1.0)
        for r in rows:
            r["pct_of_total"] = round((float(r.get("elapsed_ms") or 0) / total) * 100.0, 3)
            r["ms_per_random_point"] = round(float(r.get("elapsed_ms") or 0) / max(1, int(count or 1)), 3)
            r["ms_per_horizon_eval"] = round(float(r.get("elapsed_ms") or 0) / max(1, int(count or 1) * len(getattr(settings, "horizons", []) or [1])), 4)
        return {
            "ok": True, "engine_version": settings.engine_version, "audit_version": self.VERSION,
            "batch_id": batch_id, "count": int(count or 0), "horizons": list(getattr(settings, "horizons", []) or []),
            "total_ms_reference": round(total, 3), "phase_rows": rows,
            "native_reported_elapsed_ms": native.get("elapsed_ms"),
            "native_bridge_elapsed_ms": native.get("native_bridge_elapsed_ms"),
            "expectation_to_validate": "Claude expected twin/search + feature build to dominate runtime and decision layer to be small; use this file to verify from real run.",
        }

    def path_audit(self) -> dict:
        forecast_steps = [
            {"step": 1, "function": "ForecastService.create_run", "file": "app/services/forecast_service.py", "language": "Python", "role": "orchestrator"},
            {"step": 2, "function": "FeatureEngine.rebuild", "file": "app/engine/feature_engine.py", "language": "Python", "role": "state/feature refresh"},
            {"step": 3, "function": "NativeCoreService.tm_single", "file": "app/services/native_core_service.py", "language": "Python bridge -> native", "role": "mandatory compiled core call"},
            {"step": 4, "function": "native_core/bin/bee_native_core tm_single", "file": "native_core/go_src or native_core/src", "language": "compiled native", "role": "forecast horizon items"},
            {"step": 5, "function": "_normalise_forecast_item", "file": "app/services/forecast_service.py", "language": "Python", "role": "format/normalize native output; no Python model fallback"},
            {"step": 6, "function": "forecast_runs / forecast_items insert", "file": "app/services/forecast_service.py", "language": "Python/DuckDB", "role": "persistence/API"},
        ]
        tm_steps = [
            {"step": 1, "function": "TimeMachineService.random_tests", "file": "app/services/time_machine_service.py", "language": "Python", "role": "batch orchestrator"},
            {"step": 2, "function": "DuckDB raw_candles read", "file": "app/services/time_machine_service.py", "language": "Python/DuckDB", "role": "historical 1H candle load"},
            {"step": 3, "function": "NativeCoreService.tm_random", "file": "app/services/native_core_service.py", "language": "Python bridge -> native", "role": "mandatory compiled core call"},
            {"step": 4, "function": "native_core/bin/bee_native_core tm_random", "file": "native_core/go_src or native_core/src", "language": "compiled native", "role": "random cutoffs/twins/horizon items"},
            {"step": 5, "function": "_enrich_native_random_items_two_pass", "file": "app/services/time_machine_service.py", "language": "Python", "role": "walk-forward reliability/confidence enrichment"},
            {"step": 6, "function": "TradeSetupSelector.select_many", "file": "app/services/trade_setup_selector.py", "language": "Python", "role": "setup/alert annotation; shared selector class when invoked"},
            {"step": 7, "function": "_persist_test_items / learning warehouse", "file": "app/services/time_machine_service.py", "language": "Python/DuckDB", "role": "persistence"},
            {"step": 8, "function": "TimeMachineExportService.write_random_batch", "file": "app/services/time_machine_export_service.py", "language": "Python", "role": "CSV/ZIP export"},
        ]
        divergences = [
            {"area": "forecast_vs_random_tm", "status": "partial_shared", "detail": "Both require NativeCoreService and no Python fallback for initial horizon predictions. Time Machine still performs Python two-pass enrichment and TradeSetupSelector/export analytics after native items; Forecast normalizes native items for live UI/persistence."},
            {"area": "single_click_tm", "status": "needs_review", "detail": "Single-click Time Machine may still have richer/manual paths; compare path_audit_tm.txt with code before relying on it as identical to Random1000."},
            {"area": "twin_implementation", "status": "native_required_for_tm_forecast", "detail": "Forecast tm_single and Random tm_random both call the compiled native core. Python HistoricalTwinFinder still exists in codebase; audit should verify it is diagnostics-only and not live fallback."},
        ]
        forecast_text = self._steps_to_text("Forecast path", forecast_steps)
        tm_text = self._steps_to_text("Time Machine Random path", tm_steps) + "\n\nDivergence points:\n" + "\n".join(f"- {d['area']}: {d['status']} — {d['detail']}" for d in divergences)
        return {"ok": True, "shared_path_claim": "partially true; native prediction core is shared, post-processing differs and must be consolidated if desired", "forecast_steps": forecast_steps, "time_machine_random_steps": tm_steps, "divergence_points": divergences, "forecast_text": forecast_text, "time_machine_text": tm_text}

    def _steps_to_text(self, title: str, steps: list[dict]) -> str:
        lines = [title, "=" * len(title)]
        for s in steps:
            lines.append(f"{s['step']}. {s['function']} [{s['language']}] — {s['role']} ({s['file']})")
        return "\n".join(lines) + "\n"

    def _table_columns(self, table: str) -> set[str]:
        try:
            rows = db.fetchall(f"PRAGMA table_info('{table}')")
            return {str(r[1]) for r in rows or []}
        except Exception:
            return set()

    def _feature_coverage(self, col: str) -> dict:
        cols = self._table_columns("features")
        if col not in cols:
            return {"exists": False, "rows": 0, "non_null_rows": 0, "coverage_pct": 0.0, "min_ts": None, "max_ts": None}
        try:
            r = db.fetchone(f"SELECT COUNT(*), SUM(CASE WHEN {col} IS NOT NULL THEN 1 ELSE 0 END), MIN(CASE WHEN {col} IS NOT NULL THEN timestamp_ms ELSE NULL END), MAX(CASE WHEN {col} IS NOT NULL THEN timestamp_ms ELSE NULL END) FROM features WHERE interval='1h'")
            total = int(r[0] or 0) if r else 0
            nn = int(r[1] or 0) if r else 0
            return {"exists": True, "rows": total, "non_null_rows": nn, "coverage_pct": round((nn/max(1,total))*100.0, 3), "min_ts": int(r[2]) if r and r[2] is not None else None, "max_ts": int(r[3]) if r and r[3] is not None else None}
        except Exception as exc:
            return {"exists": True, "error": str(exc)[:300]}

    def dataset_audit(self) -> dict:
        specs = [
            ("Binance candles", "raw_candles", None, "core price backbone", True),
            ("Fear & Greed", "features", "fear_greed", "sentiment", True),
            ("Funding", "features", "funding_rate", "futures/leverage", True),
            ("Coinbase premium", "features", "spot_premium_coinbase_pct", "spot flow", True),
            ("Kraken premium", "features", "spot_premium_kraken_pct", "cross exchange", False),
            ("S&P 500", "features", "spx_close", "macro", False),
            ("S&P 1d return", "features", "spx_ret_1d", "macro", False),
            ("Nasdaq", "features", "ndq_close", "macro", False),
            ("DXY", "features", "dxy_close", "macro", False),
            ("Gold", "features", "gold_close", "macro", False),
        ]
        rows=[]
        for name, table, col, group, used_native in specs:
            if table == "raw_candles":
                try:
                    r = db.fetchone("SELECT COUNT(*), MIN(open_time), MAX(open_time) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
                    total = int(r[0] or 0) if r else 0
                    cov = {"exists": total > 0, "rows": total, "non_null_rows": total, "coverage_pct": 100.0 if total else 0.0, "min_ts": int(r[1]) if r and r[1] is not None else None, "max_ts": int(r[2]) if r and r[2] is not None else None}
                except Exception as exc:
                    cov = {"exists": False, "error": str(exc)[:300]}
            else:
                cov = self._feature_coverage(str(col))
            rows.append({
                "dataset": name, "group": group, "feature_column": col or "raw_candles",
                "present_in_db_or_features": bool(cov.get("exists")),
                "coverage_pct": cov.get("coverage_pct"), "rows": cov.get("rows"), "non_null_rows": cov.get("non_null_rows"),
                "min_ts": cov.get("min_ts"), "max_ts": cov.get("max_ts"),
                "used_in_native_state_export_now": bool(col in self.HOT_FEATURES_USED_BY_NATIVE or name == "Binance candles"),
                "used_in_decision_or_alert_now": bool(used_native),
                "note": "Macro columns may be uploaded but are not active until feature schema/native export uses them." if name in ("S&P 500","S&P 1d return","Nasdaq","DXY","Gold") else "",
            })
        active = [r["dataset"] for r in rows if r.get("used_in_decision_or_alert_now")]
        return {"ok": True, "engine_version": settings.engine_version, "rows": rows, "active_prediction_datasets": active, "macro_active": any(r["dataset"] in ("S&P 500","Nasdaq","DXY","Gold") and r.get("used_in_decision_or_alert_now") for r in rows)}

    def walkforward_audit(self, *, batch_id: str, items: list[dict], native: dict) -> dict:
        rows=[]
        future_leaks=[]
        try:
            cutoffs = [int(i.get("cutoff_ms") or i.get("timestamp_ms") or 0) for i in items[:500] if i.get("cutoff_ms") or i.get("timestamp_ms")]
        except Exception:
            cutoffs=[]
        max_feature_ts_after = None
        if cutoffs:
            sample_min = min(cutoffs)
            try:
                r = db.fetchone("SELECT MAX(timestamp_ms) FROM features WHERE interval='1h' AND timestamp_ms>?", [sample_min])
                max_feature_ts_after = int(r[0]) if r and r[0] is not None else None
            except Exception:
                pass
        # This is an audit statement of mechanisms plus checks that can be verified from code and export.
        checks = [
            {"area":"feature_snapshot", "safe_claim":"native feature CSV exports full matrix but native tm_random must use only rows <= cutoff internally", "status":"requires_native_core_verification", "evidence":"Native bridge supplies full feature CSV for speed; cutoff enforcement must be inside compiled core."},
            {"area":"twin_search", "safe_claim":"historical matches must be timestamp < cutoff", "status":"requires_native_core_verification", "evidence":"tm_random runs in compiled core; export includes cutoffs but not all candidate twin timestamps unless native emits them."},
            {"area":"calibration", "safe_claim":"two-pass enrichment should use only cutoff_ms < as_of_ms", "status":"python_code_path_present", "evidence":"_enrich_native_random_items_two_pass is invoked after native; audit with reliability bins per cutoff if needed."},
            {"area":"adaptive_weights", "safe_claim":"Forecast native path should not silently consume in-sample adaptive weights for decisions", "status":"needs_review", "evidence":"Native bridge exports adaptive_weights_current.csv; verify whether compiled core treats it as diagnostic or decision input."},
        ]
        text = ["Walk-forward / cutoff audit", "==========================", f"engine_version={settings.engine_version}", f"batch_id={batch_id}", ""]
        text.append("Verdict: this audit build exposes the places that must be proven. It does not claim full proof if native core does not export candidate twin timestamps / feature max timestamps per cutoff.")
        text.append("")
        for c in checks:
            text.append(f"- {c['area']}: {c['status']} — {c['safe_claim']} Evidence: {c['evidence']}")
        return {"ok": True, "future_leak_detected": bool(future_leaks), "leak_points": future_leaks, "checks": checks, "sampled_cutoffs": len(cutoffs), "max_feature_ts_after_first_sample": max_feature_ts_after, "text": "\n".join(text)}

    def twin_audit(self, *, native: dict, items: list[dict]) -> dict:
        sample = []
        for it in (items or [])[:20]:
            sample.append({k: it.get(k) for k in ("cutoff_ms", "horizon", "twin_count", "twin_sample", "expected_move_pct", "confidence", "method") if k in it})
        return {
            "ok": True,
            "forecast_twin_path": "NativeCoreService.tm_single -> compiled native core",
            "random_tm_twin_path": "NativeCoreService.tm_random -> compiled native core",
            "python_historical_twin_finder_exists": True,
            "python_twin_should_be": "diagnostics_only_unless_explicitly_called",
            "needs_golden_test": True,
            "golden_test_recommendation": "Run same 100 cutoffs through tm_single and tm_random/native candidate emission; compare selected twin probabilities, MFE/MAE and EV within tolerance.",
            "native_fields_seen_in_sample": sorted({k for it in (items or [])[:200] for k in it.keys()}),
            "sample_rows": sample,
        }

    def claude_handoff(self, runtime: dict, path: dict, datasets: dict, walk: dict, twin: dict) -> str:
        return f"""Runtime + Path Audit Handoff for Claude
======================================
engine_version={settings.engine_version}
audit_version={self.VERSION}

A) Runtime profile
- See runtime_profile.json and runtime_profile.csv.
- Key question: does native/twin/feature work dominate, and is decision layer <~5%?
- total_ms_reference={runtime.get('total_ms_reference')}

B) Path audit
- See path_audit_forecast.txt and path_audit_tm.txt.
- shared_path_claim={path.get('shared_path_claim')}
- divergence_points={json.dumps(_safe(path.get('divergence_points')), ensure_ascii=False)}

C) Active datasets
- See dataset_audit.json/csv.
- active_prediction_datasets={datasets.get('active_prediction_datasets')}
- macro_active={datasets.get('macro_active')}

D) Walk-forward/cutoff audit
- See walkforward_audit.txt/json.
- future_leak_detected={walk.get('future_leak_detected')}
- Important: if native core does not emit candidate twin timestamps per cutoff, this audit identifies the remaining proof gap rather than pretending it is proven.

E) Twin audit
- Forecast twin path: {twin.get('forecast_twin_path')}
- Random TM twin path: {twin.get('random_tm_twin_path')}
- Golden-test still recommended: {twin.get('golden_test_recommendation')}

What to review first:
1. runtime_profile.csv
2. path_audit_tm.txt + path_audit_forecast.txt
3. dataset_audit.csv
4. walkforward_audit.txt
5. twin_audit.json
"""
