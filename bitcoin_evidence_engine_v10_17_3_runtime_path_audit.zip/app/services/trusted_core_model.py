from __future__ import annotations

import math
from typing import Any

from app.services.calibration_service import ConfidenceCalibrationService


def _f(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        x = float(v)
        if not math.isfinite(x):
            return default
        return x
    except Exception:
        return default


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


HORIZON_HOURS = {"1h": 1, "4h": 4, "8h": 8, "24h": 24, "7d": 168, "30d": 720, "90d": 2160}


class TrustedCoreModel:
    """Single auditable model path shared by Time Machine and Forecast.

    v10.16.82 responds to the external code audit: no 40-model stew for the
    trusted core, no native/live alias bridge, and no in-sample adaptive weights.
    This model uses only the features that survived the data audits plus the
    fixed historical twin anchor.  It is intentionally small and transparent.
    """

    VERSION = "v10.17.2_specialist_alpha_engines"

    def __init__(self) -> None:
        self.calibration = ConfidenceCalibrationService()

    def predict(self, horizon: str, feature: dict[str, Any] | None, current_price: float, *, twin: dict[str, Any] | None = None, cutoff_ms: int | None = None, calibration_rows: list[dict[str, Any]] | None = None, calibration_enabled: bool = True) -> dict[str, Any]:
        h = str(horizon)
        feat = dict(feature or {})
        regime = self._regime(feat)
        score, reasons = self._score(feat, h, regime)
        core_prob = 1.0 / (1.0 + math.exp(-score))
        twin = dict(twin or {})
        twin_prob = _clamp(_f(twin.get("bullish_probability"), 0.5), 0.01, 0.99)
        twin_evidence = int(_f(twin.get("evidence_count"), 0))
        twin_move = _f(twin.get("expected_move_pct"), 0.0)
        # Twin is an independent anchor, not one of many correlated votes.
        twin_w = _clamp(twin_evidence / 180.0, 0.10, 0.48)
        raw_prob = (1.0 - twin_w) * core_prob + twin_w * twin_prob
        if not calibration_enabled:
            cal = {"probability": round(raw_prob, 6), "raw_probability": round(raw_prob, 6), "method": "raw_uncalibrated_two_pass_stage1", "sample": 0, "brier_score": None}
        elif calibration_rows is not None:
            cal = self.calibration.calibrate_probability_from_rows(h, raw_prob, calibration_rows, method="two_pass_walk_forward_in_memory")
            # When the current chronological batch is still too thin, fall back to
            # the database-only walk-forward table. Both paths only use rows before
            # cutoff_ms and neither is cached.
            if int(cal.get("sample") or 0) == 0 and cutoff_ms is not None:
                cal = self.calibration.calibrate_probability(h, raw_prob, as_of_ms=cutoff_ms)
        else:
            cal = self.calibration.calibrate_probability(h, raw_prob, as_of_ms=cutoff_ms)
        prob = float(cal["probability"])
        conf = self.calibration.confidence_from_probability(raw_prob, prob, sample=int(cal.get("sample") or 0), evidence_count=twin_evidence)
        # Expected move is deliberately humble: direction from calibrated probability,
        # magnitude from conditional twin/volatility context.
        direction = 1.0 if prob >= 0.5 else -1.0
        vol_move = self._volatility_move_hint(feat, h)
        abs_twin = abs(twin_move)
        expected_abs = max(vol_move * 0.45, min(max(abs_twin, vol_move * 0.55), self._horizon_cap(h)))
        expected_move = direction * expected_abs * _clamp(abs(prob - 0.5) * 2.8, 0.18, 1.0)
        target_hint, stop_hint = self._conditional_target_stop(twin, expected_move, h, feat)
        return {
            "engine_path": "trusted_core_single_path",
            "trusted_core_version": self.VERSION,
            "horizon": h,
            "bullish_probability": round(prob, 6),
            "bearish_probability": round(1.0 - prob, 6),
            "raw_bullish_probability": round(raw_prob, 6),
            "expected_move_pct": round(expected_move, 6),
            "expected_price": float(current_price) * (1.0 + expected_move / 100.0) if current_price else 0.0,
            "confidence": conf,
            "evidence_count": twin_evidence,
            "model_agreement": None,
            "calibration": cal,
            "condition_target_pct": round(target_hint, 6),
            "condition_stop_pct": round(stop_hint, 6),
            "core_score": round(score, 6),
            "core_regime": regime,
            "core_reasons": reasons,
            "contributions": [
                {"model_id": "TRUSTED_CORE", "name": "Walk-forward calibrated core", "horizon": h, "weight": round(1.0 - twin_w, 3), "confidence": conf, "note": "; ".join(reasons[:5])},
                {"model_id": "TWIN_ANCHOR", "name": "Full-history weighted historical twin anchor", "horizon": h, "weight": round(twin_w, 3), "confidence": conf, "evidence_count": twin_evidence, "note": f"twin_prob={twin_prob:.3f}, twin_move={twin_move:.3f}%"},
            ],
        }

    def _score(self, f: dict[str, Any], h: str, regime: str) -> tuple[float, list[str]]:
        hours = HORIZON_HOURS.get(h, 24)
        fg = _f(f.get("fear_greed"), 50.0)
        rsi = _f(f.get("rsi_14") or f.get("rsi"), 50.0)
        ret1 = _f(f.get("return_1") or f.get("candle_body_pct"), 0.0)
        ret4 = _f(f.get("return_4"), 0.0)
        ret24 = _f(f.get("return_24"), 0.0)
        vol24 = abs(_f(f.get("volatility_24"), 0.0))
        cb = _f(f.get("spot_premium_coinbase_pct"), 0.0)
        funding = _f(f.get("funding_rate"), 0.0)
        dd = _f(f.get("drawdown_from_ath"), 0.0)
        score = 0.0
        reasons: list[str] = []

        if regime == "bull_trend":
            score += 0.42; reasons.append("bull regime momentum bias")
        elif regime == "bear_trend":
            score -= 0.28; reasons.append("bear regime defensive bias")
        elif regime == "capitulation":
            score += 0.55; reasons.append("capitulation rebound bias")
        elif regime == "transition":
            score *= 0.75; reasons.append("transition is low-edge/noisy")

        # Fear & Greed is U-shaped: extreme fear and extreme greed both had positive forward skew.
        if fg <= 20:
            score += 0.35; reasons.append("extreme fear U-shape bullish")
        elif 20 < fg < 40:
            score -= 0.12; reasons.append("fear 20-40 weak zone")
        elif fg >= 80:
            score += 0.30; reasons.append("extreme greed continuation")
        elif fg >= 60:
            score += 0.16; reasons.append("greed continuation")

        # Coinbase spot pressure is the new Flow Engine seed.
        if cb >= 0.12:
            score += 0.34; reasons.append("strong Coinbase premium spot demand")
        elif cb >= 0.025:
            score += 0.18; reasons.append("positive Coinbase premium")
        elif cb <= -0.08:
            score -= 0.28; reasons.append("Coinbase discount spot weakness")

        # Funding: negative funding is often bullish/reversal; very positive funding is crowding risk.
        if funding <= -0.00012:
            score += 0.20; reasons.append("negative funding bullish squeeze potential")
        elif funding >= 0.00030:
            score -= 0.18; reasons.append("high positive funding crowding risk")

        # Horizon-specific price action: short horizon mean reversion, longer horizon momentum.
        if hours <= 4:
            score += -0.16 * _clamp(ret1, -3.0, 3.0)
            score += -0.05 * _clamp(ret4, -6.0, 6.0)
            reasons.append("short-horizon asymmetric mean-reversion")
        elif hours <= 24:
            score += -0.08 * _clamp(ret4, -6.0, 6.0) + 0.04 * _clamp(ret24, -12.0, 12.0)
            reasons.append("4h/24h mixed reversal-momentum")
        else:
            score += 0.06 * _clamp(ret24, -12.0, 12.0)
            reasons.append("long horizon momentum component")

        # Extreme crash reversal override.
        if ret24 <= -9.2 or ret1 <= -2.5:
            score += 0.48; reasons.append("top-percentile crash reversal cluster")
        if ret24 >= 9.5 and hours <= 24 and cb <= 0.0:
            score -= 0.34; reasons.append("extreme pump without Coinbase support fakeout risk")
        if dd <= -55 and fg <= 35:
            score += 0.26; reasons.append("deep drawdown recovery skew")
        if vol24 <= 0.20 and regime == "transition":
            score *= 0.70; reasons.append("low-vol transition dampening")
        return _clamp(score, -2.2, 2.2), reasons

    def _regime(self, f: dict[str, Any]) -> str:
        raw = str(f.get("regime") or f.get("regime_code") or "").lower()
        if "capitulation" in raw or "panic" in raw:
            return "capitulation"
        if "bull" in raw or "euphoria" in raw:
            return "bull_trend"
        if "bear" in raw:
            return "bear_trend"
        if "post_halving" in raw:
            return "post_halving_accumulation"
        fg = _f(f.get("fear_greed"), 50.0); rsi = _f(f.get("rsi_14"), 50.0); r24 = _f(f.get("return_24"), 0.0); dd = _f(f.get("drawdown_from_ath"), 0.0)
        if r24 <= -5.0 or (fg <= 20 and rsi <= 28) or dd <= -55:
            return "capitulation"
        if r24 > 1.0 and rsi >= 55 and fg >= 55:
            return "bull_trend"
        if r24 < -1.0 and rsi <= 45 and fg <= 45:
            return "bear_trend"
        return "transition"

    def _volatility_move_hint(self, f: dict[str, Any], h: str) -> float:
        hours = HORIZON_HOURS.get(h, 24)
        vol24 = abs(_f(f.get("volatility_24"), 0.0))
        rng = abs(_f(f.get("range_pct"), 0.0))
        base = {"1h": 0.35, "4h": 0.75, "8h": 1.05, "24h": 1.7, "7d": 4.0, "30d": 8.5, "90d": 15.0}.get(h, 1.5)
        return max(base, max(vol24, rng) * math.sqrt(max(1.0, min(hours, 720) / 24.0)))

    def _horizon_cap(self, h: str) -> float:
        return {"1h": 1.8, "4h": 3.2, "8h": 4.8, "24h": 7.5, "7d": 18.0, "30d": 38.0, "90d": 65.0}.get(h, 12.0)

    def _conditional_target_stop(self, twin: dict[str, Any], expected_move: float, h: str, f: dict[str, Any]) -> tuple[float, float]:
        abs_exp = abs(expected_move)
        abs_p50 = _f(twin.get("abs_move_p50"), 0.0)
        abs_p75 = _f(twin.get("abs_move_p75"), 0.0)
        adv_p35 = _f(twin.get("adverse_move_p35"), 0.0)
        vol_hint = self._volatility_move_hint(f, h)
        target = max(abs_exp * 0.95, abs_p50, vol_hint * 0.55)
        if abs_p75 > 0:
            target = min(max(target, abs_p50), abs_p75 * 1.05)
        stop = max(adv_p35, vol_hint * 0.38, target * 0.55)
        # Do not force a perfect RR; only keep values sane.
        return _clamp(target, 0.03, self._horizon_cap(h)), _clamp(stop, 0.02, self._horizon_cap(h) * 0.9)
