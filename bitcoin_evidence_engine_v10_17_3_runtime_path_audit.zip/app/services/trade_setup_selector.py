from __future__ import annotations

import math
from typing import Any

from app.core.config import settings
from app.db.database import db
from app.services.trade_evaluation_v2 import evaluate_historical_setup_v2, set_bulk_candle_cache, clear_bulk_candle_cache
from app.services.confluence_score import reversal_alpha, trend_continuation_alpha, classify_setup

HORIZON_HOURS = {'1h':1, '4h':4, '8h':8, '24h':24, '7d':24*7, '30d':24*30, '90d':24*90}
HORIZON_SECONDS = {k: int(v * 3600) for k, v in HORIZON_HOURS.items()}
VERSION = 'v10.17.2_specialist_alpha_engines'


def _finite(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        if math.isfinite(x):
            return x
    except Exception:
        pass
    return default


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def _sigmoid(x: float) -> float:
    try:
        return 1.0 / (1.0 + math.exp(-x))
    except Exception:
        return 0.5


class TradeSetupSelector:
    """Unified Time Machine + Forecast trade setup selector.

    v10.16.82 is built from the multi-AI audit (own audit + DeepSeek + Gemini + Claude):
    - no dependency on sparse premium features as historical core;
    - Regime Master Switch before any trade decision;
    - regime specialist logic for bull/bear/capitulation/transition;
    - Triple Gate selection: Direction Edge, Magnitude Edge, Trade Quality Edge;
    - extreme-crash reversal cluster and Fear&Greed U-shape as testable features;
    - transition/chop gets much more NO_TRADE;
    - forecast and Time Machine share this exact class.
    """

    MIN_RR = 1.18
    BASE_RR = 1.50

    def __init__(self):
        self._range_cache: dict[str, dict[str, float]] = {}

    def _recent_range_stats(self, horizon: str) -> dict[str, float]:
        horizon = str(horizon)
        if horizon in self._range_cache:
            return self._range_cache[horizon]
        h = max(1, int(HORIZON_HOURS.get(horizon, 24)))
        try:
            frame = db.df("""
                WITH c AS (
                    SELECT row_number() OVER (ORDER BY open_time) rn, open_time, close, high, low
                    FROM raw_candles
                    WHERE source='binance' AND symbol=? AND interval='1h'
                    ORDER BY open_time DESC LIMIT 25000
                ), ordered AS (
                    SELECT * FROM c ORDER BY rn
                )
                SELECT a.close AS entry_price,
                       b.close AS exit_price,
                       (SELECT MAX(x.high) FROM ordered x WHERE x.rn>a.rn AND x.rn<=a.rn+?) AS max_high,
                       (SELECT MIN(x.low) FROM ordered x WHERE x.rn>a.rn AND x.rn<=a.rn+?) AS min_low
                FROM ordered a
                JOIN ordered b ON b.rn=a.rn+?
                WHERE a.close IS NOT NULL AND a.close>0 AND b.close IS NOT NULL
                LIMIT 16000
            """, [settings.symbol, h, h, h])
            if frame.empty:
                raise RuntimeError('empty range stats')
            import pandas as pd
            entry = frame['entry_price'].astype(float).clip(lower=1e-9)
            up = ((frame['max_high'].astype(float) - entry) / entry * 100.0).clip(lower=0)
            down = ((entry - frame['min_low'].astype(float)) / entry * 100.0).clip(lower=0)
            abs_close = ((frame['exit_price'].astype(float) - entry) / entry * 100.0).abs()
            favorable = pd.concat([up, down], axis=0).dropna()
            out = {
                'median_range_pct': float(favorable.quantile(0.50)),
                'p65_range_pct': float(favorable.quantile(0.65)),
                'p75_range_pct': float(favorable.quantile(0.75)),
                'p85_range_pct': float(favorable.quantile(0.85)),
                'p92_range_pct': float(favorable.quantile(0.92)),
                'median_close_move_pct': float(abs_close.dropna().quantile(0.50)),
                'p75_close_move_pct': float(abs_close.dropna().quantile(0.75)),
                'samples': int(len(frame)),
            }
        except Exception as exc:
            base = {'1h':0.55,'4h':1.05,'8h':1.55,'24h':2.6,'7d':6.5,'30d':14.0,'90d':27.0}.get(horizon,2.0)
            out = {'median_range_pct':base*0.65,'p65_range_pct':base*0.85,'p75_range_pct':base,'p85_range_pct':base*1.25,'p92_range_pct':base*1.55,'median_close_move_pct':base*0.45,'p75_close_move_pct':base*0.75,'samples':0,'fallback_error':str(exc)[:180]}
        self._range_cache[horizon] = out
        return out

    def _feature_snapshot(self, item: dict) -> dict:
        f = dict(item.get('feature_snapshot') or {})
        return f

    def _ctx(self, item: dict) -> dict:
        f = self._feature_snapshot(item)
        # premium fields are intentionally included as optional modifiers only;
        # the Claude audit showed they are too sparse for historical core learning.
        return {
            'regime_raw': str(f.get('regime') or f.get('regime_code') or item.get('regime') or 'unknown'),
            'fear_greed': _finite(f.get('fear_greed'), 50.0),
            'rsi_14': _finite(f.get('rsi_14') or f.get('rsi'), 50.0),
            'return_1': _finite(f.get('return_1') or f.get('candle_body_pct'), 0.0),
            'return_4': _finite(f.get('return_4'), 0.0),
            'return_24': _finite(f.get('return_24') or f.get('trend'), 0.0),
            'candle_body_pct': _finite(f.get('candle_body_pct') or f.get('return_1'), 0.0),
            'range_pct': _finite(f.get('range_pct'), 0.0),
            'volatility_24': _finite(f.get('volatility_24') or f.get('volatility'), 0.0),
            'volume_zscore': _finite(f.get('volume_zscore'), 0.0),
            'volume_ratio_24': _finite(f.get('volume_ratio_24'), 1.0),
            'drawdown_from_ath': _finite(f.get('drawdown_from_ath'), 0.0),
            'cycle_progress': _finite(f.get('cycle_progress'), 0.0),
            'funding_rate': _finite(f.get('funding_rate'), 0.0),
            'spot_premium_coinbase_pct': _finite(f.get('spot_premium_coinbase_pct') or f.get('coinbase_premium_pct') or f.get('coinbase_premium'), 0.0),
            'coinbase_premium_change_4h': _finite(f.get('coinbase_premium_change_4h') or f.get('spot_premium_coinbase_change_4h'), 0.0),
            'data_completeness': _finite(f.get('data_completeness'), 0.0),
        }

    def _master_regime(self, ctx: dict) -> str:
        raw = str(ctx.get('regime_raw') or '').lower()
        fg = ctx['fear_greed']; rsi = ctx['rsi_14']; r24 = ctx['return_24']; dd = ctx['drawdown_from_ath']
        if 'capitulation' in raw or 'panic' in raw or 'crash' in raw:
            return 'capitulation'
        if 'bull' in raw or 'euphoria' in raw:
            return 'bull_trend'
        if 'bear' in raw:
            return 'bear_trend'
        if 'post_halving' in raw or 'accumulation' in raw:
            return 'post_halving_accumulation'
        # Transparent fallback for live rows whose stored label is missing/weak.
        if r24 <= -5.0 or (fg <= 20 and rsi <= 28):
            return 'capitulation'
        if r24 > 1.0 and rsi >= 55 and fg >= 55:
            return 'bull_trend'
        if r24 < -1.0 and rsi <= 45 and fg <= 45:
            return 'bear_trend'
        if dd <= -55 and fg <= 35:
            return 'capitulation'
        return 'transition'

    def _specialist_alpha_state(self, ctx: dict, master: str) -> dict:
        rev = reversal_alpha(
            regime=master, fear_greed=ctx.get('fear_greed'), funding_rate=ctx.get('funding_rate'),
            coinbase_premium_pct=ctx.get('spot_premium_coinbase_pct'), rsi_14=ctx.get('rsi_14')
        )
        cont = trend_continuation_alpha(
            regime=master, fear_greed=ctx.get('fear_greed'), funding_rate=ctx.get('funding_rate'),
            coinbase_premium_pct=ctx.get('spot_premium_coinbase_pct'), rsi_14=ctx.get('rsi_14'),
            return_4=ctx.get('return_4'), return_24=ctx.get('return_24'),
            volatility_24=ctx.get('volatility_24'), drawdown_from_ath=ctx.get('drawdown_from_ath')
        )
        setup_type = classify_setup(rev, cont)
        selected = rev if setup_type == 'reversal' else cont if setup_type == 'trend_continuation' else None
        return {
            'specialist_setup_type': setup_type,
            'reversal_score': rev.score, 'reversal_bucket': rev.bucket, 'reversal_tradeable': rev.tradeable, 'reversal_probability_hint': rev.probability_hint, 'reversal_ev_hint': rev.ev_hint, 'reversal_layers': rev.n_layers, 'reversal_contributions': rev.contributions,
            'continuation_score': cont.score, 'continuation_bucket': cont.bucket, 'continuation_tradeable': cont.tradeable, 'continuation_probability_hint': cont.probability_hint, 'continuation_ev_hint': cont.ev_hint, 'continuation_layers': cont.n_layers, 'continuation_contributions': cont.contributions,
            'selected_specialist': selected.name if selected else 'none',
            'selected_specialist_score': selected.score if selected else 0.0,
            'selected_specialist_ev_hint': selected.ev_hint if selected else 0.0,
            'selected_specialist_probability_hint': selected.probability_hint if selected else 0.5,
        }

    def _regime_bucket(self, ctx: dict, horizon: str, master: str) -> str:
        vol = abs(ctx['volatility_24']); rng = abs(ctx['range_pct']); trend = ctx['return_24']
        h = max(1, int(HORIZON_HOURS.get(str(horizon), 24)))
        vol_score = max(vol, rng)
        if master == 'capitulation':
            return 'capitulation_reversal'
        if master == 'bull_trend':
            return 'bull_momentum'
        if master == 'bear_trend':
            return 'bear_defensive'
        if master == 'post_halving_accumulation':
            return 'post_halving_accumulation'
        if vol_score >= (1.25 if h <= 4 else 2.2 if h <= 24 else 5.0):
            return 'transition_high_vol'
        if vol_score <= (0.25 if h <= 4 else 0.70 if h <= 24 else 1.8):
            return 'transition_low_vol'
        if abs(trend) >= (0.45 if h <= 4 else 1.0 if h <= 24 else 3.0):
            return 'transition_breakout_watch'
        return 'transition_chop'

    def _regime_specialist_bias(self, ctx: dict, horizon: str, candidate_side: str) -> tuple[float, str, dict]:
        """Return signed directional bias: positive favors LONG, negative favors SHORT."""
        h = str(horizon)
        master = self._master_regime(ctx)
        alpha_state = self._specialist_alpha_state(ctx, master)
        bucket = self._regime_bucket(ctx, h, master)
        fg = ctx['fear_greed']; rsi = ctx['rsi_14']; r1 = ctx['return_1']; r4 = ctx['return_4']; r24 = ctx['return_24']
        body = ctx['candle_body_pct']; volz = ctx['volume_zscore']; rng = ctx['range_pct']; vol = ctx['volatility_24']
        cb = ctx.get('spot_premium_coinbase_pct', 0.0); cb_ch4 = ctx.get('coinbase_premium_change_4h', 0.0); funding = ctx.get('funding_rate', 0.0)
        score = 0.0; tags=[]

        # Claude: strongest robust micro edge is asymmetric reversal after big red candles / crashes.
        extreme_red = (r24 <= -9.2) or (body <= -2.5) or (r1 <= -2.5)
        big_red = (body <= -1.3) or (r1 <= -1.3) or (r24 <= -5.0)
        extreme_green = (r24 >= 9.5) or (body >= 2.5) or (r1 >= 2.5)
        volume_absorption = big_red and (volz >= 1.5 or ctx['volume_ratio_24'] >= 1.8)

        if master == 'capitulation':
            score += 18.0
            tags.append('capitulation_long_reversal_bias')
            if extreme_red: score += 14.0; tags.append('top1pct_crash_reversal_cluster')
            if volume_absorption: score += 9.0; tags.append('volume_absorption_after_drop')
            if rsi <= 25: score += 7.0; tags.append('oversold_panic')
            if h == '1h': score -= 3.0  # immediate hour can still be noisy; 4h/24h cleaner.
        elif master == 'bull_trend':
            score += 10.0
            tags.append('bull_momentum_bias')
            if r24 > 0 and rsi >= 55: score += 8.0; tags.append('bull_momentum_confirmed')
            if r1 < 0 and rsi >= 45: score += 4.0; tags.append('bull_dip_buy_context')
            if extreme_green and h in ('1h','4h'): score -= 5.0; tags.append('short_term_post_pump_cooldown')
        elif master == 'bear_trend':
            score -= 10.0
            tags.append('bear_defensive_short_bias')
            if r24 < 0 and 45 <= rsi <= 62: score -= 8.0; tags.append('bear_flag_rejection_zone')
            if big_red and (rsi <= 25 or volume_absorption): score += 11.0; tags.append('bear_panic_rebound_override')
        elif master == 'post_halving_accumulation':
            score += 7.0
            tags.append('post_halving_accumulation_positive_bias')
            if fg >= 55 and r24 >= -1.0: score += 4.0
        else:
            tags.append('transition_requires_extra_edge')
            if abs(r24) < 0.6 and max(rng, vol) < 0.75:
                score += 0.0; tags.append('low_vol_chop_no_direction')
            elif r24 > 1.2 and rsi > 55:
                score += 7.0; tags.append('transition_breakout_up')
            elif r24 < -1.2 and rsi < 45:
                score -= 7.0; tags.append('transition_breakdown_down')

        # Coinbase / flow context is not a standalone magic signal; it is a cluster dimension.
        # Positive Coinbase premium/rising premium supports spot-led LONG setups; discount weakens them.
        if cb >= 0.04 or cb_ch4 > 0.02:
            score += 4.0; tags.append('coinbase_spot_premium_positive')
        elif cb <= -0.04 or cb_ch4 < -0.02:
            score -= 4.0; tags.append('coinbase_discount_pressure')
        if funding < -0.0002:
            score += 2.5; tags.append('negative_funding_rebound_pressure')
        elif funding > 0.0006:
            score -= 2.0; tags.append('overheated_positive_funding')

        # Fear & Greed U-shape from Claude: both extreme fear and extreme greed have positive forward skew, neutral/fear 20-40 is weakest.
        if fg <= 20:
            score += 6.0; tags.append('extreme_fear_u_shape_bullish')
        elif fg >= 80:
            score += 5.0; tags.append('extreme_greed_momentum_u_shape')
        elif 20 < fg < 40:
            score -= 3.0; tags.append('weak_fear_middle_zone')

        direction_sign = 1.0 if candidate_side == 'LONG' else -1.0
        aligned = score * direction_sign
        meta = {'master_regime': master, 'regime_bucket': bucket, 'bias_score_signed': round(score,3), 'specialist_tags': tags[:8], 'volume_absorption': volume_absorption, 'extreme_red': extreme_red, 'extreme_green': extreme_green}
        return aligned, bucket, meta

    def _market_potential_pct(self, item: dict, horizon: str, direction: str, ctx: dict, specialist_meta: dict) -> tuple[float, dict]:
        stats = self._recent_range_stats(horizon)
        h = max(1, int(HORIZON_HOURS.get(horizon, 24)))
        expected = abs(_finite(item.get('expected_move_pct'), 0.0))
        conf = _finite(item.get('confidence'), 50.0)
        vol_hint = max(ctx['range_pct'], ctx['volatility_24'] * math.sqrt(min(h,24)/24.0))
        hist_p = stats['p65_range_pct']
        if conf >= 68: hist_p = stats['p75_range_pct']
        if conf >= 78: hist_p = stats['p85_range_pct']
        if specialist_meta.get('extreme_red') or specialist_meta.get('extreme_green'):
            hist_p = max(hist_p, stats.get('p85_range_pct', hist_p))
        if specialist_meta.get('regime_bucket') == 'transition_low_vol':
            hist_p = min(hist_p, stats['p65_range_pct'] * 0.85)
        potential = max(hist_p, expected * 1.25, vol_hint * 1.10)
        if specialist_meta.get('volume_absorption') and direction == 'LONG':
            potential *= 1.12
        if conf < 55: potential *= 0.70
        elif conf < 62: potential *= 0.86
        caps = {'1h':1.8,'4h':3.5,'8h':5.2,'24h':8.5,'7d':20.0,'30d':42.0,'90d':72.0}
        potential = _clamp(potential, 0.03, caps.get(str(horizon), 15.0))
        return potential, {'range_stats': stats, 'context': ctx, 'vol_hint_pct': round(vol_hint,6)}

    def _policy(self, horizon: str, bucket: str, master: str, sample: int) -> dict:
        h = str(horizon)
        # v10.16.82: 1h was massively overtrading in v10.16.80, so the normal gate is materially stricter.
        min_dir = {'1h':69,'4h':65,'8h':64,'24h':65,'7d':66,'30d':67,'90d':68}.get(h,65)
        min_mag = {'1h':60,'4h':58,'8h':58,'24h':59,'7d':61,'30d':63,'90d':65}.get(h,59)
        min_qual = {'1h':67,'4h':64,'8h':64,'24h':65,'7d':66,'30d':68,'90d':70}.get(h,65)
        min_ev = {'1h':0.030,'4h':0.035,'8h':0.045,'24h':0.065,'7d':0.120,'30d':0.220,'90d':0.360}.get(h,0.06)
        min_potential = {'1h':0.35,'4h':0.62,'8h':0.90,'24h':1.35,'7d':2.8,'30d':6.2,'90d':10.0}.get(h,1.0)
        rr_target = {'1h':1.28,'4h':1.38,'8h':1.48,'24h':1.55,'7d':1.60,'30d':1.65,'90d':1.72}.get(h,1.5)
        if master == 'capitulation':
            min_dir -= 5; min_mag -= 2; min_qual -= 4; min_ev *= 0.82; rr_target += 0.05
        elif master == 'bull_trend':
            min_dir -= 2; min_qual -= 2; min_ev *= 0.90
        elif master == 'bear_trend':
            min_dir += 1; min_qual += 1; min_ev *= 1.08
        elif master == 'transition':
            min_dir += 4; min_mag += 3; min_qual += 5; min_ev *= 1.20
        if bucket in ('transition_chop','transition_low_vol'):
            min_dir += 3; min_qual += 4
        if bucket == 'transition_high_vol':
            min_dir += 2; min_qual += 3; rr_target += 0.12
        if sample < 500:
            min_dir += 2; min_qual += 3; min_ev *= 1.15
        return {'min_direction_edge':float(min_dir),'min_magnitude_edge':float(min_mag),'min_trade_quality':float(min_qual),'min_ev':float(min_ev),'min_potential':float(min_potential),'rr_target':float(rr_target)}

    def _strictness_bucket(self, direction_edge: float, magnitude_edge: float, trade_quality: float, ev_pct: float, rr: float) -> str:
        score = min(direction_edge, magnitude_edge, trade_quality)
        if score >= 84 and ev_pct > 0 and rr >= 1.45:
            return 'elite'
        if score >= 75 and ev_pct > 0 and rr >= 1.30:
            return 'strict'
        if score >= 66 and ev_pct > 0 and rr >= self.MIN_RR:
            return 'normal'
        if score >= 56:
            return 'loose_watch_only'
        return 'reject'

    def _reason(self, gates: dict, policy: dict, bucket: str) -> str:
        reasons=[]
        if gates['direction_edge'] < policy['min_direction_edge']:
            reasons.append('low_direction_edge')
        if gates['magnitude_edge'] < policy['min_magnitude_edge']:
            reasons.append('insufficient_market_potential')
        if gates['trade_quality'] < policy['min_trade_quality']:
            reasons.append('low_trade_quality')
        if gates['ev_pct'] < policy['min_ev']:
            reasons.append('negative_or_weak_expected_value')
        if gates['rr'] < self.MIN_RR:
            reasons.append('bad_rr')
        if bucket.startswith('transition'):
            reasons.append('transition_chop_requires_extra_edge')
        return 'no_trade_' + '__'.join(reasons[:5] or ['edge_not_confirmed'])


    def _alert_quality(self, out: dict, policy: dict) -> dict:
        """Notification-quality layer for the future iPhone/ntfy scanner.

        Forecast still predicts all horizons.  This layer answers a different
        question: would this historical setup have been worthy of an actual
        push notification?  v10.17.1 intentionally creates *tiers* instead of a
        single ultra-strict gate, because Random1000 showed that three alerts is
        too little to learn from.  The export must show enough candidate trades
        to mine true high-edge clusters while still separating watch/normal/
        strong/elite quality.
        """
        action = str(out.get('setup_action') or out.get('trade_action') or 'NO_TRADE')
        if action not in ('LONG', 'SHORT'):
            return {
                'alert_candidate': False,
                'alert_level': 'none',
                'alert_quality_score': 0.0,
                'alert_reason': 'no_trade_forecast_only',
                'alert_failed_gates': 'no_long_short_setup',
                'notification_tier': 'none',
            }
        conf = _finite(out.get('setup_effective_confidence') or out.get('confidence'), 50.0)
        raw_conf = _finite(out.get('confidence'), conf)
        ev = _finite(out.get('setup_expected_value_pct'), 0.0)
        rr = _finite(out.get('setup_rr'), 0.0)
        direction = _finite(out.get('setup_direction_edge'), 0.0)
        magnitude = _finite(out.get('setup_magnitude_edge'), 0.0)
        quality = _finite(out.get('setup_trade_quality') or out.get('setup_quality'), 0.0)
        master = str(out.get('setup_master_regime') or 'unknown')
        bucket = str(out.get('setup_regime_bucket') or '')
        tags = out.get('setup_specialist_tags') or []
        try:
            tag_text = ' '.join(str(x) for x in tags)
        except Exception:
            tag_text = str(tags)
        tag_l = tag_text.lower()

        # Independent-ish dimensions.  Effective confidence is only one part;
        # score also rewards historical setup quality, direction/magnitude edge,
        # EV, RR and confirmed flow/regime context.
        score = (
            0.24 * conf +
            0.18 * direction +
            0.16 * magnitude +
            0.24 * quality +
            4.0 * max(0.0, min(2.2, rr - 1.0)) +
            3.8 * max(0.0, min(2.5, ev))
        )
        if master in ('capitulation', 'bull_trend'):
            score += 3.0
        if master == 'bear_trend' and action == 'SHORT':
            score += 1.5
        if 'coinbase' in tag_l or 'premium' in tag_l or 'flow' in tag_l:
            score += 2.5
        if 'top1pct_crash' in tag_l or 'capitulation_long_reversal' in tag_l:
            score += 2.0
        specialist_type = str(out.get('specialist_setup_type') or 'none')
        specialist_score = _finite(out.get('selected_specialist_score'), 0.0)
        if specialist_type in ('reversal', 'trend_continuation'):
            score += min(8.0, max(0.0, abs(specialist_score) - 1.5) * 3.0)
        if bucket.startswith('transition'):
            score -= 8.0
        if 'transition_chop' in bucket or 'transition_low_vol' in bucket:
            score -= 6.0

        failed=[]
        hard_transition = master == 'transition' or bucket.startswith('transition')
        if ev <= 0.0: failed.append('ev_not_positive')
        if rr < 1.08: failed.append('rr_lt_1_08')
        if direction < 68.0: failed.append('direction_edge_lt_68')
        if magnitude < 56.0: failed.append('magnitude_edge_lt_56')
        if quality < 68.0: failed.append('trade_quality_lt_68')
        if conf < 52.5: failed.append('effective_conf_lt_52_5')
        if hard_transition and conf < 58.0: failed.append('transition_requires_conf_58')

        # Tiered notification model.  The lowest push tier is intentionally a
        # research-grade notification candidate so Random1000 yields enough rows
        # for cluster mining.  Production ntfy can later use only strong/elite.
        normal = (not failed and score >= 68.0)
        strong = (normal and conf >= 53.0 and score >= 72.0 and direction >= 70.0 and quality >= 70.0 and rr >= 1.10)
        elite = (strong and conf >= 58.0 and score >= 80.0 and direction >= 78.0 and quality >= 76.0 and rr >= 1.18 and ev > 0.20)

        if elite:
            level = 'elite_push'
            reason = 'elite_alert_cluster_tier_passed'
            tier = 'elite'
        elif strong:
            level = 'strong_push'
            reason = 'strong_alert_cluster_tier_passed'
            tier = 'strong'
        elif normal:
            level = 'normal_push'
            reason = 'normal_alert_cluster_tier_passed'
            tier = 'normal'
        else:
            watch = conf >= 50.0 and ev > 0.0 and rr >= 1.02 and direction >= 60.0 and quality >= 60.0 and not hard_transition
            level = 'watch_only' if watch else 'none'
            reason = 'watch_only_not_notification' if watch else 'failed_alert_gates'
            tier = 'watch' if watch else 'none'

        return {
            'alert_candidate': bool(level in ('normal_push', 'strong_push', 'elite_push')),
            'alert_level': level,
            'notification_tier': tier,
            'alert_quality_score': round(_clamp(score, 0.0, 100.0), 3),
            'alert_reason': reason,
            'alert_failed_gates': ';'.join(failed),
            'alert_confidence_min': 52.5,
            'alert_direction_edge_min': 68.0,
            'alert_magnitude_edge_min': 56.0,
            'alert_trade_quality_min': 68.0,
            'alert_raw_confidence': round(raw_conf, 3),
        }

    def select(self, item: dict, horizon: str | None = None, *, live: bool = False) -> dict:
        horizon = str(horizon or item.get('horizon') or '1h')
        entry = _finite(item.get('entry_price') or item.get('start_price') or item.get('current_price'), 0.0)
        if entry <= 0:
            return {**item, 'setup_engine_version':VERSION, 'setup_action':'NO_TRADE', 'no_trade':True, 'setup_reason':'missing_entry_price'}

        move = _finite(item.get('expected_move_pct'), 0.0)
        conf = _finite(item.get('confidence'), 50.0)
        candidate = 'LONG' if move >= 0 else 'SHORT'
        ctx = self._ctx(item)
        aligned_bias, bucket, spec_meta = self._regime_specialist_bias(ctx, horizon, candidate)
        # v10.17.2 specialist alpha engines: do not max raw scores. Use the
        # setup classifier to add a calibrated EV/probability hint only when a
        # specialist applies to the current market state. This lets reversal and
        # trend-continuation cover different years without reviving the 40-model stew.
        selected_type = alpha_state.get('specialist_setup_type')
        selected_ev_hint = _finite(alpha_state.get('selected_specialist_ev_hint'), 0.0)
        selected_prob_hint = _finite(alpha_state.get('selected_specialist_probability_hint'), 0.5)
        if selected_type == 'reversal' and candidate == ('LONG' if _finite(alpha_state.get('reversal_score'),0.0) > 0 else 'SHORT'):
            aligned_bias += min(14.0, 5.0 + selected_ev_hint * 3.0)
        elif selected_type == 'trend_continuation' and candidate == 'LONG':
            aligned_bias += min(12.0, 4.0 + selected_ev_hint * 3.0)
        master = spec_meta['master_regime']

        # Specialist can override direction only for the strongest audited cluster: panic/capitulation reversal.
        if spec_meta.get('extreme_red') and (ctx['rsi_14'] <= 30 or spec_meta.get('volume_absorption')) and horizon in ('4h','8h','24h'):
            candidate = 'LONG'
            aligned_bias, bucket, spec_meta = self._regime_specialist_bias(ctx, horizon, candidate)
        # v10.17.2 specialist alpha engines: do not max raw scores. Use the
        # setup classifier to add a calibrated EV/probability hint only when a
        # specialist applies to the current market state. This lets reversal and
        # trend-continuation cover different years without reviving the 40-model stew.
        selected_type = alpha_state.get('specialist_setup_type')
        selected_ev_hint = _finite(alpha_state.get('selected_specialist_ev_hint'), 0.0)
        selected_prob_hint = _finite(alpha_state.get('selected_specialist_probability_hint'), 0.5)
        if selected_type == 'reversal' and candidate == ('LONG' if _finite(alpha_state.get('reversal_score'),0.0) > 0 else 'SHORT'):
            aligned_bias += min(14.0, 5.0 + selected_ev_hint * 3.0)
        elif selected_type == 'trend_continuation' and candidate == 'LONG':
            aligned_bias += min(12.0, 4.0 + selected_ev_hint * 3.0)
            spec_meta['direction_override'] = 'panic_reversal_forced_long'

        potential_pct, meta = self._market_potential_pct(item, horizon, candidate, ctx, spec_meta)
        potential_usd = entry * potential_pct / 100.0
        sample = int((meta.get('range_stats') or {}).get('samples') or 0)
        policy = self._policy(horizon, bucket, master, sample)

        conviction = _clamp((conf - 50.0) / 35.0, 0.0, 1.0)
        move_abs = abs(move)
        # Target learns from realised range potential + model move, not fixed dollars.
        # v10.16.82 Claude audit fix: do not construct target/stop only to make RR look good.
        # Prefer conditional target/stop hints from the shared TrustedCore/Twin path.  These are
        # estimated from comparable historical moments (MFE/MAE style) and can fail the RR/EV gate.
        cond_target = _finite(item.get('condition_target_pct'), 0.0)
        cond_stop = _finite(item.get('condition_stop_pct'), 0.0)
        noise_floor = {'1h':0.065,'4h':0.12,'8h':0.17,'24h':0.25,'7d':0.75,'30d':1.8,'90d':3.5}.get(horizon,0.25)
        noise_pct = max(noise_floor, ctx['range_pct']*0.36, ctx['volatility_24']*(0.34 if HORIZON_HOURS.get(horizon,24)<=4 else 0.48), (meta.get('range_stats') or {}).get('median_close_move_pct',0.0)*0.40)
        desired_rr = policy['rr_target']
        if cond_target > 0 and cond_stop > 0:
            target_pct = min(max(cond_target, noise_pct * 0.75), potential_pct * 1.05)
            stop_pct = max(cond_stop, noise_pct * 0.85)
            desired_rr = target_pct / max(stop_pct, 1e-9)
            target_stop_method = 'conditional_twin_distribution_mfe_mae'
        else:
            # Legacy fallback remains only for rows without conditional distribution data.
            raw_target_pct = max(potential_pct * (0.42 + 0.30 * conviction), move_abs * (1.00 + 0.25 * conviction))
            target_pct = min(max(raw_target_pct, noise_pct * 1.05), potential_pct * 0.96)
            stop_pct = max(noise_pct, target_pct / max(policy['rr_target'], 1e-9))
            target_stop_method = 'legacy_fallback_not_rr_forced'
        target_usd = entry * target_pct / 100.0
        stop_usd = entry * stop_pct / 100.0
        rr = target_usd / stop_usd if stop_usd > 0 else 0.0
        if candidate == 'LONG':
            target_price = entry + target_usd; stop_price = entry - stop_usd
        else:
            target_price = entry - target_usd; stop_price = entry + stop_usd

        # Three independent gates.
        # Gate A: direction edge = model confidence + regime specialist alignment + momentum/reversal evidence.
        direction_edge = 50.0 + (conf - 50.0)*0.72 + aligned_bias + min(6.0, move_abs*0.60)
        if abs(aligned_bias) < 2 and master == 'transition':
            direction_edge -= 6.0
        # Gate B: magnitude edge = enough realistic movement beyond market noise.
        magnitude_ratio = potential_pct / max(policy['min_potential'], 1e-9)
        target_noise_ratio = target_pct / max(noise_pct, 1e-9)
        magnitude_edge = 48.0 + min(26.0, math.log(max(0.10, magnitude_ratio))*18.0) + min(18.0, (target_noise_ratio-1.0)*9.0) + min(7.0, move_abs*0.50)
        if bucket in ('transition_low_vol','transition_chop'):
            magnitude_edge -= 5.0
        # Gate C: trade quality = EV/PF proxy + RR + sample + no overtrading/chop penalty.
        effective_conf = conf + max(-8.0, min(8.0, aligned_bias*0.18))
        if bucket.startswith('transition'):
            effective_conf -= 3.0
        if potential_pct < policy['min_potential']:
            effective_conf -= 4.0
        effective_conf = _clamp(effective_conf, 5.0, 92.0)
        ev_pct = (effective_conf/100.0)*target_pct - (1.0-effective_conf/100.0)*stop_pct
        trade_quality = 48.0 + (effective_conf-50.0)*0.55 + min(10.0, math.log10(max(10,sample))*2.0) + min(14.0, (ev_pct/max(policy['min_ev'],1e-9))*4.2 if ev_pct>0 else ev_pct*18.0) + min(10.0, (rr-1.0)*7.5)
        if bucket.startswith('transition'):
            trade_quality -= 4.0
        if rr < self.MIN_RR:
            trade_quality -= 14.0

        direction_edge = round(_clamp(direction_edge, 0, 100),3)
        magnitude_edge = round(_clamp(magnitude_edge, 0, 100),3)
        trade_quality = round(_clamp(trade_quality, 0, 100),3)
        strictness = self._strictness_bucket(direction_edge, magnitude_edge, trade_quality, ev_pct, rr)
        gates = {'direction_edge':direction_edge,'magnitude_edge':magnitude_edge,'trade_quality':trade_quality,'ev_pct':ev_pct,'rr':rr}
        action_ok = (direction_edge >= policy['min_direction_edge'] and magnitude_edge >= policy['min_magnitude_edge'] and trade_quality >= policy['min_trade_quality'] and ev_pct >= policy['min_ev'] and potential_pct >= policy['min_potential'] and rr >= self.MIN_RR)
        action = candidate if action_ok else 'NO_TRADE'
        reason = 'triple_gate_regime_specialist_valid_setup' if action_ok else self._reason(gates, policy, bucket)

        out = dict(item)
        out.update({
            'setup_engine_version': VERSION,
            'setup_action': action,
            'trade_action': action,
            'no_trade': action == 'NO_TRADE',
            'setup_side_candidate': candidate,
            'setup_master_regime': master,
            'setup_regime_bucket': bucket,
            'setup_direction_edge': direction_edge,
            'setup_magnitude_edge': magnitude_edge,
            'setup_trade_quality': trade_quality,
            'setup_quality': trade_quality,
            'setup_strictness_bucket': strictness,
            'setup_min_direction_edge': policy['min_direction_edge'],
            'setup_min_magnitude_edge': policy['min_magnitude_edge'],
            'setup_min_trade_quality': policy['min_trade_quality'],
            'setup_min_quality': policy['min_trade_quality'],
            'market_potential_pct': round(potential_pct,6),
            'market_potential_usd': round(potential_usd,2),
            'setup_target_price': round(target_price,2),
            'setup_target_distance_pct': round(target_pct,6),
            'setup_target_distance_usd': round(target_usd,2),
            'setup_invalidation_price': round(stop_price,2),
            'setup_invalidation_distance_pct': round(stop_pct,6),
            'setup_invalidation_distance_usd': round(stop_usd,2),
            'setup_rr': round(rr or 0.0,4),
            'setup_rr_target_dynamic': round(desired_rr,4),
            'setup_expected_value_pct': round(ev_pct,6),
            'setup_effective_confidence': round(effective_conf,3),
            'setup_confidence_bucket': ('elite_55_plus' if effective_conf >= 55 else 'watch_52_55' if effective_conf >= 52 else 'low_under_52'),
            'setup_confidence_filter_pass_52': bool(effective_conf >= 52),
            'setup_confidence_filter_pass_55': bool(effective_conf >= 55),
            'setup_min_expected_value_pct': policy['min_ev'],
            'setup_min_market_potential_pct': policy['min_potential'],
            'setup_reason': reason,
            'setup_specialist_tags': spec_meta.get('specialist_tags', []),
            'setup_context_json': {**meta, **spec_meta, 'alpha_state': alpha_state, 'dynamic_policy': policy, 'noise_pct': round(noise_pct,6), 'target_stop_method': target_stop_method, 'triple_gates': gates},
            'specialist_setup_type': alpha_state.get('specialist_setup_type'),
            'selected_specialist_score': alpha_state.get('selected_specialist_score'),
            'reversal_alpha_score': alpha_state.get('reversal_score'),
            'trend_continuation_alpha_score': alpha_state.get('continuation_score'),
            'reversal_tradeable': alpha_state.get('reversal_tradeable'),
            'trend_continuation_tradeable': alpha_state.get('continuation_tradeable'),
        })
        out.update(self._alert_quality(out, policy))
        if not live:
            self.evaluate_historical_setup(out)
        return out

    def evaluate_historical_setup(self, item: dict) -> dict:
        action = str(item.get('setup_action') or 'NO_TRADE')
        entry = _finite(item.get('start_price') or item.get('entry_price'), 0.0)
        high = _finite(item.get('actual_high'), entry)
        low = _finite(item.get('actual_low'), entry)
        actual = _finite(item.get('actual_price'), entry)
        if entry <= 0:
            item.update({'setup_outcome':'unscored_missing_entry'})
            return item
        side = item.get('setup_side_candidate') or ('LONG' if _finite(item.get('expected_move_pct'),0)>=0 else 'SHORT')
        target = _finite(item.get('setup_target_price'), entry)
        stop = _finite(item.get('setup_invalidation_price'), entry)
        if side == 'LONG':
            mfe = max(0.0, high-entry); mae = max(0.0, entry-low)
            target_hit = high >= target; stop_hit = low <= stop; exit_usd = actual-entry
        else:
            mfe = max(0.0, entry-low); mae = max(0.0, high-entry)
            target_hit = low <= target; stop_hit = high >= stop; exit_usd = entry-actual
        target_usd = abs(target-entry); stop_usd = abs(stop-entry)
        # Conservative if both hit because intra-horizon ordering is unknown.
        valid_trade_existed = bool(target_hit and not stop_hit)
        no_trade_correct = None
        if action == 'NO_TRADE':
            no_trade_correct = not valid_trade_existed
            setup_outcome = 'no_trade_correct' if no_trade_correct else 'no_trade_missed_valid_trade'
            return_pct = 0.0
        else:
            if target_hit and not stop_hit:
                setup_outcome = 'target_hit_first_or_only'; return_pct = target_usd/entry*100.0
            elif stop_hit:
                setup_outcome = 'stop_hit_or_ambiguous'; return_pct = -stop_usd/entry*100.0
            else:
                setup_outcome = 'neither_hit_mark_to_horizon'; return_pct = exit_usd/entry*100.0
        item.update({
            'setup_target_hit': bool(target_hit), 'setup_stop_hit': bool(stop_hit), 'setup_both_hit_ambiguous': bool(target_hit and stop_hit),
            'setup_mfe_usd': round(mfe,2), 'setup_mae_usd': round(mae,2), 'setup_mfe_pct': round(mfe/entry*100.0,6), 'setup_mae_pct': round(mae/entry*100.0,6),
            'setup_return_pct': round(return_pct,6), 'setup_valid_trade_existed': valid_trade_existed, 'no_trade_correct': no_trade_correct, 'setup_outcome': setup_outcome,
            'setup_eval_method': 'legacy_high_low_conservative_both_loss',
        })
        # v10.16.84: keep legacy fields for comparison, but add fair v2
        # first-touch/mark-to-close evaluation so ambiguous target+stop rows are
        # no longer automatically counted as losses in audit exports.
        try:
            evaluate_historical_setup_v2(item, db=db, symbol=settings.symbol, horizon_seconds_map=HORIZON_SECONDS)
        except Exception as exc:
            item.update({'setup_eval_method_v2': 'v2_error', 'setup_eval_error_v2': str(exc)[:240]})
        return item

    def select_many(self, items: list[dict]) -> list[dict]:
        # v10.16.85: Random1000 used to call trade_evaluation_v2 for every
        # horizon row, and that module queried DuckDB per item to resolve
        # first-touch. 7000 rows x several intervals kept Uvicorn at high CPU
        # and the mobile UI appeared stuck at 95%. Preload the full required
        # 1H candle window once, then let trade_evaluation_v2 slice in memory.
        try:
            cutoffs = [int(float(i.get('cutoff_ms') or 0)) for i in (items or []) if i.get('cutoff_ms') is not None]
            if cutoffs:
                start_ms = max(0, min(cutoffs) - 3600000)
                end_ms = max(cutoffs) + 90*24*3600000 + 3600000
                rows = db.df(
                    """
                    SELECT open_time, open, high, low, close
                    FROM raw_candles
                    WHERE source='binance' AND symbol=? AND interval='1h'
                      AND open_time>? AND open_time<=?
                    ORDER BY open_time ASC
                    """,
                    [settings.symbol, start_ms, end_ms],
                )
                if rows is not None and len(rows) > 0:
                    set_bulk_candle_cache(settings.symbol, '1h', rows.to_dict('records'))
        except Exception:
            pass
        try:
            return [self.select(i, str(i.get('horizon') or '1h'), live=False) for i in items]
        finally:
            clear_bulk_candle_cache()
