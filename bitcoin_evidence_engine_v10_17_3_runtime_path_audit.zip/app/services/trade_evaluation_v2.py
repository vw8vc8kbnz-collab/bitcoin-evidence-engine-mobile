from __future__ import annotations

"""
Verbeterde, eerlijke trade-uitkomst-evaluatie voor de Bitcoin Evidence Engine.

PROBLEEM dat dit oplost
-----------------------
De huidige TradeSetupSelector.evaluate_historical_setup rekent een trade waarbij
zowel target als stop binnen de horizon geraakt worden ("both hit") conservatief
af als VERLIES. In de v10.16.83 Random-1000 export waren dat 181 van de 446
trades, en ~52% daarvan was bij slotkoers eigenlijk juist. Daardoor lijkt het
systeem ~169% slechter dan het in werkelijkheid is.

OPLOSSING (twee niveaus van eerlijkheid)
----------------------------------------
1. FIRST-TOUCH op 1h-resolutie: loop door de uur-candles binnen de horizon en
   bepaal welke prijs als EERSTE geraakt werd (target of stop). Dit lost de
   meeste ambiguïteit op en is exact hoe een echte trade zou zijn afgelopen.
   (De engine heeft dit al in _actual_info_after; deze module maakt het
   herbruikbaar en laat de selector het ook gebruiken.)

2. INTRA-CANDLE ambiguïteit: als target en stop in DEZELFDE 1h-candle vallen,
   is de volgorde nog steeds onbekend. In plaats van willekeurig "verlies" te
   kiezen, doen we het eerlijk:
     - probeer fijnere data (bv. 1m/5m) als die er is;
     - anders: gebruik een transparante, neutrale conventie op basis van waar
       de candle opende en sloot (welke kant was waarschijnlijker eerst), en
       label de uitkomst expliciet als 'intra_candle_estimated' zodat het in de
       statistiek apart telbaar is.

Geen lookahead: alle candles liggen binnen [cutoff, cutoff+horizon]; we kijken
nooit verder dan de horizon zelf.
"""

from typing import Any, Optional


def _f(v: Any, d: float = 0.0) -> float:
    try:
        x = float(v)
        return x if x == x else d
    except Exception:
        return d

# v10.16.85 bulk candle cache: Random1000 evaluates ~7000 rows.
# Querying DuckDB per row caused Uvicorn to sit at high CPU and the mobile UI
# to remain at 95%.  The selector now preloads the required 1H candles once
# and this module slices them in memory with bisect.
_BULK_CANDLE_CACHE = {}

def set_bulk_candle_cache(symbol: str, interval: str, candles: list[dict]) -> None:
    try:
        import bisect
        rows = sorted((candles or []), key=lambda r: int(_f(r.get('open_time'), 0)))
        ts = [int(_f(r.get('open_time'), 0)) for r in rows]
        _BULK_CANDLE_CACHE[(str(symbol), str(interval))] = {'rows': rows, 'ts': ts}
    except Exception:
        pass

def clear_bulk_candle_cache() -> None:
    try:
        _BULK_CANDLE_CACHE.clear()
    except Exception:
        pass

def _cached_slice(symbol: str, interval: str, cutoff_ms: int, end_ms: int) -> list[dict]:
    try:
        import bisect
        c = _BULK_CANDLE_CACHE.get((str(symbol), str(interval)))
        if not c:
            return []
        ts = c.get('ts') or []
        rows = c.get('rows') or []
        a = bisect.bisect_right(ts, int(cutoff_ms))
        b = bisect.bisect_right(ts, int(end_ms))
        return rows[a:b]
    except Exception:
        return []


def resolve_first_touch(
    candles: list[dict],
    *,
    side: str,
    entry: float,
    target_price: float,
    stop_price: float,
) -> dict:
    """Bepaal de uitkomst van een trade via first-touch op de gegeven candles.

    candles: chronologisch gesorteerde lijst van dicts met open/high/low/close
             (1h, of fijner als beschikbaar) binnen [cutoff, cutoff+horizon].
    side: 'LONG' of 'SHORT'.
    Retourneert een dict met outcome, return_pct en diagnostische velden.
    """
    if entry <= 0 or not candles:
        return {"outcome": "unresolved", "return_pct": 0.0, "method": "no_data"}

    is_long = side == "LONG"
    target_first_idx: Optional[int] = None
    stop_first_idx: Optional[int] = None
    both_same_candle_idx: Optional[int] = None

    for i, c in enumerate(candles):
        hi = _f(c.get("high")); lo = _f(c.get("low"))
        if is_long:
            t_hit = hi >= target_price
            s_hit = lo <= stop_price
        else:
            t_hit = lo <= target_price
            s_hit = hi >= stop_price

        if t_hit and s_hit:
            # Beide in dezelfde candle -> volgorde onbekend op dit timeframe.
            if target_first_idx is None and stop_first_idx is None:
                both_same_candle_idx = i
                break
        if t_hit and target_first_idx is None:
            target_first_idx = i
        if s_hit and stop_first_idx is None:
            stop_first_idx = i
        if target_first_idx is not None or stop_first_idx is not None:
            break

    target_ret = (abs(target_price - entry) / entry) * 100.0
    stop_ret = -(abs(stop_price - entry) / entry) * 100.0

    # Duidelijke first-touch beslissing.
    if both_same_candle_idx is None:
        if target_first_idx is not None and (stop_first_idx is None or target_first_idx < stop_first_idx):
            return {"outcome": "win", "return_pct": round(target_ret, 6), "method": "first_touch", "touch_idx": target_first_idx}
        if stop_first_idx is not None and (target_first_idx is None or stop_first_idx < target_first_idx):
            return {"outcome": "loss", "return_pct": round(stop_ret, 6), "method": "first_touch", "touch_idx": stop_first_idx}
        # Geen van beide geraakt -> mark-to-close op laatste candle.
        last_close = _f(candles[-1].get("close"), entry)
        mtc = (last_close / entry - 1.0) * 100.0 * (1 if is_long else -1)
        return {"outcome": "open_mark_to_close", "return_pct": round(mtc, 6), "method": "mark_to_close"}

    # Intra-candle ambiguïteit: target en stop in dezelfde candle.
    c = candles[both_same_candle_idx]
    return _resolve_intra_candle(c, side=side, entry=entry, target_price=target_price,
                                 stop_price=stop_price, target_ret=target_ret, stop_ret=stop_ret)


def _resolve_intra_candle(candle: dict, *, side: str, entry: float, target_price: float,
                          stop_price: float, target_ret: float, stop_ret: float) -> dict:
    """Eerlijke afhandeling als target+stop in dezelfde candle vallen.

    Heuristiek (transparant, neutraal): het pad binnen een candle loopt typisch
    van open -> (high/low in onbekende volgorde) -> close. We gebruiken de positie
    van de OPEN t.o.v. target/stop als beste neutrale schatting van wat eerst
    waarschijnlijk werd geraakt. Dit is GEEN garantie; daarom labelen we het als
    'intra_candle_estimated' zodat je deze trades in de statistiek apart kunt
    wegen of uitsluiten.
    """
    is_long = side == "LONG"
    o = _f(candle.get("open"), entry)
    # Afstand van open tot target en tot stop; dichtstbijzijnde wordt waarschijnlijk eerst geraakt.
    dist_to_target = abs(target_price - o)
    dist_to_stop = abs(stop_price - o)
    if dist_to_target < dist_to_stop:
        return {"outcome": "win", "return_pct": round(target_ret, 6), "method": "intra_candle_estimated",
                "note": "open dichter bij target; volgorde geschat"}
    elif dist_to_stop < dist_to_target:
        return {"outcome": "loss", "return_pct": round(stop_ret, 6), "method": "intra_candle_estimated",
                "note": "open dichter bij stop; volgorde geschat"}
    else:
        # Echt onbeslisbaar: tel als 50/50 (halve win + halve loss) i.p.v. willekeurig verlies.
        return {"outcome": "ambiguous_5050", "return_pct": round((target_ret + stop_ret) / 2.0, 6),
                "method": "intra_candle_5050", "note": "open exact tussen target en stop"}


def fetch_horizon_candles(db, symbol: str, cutoff_ms: int, horizon_seconds: int,
                          *, interval: str = "1h") -> list[dict]:
    """Haal candles binnen [cutoff, cutoff+horizon] op. Probeer fijner timeframe
    (1m/5m) als die in de DB staan voor betere intra-candle resolutie."""
    end_ms = cutoff_ms + horizon_seconds * 1000
    # Fast path for Random1000: use preloaded 1H cache and never hit DuckDB per row.
    cached = _cached_slice(symbol, "1h", cutoff_ms, end_ms)
    if cached:
        return cached
    # Voorkeur: fijnste beschikbare interval voor minste ambiguïteit.
    for iv in tuple(dict.fromkeys(["1m", "5m", "15m", interval, "1h"])):
        try:
            rows = db.df(
                """
                SELECT open_time, open, high, low, close
                FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval=? AND open_time>? AND open_time<=?
                ORDER BY open_time ASC
                """,
                [symbol, iv, cutoff_ms, end_ms],
            )
            if rows is not None and len(rows) > 0:
                return rows.to_dict("records")
        except Exception:
            continue
    return []


# ---------------------------------------------------------------------------
# Drop-in vervanger voor TradeSetupSelector.evaluate_historical_setup
# ---------------------------------------------------------------------------
def evaluate_historical_setup_v2(item: dict, *, db=None, symbol: str = "BTCUSDT",
                                 horizon_seconds_map: dict | None = None) -> dict:
    """Eerlijke vervanger. Gebruikt first-touch op 1h (of fijner) i.p.v.
    'both hit = verlies'. Valt terug op de oude high/low-only methode als er
    geen db/candles beschikbaar zijn, maar labelt dat dan expliciet.
    """
    action = str(item.get("setup_action") or item.get("action") or "NO_TRADE")
    entry = _f(item.get("start_price") or item.get("entry_price"), 0.0)
    side = item.get("setup_side_candidate") or item.get("candidate_side") or (
        "LONG" if _f(item.get("expected_move_pct"), 0) >= 0 else "SHORT")
    target = _f(item.get("setup_target_price") or item.get("target_price"), entry)
    stop = _f(item.get("setup_invalidation_price") or item.get("invalidation_price"), entry)

    if entry <= 0:
        item.update({"setup_outcome": "unscored_missing_entry"})
        return item

    # Ook NO_TRADE krijgt een v2-valid-trade check: bestond er achteraf een
    # target-first setup volgens dezelfde first-touch logica?  De trade zelf blijft
    # uiteraard 0% return, maar no_trade_correct_v2 wordt eerlijker gemeten dan
    # de oude high/low both=loss benadering.
    is_no_trade = action == "NO_TRADE"

    candles: list[dict] = []
    if db is not None and horizon_seconds_map is not None:
        hsec = int(horizon_seconds_map.get(str(item.get("horizon") or "24h"), 24 * 3600))
        cutoff_ms = int(_f(item.get("cutoff_ms"), 0))
        if cutoff_ms > 0:
            candles = fetch_horizon_candles(db, symbol, cutoff_ms, hsec)

    if candles:
        res = resolve_first_touch(candles, side=side, entry=entry, target_price=target, stop_price=stop)
        valid_trade_v2 = str(res.get("outcome")) == "win"
        item.update({
            "setup_outcome_v2": res["outcome"],
            "setup_return_pct_v2": 0.0 if is_no_trade else res["return_pct"],
            "setup_eval_method_v2": res["method"],
            "setup_valid_trade_existed_v2": bool(valid_trade_v2),
        })
        if is_no_trade:
            item.update({
                "no_trade_correct_v2": not valid_trade_v2,
                "setup_outcome_v2": "no_trade_correct_v2" if not valid_trade_v2 else "no_trade_missed_valid_trade_v2",
            })
    else:
        # Fallback: oude high/low-only methode, maar eerlijk gelabeld.
        hi = _f(item.get("actual_high"), entry); lo = _f(item.get("actual_low"), entry)
        ac = _f(item.get("actual_price"), entry)
        is_long = side == "LONG"
        if is_long:
            t_hit = hi >= target; s_hit = lo <= stop
        else:
            t_hit = lo <= target; s_hit = hi >= stop
        target_ret = abs(target - entry) / entry * 100.0
        stop_ret = -abs(stop - entry) / entry * 100.0
        if t_hit and not s_hit:
            out, ret = "win", target_ret
        elif s_hit and not t_hit:
            out, ret = "loss", stop_ret
        elif t_hit and s_hit:
            # eerlijk: mark-to-close i.p.v. automatisch verlies
            mtc = (ac / entry - 1.0) * 100.0 * (1 if is_long else -1)
            out, ret = "ambiguous_mark_to_close", mtc
        else:
            out, ret = "open_mark_to_close", (ac / entry - 1.0) * 100.0 * (1 if is_long else -1)
        valid_trade_v2 = out == "win" or (out in ("ambiguous_mark_to_close", "open_mark_to_close") and ret > 0)
        item.update({
            "setup_outcome_v2": out,
            "setup_return_pct_v2": 0.0 if is_no_trade else round(ret, 6),
            "setup_eval_method_v2": "high_low_only_no_candles",
            "setup_valid_trade_existed_v2": bool(valid_trade_v2),
        })
        if is_no_trade:
            item.update({
                "no_trade_correct_v2": not valid_trade_v2,
                "setup_outcome_v2": "no_trade_correct_v2" if not valid_trade_v2 else "no_trade_missed_valid_trade_v2",
            })
    return item
