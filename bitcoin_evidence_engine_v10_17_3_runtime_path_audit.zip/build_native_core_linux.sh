#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p native_core/bin logs

# v10.16.5 IMPORTANT:
# The Python bridge calls the ADAPTIVE native interface:
#   tm_random candles.csv features.csv adaptive_weights.csv count seed output.json
#   tm_single candles.csv features.csv adaptive_weights.csv cutoff_ms output.json
# The old C++ source in native_core/src is not compatible with that argument order.
# Therefore Linux VPS builds MUST build the Go native core from native_core/go_src.

if ! command -v go >/dev/null 2>&1; then
  echo "ERROR: Go is not installed. Run: bash install_vps.sh" >&2
  exit 1
fi

echo "Building Linux compiled native engine core (no Python fallback)..."
GO111MODULE=off go build -trimpath -ldflags="-s -w" -o native_core/bin/bee_native_core ./native_core/go_src
chmod +x native_core/bin/bee_native_core

echo "OK: native_core/bin/bee_native_core (compiled native engine core required)"
./native_core/bin/bee_native_core >/dev/null 2>&1 || true
