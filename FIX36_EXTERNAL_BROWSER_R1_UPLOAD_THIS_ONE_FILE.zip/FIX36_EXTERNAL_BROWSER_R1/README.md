# FIX36 external browser run R1

This package tests the exact delivered FIX36 application. `candidate.zip` is the
complete application ZIP, byte-for-byte unchanged. This is a separate test
package; its launcher does not install or restart the application.

## Execution

The launcher uses the existing pinned Playwright Docker image. It prepares the
exact Node 24 / Playwright 1.62.0 toolchain from the unchanged dependency lock in
a separate container. Package installation uses `npm ci --ignore-scripts`.
Only this preparation container has network access. The actual browser container
has `--network none`, no host ports and no live application/state mounts.

The original R4 oracle starts its own loopback servers and synthetic customer,
catalog, pricing and job state. Both Chromium and WebKit are mandatory. The
browser container is limited to 1.25 CPUs, 1536 MiB RAM and 512 processes; its
overall deadline is 90 minutes. Only one worker can run per run directory parent.
Each fixture also has a 10-minute deadline. Missing or failing results are retained.

The host worker runs independently of the SSH session. The start command returns
immediately. The status command reads its private run directory. After completion,
upload the `FIX36_BROWSER_EVIDENCE_*.zip` shown in the status output. A start marker
or a generated ZIP does not mean the browser tests passed: inspect `status`.

## Scope and provenance

The registry and JavaScript driver are byte-exact R4 sources recovered from commit
`1855dce5bf2ee112e88b84a6af303f6d39b0289e` and verified against the user's historical
execution evidence. All 18 fixtures and 130 required assertion IDs are unchanged.
This includes the three additional mobile material/panel, optimization/checkout
and grain discovery/reorder scenarios, plus the original R4 customer-field,
idempotency, controlled-cancellation and pricing-observation corrections.

The Python oracle differs only in explicit standalone ancestry (it does not
claim to run inside the historical Git checkout) and fixture progress messages.
See `R4_RUNNER_ADAPTATION.patch`. No runtime application file is replaced by R4
application code. The candidate and golden artifacts are safely snapshotted,
hash-verified and fully manifest-checked before execution. The report retains
the detailed fixture, profile, assertion, source mutation and engine ledgers.

A PASS is revalidated against those ledgers, exact current-run timestamps,
source hashes and artifact manifests before the external summary can say PASS.
It is not reconstructed from an old report. The native report remains intact.

## Limits and remaining release work

This is the full R4 oracle on FIX36. It is a separate 18-fixture evidence report,
not a fabricated 15-fixture report for the older FIX33 aggregate contract. That
older in-application contract is left unchanged; this complete R4 evidence must
be reconciled explicitly with the final external audit contract before aggregate
release signoff. No automatic production approval is generated.

The R4 Admin scenario checks login, presentation assets, basic viewport fit and
session behavior. It does not replace the planned checks of all six redesigned
Admin sections, Inbox pagination and actions, catalog publication, price saving,
Jobs text viewer, or a physical iPhone keyboard. Clean-server installation,
restore, domain/TLS, independent security, operations and CAM/business review
also remain separate release steps. `productionGo` and `releaseEligible` stay false.
