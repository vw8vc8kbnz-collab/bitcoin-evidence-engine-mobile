#!/usr/bin/env python3
"""Detach a bounded Docker audit worker. Never mount or restart the live tool."""
import argparse
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import traceback
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from common import IMAGE, GOLDEN_SHA, atomic_json, digest, verify_package
sys.path.insert(0, str(ROOT / 'support'))
from verify_standalone_artifact import snapshot_and_verify_artifact


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def write_status(run, status, phase, **values):
    atomic_json(run / 'RUN_STATUS.json', {
        'status': status, 'phase': phase, 'updatedAtUtc': utc_now(),
        'productionGo': False, 'runDirectory': str(run), **values,
    })
    print(status + ': ' + phase, flush=True)


def private_parent(path):
    path = path.expanduser().absolute()
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    metadata = path.lstat()
    if not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != os.getuid() or metadata.st_mode & 0o077:
        raise ValueError('Run parent must be a private directory owned by this account')
    return path.resolve()


def docker_command():
    docker = shutil.which('docker')
    if not docker:
        raise ValueError('Docker CLI is not installed')
    candidates = [[docker]]
    if shutil.which('sudo'):
        candidates.append(['sudo', '-n', docker])
    for prefix in candidates:
        result = subprocess.run(prefix + ['version', '--format', '{{.Server.Version}}'],
                                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=20)
        if result.returncode == 0:
            return prefix
    raise ValueError('Docker is not accessible directly or through sudo -n')


def container_args(run, name, network, mounts):
    args = ['run', '--rm', '--pull=never', '--init', '--name', name, '--network', network,
            '--read-only', '--user', str(os.getuid()) + ':' + str(os.getgid()),
            '--cpus=1.25', '--memory=1536m', '--memory-swap=3g', '--pids-limit=512',
            '--shm-size=256m', '--cap-drop=ALL', '--security-opt=no-new-privileges',
            '--tmpfs', '/tmp:rw,nosuid,nodev,size=128m', '--workdir', '/scratch',
            '--env', 'TMPDIR=/scratch', '--env', 'PYTHONDONTWRITEBYTECODE=1',
            '--env', 'PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1']
    for source, target, writable in mounts:
        if ',' in str(source):
            raise ValueError('Comma in audit mount path is unsupported')
        mount = 'type=bind,source=' + str(source) + ',destination=' + target
        if not writable:
            mount += ',readonly'
        args.extend(['--mount', mount])
    return args


def run_container(prefix, args, name, logfile, timeout):
    with logfile.open('wb') as output:
        try:
            result = subprocess.run(prefix + args, stdin=subprocess.DEVNULL, stdout=output,
                                    stderr=subprocess.STDOUT, timeout=timeout)
            return result.returncode
        except subprocess.TimeoutExpired:
            # The unique name belongs only to this run. No other container is selected.
            subprocess.run(prefix + ['rm', '--force', name], stdin=subprocess.DEVNULL,
                           stdout=output, stderr=subprocess.STDOUT, timeout=30, check=False)
            raise TimeoutError('Audit container exceeded its deadline: ' + name)


def export_evidence(run):
    target = run / ('FIX36_BROWSER_EVIDENCE_' + run.name + '.zip')
    files = [run / 'RUN_STATUS.json', run / 'KIT_IDENTITY.json', run / 'WORKER.log',
             ROOT / 'PACKAGE_SHA256SUMS.json', ROOT / 'R4_RUNNER_ADAPTATION.patch',
             ROOT / 'README.md', ROOT / 'oracle/FIX36_R4_PROVENANCE.json']
    files += [p for p in (run / 'evidence').rglob('*') if p.is_file()]
    files += [p for p in (run / 'logs').rglob('*') if p.is_file()]
    ledger = []
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            if not path.exists():
                continue
            if path.is_symlink():
                raise ValueError('Symlink in evidence export')
            name = path.relative_to(run).as_posix()
            archive.write(path, name)
            ledger.append(digest(path) + '  ' + name + '\n')
        archive.writestr('SHA256SUMS.txt', ''.join(ledger))
    return target


def worker(run):
    os.umask(0o077)
    if ROOT != run / 'kit':
        raise ValueError('Worker must run from its private package copy')
    outcome, code = 'FAIL', 1
    try:
        verify_package(ROOT)
        prefix = docker_command()
        image = json.loads(subprocess.check_output(prefix + ['image', 'inspect', IMAGE], timeout=30))[0]
        if IMAGE not in (image.get('RepoDigests') or []) or image.get('Architecture') != 'amd64':
            raise ValueError('The reviewed amd64 browser image is unavailable')
        atomic_json(run / 'evidence/CONTAINER_IDENTITY.json', {
            key: image.get(key) for key in ['Id', 'RepoDigests', 'Architecture', 'Os']
        })
        write_status(run, 'RUNNING', 'PINNED_TOOLCHAIN_PREPARATION')
        base_mounts = [(ROOT, '/kit', False), (run / 'scratch', '/scratch', True)]
        prepare_name = 'fix36-prepare-' + run.name.lower()
        args = container_args(run, prepare_name, 'bridge', base_mounts + [(run / 'toolchain', '/toolchain', True)])
        args += [IMAGE, 'bash', '-c',
                 'set -Eeuo pipefail; node -e "if (!process.version.startsWith(\'v24.\')) process.exit(1)"; '
                 'cp /kit/oracle/browser/package.json /kit/oracle/browser/package-lock.json /toolchain/; '
                 'npm --prefix /toolchain ci --ignore-scripts --engine-strict --no-audit --no-fund --cache /scratch/npm-cache']
        result = run_container(prefix, args, prepare_name, run / 'logs/TOOLCHAIN.log', 600)
        if result != 0:
            raise ValueError('Pinned toolchain preparation failed; inspect TOOLCHAIN.log')
        write_status(run, 'RUNNING', 'CHROMIUM_WEBKIT_18_FIXTURES')
        browser_name = 'fix36-browser-' + run.name.lower()
        args = container_args(run, browser_name, 'none', base_mounts + [
            (run / 'toolchain', '/toolchain', False), (run / 'inputs', '/inputs', False),
            (run / 'evidence', '/evidence', True)])
        args += [IMAGE, '/usr/bin/python3', '-I', '-S', '-B', '/kit/run_browser.py']
        code = run_container(prefix, args, browser_name, run / 'logs/BROWSER.log', 5400)
        summary = json.loads((run / 'evidence/BROWSER_RESULT.json').read_text())
        outcome = summary.get('status')
        if outcome not in {'PASS', 'FAIL', 'NO_GO'} or code != {'PASS': 0, 'FAIL': 1, 'NO_GO': 3}[outcome]:
            raise ValueError('Browser process and report disagree')
        write_status(run, outcome, 'BROWSER_RUN_FINISHED', browserReport='evidence/BROWSER_RESULT.json')
    except Exception as exc:
        outcome, code = 'FAIL', 1
        write_status(run, outcome, 'RUN_FAILED', error=str(exc))
        traceback.print_exc()
    finally:
        try:
            package = export_evidence(run)
            write_status(run, outcome, 'EVIDENCE_EXPORTED', evidenceZip=str(package), evidenceZipSha256=digest(package))
            print('UPLOAD_DIT_BESTAND=' + str(package), flush=True)
        except Exception as exc:
            code = 1
            write_status(run, 'FAIL', 'EVIDENCE_EXPORT_FAILED', error=str(exc))
    return code


def launch(args):
    os.umask(0o077)
    if os.getuid() == 0:
        raise ValueError('Run this launcher as ubuntu; it invokes sudo only for Docker')
    verify_package(ROOT)
    parent = private_parent(args.run_parent)
    descriptor = os.open(parent / 'runner.lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        os.close(descriptor)
        raise ValueError('An audit worker is already running; use the status command')
    try:
        run = Path(tempfile.mkdtemp(prefix=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ_'), dir=parent))
        shutil.copytree(ROOT, run / 'kit')
        verify_package(run / 'kit')
        for name in ['inputs', 'scratch', 'evidence', 'logs', 'toolchain']:
            (run / name).mkdir(mode=0o700)
        snapshot_and_verify_artifact(args.golden_archive, run / 'inputs/golden.zip', expected_sha256=GOLDEN_SHA)
        atomic_json(run / 'KIT_IDENTITY.json', {'packageManifestSha256': digest(run / 'kit/PACKAGE_SHA256SUMS.json'),
                                             'createdAtUtc': utc_now(), 'productionGo': False})
        write_status(run, 'STARTING', 'WORKER_LAUNCH')
        # Persist the path before starting, so a fast worker cannot race with it.
        pointer = parent / 'LATEST_RUN.tmp'
        pointer.write_text(str(run) + '\n')
        pointer.replace(parent / 'LATEST_RUN.txt')
        with (run / 'WORKER.log').open('ab') as output:
            process = subprocess.Popen([
                sys.executable, '-I', '-S', '-B', str(run / 'kit/launch.py'), '--worker', str(run)
            ], stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
               cwd=run, start_new_session=True, pass_fds=(descriptor,))
        print('FIX36_BROWSER_GESTART')
        print('WERKMAP=' + str(run))
        print('WORKER_PID=' + str(process.pid))
        print('De test loopt zelfstandig door. Bekijk de status met de meegeleverde statusopdracht.')
    finally:
        os.close(descriptor)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-parent', type=Path, default=Path.home() / 'metod-fix36-browser-runs')
    parser.add_argument('--golden-archive', type=Path)
    parser.add_argument('--worker', type=Path)
    args = parser.parse_args()
    if args.worker:
        return worker(args.worker.resolve())
    if args.golden_archive is None:
        parser.error('--golden-archive is required')
    try:
        launch(args)
        return 0
    except Exception as exc:
        print('FIX36_BROWSER_START_MISLUKT: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
