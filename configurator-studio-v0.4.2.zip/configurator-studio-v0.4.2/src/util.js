// Small, dependency-free utilities shared across the app.

export function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k === 'text') node.textContent = v;
    else if (k === 'style') node.setAttribute('style', v);
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else node.setAttribute(k, v);
  }
  (Array.isArray(children) ? children : [children]).forEach((c) => {
    if (c == null || c === false) return;
    node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  });
  return node;
}

export function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }
export function mount(node, child) { clear(node); node.appendChild(child); return node; }

export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export function euro(n, currency = 'EUR') {
  try { return new Intl.NumberFormat('nl-NL', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n); }
  catch { return '€' + Math.round(n).toLocaleString('nl-NL'); }
}

export function uid(prefix = 'id') {
  return prefix + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
}

export function debounce(fn, ms = 300) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

// Minimal event emitter — the engine and store use it to stay framework-agnostic.
export class Emitter {
  constructor() { this._h = new Map(); }
  on(evt, fn) { (this._h.get(evt) || this._h.set(evt, new Set()).get(evt)).add(fn); return () => this.off(evt, fn); }
  off(evt, fn) { const s = this._h.get(evt); if (s) s.delete(fn); }
  emit(evt, payload) { const s = this._h.get(evt); if (s) [...s].forEach((fn) => { try { fn(payload); } catch (e) { console.error(e); } }); }
}

let toastTimer = null;
export function toast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

export const isTouch = () => matchMedia('(pointer: coarse)').matches;
export const prefersReducedMotion = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
