// ============================================================================
// STORAGE + STORE
//
// StorageAdapter is the ONLY place that knows how data is persisted.
// Today it is localStorage. To move to Supabase/your API, implement the same
// four methods in a new adapter and swap `adapter` below — no other file changes.
// ============================================================================

import { Emitter } from './util.js';
import { seedLibrary, seedProjects } from './seed.js';

const KEY = 'variant_studio_db_v1';
let memoryDb = null; // fallback when localStorage is blocked/unavailable

/** @typedef {{get(k):Promise<any>, set(k,v):Promise<void>, all():Promise<any>, wipe():Promise<void>}} StorageAdapter */

/** localStorage implementation. */
const LocalStorageAdapter = {
  async all() {
    try { return JSON.parse(localStorage.getItem(KEY) || 'null') || memoryDb; } catch { return memoryDb; }
  },
  async save(db) {
    memoryDb = db;
    try { localStorage.setItem(KEY, JSON.stringify(db)); }
    catch (e) { console.warn('[Configurator Studio] localStorage unavailable; using in-memory fallback.', e); }
  },
  async wipe() {
    memoryDb = null;
    try { localStorage.removeItem(KEY); } catch {}
  },
};

// To use your backend later:
//   const ApiAdapter = { async all(){ return fetch('/api/db').then(r=>r.json()); },
//                        async save(db){ await fetch('/api/db',{method:'PUT',body:JSON.stringify(db)}); }, ... }
const adapter = LocalStorageAdapter;

// ----------------------------------------------------------------------------
// In-memory mirror. Reads are synchronous (fast UI), writes persist async.
// ----------------------------------------------------------------------------
class Store extends Emitter {
  constructor() { super(); this.db = { projects: {}, library: [], configurations: {}, aiJobs: {} }; this.ready = false; }

  async init() {
    const stored = await adapter.all();
    if (stored && stored.projects) {
      this.db = stored;
      if (!this.db.configurations) this.db.configurations = {};
      if (!this.db.aiJobs) this.db.aiJobs = {};
    } else {
      this.db = { projects: {}, library: seedLibrary(), configurations: {}, aiJobs: {} };
      for (const p of seedProjects(this.db.library)) this.db.projects[p.id] = p;
      await this._persist();
    }
    this.ready = true;
    this.emit('change');
  }

  async _persist() { await adapter.save(this.db); }

  // projects
  listProjects() { return Object.values(this.db.projects).sort((a, b) => b.updatedAt - a.updatedAt); }
  getProject(id) { return this.db.projects[id] || null; }
  async saveProject(project) {
    project.updatedAt = Date.now();
    this.db.projects[project.id] = project;
    await this._persist(); this.emit('change'); this.emit('project:' + project.id);
    return project;
  }
  async createProject(project) { this.db.projects[project.id] = project; await this._persist(); this.emit('change'); return project; }
  async deleteProject(id) { delete this.db.projects[id]; await this._persist(); this.emit('change'); }

  // library (account-level finishes)
  getLibrary() { return this.db.library; }
  getFinish(id) { return this.db.library.find((f) => f.id === id) || null; }
  async saveFinish(finish) {
    const i = this.db.library.findIndex((f) => f.id === finish.id);
    if (i >= 0) this.db.library[i] = finish; else this.db.library.push(finish);
    await this._persist(); this.emit('change');
    return finish;
  }
  async deleteFinish(id) { this.db.library = this.db.library.filter((f) => f.id !== id); await this._persist(); this.emit('change'); }

  async duplicateProject(id) {
    const src = this.db.projects[id]; if (!src) return null;
    const copy = JSON.parse(JSON.stringify(src));
    copy.id = 'prj_' + Math.random().toString(36).slice(2, 9);
    copy.name = src.name + ' (kopie)'; copy.status = 'draft'; copy.updatedAt = Date.now();
    this.db.projects[copy.id] = copy; await this._persist(); this.emit('change'); return copy;
  }

  // configurations (saved when a customer adds to cart)
  listConfigurations() { return Object.values(this.db.configurations).sort((a, b) => b.createdAt - a.createdAt); }
  getConfiguration(id) { return this.db.configurations[id] || null; }
  async saveConfiguration(cfg) { this.db.configurations[cfg.id] = cfg; await this._persist(); this.emit('change'); return cfg; }
  async deleteConfiguration(id) { delete this.db.configurations[id]; await this._persist(); this.emit('change'); }

  // AI jobs (mock/skeleton today, provider-backed later)
  listAiJobs(projectId = null) {
    const list = Object.values(this.db.aiJobs || {}).sort((a, b) => b.createdAt - a.createdAt);
    return projectId ? list.filter((j) => j.projectId === projectId) : list;
  }
  getAiJob(id) { return (this.db.aiJobs || {})[id] || null; }
  async saveAiJob(job) {
    if (!this.db.aiJobs) this.db.aiJobs = {};
    job.updatedAt = Date.now();
    this.db.aiJobs[job.id] = job;
    await this._persist(); this.emit('change');
    return job;
  }

  async resetAll() { await adapter.wipe(); this.db = { projects: {}, library: [], configurations: {}, aiJobs: {} }; await this.init(); }
}

export const store = new Store();
