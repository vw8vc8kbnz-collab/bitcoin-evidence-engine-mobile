// Configurations — records saved when a customer adds a configuration to cart.
import { store } from './store.js';
import { el, mount, euro, toast } from './util.js';
import { navigate } from './router.js';

function fmtDate(ts) {
  try { return new Date(ts).toLocaleString('nl-NL', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); }
  catch { return ''; }
}

export function renderConfigurations(container) {
  const list = store.listConfigurations();
  const body = list.length
    ? el('div', { class: 'cfg-list' }, list.map((c) =>
        el('button', { class: 'cfg-row', onclick: () => navigate('#/configs/' + c.id) }, [
          el('span', { class: 'cfg-code mono', text: c.publicCode }),
          el('span', { class: 'cfg-name' }, [el('b', { text: c.projectName }), el('span', { class: 'cfg-sum', text: c.summary.map((s) => s.option).join(' · ') || '—' })]),
          el('span', { class: 'cfg-meta' }, [el('span', { class: 'mono', text: euro(c.total, c.currency) }), el('span', { class: 'cfg-date', text: fmtDate(c.createdAt) })]),
        ])))
    : el('div', { class: 'empty' }, [el('div', { class: 'empty-title', text: 'Nog geen configuraties' }), el('div', { class: 'empty-sub', text: 'Zodra een klant een configuratie toevoegt aan de winkelmand, verschijnt die hier — met configuration_id, gekozen opties en totaal.' })]);

  mount(container, el('div', { class: 'configs' }, [
    el('header', { class: 'sub-header' }, [
      el('div', { class: 'brandmark' }, [el('button', { class: 'tb-back', onclick: () => navigate('#/'), text: '‹' }), el('span', { class: 'diamond' }), el('span', { class: 'brandtext', text: 'Configuraties' })]),
      el('div', { class: 'hint', text: `${list.length} totaal` }),
    ]),
    el('div', { class: 'configs-body' }, [body]),
  ]));
}

export function renderConfigDetail(container, id) {
  const c = store.getConfiguration(id);
  if (!c) { navigate('#/configs'); return; }
  const project = store.getProject(c.projectId);
  const rows = c.summary.map((s) => el('div', { class: 'ps-row' }, [
    el('span', {}, [el('b', { text: s.surface }), document.createTextNode(': ' + s.option)]),
    el('span', { class: 'mono', text: (s.sku ? s.sku + '  ' : '') + (s.delta ? '+' + euro(s.delta, c.currency) : '—') }),
  ]));

  mount(container, el('div', { class: 'configs' }, [
    el('header', { class: 'sub-header' }, [
      el('div', { class: 'brandmark' }, [el('button', { class: 'tb-back', onclick: () => navigate('#/configs'), text: '‹' }), el('span', { class: 'diamond' }), el('span', { class: 'brandtext', text: c.publicCode })]),
    ]),
    el('div', { class: 'configs-body' }, [
      el('div', { class: 'cfg-detail' }, [
        el('div', { class: 'cfg-detail-head' }, [
          el('h2', { class: 'insp-title', text: c.projectName }),
          el('div', { class: 'cfg-total mono', text: euro(c.total, c.currency) }),
        ]),
        el('div', { class: 'cfg-detail-meta mono', text: `${c.publicCode} · ${c.device} · ${fmtDate(c.createdAt)}` }),
        el('div', { class: 'flabel', text: 'Configuratie' }),
        el('div', { class: 'price-summary' }, rows.length ? rows : [el('div', { class: 'ps-row', text: 'Standaardkeuzes' })]),
        el('div', { class: 'flabel', text: 'Shopify line item properties' }),
        el('pre', { class: 'code', text: shopifyProps(c) }),
        el('div', { class: 'cfg-actions' }, [
          project ? el('button', { class: 'btn', onclick: () => navigate('#/preview/' + project.id), text: 'Open configurator' }) : null,
          el('button', { class: 'btn ghost', onclick: async () => { if (confirm('Configuratie verwijderen?')) { await store.deleteConfiguration(c.id); toast('Verwijderd'); navigate('#/configs'); } }, text: 'Verwijderen' }),
        ]),
      ]),
    ]),
  ]));
}

function shopifyProps(c) {
  const props = { _configuration_id: c.publicCode };
  c.summary.forEach((s) => { props[s.surface] = s.option + (s.variantId ? ` (${s.variantId})` : ''); });
  props['Configuratie'] = `https://app.jouwdomein.nl/configs/${c.id}`;
  return JSON.stringify(props, null, 2);
}
