// ============================================================================
// Configurator runtime UI — what the end customer sees.
// Renders any template from a RuntimeConfig and drives the shared engine.
// Used by the live route, the embed route, and the builder Preview step.
// ============================================================================

import { ConfiguratorEngine } from './engine.js';
import { el, mount, euro, clamp } from './util.js';
import { THREE } from './three.js';

function priceOf(config, selection) {
  let t = config.project.basePrice || 0;
  for (const s of config.surfaces) {
    if (!s.configurable) continue;
    const o = s.options.find((x) => x.id === (selection[s.id] || s.defaultOptionId));
    if (o) t += o.delta || 0;
  }
  return t;
}
function defaultSelection(config) {
  const sel = {}; for (const s of config.surfaces) sel[s.id] = s.defaultOptionId || s.options[0]?.id; return sel;
}
function shade(hex, amt) { const c = new THREE.Color(hex), f = amt / 100; c.r = clamp(c.r + f, 0, 1); c.g = clamp(c.g + f, 0, 1); c.b = clamp(c.b + f, 0, 1); return '#' + c.getHexString(); }
function swatchStyle(mat) {
  const hex = mat.colorHex;
  if (mat.kind === 'metal') return `background:linear-gradient(135deg,${shade(hex, 24)},${hex} 45%,${shade(hex, -20)});`;
  if (mat.kind === 'marble') return `background:radial-gradient(120% 120% at 30% 20%,#f4f1ea,${hex} 70%);`;
  if (mat.kind === 'wood') return `background:linear-gradient(150deg,${shade(hex, 16)},${hex} 45%,${shade(hex, -14)});`;
  return `background:${hex};`;
}

/**
 * @param {HTMLElement} container
 * @param {object} config RuntimeConfig
 * @param {{layout?:'desktop'|'mobile', onAddToCart?:Function}} opts
 * @returns {{engine:ConfiguratorEngine, dispose:Function}}
 */
export function renderRuntime(container, config, opts = {}) {
  const layout = opts.layout || 'auto';
  const tpl = config.template?.templateId || 'product_split';
  const selection = defaultSelection(config);

  const root = el('div', { class: `runtime runtime--${tpl} runtime--${layout}` });
  const stage = el('div', { class: 'rt-stage' });
  const brand = config.branding?.showBranding
    ? el('a', { class: 'rt-watermark', href: config.branding.link || '#', target: '_blank', rel: 'noopener' },
        [el('span', { class: 'rt-diamond' }), el('span', { text: config.branding.label || 'jouw merk' })])
    : null;
  if (brand) stage.appendChild(brand);
  const stageWrap = el('div', { class: 'rt-stagewrap' }, [stage]);

  // options + price + cta ----------------------------------------------------
  const priceEl = el('div', { class: 'rt-price', text: euro(priceOf(config, selection), config.project.currency) });
  const cta = el('button', { class: 'rt-cta', style: `--accent:${config.template?.accentColor || '#1b1a17'}`,
    onclick: () => opts.onAddToCart?.(selection, priceOf(config, selection)) }, config.template?.buttonLabel || 'Voeg toe aan winkelmand');

  function animatePrice() {
    const target = priceOf(config, selection);
    const from = parseInt((priceEl.textContent || '').replace(/\D/g, '')) || target;
    if (from === target) { priceEl.textContent = euro(target, config.project.currency); return; }
    const st = performance.now(), dur = 420;
    const step = (now) => { const t = clamp((now - st) / dur, 0, 1); const v = Math.round(from + (target - from) * (1 - Math.pow(1 - t, 3)));
      priceEl.textContent = euro(v, config.project.currency); if (t < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  }

  const groupsWrap = el('div', { class: 'rt-groups' });
  const swatchEls = {};
  config.surfaces.filter((s) => s.configurable).forEach((s) => {
    const group = el('div', { class: 'rt-group' });
    const head = el('div', { class: 'rt-group-head' }, [
      el('span', { class: 'rt-group-label', text: s.name }),
      el('span', { class: 'rt-group-choice', text: (s.options.find((o) => o.id === selection[s.id]) || {}).name || '' }),
    ]);
    const row = el('div', { class: 'rt-swatches' });
    swatchEls[s.id] = [];
    s.options.forEach((o) => {
      const b = el('button', { class: 'rt-swatch' + (selection[s.id] === o.id ? ' sel' : ''), type: 'button',
        'aria-pressed': String(selection[s.id] === o.id), 'aria-label': `${o.name}${o.delta ? ' plus ' + euro(o.delta) : ''}`,
        onclick: () => choose(s, o) }, [
        el('span', { class: 'rt-chip', style: swatchStyle(o.material) }),
        el('span', { class: 'rt-sw-name', text: o.name }),
        el('span', { class: 'rt-sw-delta', text: o.delta ? '+' + euro(o.delta, config.project.currency) : 'inbegrepen' }),
      ]);
      b._optId = o.id; b._surf = s; row.appendChild(b); swatchEls[s.id].push(b);
    });
    group.appendChild(head); group.appendChild(row); groupsWrap.appendChild(group);
    group._choiceEl = head.querySelector('.rt-group-choice'); group._surf = s;
  });

  function choose(surface, option) {
    if (selection[surface.id] === option.id) { engine.focusSurface(surface.id); return; }
    selection[surface.id] = option.id;
    engine.applyOption(surface.id, option.id, true);
    engine.focusSurface(surface.id);
    swatchEls[surface.id].forEach((b) => { const on = b._optId === option.id; b.classList.toggle('sel', on); b.setAttribute('aria-pressed', String(on)); });
    [...groupsWrap.children].forEach((g) => { if (g._surf === surface) g._choiceEl.textContent = option.name; });
    animatePrice();
  }

  // template layout ----------------------------------------------------------
  const header = el('div', { class: 'rt-header' }, [
    el('div', { class: 'rt-eyebrow', text: 'Samenstellen' }),
    el('h2', { class: 'rt-title', text: config.project.name }),
  ]);

  if (tpl === 'compact') {
    const panel = el('div', { class: 'rt-panel' }, [header, groupsWrap,
      el('div', { class: 'rt-footer' }, [el('div', { class: 'rt-price-row' }, [priceEl]), cta])]);
    root.appendChild(el('div', { class: 'rt-compact' }, [stageWrap, panel]));
  } else if (tpl === 'fullscreen') {
    const sheet = el('div', { class: 'rt-sheet' }, [
      el('div', { class: 'rt-sheet-handle' }),
      header, groupsWrap,
      el('div', { class: 'rt-footer' }, [el('div', { class: 'rt-price-row' }, [el('div', { class: 'rt-price-label', text: 'Totaal' }), priceEl]), cta]),
    ]);
    root.appendChild(el('div', { class: 'rt-full' }, [stageWrap, sheet]));
  } else {
    // product_split
    const panel = el('div', { class: 'rt-panel' }, [
      header,
      el('p', { class: 'rt-sub', text: 'Kies je afwerking — het model draait mee.' }),
      el('hr', { class: 'rt-rule' }),
      groupsWrap,
      el('div', { class: 'rt-footer' }, [
        el('div', { class: 'rt-price-row' }, [
          el('div', {}, [el('div', { class: 'rt-price-label', text: 'Totaal' }), el('div', { class: 'rt-price-meta', text: 'incl. btw' })]),
          priceEl,
        ]),
        cta,
      ]),
    ]);
    root.appendChild(stageWrap); root.appendChild(panel);
  }

  mount(container, root);

  // engine --------------------------------------------------------------------
  const engine = new ConfiguratorEngine();
  engine.mount(stage, config, { mode: 'live' }).then(() => {
    if (brand) {
      engine.on('hover', () => brand.classList.add('dim'));
      engine.on('hoverend', () => brand.classList.remove('dim'));
    }
  }).catch((e) => { console.error(e); stage.appendChild(el('div', { class: 'rt-error', text: '3D-weergave kon niet laden. Je kunt nog steeds opties kiezen.' })); });

  return {
    engine,
    dispose() { try { engine.dispose(); } catch (e) {} root.remove(); },
  };
}
