// ============================================================================
// Configurator AI Studio — skeleton/provider-ready layer.
//
// Important product rule: AI output NEVER publishes directly. It creates drafts
// (materials, suggested parts, optimization advice) that the merchant must review
// in desktop + mobile preview before publishing.
// ============================================================================

import { store } from './store.js';
import { newFinish, newProject } from './schema.js';
import { el, mount, clear, uid, toast } from './util.js';
import { navigate } from './router.js';

const PROVIDER_MODE = 'mock_adapter';

function nowIso() { return new Date().toISOString(); }
function short(s, n = 46) { s = (s || '').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
function slug(s) { return (s || 'AI').toUpperCase().replace(/[^A-Z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 12) || 'AI'; }
function hashPrompt(str) { let h = 0; for (let i = 0; i < str.length; i++) h = ((h << 5) - h + str.charCodeAt(i)) | 0; return Math.abs(h); }
function hexFromSeed(seed, fallback = '#9b8468') {
  const h = hashPrompt(seed);
  const palette = ['#5a3a22', '#c69b63', '#d9c39a', '#1d1d1d', '#c6a671', '#edeae3', '#b7b1a7', '#394047', '#9a6a45'];
  return palette[h % palette.length] || fallback;
}
function classifyMaterial(prompt) {
  const p = (prompt || '').toLowerCase();
  if (/walnoot|eiken|hout|wood|oak|walnut|teak|ash|berken/.test(p)) return 'wood';
  if (/marmer|marble|steen|stone|travertin|graniet/.test(p)) return 'marble';
  if (/staal|metal|metaal|goud|gold|champagne|chrome|chroom|aluminium|koper|brass/.test(p)) return 'metal';
  return 'solid';
}
function materialDefaults(kind, prompt, quality) {
  const p = (prompt || '').toLowerCase();
  let colorHex = hexFromSeed(prompt);
  if (/zwart|black|antraciet|anthracite/.test(p)) colorHex = '#1d1d1d';
  if (/wit|white/.test(p)) colorHex = '#f2f0ec';
  if (/walnoot|walnut/.test(p)) colorHex = '#5a3a22';
  if (/eiken|oak/.test(p)) colorHex = '#c69b63';
  if (/champagne/.test(p)) colorHex = '#c6a671';
  if (/marmer|marble/.test(p)) colorHex = '#edeae3';

  const premium = quality === 'premium';
  if (kind === 'metal') return { colorHex, roughness: premium ? 0.28 : 0.45, metalness: premium ? 0.85 : 0.55, envIntensity: premium ? 1.15 : 0.9, defaultDelta: premium ? 60 : 25 };
  if (kind === 'marble') return { colorHex, roughness: premium ? 0.2 : 0.35, metalness: 0, envIntensity: premium ? 1.05 : 0.85, defaultDelta: premium ? 120 : 45 };
  if (kind === 'wood') return { colorHex, roughness: premium ? 0.48 : 0.6, metalness: 0, envIntensity: premium ? 0.65 : 0.5, defaultDelta: premium ? 80 : 30 };
  return { colorHex, roughness: 0.42, metalness: 0, envIntensity: 0.8, defaultDelta: premium ? 35 : 10 };
}
function humanizeSlot(slot) {
  const s = (slot || '').toLowerCase();
  if (/hpl|top|blad|tabletop|surface/.test(s)) return 'Tafelblad';
  if (/core|edge|rand|kern/.test(s)) return 'Rand & kern';
  if (/frame|base|onderstel|leg|poot|steel/.test(s)) return 'Onderstel';
  if (/handle|greep/.test(s)) return 'Greep';
  return (slot || 'Onderdeel').replace(/^material[_-]?/i, '').replace(/[_-]+/g, ' ').replace(/\b\w/g, (m) => m.toUpperCase());
}
function recommendedConfigurable(slot) {
  const s = (slot || '').toLowerCase();
  if (/core|screw|bolt|detail|schroef/.test(s)) return false;
  return true;
}
function addAiJob(projectId, type, input, output, status = 'completed') {
  const job = { id: uid('aij'), projectId, type, provider: PROVIDER_MODE, status, input, output, createdAt: Date.now(), updatedAt: Date.now(), audit: { createdAt: nowIso(), requiresReview: true } };
  return store.saveAiJob(job);
}


function categoryFromPrompt(prompt = '', explicit = 'auto') {
  if (explicit && explicit !== 'auto') return explicit;
  const p = prompt.toLowerCase();
  if (/stoel|chair|fauteuil|lounge|seat|sofa/.test(p)) return 'chair';
  if (/kast|cabinet|dressoir|dresser|wardrobe|closet|front/.test(p)) return 'cabinet';
  if (/lamp|light|verlichting|shade|pendant/.test(p)) return 'lamp';
  if (/tafel|table|desk|bureau|dining/.test(p)) return 'table';
  return 'product';
}
function option(finishId, delta = 0, sku = '') { return { id: uid('opt'), finishId, delta, sku }; }
function pickFinish(ids, fallback) {
  const lib = store.getLibrary();
  for (const id of ids) if (lib.find((f) => f.id === id)) return id;
  return fallback || lib[0]?.id || 'fin_hpl_white';
}
function defaultOptions(kind, role) {
  if (role === 'wood') return [option(pickFinish(['fin_oak_nat','fin_hpl_oak'], 'fin_hpl_oak'), 0, 'AI-WOOD-01'), option(pickFinish(['fin_walnut'], 'fin_hpl_oak'), 80, 'AI-WOOD-02'), option(pickFinish(['fin_hpl_black'], 'fin_hpl_black'), 45, 'AI-WOOD-03')];
  if (role === 'metal') return [option(pickFinish(['fin_steel_black'], 'fin_hpl_black'), 0, 'AI-MET-01'), option(pickFinish(['fin_steel_white'], 'fin_hpl_white'), 20, 'AI-MET-02'), option(pickFinish(['fin_steel_champ'], 'fin_hpl_oak'), 60, 'AI-MET-03')];
  if (role === 'fabric') return [option(pickFinish(['fin_birch_white','fin_hpl_white'], 'fin_hpl_white'), 0, 'AI-FAB-01'), option(pickFinish(['fin_hpl_grey'], 'fin_hpl_grey'), 35, 'AI-FAB-02'), option(pickFinish(['fin_hpl_anthra'], 'fin_hpl_anthra'), 55, 'AI-FAB-03')];
  if (role === 'stone') return [option(pickFinish(['fin_hpl_marble'], 'fin_hpl_marble'), 0, 'AI-STN-01'), option(pickFinish(['fin_hpl_white'], 'fin_hpl_white'), 20, 'AI-STN-02')];
  return [option(pickFinish(['fin_hpl_white'], 'fin_hpl_white'), 0, 'AI-SOL-01'), option(pickFinish(['fin_hpl_anthra'], 'fin_hpl_anthra'), 30, 'AI-SOL-02')];
}
function surface(slot, name, role, configurable = true) {
  const options = defaultOptions(null, role);
  return { id: uid('srf'), slot, name, configurable, options, defaultOptionId: options[0]?.id || '' };
}
function surfacesForCategory(category) {
  const c = category || 'product';
  if (c === 'table') return [surface('ai_tabletop', 'Tafelblad', 'wood', true), surface('ai_frame', 'Onderstel', 'metal', true), surface('ai_base', 'Voetplaat', 'metal', false)];
  if (c === 'chair') return [surface('ai_seat', 'Zitting', 'wood', true), surface('ai_back', 'Rugleuning', 'wood', true), surface('ai_cushion', 'Kussen/stof', 'fabric', true), surface('ai_frame', 'Frame', 'metal', true)];
  if (c === 'cabinet') return [surface('ai_body', 'Korpus', 'wood', true), surface('ai_fronts', 'Fronten', 'wood', true), surface('ai_handles', 'Grepen', 'metal', true), surface('ai_legs', 'Poten', 'metal', false)];
  if (c === 'lamp') return [surface('ai_shade', 'Lampenkap', 'fabric', true), surface('ai_base', 'Voet & staander', 'metal', true)];
  return [surface('ai_body', 'Hoofdvorm', 'solid', true), surface('ai_detail', 'Detail', 'metal', true), surface('ai_accent', 'Accent', 'metal', true)];
}
function basePriceForCategory(category) {
  return { table: 799, chair: 429, cabinet: 1199, lamp: 249, product: 399 }[category] || 399;
}
function prettyCategory(category) {
  return { table: 'Tafel', chair: 'Stoel', cabinet: 'Kast/meubel', lamp: 'Lamp', product: 'Product' }[category] || 'Product';
}
function guessCategoryFromFiles(files = [], fallback = 'auto') {
  if (fallback && fallback !== 'auto') return fallback;
  const names = files.map((f) => (f.name || '')).join(' ').toLowerCase();
  if (/stoel|chair|fauteuil|lounge|sofa/.test(names)) return 'chair';
  if (/kast|cabinet|front|dressoir|wardrobe/.test(names)) return 'cabinet';
  if (/lamp|light|verlichting|pendant/.test(names)) return 'lamp';
  if (/tafel|table|desk|bureau/.test(names)) return 'table';
  return 'product';
}
function safeFileSummary(files = []) {
  return files.slice(0, 6).map((f) => ({ name: f.name, size: f.size, type: f.type }));
}
function imagePreviewUrls(files = []) {
  return files.slice(0, 4).map((f) => URL.createObjectURL(f));
}

export async function createAiPromptProject(prompt, category = 'auto') {
  const clean = (prompt || '').trim();
  if (!clean) throw new Error('Prompt ontbreekt');
  const cat = categoryFromPrompt(clean, category);
  const p = newProject({
    name: `AI · ${prettyCategory(cat)} · ${short(clean, 28)}`,
    status: 'draft',
    basePrice: basePriceForCategory(cat),
    model: { source: 'ai_prompt', prompt: clean, category: cat, provider: PROVIDER_MODE, generatedAt: nowIso(), reviewed: false },
    surfaces: surfacesForCategory(cat),
    scene: { environment: 'studio', exposure: 1.05, environmentIntensity: 1.05, background: 'studio', autoRotate: true },
  });
  await store.createProject(p);
  await addAiJob(p.id, 'text_to_3d_model', { prompt: clean, category: cat }, { projectId: p.id, category: cat, source: 'ai_prompt_mock', requiresReview: true });
  return p;
}

export async function createAiImageProject(files, prompt = '', category = 'auto') {
  const list = Array.from(files || []).filter((f) => f && /^image\//.test(f.type || ''));
  if (!list.length) throw new Error('Upload minimaal één productfoto');
  if (list.length > 4) throw new Error('Gebruik maximaal 4 foto’s voor deze MVP-flow');
  const clean = (prompt || '').trim();
  const cat = categoryFromPrompt(clean, category);
  const guessed = cat === 'product' ? guessCategoryFromFiles(list, category) : cat;
  const p = newProject({
    name: `Foto AI · ${prettyCategory(guessed)} · ${clean ? short(clean, 26) : short(list[0].name.replace(/\.[^.]+$/, ''), 26)}`,
    status: 'draft',
    basePrice: basePriceForCategory(guessed),
    model: {
      source: 'ai_images',
      prompt: clean,
      category: guessed,
      provider: PROVIDER_MODE,
      generatedAt: nowIso(),
      reviewed: false,
      inputImages: safeFileSummary(list),
      previewUrls: imagePreviewUrls(list),
      note: 'v0.4 mock: foto’s worden lokaal als input geregistreerd; productie gebruikt image-to-3D / multi-image-to-3D provider.'
    },
    surfaces: surfacesForCategory(guessed),
    scene: { environment: 'studio', exposure: 1.04, environmentIntensity: 1.08, background: 'studio', autoRotate: true },
  });
  await store.createProject(p);
  await addAiJob(p.id, 'image_to_3d_model', { prompt: clean, category: guessed, images: safeFileSummary(list) }, { projectId: p.id, category: guessed, source: 'ai_images_mock', requiresReview: true });
  return p;
}

export function renderAiStudio(container) {
  const projects = store.listProjects();
  const selected = projects[0]?.id || null;
  const body = el('div', { class: 'ai-page' }, [
    el('header', { class: 'sub-header' }, [
      el('div', { class: 'brandmark' }, [el('button', { class: 'tb-back', onclick: () => navigate('#/'), text: '‹' }), el('span', { class: 'diamond' }), el('span', { class: 'brandtext', text: 'Configurator AI Studio' })]),
      el('div', { class: 'hint', text: 'Asset Assistant · provider-ready skeleton' }),
    ]),
    el('div', { class: 'ai-shell' }, [
      el('aside', { class: 'ai-projects' }, [
        el('div', { class: 'flabel', text: 'Projecten' }),
        ...projects.map((p) => el('button', { class: 'ai-project', onclick: () => navigate(`#/p/${p.id}/ai`) }, [
          el('b', { text: p.name }),
          el('span', { text: `${p.surfaces.length} vlakken · ${p.status}` }),
        ])),
      ]),
      el('main', { class: 'ai-main' }, [
        selected ? projectAiPanel(selected) : el('div', { class: 'empty', text: 'Maak eerst een project aan.' }),
      ]),
    ]),
  ]);
  mount(container, body);
}

export function renderProjectAiStudio(container, projectId, opts = {}) {
  const panel = projectAiPanel(projectId, opts);
  if (opts.embedded) mount(container, panel); else mount(container, el('div', { class: 'ai-page' }, [panel]));
}

function projectAiPanel(projectId) {
  const p = store.getProject(projectId);
  if (!p) return el('div', { class: 'empty', text: 'Project niet gevonden.' });

  const jobsBox = el('div', { class: 'ai-jobs' });
  const materialPrompt = el('textarea', { class: 'inp ai-textarea', placeholder: 'Bijv. donker walnoot hout, subtiele nerf, mat gelakt, premium meubelafwerking' });
  const quality = el('select', { class: 'inp' }, [
    el('option', { value: 'fast', text: 'Snel concept' }),
    el('option', { value: 'premium', text: 'Premium realistisch' }),
  ]);
  const conceptPrompt = el('textarea', { class: 'inp ai-textarea', placeholder: 'Bijv. moderne ronde eettafel met zwart metalen kruisonderstel' });
  const modelPrompt = el('textarea', { class: 'inp ai-textarea ai-model-prompt', placeholder: 'Bijv. premium lounge stoel met houten kuip, zachte beige zitting en mat zwart metalen frame' });
  const modelCategory = el('select', { class: 'inp' }, [
    el('option', { value: 'auto', text: 'Automatisch herkennen' }),
    el('option', { value: 'table', text: 'Tafel' }),
    el('option', { value: 'chair', text: 'Stoel/fauteuil' }),
    el('option', { value: 'cabinet', text: 'Kast/meubel' }),
    el('option', { value: 'lamp', text: 'Lamp' }),
    el('option', { value: 'product', text: 'Algemeen product' }),
  ]);
  const imagePrompt = el('textarea', { class: 'inp ai-textarea', placeholder: 'Optioneel: beschrijf wat de foto’s tonen, bijv. organische lounge stoel met houten rug en beige stof' });
  const imageCategory = el('select', { class: 'inp' }, [
    el('option', { value: 'auto', text: 'Automatisch herkennen' }),
    el('option', { value: 'table', text: 'Tafel' }),
    el('option', { value: 'chair', text: 'Stoel/fauteuil' }),
    el('option', { value: 'cabinet', text: 'Kast/meubel' }),
    el('option', { value: 'lamp', text: 'Lamp' }),
    el('option', { value: 'product', text: 'Algemeen product' }),
  ]);
  const imageInput = el('input', { class: 'inp ai-file', type: 'file', accept: 'image/*', multiple: true });
  const imageHint = el('p', { class: 'hint', text: 'Upload 1–4 productfoto’s. Beste input: voorkant + zijkant + 45° hoek + detailfoto.' });

  function refreshJobs() {
    clear(jobsBox);
    const jobs = store.listAiJobs(p.id).slice(0, 6);
    if (!jobs.length) { jobsBox.appendChild(el('div', { class: 'hint', text: 'Nog geen AI-acties voor dit project.' })); return; }
    jobs.forEach((j) => jobsBox.appendChild(el('div', { class: 'ai-job' }, [
      el('span', { class: 'ai-job-type', text: j.type.replace(/_/g, ' ') }),
      el('span', { class: 'ai-job-status', text: j.status }),
      el('small', { text: new Date(j.createdAt).toLocaleString('nl-NL') }),
    ])));
  }

  async function generateModelFromPrompt() {
    const prompt = modelPrompt.value.trim();
    if (!prompt) { toast('Vul eerst een 3D-modelprompt in'); return; }
    const created = await createAiPromptProject(prompt, modelCategory.value);
    toast('AI-modelconcept gemaakt — eerst reviewen vóór publicatie');
    navigate(`#/p/${created.id}/preview`);
  }

  async function generateModelFromImages() {
    const files = Array.from(imageInput.files || []);
    if (!files.length) { toast('Upload eerst één of meer productfoto’s'); return; }
    try {
      const created = await createAiImageProject(files, imagePrompt.value, imageCategory.value);
      toast('Foto-naar-3D concept gemaakt — eerst reviewen vóór publicatie');
      navigate(`#/p/${created.id}/preview`);
    } catch (e) {
      toast(e.message || 'Foto’s konden niet worden verwerkt');
    }
  }

  async function markReviewed() {
    p.model = { ...(p.model || {}), reviewed: true, reviewedAt: nowIso() };
    await store.saveProject(p);
    await addAiJob(p.id, 'asset_review', { source: p.model?.source }, { reviewed: true });
    toast('AI/upload asset gemarkeerd als gereviewd');
    refreshJobs();
  }

  async function generateMaterial() {
    const prompt = materialPrompt.value.trim();
    if (!prompt) { toast('Vul eerst een materiaalprompt in'); return; }
    const kind = classifyMaterial(prompt);
    const defaults = materialDefaults(kind, prompt, quality.value);
    const f = newFinish({
      name: 'AI · ' + short(prompt, 34),
      kind,
      grainHex: defaults.colorHex,
      sku: 'AI-' + slug(prompt),
      ...defaults,
      metadata: { ai: true, prompt, quality: quality.value, provider: PROVIDER_MODE, representative: true },
    });
    await store.saveFinish(f);
    await addAiJob(p.id, 'material_generation', { prompt, quality: quality.value }, { finishId: f.id, name: f.name, kind });
    materialPrompt.value = '';
    toast('AI-materiaal opgeslagen in afwerkingenbibliotheek');
    refreshJobs();
  }

  async function detectParts() {
    let changed = 0;
    if (!p.surfaces.length && p.model?.source === 'demo') {
      p.surfaces.push(
        { id: uid('srf'), slot: 'material_hpl', name: 'Tafelblad', configurable: true, options: [], defaultOptionId: '' },
        { id: uid('srf'), slot: 'material_core', name: 'Rand & kern', configurable: false, options: [], defaultOptionId: '' },
        { id: uid('srf'), slot: 'material_frame', name: 'Onderstel', configurable: true, options: [], defaultOptionId: '' },
      );
      changed += 3;
    } else {
      p.surfaces.forEach((s) => {
        const nextName = humanizeSlot(s.slot);
        const nextCfg = recommendedConfigurable(s.slot);
        if (s.name !== nextName) { s.name = nextName; changed++; }
        if (s.configurable !== nextCfg) { s.configurable = nextCfg; changed++; }
      });
    }
    await store.saveProject(p);
    await addAiJob(p.id, 'part_detection', { source: p.model?.source || 'unknown' }, { changed, surfaces: p.surfaces.map((s) => ({ slot: s.slot, name: s.name, configurable: s.configurable })) });
    toast(changed ? `AI-voorstel toegepast: ${changed} wijziging(en)` : 'Onderdelen waren al logisch benoemd');
    refreshJobs();
  }

  async function optimizeForWeb() {
    const textureCount = store.getLibrary().filter((f) => f.textureUrl).length;
    const warnings = [];
    let mobileScore = p.model?.source === 'demo' ? 92 : 74;
    if (textureCount > 6) { mobileScore -= 8; warnings.push('Veel textures: maak mobile varianten of comprimeer naar KTX2/WebP.'); }
    if ((p.surfaces || []).length > 8) { mobileScore -= 6; warnings.push('Veel configureerbare vlakken: groepeer onderdelen waar mogelijk.'); }
    if (p.model?.source === 'glb' && String(p.model.url || '').startsWith('blob:')) warnings.push('GLB gebruikt een tijdelijke blob-URL; upload naar CDN/storage vóór echte publicatie.');
    p.performance = { desktopScore: Math.min(96, mobileScore + 12), mobileScore: Math.max(35, mobileScore), warnings, checkedAt: nowIso(), mode: PROVIDER_MODE };
    await store.saveProject(p);
    await addAiJob(p.id, 'optimize_for_web', { model: p.model }, p.performance);
    toast(`Mobile score: ${p.performance.mobileScore}/100`);
    refreshJobs();
  }

  async function createConceptProject() {
    const prompt = conceptPrompt.value.trim();
    if (!prompt) { toast('Vul eerst een conceptprompt in'); return; }
    const copy = JSON.parse(JSON.stringify(p));
    copy.id = uid('prj');
    copy.name = 'Concept · ' + short(prompt, 28);
    copy.status = 'draft';
    copy.model = { source: 'demo', conceptPrompt: prompt, aiConcept: true };
    copy.shopify = {};
    copy.updatedAt = Date.now();
    await store.createProject(copy);
    await addAiJob(copy.id, 'concept_model', { prompt }, { projectId: copy.id, warning: 'Mock concept; echte provider later via adapter.' });
    toast('Conceptproject gemaakt — controle vóór publicatie verplicht');
    navigate(`#/p/${copy.id}/product`);
  }

  const perf = p.performance;
  const panel = el('div', { class: 'ai-panel' }, [
    el('div', { class: 'step-head' }, [
      el('h2', { class: 'step-title', text: 'Configurator AI Studio' }),
      el('p', { class: 'step-sub', text: 'AI versnelt asset-preparatie, maar publiceert nooit direct. Alles moet door desktop/mobile preview en publish-check.' }),
    ]),
    el('div', { class: 'ai-kpis' }, [
      aiKpi('Project', p.name),
      aiKpi('Providerlaag', PROVIDER_MODE),
      aiKpi('Desktop', perf ? `${perf.desktopScore}/100` : 'nog niet gecheckt'),
      aiKpi('Mobiel', perf ? `${perf.mobileScore}/100` : 'nog niet gecheckt'),
    ]),
    el('div', { class: 'ai-grid' }, [
      aiCard('3D-model genereren uit prompt', 'Nieuwe hoofdroute: klant beschrijft het product. De tool maakt een conceptmodel met configureerbare slots. Klant kan nog steeds eigen GLB uploaden.', [
        modelPrompt,
        el('div', { class: 'field-row' }, [modelCategory, el('button', { class: 'btn dark', onclick: generateModelFromPrompt, text: 'Genereer modelconcept' })]),
        el('p', { class: 'hint', text: 'v0.4 gebruikt een lokale mock/procedural provider. Productie: Meshy/Tripo/Rodin adapter + normalizer + checker.' }),
      ]),
      aiCard('3D-model maken uit productfoto’s', 'Klant uploadt 1–4 productfoto’s. Productie gebruikt image-to-3D of multi-image-to-3D. v0.4 registreert dit als echte hoofdflow met mock-output.', [
        imageInput,
        imagePrompt,
        el('div', { class: 'field-row' }, [imageCategory, el('button', { class: 'btn dark', onclick: generateModelFromImages, text: 'Genereer uit foto’s' })]),
        imageHint,
      ]),
      aiCard('Asset review', 'AI-output of upload mag pas live als de merchant het resultaat in desktop én mobiel heeft gecontroleerd.', [
        el('button', { class: 'btn full', onclick: markReviewed, text: p.model?.reviewed ? 'Opnieuw review markeren' : 'Markeer asset als gereviewd' }),
        el('p', { class: 'hint', text: ['ai_prompt','ai_images'].includes(p.model?.source) ? 'Dit project is AI-gegenereerd en vereist review vóór publicatie.' : 'Upload/demomodel kan ook gereviewd worden.' }),
      ]),
      aiCard('Onderdelen herkennen', 'Laat AI technische slots omzetten naar begrijpelijke onderdelen zoals tafelblad, onderstel of rand.', [
        el('button', { class: 'btn dark full', onclick: detectParts, text: 'Onderdelen voorstellen' }),
      ]),
      aiCard('Materiaal maken', 'Genereer een afwerking als bibliotheek-item. Daarna kies jij zelf op welk vlak je hem gebruikt.', [
        materialPrompt,
        el('div', { class: 'field-row' }, [quality, el('button', { class: 'btn dark', onclick: generateMaterial, text: 'Genereer materiaal' })]),
      ]),
      aiCard('Optimaliseren voor mobiel', 'Mock-check voor modelgewicht, textures en publicatie-risico’s. Echte Draco/KTX2/CDN-pipeline komt later.', [
        el('button', { class: 'btn dark full', onclick: optimizeForWeb, text: 'Draai mobile check' }),
        perf?.warnings?.length ? el('ul', { class: 'ai-warnings' }, perf.warnings.map((w) => el('li', { text: w }))) : el('p', { class: 'hint', text: 'Nog geen waarschuwingen.' }),
      ]),
      aiCard('Conceptmodel maken', 'Legacy concept-kopie. De hoofdroute is nu hierboven: prompt → AI-modelconcept → review → preview → publiceren.', [
        conceptPrompt,
        el('button', { class: 'btn dark full', onclick: createConceptProject, text: 'Maak conceptproject' }),
      ]),
    ]),
    el('div', { class: 'ai-contract' }, [
      el('b', { text: 'AI-contract voor productie' }),
      el('code', { text: 'AI output → normalizer → configurator-ready checker → desktop preview → mobile preview → publish-check → live' }),
    ]),
    el('div', { class: 'step-head small' }, [el('h3', { text: 'AI jobs / audit trail' })]),
    jobsBox,
  ]);
  setTimeout(refreshJobs, 0);
  return panel;
}

function aiKpi(label, value) { return el('div', { class: 'ai-kpi' }, [el('span', { text: label }), el('b', { text: value })]); }
function aiCard(title, sub, children) { return el('section', { class: 'ai-card' }, [el('h3', { text: title }), el('p', { text: sub }), ...children]); }
