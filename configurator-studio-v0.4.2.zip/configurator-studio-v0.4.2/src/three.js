// Single source of truth for the 3D library version.
// Swapping three's version (or CDN) happens only here.
import * as THREE from 'three';
export { THREE };
export { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
