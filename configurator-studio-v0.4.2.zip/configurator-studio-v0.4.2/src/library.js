// Finish library — account-level, reusable finishes across all projects.
import { store } from './store.js';
import { el, mount, clear, euro, toast } from './util.js';
import { THREE } from './three.js';
import { newFinish } from './schema.js';
import { navigate } from './router.js';

function shade(hex, amt) { const c = new THREE.Color(hex), f = amt / 100; c.r = Math.max(0, Math.min(1, c.r + f)); c.g = Math.max(0, Math.min(1, c.g + f)); c.b = Math.max(0, Math.min(1, c.b + f)); return '#' + c.getHexString(); }
function swatch(fin) {
  if (fin.textureUrl) return `background-image:url(${fin.textureUrl});background-size:cover;background-position:center;`;
  const hex = fin.colorHex;
  if (fin.kind === 'metal') return `background:linear-gradient(135deg,${shade(hex, 24)},${hex} 45%,${shade(hex, -20)});`;
  if (fin.kind === 'marble') return `background:radial-gradient(120% 120% at 30% 20%,#f4f1ea,${hex} 70%);`;
  if (fin.kind === 'wood') return `background:linear-gradient(150deg,${shade(hex, 16)},${hex} 45%,${shade(hex, -14)});`;
  return `background:${hex};`;
}

export function renderLibrary(container) {
  let selectedId = store.getLibrary()[0]?.id || null;

  const listWrap = el('div', { class: 'lib-list' });
  const editorWrap = el('aside', { class: 'lib-editor' });

  function renderList() {
    const lib = store.getLibrary();
    clear(listWrap);
    const grid = el('div', { class: 'lib-grid' }, lib.map((f) =>
      el('button', { class: 'lib-card' + (selectedId === f.id ? ' sel' : ''), onclick: () => { selectedId = f.id; renderAll(); } }, [
        el('span', { class: 'lib-sw', style: swatch(f) }),
        el('span', { class: 'lib-card-info' }, [el('b', { text: f.name }), el('span', { class: 'mono', text: `${f.sku || '—'} · ${f.kind}` })]),
        el('span', { class: 'lib-card-delta mono', text: f.defaultDelta ? '+' + euro(f.defaultDelta) : '—' }),
      ])));
    listWrap.appendChild(grid);
    listWrap.appendChild(el('button', { class: 'btn full', onclick: async () => { const f = newFinish({ name: 'Nieuwe afwerking' }); await store.saveFinish(f); selectedId = f.id; renderAll(); }, text: '+ Nieuwe afwerking' }));
  }

  function renderEditor() {
    clear(editorWrap);
    const f = store.getLibrary().find((x) => x.id === selectedId);
    if (!f) { editorWrap.appendChild(el('div', { class: 'detail-hint', text: 'Kies een afwerking of maak een nieuwe.' })); return; }
    const save = () => { store.saveFinish(f); renderList(); refreshPreview(); };
    const debSave = (() => { let t; return () => { clearTimeout(t); t = setTimeout(save, 300); }; })();

    const preview = el('div', { class: 'lib-preview', style: swatch(f) });
    function refreshPreview() { preview.setAttribute('style', swatch(f)); }

    const fields = el('div', { class: 'form' }, [
      lf('Naam', tin(f.name, (v) => { f.name = v; debSave(); })),
      row([
        lf('Type', sel(['solid', 'wood', 'marble', 'metal'], f.kind, (v) => { f.kind = v; save(); refreshPreview(); })),
        lf('SKU', tin(f.sku || '', (v) => { f.sku = v.trim(); debSave(); })),
      ]),
      lf('Kleur', tin(f.colorHex, (v) => { f.colorHex = v; debSave(); refreshPreview(); }, 'color')),
      slider('Ruwheid', f.roughness, (v) => { f.roughness = v; debSave(); }),
      slider('Metaal', f.metalness, (v) => { f.metalness = v; debSave(); }),
      slider('Reflectie (env)', f.envIntensity, (v) => { f.envIntensity = v; debSave(); }, 0, 2),
      lf('Standaard-meerprijs', tin(String(f.defaultDelta), (v) => { f.defaultDelta = parseFloat(v) || 0; debSave(); }, 'number')),
      lf('Textuur (optioneel)', textureField(f, () => { save(); refreshPreview(); })),
      el('button', { class: 'btn ghost del', onclick: async () => { if (confirm('Afwerking verwijderen? Projecten die deze gebruiken tonen een lege optie.')) { await store.deleteFinish(f.id); selectedId = store.getLibrary()[0]?.id || null; renderAll(); toast('Verwijderd'); } }, text: 'Verwijderen' }),
    ]);
    editorWrap.appendChild(el('div', {}, [
      el('div', { class: 'insp-eyebrow', text: 'Afwerking' }),
      el('div', { class: 'lib-preview-row' }, [preview, el('div', { class: 'lib-preview-meta' }, [el('b', { text: f.name }), el('span', { class: 'mono', text: f.sku || '' })])]),
      fields,
    ]));
  }

  function renderAll() { renderList(); renderEditor(); }

  const root = el('div', { class: 'library' }, [
    el('header', { class: 'sub-header' }, [
      el('div', { class: 'brandmark' }, [el('button', { class: 'tb-back', onclick: () => navigate('#/'), text: '‹' }), el('span', { class: 'diamond' }), el('span', { class: 'brandtext', text: 'Afwerkingenbibliotheek' })]),
      el('div', { class: 'hint', text: 'Herbruikbaar over al je producten' }),
    ]),
    el('div', { class: 'library-body' }, [listWrap, editorWrap]),
  ]);
  mount(container, root);
  renderAll();
}

// atoms
function lf(label, control) { return el('label', { class: 'field' }, [el('span', { class: 'field-label', text: label }), control]); }
function row(children) { return el('div', { class: 'field-row' }, children); }
function tin(value, onInput, type = 'text') { return el('input', { class: 'inp', type, value, oninput: (e) => onInput(e.target.value) }); }
function sel(opts, value, onChange) { return el('select', { class: 'inp', onchange: (e) => onChange(e.target.value) }, opts.map((o) => el('option', { value: o, text: o, selected: o === value }))); }
function slider(label, value, onInput, min = 0, max = 1) {
  const out = el('span', { class: 'slider-val mono', text: Number(value).toFixed(2) });
  const input = el('input', { type: 'range', class: 'slider', min: String(min), max: String(max), step: '0.01', value: String(value), oninput: (e) => { const v = parseFloat(e.target.value); out.textContent = v.toFixed(2); onInput(v); } });
  return el('label', { class: 'field' }, [el('span', { class: 'field-label slider-label' }, [document.createTextNode(label), out]), input]);
}
function textureField(f, onChange) {
  const wrap = el('div', { class: 'tex-field' });
  const btn = el('label', { class: 'btn ghost', text: f.textureUrl ? 'Vervang afbeelding' : 'Upload afbeelding' }, [
    el('input', { type: 'file', accept: 'image/*', style: 'display:none', onchange: (e) => { const file = e.target.files[0]; if (file) { f.textureUrl = URL.createObjectURL(file); onChange(); render(); } } }),
  ]);
  const clearBtn = f.textureUrl ? el('button', { class: 'btn ghost', onclick: () => { f.textureUrl = undefined; onChange(); render(); }, text: 'Verwijder' }) : null;
  function render() { clear(wrap); wrap.appendChild(btn); if (f.textureUrl) wrap.appendChild(clearBtn || el('span')); }
  render();
  return wrap;
}
