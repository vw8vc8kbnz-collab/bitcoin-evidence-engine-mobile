// Seed data so the app is useful the first time it opens.
import { newFinish, newProject } from './schema.js';
import { uid } from './util.js';

export function seedLibrary() {
  return [
    newFinish({ id: 'fin_hpl_white',  name: 'HPL Wit',           kind: 'solid',  colorHex: '#f2f0ec', roughness: 0.34, metalness: 0, envIntensity: 0.8, sku: 'HPL-100', defaultDelta: 0 }),
    newFinish({ id: 'fin_hpl_grey',   name: 'HPL Lichtgrijs',    kind: 'solid',  colorHex: '#cfccc6', roughness: 0.34, metalness: 0, envIntensity: 0.8, sku: 'HPL-120', defaultDelta: 0 }),
    newFinish({ id: 'fin_hpl_anthra', name: 'HPL Antraciet',     kind: 'solid',  colorHex: '#33322f', roughness: 0.32, metalness: 0, envIntensity: 0.85, sku: 'HPL-220', defaultDelta: 15 }),
    newFinish({ id: 'fin_hpl_black',  name: 'HPL Zwart',         kind: 'solid',  colorHex: '#1a1917', roughness: 0.30, metalness: 0, envIntensity: 0.9, sku: 'HPL-240', defaultDelta: 15 }),
    newFinish({ id: 'fin_hpl_oak',    name: 'HPL Eiken-decor',   kind: 'wood',   colorHex: '#b98f57', roughness: 0.40, metalness: 0, envIntensity: 0.6, grainHex: '#7a5a30', sku: 'HPL-310', defaultDelta: 25 }),
    newFinish({ id: 'fin_hpl_marble', name: 'HPL Marmer-decor',  kind: 'marble', colorHex: '#edeae3', roughness: 0.22, metalness: 0, envIntensity: 1.1, grainHex: '#9a958c', sku: 'HPL-330', defaultDelta: 35 }),
    newFinish({ id: 'fin_birch_nat',  name: 'Berken naturel',    kind: 'wood',   colorHex: '#d9c39a', roughness: 0.60, metalness: 0, envIntensity: 0.5, grainHex: '#b59b6a', sku: 'BRK-001', defaultDelta: 0 }),
    newFinish({ id: 'fin_birch_white',name: 'Berken wit geolied',kind: 'wood',   colorHex: '#e8e0d0', roughness: 0.62, metalness: 0, envIntensity: 0.45, grainHex: '#cdbfa0', sku: 'BRK-010', defaultDelta: 10 }),
    newFinish({ id: 'fin_oak_nat',    name: 'Naturel eiken',     kind: 'wood',   colorHex: '#c69b63', roughness: 0.62, metalness: 0, envIntensity: 0.5, grainHex: '#8a6234', sku: 'OAK-001', defaultDelta: 0 }),
    newFinish({ id: 'fin_walnut',     name: 'Donker walnoot',    kind: 'wood',   colorHex: '#5a3a22', roughness: 0.55, metalness: 0, envIntensity: 0.55, grainHex: '#2f1c0f', sku: 'WAL-001', defaultDelta: 80 }),
    newFinish({ id: 'fin_steel_black',name: 'Staal mat zwart',   kind: 'metal',  colorHex: '#1d1d1d', roughness: 0.5, metalness: 0.55, envIntensity: 0.9, sku: 'ST-BLK', defaultDelta: 0 }),
    newFinish({ id: 'fin_steel_white',name: 'Staal wit',         kind: 'metal',  colorHex: '#eceae5', roughness: 0.38, metalness: 0.15, envIntensity: 0.85, sku: 'ST-WHT', defaultDelta: 20 }),
    newFinish({ id: 'fin_steel_champ',name: 'Staal champagne',   kind: 'metal',  colorHex: '#c6a671', roughness: 0.3, metalness: 0.9, envIntensity: 1.1, sku: 'ST-CHM', defaultDelta: 60 }),
  ];
}

function opt(finishId, delta, sku) { return { id: uid('opt'), finishId, delta, sku }; }

export function seedProjects(/* library */) {
  // Project 1 — birch/HPL table (the surface-model showcase)
  const hplTop = { id: 'srf_top', slot: 'material_hpl', name: 'Bovenblad (HPL)', configurable: true,
    options: [opt('fin_hpl_white', 0, 'HPL-100'), opt('fin_hpl_anthra', 15, 'HPL-220'), opt('fin_hpl_oak', 25, 'HPL-310')], defaultOptionId: '' };
  hplTop.defaultOptionId = hplTop.options[0].id;
  const birchEdge = { id: 'srf_edge', slot: 'material_core', name: 'Rand & kern (berken)', configurable: false,
    options: [opt('fin_birch_nat', 0, 'BRK-001'), opt('fin_birch_white', 10, 'BRK-010')], defaultOptionId: '' };
  birchEdge.defaultOptionId = birchEdge.options[0].id;
  const steelBase = { id: 'srf_base', slot: 'material_frame', name: 'Onderstel (staal)', configurable: true,
    options: [opt('fin_steel_black', 0, 'ST-BLK'), opt('fin_steel_white', 20, 'ST-WHT'), opt('fin_steel_champ', 60, 'ST-CHM')], defaultOptionId: '' };
  steelBase.defaultOptionId = steelBase.options[0].id;

  const p1 = newProject({
    id: 'prj_oslo_hpl', name: 'Eettafel Oslo — HPL', status: 'draft', basePrice: 640,
    model: { source: 'demo' }, surfaces: [hplTop, birchEdge, steelBase],
  });

  // Project 2 — solid oak variant (shows multi-project + different finishes)
  const top2 = { id: 'srf_top2', slot: 'material_hpl', name: 'Tafelblad', configurable: true,
    options: [opt('fin_oak_nat', 0, 'OAK-001'), opt('fin_walnut', 80, 'WAL-001'), opt('fin_hpl_marble', 140, 'HPL-330')], defaultOptionId: '' };
  top2.defaultOptionId = top2.options[0].id;
  const edge2 = { id: 'srf_edge2', slot: 'material_core', name: 'Kern', configurable: false,
    options: [opt('fin_oak_nat', 0, 'OAK-001')], defaultOptionId: '' };
  edge2.defaultOptionId = edge2.options[0].id;
  const base2 = { id: 'srf_base2', slot: 'material_frame', name: 'Onderstel', configurable: true,
    options: [opt('fin_steel_black', 0, 'ST-BLK'), opt('fin_steel_champ', 60, 'ST-CHM')], defaultOptionId: '' };
  base2.defaultOptionId = base2.options[0].id;

  const p2 = newProject({
    id: 'prj_oslo_oak', name: 'Eettafel Oslo — Massief', status: 'live', basePrice: 799,
    model: { source: 'demo' }, surfaces: [top2, edge2, base2],
  });

  return [p1, p2];
}
