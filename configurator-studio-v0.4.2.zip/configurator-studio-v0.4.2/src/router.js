// Minimal hash router. Framework-free; maps to Next.js routes later 1:1.

let handler = () => {};

export function navigate(hash) {
  if (location.hash === hash) onRoute(); else location.hash = hash;
}

export function parseRoute() {
  const h = location.hash.replace(/^#\/?/, '');
  const parts = h.split('/').filter(Boolean);
  if (!parts.length) return { name: 'dashboard' };
  if (parts[0] === 'p' && parts[1]) return { name: 'builder', id: parts[1], step: parts[2] || 'product' };
  if (parts[0] === 'preview' && parts[1]) return { name: 'preview', id: parts[1] };
  if (parts[0] === 'embed' && parts[1]) return { name: 'embed', id: parts[1] };
  if (parts[0] === 'library') return { name: 'library' };
  if (parts[0] === 'ai') return { name: 'ai' };
  if (parts[0] === 'configs' && parts[1]) return { name: 'config', id: parts[1] };
  if (parts[0] === 'configs') return { name: 'configs' };
  return { name: 'dashboard' };
}

export function onRoute() { handler(parseRoute()); }

export function startRouter(fn) {
  handler = fn;
  window.addEventListener('hashchange', onRoute);
  onRoute();
}
