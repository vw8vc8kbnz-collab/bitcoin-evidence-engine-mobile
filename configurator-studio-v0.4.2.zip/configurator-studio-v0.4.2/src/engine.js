// ============================================================================
// ConfiguratorEngine — THE single engine.
//
// Used identically by the builder preview and the live/embed runtime.
// It renders from a RuntimeConfig (never from a Project). It knows nothing
// about the DOM UI around it; it communicates via events + a small API.
// ============================================================================

import { THREE, GLTFLoader } from './three.js';
import { Emitter, clamp, prefersReducedMotion } from './util.js';

const REDUCED = prefersReducedMotion();
const easeOut = (t) => 1 - Math.pow(1 - t, 3);

// ---- procedural textures (fallback when a finish has no textureUrl) --------
const _texCache = new Map();
function grainTexture(grainHex) {
  const key = 'g' + grainHex; if (_texCache.has(key)) return _texCache.get(key);
  const c = document.createElement('canvas'); c.width = c.height = 512; const g = c.getContext('2d');
  g.fillStyle = '#cfccc7'; g.fillRect(0, 0, 512, 512);
  const gr = new THREE.Color(grainHex);
  for (let i = 0; i < 200; i++) {
    g.strokeStyle = `rgba(${gr.r * 255 | 0},${gr.g * 255 | 0},${gr.b * 255 | 0},${0.03 + Math.random() * 0.12})`;
    g.lineWidth = 0.5 + Math.random() * 2; g.beginPath();
    let x = Math.random() * 512; g.moveTo(x, 0);
    for (let y = 0; y <= 512; y += 16) { x += Math.sin(y * 0.03 + i) * 1.2; g.lineTo(x, y); } g.stroke();
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(2, 1);
  t.encoding = THREE.sRGBEncoding; t.anisotropy = 8; _texCache.set(key, t); return t;
}
function marbleTexture(veinHex) {
  const key = 'm' + veinHex; if (_texCache.has(key)) return _texCache.get(key);
  const c = document.createElement('canvas'); c.width = c.height = 512; const g = c.getContext('2d');
  g.fillStyle = '#e6e2da'; g.fillRect(0, 0, 512, 512); const v = new THREE.Color(veinHex);
  for (let i = 0; i < 12; i++) {
    g.strokeStyle = `rgba(${v.r * 255 | 0},${v.g * 255 | 0},${v.b * 255 | 0},${0.1 + Math.random() * 0.12})`;
    g.lineWidth = 0.6 + Math.random() * 2.2; g.beginPath();
    let x = Math.random() * 512, y = -10; g.moveTo(x, y);
    while (y < 522) { x += (Math.random() - 0.5) * 44; y += 18 + Math.random() * 24; g.quadraticCurveTo(x + (Math.random() - 0.5) * 28, y - 12, x, y); }
    g.stroke();
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(1.4, 1);
  t.encoding = THREE.sRGBEncoding; t.anisotropy = 8; _texCache.set(key, t); return t;
}
function mapForMaterial(spec) {
  if (spec.kind === 'metal' || spec.kind === 'solid') return null;
  return spec.kind === 'marble' ? marbleTexture(spec.grainHex || '#9a958c') : grainTexture(spec.grainHex || '#7a5a30');
}

// ---- rounded slab helper ----------------------------------------------------
function roundedRect(w, d, r) {
  const s = new THREE.Shape(); const x = -w / 2, y = -d / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + d - r); s.quadraticCurveTo(x + w, y + d, x + w - r, y + d);
  s.lineTo(x + r, y + d); s.quadraticCurveTo(x, y + d, x, y + d - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y); return s;
}

export class ConfiguratorEngine extends Emitter {
  constructor() {
    super();
    this.mode = 'live';
    this.container = null;
    this.registry = {};      // surfaceId -> { mat, meshes, slot }
    this.config = null;
    this.selection = {};
    this.highlight = null;
    this.tweens = [];
    this._raf = null;
    this._disposed = false;
  }

  async mount(container, runtimeConfig, { mode = 'live' } = {}) {
    this.container = container; this.mode = mode; this.config = runtimeConfig;
    const sc = runtimeConfig.scene || {};
    this._envScale = sc.environmentIntensity ?? 1;
    this._alwaysRotate = !!sc.autoRotate;
    this._preset = sc.environment || 'studio';

    const scene = new THREE.Scene(); this.scene = scene;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = sc.exposure ?? 1.02;
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer = renderer; container.appendChild(renderer.domElement);
    this.canvas = renderer.domElement; this.canvas.style.touchAction = 'none';
    this.setBackground(sc.background || 'studio');

    this.camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);

    this._buildEnvironment(this._preset);
    this._buildLights(this._preset);
    this._buildStatics();

    this.modelGroup = new THREE.Group(); scene.add(this.modelGroup);
    await this._buildModel(runtimeConfig.model);
    this._bindSurfaces(runtimeConfig.surfaces);

    // apply defaults
    for (const s of runtimeConfig.surfaces) {
      const optId = s.defaultOptionId || s.options[0]?.id;
      this.selection[s.id] = optId;
      if (optId) this.applyOption(s.id, optId, false);
    }

    this._initControls();
    this._frameHome();
    this._orbit.r = this._orbit.rT * 1.7; // gentle intro glide
    if (REDUCED) this._orbit.r = this._orbit.rT;

    this._ro = new ResizeObserver(() => this.resize()); this._ro.observe(container);
    this.resize();
    const loop = (now) => {
      if (this._disposed) return;
      this._tick(now);
      this._raf = requestAnimationFrame(loop);
    };
    this._raf = requestAnimationFrame(loop);
    return this;
  }

  // ---- scene setup ----------------------------------------------------------
  _envPreset(preset) {
    const P = {
      studio: { warm: 0xffeccf, wi: 1.5, cool: 0xdfe8f5, ci: 1.1, ceil: 2.4, hemi: 0.55, key: 1.15, kc: 0xfff4e6 },
      warm:   { warm: 0xffe0b0, wi: 2.1, cool: 0xf2e6d2, ci: 0.7, ceil: 2.2, hemi: 0.5, key: 1.35, kc: 0xffe6c2 },
      cool:   { warm: 0xf0f4ff, wi: 1.4, cool: 0xdfe8f5, ci: 1.7, ceil: 2.8, hemi: 0.7, key: 1.4, kc: 0xf2f6ff },
      soft:   { warm: 0xfbf3e8, wi: 1.6, cool: 0xeef2f7, ci: 1.5, ceil: 2.6, hemi: 0.85, key: 0.8, kc: 0xfff6ea },
    };
    return P[preset] || P.studio;
  }
  _buildEnvironment(preset) {
    const p = this._envPreset(preset);
    const s = new THREE.Scene();
    s.add(new THREE.Mesh(new THREE.BoxGeometry(24, 18, 24), new THREE.MeshStandardMaterial({ side: THREE.BackSide, color: 0x8c8880, roughness: 1 })));
    const panel = (x, y, z, rx, ry, w, h, i, hex) => {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({ color: 0x000000, emissive: new THREE.Color(hex), emissiveIntensity: i }));
      m.position.set(x, y, z); m.rotation.set(rx, ry, 0); s.add(m);
    };
    panel(0, 8.8, 0, Math.PI / 2, 0, 16, 16, p.ceil, 0xffffff);
    panel(-9, 2, 2, 0, Math.PI / 2, 10, 10, p.wi, p.warm);
    panel(9, 3, -2, 0, -Math.PI / 2, 10, 10, p.ci, p.cool);
    const pm = new THREE.PMREMGenerator(this.renderer);
    if (this._envTex) this._envTex.dispose();
    this._envTex = pm.fromScene(s, 0.05).texture;
    this.scene.environment = this._envTex;
  }
  _buildLights(preset) {
    const p = this._envPreset(preset);
    this._hemi = new THREE.HemisphereLight(0xfff6ea, 0xbfb8ac, p.hemi); this.scene.add(this._hemi);
    const key = new THREE.DirectionalLight(p.kc, p.key); key.position.set(4.5, 8, 4); key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048); key.shadow.radius = 7; key.shadow.bias = -0.0004;
    Object.assign(key.shadow.camera, { near: 1, far: 30, left: -6, right: 6, top: 6, bottom: -6 });
    this._key = key; this.scene.add(key);
  }
  _buildStatics() {
    const rim = new THREE.DirectionalLight(0xdfe8f5, 0.4); rim.position.set(-5, 4, -5); this.scene.add(rim);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.ShadowMaterial({ opacity: 0.26 }));
    ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; this.scene.add(ground);
  }

  // ---- live scene setters (used by the builder Weergave step) ---------------
  setExposure(v) { if (this.renderer) this.renderer.toneMappingExposure = v; }
  setAutoRotate(v) { this._alwaysRotate = !!v; }
  setEnvIntensity(v) {
    this._envScale = v;
    for (const sid of Object.keys(this.registry)) {
      const spec = this._optionSpec(sid, this.selection[sid]);
      if (spec) this.registry[sid].mat.envMapIntensity = (spec.envIntensity || 0.8) * v;
    }
  }
  setEnvironmentPreset(preset) {
    if (this._preset === preset) return;
    this._preset = preset;
    if (this._hemi) this.scene.remove(this._hemi);
    if (this._key) this.scene.remove(this._key);
    // rebuild env + lights (leaves rim/ground; acceptable)
    this._buildEnvironment(preset); this._buildLights(preset);
  }
  setBackground(bg) {
    if (!this.container) return;
    const map = { studio: '', light: '#eeece7', dark: '#17161a' };
    this.container.style.background = map[bg] ?? '';
  }

  // ---- model ----------------------------------------------------------------
  async _buildModel(model) {
    if (model?.source === 'glb' && model.url) {
      try { await this._loadGlb(model.url); return; }
      catch (e) { console.warn('GLB load failed, using fallback model:', e); }
    }
    if (model?.source === 'ai_prompt' || model?.source === 'ai_images') { this._buildPromptModel(model); return; }
    this._buildDemoTable();
  }



  _promptCategory(model = {}) {
    const p = ((model.category || '') + ' ' + (model.prompt || '') + ' ' + ((model.inputImages || []).map((f)=>f.name).join(' '))).toLowerCase();
    if (/stoel|chair|fauteuil|lounge|seat|sofa/.test(p)) return 'chair';
    if (/kast|cabinet|dresser|dressoir|front|wardrobe|closet|sideboard/.test(p)) return 'cabinet';
    if (/lamp|light|verlichting|pendant|shade/.test(p)) return 'lamp';
    if (/tafel|table|desk|bureau|dining/.test(p)) return 'table';
    return 'product';
  }

  _mat(hex = 0xffffff) { return new THREE.MeshStandardMaterial({ color: hex, roughness: 0.48, metalness: 0.02 }); }
  _addMesh(geo, slot, { pos = [0, 0, 0], rot = [0, 0, 0], scale = [1, 1, 1], color = 0xffffff } = {}) {
    const m = new THREE.Mesh(geo, this._mat(color));
    m.position.set(...pos); m.rotation.set(...rot); m.scale.set(...scale);
    m.castShadow = true; m.receiveShadow = true; m.userData.slot = slot;
    this.modelGroup.add(m); return m;
  }
  _roundedSlab(w, d, h, r, slot, y, color = 0xffffff) {
    const geo = new THREE.ExtrudeGeometry(roundedRect(w, d, r), { depth: h, bevelEnabled: true, bevelThickness: Math.min(0.018, h * 0.22), bevelSize: Math.min(0.018, h * 0.22), bevelSegments: 3, curveSegments: 18 });
    geo.rotateX(-Math.PI / 2); geo.translate(0, y, 0); geo.computeVertexNormals();
    return this._addMesh(geo, slot, { color });
  }

  _buildPromptModel(model = {}) {
    // v0.4: local procedural stand-in for a real AI provider result.
    // The data contract is intentionally the same: a generated model exposes named slots.
    const cat = this._promptCategory(model);
    if (cat === 'chair') return this._buildAiChair();
    if (cat === 'cabinet') return this._buildAiCabinet();
    if (cat === 'lamp') return this._buildAiLamp();
    if (cat === 'table') return this._buildAiTable();
    return this._buildAiProduct();
  }

  _buildAiTable() {
    // Premium pedestal table: fewer toy-like bars than the old demo.
    this._roundedSlab(2.25, 1.08, 0.095, 0.18, 'ai_tabletop', 0.82, 0xf6f2ea);
    this._addMesh(new THREE.CylinderGeometry(0.17, 0.24, 0.72, 40), 'ai_frame', { pos: [0, 0.39, 0], color: 0x171717 });
    this._addMesh(new THREE.BoxGeometry(1.45, 0.065, 0.16), 'ai_frame', { pos: [0, 0.07, 0], color: 0x171717 });
    this._addMesh(new THREE.BoxGeometry(0.16, 0.065, 0.82), 'ai_frame', { pos: [0, 0.07, 0], color: 0x171717 });
    this._addMesh(new THREE.CylinderGeometry(0.58, 0.62, 0.035, 56), 'ai_base', { pos: [0, 0.018, 0], color: 0x222222 });
  }

  _buildAiChair() {
    this._roundedSlab(1.15, 0.98, 0.13, 0.16, 'ai_seat', 0.52, 0xf4efe6);
    const back = this._addMesh(new THREE.BoxGeometry(1.12, 0.12, 0.92), 'ai_back', { pos: [0, 1.02, -0.48], rot: [-0.18, 0, 0], color: 0xf4efe6 });
    back.castShadow = true;
    this._addMesh(new THREE.BoxGeometry(0.92, 0.07, 0.78), 'ai_cushion', { pos: [0, 1.03, -0.425], rot: [-0.18, 0, 0], color: 0xd8c6ad });
    const legGeo = new THREE.CylinderGeometry(0.025, 0.035, 0.54, 16);
    [-1, 1].forEach((sx) => [-1, 1].forEach((sz) => this._addMesh(legGeo.clone(), 'ai_frame', { pos: [sx * 0.46, 0.26, sz * 0.36], rot: [0.08 * sz, 0, 0.07 * sx], color: 0x1d1d1d })));
    this._addMesh(new THREE.BoxGeometry(1.2, 0.045, 0.08), 'ai_frame', { pos: [0, 0.34, -0.43], color: 0x1d1d1d });
  }

  _buildAiCabinet() {
    this._addMesh(new THREE.BoxGeometry(1.55, 1.16, 0.48), 'ai_body', { pos: [0, 0.72, 0], color: 0xe8dfd0 });
    this._addMesh(new THREE.BoxGeometry(0.73, 1.02, 0.045), 'ai_fronts', { pos: [-0.38, 0.72, 0.263], color: 0xf3eee5 });
    this._addMesh(new THREE.BoxGeometry(0.73, 1.02, 0.045), 'ai_fronts', { pos: [0.38, 0.72, 0.263], color: 0xf3eee5 });
    this._addMesh(new THREE.CylinderGeometry(0.018, 0.018, 0.45, 18), 'ai_handles', { pos: [-0.08, 0.74, 0.30], rot: [Math.PI / 2, 0, 0], color: 0x171717 });
    this._addMesh(new THREE.CylinderGeometry(0.018, 0.018, 0.45, 18), 'ai_handles', { pos: [0.08, 0.74, 0.30], rot: [Math.PI / 2, 0, 0], color: 0x171717 });
    const legGeo = new THREE.CylinderGeometry(0.035, 0.045, 0.22, 18);
    [-1, 1].forEach((sx) => [-1, 1].forEach((sz) => this._addMesh(legGeo.clone(), 'ai_legs', { pos: [sx * 0.62, 0.11, sz * 0.16], color: 0x1d1d1d })));
  }

  _buildAiLamp() {
    this._addMesh(new THREE.CylinderGeometry(0.32, 0.36, 0.07, 44), 'ai_base', { pos: [0, 0.035, 0], color: 0x181818 });
    this._addMesh(new THREE.CylinderGeometry(0.028, 0.028, 1.15, 24), 'ai_base', { pos: [0, 0.62, 0], color: 0x181818 });
    this._addMesh(new THREE.CylinderGeometry(0.48, 0.31, 0.42, 56, 1, true), 'ai_shade', { pos: [0, 1.32, 0], color: 0xefe6d7 });
    this._addMesh(new THREE.TorusGeometry(0.34, 0.012, 12, 56), 'ai_shade', { pos: [0, 1.53, 0], rot: [Math.PI / 2, 0, 0], color: 0xd7c6ac });
    this._addMesh(new THREE.TorusGeometry(0.50, 0.012, 12, 56), 'ai_shade', { pos: [0, 1.11, 0], rot: [Math.PI / 2, 0, 0], color: 0xd7c6ac });
  }

  _buildAiProduct() {
    this._roundedSlab(1.35, 0.82, 0.42, 0.12, 'ai_body', 0.36, 0xece6dc);
    this._addMesh(new THREE.BoxGeometry(1.05, 0.12, 0.065), 'ai_detail', { pos: [0, 0.62, 0.43], color: 0x1d1d1d });
    this._addMesh(new THREE.CylinderGeometry(0.09, 0.09, 0.09, 32), 'ai_accent', { pos: [-0.42, 0.63, 0.47], rot: [Math.PI / 2, 0, 0], color: 0xc6a671 });
    this._addMesh(new THREE.CylinderGeometry(0.09, 0.09, 0.09, 32), 'ai_accent', { pos: [0.42, 0.63, 0.47], rot: [Math.PI / 2, 0, 0], color: 0xc6a671 });
  }

  _buildDemoTable() {
    const LEG_H = 0.72, CORE_T = 0.09, W = 2.15, D = 1.02, HPL_T = 0.008, T = 0.05;
    const g = this.modelGroup;

    const coreGeo = new THREE.ExtrudeGeometry(roundedRect(W, D, 0.09), { depth: CORE_T, bevelEnabled: true, bevelThickness: 0.01, bevelSize: 0.01, bevelSegments: 2, curveSegments: 12 });
    coreGeo.rotateX(-Math.PI / 2); coreGeo.translate(0, LEG_H + CORE_T, 0); coreGeo.computeVertexNormals();
    const core = new THREE.Mesh(coreGeo, new THREE.MeshStandardMaterial({ color: 0xffffff }));
    core.castShadow = true; core.userData.slot = 'material_core'; g.add(core);

    const hplGeo = new THREE.ExtrudeGeometry(roundedRect(W - 0.004, D - 0.004, 0.088), { depth: HPL_T, bevelEnabled: false, curveSegments: 12 });
    hplGeo.rotateX(-Math.PI / 2); hplGeo.translate(0, LEG_H + CORE_T + HPL_T, 0); hplGeo.computeVertexNormals();
    const hpl = new THREE.Mesh(hplGeo, new THREE.MeshStandardMaterial({ color: 0xffffff }));
    hpl.castShadow = true; hpl.userData.slot = 'material_hpl'; g.add(hpl);

    const endX = W / 2 - 0.24, footD = D - 0.22;
    const bar = (w, h, d, x, y, z) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshStandardMaterial({ color: 0x1d1d1d }));
      m.position.set(x, y, z); m.castShadow = true; m.userData.slot = 'material_frame'; g.add(m);
    };
    [-1, 1].forEach((s) => { const x = s * endX;
      bar(T, LEG_H, T, x, LEG_H / 2, footD / 2); bar(T, LEG_H, T, x, LEG_H / 2, -footD / 2);
      bar(T, T, footD + T, x, LEG_H - T / 2, 0); bar(T, T, footD + T, x, T / 2, 0);
    });
    bar(endX * 2, T, T, 0, LEG_H * 0.34, 0);
  }

  async _loadGlb(url) {
    const loader = new GLTFLoader();
    const gltf = await loader.loadAsync(url);
    const root = gltf.scene || gltf.scenes[0];
    // normalize scale/position: fit into ~2 units and sit on ground
    const box = new THREE.Box3().setFromObject(root);
    const size = new THREE.Vector3(); box.getSize(size);
    const center = new THREE.Vector3(); box.getCenter(center);
    const scale = 2.2 / Math.max(size.x, size.y, size.z, 0.001);
    root.scale.setScalar(scale);
    root.position.sub(center.multiplyScalar(scale));
    const box2 = new THREE.Box3().setFromObject(root);
    root.position.y -= box2.min.y; // sit on floor
    root.traverse((o) => {
      if (o.isMesh) {
        o.castShadow = true;
        // slot = material name (or mesh name) so surfaces can target it
        const matName = (o.material && o.material.name) || o.name || 'material';
        o.userData.slot = matName;
      }
    });
    this.modelGroup.add(root);
  }

  // Detect slots from whatever model is loaded (used by the builder Model step).
  detectSlots() {
    const slots = new Map();
    this.modelGroup.traverse((o) => {
      if (o.isMesh && o.userData.slot) {
        if (!slots.has(o.userData.slot)) slots.set(o.userData.slot, 0);
        slots.set(o.userData.slot, slots.get(o.userData.slot) + 1);
      }
    });
    return [...slots.entries()].map(([slot, count]) => ({ slot, count }));
  }

  _bindSurfaces(surfaces) {
    // collect meshes per slot
    const bySlot = new Map();
    this.modelGroup.traverse((o) => {
      if (o.isMesh && o.userData.slot) {
        if (!bySlot.has(o.userData.slot)) bySlot.set(o.userData.slot, []);
        bySlot.get(o.userData.slot).push(o);
      }
    });
    this.registry = {}; this._targets = [];
    for (const s of surfaces) {
      const meshes = bySlot.get(s.slot) || [];
      if (!meshes.length) continue;
      const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5, metalness: 0, envMapIntensity: 0.8 });
      meshes.forEach((m) => { m.material = mat; m.userData.surfaceId = s.id; });
      this.registry[s.id] = { mat, meshes, slot: s.slot };
      this._targets.push(...meshes);
    }
  }

  // ---- apply finishes -------------------------------------------------------
  _optionSpec(surfaceId, optionId) {
    const s = this.config.surfaces.find((x) => x.id === surfaceId);
    const o = s?.options.find((x) => x.id === optionId);
    return o?.material || null;
  }

  _loadTexture(url) {
    this._texUrlCache = this._texUrlCache || new Map();
    if (this._texUrlCache.has(url)) return this._texUrlCache.get(url);
    const t = new THREE.TextureLoader().load(url);
    t.wrapS = t.wrapT = THREE.RepeatWrapping; t.encoding = THREE.sRGBEncoding; t.anisotropy = 8;
    this._texUrlCache.set(url, t); return t;
  }

  applyOption(surfaceId, optionId, animate = true) {
    const reg = this.registry[surfaceId]; const spec = this._optionSpec(surfaceId, optionId);
    if (!reg || !spec) return;
    this.selection[surfaceId] = optionId;
    const mat = reg.mat, meshes = reg.meshes;
    const to = new THREE.Color(spec.colorHex);
    const map = spec.textureUrl ? this._loadTexture(spec.textureUrl) : mapForMaterial(spec);
    const envTarget = (spec.envIntensity ?? 0.8) * (this._envScale ?? 1);

    if (!animate || REDUCED) {
      mat.color.copy(to); mat.roughness = spec.roughness; mat.metalness = spec.metalness;
      mat.envMapIntensity = envTarget; mat.map = map; mat.emissiveIntensity = this.highlight === surfaceId ? 0.08 : 0;
      mat.needsUpdate = true; return;
    }
    const fc = mat.color.clone(), fr = mat.roughness, fm = mat.metalness, fe = mat.envMapIntensity;
    const baseScale = meshes.map((m) => m.scale.x); let swapped = false;
    mat.emissive.setHex(0xffffff);
    this._tween(440, (t) => {
      mat.color.copy(fc).lerp(to, t);
      mat.roughness = fr + (spec.roughness - fr) * t;
      mat.metalness = fm + (spec.metalness - fm) * t;
      mat.envMapIntensity = fe + (envTarget - fe) * t;
      const p = Math.sin(t * Math.PI);
      mat.emissiveIntensity = (this.highlight === surfaceId ? 0.08 : 0) + p * 0.10;
      meshes.forEach((m, i) => m.scale.setScalar(baseScale[i] * (1 + p * 0.012)));
      if (!swapped && t > 0.18) { mat.map = map; mat.needsUpdate = true; swapped = true; }
    }, () => {
      mat.emissiveIntensity = this.highlight === surfaceId ? 0.08 : 0;
      meshes.forEach((m, i) => m.scale.setScalar(baseScale[i]));
    });
  }

  applySelection(selection, animate = false) {
    for (const [sid, oid] of Object.entries(selection)) this.applyOption(sid, oid, animate);
  }

  // ---- builder highlight / hover -------------------------------------------
  setHighlightSurface(surfaceId) {
    if (this.highlight === surfaceId) return;
    if (this.highlight && this.registry[this.highlight]) { const m = this.registry[this.highlight].mat; m.emissive.setHex(0x000000); m.emissiveIntensity = 0; }
    this.highlight = surfaceId;
    if (surfaceId && this.registry[surfaceId]) { const m = this.registry[surfaceId].mat; m.emissive.setHex(0xffffff); m.emissiveIntensity = 0.08; }
  }
  _hoverSurface(surfaceId) {
    if (this._hover === surfaceId) return;
    if (this._hover && this._hover !== this.highlight && this.registry[this._hover]) { const m = this.registry[this._hover].mat; m.emissive.setHex(0x000000); m.emissiveIntensity = 0; }
    this._hover = surfaceId;
    if (surfaceId && surfaceId !== this.highlight && this.registry[surfaceId]) { const m = this.registry[surfaceId].mat; m.emissive.setHex(0xffffff); m.emissiveIntensity = 0.05; }
  }

  pickSurfaceAt(clientX, clientY) {
    if (!this._ray || !this._targets?.length) return null;
    const r = this.canvas.getBoundingClientRect();
    this._ndc.x = ((clientX - r.left) / r.width) * 2 - 1;
    this._ndc.y = -((clientY - r.top) / r.height) * 2 + 1;
    this._ray.setFromCamera(this._ndc, this.camera);
    const hit = this._ray.intersectObjects(this._targets, false);
    return hit.length ? { surfaceId: hit[0].object.userData.surfaceId, point: hit[0].point } : null;
  }

  // ---- camera framing -------------------------------------------------------
  _boundsOf(meshes) {
    const box = new THREE.Box3();
    (meshes || []).forEach((m) => box.expandByObject(m));
    return box;
  }
  _frameHome() {
    const box = new THREE.Box3().setFromObject(this.modelGroup);
    const size = new THREE.Vector3(); box.getSize(size);
    const center = new THREE.Vector3(); box.getCenter(center);
    this._modelBox = box;
    const r = Math.max(size.length() * 0.95, 2.4);
    this._orbit.rT = r; this._orbit.thetaT = 0.62; this._orbit.phiT = 1.12;
    this._orbit.tTarget.copy(center);
  }
  focusSurface(surfaceId) {
    if (surfaceId === 'home' || !this.registry[surfaceId]) { this._frameHome(); this._orbit.lastInteract = performance.now(); return; }
    const box = this._boundsOf(this.registry[surfaceId].meshes);
    const size = new THREE.Vector3(); box.getSize(size);
    const center = new THREE.Vector3(); box.getCenter(center);
    const mb = this._modelBox || new THREE.Box3().setFromObject(this.modelGroup);
    const mh = Math.max(mb.max.y - mb.min.y, 0.001);
    const h = clamp((center.y - mb.min.y) / mh, 0, 1);          // 0 = bottom, 1 = top
    this._orbit.rT = clamp(size.length() * 1.7 + 1.4, 2.6, this._orbit.maxR);
    this._orbit.phiT = 1.35 - h * 0.53;                          // top -> higher camera
    this._orbit.tTarget.copy(center);
    this._orbit.lastInteract = performance.now();
  }

  // ---- controls (hand-rolled: smooth on mouse + touch) ----------------------
  _initControls() {
    this._ray = new THREE.Raycaster(); this._ndc = new THREE.Vector2();
    const o = this._orbit = {
      target: new THREE.Vector3(), tTarget: new THREE.Vector3(),
      r: 5, theta: 0.62, phi: 1.12, rT: 5, thetaT: 0.62, phiT: 1.12,
      minR: 2.4, maxR: 9, minPhi: 0.28, maxPhi: 1.44,
      dragging: false, moved: 0, lastX: 0, lastY: 0, pinch: 0, lastInteract: performance.now(),
    };
    const cv = this.canvas;
    cv.addEventListener('pointerdown', (e) => { o.dragging = true; o.moved = 0; o.lastX = e.clientX; o.lastY = e.clientY; cv.setPointerCapture?.(e.pointerId); });
    cv.addEventListener('pointermove', (e) => {
      if (o.dragging) {
        const dx = e.clientX - o.lastX, dy = e.clientY - o.lastY; o.moved += Math.abs(dx) + Math.abs(dy);
        o.lastX = e.clientX; o.lastY = e.clientY;
        o.thetaT -= dx * 0.0075; o.phiT = clamp(o.phiT - dy * 0.0075, o.minPhi, o.maxPhi);
        o.lastInteract = performance.now();
        if (this.mode === 'builder') { this._hoverSurface(null); this.emit('hoverend'); }
        return;
      }
      if (this.mode === 'builder') {
        const p = this.pickSurfaceAt(e.clientX, e.clientY);
        if (p && p.surfaceId) { this._hoverSurface(p.surfaceId); cv.style.cursor = 'pointer'; this.emit('hover', { ...p }); }
        else { this._hoverSurface(null); cv.style.cursor = 'default'; this.emit('hoverend'); }
      }
    });
    const up = (e) => {
      o.dragging = false;
      if (this.mode === 'builder' && o.moved < 6) {
        const p = this.pickSurfaceAt(e.clientX, e.clientY);
        if (p && p.surfaceId) { this.focusSurface(p.surfaceId); this.emit('select', p.surfaceId); }
      }
    };
    cv.addEventListener('pointerup', up);
    cv.addEventListener('pointercancel', () => { o.dragging = false; });
    cv.addEventListener('wheel', (e) => { e.preventDefault(); o.rT = clamp(o.rT * (1 + e.deltaY * 0.0009), o.minR, o.maxR); o.lastInteract = performance.now(); }, { passive: false });
    cv.addEventListener('touchmove', (e) => {
      if (e.touches.length === 2) {
        const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
        if (o.pinch) o.rT = clamp(o.rT * (o.pinch / d), o.minR, o.maxR);
        o.pinch = d; o.lastInteract = performance.now();
      }
    }, { passive: true });
    cv.addEventListener('touchend', () => { o.pinch = 0; });
  }

  // ---- transitions ----------------------------------------------------------
  _tween(dur, upd, done) {
    if (REDUCED) { upd(1); done && done(); return; }
    const st = performance.now();
    this.tweens.push({ update(now) { const t = clamp((now - st) / dur, 0, 1); upd(easeOut(t)); if (t >= 1) { done && done(); return true; } return false; } });
  }

  _tick(now) {
    const o = this._orbit;
    if (o) {
      if (!o.dragging && !REDUCED) {
        if (this._alwaysRotate) o.thetaT += 0.0016;
        else if ((now - o.lastInteract) > 3400) o.thetaT += 0.0012;
      }
      const L = REDUCED ? 1 : 0.09;
      o.r += (o.rT - o.r) * L; o.theta += (o.thetaT - o.theta) * L; o.phi += (o.phiT - o.phi) * L;
      o.target.lerp(o.tTarget, L);
      const sp = Math.sin(o.phi);
      this.camera.position.set(
        o.target.x + o.r * sp * Math.sin(o.theta),
        o.target.y + o.r * Math.cos(o.phi),
        o.target.z + o.r * sp * Math.cos(o.theta));
      this.camera.lookAt(o.target);
    }
    for (let i = this.tweens.length - 1; i >= 0; i--) if (this.tweens[i].update(now)) this.tweens.splice(i, 1);
    this.renderer.render(this.scene, this.camera);
  }

  resize() {
    if (!this.container || !this.renderer) return;
    const w = this.container.clientWidth || 1, h = this.container.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
  }

  dispose() {
    this._disposed = true;
    if (this._raf) cancelAnimationFrame(this._raf);
    this._ro?.disconnect();
    try {
      this.scene?.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) { const m = o.material; (Array.isArray(m) ? m : [m]).forEach((x) => x.dispose()); } });
      this.renderer?.dispose();
      this.renderer?.domElement?.remove();
    } catch (e) { /* noop */ }
  }
}
