# Configurator Studio v0.4.2

AI-first proof-of-concept voor een no-code 3D configurator SaaS.

Belangrijkste fix in v0.4.2:

- Port `9999` deploy-fix via nginx.
- Voorkomt dat iPhone/Safari de serverresponse als download behandelt.
- Levert `/` expliciet als `index.html` met `text/html`.
- Levert ES modules met correcte JavaScript MIME type.

Gebruik `deploy/deploy-9999.sh` op de VPS.
