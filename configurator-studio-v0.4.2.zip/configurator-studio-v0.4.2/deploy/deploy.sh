#!/usr/bin/env bash
# Configurator Studio — deploy to nginx on this VPS.
# Run from anywhere:  bash deploy/deploy.sh
set -euo pipefail

# --- paths ------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"          # the 'variant' folder
WEB_ROOT="/var/www/configurator-studio"
NGINX_CONF="/etc/nginx/sites-available/configurator-studio"
NGINX_LINK="/etc/nginx/sites-enabled/configurator-studio"

echo "→ Source:   $SRC_DIR"
echo "→ Web root: $WEB_ROOT"

# --- copy the app to the web root (exclude deploy/) -------------------------
sudo mkdir -p "$WEB_ROOT"
sudo rsync -a --delete --exclude 'deploy' --exclude '.git' "$SRC_DIR"/ "$WEB_ROOT"/
sudo chown -R www-data:www-data "$WEB_ROOT"
echo "✓ Files copied."

# --- install nginx config (only if not already present) ---------------------
if [ ! -f "$NGINX_CONF" ]; then
  sudo cp "$SCRIPT_DIR/nginx-configurator-studio.conf" "$NGINX_CONF"
  echo "✓ Nginx config installed at $NGINX_CONF"
else
  echo "• Nginx config already exists — left untouched. Edit it manually if needed."
fi
[ -L "$NGINX_LINK" ] || sudo ln -s "$NGINX_CONF" "$NGINX_LINK"

# --- test + reload ----------------------------------------------------------
sudo nginx -t
sudo systemctl reload nginx
echo "✓ Nginx reloaded."

# --- firewall hint ----------------------------------------------------------
if command -v ufw >/dev/null 2>&1; then
  sudo ufw allow 'Nginx HTTP' >/dev/null 2>&1 || true
fi

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo
echo "KLAAR. Open in je browser:  http://${IP:-<VPS-IP>}/"
echo "(Zorg dat poort 80 open staat bij je VPS-provider.)"
