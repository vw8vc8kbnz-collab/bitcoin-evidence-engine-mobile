#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"
WEB_ROOT="/var/www/configurator-studio"
NGINX_CONF="/etc/nginx/sites-available/configurator-studio-9999"
NGINX_LINK="/etc/nginx/sites-enabled/configurator-studio-9999"

sudo mkdir -p "$WEB_ROOT"
sudo rsync -a --delete --exclude 'deploy' --exclude '.git' "$SRC_DIR"/ "$WEB_ROOT"/
sudo chown -R www-data:www-data "$WEB_ROOT"

# If an older systemd service is occupying :9999 and serving the wrong content, stop it.
if systemctl list-unit-files | grep -q '^configurator\.service'; then
  sudo systemctl stop configurator || true
  sudo systemctl disable configurator || true
fi

sudo cp "$SCRIPT_DIR/nginx-configurator-studio-9999.conf" "$NGINX_CONF"
sudo ln -sfn "$NGINX_CONF" "$NGINX_LINK"
sudo nginx -t
sudo systemctl reload nginx

if command -v ufw >/dev/null 2>&1; then
  sudo ufw allow 9999/tcp >/dev/null 2>&1 || true
fi

echo "KLAAR — http://$(hostname -I | awk '{print $1}'):9999/"
