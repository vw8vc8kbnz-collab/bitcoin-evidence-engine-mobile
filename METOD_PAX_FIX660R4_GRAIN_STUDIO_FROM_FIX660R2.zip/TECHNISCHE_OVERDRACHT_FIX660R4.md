# Technische overdracht FIX660R4

## Doel
FIX660R4 is de gecorrigeerde installer voor de al gebouwde FIX660R3 Grain Studio UI. De huidige VPS staat op FIX660R2 met family marker `FIX660_GRAIN_STUDIO`; R3 weigerde die marker omdat zijn baseline allowlist alleen FIX659R1/R2 kende.

## Veilig upgradecontract
- FIX659R1 en FIX659R2 blijven ondersteund met bestaande golden hashes.
- FIX660R2 wordt alleen geaccepteerd wanneer meerdere immutable app-bestanden exact de bekende R2 hashes hebben.
- Een willekeurige of lokaal gewijzigde `FIX660_GRAIN_STUDIO` wordt fail-closed geweigerd.
- Een exact reeds geïnstalleerde doelbuild mag idempotent opnieuw worden geverifieerd.
- Preflight, backup, state-preserving rsync, rollback en tempfile-smokes blijven behouden.

## Functionele doelbuild
- Mobile nerfpreview is een fixed bottom drawer op dezelfde <=900px breakpoint als de mobiele nerf-layout.
- Preview staat niet inline in de scrollflow.
- Semantische nerfvolgorde is bottom-to-top: positie/grainOrder 1 = fysiek onderste paneel; elk nieuw paneel komt erboven.
- Presentatielaag draait alleen de zichtvolgorde om voor top-down DOM/canvas rendering.
- Touch reorder vertaalt zichtvolgorde terug naar bottom-to-top data.
- Exacte werkelijke widthMm-gelijkheid blijft verplicht.

## Buiten scope / behouden
Pricing mixed-VAT v2, CSV-only library, taxonomy/Admin override, material swatches, optimizer, submit-idempotency, SSE/security en http://51.195.102.180:8790 blijven behouden.
