# METOD/PAX FIX660R4 — corrected in-family upgrade

Deze release bevat dezelfde gewenste Grain Studio UI als FIX660R3: mobile bottom drawer + bottom-to-top stack semantics.

FIX660R4 corrigeert uitsluitend de deployment route voor een VPS waar FIX660R2 al live staat. FIX660R2 en het doel delen de family marker `FIX660_GRAIN_STUDIO`; daarom verifieert de installer de exacte immutable FIX660R2 bronhashes voordat hij live state aanraakt. Marker-only acceptatie is verboden.

De release is schoon: geen runtime catalogusstate, events, generated backups of CSV in de ZIP. Pricing, optimizer, library/taxonomy, submit/security en URL/poort blijven buiten scope.
