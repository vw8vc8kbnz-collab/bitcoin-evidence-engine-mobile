#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="FIX660R4"
STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${METOD_PAX_APP_DIR:-/opt/adzaagt/metod-pax}"
PUBLIC_ORIGIN="${PUBLIC_ORIGIN:-http://51.195.102.180:8790}"
ADMIN_ORIGIN="${ADMIN_ORIGIN:-${PUBLIC_ORIGIN}}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-/etc/adzaagt/metod-pax/admin_credentials.live.json}"
TS="$(date +%Y%m%d_%H%M%S)"
LOG="/tmp/METOD_PAX_FIX660R4_DEPLOY_${TS}.log"
APP_BACKUP="${APP_DIR}_backup_before_FIX660R4_${TS}"
CONFIG_TAR="/var/backups/metod-pax/FIX660R4_outer_config_${TS}.tar"
HAD_APP=0
LIVE_TOUCHED=0
SUCCESS=0

info(){ echo "[$VERSION] $*"; }
fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }

rollback(){
  local rc=$?
  if [[ "$SUCCESS" -eq 1 ]]; then
    info "Deploy succesvol. Log: $LOG"
    return 0
  fi
  echo "[$VERSION] INSTALLATIE MISLUKT (code $rc). Log: $LOG" >&2
  echo "[$VERSION] Staging blijft voor diagnose: $STAGE" >&2
  if [[ "$LIVE_TOUCHED" -eq 1 ]]; then
    echo "[$VERSION] Automatische app/config-rollback wordt uitgevoerd..." >&2
    set +e
    if [[ "$HAD_APP" -eq 1 && -d "$APP_BACKUP" ]]; then
      sudo rm -rf "$APP_DIR"
      sudo cp -a "$APP_BACKUP" "$APP_DIR"
    elif [[ "$HAD_APP" -eq 0 ]]; then
      sudo rm -rf "$APP_DIR"
    fi
    if [[ -f "$CONFIG_TAR" ]]; then
      sudo rm -rf /etc/adzaagt/metod-pax
      sudo rm -f /etc/systemd/system/metod-pax.service
      sudo rm -f /etc/systemd/system/metod-pax-certbot-renew.service /etc/systemd/system/metod-pax-certbot-renew.timer
      sudo rm -f /etc/systemd/system/timers.target.wants/metod-pax-certbot-renew.timer
      sudo rm -f /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790
      sudo rm -f /etc/nginx/sites-available/metod-pax-https /etc/nginx/sites-enabled/metod-pax-https
      sudo rm -f /etc/nginx/sites-available/metod-pax-acme-ip /etc/nginx/sites-enabled/metod-pax-acme-ip
      sudo tar -xpf "$CONFIG_TAR" -C /
    fi
    sudo systemctl daemon-reload || true
    if sudo nginx -t; then sudo systemctl reload nginx || true; fi
    if [[ -f /etc/systemd/system/metod-pax.service ]]; then sudo systemctl restart metod-pax.service || true; fi
    if [[ -e /etc/systemd/system/timers.target.wants/metod-pax-certbot-renew.timer ]]; then sudo systemctl start metod-pax-certbot-renew.timer || true; fi
    echo "[$VERSION] Rollbackpoging afgerond." >&2
    set -e
  fi
  return "$rc"
}
trap rollback EXIT
exec > >(tee -a "$LOG") 2>&1

[[ "$PUBLIC_ORIGIN" == 'http://51.195.102.180:8790' ]] || fail "PUBLIC_ORIGIN moet voor deze compatibility release exact http://51.195.102.180:8790 zijn"
[[ "$ADMIN_ORIGIN" == "$PUBLIC_ORIGIN" ]] || fail "ADMIN_ORIGIN moet gelijk zijn aan PUBLIC_ORIGIN"
[[ -f "$CREDS_FILE" ]] || fail "Bestaande externe Admin credentials ontbreken: $CREDS_FILE"
for cmd in rsync python3 sha256sum grep tar curl nginx systemctl; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
sudo -v
sudo test -r "$CREDS_FILE" || fail "Admin credentials zijn niet root-leesbaar: $CREDS_FILE"

# Prove the existing golden service is healthy before touching anything.
if [[ -d "$APP_DIR/app" ]]; then
  sudo systemctl is-active --quiet metod-pax.service || fail "Bestaande metod-pax.service is vóór deploy niet actief"
  curl -fsS http://127.0.0.1:8790/ -o /dev/null || fail "Bestaande Tool A op :8790 geeft vóór deploy geen HTTP succes"
  curl -fsS http://127.0.0.1:8792/api/materials/library -o /dev/null || fail "Bestaande backend :8792 is vóór deploy niet gezond"
  LIVE_MARKER="$(grep -m1 "__PERFORMANCE_BUILD" "$APP_DIR/app/server_py.py" 2>/dev/null || true)"
  case "$LIVE_MARKER" in
    *"FIX659R1_ADAPTIVE_CNC_MOBILE_FIT"*)
      # Current production baseline confirmed by the user. Verify immutable source hashes,
      # not just the text marker, before allowing the consolidated R1 -> R2 -> FIX660 jump.
      echo "94e87b86287028675ff9b2d627a367f1820c7674d45678ca5e2cd329e7f926b6  $APP_DIR/app/toolA.html" | sha256sum -c - >/dev/null || fail "FIX659R1 toolA.html wijkt af van de golden baseline"
      echo "31aebb39672abf27134dd64499ca868a9ff6361542fb47d2f5f8f644173fc277  $APP_DIR/app/server_py.py" | sha256sum -c - >/dev/null || fail "FIX659R1 server_py.py wijkt af van de golden baseline"
      echo "0da05bf47404f8e7b3e3b3dfd2d582f400da6b9acefdbf58d61f56300a69c179  $APP_DIR/app/toolA_material_swatch_renderer.js" | sha256sum -c - >/dev/null || fail "FIX659R1 material renderer wijkt af van de golden baseline"
      grep -Fq "FIX659R2_MOBILE_POLISH_SMART_QTY" "$STAGE/app/toolA.html" || fail "Staged FIX660 bevat de vereiste FIX659R2 mobile-polish tussenlaag niet"
      info "Exacte FIX659R1 golden baseline bevestigd; FIX659R2-polish wordt automatisch meegeüpgraded vóór FIX660."
      ;;
    *"FIX659R2_MOBILE_POLISH_SMART_QTY"*)
      echo "a96713f3d0cd1fb8b17b5b34467118d61b01aa8c6d21dfe919233d732bde7050  $APP_DIR/app/toolA.html" | sha256sum -c - >/dev/null || fail "FIX659R2 toolA.html wijkt af van de golden baseline"
      echo "ec598352d142f7a2017ace945ef363aaf532b3ef5bb1d4d490d526ea112d94b5  $APP_DIR/app/server_py.py" | sha256sum -c - >/dev/null || fail "FIX659R2 server_py.py wijkt af van de golden baseline"
      echo "0da05bf47404f8e7b3e3b3dfd2d582f400da6b9acefdbf58d61f56300a69c179  $APP_DIR/app/toolA_material_swatch_renderer.js" | sha256sum -c - >/dev/null || fail "FIX659R2 material renderer wijkt af van de golden baseline"
      info "Exacte FIX659R2 golden baseline bevestigd."
      ;;
    *"FIX660_GRAIN_STUDIO"*)
      # FIX660R2 is currently live on the user's VPS. Because FIX660R2 and the
      # target FIX660R3 UI share the family build marker, prove the exact immutable
      # source hashes before allowing the in-family upgrade. Never accept marker-only.
      R2_OK=1
      [[ "$(sha256sum "$APP_DIR/app/toolA.html" | awk '{print $1}')" == "77703f8332085663e80e5c722b4e99265e43cfe419cf3ddebc51e6a706453215" ]] || R2_OK=0
      [[ "$(sha256sum "$APP_DIR/app/server_py.py" | awk '{print $1}')" == "058b4692aa251ff1c4a92489d639da60027e28bd120a2ab362eec8c3a63f122f" ]] || R2_OK=0
      [[ "$(sha256sum "$APP_DIR/app/toolA_grain_studio_renderer.js" | awk '{print $1}')" == "4e1ad693fb2bf4232e7e75a4c55fc07f5ae4e04c63faa1b161ad6573ec50f0d1" ]] || R2_OK=0
      [[ "$(sha256sum "$APP_DIR/app/toolA_grain_studio.css" | awk '{print $1}')" == "1f7f79b828389c4e62ed6fdd38eae666384bbec92011a77748cc2c8beea2f9ec" ]] || R2_OK=0
      [[ "$(sha256sum "$APP_DIR/app/toolA_grain_mobile_scale.js" | awk '{print $1}')" == "18d430df907c5635fabbb9489b87d2fa14961982b46553cf9344b438f09e3fb4" ]] || R2_OK=0
      if [[ "$R2_OK" -eq 1 ]]; then
        info "Exacte FIX660R2 golden baseline bevestigd; in-family upgrade naar mobile drawer/bottom-up stack toegestaan."
      else
        # If all target immutable UI hashes already match staged R3, treat rerun as an
        # intentional idempotent refresh; otherwise fail closed.
        TARGET_OK=1
        for f in toolA.html toolA_grain_studio_renderer.js toolA_grain_studio.css toolA_grain_mobile_scale.js toolA_grain_mobile_scale.css; do
          [[ -f "$APP_DIR/app/$f" && "$(sha256sum "$APP_DIR/app/$f" | awk '{print $1}')" == "$(sha256sum "$STAGE/app/$f" | awk '{print $1}')" ]] || TARGET_OK=0
        done
        [[ "$TARGET_OK" -eq 1 ]] || fail "Live FIX660 marker gevonden, maar bronhashes zijn niet exact FIX660R2 en ook niet de staged doelbuild; deploy stopt fail-closed"
        info "Exacte FIX660R3-doelbuild staat al live; veilige idempotente refresh toegestaan."
      fi
      ;;
    *)
      fail "FIX660R4 accepteert uitsluitend de exacte FIX659R1/FIX659R2/FIX660R2 golden baseline of een reeds aanwezige exacte FIX660R3-doelbuild; live marker: ${LIVE_MARKER:-onbekend}"
      ;;
  esac
fi

# Extracted release integrity and clean-tree contracts.
(cd "$STAGE" && sha256sum -c SHA256SUMS.txt >/dev/null)
python3 - "$STAGE" <<'PY'
from pathlib import Path
import json,sys
root=Path(sys.argv[1])
bad=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and ('__pycache__' in p.parts or p.suffix.lower() in {'.pyc','.bak','.csv'})]
if bad: raise SystemExit(f'Onschone staged release: {bad[:20]}')
lib=json.loads((root/'app/material_library.json').read_text(encoding='utf-8'))
assert lib.get('source')=='CSV_CATALOG_ONLY' and lib.get('records')==[]
assert lib.get('pricingModel')=='catalog_sell_price_incl_vat_v2'
print('Release integrity/CSV-only seed/pricing-v2: OK')
PY

# All application regressions run before live files are touched.
python3 -m py_compile "$STAGE"/app/*.py "$STAGE"/tools/*.py
bash -n "$STAGE/DEPLOY_FIX660.sh"
bash -n "$STAGE/INSTALL_FIX660R4_FROM_STAGE.sh"
if command -v node >/dev/null; then for f in "$STAGE"/app/*.js; do node --check "$f" >/dev/null; done; fi
python3 "$STAGE/tools/fix660_regression.py"

PREFLIGHT_ENV="$STAGE/.production-preflight.env"
cat > "$PREFLIGHT_ENV" <<EOF2
APP_ENV=production
PRODUCTION_HARDENING=1
ADMIN_HASH_ONLY=1
ADMIN_STAGING_OPEN=0
ADMIN_CREDENTIALS_FILE=$CREDS_FILE
LEGACY_HTTP_COMPAT=1
LEGACY_HTTP_ORIGIN=$PUBLIC_ORIGIN
TRUSTED_PROXY_IPS=127.0.0.1,::1
ALLOWED_ORIGINS=$PUBLIC_ORIGIN
ALLOWED_ADMIN_ORIGINS=$ADMIN_ORIGIN
PUBLIC_JSON_MAX_BYTES=16777216
SUBMIT_MAX_BYTES=8388608
PUBLIC_DXF_BLOB_MAX_BYTES=2097152
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
EOF2
sudo env APP_DIR="$STAGE" METOD_ENV_FILE="$PREFLIGHT_ENV" python3 "$STAGE/tools/final_preflight.py"
rm -f "$PREFLIGHT_ENV"
# Validation imports/py_compile may create bytecode in staging. Never copy test artifacts live.
find "$STAGE" -type d -name '__pycache__' -prune -exec rm -rf {} +
find "$STAGE" -type f -name '*.pyc' -delete
info "FIX660 preflight groen. Nu pas live backup/switch."

if [[ -d "$APP_DIR/app" ]]; then
  HAD_APP=1
  sudo cp -a "$APP_DIR" "$APP_BACKUP"
  info "Volledige appbackup: $APP_BACKUP"
fi
sudo mkdir -p "$(dirname "$CONFIG_TAR")"
TAR_INPUTS=()
for f in /etc/adzaagt/metod-pax /etc/systemd/system/metod-pax.service \
         /etc/systemd/system/metod-pax-certbot-renew.service /etc/systemd/system/metod-pax-certbot-renew.timer \
         /etc/systemd/system/timers.target.wants/metod-pax-certbot-renew.timer \
         /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790 \
         /etc/nginx/sites-available/metod-pax-https /etc/nginx/sites-enabled/metod-pax-https \
         /etc/nginx/sites-available/metod-pax-acme-ip /etc/nginx/sites-enabled/metod-pax-acme-ip; do
  [[ -e "$f" || -L "$f" ]] && TAR_INPUTS+=("${f#/}")
done
if ((${#TAR_INPUTS[@]})); then
  sudo tar -cpf "$CONFIG_TAR" -C / "${TAR_INPUTS[@]}"
else
  sudo tar -cpf "$CONFIG_TAR" --files-from /dev/null
fi
info "Externe configbackup: $CONFIG_TAR"
LIVE_TOUCHED=1

sudo mkdir -p "$APP_DIR/app/jobs" "$APP_DIR/app/requests" "$APP_DIR/app/queue" "$APP_DIR/app/archive" \
  "$APP_DIR/app/backups" "$APP_DIR/app/drafts" "$APP_DIR/app/system" "$APP_DIR/app/decor_media" "$APP_DIR/app/config"

# Existing live state always wins; release seeds are only for a truly fresh install.
if [[ ! -f "$APP_DIR/app/material_library.json" ]]; then sudo install -m 0640 "$STAGE/app/material_library.json" "$APP_DIR/app/material_library.json"; fi
if [[ ! -f "$APP_DIR/app/config/pricing_active.json" ]]; then sudo install -m 0640 "$STAGE/app/config/pricing_active.json" "$APP_DIR/app/config/pricing_active.json"; fi
if [[ ! -d "$APP_DIR/app/embedded_dxfs" && -d "$STAGE/app/embedded_dxfs" ]]; then sudo cp -a "$STAGE/app/embedded_dxfs" "$APP_DIR/app/embedded_dxfs"; fi
if [[ ! -f "$APP_DIR/app/embedded_dxfs_manifest.json" && -f "$STAGE/app/embedded_dxfs_manifest.json" ]]; then sudo cp -a "$STAGE/app/embedded_dxfs_manifest.json" "$APP_DIR/app/embedded_dxfs_manifest.json"; fi

sudo rsync -a --delete "$STAGE/" "$APP_DIR/" \
  --exclude 'app/jobs/' \
  --exclude 'app/requests/' \
  --exclude 'app/queue/' \
  --exclude 'app/archive/' \
  --exclude 'app/backups/' \
  --exclude 'app/drafts/' \
  --exclude 'app/system/' \
  --exclude 'app/decor_media/' \
  --exclude 'app/material_library.json' \
  --exclude 'app/config/pricing_active.json' \
  --exclude 'app/config/pricing_versions/' \
  --exclude 'app/config/pricing_audit.jsonl' \
  --exclude 'app/embedded_dxfs/' \
  --exclude 'app/embedded_dxfs_manifest.json' \
  --exclude '.production-preflight.env'

sudo chmod +x "$APP_DIR/DEPLOY_FIX660.sh" "$APP_DIR/INSTALL_FIX660R4_FROM_STAGE.sh" "$APP_DIR"/tools/*.py
sudo env \
  PUBLIC_ORIGIN="$PUBLIC_ORIGIN" \
  ADMIN_ORIGIN="$ADMIN_ORIGIN" \
  ADMIN_CREDENTIALS_FILE="$CREDS_FILE" \
  METOD_PAX_APP_DIR="$APP_DIR" \
  bash "$APP_DIR/DEPLOY_FIX660.sh"

# Final smoke: same URL and same port, new build marker.
# IMPORTANT: never pipe curl into `grep -q` while `pipefail` is active. `grep -q`
# may exit as soon as it finds the marker, which closes the pipe while curl is
# still writing and makes curl return 23 (CURLE_WRITE_ERROR). Download fully
# first, then inspect the completed response.
SMOKE_BACKEND="$(mktemp /tmp/metod_fix660_backend_smoke_XXXXXX.html)"
SMOKE_PROXY="$(mktemp /tmp/metod_fix660_proxy_smoke_XXXXXX.html)"
curl -fsS "http://127.0.0.1:8792/toolA.html?v=660r3" -o "$SMOKE_BACKEND"
grep -Fq 'FIX660_GRAIN_STUDIO' "$SMOKE_BACKEND"
curl -fsS -H 'Host: 51.195.102.180:8790' "http://127.0.0.1:8790/toolA.html?v=660r3" -o "$SMOKE_PROXY"
grep -Fq 'FIX660_GRAIN_STUDIO' "$SMOKE_PROXY"
rm -f "$SMOKE_BACKEND" "$SMOKE_PROXY"
sudo systemctl is-active --quiet metod-pax.service
sudo nginx -t

SUCCESS=1
info "FIX660 ACTIEF en alle checks groen. (FIX660R4 installer; mobile drawer + bottom-up stack)"
info "Tool A ONGEWIJZIGD: http://51.195.102.180:8790/"
info "Admin ONGEWIJZIGD:  http://51.195.102.180:8790/admin/"
info "Appbackup: $APP_BACKUP"
info "Configbackup: $CONFIG_TAR"
