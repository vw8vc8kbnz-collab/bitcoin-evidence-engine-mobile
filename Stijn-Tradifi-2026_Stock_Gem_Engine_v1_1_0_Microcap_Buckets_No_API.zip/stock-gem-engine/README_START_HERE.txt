Stijn-Tradifi-2026 Stock Gem Engine v1.1.0

No-API safe mode. Microcap-first dashboard with market-cap buckets, sector filter and company website links.
Install/update with scripts/install_or_update.sh.
