#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="FIX657R2"
APP_DIR="${METOD_PAX_APP_DIR:-/opt/adzaagt/metod-pax}"
ENV_DIR="${METOD_PAX_ENV_DIR:-/etc/adzaagt/metod-pax}"
ENV_FILE="$ENV_DIR/metod-pax.env"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-$ENV_DIR/admin_credentials.live.json}"
SERVICE_FILE="/etc/systemd/system/metod-pax.service"
NGINX_SITE="/etc/nginx/sites-available/metod-pax-8790"
NGINX_LINK="/etc/nginx/sites-enabled/metod-pax-8790"
BACKUP_ROOT="${METOD_CONFIG_BACKUP_ROOT:-/var/backups/metod-pax}"
PUBLIC_ORIGIN="${PUBLIC_ORIGIN:-http://51.195.102.180:8790}"
ADMIN_ORIGIN="${ADMIN_ORIGIN:-${PUBLIC_ORIGIN}}"

fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }
info(){ echo "[$VERSION] $*"; }

[[ "$EUID" -eq 0 ]] || fail "Voer DEPLOY_FIX657R2.sh met sudo/root uit."
for cmd in python3 nginx systemctl curl grep sha256sum; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
[[ -d "$APP_DIR/app" ]] || fail "APP_DIR ontbreekt: $APP_DIR"
[[ -f "$CREDS_FILE" && -r "$CREDS_FILE" ]] || fail "Bestaande hash-only Admin credentials ontbreken: $CREDS_FILE"

# This release deliberately preserves the already-live URL. The bridge is exact,
# not a generic permission to run production on arbitrary HTTP origins.
readarray -t ORIGIN_INFO < <(python3 - "$PUBLIC_ORIGIN" "$ADMIN_ORIGIN" <<'PY'
import sys
from urllib.parse import urlparse
expected='http://51.195.102.180:8790'
for label, raw in [('PUBLIC_ORIGIN',sys.argv[1]),('ADMIN_ORIGIN',sys.argv[2])]:
    u=urlparse(raw)
    if raw != expected or u.scheme.lower()!='http' or u.hostname!='51.195.102.180' or u.port!=8790:
        raise SystemExit(f'{label} moet voor FIX657R2 exact {expected} zijn, gevonden {raw!r}')
    if u.username or u.password or u.query or u.fragment or u.path not in ('','/') or '*' in raw:
        raise SystemExit(f'{label} is structureel ongeldig: {raw!r}')
print(expected)
print(expected)
PY
) || fail "Ongeldige legacy HTTP origin"
PUBLIC_ORIGIN="${ORIGIN_INFO[0]}"
ADMIN_ORIGIN="${ORIGIN_INFO[1]}"

# Credentials must remain private and hash-only before any config/service change.
python3 - "$CREDS_FILE" "$APP_DIR" <<'PY'
import json, os, sys
from pathlib import Path
p=Path(sys.argv[1]); app=Path(sys.argv[2]).resolve(); rp=p.resolve()
if rp==app or app in rp.parents: raise SystemExit('Admin credentials mogen niet in APP_DIR staan')
obj=json.loads(p.read_text(encoding='utf-8'))
h=str(obj.get('password_hash') or '')
if not h.startswith('pbkdf2_sha256$') or str(obj.get('password') or '').strip():
    raise SystemExit('Admin credentials moeten hash-only PBKDF2-SHA256 zijn')
if os.name!='nt' and (p.stat().st_mode & 0o777)!=0o600:
    raise SystemExit(f'Admin credentials permissies moeten 0600 zijn, nu {oct(p.stat().st_mode & 0o777)}')
print('Admin credentials contract OK.')
PY

TS="$(date +%Y%m%d_%H%M%S)"
CFG_BACKUP="$BACKUP_ROOT/${VERSION}_$TS"
mkdir -p "$CFG_BACKUP" "$ENV_DIR"
for f in "$ENV_FILE" "$SERVICE_FILE" "$NGINX_SITE" \
         /etc/nginx/sites-available/metod-pax-https /etc/nginx/sites-enabled/metod-pax-https \
         /etc/nginx/sites-available/metod-pax-acme-ip /etc/nginx/sites-enabled/metod-pax-acme-ip \
         /etc/systemd/system/metod-pax-certbot-renew.service /etc/systemd/system/metod-pax-certbot-renew.timer; do
  if [[ -e "$f" || -L "$f" ]]; then cp -a --no-dereference "$f" "$CFG_BACKUP/$(echo "$f" | sed 's#/#__#g')" 2>/dev/null || true; fi
done
info "Externe configbackup: $CFG_BACKUP"

# Preserve the four Admin business-cost values exactly. The website CSV sheet amount
# remains the direct gross price; no general material factor may be active.
python3 - "$APP_DIR/app/config/pricing_active.json" <<'PY'
import json, os, sys
p=sys.argv[1]
try: obj=json.load(open(p,encoding='utf-8'))
except Exception: obj={}
if not isinstance(obj,dict): obj={}
sp=obj.get('sellPricing') if isinstance(obj.get('sellPricing'),dict) else {}
sp.pop('sheetPriceFactor',None)
for key,default in (('edgeBandPricePerM',4.5),('cncCostPerSheet',0.0),('drawingCostFixed',0.0),('transportCostFixed',0.0)):
    try: sp[key]=float(sp[key]) if key in sp and sp[key] is not None else float(default)
    except Exception: sp[key]=float(default)
obj['sellPricing']=sp
obj['pricingModel']='catalog_sell_price_incl_vat_v2'
tmp=p+'.fix657r2.tmp'
with open(tmp,'w',encoding='utf-8') as f:
    json.dump(obj,f,ensure_ascii=False,indent=2); f.flush(); os.fsync(f.fileno())
os.replace(tmp,p)
print('Pricingcontract: plaat=CSV incl. BTW; overige Admin-kosten excl. BTW.')
PY

# Keep the existing published CSV catalog; quarantine only legacy/non-CSV active records.
mkdir -p "$APP_DIR/app/system/catalog_legacy_archive" "$APP_DIR/app/system/catalog_imports/history" "$APP_DIR/app/decor_media" "$APP_DIR/app/backups"
python3 "$APP_DIR/tools/fix652_catalog_only_migrate.py" \
  --library "$APP_DIR/app/material_library.json" \
  --archive-dir "$APP_DIR/app/system/catalog_legacy_archive" \
  --registry "$APP_DIR/app/system/catalog_public_ids.json"
python3 "$APP_DIR/tools/fix654_prepare_catalog_media.py" --app-dir "$APP_DIR/app" || true

# Production application controls stay enabled. LEGACY_HTTP_COMPAT is deliberately
# pinned to the one existing reverse-proxy origin and can later be removed in a
# separate HTTPS migration without touching pricing/optimizer/business logic.
ENV_TMP="$ENV_FILE.tmp.$TS"
cat > "$ENV_TMP" <<EOF2
METOD_PORT=8792
PRODUCTION_HARDENING=1
ADMIN_HASH_ONLY=1
APP_ENV=production
ADMIN_CREDENTIALS_FILE=$CREDS_FILE
ADMIN_STAGING_OPEN=0
LEGACY_HTTP_COMPAT=1
LEGACY_HTTP_ORIGIN=$PUBLIC_ORIGIN
TRUSTED_PROXY_IPS=127.0.0.1,::1
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
PUBLIC_JSON_MAX_BYTES=16777216
SUBMIT_MAX_BYTES=8388608
PUBLIC_DXF_BLOB_MAX_BYTES=2097152
PUBLIC_JOB_TOTAL_QTY_LIMIT=250
PUBLIC_JOB_MAX_AREA_LB=250
JOB_OUTPUT_MAX_BYTES=536870912
CATALOG_IMAGE_WORKERS=4
ALLOWED_ORIGINS=$PUBLIC_ORIGIN
ALLOWED_ADMIN_ORIGINS=$ADMIN_ORIGIN
EOF2
chmod 0640 "$ENV_TMP"
mv "$ENV_TMP" "$ENV_FILE"

cat > "$SERVICE_FILE" <<EOF2
[Unit]
Description=METOD PAX Tool FIX657R2
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR/app
EnvironmentFile=$ENV_FILE
ExecStart=/usr/bin/python3 $APP_DIR/app/server_py.py
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
UMask=0027

[Install]
WantedBy=multi-user.target
EOF2

# Preserve the established public contract: http://51.195.102.180:8790/ -> 127.0.0.1:8792.
cat > "$NGINX_SITE" <<'EOF2'
server {
    listen 8790;
    listen [::]:8790;
    server_name 51.195.102.180 _;

    client_max_body_size 20m;

    location / {
        proxy_pass http://127.0.0.1:8792;
        proxy_http_version 1.1;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto http;
        proxy_set_header X-Forwarded-Host $http_host;
        proxy_set_header X-Forwarded-Port 8790;
        proxy_connect_timeout 30s;
        proxy_send_timeout 1800s;
        proxy_read_timeout 1800s;
        proxy_buffering off;
    }
}
EOF2
ln -sfn "$NGINX_SITE" "$NGINX_LINK"

# Clean only the FIX657R1-specific TLS bootstrap units/sites that may have been left
# behind by the aborted attempt. Certificates/Certbot files are not destructively removed.
systemctl disable --now metod-pax-certbot-renew.timer >/dev/null 2>&1 || true
rm -f /etc/systemd/system/metod-pax-certbot-renew.timer /etc/systemd/system/metod-pax-certbot-renew.service
rm -f /etc/nginx/sites-enabled/metod-pax-https /etc/nginx/sites-available/metod-pax-https
rm -f /etc/nginx/sites-enabled/metod-pax-acme-ip /etc/nginx/sites-available/metod-pax-acme-ip

# Release integrity/static contracts before restart.
python3 -m py_compile "$APP_DIR"/app/*.py "$APP_DIR"/tools/*.py
bash -n "$APP_DIR/DEPLOY_FIX657R2.sh"
python3 "$APP_DIR/tools/fix657r2_regression.py"
APP_DIR="$APP_DIR" METOD_ENV_FILE="$ENV_FILE" python3 "$APP_DIR/tools/final_preflight.py"
nginx -t

systemctl daemon-reload
systemctl enable metod-pax.service >/dev/null
systemctl restart metod-pax.service
systemctl reload nginx
sleep 2
systemctl is-active --quiet metod-pax.service || { journalctl -u metod-pax.service -n 100 --no-pager >&2; fail "metod-pax.service startte niet"; }

TMP_HTML="$(mktemp)"; TMP_LIB="$(mktemp)"; TMP_HDR="$(mktemp)"; TMP_BAD="$(mktemp)"
trap 'rm -f "$TMP_HTML" "$TMP_LIB" "$TMP_HDR" "$TMP_BAD"' EXIT
curl -fsS http://127.0.0.1:8792/toolA.html?v=657r2 -o "$TMP_HTML"
curl -fsS --compressed http://127.0.0.1:8792/api/materials/library -o "$TMP_LIB"
grep -Fq 'FIX657R2_HTTP8790_STABLE_VAT_TRUTH' "$TMP_HTML"
grep -Fq 'decor_library.js?v=657r2' "$TMP_HTML"
python3 - "$TMP_LIB" "$APP_DIR/app/material_library.json" <<'PY'
import json,re,sys
pub=json.load(open(sys.argv[1],encoding='utf-8')); internal=json.load(open(sys.argv[2],encoding='utf-8'))
assert pub.get('ok') is True
records=pub.get('records') or []; active=internal.get('records') or []
assert internal.get('source')=='CSV_CATALOG_ONLY'
assert len(records)==len(active),(len(records),len(active))
allowed={'publicMaterialId','publicName','brand','decorType','visualFamily','visualTags','colorGroup','searchTags','thicknessMm','sheetSizeMm','hasGrain','grainDefaultOn','active','published','isPopular','isNew','imageAvailable','imageThumbUrl','imagePreviewUrl'}
for r in records:
    assert set(r).issubset(allowed), set(r)-allowed
    assert re.fullmatch(r'decor_[a-f0-9]{20,40}',str(r.get('publicMaterialId') or ''))
    assert float(r.get('thicknessMm') or 0) in (18.0,19.0,20.0)
forbidden={'articleNumber','articleNo','materialCode','purchasePrice','purchasePricePerSheet','supplier','supplierName','leverancier','imageSourceUrl','imageSourceUrls','sellPriceInclVatPerSheet','sellPriceExVatPerSheet'}
assert not any(forbidden.intersection(r) for r in records)
print(f'Publieke library privacy OK: {len(records)} records.')
PY

# Public reverse-proxy smoke on the unchanged URL/port.
curl -fsS -H 'Host: 51.195.102.180:8790' http://127.0.0.1:8790/toolA.html?v=657r2 -o /dev/null
curl -fsS -H 'Host: 51.195.102.180:8790' http://127.0.0.1:8790/api/materials/library -o /dev/null
curl -sS -D "$TMP_HDR" -o /dev/null \
  -H 'Host: 51.195.102.180:8790' -H 'Origin: http://51.195.102.180:8790' \
  http://127.0.0.1:8790/api/materials/library
grep -Fiq 'Access-Control-Allow-Origin: http://51.195.102.180:8790' "$TMP_HDR"
curl -sS -D "$TMP_BAD" -o /dev/null \
  -H 'Host: 51.195.102.180:8790' -H 'Origin: http://attacker.invalid:8790' \
  http://127.0.0.1:8790/api/materials/library
if grep -Fiq 'Access-Control-Allow-Origin: http://attacker.invalid:8790' "$TMP_BAD"; then
  fail "Onveilige Origin werd gereflecteerd"
fi

info "ACTIEF en FIX657R2 preflight geslaagd."
info "Tool A blijft: $PUBLIC_ORIGIN/"
info "Admin blijft:  $ADMIN_ORIGIN/admin/"
info "LET OP: HTTP is bewust tijdelijk behouden; TLS-migratie is een aparte toekomstige release."
