#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="FIX657R2"
STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${METOD_PAX_APP_DIR:-/opt/adzaagt/metod-pax}"
PUBLIC_ORIGIN="${PUBLIC_ORIGIN:-http://51.195.102.180:8790}"
ADMIN_ORIGIN="${ADMIN_ORIGIN:-${PUBLIC_ORIGIN}}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-/etc/adzaagt/metod-pax/admin_credentials.live.json}"
TS="$(date +%Y%m%d_%H%M%S)"
LOG="/tmp/METOD_PAX_FIX657R2_DEPLOY_${TS}.log"
APP_BACKUP="${APP_DIR}_backup_before_FIX657R2_${TS}"
CONFIG_TAR="/var/backups/metod-pax/FIX657R2_outer_config_${TS}.tar"
HAD_APP=0
LIVE_TOUCHED=0
SUCCESS=0

info(){ echo "[$VERSION] $*"; }
fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }

rollback(){
  local rc=$?
  if [[ "$SUCCESS" -eq 1 ]]; then
    info "Deploy succesvol. Log: $LOG"
    return 0
  fi
  echo "[$VERSION] INSTALLATIE MISLUKT (code $rc). Log: $LOG" >&2
  echo "[$VERSION] Staging blijft voor diagnose: $STAGE" >&2
  if [[ "$LIVE_TOUCHED" -eq 1 ]]; then
    echo "[$VERSION] Automatische app/config-rollback wordt uitgevoerd..." >&2
    set +e
    if [[ "$HAD_APP" -eq 1 && -d "$APP_BACKUP" ]]; then
      sudo rm -rf "$APP_DIR"
      sudo cp -a "$APP_BACKUP" "$APP_DIR"
    elif [[ "$HAD_APP" -eq 0 ]]; then
      sudo rm -rf "$APP_DIR"
    fi
    if [[ -f "$CONFIG_TAR" ]]; then
      sudo rm -rf /etc/adzaagt/metod-pax
      sudo rm -f /etc/systemd/system/metod-pax.service
      sudo rm -f /etc/systemd/system/metod-pax-certbot-renew.service /etc/systemd/system/metod-pax-certbot-renew.timer
      sudo rm -f /etc/systemd/system/timers.target.wants/metod-pax-certbot-renew.timer
      sudo rm -f /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790
      sudo rm -f /etc/nginx/sites-available/metod-pax-https /etc/nginx/sites-enabled/metod-pax-https
      sudo rm -f /etc/nginx/sites-available/metod-pax-acme-ip /etc/nginx/sites-enabled/metod-pax-acme-ip
      sudo tar -xpf "$CONFIG_TAR" -C /
    fi
    sudo systemctl daemon-reload || true
    if sudo nginx -t; then sudo systemctl reload nginx || true; fi
    if [[ -f /etc/systemd/system/metod-pax.service ]]; then sudo systemctl restart metod-pax.service || true; fi
    if [[ -e /etc/systemd/system/timers.target.wants/metod-pax-certbot-renew.timer ]]; then sudo systemctl start metod-pax-certbot-renew.timer || true; fi
    echo "[$VERSION] Rollbackpoging afgerond." >&2
    set -e
  fi
  return "$rc"
}
trap rollback EXIT
exec > >(tee -a "$LOG") 2>&1

[[ "$PUBLIC_ORIGIN" == 'http://51.195.102.180:8790' ]] || fail "PUBLIC_ORIGIN moet voor deze compatibility release exact http://51.195.102.180:8790 zijn"
[[ "$ADMIN_ORIGIN" == "$PUBLIC_ORIGIN" ]] || fail "ADMIN_ORIGIN moet gelijk zijn aan PUBLIC_ORIGIN"
[[ -f "$CREDS_FILE" ]] || fail "Bestaande externe Admin credentials ontbreken: $CREDS_FILE"
for cmd in rsync python3 sha256sum grep tar curl nginx systemctl; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
sudo -v

# Prove the existing golden service is healthy before touching anything.
if [[ -d "$APP_DIR/app" ]]; then
  sudo systemctl is-active --quiet metod-pax.service || fail "Bestaande metod-pax.service is vóór deploy niet actief"
  curl -fsS http://127.0.0.1:8790/ -o /dev/null || fail "Bestaande Tool A op :8790 geeft vóór deploy geen HTTP succes"
  curl -fsS http://127.0.0.1:8792/api/materials/library -o /dev/null || fail "Bestaande backend :8792 is vóór deploy niet gezond"
  info "Bestaande FIX656/FIX65x runtime gezond op :8790 -> :8792."
fi

# Extracted release integrity and clean-tree contracts.
(cd "$STAGE" && sha256sum -c SHA256SUMS.txt >/dev/null)
python3 - "$STAGE" <<'PY'
from pathlib import Path
import json,sys
root=Path(sys.argv[1])
bad=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and ('__pycache__' in p.parts or p.suffix.lower() in {'.pyc','.bak','.csv'})]
if bad: raise SystemExit(f'Onschone staged release: {bad[:20]}')
lib=json.loads((root/'app/material_library.json').read_text(encoding='utf-8'))
assert lib.get('source')=='CSV_CATALOG_ONLY' and lib.get('records')==[]
assert lib.get('pricingModel')=='catalog_sell_price_incl_vat_v2'
print('Release integrity/CSV-only seed/pricing-v2: OK')
PY

# All application regressions run before live files are touched.
python3 -m py_compile "$STAGE"/app/*.py "$STAGE"/tools/*.py
bash -n "$STAGE/DEPLOY_FIX657R2.sh"
bash -n "$STAGE/INSTALL_FIX657R2_FROM_STAGE.sh"
if command -v node >/dev/null; then for f in "$STAGE"/app/*.js; do node --check "$f" >/dev/null; done; fi
python3 "$STAGE/tools/fix657r2_regression.py"

PREFLIGHT_ENV="$STAGE/.production-preflight.env"
cat > "$PREFLIGHT_ENV" <<EOF2
APP_ENV=production
PRODUCTION_HARDENING=1
ADMIN_HASH_ONLY=1
ADMIN_STAGING_OPEN=0
ADMIN_CREDENTIALS_FILE=$CREDS_FILE
LEGACY_HTTP_COMPAT=1
LEGACY_HTTP_ORIGIN=$PUBLIC_ORIGIN
TRUSTED_PROXY_IPS=127.0.0.1,::1
ALLOWED_ORIGINS=$PUBLIC_ORIGIN
ALLOWED_ADMIN_ORIGINS=$ADMIN_ORIGIN
PUBLIC_JSON_MAX_BYTES=16777216
SUBMIT_MAX_BYTES=8388608
PUBLIC_DXF_BLOB_MAX_BYTES=2097152
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
EOF2
APP_DIR="$STAGE" METOD_ENV_FILE="$PREFLIGHT_ENV" python3 "$STAGE/tools/final_preflight.py"
rm -f "$PREFLIGHT_ENV"
info "FIX657R2 preflight groen. Nu pas live backup/switch."

if [[ -d "$APP_DIR/app" ]]; then
  HAD_APP=1
  sudo cp -a "$APP_DIR" "$APP_BACKUP"
  info "Volledige appbackup: $APP_BACKUP"
fi
sudo mkdir -p "$(dirname "$CONFIG_TAR")"
TAR_INPUTS=()
for f in /etc/adzaagt/metod-pax /etc/systemd/system/metod-pax.service \
         /etc/systemd/system/metod-pax-certbot-renew.service /etc/systemd/system/metod-pax-certbot-renew.timer \
         /etc/systemd/system/timers.target.wants/metod-pax-certbot-renew.timer \
         /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790 \
         /etc/nginx/sites-available/metod-pax-https /etc/nginx/sites-enabled/metod-pax-https \
         /etc/nginx/sites-available/metod-pax-acme-ip /etc/nginx/sites-enabled/metod-pax-acme-ip; do
  [[ -e "$f" || -L "$f" ]] && TAR_INPUTS+=("${f#/}")
done
if ((${#TAR_INPUTS[@]})); then
  sudo tar -cpf "$CONFIG_TAR" -C / "${TAR_INPUTS[@]}"
else
  sudo tar -cpf "$CONFIG_TAR" --files-from /dev/null
fi
info "Externe configbackup: $CONFIG_TAR"
LIVE_TOUCHED=1

sudo mkdir -p "$APP_DIR/app/jobs" "$APP_DIR/app/requests" "$APP_DIR/app/queue" "$APP_DIR/app/archive" \
  "$APP_DIR/app/backups" "$APP_DIR/app/drafts" "$APP_DIR/app/system" "$APP_DIR/app/decor_media" "$APP_DIR/app/config"

# Existing live state always wins; release seeds are only for a truly fresh install.
if [[ ! -f "$APP_DIR/app/material_library.json" ]]; then sudo install -m 0640 "$STAGE/app/material_library.json" "$APP_DIR/app/material_library.json"; fi
if [[ ! -f "$APP_DIR/app/config/pricing_active.json" ]]; then sudo install -m 0640 "$STAGE/app/config/pricing_active.json" "$APP_DIR/app/config/pricing_active.json"; fi
if [[ ! -d "$APP_DIR/app/embedded_dxfs" && -d "$STAGE/app/embedded_dxfs" ]]; then sudo cp -a "$STAGE/app/embedded_dxfs" "$APP_DIR/app/embedded_dxfs"; fi
if [[ ! -f "$APP_DIR/app/embedded_dxfs_manifest.json" && -f "$STAGE/app/embedded_dxfs_manifest.json" ]]; then sudo cp -a "$STAGE/app/embedded_dxfs_manifest.json" "$APP_DIR/app/embedded_dxfs_manifest.json"; fi

sudo rsync -a --delete "$STAGE/" "$APP_DIR/" \
  --exclude 'app/jobs/' \
  --exclude 'app/requests/' \
  --exclude 'app/queue/' \
  --exclude 'app/archive/' \
  --exclude 'app/backups/' \
  --exclude 'app/drafts/' \
  --exclude 'app/system/' \
  --exclude 'app/decor_media/' \
  --exclude 'app/material_library.json' \
  --exclude 'app/config/pricing_active.json' \
  --exclude 'app/config/pricing_versions/' \
  --exclude 'app/config/pricing_audit.jsonl' \
  --exclude 'app/embedded_dxfs/' \
  --exclude 'app/embedded_dxfs_manifest.json' \
  --exclude '.production-preflight.env'

sudo chmod +x "$APP_DIR/DEPLOY_FIX657R2.sh" "$APP_DIR/INSTALL_FIX657R2_FROM_STAGE.sh" "$APP_DIR"/tools/*.py
sudo env \
  PUBLIC_ORIGIN="$PUBLIC_ORIGIN" \
  ADMIN_ORIGIN="$ADMIN_ORIGIN" \
  ADMIN_CREDENTIALS_FILE="$CREDS_FILE" \
  METOD_PAX_APP_DIR="$APP_DIR" \
  bash "$APP_DIR/DEPLOY_FIX657R2.sh"

# Final smoke: same URL and same port, new build marker.
curl -fsS "http://127.0.0.1:8792/toolA.html?v=657r2" | grep -Fq 'FIX657R2_HTTP8790_STABLE_VAT_TRUTH'
curl -fsS -H 'Host: 51.195.102.180:8790' "http://127.0.0.1:8790/toolA.html?v=657r2" | grep -Fq 'FIX657R2_HTTP8790_STABLE_VAT_TRUTH'
sudo systemctl is-active --quiet metod-pax.service
sudo nginx -t

SUCCESS=1
info "FIX657R2 ACTIEF en alle checks groen."
info "Tool A ONGEWIJZIGD: http://51.195.102.180:8790/"
info "Admin ONGEWIJZIGD:  http://51.195.102.180:8790/admin/"
info "Appbackup: $APP_BACKUP"
info "Configbackup: $CONFIG_TAR"
