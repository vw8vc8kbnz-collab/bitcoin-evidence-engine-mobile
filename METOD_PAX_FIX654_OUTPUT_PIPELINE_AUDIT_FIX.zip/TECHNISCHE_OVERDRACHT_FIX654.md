# Technische overdracht — METOD/PAX FIX654

## Release
`FIX654_OUTPUT_PIPELINE_AUDIT`

Basis is FIX653. Deze release herstelt de productie-outputketen en maakt completion expliciet.

## Kerncontract jobfinalisatie
Een optimizerproces met exitcode 0 is niet meer automatisch een afgeronde Tool A-job.
Per materiaal-subjob voert `_finalize_subjob_outputs(job_root)` nu uit:

1. valideer `placements.json`, `report.json`, `quote.json`;
2. `_generate_labels_json`;
3. `_generate_stickertool_json`;
4. `_rename_sheet_dxfs`;
5. `_build_admin_dxf_exports`;
6. `_write_human_calculation_summary`;
7. valideer sheet-DXF/StickerTool/summary;
8. atomisch `output/finalization.json = COMPLETE|ERROR`.

Een ERROR wordt doorgegeven aan de async runner en mag nooit als eindeloos PROCESSING eindigen.

## Opaque subjobs
Publieke subjob-ID's blijven `<parent>__mat_001`, etc. `001` is uitsluitend een index.
`_job_material_context()` resolveert intern materiaal uit `input/panels.csv`. Gebruik nooit meer
`split('__mat_')[-1]` als materialCode.

## Parent/Admin-linkage
`_create_job_from_payload()` retourneert subjobs en schrijft `parent/output/links.json`.
`_start_async_job_create()` bewaart na succes die lijst in `REQUESTS/<parent>/status.json -> job`.
`_build_request_file_manifest()` heeft recovery via links.json en daarna filesystem glob, zodat
ook oudere jobs zonder status.subjobs waar mogelijk opnieuw zichtbaar worden.

## Admin outputs
Productie-output per subjob:
- `output/DXF_Zaagplaten/*.dxf`
- `output/DXF_Onderdelen/*.dxf`
- `output/stickers.json`
- `output/stickertool.json`
- `output/labels.json`
- `output/placements.json`
- `output/report.json`
- `output/quote.json`
- `output/calculation_summary.txt`
- `output/finalization.json`

Productie-output is Admin-only. Publieke jobtokens mogen alleen de gesanitized quote lezen.

## Tool A polling
`pollJob()` heeft nu:
- initieel 1% i.p.v. 0%;
- serverprogress als bron;
- status-outage watchdog van 2 minuten;
- totale client-wachtguard van 30 minuten;
- na 90 seconden zonder progress een duidelijke 'duurt langer' melding;
- server ERROR wordt direct als fout getoond.

## Overzicht
`renderOverviewSafe()` is de primaire wrapper. Hij:
- normaliseert state;
- probeert de bestaande volledige renderer;
- controleert of er werkelijk tabs/inhoud zijn bij aanwezige panelen;
- reset zo nodig naar `overviewTab='all'`;
- gebruikt `renderOverviewSimple()` als fallback;
- laat nooit bewust een lege witte modal achter.

## Library performance
`decor_library.js`:
- cachet een genormaliseerde zoek/filterindex;
- chunkgrootte 32;
- volgende chunks worden geappend i.p.v. volledige grid-rerender;
- één delegated click handler op de grid;
- `content-visibility:auto` voor cards;
- selectopties worden alleen bij gewijzigde signature vernieuwd.

## Catalog images vóór publicatie
Nieuwe CSV-preview reserveert private opaque IDs en bepaalt `imageTargets`.
Image sync draait tegen private staging:
`system/catalog_imports/<importId>_media/<publicMaterialId>/...`

Publiceren is geblokkeerd zolang required image staging niet `DONE` + zero failures is.
Na succesvolle voorbereiding worden media atomisch naar `decor_media/<publicMaterialId>` gepromoveerd,
pas daarna wordt de nieuwe catalogus actief.

`catalog_importer.atomic_write_cached_image()` maakt indien Pillow beschikbaar:
- `catalog.img` sanitized source
- `thumb.webp` max 720x540
- `preview.webp` max 1600x1200
- `catalog.meta.json`

Pillow is optioneel; raw local cache is fallback. `tools/fix654_prepare_catalog_media.py` bouwt bij
deploy varianten uit bestaande lokale cache zonder nieuwe internetdownloads.

## Pricing auditfix
De algemene materiaalfactor blijft verwijderd. CSV directe verkoopprijs blijft bron.
FIX654 corrigeert twee subtiele zaken:
1. Admin-waarde `0` voor CNC/tekenen/transport wordt niet meer door `or DEFAULT` vervangen.
2. De CSV prijs incl. BTW wordt voor materiaal incl. BTW exact behouden; totalen worden niet opnieuw
   uit een tweedecimaal afgeronde ex-BTW materiaalregel gereconstrueerd.

## Niet wijzigen zonder nieuwe audit
- publicMaterialId privacyboundary;
- CSV-only actieve library;
- 18/19/20 whitelist;
- productie-output Admin-only;
- explicit finalization contract;
- live data exclusions in deployment;
- FIX644/FIX645 Step2 keyboardgedrag;
- FIX648/FIX650 mobiele nerf-presentatie.

## VPS acceptatie na deploy
Test minimaal:
1. bestaand materiaal selecteren en Overzicht openen: rijen zichtbaar;
2. prijs berekenen: overlay verlaat startfase en eindigt op 100%;
3. Admin aanvraag openen: materiaal-subjob zichtbaar;
4. DXF-zaagplaten download zichtbaar;
5. StickerTool JSON zichtbaar en bevat items;
6. Tool A zoeken/filteren en ver naar beneden scrollen;
7. nieuwe CSV alleen 'controleren': image-prep loopt, publiceren blijft disabled tot klaar;
8. artikelnummer nergens in publieke browser/API zichtbaar.
