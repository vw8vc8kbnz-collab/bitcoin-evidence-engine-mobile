from __future__ import annotations
from fastapi import APIRouter
import asyncio
import math
import json
from app.db.database import db
from app.services.sync_service import SyncService
from app.services.data_foundation_service import DataFoundationService
from app.services.audit_service import AuditService
from app.services.forecast_service import ForecastService
from app.services.health_service import HealthService
from app.services.time_machine_service import TimeMachineService
from app.services.evidence_attribution_service import EvidenceAttributionService
from app.services.time_machine_learning_service import TimeMachineLearningService
from app.services.native_core_service import NativeCoreService
from app.services.historical_memory_service import HistoricalMemoryService
from app.services.seed_export_service import SeedExportService
from app.services.time_machine_export_service import TimeMachineExportService
from app.core.logger import log
from app.core.config import settings
from app.core.runtime_locks import sync_lock, tm_priority_event
from app.core.debug import append_jsonl
from pathlib import Path
from fastapi.responses import FileResponse


def _clean_for_json(obj):
    """FastAPI refuses NaN/Inf values. DuckDB/Pandas can return them when some
    evidence layers are still empty. Convert all non-finite floats to None so
    the dashboard never collapses into API error while sync is running.
    """
    if obj is None:
        return None
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, int) or isinstance(obj, bool) or isinstance(obj, str):
        return obj
    if isinstance(obj, dict):
        return {str(k): _clean_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean_for_json(v) for v in obj]
    try:
        # pandas Timestamp / numpy scalars / datetime objects
        if hasattr(obj, "isoformat"):
            return obj.isoformat()
        if hasattr(obj, "item"):
            return _clean_for_json(obj.item())
    except Exception:
        pass
    return str(obj)


def _safe_df(sql: str, params=None):
    try:
        return db.df(sql, params or []).to_dict('records')
    except Exception as exc:
        log.exception("Dashboard query failed: %s", exc)
        return []


def _safe_one(sql: str, params=None):
    try:
        return db.fetchone(sql, params or [])
    except Exception as exc:
        log.exception("Dashboard scalar query failed: %s", exc)
        return None

router = APIRouter(prefix="/api")

@router.get("/dashboard/status")
def dashboard_status():
    """Fast, lightweight dashboard status.

    This endpoint avoids heavy archive/model queries so the frontend can always
    keep price/sync/integrity visible even while the full dashboard is being
    refreshed or sync is active.
    """
    try:
        foundation = DataFoundationService()
        readiness = foundation.readiness()
        integrity = foundation.data_integrity(record_state=False)
        ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
        latest_candle = _safe_one("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
        latest_feature = _safe_df("""
            SELECT timestamp_ms, close, regime, data_completeness, funding_rate, open_interest_value,
                   open_interest_change_24h, long_short_ratio, taker_buy_sell_ratio, orderbook_imbalance,
                   orderbook_spread, taker_delta_ratio, futures_basis_premium_pct, top_position_long_short_ratio,
                   top_account_long_short_ratio, cross_exchange_spread_pct, spot_premium_kraken_pct,
                   spot_premium_coinbase_pct, coinmetrics_mvrv, fear_greed, drawdown_from_ath, cycle_progress,
                   volume_zscore, volume_ratio_24, range_pct, candle_body_pct
            FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
        """)
        sync_state = _safe_df("SELECT key, value, updated_at FROM sync_state")
        price = ticker_price or (latest_candle if latest_candle else None)
        return _clean_for_json({
            "api_status": "busy" if sync_lock.locked() else "ok",
            "btc_price": float(price[0]) if price and price[0] is not None else None,
            "latest_feature": latest_feature[0] if latest_feature else None,
            "sync_state": sync_state,
            "readiness": readiness,
            "data_integrity": integrity,
            "sync_busy": sync_lock.locked(),
        })
    except Exception as exc:
        log.exception("Dashboard status failed: %s", exc)
        return _clean_for_json({"api_status":"error", "error":str(exc), "sync_state": _safe_df("SELECT key, value, updated_at FROM sync_state")})

@router.get("/dashboard")
def dashboard():
    try:
        # If a sync owns the pipeline, return a lightweight but useful payload.
        # Keep cached/visible price + sync state instead of forcing the frontend
        # into a red timeout/error state.
        if sync_lock.locked():
            status = dashboard_status()
            if isinstance(status, dict):
                status.setdefault("latest_items", [])
                status.setdefault("data_health", HealthService().list())
                status["message"] = "sync/forecast busy; lightweight status returned"
                return _clean_for_json(status)
        latest_run = _safe_one("SELECT run_id FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1")
        latest_items=[]
        if latest_run:
            latest_items = _safe_df("""
                SELECT * FROM forecast_items WHERE run_id=?
                ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
            """, [latest_run[0]])
        runs = _safe_df("SELECT * FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 25")
        archive = _safe_df("SELECT * FROM forecast_items ORDER BY run_id DESC, due_at_ms ASC LIMIT 150")
        acc = _safe_df("""
            SELECT horizon, COUNT(*) AS total, SUM(CASE WHEN direction_correct THEN 1 ELSE 0 END) AS correct,
                   AVG(CASE WHEN direction_correct THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(ABS(price_error_pct)) AS avg_abs_price_error
            FROM forecast_items WHERE status='resolved' GROUP BY horizon ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """)
        model_scores = _safe_df("SELECT * FROM model_scores ORDER BY hitrate DESC, total DESC LIMIT 50")
        ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
        price = ticker_price or _safe_one("SELECT close FROM raw_candles WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h' ORDER BY open_time DESC LIMIT 1")
        latest_feature = _safe_df("""
            SELECT timestamp_ms, close, regime, data_completeness, funding_rate, open_interest_value,
                   open_interest_change_24h, long_short_ratio, taker_buy_sell_ratio, orderbook_imbalance,
                   orderbook_spread, taker_delta_ratio, futures_basis_premium_pct, top_position_long_short_ratio,
                   top_account_long_short_ratio, cross_exchange_spread_pct, spot_premium_kraken_pct,
                   spot_premium_coinbase_pct, coinmetrics_mvrv, fear_greed, drawdown_from_ath, cycle_progress,
                   volume_zscore, volume_ratio_24, range_pct, candle_body_pct
            FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
        """)
        composite_orderbook = _safe_df("""
            SELECT timestamp_ms, value, metadata
            FROM raw_metric_points
            WHERE source='composite_orderbook' AND metric='orderbook_imbalance'
            ORDER BY timestamp_ms DESC LIMIT 1
        """)
        sync_state = _safe_df("SELECT key, value, updated_at FROM sync_state")
        foundation = DataFoundationService()
        readiness = foundation.readiness()
        integrity = foundation.data_integrity(record_state=False)
        result = {
            "btc_price": float(price[0]) if price and price[0] is not None else None,
            "latest_feature": latest_feature[0] if latest_feature else None,
            "latest_items": latest_items,
            "runs": runs,
            "archive": archive,
            "accuracy": acc,
            "model_scores": model_scores,
            "data_health": HealthService().list(),
            "composite_orderbook": composite_orderbook[0] if composite_orderbook else None,
            "sync_state": sync_state,
            "readiness": readiness,
            "data_integrity": integrity,
            "api_status": "ok",
        }
        return _clean_for_json(result)
    except Exception as exc:
        log.exception("Dashboard API hard failure: %s", exc)
        return _clean_for_json({
            "api_status":"error",
            "error":str(exc),
            "btc_price":None,
            "latest_items":[],
            "data_health":HealthService().list(),
            "sync_state":_safe_df("SELECT key, value, updated_at FROM sync_state"),
        })

@router.post("/sync")
async def sync():
    log.info("Manual sync+forecast requested from dashboard")
    append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_entered"})
    now_fn = __import__("app.core.time_utils", fromlist=["utc_now"]).utc_now
    if sync_lock.locked():
        append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_rejected_busy"})
        return _clean_for_json({"created": False, "reason": "sync already running", "status": "busy"})
    async with sync_lock:
        try:
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["manual_sync_status", "syncing", now_fn()])
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_phase", "phase": "sync_forecast_fast_start"})
            result = await DataFoundationService().run_forecast_pipeline(source="manual")
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_phase", "phase": "data_foundation_done", "result": result})
            log.info("Manual Data Foundation sync completed. forecast_created=%s run=%s reason=%s", result.get("created"), result.get("run_id"), result.get("reason"))
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_completed", "forecast_created": result.get("created"), "run_id": result.get("run_id"), "reason": result.get("reason")})
            return _clean_for_json(result)
        except Exception as exc:
            log.exception("Manual sync+forecast failed: %s", exc)
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_failed", "error": str(exc)})
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["manual_sync_status", "error", now_fn()])
            return _clean_for_json({"created": False, "error": str(exc), "reason": str(exc)})

@router.post("/forecast")
def forecast():
    try:
        return _clean_for_json(ForecastService().create_run())
    except Exception as exc:
        log.exception("Manual forecast failed: %s", exc)
        return {"created": False, "reason": str(exc)}

@router.post("/audit")
def audit():
    return AuditService().audit_due_predictions()

@router.get("/data/readiness")
def data_readiness():
    return _clean_for_json(DataFoundationService().readiness())

@router.get("/data/integrity")
def data_integrity():
    return _clean_for_json(DataFoundationService().data_integrity())



@router.get("/native/status")
def native_status():
    return _clean_for_json(NativeCoreService().status())

@router.get("/time-machine/chart")
def time_machine_chart(timeframe: str = "1h", limit: int = 5000, start_ms: int | None = None, end_ms: int | None = None):
    return TimeMachineService().chart_points(timeframe=timeframe, limit=limit, start_ms=start_ms, end_ms=end_ms)

@router.post("/time-machine/resolve")
def time_machine_resolve(payload: dict):
    return TimeMachineService().resolve_click(int(payload.get("timestamp_ms")))

@router.post("/time-machine/run")
def time_machine_run(payload: dict):
    try:
        ts = int(payload.get("timestamp_ms"))
        log.info("Time Machine manual run requested timestamp_ms=%s", ts)
        result = TimeMachineService().run(ts, bool(payload.get("reveal", True)), persist=bool(payload.get("persist", True)), source="manual", hydrate_context=bool(payload.get("hydrate_context", False)))
        log.info("Time Machine manual run finished ok=%s items=%s", result.get("ok"), len(result.get("items", [])) if isinstance(result, dict) else "?")
        return _clean_for_json(result)
    except Exception as exc:
        tm_priority_event.clear()
        log.exception("Time Machine manual run failed: %s", exc)
        return _clean_for_json({"ok": False, "reason": str(exc), "items": []})

@router.post("/time-machine/random-tests")
def time_machine_random_tests(payload: dict):
    try:
        return _clean_for_json(TimeMachineService().random_tests(int(payload.get("count", 100))))
    except Exception as exc:
        tm_priority_event.clear()
        log.exception("Time Machine random tests failed: %s", exc)
        return _clean_for_json({"ok": False, "reason": str(exc), "summary": {}, "native_status": NativeCoreService().status()})

@router.get("/time-machine/random-status")
def time_machine_random_status(batch_id: str | None = None):
    return _clean_for_json(TimeMachineService().random_batch_status(batch_id))



@router.get("/time-machine/export/latest")
def time_machine_export_latest():
    return _clean_for_json(TimeMachineExportService().latest_info())

@router.get("/time-machine/export/download")
def time_machine_export_download(batch_id: str | None = None):
    path = TimeMachineExportService().export_path(batch_id)
    if not path or not path.exists():
        return _clean_for_json({"ok": False, "reason": "Nog geen Time Machine random export gevonden. Draai eerst Random100 of Random1000."})
    return FileResponse(str(path), media_type="application/zip", filename=path.name)

@router.get("/time-machine/stats")
def time_machine_stats():
    return TimeMachineService().stats()


@router.get("/debug/snapshot")
def debug_snapshot():
    """Human-readable debug state for support/log exports."""
    try:
        candle_range = _safe_one("SELECT MIN(open_time), MAX(open_time), COUNT(*) FROM raw_candles WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h'")
        metric_counts = _safe_df("SELECT source, metric, COUNT(*) AS rows, MAX(timestamp_ms) AS last_ts FROM raw_metric_points GROUP BY source, metric ORDER BY source, metric")
        feature_range = _safe_one("SELECT MIN(timestamp_ms), MAX(timestamp_ms), COUNT(*) FROM features WHERE interval='1h'")
        latest_tm = _safe_df("SELECT horizon, COUNT(*) AS tests, SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS wins FROM time_machine_tests GROUP BY horizon ORDER BY horizon")
        return _clean_for_json({
            "engine_version": settings.engine_version,
            "db_path": str(settings.db_path),
            "candle_range": candle_range,
            "feature_range": feature_range,
            "metric_counts": metric_counts,
            "time_machine_scoreboard": latest_tm,
            "time_machine_learning_snapshots": _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots"),
            "time_machine_learning_signals": _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores"),
            "data_health": HealthService().list(),
            "sync_state": _safe_df("SELECT key, value, updated_at FROM sync_state"),
        })
    except Exception as exc:
        log.exception("Debug snapshot failed: %s", exc)
        return {"error": str(exc)}


@router.post("/debug/frontend-event")
def frontend_event(payload: dict):
    """Small frontend diagnostics endpoint used by the Time Machine chart.
    It makes click/drag/pointer problems visible in exported logs without
    disturbing the UI if logging fails.
    """
    try:
        from app.core.debug import append_jsonl
        append_jsonl("frontend_audit.jsonl", {"event": "frontend", **(payload or {})})
        return {"ok": True}
    except Exception as exc:
        log.warning("Frontend debug event failed: %s", exc)
        return {"ok": False, "reason": str(exc)}


@router.get("/evidence-attribution")
def evidence_attribution(min_total: int = 3):
    try:
        return _clean_for_json(EvidenceAttributionService().leaderboard(min_total=min_total))
    except Exception as exc:
        log.exception("Evidence attribution endpoint failed: %s", exc)
        return _clean_for_json({"top": [], "by_horizon": [], "weak": [], "error": str(exc)})

@router.get("/time-machine/learning")
def time_machine_learning(min_total: int = 5):
    try:
        return _clean_for_json(TimeMachineLearningService().leaderboard(min_total=min_total))
    except Exception as exc:
        log.exception("Time Machine learning endpoint failed: %s", exc)
        return _clean_for_json({"top": [], "by_horizon": [], "weak": [], "coverage": [], "error": str(exc)})


@router.get("/historical-memory/status")
def historical_memory_status():
    try:
        # V10.15.3: this endpoint must be extremely light. Do NOT rebuild/write
        # adaptive weights on every UI poll; that can block behind DuckDB while
        # history is inserting chunks and caused 6000ms frontend timeouts.
        svc = HistoricalMemoryService()
        weights = {}
        try:
            from app.core.config import settings as _settings
            import json as _json
            p = _settings.base_dir / "logs" / "adaptive_feature_weights.json"
            if p.exists():
                weights = _json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            weights = {}
        return _clean_for_json({"ok": True, "history": svc.history_status(), "adaptive_weights": weights})
    except Exception as exc:
        log.exception("Historical memory status failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/historical-memory/backfill")
async def historical_memory_backfill(mode: str = "daemon"):
    try:
        svc = HistoricalMemoryService()
        if str(mode).lower() in ("pass", "single", "once"):
            return _clean_for_json(await svc.ensure_eight_year_history_background())
        # V10.15.1: manual button may never block until 70k is complete.
        # It only checks/restarts the same auto-completion daemon and returns immediately.
        asyncio.create_task(svc.ensure_eight_year_history_daemon())
        return _clean_for_json({"ok": True, "queued": True, "message": "Historical Memory auto-completion daemon is running/queued", "status": svc.history_status()})
    except Exception as exc:
        log.exception("Historical memory backfill failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/historical-memory/daemon")
async def historical_memory_daemon():
    try:
        svc = HistoricalMemoryService()
        asyncio.create_task(svc.ensure_eight_year_history_daemon())
        return _clean_for_json({"ok": True, "queued": True, "message": "Historical Memory auto-completion daemon is running/queued", "status": svc.history_status()})
    except Exception as exc:
        log.exception("Historical memory daemon failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/adaptive-weights/rebuild")
def adaptive_weights_rebuild():
    try:
        return _clean_for_json(HistoricalMemoryService().adaptive_weights())
    except Exception as exc:
        log.exception("Adaptive weights rebuild failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.get("/logs/tail")
def logs_tail(lines: int = 300):
    path = settings.base_dir / "logs" / "bee_runtime.log"
    if not path.exists():
        return {"path": str(path), "lines": []}
    data = path.read_text(encoding="utf-8", errors="replace").splitlines()
    return {"path": str(path), "lines": data[-max(1, min(lines, 2000)):]}


@router.get("/seed-export/status")
def seed_export_status():
    try:
        svc = SeedExportService()
        return _clean_for_json({"ok": True, "latest_export": svc.latest_export_info(), "manifest_preview": svc.manifest()})
    except Exception as exc:
        log.exception("Seed export status failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/seed-export/create")
def seed_export_create():
    try:
        return _clean_for_json(SeedExportService().export_seed_zip())
    except Exception as exc:
        log.exception("Seed export create failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.get("/seed-export/download")
def seed_export_download():
    svc = SeedExportService()
    info = svc.latest_export_info()
    path = Path(info.get("path", ""))
    if not path.exists():
        result = svc.export_seed_zip()
        path = Path(result["path"])
    return FileResponse(str(path), media_type="application/zip", filename=path.name)

@router.get("/mobile/summary")
def mobile_summary():
    """iPhone-first lightweight payload.

    Designed for cloud/PWA use: never runs heavy forecast rebuilds and avoids
    wide archive queries so mobile Safari stays responsive while the backend is
    loading history or learning data.
    """
    try:
        dash = dashboard_status()
        hist = HistoricalMemoryService().history_status()
        native = NativeCoreService().status()
        latest_items = _safe_df("""
            SELECT horizon, bullish_probability, bearish_probability, expected_move_pct,
                   expected_price, invalidation_price, confidence, status, due_at_ms
            FROM forecast_items
            WHERE run_id=(SELECT run_id FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1)
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """)
        accuracy = _safe_df("""
            SELECT horizon, COUNT(*) AS total,
                   SUM(CASE WHEN direction_correct THEN 1 ELSE 0 END) AS correct,
                   AVG(CASE WHEN direction_correct THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(total_score) AS avg_score
            FROM time_machine_tests
            GROUP BY horizon
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """)
        tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id), MAX(created_at) FROM time_machine_tests")
        feature_snapshots = _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots")
        signals = _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores")
        candle_range = _safe_one("SELECT MIN(open_time), MAX(open_time), COUNT(*) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
        return _clean_for_json({
            "ok": True,
            "engine_version": settings.engine_version,
            "api_status": dash.get("api_status") if isinstance(dash, dict) else "ok",
            "sync_busy": bool(dash.get("sync_busy")) if isinstance(dash, dict) else False,
            "btc_price": dash.get("btc_price") if isinstance(dash, dict) else None,
            "latest_feature": dash.get("latest_feature") if isinstance(dash, dict) else None,
            "sync_state": dash.get("sync_state") if isinstance(dash, dict) else [],
            "history": hist,
            "native": native,
            "latest_items": latest_items,
            "accuracy": accuracy,
            "learning": {
                "time_machine_tests": int(tm_counts[0] or 0) if tm_counts else 0,
                "time_machine_batches": int(tm_counts[1] or 0) if tm_counts else 0,
                "latest_test_at": tm_counts[2] if tm_counts else None,
                "feature_snapshots": int(feature_snapshots[0] or 0) if feature_snapshots else 0,
                "latest_feature_snapshot_at": feature_snapshots[1] if feature_snapshots else None,
                "signal_events": int(signals[0] or 0) if signals else 0,
                "latest_signal_at": signals[1] if signals else None,
            },
            "candle_range": {
                "from_ms": candle_range[0] if candle_range else None,
                "to_ms": candle_range[1] if candle_range else None,
                "rows": int(candle_range[2] or 0) if candle_range else 0,
            },
        })
    except Exception as exc:
        log.exception("Mobile summary failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc), "engine_version": settings.engine_version})

@router.get("/mobile/chart")
def mobile_chart(limit: int = 360):
    return TimeMachineService().chart_points(timeframe="1h", limit=max(50, min(int(limit), 1000)))
