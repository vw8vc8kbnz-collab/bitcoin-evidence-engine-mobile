# ENGINE FOUNDATION — AUDIT-READY DESIGN v1.1

## Core statement

Configurator Studio v1.1 is not a generative 3D product promise.
It is a reliable configurable-product engine.

- AI may suggest, but never confirm.
- Geometry must be configurable before the builder can proceed.
- Pricing may only use authoritative inputs.
- Publishing is an immutable, gated runtime snapshot.

## 1. Reliable Source Model Path first

v1.1 focuses on uploaded/verified 3D models and controlled product data.

Flow:

1. Intake
2. Evidence store
3. Truth Graph v2
4. Boolean critical-field gate
5. Asset / mesh inventory
6. Segmentation & Configurability Gate
7. Builder Draft
8. Click-to-action Builder
9. Pricing & Rule validation
10. Runtime compiler
11. Publish gate

Photo-to-3D reconstruction is explicitly out of scope for v1.1.

## 2. Truth Graph v2

The Truth Graph separates value, provenance, candidates and verification.

AI outputs are candidate facts only:

```json
{
  "key": "dimensions.length",
  "value": null,
  "candidates": [
    {"value": 2200, "provenance": "ai_inferred", "confidence": 0.99}
  ],
  "verified": {"by": null, "method": "none"},
  "status": "inferred",
  "pricing_allowed": false
}
```

A confirmed measurement must be user/admin/measured/import verified:

```json
{
  "key": "dimensions.length",
  "value": 2200,
  "unit": "mm",
  "verified": {"by": "user_123", "method": "user_confirmed"},
  "status": "confirmed",
  "pricing_allowed": true
}
```

## 3. Gates are boolean

No gate depends on a pseudo-score.

Gate allowed means:

- every required critical field is confirmed
- every pricing input is authoritative
- conflicts are resolved
- model is configureerbaar
- pricing/rules validate
- runtime compile succeeds

Progress may be shown as "4 of 7 essential details complete", never as a decisive score.

## 4. Segmentation / Configurability Gate

A model can only proceed to builder/publish if intended configurable parts are isolable.

Blocked examples:

- merged single mesh
- no material slots
- intended part not mapped
- option targets non-isolable geometry
- mobile performance too heavy

## 5. Builder Interaction Engine

Model B is the chosen UX pattern:

Click surface/part in 3D model
→ selection state
→ isolation check
→ smooth contextual action menu
→ apply no-code action

Allowed action categories:

- link/create part
- material/texture
- dimension
- geometry/visibility variant
- pricing rule
- rule/warning
- order output

The menu must not offer impossible geometry actions when a part is not isolable.

## 6. Pricing & Rules separation

Pricing Engine is the only price source.

Rule Engine may:

- show/hide/disable/require options
- show warnings
- set order fields
- enable/disable pricing rules

Rule Engine may not directly add price.

## 7. Runtime immutability

Publishing creates an immutable runtime snapshot.

Draft blueprint changes do not affect live runtime until republished.

Runtime must contain only compiled customer-safe config:
- no internal logs
- no provider details
- no draft-only fields
- no cross-workspace data

## 8. Credits / jobs

v1.1 includes schemas and mock logic for jobs/ledger/failure taxonomy only.

Credit principles:

- credits are internal product currency
- provider costs are decoupled
- reserve/capture/refund through idempotent double-entry ledger
- technical success and quality acceptance are separate states

## 9. Test targets

Engine smoke tests currently validate:
- AI candidate never confirms
- AI measurement cannot price
- confirmed measurement can price
- boolean gates block missing fields
- merged mesh blocks configurability
- rules cannot add price
- conflicting rule state invalidates configuration
- area pricing requires authoritative dimensions
- ledger entries balance
- failure taxonomy settlement
