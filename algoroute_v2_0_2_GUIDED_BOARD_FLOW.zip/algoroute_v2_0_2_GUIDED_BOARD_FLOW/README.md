# AlgoRoute v2.0.2 — Guided Board Flow

- Centered import/mapping modal instead of off-screen drawer feedback.
- Planning Board now guides the user with one primary next action.
- CSV upload → AI Mapping → Import & GPS check → Auto Plan.
- Auto Plan prevents first-run dead-end by creating a temporary Bus 01 when no fleet exists yet.
- Cleaner AI Mapping drawer: only real doubtful fields are shown.
