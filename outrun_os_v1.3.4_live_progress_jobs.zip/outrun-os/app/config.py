"""
Central configuration for Outrun OS.

Design goal: the ONLY things you ever need to set are the two API keys.
Everything else has a safe default. TEST_MODE defaults to ON, so nothing
can be sent by accident before you deliberately go live.
"""
import os


def _bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


VERSION = "1.3.4-live-progress"

# --- The only two things you must provide (via Termius / .env / systemd) -----
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "").strip()
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "").strip()

# --- Safety: test mode is server-side and defaults ON ------------------------
# There is deliberately NO endpoint to switch this off from the browser.
# Going live = change this env var and restart the service.
TEST_MODE = _bool("OUTRUN_TEST_MODE", True)

# --- Everything below has sane defaults --------------------------------------
TENANT = os.environ.get("OUTRUN_TENANT", "outruniq")
DB_PATH = os.environ.get("OUTRUN_DB", os.path.join(os.path.dirname(os.path.dirname(__file__)), "outrun_os.db"))

HOST = os.environ.get("OUTRUN_HOST", "0.0.0.0")
PORT = int(os.environ.get("OUTRUN_PORT", "8700"))

# Background worker that advances the pipeline on a timer (test-mode friendly).
WORKER_ENABLED = _bool("OUTRUN_WORKER", False)
WORKER_INTERVAL_SEC = int(os.environ.get("OUTRUN_WORKER_INTERVAL", "20"))

# Evidence Engine Step 1: deep crawl limits. No paid AI/API calls.
CRAWL_MAX_PAGES = int(os.environ.get("OUTRUN_CRAWL_MAX_PAGES", "80"))
CRAWL_MAX_DEPTH = int(os.environ.get("OUTRUN_CRAWL_MAX_DEPTH", "2"))
CRAWL_SOCIAL_MAX_PAGES = int(os.environ.get("OUTRUN_CRAWL_SOCIAL_MAX_PAGES", "3"))

# Sender identity used in generated outreach.
SENDER_NAME = os.environ.get("OUTRUN_SENDER_NAME", "Stijn")
SENDER_BRAND = os.environ.get("OUTRUN_SENDER_BRAND", "Outrun IQ")
COMMISSION_PCT = os.environ.get("OUTRUN_COMMISSION", "10")

# LLM model names (override only if you want a different tier).
DEEPSEEK_MODEL = os.environ.get("OUTRUN_DEEPSEEK_MODEL", "deepseek-chat")
OPENAI_MODEL = os.environ.get("OUTRUN_OPENAI_MODEL", "gpt-4o")
OPENAI_VISION_MODEL = os.environ.get("OUTRUN_OPENAI_VISION_MODEL", "gpt-4o")

# Optional real discovery source. Off unless you add a key. (SerpAPI-compatible.)
SERPAPI_KEY = os.environ.get("SERPAPI_KEY", "").strip()

# Master company database: cheap local base. Real bulk source should be imported
# from a KvK/open-data CSV; generated fallback keeps testing possible without API cost.
MASTER_BATCH_SIZE = int(os.environ.get("OUTRUN_MASTER_BATCH_SIZE", "10000"))

# SMTP is ONLY used when TEST_MODE is False. Left blank = cannot send.
SMTP_HOST = os.environ.get("OUTRUN_SMTP_HOST", "")
SMTP_PORT = int(os.environ.get("OUTRUN_SMTP_PORT", "587"))
SMTP_USER = os.environ.get("OUTRUN_SMTP_USER", "")
SMTP_PASS = os.environ.get("OUTRUN_SMTP_PASS", "")
SMTP_FROM = os.environ.get("OUTRUN_SMTP_FROM", "")

# Timing-signal half-life in days (event-driven signals cool over time).
TIMING_HALFLIFE_DAYS = float(os.environ.get("OUTRUN_TIMING_HALFLIFE", "10"))


def llm_keys_present() -> bool:
    return bool(DEEPSEEK_API_KEY) or bool(OPENAI_API_KEY)


def status_summary() -> dict:
    return {
        "version": VERSION,
        "test_mode": TEST_MODE,
        "tenant": TENANT,
        "deepseek": "live" if DEEPSEEK_API_KEY else "mock",
        "openai": "live" if OPENAI_API_KEY else "mock",
        "worker": WORKER_ENABLED,
        "crawl_max_pages": CRAWL_MAX_PAGES,
        "crawl_max_depth": CRAWL_MAX_DEPTH,
        "can_send": (not TEST_MODE) and bool(SMTP_HOST),
    }
