# OVERDRACHT — Outrun OS v1.3.4 Live Progress Jobs

## Context
Outrun OS is de standalone acquisition intelligence tool voor Outrun IQ. De gebruiker wil een grote lokale KvK/company master database, slimme filters en handmatige deep search per bedrijf. Dure API/AI-calls mogen niet 24/7 draaien.

## Wat v1.3.4 oplost
In v1.3.3 was onduidelijk of de tool bezig was met laden. Er was geen zichtbare live status bij:
- master vullen 10k;
- basic analyse;
- deep search.

v1.3.4 voegt een SQLite-backed jobsysteem toe met live progress polling.

## Nieuwe bestanden/wijzigingen
- `app/jobs.py`: eenvoudige persisted background jobs met status/progress/ETA/result/error.
- `app/db.py`: `jobs`-tabel toegevoegd.
- `app/api.py`: endpoints:
  - `GET /api/jobs`
  - `GET /api/job/{job_id}`
  - `POST /api/master/bootstrap` start nu async job.
  - `POST /api/master/basic-analyze` start nu async job.
  - `POST /api/lead/{cid}/deep-crawl` start nu async job.
- `app/pipeline/master_company_db.py`: progress callbacks toegevoegd.
- `app/pipeline/deep_crawl.py`: progress callbacks tijdens websitecrawl/social-check/opslag.
- `web/index.html`: live job panel, progressbar, spinner, ETA, loading chips.

## Principes blijven hetzelfde
- Geen automatische deep search.
- Geen 24/7 AI-kosten.
- Deep search handmatig per bedrijf.
- Master/company data blijft permanent tussen versies.
- ZIP bevat geen `outrun_os.db`, zodat bestaande VPS-database niet overschreven wordt.

## Volgende logische stap
- Echte KvK/open dataset import verbeteren met bestand-upload in plaats van paste prompt.
- Company Intelligence Report uitbreiden met bewijslinks per claim.
- Outreach-mails pas genereren na voldoende evidence quality.
