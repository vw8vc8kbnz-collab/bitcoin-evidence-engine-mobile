# Outrun OS v1.3.4 — Live Progress Jobs

VPS-safe standalone acquisition cockpit voor Outrun IQ.

## Nieuw in v1.3.4
- Live job/progress systeem voor lange taken.
- `master vullen 10k` draait op achtergrond en toont live aantal, percentage en ETA.
- `basic analyse` draait op achtergrond met voortgang.
- `deep search` draait op achtergrond met pagina-progress, social-check progress en ETA.
- UI-knoppen krijgen loading-state/spinner.
- Laatste taak blijft zichtbaar als klaar/mislukt, inclusief foutmelding bij failure.
- Geen extra betaalde AI-calls voor deze progress-laag.

## Belangrijk
- Master DB, data en `.env` moeten bij updates behouden blijven.
- Deep search blijft handmatig gestart; geen 24/7 dure API/AI scanning.
