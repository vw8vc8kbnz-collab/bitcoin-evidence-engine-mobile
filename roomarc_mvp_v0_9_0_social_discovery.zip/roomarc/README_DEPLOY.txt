ROOMARC MVP v0.9.0 — Social discovery polish

Installeren/updaten op VPS:

cd ~ && rm -rf roomarc-src roomarc-unpack roomarc && git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git roomarc-src && mkdir -p roomarc-unpack && unzip -oq roomarc-src/roomarc_mvp_v0_9_0_social_discovery.zip -d roomarc-unpack && bash roomarc-unpack/install_roomarc.sh

Open:
http://SERVER-IP:8899

Demo-login:
demo@roomarc.local
demo123

Nieuw in v0.9.0:
- Ontdekken 2.0 met stijlfilters en betere social discovery.
- Populaire huizen, kamer-tijdlijnen en nieuwe updates.
- Publieke home profiles met sterkere social proof.
- Bewaard-tab meer als inspiratiecollectie.
- Extra voorbeeldkamers/huizen blijven via demo seed beschikbaar.
