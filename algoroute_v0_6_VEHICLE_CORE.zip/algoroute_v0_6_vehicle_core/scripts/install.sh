#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p data
if [ ! -f data/algoroute_store.json ]; then
  cat > data/algoroute_store.json <<'JSON'
{
  "vehicles": [
    {
      "id": "veh_001",
      "code": "V-01",
      "license_plate": "V-123-AB",
      "brand": "Mercedes-Benz",
      "model": "Sprinter 317",
      "vehicle_type": "Bestelbus bakwagen",
      "status": "available",
      "maintenance_until": null,
      "max_weight_kg": 1250,
      "euro_pallets": 6,
      "roll_containers": 8,
      "notes": "Hoofdbus regio Randstad"
    },
    {
      "id": "veh_002",
      "code": "V-02",
      "license_plate": "V-456-CD",
      "brand": "Volkswagen",
      "model": "Crafter",
      "vehicle_type": "Bestelbus L4H3",
      "status": "maintenance",
      "maintenance_until": "2026-07-03",
      "max_weight_kg": 1100,
      "euro_pallets": 5,
      "roll_containers": 7,
      "notes": "Onderhoud: remmen + banden"
    }
  ],
  "transport_units": [
    {"id": "tu_europallet", "name": "Europallet", "length_mm": 1200, "width_mm": 800, "height_mm": 144, "max_weight_kg": 1500, "active": true},
    {"id": "tu_roll_a", "name": "Rolcontainer A", "length_mm": 720, "width_mm": 800, "height_mm": 1700, "max_weight_kg": 500, "active": true},
    {"id": "tu_roll_b", "name": "Rolcontainer B", "length_mm": 800, "width_mm": 900, "height_mm": 1800, "max_weight_kg": 600, "active": true}
  ]
}
JSON
fi
chmod -R 755 data
printf 'AlgoRoute v0.6 install ready.\n'
