# AlgoRoute C++ Optimization Core

Reserved module for the future C++ core:
- route solver
- promise guard
- pallet/rolcontainer capacity solver
- live recalculation
- EV intelligence

v0.6 uses API storage first; C++ integration follows after Import Studio and planning inputs are stable.
