# AlgoRoute v0.6 Vehicle Core

Functionele SaaS-basis voor AlgoRoute:

- Wagenpark module met echte API-koppeling
- Voertuigen aanmaken, bewerken, verwijderen
- Status: beschikbaar, onderhoud, niet beschikbaar
- Onderhoud tot datum
- Capaciteit europallets en rolcontainers
- Transport Unit Types beheren
- Persistente JSON-opslag in `/app/data/algoroute_store.json`
- Frontend gebruikt API, geen hardcoded wagenparkdata meer
- Nginx serveert frontend op `/` en proxy't `/api/` naar FastAPI

Open na deploy:

```text
http://51.195.102.180:8787/
```

Healthcheck:

```text
http://51.195.102.180:8787/api/health
```
