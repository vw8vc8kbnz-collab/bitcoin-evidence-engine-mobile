const API = '/api';
const state = { page: 'dashboard', vehicles: [], units: [], stats: {}, editingVehicle: null, editingUnit: null };
const navItems = [
  ['dashboard','▦','Dashboard'],['planning','⌖','Planning'],['routes','⌘','Routes'],['live-map','▣','Live Kaart'],['fleet','▣','Wagenpark'],['import','⇧','Import Studio'],['tracking','➤','Live Tracking'],['customer','⊙','Klanttracking'],['reports','▣','Rapportages'],['settings','⚙','Instellingen']
];

async function api(path, options={}){
  const res = await fetch(API + path, {headers:{'Content-Type':'application/json'}, ...options});
  if(!res.ok){ let detail='API fout'; try{detail=(await res.json()).detail||detail}catch{}; throw new Error(detail); }
  return res.json();
}
async function load(){
  const data = await api('/bootstrap');
  state.vehicles = data.vehicles || [];
  state.units = data.transport_units || [];
  state.stats = data.stats || {};
  render();
}
function setPage(page){ state.page=page; state.editingVehicle=null; state.editingUnit=null; render(); }
function renderNav(){
  document.getElementById('nav').innerHTML = navItems.map(([key,icon,label])=>`<button class="nav-item ${state.page===key?'active':''}" onclick="setPage('${key}')"><i>${icon}</i><span>${label}</span></button>`).join('');
}
function render(){ renderNav(); const c=document.getElementById('content');
  const map={dashboard:dashboardPage,planning:planningPage,routes:routesPage,'live-map':liveMapPage,fleet:fleetPage,import:importPage,tracking:trackingPage,customer:customerPage,reports:reportsPage,settings:settingsPage};
  c.innerHTML=(map[state.page]||dashboardPage)();
  bindForms();
}
function dashboardPage(){return `<div class="grid dash-grid">
  <div>
    <div class="card"><h2>Live Tracking <span class="badge available">Live</span></h2>${mapMarkup()}<div class="stats">
      ${metric('Kilometers','1.248 km','+8%')}${metric('Beschikbaar',state.stats.vehicles_available||0,'voertuigen')}${metric('Palletcapaciteit',state.stats.euro_pallet_capacity||0,'EPAL')}${metric('Rolcontainers',state.stats.roll_container_capacity||0,'actief')}
    </div></div>
    <div class="grid" style="grid-template-columns:1fr 1fr; margin-top:24px">${planningMini()}${importMini()}</div>
  </div>
  <div class="grid">
    <div class="card"><h3>Overzicht vandaag</h3><div class="stats" style="grid-template-columns:repeat(3,1fr)">${metric('Routes','12','')}${metric('On-time','98%','')}${metric('Stops','256','')}</div></div>
    <div class="card"><h3>Prestaties</h3>${chart()}</div>
    <div class="card"><h3>Meldingen</h3>${alerts()}</div>
    ${fleetMini()}
  </div>
</div>`}
function mapMarkup(){return `<div class="live-map"><svg class="route-line" viewBox="0 0 900 620"><path d="M570 95 C515 150 480 200 520 245 S655 240 690 315 S590 395 610 470" fill="none" stroke="#0f87ff" stroke-width="8" stroke-linecap="round" filter="url(#g)"/><defs><filter id="g"><feGaussianBlur stdDeviation="2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs></svg><div class="stop" style="left:56%;top:20%">1</div><div class="stop" style="left:50%;top:36%">2</div><div class="stop" style="left:57%;top:57%">3</div><div class="stop" style="left:73%;top:44%">4</div><div class="truck"></div></div>`}
function metric(label,value,delta){return `<div class="card metric"><span class="muted">${label}</span><b>${value}</b><small>${delta}</small></div>`}
function chart(){return `<div class="line-chart"><svg viewBox="0 0 600 180"><path d="M30 135 L105 88 L180 65 L250 105 L330 50 L405 35 L490 86 L570 64" fill="none" stroke="#1387ff" stroke-width="7" stroke-linecap="round"/><g fill="#1387ff"><circle cx="105" cy="88" r="6"/><circle cx="330" cy="50" r="6"/><circle cx="405" cy="35" r="6"/><circle cx="570" cy="64" r="6"/></g></svg></div>`}
function alerts(){return `<div class="alerts"><div class="alert"><span class="red">△</span><div><b>Verkeersvertraging A2</b><div class="muted">10 min extra reistijd</div></div><time>10:24</time></div><div class="alert"><span class="green">⌖</span><div><b>Afwijking leveradres</b><div class="muted">Route aangepast</div></div><time>09:15</time></div><div class="alert"><span class="amber">△</span><div><b>Stop vertraagd</b><div class="muted">Klant niet aanwezig</div></div><time>08:47</time></div></div>`}
function planningMini(){return `<div class="card"><h3>Planning</h3><table class="mini"><tr><td>R001</td><td>Jan de Vries</td><td><span class="badge available">Actief</span></td></tr><tr><td>R002</td><td>Pieter Smit</td><td><span class="badge available">Actief</span></td></tr><tr><td>R003</td><td>Marco Jansen</td><td><span class="badge maintenance">Gepland</span></td></tr></table></div>`}
function importMini(){return `<div class="card"><h3>Import Studio</h3><div class="import-drop">⇧<br><b>Sleep CSV/Excel hierheen</b><p class="muted">Smart Field Picker volgt in v0.7</p></div></div>`}
function fleetMini(){return `<div class="card"><h3>Wagenpark</h3><div class="vehicle-list">${state.vehicles.slice(0,3).map(v=>vehicleRow(v,false)).join('')}</div></div>`}
function fleetPage(){return `<div class="page-head"><div><h1>Wagenpark</h1><p>Beheer voertuigen, beschikbaarheid en laadcapaciteit. Deze data wordt straks direct gebruikt door de optimizer.</p></div><button class="btn" onclick="newVehicle()">+ Voertuig toevoegen</button></div><div class="module-grid"><div class="card"><h2>Voertuigen</h2><div class="vehicle-list">${state.vehicles.map(v=>vehicleRow(v,true)).join('')||'<p class="muted">Nog geen voertuigen.</p>'}</div></div><div>${vehicleForm()}<br>${unitManager()}</div></div>`}
function vehicleRow(v, actions=true){const statusLabel={available:'Beschikbaar',maintenance:'Onderhoud',unavailable:'Niet beschikbaar'}[v.status]||v.status;return `<div class="vehicle-row"><div><div class="vehicle-title"><span>${v.code}</span><span class="badge ${v.status}">${statusLabel}</span></div><div class="sub">${v.license_plate} · ${v.brand} ${v.model} · ${v.vehicle_type||'Voertuig'}</div><div class="caps"><span>${v.max_weight_kg||0} kg</span><span>${v.euro_pallets||0} europallets</span><span>${v.roll_containers||0} rolcontainers</span>${v.maintenance_until?`<span>onderhoud tot ${v.maintenance_until}</span>`:''}</div></div>${actions?`<div class="actions"><button class="icon-btn" onclick="editVehicle('${v.id}')">✎</button><button class="icon-btn" onclick="removeVehicle('${v.id}')">×</button></div>`:''}</div>`}
function vehicleForm(){const v=state.editingVehicle||{code:'',license_plate:'',brand:'',model:'',vehicle_type:'',status:'available',maintenance_until:'',max_weight_kg:0,euro_pallets:0,roll_containers:0,notes:''};return `<div class="card"><h2>${state.editingVehicle?'Voertuig bewerken':'Nieuw voertuig'}</h2><form id="vehicleForm" class="form-grid"><input type="hidden" name="id" value="${v.id||''}">${field('Code','code',v.code)}${field('Kenteken','license_plate',v.license_plate)}${field('Merk','brand',v.brand)}${field('Model','model',v.model)}${field('Type voertuig','vehicle_type',v.vehicle_type)}<div class="field"><label>Status</label><select name="status"><option value="available" ${v.status==='available'?'selected':''}>Beschikbaar</option><option value="maintenance" ${v.status==='maintenance'?'selected':''}>Onderhoud</option><option value="unavailable" ${v.status==='unavailable'?'selected':''}>Niet beschikbaar</option></select></div>${field('Onderhoud tot','maintenance_until',v.maintenance_until||'','date')}${field('Max gewicht kg','max_weight_kg',v.max_weight_kg,'number')}${field('Europallets','euro_pallets',v.euro_pallets,'number')}${field('Rolcontainers','roll_containers',v.roll_containers,'number')}<div class="field full"><label>Notities</label><textarea name="notes">${v.notes||''}</textarea></div><div class="field full"><button class="btn" type="submit">${state.editingVehicle?'Opslaan':'Toevoegen'}</button> ${state.editingVehicle?'<button class="btn secondary" type="button" onclick="cancelEdit()">Annuleren</button>':''}</div></form></div>`}
function field(label,name,value,type='text'){return `<div class="field"><label>${label}</label><input name="${name}" type="${type}" value="${value??''}"></div>`}
function unitManager(){return `<div class="card"><div class="page-head" style="margin:0 0 14px"><div><h2>Transport Units</h2><p>Standaard laad-eenheden voor planning.</p></div><button class="btn secondary" onclick="newUnit()">+ Type</button></div><div class="unit-list">${state.units.map(u=>`<div class="unit-row"><div><b>${u.name}</b><div class="sub">${u.length_mm}×${u.width_mm}×${u.height_mm} mm · max ${u.max_weight_kg} kg</div></div><div class="actions"><button class="icon-btn" onclick="editUnit('${u.id}')">✎</button><button class="icon-btn" onclick="removeUnit('${u.id}')">×</button></div></div>`).join('')}</div>${unitForm()}</div>`}
function unitForm(){if(!state.editingUnit)return ''; const u=state.editingUnit;return `<form id="unitForm" class="form-grid" style="margin-top:16px"><input type="hidden" name="id" value="${u.id||''}">${field('Naam','name',u.name)}${field('Lengte mm','length_mm',u.length_mm,'number')}${field('Breedte mm','width_mm',u.width_mm,'number')}${field('Hoogte mm','height_mm',u.height_mm,'number')}${field('Max gewicht kg','max_weight_kg',u.max_weight_kg,'number')}<div class="field full"><button class="btn" type="submit">Opslaan</button><button class="btn secondary" type="button" onclick="state.editingUnit=null;render()">Annuleren</button></div></form>`}
function planningPage(){return pageShell('Planning','Selecteer datum, orders en beschikbare voertuigen. In v0.8 koppelen we hier de eerste route-engine aan.',`<div class="card"><h2>Beschikbare capaciteit vandaag</h2><div class="stats">${metric('Voertuigen',state.stats.vehicles_available||0,'beschikbaar')}${metric('Europallets',state.stats.euro_pallet_capacity||0,'capaciteit')}${metric('Rolcontainers',state.stats.roll_container_capacity||0,'capaciteit')}</div></div>`)}
function routesPage(){return pageShell('Routes','Routeoverzicht met stopvolgorde, ETA en load-check status.',`<div class="card">${mapMarkup()}</div>`)}
function liveMapPage(){return pageShell('Live Kaart','Eigen cockpitpagina voor live buslocaties, routes, traffic en alerts.',`<div class="card"><h2>Nederland Live Map</h2>${mapMarkup()}</div>`)}
function importPage(){return pageShell('Import Studio','Volgende stap: Smart Field Picker met CSV preview, mapping templates en validatie.',`<div class="card"><h2>CSV Mapper v0.7 preview</h2><div class="import-drop">⇧<br><b>Bestanden slepen of kiezen</b><p class="muted">Kolom A/B/C wordt straks gekoppeld via zoekbare field picker.</p></div></div>`)}
function trackingPage(){return pageShell('Live Tracking','Chauffeur tracking en statusupdates komen hier samen.',`<div class="card">${mapMarkup()}</div>`)}
function customerPage(){return pageShell('Klanttracking','Mobiele trackinglinks met ETA en aantal stops vóór levering.',`<div class="card"><h2>Tracking Portal</h2><p class="muted">Token-gebaseerde klantpagina volgt na route-publicatie.</p></div>`)}
function reportsPage(){return pageShell('Rapportages','Prestaties, on-time percentage, kilometers, CO₂ en laadcapaciteit.',`<div class="card">${chart()}</div>`)}
function settingsPage(){return pageShell('Instellingen','Bedrijfsinstellingen, depots, route-regels, promise guard en EV-roadmap.',`<div class="card"><h2>Roadmap settings</h2><p class="muted">Dynamic recalculation en EV Intelligence zijn architecturaal gereserveerd.</p></div>`)}
function pageShell(title,desc,body){return `<div class="page-head"><div><h1>${title}</h1><p>${desc}</p></div></div>${body}`}
function bindForms(){const vf=document.getElementById('vehicleForm'); if(vf)vf.onsubmit=saveVehicle; const uf=document.getElementById('unitForm'); if(uf)uf.onsubmit=saveUnit;}
function formObj(form){return Object.fromEntries(new FormData(form).entries())}
async function saveVehicle(e){e.preventDefault(); const o=formObj(e.target); ['max_weight_kg','euro_pallets','roll_containers'].forEach(k=>o[k]=Number(o[k]||0)); const id=o.id; delete o.id; if(!o.maintenance_until)o.maintenance_until=null; try{ if(id) await api('/vehicles/'+id,{method:'PUT',body:JSON.stringify(o)}); else await api('/vehicles',{method:'POST',body:JSON.stringify(o)}); state.editingVehicle=null; await load(); }catch(err){alert(err.message)}}
function newVehicle(){state.editingVehicle=null;render(); setTimeout(()=>document.querySelector('[name=code]')?.focus(),0)}
function editVehicle(id){state.editingVehicle={...state.vehicles.find(v=>v.id===id)};render()}
function cancelEdit(){state.editingVehicle=null;render()}
async function removeVehicle(id){if(confirm('Voertuig verwijderen?')){await api('/vehicles/'+id,{method:'DELETE'}); await load();}}
function newUnit(){state.editingUnit={name:'',length_mm:0,width_mm:0,height_mm:0,max_weight_kg:0,active:true};render()}
function editUnit(id){state.editingUnit={...state.units.find(u=>u.id===id)};render()}
async function saveUnit(e){e.preventDefault(); const o=formObj(e.target); ['length_mm','width_mm','height_mm','max_weight_kg'].forEach(k=>o[k]=Number(o[k]||0)); o.active=true; const id=o.id; delete o.id; if(id) await api('/transport-units/'+id,{method:'PUT',body:JSON.stringify(o)}); else await api('/transport-units',{method:'POST',body:JSON.stringify(o)}); state.editingUnit=null; await load();}
async function removeUnit(id){if(confirm('Transport-unit verwijderen?')){await api('/transport-units/'+id,{method:'DELETE'}); await load();}}
load().catch(e=>{document.getElementById('content').innerHTML=`<div class="card"><h1>API fout</h1><p>${e.message}</p></div>`});
