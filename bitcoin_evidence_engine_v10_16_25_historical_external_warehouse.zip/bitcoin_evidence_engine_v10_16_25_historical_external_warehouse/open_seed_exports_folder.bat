@echo off
cd /d %~dp0
if not exist "exports" mkdir exports
start "" "%CD%\exports"
