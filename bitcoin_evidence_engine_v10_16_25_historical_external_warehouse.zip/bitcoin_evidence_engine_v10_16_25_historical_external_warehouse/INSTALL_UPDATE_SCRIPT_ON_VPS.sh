#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p "$HOME/bitcoin-engine-deploy"
cp update.sh "$HOME/bitcoin-engine-deploy/update.sh"
chmod +x "$HOME/bitcoin-engine-deploy/update.sh"
echo "✅ update.sh geïnstalleerd in ~/bitcoin-engine-deploy/update.sh"
echo "Voortaan gebruik je:"
echo "  cd ~/bitcoin-engine-deploy && bash update.sh"
