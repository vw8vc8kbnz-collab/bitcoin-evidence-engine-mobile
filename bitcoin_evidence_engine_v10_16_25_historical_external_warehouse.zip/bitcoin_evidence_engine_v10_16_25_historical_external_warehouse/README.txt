Bitcoin Evidence Engine V10.16.2 Oracle Cloud Mobile

Deze build is speciaal gemaakt voor de richting: iPhone mobile app + Oracle Cloud Always Free/VPS backend.

Lees eerst: ORACLE_CLOUD_IPHONE_GUIDE.txt

Voor lokaal Windows testen kan start.bat nog gebruikt worden. Voor Oracle/VPS gebruik je:

  bash oracle_bootstrap_ubuntu.sh
  bash start_oracle.sh

Daarna open je /mobile op je iPhone.
