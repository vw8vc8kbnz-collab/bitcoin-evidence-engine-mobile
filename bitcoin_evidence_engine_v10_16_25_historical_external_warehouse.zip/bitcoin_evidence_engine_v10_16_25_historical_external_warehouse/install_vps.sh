#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "=============================================="
echo "Bitcoin Evidence Engine v10.16.5 VPS INSTALL"
echo "=============================================="

if command -v sudo >/dev/null 2>&1; then
  SUDO="sudo"
else
  SUDO=""
fi

if command -v apt-get >/dev/null 2>&1; then
  echo "Installing Ubuntu packages..."
  $SUDO apt-get update
  $SUDO apt-get install -y python3 python3-venv python3-pip build-essential golang-go curl unzip procps
fi

rm -rf .venv
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip wheel setuptools
python -m pip install -r requirements.txt

bash build_native_core_linux.sh
mkdir -p "$HOME/bitcoin_evidence_data" logs

echo ""
echo "INSTALL OK. Start nu met:"
echo "  bash restart_vps.sh"
