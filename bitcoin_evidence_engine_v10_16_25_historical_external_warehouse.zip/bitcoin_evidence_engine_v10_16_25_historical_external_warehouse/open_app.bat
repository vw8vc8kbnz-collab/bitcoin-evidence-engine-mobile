@echo off
setlocal
cd /d %~dp0
set URL=http://127.0.0.1:8787

REM Wait until FastAPI responds before opening the app window.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; for($i=0;$i -lt 80;$i++){ try{ $r=Invoke-WebRequest -UseBasicParsing '%URL%' -TimeoutSec 1; if($r.StatusCode -ge 200){$ok=$true; break} } catch{}; Start-Sleep -Milliseconds 500 }; if(-not $ok){ exit 2 }"
if errorlevel 1 (
  echo App server did not respond yet. Open manually: %URL%
  >>"logs\launcher.log" echo [%date% %time%] App server not ready for app window
  exit /b 1
)

set EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe
set EDGE2=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe
set CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe
set CHROME2=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe
set PROFILE=%CD%\app_profile

if exist "%EDGE%" (
  start "Bitcoin Evidence Engine" "%EDGE%" --app=%URL% --user-data-dir="%PROFILE%" --window-size=1680,980
  exit /b
)
if exist "%EDGE2%" (
  start "Bitcoin Evidence Engine" "%EDGE2%" --app=%URL% --user-data-dir="%PROFILE%" --window-size=1680,980
  exit /b
)
if exist "%CHROME%" (
  start "Bitcoin Evidence Engine" "%CHROME%" --app=%URL% --user-data-dir="%PROFILE%" --window-size=1680,980
  exit /b
)
if exist "%CHROME2%" (
  start "Bitcoin Evidence Engine" "%CHROME2%" --app=%URL% --user-data-dir="%PROFILE%" --window-size=1680,980
  exit /b
)
start "Bitcoin Evidence Engine" %URL%
