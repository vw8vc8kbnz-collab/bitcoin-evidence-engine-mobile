Seed Data exporteren
=====================

1. Start de app met start.bat.
2. Wacht tot History Memory 100% / Volledig geladen is.
3. Klik links op: Export Seed Snapshot.
4. De app maakt dan:
   exports\bitcoin_evidence_engine_seed_export.zip
5. Upload die ZIP naar ChatGPT.

Deze export bevat de gedeelde AppData DuckDB database, de 70k Binance 1h candles,
Time Machine tests, learning snapshots, signal scores, adaptive weights, relevante
logs en native cache-bestanden als die aanwezig zijn.
