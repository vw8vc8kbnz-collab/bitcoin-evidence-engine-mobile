@echo off
setlocal
set "BEE_HOME=%LOCALAPPDATA%\BitcoinEvidenceEngine"
echo This removes the shared Python environment used by Bitcoin Evidence Engine.
echo Folder: %BEE_HOME%
choice /C YN /M "Continue"
if errorlevel 2 exit /b 0
rmdir /s /q "%BEE_HOME%"
echo Removed. Next start will reinstall packages once.
pause
