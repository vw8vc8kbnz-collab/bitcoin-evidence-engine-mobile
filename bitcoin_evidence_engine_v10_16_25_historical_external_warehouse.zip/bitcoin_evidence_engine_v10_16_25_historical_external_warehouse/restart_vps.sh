#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PORT="${PORT:-8787}"

bash stop_vps.sh || true

if [ ! -x .venv/bin/python ] || ! .venv/bin/python -c "import uvicorn" >/dev/null 2>&1; then
  echo ".venv/uvicorn ontbreekt; installatie wordt automatisch uitgevoerd..."
  bash install_vps.sh
fi

if [ ! -x native_core/bin/bee_native_core ]; then
  bash build_native_core_linux.sh
fi

mkdir -p logs
nohup bash start_vps.sh > server.log 2>&1 &
PID=$!
echo "Started background process PID $PID"

for i in $(seq 1 30); do
  sleep 1
  if curl -fsS "http://127.0.0.1:${PORT}/api/health" >/tmp/bee_health.json 2>/dev/null || curl -fsS "http://127.0.0.1:${PORT}/health" >/tmp/bee_health.json 2>/dev/null; then
    echo "ONLINE: http://127.0.0.1:${PORT}"
    cat /tmp/bee_health.json || true
    echo ""
    echo "Open extern: http://51.195.102.180:${PORT}"
    exit 0
  fi
  if ! kill -0 "$PID" 2>/dev/null; then
    echo "Server stopped during startup. Last log lines:"
    tail -80 server.log || true
    exit 1
  fi
done

echo "Server did not become healthy within 30 seconds. Last log lines:"
tail -120 server.log || true
exit 1
