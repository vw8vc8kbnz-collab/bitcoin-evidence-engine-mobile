@echo off
cd /d %~dp0
if exist .deps_installed del .deps_installed
if exist .venv rmdir /s /q .venv
echo Dependencies reset. Start start.bat again to reinstall.
pause
