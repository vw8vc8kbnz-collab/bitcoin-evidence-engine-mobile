Bitcoin Evidence Engine v10.16.7

EENMALIG op de VPS installeren nadat deze ZIP in GitHub staat:

cd ~/bitcoin-engine-deploy
rm -rf github_latest .update_extract
git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git github_latest
ZIP=$(find github_latest -maxdepth 2 -type f \( -iname "bitcoin_evidence_engine*.zip" -o -iname "engine*.zip" \) -printf "%T@ %p\n" | sort -nr | head -1 | cut -d" " -f2-)
mkdir -p .update_extract
unzip -q "$ZIP" -d .update_extract
cp $(find .update_extract -type f -name update.sh | head -1) ./update.sh
chmod +x update.sh
bash update.sh

DAARNA VOORTAAN ALLEEN:
cd ~/bitcoin-engine-deploy && bash update.sh
