@echo off
cd /d %~dp0
if not exist logs mkdir logs
echo Exporting debug logs and database snapshot info...
(
  echo BEE debug export
  echo Date: %date% %time%
  echo Folder: %cd%
  echo.
  echo Python:
  python --version 2^>^&1
  echo.
  echo Files:
  dir /b
) > logs\environment_snapshot.txt
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path logs -DestinationPath bee_debug_logs.zip -Force"
echo Created bee_debug_logs.zip. Send that ZIP to ChatGPT.
pause
