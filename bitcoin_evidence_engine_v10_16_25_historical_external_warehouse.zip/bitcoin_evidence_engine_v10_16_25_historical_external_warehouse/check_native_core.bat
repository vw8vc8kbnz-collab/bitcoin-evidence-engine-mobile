@echo off
cd /d %~dp0
if not exist "native_core\bin\bee_native_core.exe" (
  echo Native core ontbreekt.
  pause
  exit /b 1
)
echo Native core aanwezig:
native_core\bin\bee_native_core.exe
echo.
echo OK. Start nu start.bat
pause
