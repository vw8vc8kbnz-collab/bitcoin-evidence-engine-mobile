@echo off
setlocal EnableExtensions
cd /d %~dp0

echo.
echo Bitcoin Evidence Engine V10.16.0 Mobile PWA Preview
echo ------------------------------------------------------
echo Deze start opent de backend op je lokale netwerk zodat je hem op je iPhone kunt testen.
echo.
echo Zoek hieronder je IPv4 adres. Op je iPhone open je daarna:
echo.
for /f "tokens=14 delims= " %%a in ('ipconfig ^| findstr /R /C:"IPv4.*192\." /C:"IPv4.*10\." /C:"IPv4.*172\."') do echo   http://%%a:8787/mobile
echo.
echo Als Windows Firewall vraagt om toegang: toestaan op Prive-netwerken.
echo.
pause
set BEE_HOST=0.0.0.0
set BEE_AUTO_OPEN=0
call start.bat
