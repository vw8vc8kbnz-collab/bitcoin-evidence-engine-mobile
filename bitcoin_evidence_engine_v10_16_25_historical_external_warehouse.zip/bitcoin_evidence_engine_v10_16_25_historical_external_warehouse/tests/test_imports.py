def test_imports():
    import app.main
    import app.engine.meta_judge
    import app.engine.model_arena
