Bitcoin Evidence Engine V10.9 Native Core

C++ is verplicht voor:
- Time Machine chart OHLC aggregation/downsampling
- Random 100 / Random 1000 Time Machine batch backtests

Build op Windows:
- Dubbelklik build_native_core.bat in de hoofdmap, of
- start.bat bouwt automatisch als native_core/bin/bee_native_core.exe ontbreekt.

Benodigd:
- Visual Studio Build Tools met C++ workload, of
- MinGW g++ in PATH.

Geen Python fallback:
Als bee_native_core.exe ontbreekt of crasht, geeft de app bewust een duidelijke fout. Zo weet je zeker of de engine echt native draait.

V10.12 State Vector Engine:
- tm_single/tm_random now receive candles.csv + state_features.csv.
- Heavy Time Machine matching runs on a native state vector: price structure, volatility, RSI, funding, OI change, long/short, taker ratio, Fear & Greed, spot premium, volume z-score, drawdown and regime code.
