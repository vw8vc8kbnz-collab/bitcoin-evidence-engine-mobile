package main

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"os"
	"sort"
	"strconv"
	"time"
)

type Candle struct {
	Ts            int64
	O, H, L, C, V float64
}
type StateFeature struct {
	Ts                                                                                          int64
	Rsi, Funding, OiChg, LongShort, Taker, Fear, SpotPrem, VolZ, Drawdown, Completeness, Regime float64
}
type ChartPoint struct {
	TimestampMs int64   `json:"timestamp_ms"`
	Open        float64 `json:"open"`
	High        float64 `json:"high"`
	Low         float64 `json:"low"`
	Close       float64 `json:"close"`
	Volume      float64 `json:"volume"`
}
type RandomItem struct {
	Horizon            string                   `json:"horizon"`
	CutoffMs           int64                    `json:"cutoff_ms"`
	DueAtMs            int64                    `json:"due_at_ms"`
	StartPrice         float64                  `json:"start_price"`
	BullishProbability float64                  `json:"bullish_probability"`
	BearishProbability float64                  `json:"bearish_probability"`
	ExpectedMovePct    float64                  `json:"expected_move_pct"`
	ExpectedPrice      float64                  `json:"expected_price"`
	Confidence         float64                  `json:"confidence"`
	EvidenceCount      int                      `json:"evidence_count"`
	ActualPrice        float64                  `json:"actual_price"`
	ActualHigh         float64                  `json:"actual_high"`
	ActualLow          float64                  `json:"actual_low"`
	ActualMovePct      float64                  `json:"actual_move_pct"`
	DirectionCorrect   bool                     `json:"direction_correct"`
	TargetTouched      bool                     `json:"target_touched"`
	TargetReached      bool                     `json:"target_reached"`
	PartialReached     bool                     `json:"partial_reached"`
	OutcomeTier        string                   `json:"outcome_tier"`
	OutcomeLabel       string                   `json:"outcome_label"`
	OutcomeExplain     string                   `json:"outcome_explain"`
	InvalidationPrice  float64                  `json:"invalidation_price"`
	Invalidated        bool                     `json:"invalidated"`
	TargetGapPct       float64                  `json:"target_gap_pct"`
	PriceErrorPct      float64                  `json:"price_error_pct"`
	TotalScore         float64                  `json:"total_score"`
	TargetScore        float64                  `json:"target_score"`
	Contributions      []map[string]interface{} `json:"contributions"`
	StateDiagnostics   map[string]interface{}   `json:"state_diagnostics,omitempty"`
	Status             string                   `json:"status"`
}
type Summary struct {
	Total              int     `json:"total"`
	Correct            int     `json:"correct"`
	Partial            int     `json:"partial"`
	Hitrate            float64 `json:"hitrate"`
	HitrateWithPartial float64 `json:"hitrate_with_partial"`
	AvgScore           float64 `json:"avg_score"`
	AvgError           float64 `json:"avg_error"`
}
type SumAcc struct {
	total, correct, partial int
	score, err              float64
}

var horizons = []string{"1h", "4h", "8h", "24h", "7d", "30d", "90d"}
var steps = []int{1, 4, 8, 24, 168, 720, 2160}
var partials = []float64{0.18, 0.28, 0.38, 0.55, 0.90, 1.60, 2.40}
var baseTargets = []float64{0.35, 0.90, 1.35, 2.40, 6.50, 14.00, 30.00}

var stateDimNames = []string{
	"return_4h", "return_24h", "return_7d", "ma20_distance", "ma50_distance", "volatility_24",
	"rsi_state", "funding_rate", "open_interest_change_24h", "long_short_ratio", "taker_buy_sell_ratio",
	"fear_greed", "spot_premium", "volume_zscore", "drawdown_from_ath", "data_completeness", "regime_code",
}

func nonZeroRate(vec [][]float64, start int, end int, k int) float64 {
	if end <= start {
		return 0
	}
	cnt := 0
	for j := start; j < end; j++ {
		if math.Abs(vec[j][k]) > 1e-9 {
			cnt++
		}
	}
	return float64(cnt) / float64(end-start)
}

func weightedMedian(vals []float64, weights []float64) float64 {
	if len(vals) == 0 {
		return 0
	}
	type VW struct{ v, w float64 }
	pairs := make([]VW, len(vals))
	total := 0.0
	for i := range vals {
		pairs[i] = VW{vals[i], weights[i]}
		total += weights[i]
	}
	sort.Slice(pairs, func(i, j int) bool { return pairs[i].v < pairs[j].v })
	acc := 0.0
	for _, p := range pairs {
		acc += p.w
		if acc >= total*0.5 {
			return p.v
		}
	}
	return pairs[len(pairs)-1].v
}

func pct(a, b float64) float64 {
	if b == 0 {
		return 0
	}
	return (a/b - 1) * 100
}
func clamp(v, a, b float64) float64 {
	if v < a {
		return a
	}
	if v > b {
		return b
	}
	return v
}
func median(vals []float64) float64 {
	n := len(vals)
	if n == 0 {
		return 0
	}
	cp := append([]float64(nil), vals...)
	sort.Float64s(cp)
	if n%2 == 1 {
		return cp[n/2]
	}
	return (cp[n/2-1] + cp[n/2]) / 2
}
func maxSlice(a []float64) float64 {
	if len(a) == 0 {
		return 0
	}
	m := a[0]
	for _, v := range a {
		if v > m {
			m = v
		}
	}
	return m
}
func minSlice(a []float64) float64 {
	if len(a) == 0 {
		return 0
	}
	m := a[0]
	for _, v := range a {
		if v < m {
			m = v
		}
	}
	return m
}
func rollingMean(a []float64, n int) []float64 {
	out := make([]float64, len(a))
	sum := 0.0
	for i, v := range a {
		sum += v
		if i >= n {
			sum -= a[i-n]
		}
		if i >= n-1 {
			out[i] = sum / float64(n)
		} else {
			out[i] = v
		}
	}
	return out
}
func rollingStdReturns(close []float64, n int) []float64 {
	r := make([]float64, len(close))
	for i := 1; i < len(close); i++ {
		r[i] = pct(close[i], close[i-1])
	}
	out := make([]float64, len(close))
	for i := range close {
		if i < n {
			continue
		}
		mean := 0.0
		for j := i - n + 1; j <= i; j++ {
			mean += r[j]
		}
		mean /= float64(n)
		varr := 0.0
		for j := i - n + 1; j <= i; j++ {
			d := r[j] - mean
			varr += d * d
		}
		out[i] = math.Sqrt(varr / float64(n))
	}
	return out
}

func readCSV(path string) ([]Candle, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	recs, err := csv.NewReader(f).ReadAll()
	if err != nil {
		return nil, err
	}
	out := make([]Candle, 0, len(recs))
	for i, r := range recs {
		if i == 0 {
			continue
		}
		if len(r) < 6 {
			continue
		}
		ts, _ := strconv.ParseInt(r[0], 10, 64)
		o, _ := strconv.ParseFloat(r[1], 64)
		h, _ := strconv.ParseFloat(r[2], 64)
		l, _ := strconv.ParseFloat(r[3], 64)
		c, _ := strconv.ParseFloat(r[4], 64)
		v, _ := strconv.ParseFloat(r[5], 64)
		if ts > 0 && o > 0 && h > 0 && l > 0 && c > 0 {
			out = append(out, Candle{ts, o, h, l, c, v})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Ts < out[j].Ts })
	return out, nil
}

func parseFloatCell(v string) float64 {
	x, err := strconv.ParseFloat(v, 64)
	if err != nil || math.IsNaN(x) || math.IsInf(x, 0) {
		return 0
	}
	return x
}
func readFeatureCSV(path string) ([]StateFeature, error) {
	if path == "" {
		return nil, nil
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, nil
	}
	defer f.Close()
	recs, err := csv.NewReader(f).ReadAll()
	if err != nil || len(recs) < 2 {
		return nil, nil
	}
	out := make([]StateFeature, 0, len(recs))
	for i, r := range recs {
		if i == 0 {
			continue
		}
		if len(r) < 12 {
			continue
		}
		ts, _ := strconv.ParseInt(r[0], 10, 64)
		if ts <= 0 {
			continue
		}
		out = append(out, StateFeature{Ts: ts, Rsi: parseFloatCell(r[1]), Funding: parseFloatCell(r[2]), OiChg: parseFloatCell(r[3]), LongShort: parseFloatCell(r[4]), Taker: parseFloatCell(r[5]), Fear: parseFloatCell(r[6]), SpotPrem: parseFloatCell(r[7]), VolZ: parseFloatCell(r[8]), Drawdown: parseFloatCell(r[9]), Completeness: parseFloatCell(r[10]), Regime: parseFloatCell(r[11])})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Ts < out[j].Ts })
	return out, nil
}
func regimeCode(s string) float64 {
	switch s {
	case "bull_trend":
		return 1.0
	case "bear_trend":
		return -1.0
	case "high_volatility":
		return 0.5
	case "range":
		return 0.0
	case "capitulation":
		return -0.75
	default:
		return 0.0
	}
}

func readWeightCSV(path string) map[string]float64 {
	out := map[string]float64{}
	if path == "" {
		return out
	}
	f, err := os.Open(path)
	if err != nil {
		return out
	}
	defer f.Close()
	recs, err := csv.NewReader(f).ReadAll()
	if err != nil {
		return out
	}
	for i, r := range recs {
		if i == 0 || len(r) < 2 {
			continue
		}
		w := parseFloatCell(r[1])
		if w > 0 && !math.IsNaN(w) && !math.IsInf(w, 0) {
			out[r[0]] = clamp(w, 0.10, 3.50)
		}
	}
	return out
}

func alignFeatures(ts []int64, feats []StateFeature) []StateFeature {
	out := make([]StateFeature, len(ts))
	if len(feats) == 0 {
		return out
	}
	j := 0
	cur := StateFeature{}
	for i, t := range ts {
		for j < len(feats) && feats[j].Ts <= t {
			cur = feats[j]
			j++
		}
		out[i] = cur
	}
	return out
}
func prepState(c []Candle, feats []StateFeature) (ts []int64, openA, highA, lowA, closeA, volA []float64, vec [][]float64, aligned []StateFeature) {
	ts, openA, highA, lowA, closeA, volA, base := prep(c)
	aligned = alignFeatures(ts, feats)
	vec = make([][]float64, len(c))
	for i := range c {
		f := aligned[i]
		// State Vector V10.12: price structure + volume + external market state.
		// Normalized/bucketed enough that missing external values do not dominate.
		rsiState := (f.Rsi - 50.0) / 20.0
		fearState := (f.Fear - 50.0) / 25.0
		fundingState := f.Funding * 10000.0
		oiState := f.OiChg
		longShortState := 0.0
		if f.LongShort > 0 {
			longShortState = math.Log(math.Max(0.05, f.LongShort))
		}
		takerState := f.Taker - 1.0
		spotState := f.SpotPrem
		volZState := f.VolZ
		drawdownState := f.Drawdown / 20.0
		completeness := f.Completeness
		vec[i] = []float64{base[i][0], base[i][1], base[i][2], base[i][3], base[i][4], base[i][5], rsiState, fundingState, oiState, longShortState, takerState, fearState, spotState, volZState, drawdownState, completeness, f.Regime}
	}
	return
}

func prep(c []Candle) (ts []int64, openA, highA, lowA, closeA, volA []float64, vec [][6]float64) {
	n := len(c)
	ts = make([]int64, n)
	openA = make([]float64, n)
	highA = make([]float64, n)
	lowA = make([]float64, n)
	closeA = make([]float64, n)
	volA = make([]float64, n)
	for i, x := range c {
		ts[i] = x.Ts
		openA[i] = x.O
		highA[i] = x.H
		lowA[i] = x.L
		closeA[i] = x.C
		volA[i] = x.V
	}
	ma20 := rollingMean(closeA, 20)
	ma50 := rollingMean(closeA, 50)
	vol24 := rollingStdReturns(closeA, 24)
	ret24 := make([]float64, n)
	ret168 := make([]float64, n)
	ret4 := make([]float64, n)
	for i := range closeA {
		if i >= 4 {
			ret4[i] = pct(closeA[i], closeA[i-4])
		}
		if i >= 24 {
			ret24[i] = pct(closeA[i], closeA[i-24])
		}
		if i >= 168 {
			ret168[i] = pct(closeA[i], closeA[i-168])
		}
	}
	vec = make([][6]float64, n)
	for i := range closeA {
		denom := closeA[i]
		if denom == 0 {
			denom = 1
		}
		vec[i] = [6]float64{ret4[i], ret24[i], ret168[i], pct(ma20[i], denom), pct(ma50[i], denom), vol24[i]}
	}
	return
}

func computeItems(c []Candle, idx int, feats []StateFeature, adaptiveWeights map[string]float64) ([]RandomItem, []SumAcc, error) {
	n := len(c)
	if n < 900 {
		return nil, nil, fmt.Errorf("not enough candles")
	}
	ts, openA, highA, lowA, closeA, _, vec, _ := prepState(c, feats)
	if idx < 0 || idx >= n-2 {
		return nil, nil, fmt.Errorf("selected index out of range")
	}
	start := closeA[idx]
	cutoff := ts[idx]
	// Dynamic history window. Older builds required exactly 5000 candles before a point;
	// with a 6M visible chart that made Random 100/1000 return zero. This adapts to the
	// local warehouse while still requiring enough prior candles for a meaningful twin set.
	histStart := idx - 5000
	if histStart < 24*30 {
		histStart = 24 * 30
	}
	histLen := idx - histStart
	if histLen < 220 {
		return nil, nil, fmt.Errorf("not enough historical context before selected point: %d candles", histLen)
	}
	dims := len(vec[idx])
	med := make([]float64, dims)
	sd := make([]float64, dims)
	weights := make([]float64, dims)
	active := make([]bool, dims)
	activeNames := make([]string, 0, dims)
	dimDiag := make([]map[string]interface{}, 0, dims)
	for k := range weights {
		weights[k] = 1.0
	}
	if dims >= 17 {
		// V10.13 State Vector V2: external evidence is allowed to steer the native nearest-state search,
		// but only when that dimension has real historical coverage/variance. This prevents sparse live-only
		// provider data from pretending to be evidence for older cutoffs.
		weights[0] = 1.10  // 4h momentum
		weights[1] = 1.20  // 24h momentum
		weights[2] = 0.90  // 7d momentum
		weights[3] = 0.75  // ma20 distance
		weights[4] = 0.75  // ma50 distance
		weights[5] = 0.95  // volatility
		weights[6] = 0.95  // RSI
		weights[7] = 1.35  // funding
		weights[8] = 1.45  // open interest change
		weights[9] = 0.95  // long/short
		weights[10] = 1.20 // taker ratio
		weights[11] = 0.60 // fear greed
		weights[12] = 1.05 // spot premium
		weights[13] = 0.85 // volume zscore
		weights[14] = 0.75 // drawdown
		weights[15] = 0.25 // completeness (weak guard only)
		weights[16] = 0.55 // regime
	}
	// V10.14.2 Real Adaptive Weight Gate: Python exports weights learned from
	// Time Machine outcomes. Use them conservatively: price structure stays stable,
	// external evidence dimensions can earn more/less vote based on historical proof.
	adaptiveApplied := 0
	for k := 0; k < dims && k < len(stateDimNames); k++ {
		if w, ok := adaptiveWeights[stateDimNames[k]]; ok && w > 0 {
			weights[k] = clamp(w, 0.10, 3.50)
			adaptiveApplied++
		}
	}
	for k := 0; k < dims; k++ {
		vals := make([]float64, 0, histLen)
		for j := histStart; j < idx; j++ {
			vals = append(vals, vec[j][k])
		}
		med[k] = median(vals)
		mean := 0.0
		for _, v := range vals {
			mean += v
		}
		mean /= float64(len(vals))
		varr := 0.0
		for _, v := range vals {
			d := v - mean
			varr += d * d
		}
		sd[k] = math.Sqrt(varr / float64(len(vals)))
		if sd[k] == 0 || math.IsNaN(sd[k]) || math.IsInf(sd[k], 0) {
			sd[k] = 1
		}
		nzr := nonZeroRate(vec, histStart, idx, k)
		// Base OHLC/volume dimensions always stay active; external dimensions require coverage.
		active[k] = k < 6 || nzr >= 0.025 || math.Abs(vec[idx][k]) > 1e-9
		if active[k] {
			name := fmt.Sprintf("dim_%d", k)
			if k < len(stateDimNames) {
				name = stateDimNames[k]
			}
			activeNames = append(activeNames, name)
		}
		name := fmt.Sprintf("dim_%d", k)
		if k < len(stateDimNames) {
			name = stateDimNames[k]
		}
		dimDiag = append(dimDiag, map[string]interface{}{"name": name, "active": active[k], "weight": weights[k], "history_nonzero_rate": nzr, "history_sd": sd[k], "cutoff_value": vec[idx][k]})
	}
	type Pair struct {
		d float64
		j int
	}
	dist := make([]Pair, 0, histLen)
	for j := histStart; j < idx; j++ {
		d := 0.0
		for k := 0; k < dims; k++ {
			if !active[k] {
				continue
			}
			z := (vec[j][k] - vec[idx][k]) / sd[k]
			// hard cap prevents one noisy provider field from dominating all price structure.
			if z > 6 {
				z = 6
			}
			if z < -6 {
				z = -6
			}
			d += weights[k] * z * z
		}
		dist = append(dist, Pair{math.Sqrt(d), j})
	}
	sort.Slice(dist, func(a, b int) bool { return dist[a].d < dist[b].d })
	items := make([]RandomItem, 0, 7)
	sums := make([]SumAcc, 7)
	for h := 0; h < 7; h++ {
		step := steps[h]
		if idx+step >= n { // future truth unavailable; still return forecast context, but mark future_not_available
			step = n - 1 - idx
			if step < 1 {
				step = 1
			}
		}
		cand := make([]Pair, 0, len(dist))
		for _, p := range dist {
			if p.j+step < idx {
				cand = append(cand, p)
			}
		}
		prob := 0.5
		expMove := 0.0
		evidence := len(cand)
		avgNeighborDistance := 0.0
		neighborAgreement := 0.0
		if len(cand) >= 50 {
			take := 320
			if len(cand) < take {
				take = len(cand)
			}
			moves := make([]float64, 0, take)
			wts := make([]float64, 0, take)
			posW := 0.0
			totalW := 0.0
			meanMove := 0.0
			for q := 0; q < take; q++ {
				ci := cand[q].j
				mv := pct(closeA[ci+step], closeA[ci])
				w := 1.0 / math.Pow(0.45+cand[q].d, 1.55)
				moves = append(moves, mv)
				wts = append(wts, w)
				totalW += w
				meanMove += mv * w
				avgNeighborDistance += cand[q].d
				if mv > 0 {
					posW += w
				}
			}
			prob = posW / totalW
			meanMove = meanMove / totalW
			medMove := weightedMedian(moves, wts)
			expMove = 0.62*medMove + 0.38*meanMove
			neighborAgreement = math.Abs(prob - 0.5) * 2.0
			if idx >= 24 {
				expMove += 0.08 * pct(closeA[idx], closeA[idx-24])
			}
			if idx >= 168 {
				expMove += 0.025 * pct(closeA[idx], closeA[idx-168])
			}
			evidence = take
			avgNeighborDistance = avgNeighborDistance / float64(take)
		}

		// V10.16.12 Reliable Ensemble Layer:
		// The old native batch used almost only nearest historical states. It was fast,
		// but confidence was over-aggressive and it did not expose enough independent
		// specialist opinions. Blend in small, inspectable model signals using only
		// data available at the cutoff. These signals are deliberately conservative:
		// historical twins remain the anchor, while momentum/trend/RSI/futures/volume
		// can tilt only part of the final probability and target.
		mom4 := 0.0
		mom24 := 0.0
		mom7d := 0.0
		ma20d := 0.0
		ma50d := 0.0
		vol24 := 0.0
		rsiState := 0.0
		fundingState := 0.0
		oiState := 0.0
		longShortState := 0.0
		takerState := 0.0
		fearState := 0.0
		volZState := 0.0
		drawdownState := 0.0
		regimeState := 0.0
		if dims >= 17 {
			mom4 = vec[idx][0]
			mom24 = vec[idx][1]
			mom7d = vec[idx][2]
			ma20d = vec[idx][3]
			ma50d = vec[idx][4]
			vol24 = vec[idx][5]
			rsiState = vec[idx][6]
			fundingState = vec[idx][7]
			oiState = vec[idx][8]
			longShortState = vec[idx][9]
			takerState = vec[idx][10]
			fearState = vec[idx][11]
			volZState = vec[idx][13]
			drawdownState = vec[idx][14]
			regimeState = vec[idx][16]
		}
		momentumScore := clamp(mom4*0.18+mom24*0.055+mom7d*0.018, -2.5, 2.5)
		trendScore := clamp((-ma20d)*0.10+(-ma50d)*0.055+regimeState*0.18, -2.0, 2.0)
		rsiScore := clamp(-rsiState*0.18, -1.2, 1.2) // contrarian: overheated RSI reduces upside, washed-out RSI supports bounce
		futuresScore := clamp(-fundingState*0.06-oiState*0.035+longShortState*(-0.18)+takerState*0.20, -1.8, 1.8)
		flowScore := clamp(volZState*0.055+fearState*(-0.08)+drawdownState*(-0.10), -1.4, 1.4)
		volPenalty := clamp(math.Abs(vol24)/7.5, 0.0, 0.22)
		modelScore := momentumScore*0.26 + trendScore*0.22 + rsiScore*0.14 + futuresScore*0.23 + flowScore*0.15
		modelProb := clamp(0.5+modelScore/5.0, 0.08, 0.92)
		modelMove := modelScore * baseTargets[h] * 0.30
		modelAgreement := 1.0 - clamp(math.Abs((prob-0.5)-(modelProb-0.5))*2.8, 0.0, 1.0)
		blend := clamp(0.18+modelAgreement*0.12, 0.16, 0.30)
		prob = clamp(prob*(1.0-blend)+modelProb*blend, 0.02, 0.98)
		expMove = expMove*(1.0-blend*0.65) + modelMove*(blend*0.65)
		sign := 1.0
		if prob < 0.5 {
			sign = -1
		}
		if math.Abs(prob-0.5) < 0.015 && math.Abs(expMove) > 0.0001 {
			if expMove >= 0 {
				sign = 1
			} else {
				sign = -1
			}
		}
		edge := math.Abs(prob - 0.5)
		floorPct := baseTargets[h] * clamp(0.55+edge*7.0, 0.55, 1.35)
		capPct := baseTargets[h] * 3.0
		if math.Abs(expMove) < floorPct {
			expMove = sign * floorPct
		}
		if math.Abs(expMove) > capPct {
			expMove = sign * capPct
		}
		target := start * (1 + expMove/100)
		distpct := math.Abs(pct(target, start))
		base := math.Max(distpct*0.65, math.Max(partials[h]*1.8, 0.35))
		inv := start * (1 - base/100)
		if expMove < 0 {
			inv = start * (1 + base/100)
		}
		due := idx + steps[h]
		truthAvailable := due < n
		if due >= n {
			due = n - 1
		}
		actual := closeA[due]
		actualMove := pct(actual, start)
		ah := actual
		al := actual
		if due > idx {
			ah = maxSlice(highA[idx+1 : due+1])
			al = minSlice(lowA[idx+1 : due+1])
		}
		up := expMove >= 0
		firstTarget := false
		firstInvalid := false
		if truthAvailable {
			for j := idx + 1; j <= due; j++ {
				th := false
				ih := false
				if up {
					th = highA[j] >= target
					ih = lowA[j] <= inv
				} else {
					th = lowA[j] <= target
					ih = highA[j] >= inv
				}
				if th || ih {
					if th && ih {
						if math.Abs(openA[j]-target) <= math.Abs(openA[j]-inv) {
							firstTarget = true
						} else {
							firstInvalid = true
						}
					} else if th {
						firstTarget = true
					} else {
						firstInvalid = true
					}
					break
				}
			}
		}
		targetTouched := false
		closest := al
		if up {
			targetTouched = truthAvailable && ah >= target
			closest = ah
		} else {
			targetTouched = truthAvailable && al <= target
			closest = al
		}
		gap := pct(closest, target)
		absgap := math.Abs(gap)
		partial := truthAvailable && (!firstTarget && !firstInvalid && absgap <= partials[h])
		score := 0.0
		tier := "fail"
		label := "FAIL doel niet gehaald"
		explain := "doelprijs niet geraakt"
		if firstTarget {
			score = 100
			tier = "win"
			label = "WIN"
			explain = "doel geraakt vóór invalidatie"
		} else if partial {
			score = math.Max(55, math.Min(88, 100-absgap*18))
			tier = "partial"
			label = "PARTIAL"
			explain = "doel bijna geraakt zonder invalidatie"
		} else {
			if firstInvalid {
				score = 0
				label = "FAIL invalidatie"
				explain = "invalidatie werd eerder geraakt"
			} else {
				score = math.Max(0, math.Min(35, 100-absgap*18))
			}
			tier = "fail"
		}
		dirOk := (actualMove >= 0) == (expMove >= 0)
		if truthAvailable {
			sums[h].total++
			if firstTarget {
				sums[h].correct++
			}
			if partial {
				sums[h].partial++
			}
			sums[h].score += score
			sums[h].err += absgap
		}
		status := "revealed"
		if !truthAvailable {
			status = "future_not_available"
		}
		externalActive := 0
		for k := 6; k < dims; k++ {
			if active[k] {
				externalActive++
			}
		}
		extWeight := 0.30 * clamp(float64(externalActive)/8.0, 0.0, 1.0)
		priceWeight := 0.48 - extWeight*0.18
		stateWeight := 0.52 - extWeight*0.10
		modelWeight := math.Max(0.0, 1.0-priceWeight-stateWeight-extWeight)
		distanceQuality := clamp(1.0-avgNeighborDistance/7.5, 0.0, 1.0)
		evidenceQuality := clamp(float64(evidence)/320.0, 0.0, 1.0)
		edgeQuality := clamp(math.Abs(prob-0.5)*2.0, 0.0, 1.0)
		confidence := clamp(14.0+edgeQuality*34.0+evidenceQuality*16.0+distanceQuality*24.0+modelAgreement*10.0-neighborAgreement*volPenalty*18.0+float64(externalActive)*0.65, 8.0, 88.0)
		diag := map[string]interface{}{
			"engine":                "state_vector_v2_adaptive_8y",
			"adaptive_weights_applied": adaptiveApplied,
			"active_dimensions":     activeNames,
			"external_active_count": externalActive,
			"dimension_diagnostics": dimDiag,
			"avg_neighbor_distance": avgNeighborDistance,
			"neighbor_count":        evidence,
			"distance_quality":      distanceQuality,
			"evidence_quality":      evidenceQuality,
			"edge_quality":          edgeQuality,
			"model_agreement":       modelAgreement,
			"confidence_formula":    "v10.16.12 calibrated by edge + neighbor distance + model agreement; no fixed high-confidence evidence boost",
		}
		items = append(items, RandomItem{Horizon: horizons[h], CutoffMs: cutoff, DueAtMs: ts[due], StartPrice: start, BullishProbability: clamp(prob, 0.01, 0.99), BearishProbability: 1 - clamp(prob, 0.01, 0.99), ExpectedMovePct: expMove, ExpectedPrice: target, Confidence: confidence, EvidenceCount: evidence, ActualPrice: actual, ActualHigh: ah, ActualLow: al, ActualMovePct: actualMove, DirectionCorrect: dirOk, TargetTouched: targetTouched, TargetReached: firstTarget, PartialReached: partial, OutcomeTier: tier, OutcomeLabel: label, OutcomeExplain: explain, InvalidationPrice: inv, Invalidated: firstInvalid, TargetGapPct: gap, PriceErrorPct: actualMove - expMove, TotalScore: score, TargetScore: math.Max(0, 100-absgap*18), Contributions: []map[string]interface{}{{"model_id": "NATIVE_STATE_VECTOR_V2", "name": "Native Historical State Vector V2 Adaptive 8Y", "weight": stateWeight, "evidence_count": evidence, "active_dimensions": len(activeNames)}, {"model_id": "PRICE_STRUCTURE", "name": "OHLC/volume structure", "weight": priceWeight, "evidence_count": evidence}, {"model_id": "SPECIALIST_ENSEMBLE_V1", "name": "Momentum/Trend/RSI/Flow/Futures ensemble", "weight": modelWeight, "evidence_count": evidence, "model_probability": modelProb, "model_score": modelScore, "agreement": modelAgreement}, {"model_id": "EXTERNAL_EVIDENCE_STATE", "name": "Funding/OI/sentiment/spot context", "weight": extWeight, "evidence_count": evidence, "external_active_count": externalActive}}, StateDiagnostics: diag, Status: status})
	}
	return items, sums, nil
}

func summaryFromSums(sums []SumAcc) map[string]Summary {
	sm := map[string]Summary{}
	for h := 0; h < 7; h++ {
		total := sums[h].total
		s := Summary{Total: total, Correct: sums[h].correct, Partial: sums[h].partial}
		if total > 0 {
			s.Hitrate = float64(sums[h].correct) / float64(total)
			s.HitrateWithPartial = float64(sums[h].correct+sums[h].partial) / float64(total)
			s.AvgScore = sums[h].score / float64(total)
			s.AvgError = sums[h].err / float64(total)
		}
		sm[horizons[h]] = s
	}
	return sm
}

func tmSingle(csvPath string, featurePath string, weightPath string, cutoff int64, outPath string) error {
	t0 := time.Now()
	candles, err := readCSV(csvPath)
	if err != nil {
		return err
	}
	feats, _ := readFeatureCSV(featurePath)
	adaptiveWeights := readWeightCSV(weightPath)
	if len(candles) < 900 {
		return fmt.Errorf("not enough candles")
	}
	idx := sort.Search(len(candles), func(i int) bool { return candles[i].Ts >= cutoff })
	if idx >= len(candles) {
		idx = len(candles) - 1
	}
	if idx > 0 && math.Abs(float64(candles[idx-1].Ts-cutoff)) < math.Abs(float64(candles[idx].Ts-cutoff)) {
		idx--
	}
	items, sums, err := computeItems(candles, idx, feats, adaptiveWeights)
	if err != nil {
		return err
	}
	out := map[string]interface{}{"ok": true, "mode": "native_cpp_single", "engine_version": "v10.14.2-real-adaptive-learning", "cutoff_ms": candles[idx].Ts, "start_price": candles[idx].C, "selected_candle": map[string]interface{}{"timestamp_ms": candles[idx].Ts, "open": candles[idx].O, "high": candles[idx].H, "low": candles[idx].L, "close": candles[idx].C, "volume": candles[idx].V}, "items": items, "summary": summaryFromSums(sums), "elapsed_ms": time.Since(t0).Milliseconds()}
	b, _ := json.Marshal(out)
	return os.WriteFile(outPath, b, 0644)
}

func tmRandom(csvPath string, featurePath string, weightPath string, count int, seed int64, outPath string) error {
	t0 := time.Now()
	candles, err := readCSV(csvPath)
	if err != nil {
		return err
	}
	feats, _ := readFeatureCSV(featurePath)
	adaptiveWeights := readWeightCSV(weightPath)
	n := len(candles)
	maxSteps := 2160
	if n < maxSteps+900 {
		return fmt.Errorf("not enough candles")
	}
	// Dynamic eligible range: enough prior history for twins and enough future truth for 90d.
	eligibleStart := 24 * 30
	if n > 9000 {
		eligibleStart = 5000
	} else if n > 5200 {
		eligibleStart = 1200
	}
	eligibleEnd := n - maxSteps - 2
	if eligibleEnd <= eligibleStart {
		return fmt.Errorf("no eligible points: n=%d start=%d end=%d", n, eligibleStart, eligibleEnd)
	}
	eligible := make([]int, 0, eligibleEnd-eligibleStart)
	for i := eligibleStart; i < eligibleEnd; i++ {
		eligible = append(eligible, i)
	}
	rng := rand.New(rand.NewSource(seed))
	rng.Shuffle(len(eligible), func(i, j int) { eligible[i], eligible[j] = eligible[j], eligible[i] })
	if count < 1 {
		count = 1
	}
	if count > 10000 {
		count = 10000
	}
	if len(eligible) < count {
		count = len(eligible)
	}
	eligible = eligible[:count]
	all := make([]RandomItem, 0, count*7)
	sums := make([]SumAcc, 7)
	for _, idx := range eligible {
		items, ss, err := computeItems(candles, idx, feats, adaptiveWeights)
		if err != nil {
			continue
		}
		all = append(all, items...)
		for h := 0; h < 7; h++ {
			sums[h].total += ss[h].total
			sums[h].correct += ss[h].correct
			sums[h].partial += ss[h].partial
			sums[h].score += ss[h].score
			sums[h].err += ss[h].err
		}
	}
	out := map[string]interface{}{"ok": true, "mode": "native_cpp_random", "engine_version": "v10.14.2-real-adaptive-learning", "items": all, "summary": summaryFromSums(sums), "count": count, "items_logged": len(all), "elapsed_ms": time.Since(t0).Milliseconds()}
	b, _ := json.Marshal(out)
	return os.WriteFile(outPath, b, 0644)
}

func chartOHLC(csvPath string, bucketHours int, limit int, outPath string) error {
	t0 := time.Now()
	candles, err := readCSV(csvPath)
	if err != nil {
		return err
	}
	if bucketHours < 1 {
		bucketHours = 1
	}
	if limit < 50 {
		limit = 50
	}
	if limit > 50000 {
		limit = 50000
	}
	bucketMs := int64(bucketHours) * 3600 * 1000
	pts := make([]ChartPoint, 0)
	var cur int64 = -1
	var p ChartPoint
	init := false
	for _, x := range candles {
		b := (x.Ts / bucketMs) * bucketMs
		if !init || b != cur {
			if init {
				pts = append(pts, p)
			}
			p = ChartPoint{TimestampMs: x.Ts, Open: x.O, High: x.H, Low: x.L, Close: x.C, Volume: x.V}
			cur = b
			init = true
		} else {
			if x.H > p.High {
				p.High = x.H
			}
			if x.L < p.Low {
				p.Low = x.L
			}
			p.Close = x.C
			p.Volume += x.V
		}
	}
	if init {
		pts = append(pts, p)
	}
	raw := len(pts)
	if len(pts) > limit {
		step := float64(len(pts)) / float64(limit)
		ds := make([]ChartPoint, 0, limit)
		last := -1
		for i := 0; i < limit; i++ {
			idx := int(math.Floor(float64(i) * step))
			if idx >= len(pts) {
				idx = len(pts) - 1
			}
			if idx != last {
				ds = append(ds, pts[idx])
				last = idx
			}
		}
		if ds[len(ds)-1].TimestampMs != pts[len(pts)-1].TimestampMs {
			ds = append(ds, pts[len(pts)-1])
		}
		pts = ds
	}
	out := map[string]interface{}{"ok": true, "mode": "native_cpp_chart", "points": pts, "count": len(pts), "raw_count": raw, "bucket_hours": bucketHours, "elapsed_ms": time.Since(t0).Milliseconds()}
	b, _ := json.Marshal(out)
	return os.WriteFile(outPath, b, 0644)
}

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: bee_native_core tm_single|tm_random|chart_ohlc ...")
		os.Exit(1)
	}
	var err error
	switch os.Args[1] {
	case "chart_ohlc":
		if len(os.Args) < 6 {
			fmt.Fprintln(os.Stderr, "chart_ohlc needs candles.csv bucket_hours limit output.json")
			os.Exit(1)
		}
		bh, _ := strconv.Atoi(os.Args[3])
		lim, _ := strconv.Atoi(os.Args[4])
		err = chartOHLC(os.Args[2], bh, lim, os.Args[5])
	case "tm_random":
		if len(os.Args) < 8 {
			fmt.Fprintln(os.Stderr, "tm_random needs candles.csv features.csv adaptive_weights.csv count seed output.json")
			os.Exit(1)
		}
		cnt, _ := strconv.Atoi(os.Args[5])
		seed, _ := strconv.ParseInt(os.Args[6], 10, 64)
		err = tmRandom(os.Args[2], os.Args[3], os.Args[4], cnt, seed, os.Args[7])
	case "tm_single":
		if len(os.Args) < 7 {
			fmt.Fprintln(os.Stderr, "tm_single needs candles.csv features.csv adaptive_weights.csv cutoff_ms output.json")
			os.Exit(1)
		}
		cutoff, _ := strconv.ParseInt(os.Args[5], 10, 64)
		err = tmSingle(os.Args[2], os.Args[3], os.Args[4], cutoff, os.Args[6])
	default:
		fmt.Fprintln(os.Stderr, "unknown command")
		os.Exit(1)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(2)
	}
}
