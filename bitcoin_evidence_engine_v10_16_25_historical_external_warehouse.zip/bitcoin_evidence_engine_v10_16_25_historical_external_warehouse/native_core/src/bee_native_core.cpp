// Bitcoin Evidence Engine Native Core V10.9
// Purpose: accelerate heavy Time Machine random backtests and chart aggregation outside Python loops.
// Build Windows: native_core\\build_native_core.bat
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <vector>

struct Candle { long long ts; double o,h,l,c,v; };
struct Vec6 { double x[6]; };
static const char* HORIZONS[] = {"1h","4h","8h","24h","7d","30d","90d"};
static const int STEPS[] = {1,4,8,24,168,720,2160};
static const double PARTIALS[] = {0.18,0.28,0.38,0.55,0.90,1.60,2.40};
static const double BASE_TARGETS[] = {0.35,0.90,1.35,2.40,6.50,14.00,30.00};

static double pct(double a, double b){ return (b==0.0 ? 0.0 : ((a/b)-1.0)*100.0); }
static double clamp(double x, double lo, double hi){ return std::max(lo, std::min(hi, x)); }
static std::string esc(const std::string& s){ std::string o; for(char c:s){ if(c=='"') o += "\\\""; else if(c=='\\') o += "\\\\"; else o += c; } return o; }

static bool read_csv(const std::string& path, std::vector<Candle>& out){
    std::ifstream f(path); if(!f) return false;
    std::string line; std::getline(f,line); // header
    while(std::getline(f,line)){
        if(line.empty()) continue;
        std::stringstream ss(line); std::string cell; std::vector<std::string> cols;
        while(std::getline(ss, cell, ',')) cols.push_back(cell);
        if(cols.size() < 6) continue;
        try { out.push_back({std::stoll(cols[0]), std::stod(cols[1]), std::stod(cols[2]), std::stod(cols[3]), std::stod(cols[4]), std::stod(cols[5])}); }
        catch(...) { }
    }
    return !out.empty();
}

static std::vector<double> rolling_mean(const std::vector<double>& x, int period){
    std::vector<double> r(x.size(), 0.0); double sum=0.0;
    for(size_t i=0;i<x.size();++i){ sum += x[i]; if((int)i>=period) sum -= x[i-period]; int denom = std::min<int>(period, i+1); r[i]=sum/std::max(1,denom); }
    return r;
}
static std::vector<double> rolling_std_returns(const std::vector<double>& close, int period){
    std::vector<double> ret(close.size(),0.0), r(close.size(),0.0);
    for(size_t i=1;i<close.size();++i) ret[i] = pct(close[i], close[i-1]);
    for(size_t i=0;i<close.size();++i){
        int a = (int)std::max<long long>(0, (long long)i-period+1); int n = (int)i-a+1;
        double mean=0; for(int j=a;j<=(int)i;++j) mean += ret[j]; mean /= std::max(1,n);
        double var=0; for(int j=a;j<=(int)i;++j){ double d=ret[j]-mean; var += d*d; }
        r[i] = std::sqrt(var/std::max(1,n));
    }
    return r;
}
static double median(std::vector<double> v){
    if(v.empty()) return 0.0; size_t m=v.size()/2; std::nth_element(v.begin(), v.begin()+m, v.end()); double a=v[m];
    if(v.size()%2==0){ std::nth_element(v.begin(), v.begin()+m-1, v.end()); a=(a+v[m-1])*0.5; }
    return a;
}

static void write_json_string(std::ofstream& o, const std::string& s){ o << '"' << esc(s) << '"'; }

static int tm_random(const std::string& csv, int count, unsigned seed, const std::string& out_path){
    auto t0 = std::chrono::high_resolution_clock::now();
    std::vector<Candle> candles; if(!read_csv(csv, candles)){ std::cerr << "could not read candles csv\n"; return 2; }
    const int n = (int)candles.size();
    const int max_steps = 2160;
    if(n < max_steps + 500){ std::cerr << "not enough candles\n"; return 3; }
    std::vector<long long> ts(n); std::vector<double> open(n), high(n), low(n), close(n), vol(n);
    for(int i=0;i<n;++i){ ts[i]=candles[i].ts; open[i]=candles[i].o; high[i]=candles[i].h; low[i]=candles[i].l; close[i]=candles[i].c; vol[i]=candles[i].v; }
    std::vector<double> ret4(n), ret24(n), ret168(n), dd(n), volratio(n);
    for(int i=0;i<n;++i){ ret4[i]=(i>=4?pct(close[i],close[i-4]):0); ret24[i]=(i>=24?pct(close[i],close[i-24]):0); ret168[i]=(i>=168?pct(close[i],close[i-168]):0); }
    auto vol24 = rolling_std_returns(close,24); auto vma24=rolling_mean(vol,24); auto vma168=rolling_mean(vol,168);
    for(int i=0;i<n;++i){ int a=std::max(0,i-2160+1); double mx=close[a]; for(int j=a;j<=i;++j) mx=std::max(mx,close[j]); dd[i]=pct(close[i], std::max(mx,1e-9)); volratio[i]=vma24[i]/std::max(vma168[i],1e-9); }
    std::vector<Vec6> vec(n); for(int i=0;i<n;++i){ vec[i]={{ret4[i],ret24[i],ret168[i],vol24[i],dd[i],std::isfinite(volratio[i])?volratio[i]:0.0}}; }
    int eligible_start=24*120, eligible_end=n-max_steps-2; if(eligible_end<=eligible_start){ std::cerr << "no eligible points\n"; return 4; }
    std::vector<int> eligible; eligible.reserve(eligible_end-eligible_start); for(int i=eligible_start;i<eligible_end;++i) eligible.push_back(i);
    std::mt19937 rng(seed ? seed : (unsigned)std::chrono::high_resolution_clock::now().time_since_epoch().count()); std::shuffle(eligible.begin(), eligible.end(), rng);
    count = std::max(1, std::min(count, 10000)); if((int)eligible.size() < count) count = (int)eligible.size(); eligible.resize(count);
    struct Sum { int total=0, correct=0, partial=0; double score=0, err=0; }; Sum sums[7];
    std::ofstream o(out_path); if(!o){ std::cerr << "could not open output\n"; return 5; }
    o << std::fixed << std::setprecision(8);
    o << "{\"ok\":true,\"mode\":\"native_cpp\",\"engine_version\":\"v10.9-native-enforced\",\"items\":[";
    bool firstItem=true; int example_count=0; std::ostringstream examples;
    for(int sample_i=0; sample_i<count; ++sample_i){
        int idx=eligible[sample_i]; double start=close[idx]; long long cutoff=ts[idx];
        if(example_count<20){ if(example_count) examples << ","; examples << "{\"cutoff_ms\":" << cutoff << ",\"start_price\":" << start << "}"; example_count++; }
        int hist_start=std::max(24*30, idx-5000); int hist_len=idx-hist_start; if(hist_len<300) continue;
        double med[6]={0}, sd[6]={0};
        for(int k=0;k<6;++k){ std::vector<double> vals; vals.reserve(hist_len); for(int j=hist_start;j<idx;++j) vals.push_back(vec[j].x[k]); med[k]=median(vals); double mean=std::accumulate(vals.begin(),vals.end(),0.0)/vals.size(); double var=0; for(double v:vals){ double d=v-mean; var += d*d; } sd[k]=std::sqrt(var/std::max<size_t>(1,vals.size())); if(sd[k]==0 || !std::isfinite(sd[k])) sd[k]=1.0; }
        std::vector<std::pair<double,int>> dist; dist.reserve(hist_len);
        for(int j=hist_start;j<idx;++j){ double d=0; for(int k=0;k<6;++k){ double z=(vec[j].x[k]-vec[idx].x[k])/sd[k]; d += z*z; } dist.emplace_back(std::sqrt(d),j); }
        for(int h=0;h<7;++h){
            int steps=STEPS[h]; std::vector<std::pair<double,int>> cand; cand.reserve(dist.size()); for(auto &p:dist) if(p.second+steps<idx) cand.push_back(p);
            double prob=0.5, exp_move=0; int evidence=(int)cand.size();
            if((int)cand.size()>=80){ int take=std::min(180,(int)cand.size()); std::nth_element(cand.begin(), cand.begin()+take, cand.end()); std::vector<double> moves; moves.reserve(take); int pos=0; for(int q=0;q<take;++q){ int ci=cand[q].second; double mv=pct(close[ci+steps], close[ci]); moves.push_back(mv); if(mv>0) pos++; } prob=(double)pos/take; exp_move=median(moves) + 0.12*ret24[idx] + 0.035*ret168[idx]; evidence=take; }
            // V10.9: target calibration floor. Prevent meaningless $50-$100 targets
            // on BTC when a horizon normally moves much more. Probability still
            // communicates edge strength; target distance must remain practical.
            double sign = (prob >= 0.5 ? 1.0 : -1.0);
            if(std::abs(prob-0.5) < 0.015 && std::abs(exp_move) > 0.0001) sign = exp_move >= 0 ? 1.0 : -1.0;
            double edge = std::abs(prob-0.5);
            double floor_pct = BASE_TARGETS[h] * clamp(0.55 + edge*7.0, 0.55, 1.35);
            double cap_pct = BASE_TARGETS[h] * 3.0;
            if(std::abs(exp_move) < floor_pct) exp_move = sign * floor_pct;
            if(std::abs(exp_move) > cap_pct) exp_move = sign * cap_pct;
            double target=start*(1.0+exp_move/100.0); double distpct=std::abs(pct(target,start)); double base=std::max({distpct*0.65, PARTIALS[h]*1.8, 0.35}); double inv = exp_move>=0 ? start*(1.0-base/100.0) : start*(1.0+base/100.0);
            int due=std::min(n-1, idx+steps); bool up=exp_move>=0, first_target=false, first_invalid=false;
            double ah=close[due], al=close[due]; if(due>idx){ ah=*std::max_element(high.begin()+idx+1, high.begin()+due+1); al=*std::min_element(low.begin()+idx+1, low.begin()+due+1); }
            for(int j=idx+1;j<=due;++j){ bool th=up ? high[j]>=target : low[j]<=target; bool ih=up ? low[j]<=inv : high[j]>=inv; if(th||ih){ if(th&&ih){ if(std::abs(open[j]-target)<=std::abs(open[j]-inv)) first_target=true; else first_invalid=true; } else if(th) first_target=true; else first_invalid=true; break; } }
            bool target_touched = due>idx ? (up ? ah>=target : al<=target) : false; double actual=close[due]; double actual_move=pct(actual,start); bool dir_ok=(actual_move>=0)==(exp_move>=0); double closest=up?ah:al; double gap=pct(closest,target); double absgap=std::abs(gap); bool partial=(!first_target && !first_invalid && absgap<=PARTIALS[h]); double score=0; std::string tier="fail"; if(first_target){score=100; tier="win";} else if(partial){score=std::max(55.0,std::min(88.0,100-absgap*18)); tier="partial";} else {score=first_invalid?0:std::max(0.0,std::min(35.0,100-absgap*18)); tier="fail";}
            sums[h].total++; if(first_target) sums[h].correct++; if(partial) sums[h].partial++; sums[h].score += score; sums[h].err += absgap;
            if(!firstItem) o << ","; firstItem=false;
            o << "{\"horizon\":"; write_json_string(o,HORIZONS[h]);
            o << ",\"cutoff_ms\":" << cutoff << ",\"due_at_ms\":" << ts[due] << ",\"start_price\":" << start
              << ",\"bullish_probability\":" << clamp(prob,0.01,0.99) << ",\"bearish_probability\":" << (1.0-clamp(prob,0.01,0.99))
              << ",\"expected_move_pct\":" << exp_move << ",\"expected_price\":" << target << ",\"confidence\":" << std::min(94.0,30.0+evidence/5.0+std::abs(prob-0.5)*90.0)
              << ",\"evidence_count\":" << evidence << ",\"actual_price\":" << actual << ",\"actual_high\":" << ah << ",\"actual_low\":" << al
              << ",\"actual_move_pct\":" << actual_move << ",\"direction_correct\":" << (dir_ok?"true":"false") << ",\"target_touched\":" << (target_touched?"true":"false")
              << ",\"target_reached\":" << (first_target?"true":"false") << ",\"partial_reached\":" << (partial?"true":"false") << ",\"outcome_tier\":"; write_json_string(o,tier);
            o << ",\"invalidation_price\":" << inv << ",\"invalidated\":" << (first_invalid?"true":"false") << ",\"target_gap_pct\":" << gap
              << ",\"price_error_pct\":" << (actual_move-exp_move) << ",\"total_score\":" << score << ",\"contributions\":[{\"model_id\":\"CPP_FAST_TWIN\",\"name\":\"C++ Fast Historical Twin Batch\",\"weight\":1,\"evidence_count\":" << evidence << "}]}";
        }
    }
    auto t1=std::chrono::high_resolution_clock::now(); long long elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(t1-t0).count();
    o << "],\"summary\":{";
    for(int h=0;h<7;++h){ if(h) o << ","; o << "\"" << HORIZONS[h] << "\":{"; int total=sums[h].total; double hit=total?(double)sums[h].correct/total:0; double hitp=total?(double)(sums[h].correct+sums[h].partial)/total:0; double avgs=total?sums[h].score/total:0; double avge=total?sums[h].err/total:0; o << "\"total\":" << total << ",\"correct\":" << sums[h].correct << ",\"partial\":" << sums[h].partial << ",\"hitrate\":" << hit << ",\"hitrate_with_partial\":" << hitp << ",\"avg_score\":" << avgs << ",\"avg_error\":" << avge << "}"; }
    o << "},\"examples\":[" << examples.str() << "],\"count\":" << count << ",\"elapsed_ms\":" << elapsed << "}";
    return 0;
}


static int chart_ohlc(const std::string& csv, int bucket_hours, int limit, const std::string& out_path){
    auto t0 = std::chrono::high_resolution_clock::now();
    std::vector<Candle> candles; if(!read_csv(csv, candles)){ std::cerr << "could not read candles csv\n"; return 2; }
    bucket_hours = std::max(1, bucket_hours);
    limit = std::max(50, std::min(limit, 50000));
    long long bucket_ms = (long long)bucket_hours * 3600LL * 1000LL;
    struct Agg { long long ts=0; double o=0,h=0,l=0,c=0,v=0; bool init=false; };
    std::vector<Agg> aggs;
    long long cur_bucket = -1;
    Agg a;
    for(const auto& x: candles){
        long long b = (x.ts / bucket_ms) * bucket_ms;
        if(!a.init || b != cur_bucket){
            if(a.init) aggs.push_back(a);
            a = Agg(); a.init=true; a.ts=x.ts; a.o=x.o; a.h=x.h; a.l=x.l; a.c=x.c; a.v=x.v; cur_bucket=b;
        } else {
            a.h = std::max(a.h, x.h); a.l = std::min(a.l, x.l); a.c=x.c; a.v += x.v;
        }
    }
    if(a.init) aggs.push_back(a);
    int raw_count = (int)aggs.size();
    std::vector<int> keep;
    if(raw_count <= limit){ for(int i=0;i<raw_count;++i) keep.push_back(i); }
    else {
        // Even sampling keeps the visible range shape while limiting browser draw cost.
        double step = (double)raw_count / (double)limit;
        for(int i=0;i<limit;++i){ int idx=(int)std::floor(i*step); if(idx>=raw_count) idx=raw_count-1; keep.push_back(idx); }
        if(!keep.empty()) keep.back() = raw_count-1;
    }
    auto t1 = std::chrono::high_resolution_clock::now();
    long long elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(t1-t0).count();
    std::ofstream o(out_path); if(!o){ std::cerr << "could not open output\n"; return 5; }
    o << std::fixed << std::setprecision(8);
    o << "{\"ok\":true,\"mode\":\"native_cpp_chart\",\"engine_version\":\"v10.9-native-chart\",\"count\":" << keep.size() << ",\"raw_count\":" << raw_count << ",\"elapsed_ms\":" << elapsed << ",\"points\":[";
    for(size_t k=0;k<keep.size();++k){ const auto& x=aggs[keep[k]]; if(k) o << ","; o << "{\"timestamp_ms\":" << x.ts << ",\"open\":" << x.o << ",\"high\":" << x.h << ",\"low\":" << x.l << ",\"close\":" << x.c << ",\"volume\":" << x.v << "}"; }
    o << "]}";
    return 0;
}

int main(int argc, char** argv){
    if(argc < 2){ std::cerr << "usage: bee_native_core tm_random candles.csv count seed output.json\n"; return 1; }
    std::string cmd=argv[1];
    if(cmd=="tm_random"){
        if(argc < 6){ std::cerr << "tm_random needs candles.csv count seed output.json\n"; return 1; }
        return tm_random(argv[2], std::stoi(argv[3]), (unsigned)std::stoul(argv[4]), argv[5]);
    }
    if(cmd=="chart_ohlc"){
        if(argc < 6){ std::cerr << "chart_ohlc needs candles.csv bucket_hours limit output.json\n"; return 1; }
        return chart_ohlc(argv[2], std::stoi(argv[3]), std::stoi(argv[4]), argv[5]);
    }
    std::cerr << "unknown command\n"; return 1;
}
