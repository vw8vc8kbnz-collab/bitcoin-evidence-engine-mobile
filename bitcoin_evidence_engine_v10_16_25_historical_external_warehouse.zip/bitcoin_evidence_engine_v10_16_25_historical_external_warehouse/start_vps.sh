#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p "$HOME/bitcoin_evidence_data" logs native_core/bin

export BEE_CLOUD_MODE=1
export BEE_FORCE_MOBILE=1
export BEE_HOST="${BEE_HOST:-0.0.0.0}"
export PORT="${PORT:-8787}"
export BEE_DATA_DIR="${BEE_DATA_DIR:-$HOME/bitcoin_evidence_data}"
export BEE_AUTO_OPEN=0
export PYTHONUNBUFFERED=1

if [ -f .env.oracle ]; then
  set -a
  . ./.env.oracle
  set +a
fi

if [ ! -x .venv/bin/python ]; then
  echo "ERROR: .venv ontbreekt. Run eerst: bash install_vps.sh" >&2
  exit 1
fi

if ! .venv/bin/python -c "import uvicorn" >/dev/null 2>&1; then
  echo "ERROR: uvicorn ontbreekt in .venv. Run: bash install_vps.sh" >&2
  exit 1
fi

if [ ! -x native_core/bin/bee_native_core ]; then
  bash build_native_core_linux.sh
fi

echo "Starting Bitcoin Evidence Engine on 0.0.0.0:${PORT}"
exec .venv/bin/python -m uvicorn app.main:app --host "$BEE_HOST" --port "$PORT" --proxy-headers
