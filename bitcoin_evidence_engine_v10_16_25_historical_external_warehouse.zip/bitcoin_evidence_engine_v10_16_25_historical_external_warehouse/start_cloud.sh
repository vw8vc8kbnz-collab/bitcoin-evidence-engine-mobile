#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs app/data native_core/bin
export BEE_HOST="${BEE_HOST:-0.0.0.0}"
export PORT="${PORT:-8787}"
export BEE_DATA_DIR="${BEE_DATA_DIR:-$PWD/app/data}"
export BEE_AUTO_OPEN=0
export PYTHONUNBUFFERED=1
if [ ! -x native_core/bin/bee_native_core ]; then
  ./build_native_core_linux.sh
fi
python -m uvicorn app.main:app --host "$BEE_HOST" --port "$PORT" --proxy-headers
