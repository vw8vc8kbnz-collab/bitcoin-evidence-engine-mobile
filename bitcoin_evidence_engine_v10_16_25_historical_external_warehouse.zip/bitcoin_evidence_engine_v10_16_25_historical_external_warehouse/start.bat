@echo off
setlocal EnableExtensions
cd /d %~dp0

title Bitcoin Evidence Engine V10.16.2 Oracle Cloud Mobile
if not exist "logs" mkdir logs
>>"logs\launcher.log" echo [%date% %time%] Starting launcher in %CD%

echo.
echo Bitcoin Evidence Engine V10.16.2 Oracle Cloud Mobile
echo -------------------------------------------------
echo Gedeelde Python omgeving:
echo %LOCALAPPDATA%\BitcoinEvidenceEngine\venv
echo Gedeelde data/cache:
echo %LOCALAPPDATA%\BitcoinEvidenceEngine\data
echo.

REM V10.14.2: native core is meegeleverd. Geen lokale C++ compiler nodig.
if not exist "native_core\bin\bee_native_core.exe" (
  echo ERROR: native_core\bin\bee_native_core.exe ontbreekt.
  echo Deze versie heeft geen Python fallback voor zware Time Machine-paden.
  echo Pak de ZIP opnieuw volledig uit en start daarna opnieuw.
  >>"logs\launcher.log" echo [%date% %time%] ERROR native core exe missing
  pause
  exit /b 1
) else (
  echo Native core OK: native_core\bin\bee_native_core.exe
  >>"logs\launcher.log" echo [%date% %time%] Native core OK included exe
)

where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python launcher ^(py^) niet gevonden. Installeer Python 3.11+ en vink "Add Python to PATH" aan.
  >>"logs\launcher.log" echo [%date% %time%] ERROR py launcher not found
  pause
  exit /b 1
)

set "BEE_HOME=%LOCALAPPDATA%\BitcoinEvidenceEngine"
set "BEE_VENV=%BEE_HOME%\venv"
set "BEE_DATA_DIR=%BEE_HOME%\data"
if not exist "%BEE_HOME%" mkdir "%BEE_HOME%"
if not exist "%BEE_DATA_DIR%" mkdir "%BEE_DATA_DIR%"

if not exist "%BEE_VENV%\Scripts\python.exe" (
  echo Creating shared Python environment...
  >>"logs\launcher.log" echo [%date% %time%] Creating shared venv %BEE_VENV%
  py -3 -m venv "%BEE_VENV%"
  if errorlevel 1 (
    echo ERROR: Python environment could not be created.
    pause
    exit /b 1
  )
) else (
  echo Using shared Python environment.
)

call "%BEE_VENV%\Scripts\activate.bat"

echo Checking Python packages...
python -c "import fastapi,uvicorn,duckdb,pandas,numpy,httpx,pydantic" >nul 2>nul
if errorlevel 1 (
  echo.
  echo Installing missing Python packages. Dit gebeurt alleen als imports ontbreken...
  echo.
  >>"logs\launcher.log" echo [%date% %time%] Installing missing dependencies
  python -m pip install --disable-pip-version-check --upgrade pip 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -FilePath 'logs\pip_install.log' -Append"
  if errorlevel 1 goto pip_error
  python -m pip install --disable-pip-version-check --prefer-binary -r requirements.txt 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -FilePath 'logs\pip_install.log' -Append"
  if errorlevel 1 goto pip_error
  >>"logs\launcher.log" echo [%date% %time%] Dependencies installed OK
) else (
  echo Python packages OK. Skipping pip install.
  >>"logs\launcher.log" echo [%date% %time%] Package import check OK, skipped pip
)

echo.
echo Starting backend + app window...
echo Runtime log: %CD%\logs\bee_runtime.log
>>"logs\launcher.log" echo [%date% %time%] Starting backend
set BEE_AUTO_OPEN=0
set BEE_APP_MODE=1
start "Bitcoin Evidence Engine App Launcher" cmd /c "call open_app.bat"
python -m app.main

echo.
echo Server stopped. Check logs\bee_runtime.log for details.
pause
exit /b 0

:pip_error
echo.
echo ERROR: Package installation failed or was interrupted.
echo Check logs\pip_install.log and send the logs folder to ChatGPT.
>>"logs\launcher.log" echo [%date% %time%] ERROR installing dependencies
pause
exit /b 1
