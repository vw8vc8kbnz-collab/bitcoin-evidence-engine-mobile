Bitcoin Evidence Engine v10.16.9 VPS update

Deze versie forceert Python 3.12/3.11 in plaats van Python 3.14.
Python 3.14 is te nieuw voor pydantic-core wheels en gaf dependency errors.

Gebruik na upload naar GitHub:

cd ~/bitcoin-engine-deploy
bash update.sh

Daarna openen: http://51.195.102.180:8787
