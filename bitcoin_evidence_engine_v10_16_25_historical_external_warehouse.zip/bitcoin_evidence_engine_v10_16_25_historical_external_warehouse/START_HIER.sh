#!/usr/bin/env bash
set -euo pipefail
# Lokale start binnen een uitgepakte release. Voor normale VPS-updates gebruik:
#   cd ~/bitcoin-engine-deploy && bash update.sh
cd "$(dirname "$0")"
export BEE_DATA_DIR="${BEE_DATA_DIR:-$HOME/bitcoin_evidence_data}"
export BEE_CLOUD_MODE="1"
mkdir -p "$BEE_DATA_DIR" logs
pkill -f "uvicorn app.main:app" >/dev/null 2>&1 || true
sudo apt-get update
sudo apt-get install -y python3.12 python3.12-venv python3.12-dev golang-go curl unzip git procps
rm -rf .venv
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade 'pip<26' wheel setuptools
sed -i 's/^duckdb==1\.1\.3/duckdb>=1.4.2,<1.7/g; s/^pandas==2\.2\.3/pandas>=2.2.3,<3.1/g; s/^numpy==2\.1\.3/numpy>=2.1.3,<3.0/g; s/^pydantic==2\.10\.3/pydantic>=2.10.3,<3.0/g' requirements.txt || true
python -m pip install --only-binary=:all: -r requirements.txt
bash build_native_core_linux.sh
nohup .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8787 --proxy-headers > server.log 2>&1 &
sleep 3
curl -fsS http://127.0.0.1:8787/api/health >/dev/null && echo "✅ ONLINE: http://51.195.102.180:8787"
