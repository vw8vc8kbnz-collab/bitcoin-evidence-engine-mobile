from __future__ import annotations
import json
import platform
import subprocess
import tempfile
import time
from pathlib import Path
import pandas as pd
from app.core.config import settings
from app.db.database import db
from app.core.debug import append_jsonl
from app.core.logger import log
from app.services.historical_memory_service import HistoricalMemoryService

class NativeCoreRequiredError(RuntimeError):
    pass

class NativeCoreService:
    """Mandatory C++ sidecar bridge for heavy engine paths.

    V10.13 rule: no silent Python fallback for Time Machine chart aggregation or
    Random 100/1000. Python is only the UI/API/database orchestration layer; the
    expensive candle-array work must be done by native_core/bin/bee_native_core.exe.
    If the exe is missing or fails, the API returns a clear native-required error.
    """

    def __init__(self) -> None:
        self.root = settings.base_dir / "native_core"
        exe_name = "bee_native_core.exe" if platform.system().lower().startswith("win") else "bee_native_core"
        self.exe = self.root / "bin" / exe_name

    def available(self) -> bool:
        return self.exe.exists() and self.exe.is_file()

    def status(self) -> dict:
        return {
            "required": True,
            "available": self.available(),
            "exe": str(self.exe),
            "mode": "native_cpp_required" if self.available() else "native_cpp_missing",
            "message": "Go native core actief met 8Y memory + persistent Time Machine warehouse" if self.available() else "C++ native core ontbreekt. Native fallback is uitgeschakeld."
        }


    def _cache_dir(self) -> Path:
        d = settings.data_dir / "native_cache"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _cached_candles_csv(self, candles_df: pd.DataFrame, prefix: str = "tm") -> Path:
        required = ["open_time", "open", "high", "low", "close", "volume"]
        n = int(len(candles_df))
        min_ts = int(candles_df["open_time"].min())
        max_ts = int(candles_df["open_time"].max())
        path = self._cache_dir() / f"{prefix}_candles_{n}_{min_ts}_{max_ts}.csv"
        if not path.exists() or path.stat().st_size < 64:
            candles_df[required].to_csv(path, index=False, header=["timestamp_ms","open","high","low","close","volume"])
            append_jsonl('native_core_audit.jsonl', {"event":"native_candles_cache_write_v10145", "prefix":prefix, "rows":n, "path":str(path)})
        return path

    def _cached_features_csv(self, min_ts: int, max_ts: int) -> tuple[Path, int]:
        # Cache by requested range and current feature table size/max timestamp.
        try:
            sig = db.fetchone("SELECT COUNT(*), MAX(timestamp_ms) FROM features WHERE interval='1h' AND timestamp_ms>=? AND timestamp_ms<=?", [int(min_ts), int(max_ts)])
            fcount = int(sig[0] or 0) if sig else 0
            fmax = int(sig[1] or 0) if sig and sig[1] is not None else 0
        except Exception:
            fcount, fmax = 0, 0
        path = self._cache_dir() / f"state_features_{int(min_ts)}_{int(max_ts)}_{fcount}_{fmax}.csv"
        if path.exists() and path.stat().st_size > 32:
            return path, max(1, fcount)
        tmp = path.with_suffix('.tmp.csv')
        rows = self._write_state_features_csv(tmp, int(min_ts), int(max_ts))
        try:
            tmp.replace(path)
        except Exception:
            path = tmp
        append_jsonl('native_core_audit.jsonl', {"event":"native_feature_cache_write_v10145", "rows":rows, "path":str(path)})
        return path, rows

    def _cached_weights_csv(self) -> tuple[Path, dict]:
        path = self._cache_dir() / "adaptive_weights_current.csv"
        info = HistoricalMemoryService().export_weights_csv(path)
        return path, info

    def _write_state_features_csv(self, out_path: Path, min_ts: int, max_ts: int) -> int:
        """Export the market-state evidence layer for the native core.

        V10.13: Time Machine compares historical market *states*, not only
        candle shapes. The native core receives a compact feature matrix keyed by
        timestamp. Missing values are intentionally converted to zero so sparse
        external providers never block the engine.
        """
        cols = [
            "timestamp_ms", "rsi_14", "funding_rate", "open_interest_change_24h",
            "long_short_ratio", "taker_buy_sell_ratio", "fear_greed",
            "spot_premium_coinbase_pct", "volume_zscore", "drawdown_from_ath",
            "data_completeness", "regime_code",
        ]
        try:
            frame = db.df("""
                SELECT timestamp_ms,
                       COALESCE(rsi_14, 0) AS rsi_14,
                       COALESCE(funding_rate, 0) AS funding_rate,
                       COALESCE(open_interest_change_24h, 0) AS open_interest_change_24h,
                       COALESCE(long_short_ratio, 0) AS long_short_ratio,
                       COALESCE(taker_buy_sell_ratio, 0) AS taker_buy_sell_ratio,
                       COALESCE(fear_greed, 0) AS fear_greed,
                       COALESCE(spot_premium_coinbase_pct, spot_premium_kraken_pct, cross_exchange_spread_pct, 0) AS spot_premium_coinbase_pct,
                       COALESCE(volume_zscore, 0) AS volume_zscore,
                       COALESCE(drawdown_from_ath, 0) AS drawdown_from_ath,
                       COALESCE(data_completeness, 0) AS data_completeness,
                       CASE regime
                         WHEN 'bull_trend' THEN 1.0
                         WHEN 'bear_trend' THEN -1.0
                         WHEN 'high_volatility' THEN 0.5
                         WHEN 'capitulation' THEN -0.75
                         ELSE 0.0
                       END AS regime_code
                FROM features
                WHERE interval='1h' AND timestamp_ms>=? AND timestamp_ms<=?
                ORDER BY timestamp_ms ASC
            """, [int(min_ts), int(max_ts)])
        except Exception as exc:
            append_jsonl('native_core_audit.jsonl', {"event":"state_feature_export_failed", "error":str(exc), "min_ts":int(min_ts), "max_ts":int(max_ts)})
            frame = pd.DataFrame(columns=cols)
        source = "features_table"
        if frame is None or frame.empty:
            # V10.14.2: native similarity must never receive 0 feature rows.
            # If the feature warehouse has not been rebuilt yet, export a neutral
            # state row per candle timestamp. This is honest: state diagnostics will
            # show zero data-completeness, and native uses price structure only.
            try:
                ts_frame = db.df("""
                    SELECT open_time AS timestamp_ms
                    FROM raw_candles
                    WHERE source='binance' AND symbol=? AND interval='1h'
                      AND open_time>=? AND open_time<=?
                    ORDER BY open_time ASC
                """, [settings.symbol, int(min_ts), int(max_ts)])
            except Exception:
                ts_frame = pd.DataFrame(columns=["timestamp_ms"])
            frame = ts_frame.copy() if ts_frame is not None else pd.DataFrame(columns=["timestamp_ms"])
            source = "neutral_from_candles"
            append_jsonl('native_core_audit.jsonl', {"event":"state_feature_export_neutral_from_candles", "rows":int(len(frame)), "min_ts":int(min_ts), "max_ts":int(max_ts)})
        for c in cols:
            if c not in frame.columns:
                frame[c] = 0
        coverage = {}
        try:
            for c in cols[1:-1]:
                if c in frame.columns and len(frame):
                    coverage[c] = round(float(frame[c].notna().mean() * 100.0), 2)
        except Exception:
            coverage = {}
        frame = frame[cols].fillna(0)
        if frame.empty:
            raise NativeCoreRequiredError("Geen candles/features beschikbaar voor native state export.")
        frame.to_csv(out_path, index=False)
        append_jsonl('native_core_audit.jsonl', {
            "event":"state_feature_export_v10142",
            "rows": int(len(frame)),
            "source": source,
            "min_ts": int(min_ts),
            "max_ts": int(max_ts),
            "coverage_pct": coverage,
        })
        return int(len(frame))

    def require(self) -> None:
        if not self.available():
            append_jsonl('native_core_audit.jsonl', {"event":"native_required_missing", "exe":str(self.exe)})
            raise NativeCoreRequiredError(
                "C++ native core ontbreekt. Python fallback is bewust uitgeschakeld. "
                "Draai build_native_core.bat of installeer Visual Studio Build Tools/MinGW."
            )

    def _rebuild_go_native_core_once(self) -> bool:
        """Repair VPS installs that still contain the old C++ binary.

        The Python bridge uses the adaptive Go interface:
        tm_random candles.csv features.csv adaptive_weights.csv count seed out.json.
        Old C++ binaries expect tm_random candles.csv count seed out.json and crash
        with std::stoul when argv[4] is a weights path. Rebuild Go once in-place.
        """
        script = settings.base_dir / "build_native_core_linux.sh"
        if not script.exists():
            return False
        try:
            proc = subprocess.run(["bash", str(script)], cwd=str(settings.base_dir), capture_output=True, text=True, timeout=120)
            append_jsonl('native_core_audit.jsonl', {
                "event":"native_go_rebuild_attempt_v101613",
                "returncode": proc.returncode,
                "stdout": proc.stdout[-2000:],
                "stderr": proc.stderr[-2000:],
            })
            return proc.returncode == 0 and self.available()
        except Exception as exc:
            append_jsonl('native_core_audit.jsonl', {"event":"native_go_rebuild_exception_v101613", "error":str(exc)})
            return False

    def _run(self, args: list[str], timeout: int, event_prefix: str) -> dict:
        self.require()

        def run_once():
            t0_inner = time.perf_counter()
            proc_inner = subprocess.run([str(self.exe)] + args, cwd=str(settings.base_dir), capture_output=True, text=True, timeout=timeout)
            return proc_inner, int((time.perf_counter() - t0_inner) * 1000)

        try:
            proc, elapsed_ms = run_once()
        except Exception as exc:
            append_jsonl('native_core_audit.jsonl', {"event":f"{event_prefix}_exception", "error":str(exc)})
            raise NativeCoreRequiredError(f"C++/Go native core crash/timeout: {exc}") from exc
        if proc.returncode != 0:
            stderr_tail = proc.stderr[-2000:]
            stdout_tail = proc.stdout[-1000:]
            # Auto-repair the known wrong-binary failure from old C++ cores.
            if ("stoul" in stderr_tail or "invalid_argument" in stderr_tail or "tm_random needs candles.csv count seed" in stderr_tail) and self._rebuild_go_native_core_once():
                try:
                    proc, elapsed_ms = run_once()
                except Exception as exc:
                    append_jsonl('native_core_audit.jsonl', {"event":f"{event_prefix}_exception_after_rebuild", "error":str(exc)})
                    raise NativeCoreRequiredError(f"Go native core crash/timeout na rebuild: {exc}") from exc
            if proc.returncode != 0:
                append_jsonl('native_core_audit.jsonl', {"event":f"{event_prefix}_nonzero", "returncode":proc.returncode, "stderr":proc.stderr[-2000:], "stdout":proc.stdout[-1000:], "elapsed_ms":elapsed_ms})
                raise NativeCoreRequiredError(f"Native core gaf foutcode {proc.returncode}: {proc.stderr[-500:]}")
        return {"elapsed_ms": elapsed_ms, "stdout": proc.stdout, "stderr": proc.stderr}

    def chart_ohlc(self, candles_df: pd.DataFrame, bucket_hours: int = 1, limit: int = 1400) -> dict:
        required = ["open_time", "open", "high", "low", "close", "volume"]
        if candles_df is None or candles_df.empty or any(c not in candles_df.columns for c in required):
            raise NativeCoreRequiredError("Geen geldige candle-data voor C++ chart core.")
        bucket_hours = max(1, int(bucket_hours))
        limit = max(50, min(int(limit), 50000))
        with tempfile.TemporaryDirectory(prefix="bee_native_chart_") as td:
            td_path = Path(td)
            out_path = td_path / "chart.json"
            csv_path = self._cached_candles_csv(candles_df, prefix=f"chart_{bucket_hours}h")
            run = self._run(["chart_ohlc", str(csv_path), str(bucket_hours), str(limit), str(out_path)], timeout=30, event_prefix="native_chart")
            try:
                data = json.loads(out_path.read_text(encoding="utf-8"))
            except Exception as exc:
                append_jsonl('native_core_audit.jsonl', {"event":"native_chart_bad_json", "error":str(exc), "stdout":run.get("stdout","")[-500:], "stderr":run.get("stderr","")[-500:]})
                raise NativeCoreRequiredError(f"C++ chart core gaf ongeldige JSON: {exc}") from exc
            data["native_bridge_elapsed_ms"] = run["elapsed_ms"]
            data["native_required"] = True
            append_jsonl('native_core_audit.jsonl', {"event":"native_chart_ok", "count":data.get("count"), "raw_count":data.get("raw_count"), "elapsed_ms":run["elapsed_ms"], "core_elapsed_ms":data.get("elapsed_ms")})
            return data


    def tm_single(self, candles_df: pd.DataFrame, cutoff_ms: int) -> dict:
        required = ["open_time", "open", "high", "low", "close", "volume"]
        if candles_df is None or candles_df.empty or any(c not in candles_df.columns for c in required):
            raise NativeCoreRequiredError("Geen geldige candle-data voor C++ single Time Machine core.")
        with tempfile.TemporaryDirectory(prefix="bee_native_tm_single_") as td:
            td_path = Path(td)
            out_path = td_path / "result.json"
            csv_path = self._cached_candles_csv(candles_df, prefix="tm_single")
            features_path, feature_rows = self._cached_features_csv(int(candles_df["open_time"].min()), int(candles_df["open_time"].max()))
            weights_path, weight_info = self._cached_weights_csv()
            run = self._run(["tm_single", str(csv_path), str(features_path), str(weights_path), str(int(cutoff_ms)), str(out_path)], timeout=30, event_prefix="native_tm_single_adaptive")
            try:
                data = json.loads(out_path.read_text(encoding="utf-8"))
            except Exception as exc:
                append_jsonl('native_core_audit.jsonl', {"event":"native_tm_single_bad_json", "error":str(exc), "stdout":run.get("stdout","")[-500:], "stderr":run.get("stderr","")[-500:]})
                raise NativeCoreRequiredError(f"C++ single Time Machine core gaf ongeldige JSON: {exc}") from exc
            data["native_bridge_elapsed_ms"] = run["elapsed_ms"]
            data["native_required"] = True
            append_jsonl('native_core_audit.jsonl', {"event":"native_tm_single_adaptive_ok", "items":len(data.get("items") or []), "feature_rows":feature_rows, "weight_dimensions":weight_info.get("rows"), "elapsed_ms":run["elapsed_ms"], "core_elapsed_ms":data.get("elapsed_ms")})
            return data

    def tm_random(self, candles_df: pd.DataFrame, count: int = 100) -> dict:
        required = ["open_time", "open", "high", "low", "close", "volume"]
        if candles_df is None or candles_df.empty or any(c not in candles_df.columns for c in required):
            raise NativeCoreRequiredError("Geen geldige candle-data voor C++ random Time Machine core.")
        count = max(1, min(int(count), 10000))
        with tempfile.TemporaryDirectory(prefix="bee_native_tm_") as td:
            td_path = Path(td)
            out_path = td_path / "result.json"
            csv_path = self._cached_candles_csv(candles_df, prefix="tm_random")
            features_path, feature_rows = self._cached_features_csv(int(candles_df["open_time"].min()), int(candles_df["open_time"].max()))
            weights_path, weight_info = self._cached_weights_csv()
            seed = int(time.time() * 1000) % (2**32 - 1)
            run = self._run(["tm_random", str(csv_path), str(features_path), str(weights_path), str(count), str(seed), str(out_path)], timeout=180, event_prefix="native_tm_random_adaptive")
            try:
                data = json.loads(out_path.read_text(encoding="utf-8"))
            except Exception as exc:
                append_jsonl('native_core_audit.jsonl', {"event":"native_tm_random_bad_json", "error":str(exc), "stdout":run.get("stdout","")[-500:], "stderr":run.get("stderr","")[-500:]})
                raise NativeCoreRequiredError(f"C++ random core gaf ongeldige JSON: {exc}") from exc
            data["native_bridge_elapsed_ms"] = run["elapsed_ms"]
            data["native_required"] = True
            append_jsonl('native_core_audit.jsonl', {"event":"native_tm_random_adaptive_ok", "count":data.get("count"), "items":len(data.get("items") or []), "feature_rows":feature_rows, "weight_dimensions":weight_info.get("rows"), "elapsed_ms":run["elapsed_ms"], "core_elapsed_ms":data.get("elapsed_ms")})
            return data
