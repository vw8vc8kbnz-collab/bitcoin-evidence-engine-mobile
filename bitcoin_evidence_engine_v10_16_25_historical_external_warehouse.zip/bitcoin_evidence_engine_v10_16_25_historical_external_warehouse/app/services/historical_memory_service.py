from __future__ import annotations

import asyncio
import json
import math
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl, write_json
from app.core.logger import log
from app.core.runtime_locks import tm_priority_event
from app.core.time_utils import utc_now
from app.db.database import db
from app.services.sync_service import SyncService
from app.engine.feature_engine import FeatureEngine


DIMENSION_TO_SIGNALS: dict[str, list[str]] = {
    "rsi_state": ["rsi_14:"],
    "funding_rate": ["funding_rate:"],
    "open_interest_change_24h": ["open_interest_change_24h:"],
    "long_short_ratio": ["long_short_ratio:"],
    "taker_buy_sell_ratio": ["taker_delta_ratio:"],
    "fear_greed": ["fear_greed:"],
    "spot_premium": ["spot_coinbase_premium:", "spot_cross_exchange_spread:"],
    "volume_zscore": ["volume_zscore:"],
    "drawdown_from_ath": ["drawdown_from_ath:"],
    "regime_code": ["regime:"],
    "data_completeness": ["data_completeness:"],
}

DEFAULT_WEIGHTS = {
    "return_4h": 1.10,
    "return_24h": 1.20,
    "return_7d": 0.90,
    "ma20_distance": 0.75,
    "ma50_distance": 0.75,
    "volatility_24": 0.95,
    "rsi_state": 0.95,
    "funding_rate": 1.35,
    "open_interest_change_24h": 1.45,
    "long_short_ratio": 0.95,
    "taker_buy_sell_ratio": 1.20,
    "fear_greed": 0.60,
    "spot_premium": 1.05,
    "volume_zscore": 0.85,
    "drawdown_from_ath": 0.75,
    "data_completeness": 0.25,
    "regime_code": 0.55,
}

_HISTORY_DAEMON_LOCK = threading.Lock()
_HISTORY_DAEMON_RUNNING = False
_HISTORY_STATUS_CACHE: dict[str, Any] = {}

def _fallback_history_status(reason: str = "db_busy") -> dict[str, Any]:
    cached = dict(_HISTORY_STATUS_CACHE or {})
    target = int(getattr(settings, "historical_target_rows_1h", 70000))
    if not cached:
        cached = {
            "symbol": settings.symbol, "interval": "1h", "stored_rows": 0,
            "min_ts": None, "max_ts": None, "target_start_ms": int(settings.historical_start_ms),
            "target_rows": target, "target_years": settings.historical_target_years,
            "coverage_pct": 0.0, "raw_coverage_pct": 0.0, "remaining_rows": target,
            "complete": False,
        }
    cached["running"] = bool(_HISTORY_DAEMON_RUNNING)
    cached["auto_startup_enabled"] = bool(settings.historical_auto_complete_on_startup)
    cached["loading_state"] = "loading" if cached.get("running") else "queued"
    cached["status_label"] = "Automatisch laden" if cached.get("running") else "In wachtrij"
    cached["state_message"] = reason
    cached["ui_message"] = f"{cached['status_label']} · {int(cached.get('stored_rows') or 0):,}/{int(cached.get('target_rows') or target):,} · {float(cached.get('coverage_pct') or 0):.2f}%"
    cached["status_source"] = "cache"
    return cached


class HistoricalMemoryService:
    """V10.14: eight-year candle memory + adaptive feature weights.

    Rules:
    - The chart can remain limited to visible candles.
    - Time Machine/native similarity should have the full local 1H warehouse.
    - Backfill is resumable and runs in the background, never as a UI-blocking route.
    - Feature weights are derived from actual Time Machine outcomes and exported for C++.
    """

    def _state(self, key: str, value: str) -> None:
        try:
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", [key, value, utc_now()])
        except Exception:
            pass

    def history_status(self) -> dict[str, Any]:
        """Fast UI-safe Historical Memory status.

        V10.15.3: the frontend was timing out while backfill/forecast held the
        single DuckDB lock. Status may never block the UI. We therefore try the
        DB lock briefly and fall back to the last in-memory snapshot when busy.
        """
        global _HISTORY_STATUS_CACHE
        acquired = False
        try:
            acquired = db.lock.acquire(timeout=0.20)
            if not acquired:
                return _fallback_history_status("db busy; showing last known history progress")
            row = db.conn.execute("""
                SELECT COUNT(*), MIN(open_time), MAX(open_time)
                FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h'
            """, [settings.symbol]).fetchone()
            count = int(row[0] or 0) if row else 0
            min_ts = int(row[1]) if row and row[1] is not None else None
            max_ts = int(row[2]) if row and row[2] is not None else None
            target = int(settings.historical_target_rows_1h)
            raw_coverage = min(100.0, (count / target) * 100.0) if target else 0.0
            start_target_ms = int(settings.historical_start_ms)
            complete_by_rows = count >= target
            complete_by_start = bool(min_ts and min_ts <= start_target_ms + 2 * 3600000)
            complete = bool(complete_by_rows or complete_by_start)
            coverage = 100.0 if complete else raw_coverage
            remaining = max(0, target - count)
            state_row = db.conn.execute("SELECT value FROM sync_state WHERE key='historical_memory'").fetchone()
            state_msg = str(state_row[0]) if state_row and state_row[0] is not None else "auto loading queued"
            autostart_row = db.conn.execute("SELECT value FROM sync_state WHERE key='historical_memory_autostart'").fetchone()
            autostart = str(autostart_row[0]) if autostart_row and autostart_row[0] is not None else ("enabled" if bool(settings.historical_auto_complete_on_startup) else "disabled")
            running = bool(_HISTORY_DAEMON_RUNNING)
            latest_lag_hours = None
            if max_ts:
                try:
                    latest_lag_hours = max(0.0, (int(utc_now().timestamp() * 1000) - int(max_ts)) / 3600000.0)
                except Exception:
                    latest_lag_hours = None
            incremental_state = "up_to_date" if complete and (latest_lag_hours is None or latest_lag_hours <= 2.5) else ("needs_recent_sync" if complete else "backfill_required")
            if complete:
                loading_state = "complete"; status_label = "Volledig geladen"
                ui_message = f"Volledig geladen in gedeelde database · {count:,}/{target:,} · 100% · exporteer seed-snapshot om naar ChatGPT te sturen"
            elif running:
                loading_state = "loading"; status_label = "Automatisch laden"; ui_message = f"Automatisch laden · {count:,}/{target:,} · {coverage:.2f}%"
            elif "waiting" in state_msg.lower() or "retry" in state_msg.lower():
                loading_state = "waiting_retry"; status_label = "Wachten / opnieuw proberen"; ui_message = f"Wachten/opnieuw proberen · {count:,}/{target:,} · {coverage:.2f}%"
            else:
                loading_state = "queued" if bool(settings.historical_auto_complete_on_startup) else "manual"
                status_label = "In wachtrij" if bool(settings.historical_auto_complete_on_startup) else "Handmatig"
                ui_message = f"In wachtrij · {count:,}/{target:,} · {coverage:.2f}%"
            payload = {
                "symbol": settings.symbol, "interval": "1h", "stored_rows": count,
                "min_ts": min_ts, "max_ts": max_ts, "target_start_ms": start_target_ms,
                "target_rows": target, "target_years": settings.historical_target_years,
                "coverage_pct": round(coverage, 2), "raw_coverage_pct": round(raw_coverage, 2),
                "remaining_rows": remaining, "complete": complete, "running": running,
                "auto_startup_enabled": bool(settings.historical_auto_complete_on_startup),
                "autostart_state": autostart, "loading_state": loading_state,
                "status_label": status_label, "state_message": state_msg, "ui_message": ui_message,
                "latest_lag_hours": round(float(latest_lag_hours), 2) if latest_lag_hours is not None else None,
                "incremental_state": incremental_state,
                "shared_data_dir": str(settings.data_dir),
                "status_source": "db",
            }
            _HISTORY_STATUS_CACHE = dict(payload)
            return payload
        except Exception as exc:
            return _fallback_history_status("status cache fallback: " + str(exc)[:120])
        finally:
            if acquired:
                try: db.lock.release()
                except Exception: pass

    async def ensure_eight_year_history_background(self, *, max_chunks: int | None = None) -> dict:
        max_chunks = int(max_chunks or settings.historical_backfill_max_chunks_background)
        status = self.history_status()
        if status.get("complete"):
            self._state("historical_memory", f"complete {status['stored_rows']} rows")
            return {"ok": True, "already_complete": True, "status": status}
        self._state("historical_memory", f"backfilling {status['stored_rows']}/{status['target_rows']}")
        append_jsonl("historical_memory_audit.jsonl", {"event": "backfill_start", "status": status, "max_chunks": max_chunks})
        sync = SyncService()
        total_rows = 0
        chunks_done = 0
        last_result: dict[str, Any] = {}
        # Use one-chunk calls so each DB write is short and progress is visible.
        old_chunks = getattr(settings, "backfill_max_chunks_per_sync", 1)
        try:
            settings.backfill_max_chunks_per_sync = 1
            for _ in range(max_chunks):
                cur = self.history_status()
                if cur.get("complete"):
                    break
                # V10.14.5: Time Machine/chart has priority. If the user is
                # interacting, pause before starting the next provider/DB chunk.
                while tm_priority_event.is_set():
                    self._state("historical_memory", f"paused for Time Machine · {cur['stored_rows']}/{cur['target_rows']} ({cur['coverage_pct']}%)")
                    await asyncio.sleep(0.35)
                    cur = self.history_status()
                    if cur.get("complete"):
                        break
                if cur.get("complete"):
                    break
                last_result = await sync.sync_binance_deep_history()
                rows = int(last_result.get("rows") or 0) if isinstance(last_result, dict) else 0
                total_rows += rows
                chunks_done += int(last_result.get("chunks") or 0) if isinstance(last_result, dict) else 0
                cur2 = self.history_status()
                self._state("historical_memory", f"backfilling {cur2['stored_rows']}/{cur2['target_rows']} ({cur2['coverage_pct']}%)")
                append_jsonl("historical_memory_audit.jsonl", {"event": "backfill_chunk", "result": last_result, "status": cur2})
                # V10.14.3: keep features in step with the growing 8Y memory.
                # Rebuild periodically in the background so feature_count does not
                # remain zero until the entire 70k-row backfill is finished.
                if chunks_done and chunks_done % int(getattr(settings, 'feature_progressive_rebuild_every_chunks', 10)) == 0:
                    try:
                        prog_rebuilt = FeatureEngine().rebuild()
                        append_jsonl("historical_memory_audit.jsonl", {"event":"progressive_feature_rebuild_v10143", "chunks_done":chunks_done, "features_rebuilt":prog_rebuilt, "status":cur2})
                    except Exception as exc:
                        append_jsonl("historical_memory_audit.jsonl", {"event":"progressive_feature_rebuild_failed_v10143", "chunks_done":chunks_done, "error":str(exc)})
                if rows <= 0:
                    break
                await asyncio.sleep(float(settings.historical_backfill_batch_pause_seconds))
        finally:
            settings.backfill_max_chunks_per_sync = old_chunks
        # V10.14.5: Do not rebuild features at the end of every small pass.
        # The daemon controls feature rebuild cadence, otherwise a user click can
        # get stuck behind repeated full feature rebuilds.
        rebuilt = 0
        final_status = self.history_status()
        self._state("historical_memory", f"{'complete' if final_status['complete'] else 'partial'} {final_status['stored_rows']} rows")
        append_jsonl("historical_memory_audit.jsonl", {"event": "backfill_done", "rows_added": total_rows, "chunks": chunks_done, "features_rebuilt": rebuilt, "status": final_status})
        return {"ok": True, "rows_added": total_rows, "chunks": chunks_done, "features_rebuilt": rebuilt, "status": final_status, "last_result": last_result}


    async def ensure_eight_year_history_daemon(self) -> dict[str, Any]:
        """Keep filling the 8Y warehouse until complete without blocking UI.

        V10.15.5: fast incremental history daemon. Previous builds could fetch one pass
        and then appear stuck around 15k because feature rebuild / learning
        bootstrap started while the 70k memory was still incomplete. This daemon
        keeps fetching history first. Adaptive learning is postponed until the
        warehouse is complete so it cannot block Binance backfill progress.
        """
        global _HISTORY_DAEMON_RUNNING
        with _HISTORY_DAEMON_LOCK:
            if _HISTORY_DAEMON_RUNNING:
                return {"ok": True, "already_running": True, "status": self.history_status()}
            _HISTORY_DAEMON_RUNNING = True
        started = utc_now()
        total_rows_added = 0
        passes = 0
        last_feature_rebuild_rows = 0
        last_feature_rebuild_at_count = 0
        try:
            append_jsonl("historical_memory_audit.jsonl", {"event": "daemon_start_v10151", "status": self.history_status()})
            while True:
                status = self.history_status()
                if status.get("complete"):
                    # V10.15.5: once the 70k warehouse exists, do not run a
                    # full deep backfill again. Only refresh the recent Binance
                    # window so new 1h candles since the last run are inserted.
                    self._state("historical_memory", f"complete {status['stored_rows']}/{status['target_rows']} · checking recent candles only")
                    try:
                        inc = await SyncService().sync_binance_candles()
                        append_jsonl("historical_memory_audit.jsonl", {"event": "incremental_recent_sync_v10155", "result": inc, "before_status": status, "after_status": self.history_status()})
                    except Exception as exc:
                        append_jsonl("historical_memory_audit.jsonl", {"event": "incremental_recent_sync_failed_v10155", "error": str(exc), "status": status})
                    self._state("historical_memory", f"complete {status['stored_rows']}/{status['target_rows']} · 100% · incremental only")
                    break
                passes += 1
                while tm_priority_event.is_set():
                    self._state("historical_memory", f"paused for Time Machine · {status['stored_rows']}/{status['target_rows']} ({status['coverage_pct']}%)")
                    await asyncio.sleep(0.35)
                    status = self.history_status()
                    if status.get("complete"):
                        break
                if status.get("complete"):
                    break
                self._state("historical_memory", f"backfilling {status['stored_rows']}/{status['target_rows']} ({status['coverage_pct']}%)")
                result = await self.ensure_eight_year_history_background(max_chunks=int(settings.historical_daemon_pass_chunks))
                new_status = self.history_status()
                rows_added = int(result.get("rows_added") or 0) if isinstance(result, dict) else 0
                total_rows_added += rows_added
                append_jsonl("historical_memory_audit.jsonl", {"event": "daemon_pass_done_v10151", "pass": passes, "rows_added": rows_added, "status": new_status})
                # Rebuild features after enough new history, but never on click.
                if (int(new_status.get("stored_rows") or 0) - last_feature_rebuild_at_count) >= int(settings.historical_feature_rebuild_min_new_rows):
                    try:
                        rebuilt = FeatureEngine().rebuild()
                        last_feature_rebuild_rows = int(rebuilt or 0)
                        last_feature_rebuild_at_count = int(new_status.get("stored_rows") or 0)
                        append_jsonl("historical_memory_audit.jsonl", {"event": "daemon_feature_rebuild_v10151", "features": last_feature_rebuild_rows, "stored_rows": last_feature_rebuild_at_count})
                    except Exception as exc:
                        append_jsonl("historical_memory_audit.jsonl", {"event": "daemon_feature_rebuild_failed_v10151", "error": str(exc)})
                # Run a small learning bootstrap once enough candles exist. This
                # is intentionally tiny and async so the user can keep working.
                try:
                    if bool(settings.learning_bootstrap_enabled) and bool(new_status.get("complete")):
                        boot = self.learning_bootstrap_if_needed()
                        if boot.get("started"):
                            append_jsonl("historical_memory_audit.jsonl", {"event": "learning_bootstrap_started_v10154", **boot})
                    elif not bool(new_status.get("complete")):
                        append_jsonl("historical_memory_audit.jsonl", {"event": "history_first_learning_deferred_v10154", "stored_rows": int(new_status.get("stored_rows") or 0), "target_rows": int(new_status.get("target_rows") or 0)})
                except Exception as exc:
                    append_jsonl("historical_memory_audit.jsonl", {"event": "learning_bootstrap_failed_v10151", "error": str(exc)})
                if rows_added <= 0:
                    # Avoid tight loops if provider/network returns no rows, but do
                    # not silently stop: the goal is to keep pushing toward 70k.
                    self._state("historical_memory", f"waiting/retry · {new_status['stored_rows']}/{new_status['target_rows']} ({new_status['coverage_pct']}%)")
                    await asyncio.sleep(max(float(settings.historical_daemon_stall_backoff_seconds), float(settings.historical_daemon_pause_seconds) * 4.0))
                else:
                    await asyncio.sleep(float(settings.historical_daemon_pause_seconds))
            try:
                final_features = FeatureEngine().rebuild()
                last_feature_rebuild_rows = int(final_features or 0)
            except Exception:
                pass
            final_weights = self.adaptive_weights()
            final_status = self.history_status()
            append_jsonl("historical_memory_audit.jsonl", {"event": "daemon_complete_v10151", "passes": passes, "rows_added": total_rows_added, "features": last_feature_rebuild_rows, "weights_active": final_weights.get("active"), "status": final_status})
            return {"ok": True, "complete": True, "passes": passes, "rows_added": total_rows_added, "features_rebuilt": last_feature_rebuild_rows, "status": final_status, "adaptive_weights": final_weights}
        finally:
            _HISTORY_DAEMON_RUNNING = False

    def learning_bootstrap_if_needed(self) -> dict[str, Any]:
        """Start small native random batches until adaptive rows exist.

        This does not force weights to become active with fake data; it only
        ensures the warehouse gets real Time Machine samples. Native random tests
        still score actual historical outcomes.
        """
        status = self.history_status()
        if int(status.get("stored_rows") or 0) < int(settings.learning_bootstrap_min_history_rows):
            return {"started": False, "reason": "not_enough_history", "history": status}
        weights = self.adaptive_weights()
        if bool(weights.get("active")) or int(weights.get("rows_used") or 0) >= int(settings.learning_bootstrap_target_rows_used):
            return {"started": False, "reason": "already_enough_learning", "rows_used": int(weights.get("rows_used") or 0), "active": bool(weights.get("active"))}
        marker = db.fetchone("SELECT value FROM sync_state WHERE key='learning_bootstrap_running'")
        if marker and str(marker[0]) == '1':
            return {"started": False, "reason": "already_running"}
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["learning_bootstrap_running", "1", utc_now()])
        def _run() -> None:
            try:
                from app.services.time_machine_service import TimeMachineService
                svc = TimeMachineService()
                batches = int(settings.learning_bootstrap_max_batches_per_pass)
                for i in range(max(1, batches)):
                    res = svc.random_tests(count=int(settings.learning_bootstrap_batch_size))
                    append_jsonl("adaptive_weights_audit.jsonl", {"event": "learning_bootstrap_random_started_v10144", "batch": i+1, "result": {k: res.get(k) for k in ('ok','batch_id','count','native_items','elapsed_ms','import_status')}})
                    time.sleep(0.3)
                self.adaptive_weights()
            except Exception as exc:
                append_jsonl("adaptive_weights_audit.jsonl", {"event": "learning_bootstrap_error_v10144", "error": str(exc)})
            finally:
                try:
                    db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["learning_bootstrap_running", "0", utc_now()])
                except Exception:
                    pass
        threading.Thread(target=_run, daemon=True, name="learning-bootstrap-v10144").start()
        return {"started": True, "history": status, "rows_used_before": int(weights.get("rows_used") or 0)}

    def adaptive_weights(self, min_total: int | None = None) -> dict[str, Any]:
        """Build conservative adaptive weights from proven Time Machine outcomes.

        V10.14.3 rules:
        - Never pretend adaptive learning is active when there are no real samples.
        - Signal buckets below `adaptive_activation_sample` are diagnostic only.
        - Native core receives *no adaptive override rows* until at least one
          dimension has enough evidence. Then only proven dimensions are exported.
        - Base/static weights remain the fallback, so the engine stays stable.
        """
        min_total = int(min_total if min_total is not None else settings.adaptive_min_signal_total)
        activation_sample = int(settings.adaptive_activation_sample)
        strong_activation_sample = int(getattr(settings, "adaptive_strong_activation_sample", 500))
        min_rows_used = int(settings.adaptive_min_rows_used)
        rows = db.df("""
            SELECT signal_key, signal_label, signal_type, horizon, regime, total,
                   hitrate_with_partial, avg_score, avg_target_gap_pct
            FROM time_machine_signal_scores
            WHERE total >= ?
        """, [min_total]).to_dict("records")
        dim_stats: dict[str, dict[str, Any]] = {}
        active_dims: list[str] = []
        for dim, prefixes in DIMENSION_TO_SIGNALS.items():
            matches = []
            for r in rows:
                key = str(r.get("signal_key") or "")
                if any(key.startswith(p) for p in prefixes):
                    matches.append(r)
            if not matches:
                continue
            weighted_quality = 0.0
            total_n = 0.0
            for r in matches:
                n = float(r.get("total") or 0)
                hwp = float(r.get("hitrate_with_partial") or 0.0)
                score = float(r.get("avg_score") or 0.0) / 100.0
                gap = float(r.get("avg_target_gap_pct") or 0.0)
                quality = 0.55 * hwp + 0.35 * score + 0.10 * max(0.0, 1.0 - min(gap, 10.0) / 10.0)
                weighted_quality += quality * n
                total_n += n
            q = weighted_quality / total_n if total_n else 0.50
            # V10.14.3: once a signal has enough samples, let it nudge the native
            # state search lightly. Full-strength weighting is only allowed after
            # a larger sample. This gives the engine a real, conservative learning
            # loop instead of staying at rows_used=0 for too long.
            light_ready = bool(total_n >= activation_sample)
            strong_ready = bool(total_n >= strong_activation_sample)
            if strong_ready:
                mult = max(0.60, min(1.90, 1.0 + (q - 0.50) * 2.4))
                phase = "strong"
            elif light_ready:
                mult = max(0.85, min(1.15, 1.0 + (q - 0.50) * 0.9))
                phase = "light"
            else:
                mult = 1.0
                phase = f"needs >= {activation_sample} samples"
            if light_ready:
                active_dims.append(dim)
            dim_stats[dim] = {
                "quality": round(q, 4),
                "multiplier": round(mult, 4),
                "sample": int(total_n),
                "matched_signals": len(matches),
                "active": light_ready,
                "strength": phase,
                "reason": phase if light_ready else phase,
            }
        weights = {}
        adaptive_weights = {}
        for dim, base in DEFAULT_WEIGHTS.items():
            st = dim_stats.get(dim) or {}
            ready = bool(st.get("active"))
            mult = float(st.get("multiplier") or 1.0)
            if dim in ("return_4h", "return_24h", "return_7d", "ma20_distance", "ma50_distance", "volatility_24"):
                final = base
                ready = False  # price-structure baseline stays stable for now
            elif ready:
                final = max(0.15, min(2.75, base * mult))
                adaptive_weights[dim] = round(final, 5)
            else:
                final = base
            weights[dim] = round(final, 5)
        active = bool(len(active_dims) > 0 and len(rows) >= min_rows_used)
        payload = {
            "engine_version": settings.engine_version,
            "min_total": min_total,
            "activation_sample": activation_sample,
            "strong_activation_sample": strong_activation_sample,
            "min_rows_used": min_rows_used,
            "active": active,
            "weights": weights,
            "adaptive_weights": adaptive_weights if active else {},
            "dimension_stats": dim_stats,
            "active_dimensions": active_dims if active else [],
            "rows_used": len(rows),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "message": "adaptive learning active" if active else "adaptive learning waiting for more Time Machine samples",
        }
        write_json("adaptive_feature_weights.json", payload)
        # V10.14.4: keep the database status table in sync with the JSON export.
        # Dashboard/readiness previously looked at this table, while the learning
        # code only wrote JSON, so the UI could still show 0 learned dimensions.
        try:
            db.execute("DELETE FROM adaptive_feature_weights")
            now = utc_now()
            rows_to_write = []
            for dim, weight in (adaptive_weights if active else {}).items():
                st = dim_stats.get(dim, {})
                rows_to_write.append([dim, float(weight), float(st.get('quality') or 0.5), int(st.get('sample') or 0), int(st.get('matched_signals') or 0), now])
            if rows_to_write:
                db.executemany("INSERT OR REPLACE INTO adaptive_feature_weights VALUES (?, ?, ?, ?, ?, ?)", rows_to_write)
        except Exception as exc:
            append_jsonl("adaptive_weights_audit.jsonl", {"event":"adaptive_weight_table_sync_failed_v10144", "error":str(exc)})
        self._state("adaptive_weights", ("active " if active else "waiting ") + f"{len(active_dims)} dims · rows {len(rows)}")
        append_jsonl("adaptive_weights_audit.jsonl", {"event": "weights_built_v10144", **payload})
        return payload

    def export_weights_csv(self, path: Path) -> dict[str, Any]:
        payload = self.adaptive_weights()
        adaptive = payload.get("adaptive_weights") or {}
        # Important: an empty CSV means native core uses its stable built-in base
        # weights. We only export dimensions that are proven active.
        with path.open("w", encoding="utf-8") as f:
            f.write("dimension,weight,active,sample,quality\n")
            for k, v in adaptive.items():
                st = payload.get("dimension_stats", {}).get(k, {})
                f.write(f"{k},{v},1,{int(st.get('sample') or 0)},{float(st.get('quality') or 0):.6f}\n")
        return {
            "path": str(path),
            "rows": len(adaptive),
            "active": bool(payload.get("active")),
            "payload": payload,
        }
