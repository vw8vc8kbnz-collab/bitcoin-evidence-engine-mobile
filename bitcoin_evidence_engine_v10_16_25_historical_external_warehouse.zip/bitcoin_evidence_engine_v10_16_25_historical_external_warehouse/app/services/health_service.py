from __future__ import annotations
import json
from app.db.database import db
from app.core.time_utils import utc_now

class HealthService:
    def success(self, source: str, rows_added: int = 0, detail: dict | None = None):
        db.execute("""
            INSERT OR REPLACE INTO data_health(source,status,last_success_at,last_error_at,last_error,rows_added,detail)
            VALUES (?, 'ok', ?, COALESCE((SELECT last_error_at FROM data_health WHERE source=?), NULL), COALESCE((SELECT last_error FROM data_health WHERE source=?), NULL), ?, ?)
        """, [source, utc_now(), source, source, rows_added, json.dumps(detail or {})])

    def error(self, source: str, error: Exception | str, detail: dict | None = None):
        db.execute("""
            INSERT OR REPLACE INTO data_health(source,status,last_success_at,last_error_at,last_error,rows_added,detail)
            VALUES (?, 'error', COALESCE((SELECT last_success_at FROM data_health WHERE source=?), NULL), ?, ?, COALESCE((SELECT rows_added FROM data_health WHERE source=?), 0), ?)
        """, [source, source, utc_now(), str(error)[:1000], source, json.dumps(detail or {})])

    def skipped(self, source: str, reason: str, detail: dict | None = None):
        db.execute("""
            INSERT OR REPLACE INTO data_health(source,status,last_success_at,last_error_at,last_error,rows_added,detail)
            VALUES (?, 'skipped', COALESCE((SELECT last_success_at FROM data_health WHERE source=?), NULL), ?, ?, COALESCE((SELECT rows_added FROM data_health WHERE source=?), 0), ?)
        """, [source, source, utc_now(), reason[:1000], source, json.dumps(detail or {})])

    def list(self):
        return db.df("SELECT * FROM data_health ORDER BY source").to_dict("records")
