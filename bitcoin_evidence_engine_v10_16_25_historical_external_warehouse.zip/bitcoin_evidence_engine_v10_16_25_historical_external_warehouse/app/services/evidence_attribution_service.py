from __future__ import annotations
import json
import uuid
from datetime import datetime, timezone
from app.db.database import db
from app.core.debug import append_jsonl, write_json
from app.core.logger import log


def _bucket(name: str, value, cuts: list[tuple[float, str]], default: str = "unknown") -> tuple[str, str]:
    try:
        v = float(value)
    except Exception:
        return f"{name}:unknown", f"{name} unknown"
    for cut, label in cuts:
        if v <= cut:
            return f"{name}:{label}", f"{name} {label}"
    return f"{name}:{default}", f"{name} {default}"


class EvidenceAttributionService:
    """Learns which signals are present during Time Machine wins/fails.

    This is intentionally simple and inspectable: every completed Time Machine
    horizon item emits attribution events for the contributing models and a few
    setup buckets. The aggregate table then tells us which signals are actually
    useful per horizon.
    """

    def record_time_machine_items(self, *, batch_id: str, cutoff_ms: int, items: list[dict]) -> None:
        now = datetime.now(timezone.utc)
        event_count = 0
        try:
            for item in items:
                if item.get("actual_price") is None or item.get("target_reached") is None:
                    continue
                horizon = str(item.get("horizon"))
                won = bool(item.get("target_reached"))
                partial = bool(item.get("partial_reached")) or (not won and float(item.get("total_score") or 0.0) >= 55.0)
                target_gap = float(item.get("target_gap_pct") or 0.0)
                score = float(item.get("total_score") or 0.0)
                signals = self._signals_for_item(item)
                for sig in signals:
                    self._insert_event(
                        batch_id=batch_id,
                        created_at=now,
                        cutoff_ms=int(item.get("cutoff_ms") or cutoff_ms or 0),
                        horizon=horizon,
                        signal=sig,
                        won=won,
                        target_gap=target_gap,
                        score=score,
                    )
                    self._update_stat(horizon=horizon, signal=sig, won=won or partial, target_gap=target_gap, score=score, now=now)
                    event_count += 1
            append_jsonl("evidence_attribution_audit.jsonl", {"event":"attribution_recorded", "batch_id":batch_id, "cutoff_ms":cutoff_ms, "items":len(items), "events":event_count})
        except Exception as exc:
            # Attribution must never break Time Machine. It is a learning layer.
            log.exception("Evidence attribution failed: %s", exc)
            append_jsonl("evidence_attribution_audit.jsonl", {"event":"attribution_failed", "batch_id":batch_id, "error":str(exc)})

    def _signals_for_item(self, item: dict) -> list[dict]:
        signals: list[dict] = []
        # Setup buckets.
        prob = float(item.get("bullish_probability") or 0.5) * 100.0
        conf = float(item.get("confidence") or 0.0)
        exp_move = float(item.get("expected_move_pct") or 0.0)
        direction = "up" if prob >= 50 else "down"
        for key, label, typ, meta in [
            (f"direction:{direction}", f"Forecast richting {direction}", "setup", {"prob": prob}),
            (*_bucket("prob", abs(prob-50), [(2.5,"neutral"),(7.5,"light_edge"),(15,"strong_edge")], "extreme_edge"), "setup", {"prob": prob}),
            (*_bucket("confidence", conf, [(35,"low"),(55,"medium"),(75,"high")], "very_high"), "setup", {"confidence": conf}),
            (*_bucket("target_move_abs", abs(exp_move), [(0.75,"tiny"),(2.5,"small"),(8,"medium")], "large"), "setup", {"expected_move_pct": exp_move}),
        ]:
            signals.append({"key": key, "label": label, "type": typ, "metadata": meta})

        # Model contributions.
        contribs = item.get("contributions") or []
        if not contribs and item.get("model_contributions_json"):
            try:
                contribs = json.loads(item.get("model_contributions_json") or "[]")
            except Exception:
                contribs = []
        for m in contribs:
            mid = str(m.get("model_id") or m.get("name") or "unknown_model")
            name = str(m.get("name") or mid)
            try:
                mbull = float(m.get("bullish_probability", 0.5))
            except Exception:
                mbull = 0.5
            try:
                weight = float(m.get("weight", 0.0))
            except Exception:
                weight = 0.0
            if weight < 0.15:
                continue
            bias = "bullish" if mbull >= 0.55 else "bearish" if mbull <= 0.45 else "neutral"
            signals.append({
                "key": f"model:{mid}:{bias}",
                "label": f"{name} {bias}",
                "type": "model",
                "metadata": {"model_id": mid, "name": name, "bullish_probability": mbull, "weight": weight, "reason": m.get("reason")},
            })
        # Deduplicate per item so one model cannot double-count the same horizon.
        out = []
        seen = set()
        for sig in signals:
            if sig["key"] in seen:
                continue
            seen.add(sig["key"])
            out.append(sig)
        return out

    def _insert_event(self, *, batch_id: str, created_at, cutoff_ms: int, horizon: str, signal: dict, won: bool, target_gap: float, score: float) -> None:
        db.execute("""
            INSERT OR REPLACE INTO evidence_attribution_events
            (event_id, batch_id, created_at, cutoff_ms, horizon, signal_key, signal_label, signal_type,
             target_reached, target_gap_pct, total_score, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            str(uuid.uuid4()), batch_id, created_at, cutoff_ms, horizon, signal["key"], signal.get("label"),
            signal.get("type"), bool(won), float(target_gap), float(score), json.dumps(signal.get("metadata") or {})
        ])

    def _update_stat(self, *, horizon: str, signal: dict, won: bool, target_gap: float, score: float, now) -> None:
        row = db.fetchone("""
            SELECT total, wins, losses, avg_target_gap_pct, avg_score
            FROM evidence_attribution_stats WHERE signal_key=? AND horizon=?
        """, [signal["key"], horizon])
        if row:
            total, wins, losses, avg_gap, avg_score = int(row[0] or 0), int(row[1] or 0), int(row[2] or 0), float(row[3] or 0), float(row[4] or 0)
        else:
            total = wins = losses = 0
            avg_gap = avg_score = 0.0
        new_total = total + 1
        new_wins = wins + (1 if won else 0)
        new_losses = losses + (0 if won else 1)
        new_hitrate = new_wins / new_total if new_total else 0.0
        new_avg_gap = (avg_gap * total + abs(float(target_gap))) / new_total
        new_avg_score = (avg_score * total + float(score)) / new_total
        db.execute("""
            INSERT OR REPLACE INTO evidence_attribution_stats
            (signal_key, signal_label, signal_type, horizon, total, wins, losses, hitrate,
             avg_target_gap_pct, avg_score, last_seen_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            signal["key"], signal.get("label"), signal.get("type"), horizon,
            new_total, new_wins, new_losses, new_hitrate, new_avg_gap, new_avg_score, now
        ])

    def leaderboard(self, min_total: int = 3, limit: int = 60) -> dict:
        rows = db.df("""
            SELECT signal_key, signal_label, signal_type, horizon, total, wins, losses, hitrate,
                   avg_target_gap_pct, avg_score, last_seen_at
            FROM evidence_attribution_stats
            WHERE total >= ?
            ORDER BY hitrate DESC, total DESC, avg_score DESC
            LIMIT ?
        """, [int(min_total), int(limit)]).to_dict("records")
        by_horizon = db.df("""
            SELECT horizon, signal_key, signal_label, signal_type, total, wins, losses, hitrate,
                   avg_target_gap_pct, avg_score
            FROM evidence_attribution_stats
            WHERE total >= ?
            QUALIFY ROW_NUMBER() OVER (PARTITION BY horizon ORDER BY hitrate DESC, total DESC, avg_score DESC) <= 8
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END,
                     hitrate DESC, total DESC
        """, [int(min_total)]).to_dict("records")
        weak = db.df("""
            SELECT signal_key, signal_label, signal_type, horizon, total, wins, losses, hitrate,
                   avg_target_gap_pct, avg_score
            FROM evidence_attribution_stats
            WHERE total >= ?
            ORDER BY hitrate ASC, total DESC
            LIMIT ?
        """, [int(min_total), int(limit//2)]).to_dict("records")
        data = {"top": rows, "by_horizon": by_horizon, "weak": weak}
        write_json("last_evidence_attribution.json", data)
        return data
