from __future__ import annotations
from app.db.database import db
from app.core.time_utils import utc_now, to_ms

class AuditService:
    def audit_due_predictions(self) -> dict:
        now = utc_now(); now_ms = to_ms(now)
        due = db.fetchall("""
            SELECT item_id, horizon, due_at_ms, start_price, bullish_probability, expected_price, expected_move_pct, invalidation_price
            FROM forecast_items
            WHERE status='open' AND due_at_ms <= ?
        """, [now_ms])
        resolved=0
        for item_id, horizon, due_at_ms, start_price, bull, expected, expected_move_pct, invalidation_price in due:
            actual_info = self._range_until_due(int(due_at_ms), horizon)
            if actual_info is None:
                continue
            actual = float(actual_info['close'])
            actual_high = float(actual_info['high'])
            actual_low = float(actual_info['low'])
            actual_move = (actual / float(start_price) - 1) * 100
            predicted_up = float(expected_move_pct or 0) >= 0
            actual_up = actual >= float(start_price)
            correct = predicted_up == actual_up
            price_error = (actual / float(expected) - 1) * 100 if expected else None
            if predicted_up:
                target_touched = actual_high >= float(expected)
                invalidated = actual_low <= float(invalidation_price or 0)
                closest = actual_high
            else:
                target_touched = actual_low <= float(expected)
                invalidated = actual_high >= float(invalidation_price or 999999999)
                closest = actual_low
            target_reached = bool(target_touched and not invalidated)
            target_gap_pct = (closest / float(expected) - 1) * 100 if expected else None
            db.execute("""
                UPDATE forecast_items
                SET status='resolved', actual_price=?, actual_high=?, actual_low=?, actual_move_pct=?,
                    direction_correct=?, target_reached=?, target_gap_pct=?, price_error_pct=?, resolved_at=?
                WHERE item_id=?
            """, [actual, actual_high, actual_low, actual_move, correct, target_reached, target_gap_pct, price_error, now, item_id])
            self._update_model_scores(item_id, horizon, target_reached, abs(price_error or 0))
            resolved += 1
        return {"resolved": resolved, "checked": len(due)}

    def _range_until_due(self, due_at_ms: int, horizon: str) -> dict | None:
        # Get final close at/after due and high/low from the previous horizon window.
        close_row = db.fetchone("""
            SELECT open_time, close FROM raw_candles
            WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h' AND open_time >= ?
            ORDER BY open_time ASC LIMIT 1
        """, [due_at_ms])
        if not close_row:
            return None
        # Use a conservative open_time window ending at the resolved due candle.
        from app.core.time_utils import HORIZON_SECONDS
        start_ms = int(close_row[0]) - HORIZON_SECONDS[horizon] * 1000
        range_row = db.fetchone("""
            SELECT MAX(high), MIN(low) FROM raw_candles
            WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h' AND open_time>? AND open_time<=?
        """, [start_ms, int(close_row[0])])
        return {"close": float(close_row[1]), "high": float(range_row[0] or close_row[1]), "low": float(range_row[1] or close_row[1])}

    def _price_at_or_after(self, timestamp_ms: int) -> float | None:
        row = db.fetchone("""
            SELECT close FROM raw_candles
            WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h' AND open_time >= ?
            ORDER BY open_time ASC LIMIT 1
        """, [timestamp_ms])
        return float(row[0]) if row else None

    def _update_model_scores(self, item_id: str, horizon: str, correct: bool, abs_error: float):
        row = db.fetchone("SELECT contributions_json FROM forecast_items WHERE item_id=?", [item_id])
        if not row or not row[0]: return
        import json
        for m in json.loads(row[0]):
            model_id = m.get('model_id')
            old = db.fetchone("SELECT total, correct, avg_price_error_pct FROM model_scores WHERE model_id=? AND horizon=?", [model_id, horizon])
            if old:
                total, corr, avg_err = int(old[0]), int(old[1]), float(old[2] or 0)
            else:
                total, corr, avg_err = 0, 0, 0.0
            total += 1; corr += 1 if correct else 0
            avg_err = ((avg_err*(total-1)) + abs_error) / total
            hitrate = corr / total if total else 0.5
            db.execute("""
                INSERT OR REPLACE INTO model_scores VALUES (?, ?, ?, ?, ?, ?, ?)
            """, [model_id, horizon, total, corr, hitrate, avg_err, utc_now()])
