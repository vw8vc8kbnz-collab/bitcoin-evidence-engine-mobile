from __future__ import annotations

import json
import os
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl
from app.db.database import db
from app.services.historical_memory_service import HistoricalMemoryService


class SeedExportService:
    """Create a verified portable seed snapshot from the shared local database.

    V10.15.7 makes the export unambiguous for Stijn:
    - the UI may say 70k is complete because the app is reading the shared
      AppData database, not because the extracted ZIP folder itself contains the
      seed yet;
    - this service writes a real folder snapshot under exports/seed_snapshot/
      and then zips that exact folder;
    - the manifest includes row counts, ranges, source DB path and DB size;
    - the result is marked seed_ready only when the source DB really contains
      at least 70,000 Binance BTCUSDT 1h candles.
    """

    EXPORT_DIR = settings.base_dir / "exports"
    SNAPSHOT_DIR = EXPORT_DIR / "seed_snapshot"
    EXPORT_NAME = "bitcoin_evidence_engine_seed_export.zip"
    MIN_SEED_CANDLES = 70000

    def __init__(self) -> None:
        self.export_dir = self.EXPORT_DIR
        self.snapshot_dir = self.SNAPSHOT_DIR
        self.export_dir.mkdir(parents=True, exist_ok=True)

    def manifest(self) -> dict[str, Any]:
        history = self._history_summary()
        db_path = Path(settings.db_path)
        rows = int(history.get("raw_candle_rows") or history.get("stored_rows") or 0)
        db_bytes = self._size(db_path) or 0
        latest_export = self.latest_export_info(include_manifest=False)
        return {
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "engine_version": settings.engine_version,
            "app_name": settings.app_name,
            "seed_ready": bool(rows >= self.MIN_SEED_CANDLES and db_path.exists() and db_bytes > 0),
            "seed_ready_reason": self._ready_reason(rows, db_path, db_bytes),
            "required_min_candles": self.MIN_SEED_CANDLES,
            "source_database": {
                "path": str(db_path),
                "exists": db_path.exists(),
                "bytes": db_bytes,
                "is_shared_appdata": "BitcoinEvidenceEngine" in str(db_path) and "AppData" in str(db_path),
            },
            "snapshot_folder": str(self.snapshot_dir),
            "latest_export": latest_export,
            "data_dir": str(settings.data_dir),
            "history": history,
            "tables": self._table_counts(),
            "ranges": self._ranges(),
            "learning": self._learning_summary(),
            "files": self._file_summary(),
            "notes": [
                "If this manifest says seed_ready=true, the export contains the actual DuckDB seed data, not just logs.",
                "The app normally reads the shared LOCALAPPDATA database so new builds do not re-download 70k candles.",
                "The next ChatGPT build can embed data/bitcoin_evidence_engine.duckdb from this export as the standard seed database.",
            ],
        }

    def export_seed_zip(self) -> dict[str, Any]:
        manifest = self.manifest()
        rows = int((manifest.get("history") or {}).get("raw_candle_rows") or 0)
        if not manifest.get("seed_ready"):
            append_jsonl("seed_export_audit.jsonl", {"event": "seed_export_refused_not_ready_v10157", "rows": rows, "manifest": manifest})
            return {
                "ok": False,
                "error": manifest.get("seed_ready_reason") or "seed database is not ready",
                "seed_ready": False,
                "manifest": manifest,
            }

        # Force DuckDB to flush before copying. Sidecars are copied too.
        try:
            db.execute("CHECKPOINT")
        except Exception as exc:
            append_jsonl("seed_export_audit.jsonl", {"event": "checkpoint_failed", "error": str(exc)})

        self._build_snapshot_folder(manifest)
        out = self.export_dir / self.EXPORT_NAME
        tmp = self.export_dir / (self.EXPORT_NAME + ".tmp")
        if tmp.exists():
            tmp.unlink()

        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for p in self.snapshot_dir.rglob("*"):
                if p.is_file():
                    zf.write(p, p.relative_to(self.snapshot_dir).as_posix())
        tmp.replace(out)

        verify = self._verify_export_zip(out)
        result = {
            "ok": bool(verify.get("ok")),
            "path": str(out),
            "folder": str(self.snapshot_dir),
            "filename": out.name,
            "bytes": out.stat().st_size,
            "download_url": "/api/seed-export/download",
            "seed_ready": True,
            "verification": verify,
            "manifest": manifest,
        }
        append_jsonl("seed_export_audit.jsonl", {"event": "seed_export_created_v10157", **{k: v for k, v in result.items() if k != "manifest"}, "history": manifest.get("history")})
        return result

    def latest_export_info(self, include_manifest: bool = True) -> dict[str, Any]:
        out = self.export_dir / self.EXPORT_NAME
        info: dict[str, Any] = {"exists": out.exists(), "path": str(out), "download_url": "/api/seed-export/download"}
        if out.exists():
            info.update({
                "filename": out.name,
                "bytes": out.stat().st_size,
                "modified_at": datetime.fromtimestamp(out.stat().st_mtime, timezone.utc).isoformat(),
            })
            if include_manifest:
                try:
                    with zipfile.ZipFile(out) as zf:
                        raw = zf.read("seed_manifest.json")
                        man = json.loads(raw.decode("utf-8"))
                        info["manifest_history_rows"] = int((man.get("history") or {}).get("raw_candle_rows") or 0)
                        info["manifest_seed_ready"] = bool(man.get("seed_ready"))
                except Exception as exc:
                    info["manifest_error"] = str(exc)
        info["snapshot_folder_exists"] = self.snapshot_dir.exists()
        info["snapshot_folder"] = str(self.snapshot_dir)
        return info

    def _build_snapshot_folder(self, manifest: dict[str, Any]) -> None:
        if self.snapshot_dir.exists():
            shutil.rmtree(self.snapshot_dir)
        (self.snapshot_dir / "data").mkdir(parents=True, exist_ok=True)
        (self.snapshot_dir / "logs").mkdir(parents=True, exist_ok=True)
        (self.snapshot_dir / "data_extra").mkdir(parents=True, exist_ok=True)

        (self.snapshot_dir / "seed_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        self._copy_database_files(self.snapshot_dir / "data")
        self._copy_data_sidecars(self.snapshot_dir / "data_extra")
        self._copy_logs(self.snapshot_dir / "logs")
        self._copy_native_cache(self.snapshot_dir)
        self._write_readme(self.snapshot_dir)

    def _copy_database_files(self, target: Path) -> None:
        db_path = Path(settings.db_path)
        candidates = [db_path]
        candidates.extend(db_path.parent.glob(db_path.name + "*"))
        candidates.extend(db_path.parent.glob(db_path.stem + ".wal"))
        seen: set[Path] = set()
        for p in candidates:
            if not p.exists() or not p.is_file():
                continue
            try:
                rp = p.resolve()
            except Exception:
                rp = p
            if rp in seen:
                continue
            seen.add(rp)
            shutil.copy2(p, target / p.name)

    def _copy_data_sidecars(self, target: Path) -> None:
        data_dir = Path(settings.data_dir)
        if not data_dir.exists():
            return
        for p in data_dir.rglob("*"):
            if not p.is_file():
                continue
            if p.name.startswith("bitcoin_evidence_engine.duckdb"):
                continue
            if p.suffix.lower() in {".tmp", ".lock"}:
                continue
            try:
                rel = p.relative_to(data_dir)
            except Exception:
                rel = Path(p.name)
            dst = target / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copy2(p, dst)
            except Exception:
                pass

    def _copy_logs(self, target: Path) -> None:
        logs = settings.base_dir / "logs"
        if not logs.exists():
            return
        important = {
            "adaptive_feature_weights.json", "historical_memory_audit.jsonl", "sync_audit.jsonl",
            "time_machine_audit.jsonl", "native_core_audit.jsonl", "startup_data_migration.jsonl",
            "seed_export_audit.jsonl", "bee_runtime.log", "last_data_readiness.json",
            "last_data_health_snapshot.json", "last_time_machine_run.json",
        }
        for p in logs.rglob("*"):
            if not p.is_file():
                continue
            try:
                size = p.stat().st_size
            except Exception:
                size = 0
            if p.name not in important and size > 10 * 1024 * 1024:
                continue
            try:
                rel = p.relative_to(logs)
            except Exception:
                rel = Path(p.name)
            dst = target / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copy2(p, dst)
            except Exception:
                pass

    def _copy_native_cache(self, root_target: Path) -> None:
        roots = [(settings.base_dir / "native_cache", "native_cache"), (Path(settings.data_dir) / "native_cache", "native_cache_shared")]
        for root, prefix in roots:
            if not root.exists():
                continue
            for p in root.rglob("*"):
                if not p.is_file():
                    continue
                try:
                    rel = p.relative_to(root)
                except Exception:
                    rel = Path(p.name)
                dst = root_target / prefix / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(p, dst)
                except Exception:
                    pass

    def _write_readme(self, root: Path) -> None:
        (root / "README_SEED_EXPORT.txt").write_text(
            "Bitcoin Evidence Engine Seed Snapshot\n"
            "====================================\n\n"
            "Stuur de ZIP bitcoin_evidence_engine_seed_export.zip terug naar ChatGPT.\n"
            "Deze snapshot bevat de echte DuckDB database onder data/ en niet alleen debug-logs.\n\n"
            "Belangrijk:\n"
            "- 70k history kan in de UI compleet lijken omdat de app de gedeelde AppData DB gebruikt.\n"
            "- Pas deze export-ZIP is het bestand dat in een volgende build standaard ingebouwd kan worden.\n"
            "- Controleer seed_manifest.json: seed_ready moet true zijn en raw_candle_rows moet >= 70000 zijn.\n",
            encoding="utf-8",
        )

    def _verify_export_zip(self, out: Path) -> dict[str, Any]:
        try:
            with zipfile.ZipFile(out) as zf:
                names = set(zf.namelist())
                man = json.loads(zf.read("seed_manifest.json").decode("utf-8"))
                rows = int((man.get("history") or {}).get("raw_candle_rows") or 0)
                db_present = "data/bitcoin_evidence_engine.duckdb" in names
                return {"ok": db_present and rows >= self.MIN_SEED_CANDLES, "db_present": db_present, "rows": rows, "file_count": len(names)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def _ready_reason(self, rows: int, db_path: Path, db_bytes: int) -> str:
        if not db_path.exists():
            return f"source database not found: {db_path}"
        if db_bytes <= 0:
            return f"source database exists but is empty: {db_path}"
        if rows < self.MIN_SEED_CANDLES:
            return f"history not complete for seed export: {rows}/{self.MIN_SEED_CANDLES} candles"
        return f"ready: {rows}/{self.MIN_SEED_CANDLES} candles in {db_path}"

    def _history_summary(self) -> dict[str, Any]:
        try:
            status = HistoricalMemoryService().history_status()
        except Exception as exc:
            status = {"error": str(exc)}
        row = self._one("""
            SELECT COUNT(*) AS rows, MIN(open_time) AS min_ts, MAX(open_time) AS max_ts,
                   MIN(close) AS min_close, MAX(close) AS max_close
            FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'
        """, [settings.symbol])
        status.update({
            "raw_candle_rows": int(row[0] or 0) if row else 0,
            "raw_min_open_time_ms": int(row[1]) if row and row[1] is not None else None,
            "raw_max_open_time_ms": int(row[2]) if row and row[2] is not None else None,
            "raw_min_close": float(row[3]) if row and row[3] is not None else None,
            "raw_max_close": float(row[4]) if row and row[4] is not None else None,
        })
        return status

    def _table_counts(self) -> dict[str, int]:
        tables = [
            "raw_candles", "raw_metric_points", "features", "forecast_runs", "forecast_items",
            "model_scores", "sync_state", "evidence_snapshots", "time_machine_tests",
            "evidence_attribution_stats", "evidence_attribution_events",
            "time_machine_feature_snapshots", "time_machine_signal_scores",
            "adaptive_feature_weights", "historical_memory_runs", "data_health",
        ]
        out: dict[str, int] = {}
        for t in tables:
            try:
                row = db.fetchone(f"SELECT COUNT(*) FROM {t}")
                out[t] = int(row[0] or 0) if row else 0
            except Exception:
                out[t] = -1
        return out

    def _ranges(self) -> dict[str, Any]:
        return {
            "raw_candles_binance_1h": self._range("raw_candles", "open_time", "source='binance' AND symbol='BTCUSDT' AND interval='1h'"),
            "features_1h": self._range("features", "timestamp_ms", "interval='1h'"),
            "time_machine_tests": self._range("time_machine_tests", "cutoff_ms", "1=1"),
            "time_machine_feature_snapshots": self._range("time_machine_feature_snapshots", "cutoff_ms", "1=1"),
            "raw_metric_points": self._range("raw_metric_points", "timestamp_ms", "1=1"),
        }

    def _learning_summary(self) -> dict[str, Any]:
        return {
            "time_machine_by_horizon": self._rows("""
                SELECT horizon, COUNT(*) AS tests,
                       SUM(CASE WHEN direction_correct THEN 1 ELSE 0 END) AS direction_wins,
                       SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS target_wins,
                       AVG(total_score) AS avg_score
                FROM time_machine_tests GROUP BY horizon ORDER BY horizon
            """),
            "feature_snapshots_by_horizon": self._rows("""
                SELECT horizon, COUNT(*) AS snapshots, AVG(total_score) AS avg_score
                FROM time_machine_feature_snapshots GROUP BY horizon ORDER BY horizon
            """),
            "signal_score_top": self._rows("""
                SELECT signal_key, horizon, regime, total, wins, partials, fails, hitrate, avg_score
                FROM time_machine_signal_scores ORDER BY total DESC, hitrate DESC LIMIT 50
            """),
            "adaptive_weights": self._rows("""
                SELECT dimension, weight, quality, sample, matched_signals, updated_at
                FROM adaptive_feature_weights ORDER BY sample DESC, dimension LIMIT 100
            """),
        }

    def _file_summary(self) -> dict[str, Any]:
        return {
            "db_bytes": self._size(Path(settings.db_path)),
            "export_dir": str(self.export_dir),
            "snapshot_dir": str(self.snapshot_dir),
            "logs_dir": str(settings.base_dir / "logs"),
            "data_dir": str(settings.data_dir),
        }

    def _range(self, table: str, col: str, where: str) -> dict[str, Any]:
        try:
            row = db.fetchone(f"SELECT COUNT(*), MIN({col}), MAX({col}) FROM {table} WHERE {where}")
            return {"rows": int(row[0] or 0), "min_ms": int(row[1]) if row and row[1] is not None else None, "max_ms": int(row[2]) if row and row[2] is not None else None}
        except Exception as exc:
            return {"error": str(exc)}

    def _size(self, p: Path) -> int | None:
        try:
            return p.stat().st_size if p.exists() else None
        except Exception:
            return None

    def _one(self, sql: str, params: list[Any] | None = None):
        try:
            return db.fetchone(sql, params or [])
        except Exception:
            return None

    def _rows(self, sql: str, params: list[Any] | None = None) -> list[dict[str, Any]]:
        try:
            frame = db.df(sql, params or [])
            return json.loads(frame.to_json(orient="records", date_format="iso"))
        except Exception as exc:
            return [{"error": str(exc)}]
