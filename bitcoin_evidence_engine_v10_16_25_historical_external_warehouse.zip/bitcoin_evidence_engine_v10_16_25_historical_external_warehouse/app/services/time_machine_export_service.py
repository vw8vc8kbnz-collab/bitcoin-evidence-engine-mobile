from __future__ import annotations

import csv
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl
from app.db.database import db


def _safe_json(obj: Any) -> Any:
    try:
        import math
        if obj is None or isinstance(obj, (str, bool, int)):
            return obj
        if isinstance(obj, float):
            return obj if math.isfinite(obj) else None
        if isinstance(obj, dict):
            return {str(k): _safe_json(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [_safe_json(v) for v in obj]
        if hasattr(obj, 'item'):
            return _safe_json(obj.item())
        if hasattr(obj, 'isoformat'):
            return obj.isoformat()
    except Exception:
        pass
    return str(obj)


class TimeMachineExportService:
    """Persistent Time Machine evidence exports.

    Random100/Random1000 should be analyzable later exactly like the local debug
    folders. This service stores the raw native items, summary, and relevant DB
    rows under the shared data directory, so exports survive new ZIP versions.
    """

    ROOT = settings.data_dir / "time_machine_exports"

    def __init__(self) -> None:
        self.root = self.ROOT
        self.root.mkdir(parents=True, exist_ok=True)

    def _evidence_data_status(self) -> dict:
        """Snapshot of what evidence data is truly present in the DB.

        Included in every Time Machine ZIP so audits can distinguish real
        external history from proxy/model placeholders.
        """
        metrics = [
            ("Binance Spot candles", "raw_candles", "binance", "BTCUSDT 1h OHLCV", "core_price"),
            ("Binance Futures funding", "raw_metric_points", "binance_futures", "funding_rate", "futures"),
            ("Binance Futures open interest", "raw_metric_points", "binance_futures", "open_interest_value", "futures"),
            ("Long/Short ratio", "raw_metric_points", "binance_futures", "long_short_ratio", "futures"),
            ("Top position L/S", "raw_metric_points", "binance_futures", "top_position_long_short_ratio", "futures"),
            ("Top account L/S", "raw_metric_points", "binance_futures", "top_account_long_short_ratio", "futures"),
            ("Taker buy/sell ratio", "raw_metric_points", "binance_futures", "taker_buy_sell_ratio", "orderflow"),
            ("Taker delta", "raw_metric_points", "binance_futures", "taker_delta_ratio", "orderflow"),
            ("Futures basis/premium", "raw_metric_points", "binance_futures", "futures_basis_premium_pct", "futures"),
            ("Composite orderbook", "raw_metric_points", "composite_orderbook", "orderbook_imbalance", "orderbook"),
            ("Fear & Greed", "raw_metric_points", "alternative_me", "fear_greed", "sentiment"),
            ("Coinbase premium", "raw_metric_points", "spot_composite", "spot_premium_coinbase_pct", "cross_exchange"),
            ("Kraken premium", "raw_metric_points", "spot_composite", "spot_premium_kraken_pct", "cross_exchange"),
            ("Coinbase hourly close", "raw_metric_points", "coinbase_history", "btc_close", "cross_exchange"),
            ("Kraken hourly close", "raw_metric_points", "kraken_history", "btc_close", "cross_exchange"),
            ("CoinMetrics MVRV", "raw_metric_points", "coinmetrics_community", "CapMVRVCur", "onchain"),
        ]
        rows=[]
        for label, table, source, metric, group in metrics:
            try:
                if table == "raw_candles":
                    r = db.fetchone("SELECT COUNT(*), MIN(open_time), MAX(open_time) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
                else:
                    r = db.fetchone("SELECT COUNT(*), MIN(timestamp_ms), MAX(timestamp_ms) FROM raw_metric_points WHERE source=? AND metric=?", [source, metric])
                count = int(r[0] or 0) if r else 0
                min_ms = int(r[1]) if r and r[1] is not None else None
                max_ms = int(r[2]) if r and r[2] is not None else None
            except Exception:
                count, min_ms, max_ms = 0, None, None
            status = "active" if count >= 1000 else ("partial" if count > 0 else "missing")
            rows.append({"label":label,"source":source,"metric":metric,"group":group,"rows":count,"min_ms":min_ms,"max_ms":max_ms,"status":status})
        return {"rows": rows, "summary": {"active": sum(1 for r in rows if r['status']=='active'), "partial": sum(1 for r in rows if r['status']=='partial'), "missing": sum(1 for r in rows if r['status']=='missing'), "total": len(rows)}}

    def _write_evidence_status_files(self, d: Path) -> None:
        status = self._evidence_data_status()
        (d / "evidence_data_status.json").write_text(json.dumps(_safe_json(status), ensure_ascii=False, indent=2), encoding="utf-8")
        with (d / "evidence_data_status.csv").open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=["label","source","metric","group","rows","min_ms","max_ms","status"])
            w.writeheader(); w.writerows(status.get("rows", []))
        (d / "EVIDENCE_DATA_README.txt").write_text(
            "Deze export bevat per datasource hoeveel echte historische rijen beschikbaar zijn.\n"
            "Status active = 1000+ rijen, partial = enkele rijen, missing = geen historische data.\n"
            "Modellen met ontbrekende datasource mogen alleen proxy/laag gewicht gebruiken.\n"
            "Forecast en Time Machine horen dezelfde state-vector/data te gebruiken.\n",
            encoding="utf-8"
        )

    def _batch_dir(self, batch_id: str) -> Path:
        safe = ''.join(ch for ch in str(batch_id) if ch.isalnum() or ch in ('-', '_'))[:80] or 'batch'
        d = self.root / safe
        d.mkdir(parents=True, exist_ok=True)
        return d

    def write_random_batch(self, *, batch_id: str, count: int, native: dict, items: list[dict], summary: dict, source: str) -> dict:
        d = self._batch_dir(batch_id)
        now = datetime.now(timezone.utc).isoformat()
        meta = {
            "ok": True,
            "kind": "time_machine_random_batch",
            "batch_id": batch_id,
            "source": source,
            "requested_count": int(count),
            "item_count": len(items),
            "created_at": now,
            "engine_version": settings.engine_version,
            "data_dir": str(settings.data_dir),
            "db_path": str(settings.db_path),
            "native_elapsed_ms": native.get("elapsed_ms"),
            "native_bridge_elapsed_ms": native.get("native_bridge_elapsed_ms"),
        }
        (d / "manifest.json").write_text(json.dumps(_safe_json(meta), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "summary.json").write_text(json.dumps(_safe_json(summary), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "native_result_without_items.json").write_text(json.dumps(_safe_json({k:v for k,v in native.items() if k != 'items'}), ensure_ascii=False, indent=2), encoding="utf-8")
        self._write_evidence_status_files(d)
        (d / "random_items.json").write_text(json.dumps(_safe_json(items), ensure_ascii=False, indent=2), encoding="utf-8")
        # CSV is easier for ChatGPT/Python analysis and spreadsheet inspection.
        flat_keys = sorted({str(k) for item in items for k in item.keys()})
        with (d / "random_items.csv").open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=flat_keys)
            w.writeheader()
            for item in items:
                row = {}
                for k in flat_keys:
                    v = item.get(k)
                    if isinstance(v, (dict, list, tuple)):
                        row[k] = json.dumps(_safe_json(v), ensure_ascii=False)
                    else:
                        row[k] = _safe_json(v)
                w.writerow(row)
        # Snapshot current learning/stat tables where available. V10.16.16:
        # batch-scoped files first, so the ZIP can be analyzed without mixing
        # older Random100/1000 runs. Aggregate files are still included for
        # context, but are explicitly named *_all.csv.
        batch_sql = {
            "time_machine_tests_batch.csv": ("SELECT * FROM time_machine_tests WHERE batch_id=? ORDER BY cutoff_ms, horizon", [batch_id]),
            "time_machine_feature_snapshots_batch.csv": ("SELECT * FROM time_machine_feature_snapshots WHERE batch_id=? ORDER BY cutoff_ms, horizon", [batch_id]),
            "evidence_attribution_events_batch.csv": ("SELECT * FROM evidence_attribution_events WHERE batch_id=? ORDER BY cutoff_ms, horizon", [batch_id]),
        }
        aggregate_sql = {
            "time_machine_tests_all_recent.csv": ("SELECT * FROM time_machine_tests ORDER BY created_at DESC LIMIT 50000", []),
            "time_machine_feature_snapshots_all_recent.csv": ("SELECT * FROM time_machine_feature_snapshots ORDER BY created_at DESC LIMIT 50000", []),
            "time_machine_signal_scores_all.csv": ("SELECT * FROM time_machine_signal_scores ORDER BY total DESC, hitrate_with_partial DESC LIMIT 50000", []),
            "model_scores.csv": ("SELECT * FROM model_scores ORDER BY horizon, total DESC", []),
            "adaptive_feature_weights.csv": ("SELECT * FROM adaptive_feature_weights ORDER BY sample DESC, quality DESC", []),
            "data_health.csv": ("SELECT * FROM data_health ORDER BY source", []),
            "raw_metric_points_recent.csv": ("SELECT * FROM raw_metric_points ORDER BY timestamp_ms DESC LIMIT 20000", []),
            "features_recent_snapshot.csv": ("SELECT * FROM features ORDER BY timestamp_ms DESC LIMIT 10000", []),
        }
        for name, (sql, params) in {**batch_sql, **aggregate_sql}.items():
            try:
                frame = db.df(sql, params) if params else db.df(sql)
                frame.to_csv(d / name, index=False)
            except Exception as exc:
                (d / (name + ".error.txt")).write_text(str(exc), encoding="utf-8")
        zip_path = self._zip_dir(d)
        latest = {**meta, "path": str(zip_path), "download_url": f"/api/time-machine/export/download?batch_id={batch_id}"}
        (self.root / "latest_random_export.json").write_text(json.dumps(_safe_json(latest), ensure_ascii=False, indent=2), encoding="utf-8")
        append_jsonl("time_machine_export_audit.jsonl", {"event":"tm_random_export_written_v101615", **latest})
        return latest

    def _zip_dir(self, d: Path) -> Path:
        out = d.with_suffix(".zip")
        tmp = out.with_suffix(".zip.tmp")
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for p in sorted(d.rglob("*")):
                if p.is_file():
                    zf.write(p, p.relative_to(d.parent))
        tmp.replace(out)
        return out

    def latest_info(self) -> dict:
        p = self.root / "latest_random_export.json"
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                pass
        zips = sorted(self.root.glob("*.zip"), key=lambda q: q.stat().st_mtime if q.exists() else 0, reverse=True)
        if not zips:
            return {"exists": False, "root": str(self.root)}
        batch_id = zips[0].stem
        return {"exists": True, "batch_id": batch_id, "path": str(zips[0]), "download_url": f"/api/time-machine/export/download?batch_id={batch_id}"}


    def list_exports(self, limit: int = 25) -> dict:
        """Return recent persistent Time Machine export batches."""
        rows = []
        for z in sorted(self.root.glob("*.zip"), key=lambda q: q.stat().st_mtime if q.exists() else 0, reverse=True)[:max(1, min(int(limit), 100))]:
            batch_id = z.stem
            meta_path = self.root / batch_id / "manifest.json"
            meta = {"batch_id": batch_id, "path": str(z), "download_url": f"/api/time-machine/export/download?batch_id={batch_id}", "size_bytes": z.stat().st_size}
            try:
                if meta_path.exists():
                    meta.update(json.loads(meta_path.read_text(encoding="utf-8")))
            except Exception:
                pass
            rows.append(_safe_json(meta))
        return {"ok": True, "count": len(rows), "rows": rows, "root": str(self.root)}

    def reset_warehouse(self, *, delete_exports: bool = False) -> dict:
        """Clear Time Machine learning/test warehouse without touching candles.

        This is intentionally scoped: raw_candles, features, forecasts and sync
        state remain intact. Use it before a clean Random100/Random1000 audit so
        old runs do not mix with the new batch.
        """
        tables = [
            "time_machine_tests",
            "time_machine_feature_snapshots",
            "time_machine_signal_scores",
            "evidence_attribution_events",
            "evidence_attribution_stats",
            "adaptive_feature_weights",
            "model_scores",
        ]
        before = {}
        after = {}
        for t in tables:
            try:
                before[t] = int(db.fetchone(f"SELECT COUNT(*) FROM {t}")[0] or 0)
                db.execute(f"DELETE FROM {t}")
                after[t] = int(db.fetchone(f"SELECT COUNT(*) FROM {t}")[0] or 0)
            except Exception as exc:
                before[t] = f"error: {exc}"
                after[t] = None
        exports_deleted = 0
        if delete_exports:
            try:
                for p in self.root.glob("*"):
                    if p.is_file() and p.suffix == ".zip":
                        p.unlink(missing_ok=True); exports_deleted += 1
                    elif p.is_dir():
                        import shutil
                        shutil.rmtree(p, ignore_errors=True); exports_deleted += 1
                (self.root / "latest_random_export.json").unlink(missing_ok=True)
            except Exception as exc:
                append_jsonl("time_machine_export_audit.jsonl", {"event":"reset_exports_failed_v101616", "error":str(exc)})
        payload = {"ok": True, "reset": "time_machine_warehouse_only", "delete_exports": bool(delete_exports), "exports_deleted": exports_deleted, "before": before, "after": after, "data_dir": str(settings.data_dir), "db_path": str(settings.db_path)}
        append_jsonl("time_machine_export_audit.jsonl", {"event":"reset_time_machine_warehouse_v101616", **payload})
        return payload

    def export_path(self, batch_id: str | None = None) -> Path | None:
        if batch_id:
            p = self.root / f"{batch_id}.zip"
            return p if p.exists() else None
        info = self.latest_info()
        p = Path(info.get("path", "")) if info.get("path") else None
        return p if p and p.exists() else None
