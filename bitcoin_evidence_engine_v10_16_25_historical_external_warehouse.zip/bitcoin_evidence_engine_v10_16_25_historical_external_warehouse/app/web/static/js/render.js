import {money,pct,pctRaw,smallDate,statusTag} from './format.js';

export function renderDashboard(data){
  const priceEl=document.getElementById('btcPrice'); if(priceEl) priceEl.textContent = money(data.btc_price);
  const syncEl=document.getElementById('syncState'); if(syncEl) syncEl.textContent = new Date().toLocaleTimeString();
  const topClock=document.getElementById('topClock'); if(topClock) topClock.textContent = new Date().toLocaleTimeString();
  const f=data.latest_feature||{};
  const reg=document.getElementById('regimeCard'); if(reg) reg.textContent=(f.regime||'—').replaceAll('_',' ');
  const comp=document.getElementById('completenessCard'); if(comp) comp.textContent=f.data_completeness==null?'Data —':'Data '+Number(f.data_completeness).toFixed(0)+'%';
  const fear=document.getElementById('fearCard'); if(fear) fear.textContent=f.fear_greed==null?'—':Number(f.fear_greed).toFixed(0);
  const live=document.getElementById('topDataLive'); if(live) live.textContent='Data: '+((data.sync_state||[]).find(x=>x.key==='startup_sync_status')?.value||'sync');
  renderForecast(data.latest_items || []);
  renderContributions(data.latest_items?.[0]);
  renderEvidence(data.latest_feature);
  renderKeyEvidence(data.latest_feature, data.composite_orderbook, data.latest_items || []);
  renderCompositeOrderbook(data.composite_orderbook);
  renderArchive(data.archive || []);
  renderAccuracy(data.accuracy || []);
  renderModels(data.model_scores || []);
  renderHealth(data.data_health || []);
  renderSyncState(data.sync_state || [], data.readiness || {});
  renderConfidence(data.latest_items || []);
}

function renderForecast(items){
  const status=document.getElementById('forecastStatus');
  const el=document.getElementById('forecast');
  const mirror=document.getElementById('forecastMirror');
  if(!items || !items.length){
    if(status) status.textContent='geen forecast-items gevonden';
    const empty = '<div class="empty-state">Nog geen forecast. Klik links op <b>Sync + Forecast</b>. Tijdens de eerste sync zie je voortgang in Data Health en logs/bee_runtime.log.</div>';
    if(el) el.innerHTML = empty; if(mirror) mirror.innerHTML = empty;
    return;
  }
  if(status) status.textContent = `${items.length} horizons · laatste run`;
  const html = `<table class="forecast-table"><thead><tr><th>Horizon</th><th>Direction</th><th>Expected Price</th><th>Move</th><th>Confidence</th><th>Evidence</th><th>Status</th></tr></thead><tbody>${items.map(x=>{
    const bull = Number(x.bullish_probability || 0.5);
    const bear = 1-bull;
    return `<tr>
      <td><b>${x.horizon}</b></td>
      <td><div class="direction-bar"><span class="up">${(bull*100).toFixed(1)}%</span><i><em style="width:${Math.round(bull*100)}%"></em></i><span class="down">${(bear*100).toFixed(1)}%</span></div></td>
      <td><b>${money(x.expected_price)}</b></td>
      <td>${pctRaw(x.expected_move_pct)}</td>
      <td>${Number(x.confidence||0).toFixed(0)}/100</td>
      <td>${x.evidence_count || 0}</td>
      <td><span class="status">${x.status}</span></td>
    </tr>`}).join('')}</tbody></table>`;
  if(el) el.innerHTML = html;
  if(mirror) mirror.innerHTML = html;
}
function renderContributions(item){
  const el=document.getElementById('contributions'); if(!el) return;
  if(!item || !item.contributions_json){ el.innerHTML='<div class="mini">Nog geen modeldata</div>'; return; }
  let models=[]; try{models=JSON.parse(item.contributions_json)}catch(e){}
  el.innerHTML=models.map(m=>`<div class="contrib"><strong>${m.name}</strong><span>${(m.bullish_probability*100).toFixed(1)}% bullish · weight ${Number(m.weight).toFixed(2)}<br>${m.reason||''}</span></div>`).join('');
}
function renderEvidence(f){
  const el=document.getElementById('evidenceGrid');
  if(!el) return;
  if(!f){ el.innerHTML='<div class="mini">Nog geen feature-state. Klik Sync + Forecast.</div>'; return; }
  const fields=[
    ['Regime', f.regime || '—'],
    ['Data completeness', f.data_completeness==null?'—':Number(f.data_completeness).toFixed(1)+'%'],
    ['Funding rate', f.funding_rate==null?'—':(Number(f.funding_rate)*100).toFixed(4)+'%'],
    ['Open interest 24h', f.open_interest_change_24h==null?'—':Number(f.open_interest_change_24h).toFixed(2)+'%'],
    ['Long/short ratio', f.long_short_ratio==null?'—':Number(f.long_short_ratio).toFixed(3)],
    ['Taker buy/sell', f.taker_buy_sell_ratio==null?'—':Number(f.taker_buy_sell_ratio).toFixed(3)],
    ['Taker delta/CVD', f.taker_delta_ratio==null?'—':(Number(f.taker_delta_ratio)*100).toFixed(2)+'%'],
    ['Basis premium', f.futures_basis_premium_pct==null?'—':Number(f.futures_basis_premium_pct).toFixed(3)+'%'],
    ['Top trader pos.', f.top_position_long_short_ratio==null?'—':Number(f.top_position_long_short_ratio).toFixed(3)],
    ['Spot spread', f.cross_exchange_spread_pct==null?'—':Number(f.cross_exchange_spread_pct).toFixed(3)+'%'],
    ['Kraken premium', f.spot_premium_kraken_pct==null?'—':Number(f.spot_premium_kraken_pct).toFixed(3)+'%'],
    ['Coinbase premium', f.spot_premium_coinbase_pct==null?'—':Number(f.spot_premium_coinbase_pct).toFixed(3)+'%'],
    ['Composite orderbook', f.orderbook_imbalance==null?'—':(Number(f.orderbook_imbalance)*100).toFixed(1)+'% bid'],
    ['Composite spread', f.orderbook_spread==null?'—':'$'+Number(f.orderbook_spread).toFixed(2)],
    ['MVRV', f.coinmetrics_mvrv==null?'—':Number(f.coinmetrics_mvrv).toFixed(2)],
    ['Fear & Greed', f.fear_greed==null?'—':Number(f.fear_greed).toFixed(0)],
    ['Drawdown ATH', f.drawdown_from_ath==null?'—':Number(f.drawdown_from_ath).toFixed(1)+'%'],
    ['Cycle progress', f.cycle_progress==null?'—':(Number(f.cycle_progress)*100).toFixed(1)+'%'],
    ['Volume z-score', f.volume_zscore==null?'—':Number(f.volume_zscore).toFixed(2)],
    ['Volume ratio 24h', f.volume_ratio_24==null?'—':Number(f.volume_ratio_24).toFixed(2)+'x'],
    ['Range %', f.range_pct==null?'—':Number(f.range_pct).toFixed(2)+'%'],
    ['Candle body %', f.candle_body_pct==null?'—':Number(f.candle_body_pct).toFixed(2)+'%'],
  ];
  const html=fields.map(([k,v])=>`<div class="evidence"><span>${k}</span><strong>${v}</strong></div>`).join('');
  el.innerHTML=html;
  const dash=document.getElementById('dashboardEvidenceGrid'); if(dash) dash.innerHTML=html;
}



function renderKeyEvidence(f, orderbook, items){
  const el=document.getElementById('keyEvidenceList');
  if(!el) return;
  const avgBull = items && items.length ? items.reduce((a,x)=>a+Number(x.bullish_probability||0.5),0)/items.length : null;
  const rows = [
    ['Overall forecast bias', avgBull==null?'—':(avgBull>=0.5?'Bullish':'Bearish'), avgBull==null?'neutral':avgBull>=0.5?'bullish':'bearish'],
    ['Market regime', f?.regime || '—', 'neutral'],
    ['Data completeness', f?.data_completeness==null?'—':Number(f.data_completeness).toFixed(1)+'%', Number(f?.data_completeness||0)>=70?'bullish':'neutral'],
    ['Funding rates', f?.funding_rate==null?'—':(Number(f.funding_rate)*100).toFixed(4)+'%', Number(f?.funding_rate||0)>0.0005?'bearish':'neutral'],
    ['Open interest 24h', f?.open_interest_change_24h==null?'—':Number(f.open_interest_change_24h).toFixed(2)+'%', 'neutral'],
    ['Taker delta/CVD', f?.taker_delta_ratio==null?'—':(Number(f.taker_delta_ratio)*100).toFixed(2)+'%', Number(f?.taker_delta_ratio||0)>0.06?'bullish':Number(f?.taker_delta_ratio||0)<-0.06?'bearish':'neutral'],
    ['Basis premium', f?.futures_basis_premium_pct==null?'—':Number(f.futures_basis_premium_pct).toFixed(3)+'%', 'neutral'],
    ['Spot source spread', f?.cross_exchange_spread_pct==null?'—':Number(f.cross_exchange_spread_pct).toFixed(3)+'%', Number(f?.cross_exchange_spread_pct||0)<0.12?'bullish':'neutral'],
    ['Composite orderbook', f?.orderbook_imbalance==null?'—':(Number(f.orderbook_imbalance)*100).toFixed(1)+'% bid', Number(f?.orderbook_imbalance||0.5)>=0.53?'bullish':Number(f?.orderbook_imbalance||0.5)<=0.47?'bearish':'neutral'],
    ['MVRV proxy', f?.coinmetrics_mvrv==null?'—':Number(f.coinmetrics_mvrv).toFixed(2), 'neutral'],
    ['Fear & Greed', f?.fear_greed==null?'—':Number(f.fear_greed).toFixed(0), 'neutral']
  ];
  const html = rows.map(([k,v,t])=>`<div class="key-row"><span>${k}</span><b class="${t}">${v}</b></div>`).join('');
  el.innerHTML = html;
  const mirror=document.getElementById('keyEvidenceMirror'); if(mirror) mirror.innerHTML=html;
}


function renderCompositeOrderbook(row){
  const el=document.getElementById('orderbookComposite');
  const dash=document.getElementById('dashboardOrderbookComposite');
  if(!row || !row.metadata){ const empty='<div class="mini">Nog geen composite orderbook snapshot. Klik Sync + Forecast.</div>'; if(el)el.innerHTML=empty; if(dash)dash.innerHTML=empty; return; }
  let x={}; try{x=JSON.parse(row.metadata)}catch(e){}
  const exchanges=(x.exchanges||[]).map(ex=>`<div class="mini"><strong>${ex.exchange}</strong><span>mid: ${money(ex.mid)}<br>spread: ${ex.spread==null?'—':'$'+Number(ex.spread).toFixed(2)}<br>1% bid pressure: ${ex.bands?.['0.0100']?.imbalance==null?'—':(ex.bands['0.0100'].imbalance*100).toFixed(1)+'%'}</span></div>`).join('');
  const walls=(x.walls||[]).slice(0,6).map(w=>`<tr><td>${w.exchange}</td><td>${w.side}</td><td>${money(w.price)}</td><td>${Number(w.btc).toFixed(2)} BTC</td><td>${Number(w.distance_pct).toFixed(2)}%</td></tr>`).join('');
  const html=`
    <div class="evidence-grid">
      <div class="evidence"><span>Composite pressure</span><strong>${x.composite_imbalance==null?'—':(x.composite_imbalance*100).toFixed(1)+'% bid'}</strong></div>
      <div class="evidence"><span>Exchanges active</span><strong>${x.exchange_count||0}/5</strong></div>
      <div class="evidence"><span>Bid liquidity 1%</span><strong>${money(x.bid_notional_1pct)}</strong></div>
      <div class="evidence"><span>Ask liquidity 1%</span><strong>${money(x.ask_notional_1pct)}</strong></div>
    </div>
    <div class="mini-cards" style="margin-top:14px">${exchanges}</div>
    <div class="table-wrap" style="margin-top:14px"><table class="compact"><thead><tr><th>Exchange</th><th>Side</th><th>Price</th><th>Size</th><th>Distance</th></tr></thead><tbody>${walls || '<tr><td colspan="5">Geen grote walls gevonden binnen 2.5%</td></tr>'}</tbody></table></div>`;
  if(el) el.innerHTML=html;
  if(dash) dash.innerHTML=html;
}

function renderArchive(rows){
  const archiveEl=document.getElementById('archiveBody'); if(!archiveEl) return; archiveEl.innerHTML = (rows||[]).map(r=>`<tr><td>#${r.run_id}</td><td>${r.horizon}</td><td>${money(r.start_price)}</td><td>${(r.bullish_probability*100).toFixed(1)}% ${r.bullish_probability>=.5?'up':'down'}</td><td>${money(r.expected_price)}</td><td>${money(r.actual_price)}</td><td>${statusTag(r)}</td></tr>`).join('');
}
function renderAccuracy(rows){
  const el=document.getElementById('accuracyCards'); if(!el) return;
  el.innerHTML = (rows||[]).map(r=>`<div class="mini"><strong>${r.horizon}</strong><span>Hitrate: ${r.hitrate==null?'—':(r.hitrate*100).toFixed(1)+'%'}<br>Total: ${r.total||0}<br>Avg error: ${r.avg_abs_price_error==null?'—':Number(r.avg_abs_price_error).toFixed(2)+'%'}</span></div>`).join('') || '<div class="mini">Nog geen afgeronde voorspellingen</div>';
}
function renderModels(rows){
  const modelEl=document.getElementById('modelBody'); if(!modelEl) return; modelEl.innerHTML = (rows||[]).map(r=>`<tr><td>${r.model_id}</td><td>${r.horizon}</td><td>${(r.hitrate*100).toFixed(1)}%</td><td>${r.total}</td></tr>`).join('') || '<tr><td colspan="4">Nog geen model-scores</td></tr>';
}
function renderHealth(rows){
  const el=document.getElementById('healthGrid'); if(!el) return;
  el.innerHTML = (rows||[]).map(r=>{
    const cls = r.status==='ok' ? 'ok' : (r.status==='skipped' ? 'neutral' : 'error');
    const label = r.status==='skipped' ? 'optional / skipped' : r.status;
    return `<div class="health provider-${cls}"><strong>${r.source}</strong><span>Status: <b class="${cls}">${label}</b><br>Last ok: ${smallDate(r.last_success_at)}<br>${r.last_error?((r.status==='skipped'?'Note: ':'Error: ')+r.last_error):'Geen error'}</span></div>`;
  }).join('') || '<div class="health">Nog geen syncstatus</div>';
}


function renderSyncState(rows, readiness={}){
  const map = Object.fromEntries((rows||[]).map(r=>[r.key, r.value]));
  const startup = map.startup_sync_status || map.manual_sync_status || '—';
  const phase = map.sync_phase || '—';
  const side = document.getElementById('sideSyncStatus');
  const sidePhase = document.getElementById('sideSyncPhase');
  const box = document.getElementById('syncBox');
  if(side) side.textContent = startup;
  if(sidePhase) sidePhase.textContent = phase;
  const hist = readiness && readiness.historical_memory ? readiness.historical_memory : null;
  const histStatus = document.getElementById('historyMemoryStatus');
  const histPhase = document.getElementById('historyMemoryPhase');
  if(hist){
    const stored = Number(hist.stored_rows || 0);
    const target = Number(hist.target_rows || 70000);
    const cov = Number(hist.coverage_pct || 0);
    const label = hist.status_label || (hist.complete ? 'Volledig geladen' : (hist.running ? 'Automatisch laden' : 'In wachtrij'));
    const msg = hist.ui_message || `${stored.toLocaleString()} / ${target.toLocaleString()} · ${cov.toFixed(2)}%`;
    if(histStatus) histStatus.textContent = hist.complete ? 'Volledig geladen' : `${stored.toLocaleString()} / ${target.toLocaleString()}`;
    if(histPhase) histPhase.textContent = hist.complete ? `Klaar · 100% · ${stored.toLocaleString()} candles` : `${label} · ${cov.toFixed(2)}% · nog ${Number(hist.remaining_rows||0).toLocaleString()}`;
    const bar = document.getElementById('historyMemoryBar');
    if(bar) bar.style.width = `${Math.max(0, Math.min(100, cov)).toFixed(2)}%`;
    const progress = bar ? bar.parentElement : null;
    if(progress) progress.classList.toggle('complete', !!hist.complete);
    const memoryBtn = document.getElementById('memoryBtn');
    if(memoryBtn){
      memoryBtn.textContent = hist.complete ? 'History Loaded' : (hist.running ? 'Auto Loading...' : 'Check Auto History');
      memoryBtn.disabled = !!hist.running && !hist.complete;
    }
  }
  if(box) box.innerHTML = `<b>Sync:</b> ${startup}<br><b>Phase:</b> ${phase}<br>${hist ? `<b>History:</b> ${hist.ui_message || `${Number(hist.stored_rows||0).toLocaleString()} / ${Number(hist.target_rows||70000).toLocaleString()} · ${Number(hist.coverage_pct||0).toFixed(2)}%`}<br>` : ''}<small>Details staan ook in logs/bee_runtime.log</small>`;
}

function renderConfidence(items){
  const dial = document.getElementById('confidenceDial');
  if(!dial) return;
  const mirror=document.getElementById('confidenceDialMirror');
  if(!items || !items.length){ const html='<b>—</b><span>nog geen forecast</span>'; dial.innerHTML = html; if(mirror) mirror.innerHTML=html; return; }
  const avg = items.reduce((a,x)=>a+Number(x.confidence||0),0)/items.length;
  const html = `<b>${avg.toFixed(0)}%</b><span>${avg>=70?'High confidence':avg>=50?'Medium confidence':'Low confidence'}</span>`;
  dial.innerHTML = html; if(mirror) mirror.innerHTML=html;
}
