export const money = v => v==null ? '—' : '$' + Number(v).toLocaleString('en-US',{maximumFractionDigits:0});
export const pct = v => v==null ? '—' : (Number(v)*100).toFixed(1) + '%';
export const pctRaw = v => v==null ? '—' : Number(v).toFixed(2) + '%';
export const smallDate = v => v ? new Date(v).toLocaleString() : '—';
export function statusTag(row){
  if(row.status === 'resolved') return row.direction_correct ? '<span class="tag resolved">✅ correct</span>' : '<span class="tag fail">❌ fout</span>';
  return '<span class="tag open">open</span>';
}
