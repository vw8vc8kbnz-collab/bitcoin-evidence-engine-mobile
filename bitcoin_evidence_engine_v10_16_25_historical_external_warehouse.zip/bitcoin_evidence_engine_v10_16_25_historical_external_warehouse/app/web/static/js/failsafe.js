(function(){
  "use strict";
  function $(id){ return document.getElementById(id); }
  function setText(id, txt){ var el=$(id); if(el) el.textContent=txt; }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
  function money(v){ if(v===null || v===undefined || isNaN(Number(v))) return '—'; return '$'+Number(v).toLocaleString('en-US',{maximumFractionDigits:0}); }
  function pctMove(v){ if(v===null || v===undefined || isNaN(Number(v))) return '—'; return Number(v).toFixed(2)+'%'; }
  function pctProb(v){ if(v===null || v===undefined || isNaN(Number(v))) return '—'; return (Number(v)*100).toFixed(1)+'%'; }

  function outcomeTier(x){
    if(!x) return {tier:'open',label:'OPEN',short:'OPEN',explain:'geen data'};
    if(x.target_reached===true || x.outcome_tier==='win') return {tier:'win',label:'✅ WIN',short:'WIN',explain:'doel geraakt vóór invalidatie'};
    if(x.outcome_tier==='partial' || x.partial_reached===true || (!x.invalidated && Number(x.total_score||0)>=55)) return {tier:'partial',label:'🟡 PARTIAL',short:'PARTIAL',explain:x.outcome_explain||'bijna raak zonder invalidatie'};
    if(x.invalidated===true) return {tier:'fail',label:'❌ FAIL',short:'FAIL',explain:'invalidatie geraakt'};
    if(x.target_reached===false) return {tier:'fail',label:'❌ FAIL',short:'FAIL',explain:'doel niet gehaald'};
    if(x.target_touched===true && !x.invalidated) return {tier:'win',label:'✅ WIN',short:'WIN',explain:'target touched vóór invalidatie'};
    return {tier:'open',label:'○ OPEN',short:'OPEN',explain:'geen werkelijkheid'};
  }
  function targetHitBadge(x){ var o=outcomeTier(x); var cls=o.tier==='win'?'strong-hit':(o.tier==='partial'?'near':(o.tier==='fail'?'miss':'open')); return '<span class="tm-outcome '+cls+'">'+esc(o.label)+'</span><small>'+esc(o.explain)+'</small>'; }
  function invalidationCell(x){ if(x.invalidation_price==null)return '<span class="tm-outcome open">—</span><small>geen invalidatie</small>'; var bad=x.invalidated===true; return '<span class="tm-outcome '+(bad?'miss':'strong-hit')+'">'+(bad?'geraakt':'niet geraakt')+'</span><small>'+money(x.invalidation_price)+' · '+(x.invalidation_gap_pct==null?'—':Number(x.invalidation_gap_pct).toFixed(2)+'%')+'</small>'; }
  function targetGapCell(x){ var gap=x.target_gap_pct==null?null:Number(x.target_gap_pct); var err=gap==null?null:Math.abs(gap); var score=x.target_score==null?(x.total_score==null?null:Number(x.total_score)):Number(x.target_score); var label='—', cls='open'; if(err!=null){ if(x.target_reached){label='target bereikt';cls='strong-hit';} else if(err<=0.35){label='net niet';cls='near';} else if(err<=1.25){label='dichtbij';cls='near';} else {label='ver weg';cls='miss';} } return '<span class="tm-outcome '+cls+'">'+esc(label)+'</span><small>'+(score==null?'—':score.toFixed(0)+'/100')+' · afstand '+(gap==null?'—':gap.toFixed(2)+'%')+'</small>'; }
  function directionWordFromMove(v){ var n=Number(v||0); if(Math.abs(n)<0.03)return 'vlak'; return n>0?'omhoog':'omlaag'; }

  function val(v,d){ return (v===null || v===undefined || isNaN(Number(v))) ? '—' : Number(v).toFixed(d==null?2:d); }
  function log(kind, extra){
    try{ fetch('/api/debug/frontend-event', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(Object.assign({kind:kind, failsafe:true, browser_ts:Date.now()}, extra||{}))}).catch(function(){}); }catch(e){}
  }

  var state = {dashboard:null, miniPoints:[], tmPoints:[], tmSelected:null, tmResult:null, refreshing:false, syncing:false, tmLoading:false, tmRunning:false, tmTf:'1h', tmRangeKey:'6M', tmStartMs:null, tmEndMs:null, tmPanOffsetMs:0, tmDrag:null, tmHover:null, tmCustomStartMs:null, tmCustomEndMs:null, tmWheelTimer:null, historyStatus:null, historyPolling:false};

  async function getJSON(url, opts, timeoutMs){
    opts = opts || {};
    timeoutMs = timeoutMs || 12000;
    var ctrl = new AbortController();
    var t = setTimeout(function(){ try{ctrl.abort();}catch(e){} }, timeoutMs);
    try{
      var r = await fetch(url, Object.assign({cache:'no-store', signal:ctrl.signal}, opts));
      var txt = await r.text();
      var data = txt ? JSON.parse(txt) : {};
      if(!r.ok) throw new Error(url+' HTTP '+r.status+' '+txt.slice(0,220));
      return data;
    } catch(e){ if(e && e.name==='AbortError') throw new Error(url+' timeout na '+timeoutMs+'ms'); throw e; } finally { clearTimeout(t); }
  }

  function setPage(page){
    document.querySelectorAll('.page').forEach(function(p){ p.classList.remove('active'); });
    var target=$('page-'+page) || $('page-dashboard');
    if(target) target.classList.add('active');
    document.querySelectorAll('.app-nav button').forEach(function(b){ b.classList.toggle('active', b.getAttribute('data-page')===page); });
    try{ localStorage.setItem('bee_page', page); }catch(e){}
    if(page==='dashboard') setTimeout(drawMiniChart,50);
    if(page==='timemachine') setTimeout(loadTimeMachineChart,80);
  }

  function renderForecast(items){
    var status=$('forecastStatus');
    if(status) status.textContent = items && items.length ? (items.length+' horizons · laatste run') : 'geen forecast-items gevonden';
    var html;
    if(!items || !items.length){
      html='<div class="empty-state">Data wordt automatisch opgehaald. Wacht ±10-30 sec of klik <b>Sync + Forecast</b>.</div>';
    } else {
      html='<table class="forecast-table"><thead><tr><th>Horizon</th><th>Direction</th><th>Expected Price</th><th>Move</th><th>Confidence</th><th>Evidence</th><th>Status</th></tr></thead><tbody>'+items.map(function(x){
        var bull=Number(x.bullish_probability==null?0.5:x.bullish_probability), bear=1-bull;
        return '<tr><td><b>'+esc(x.horizon)+'</b></td><td><div class="direction-bar"><span class="up">'+(bull*100).toFixed(1)+'%</span><i><em style="width:'+Math.round(bull*100)+'%"></em></i><span class="down">'+(bear*100).toFixed(1)+'%</span></div></td><td><b>'+money(x.expected_price)+'</b></td><td>'+pctMove(x.expected_move_pct)+'</td><td>'+val(x.confidence,0)+'/100</td><td>'+esc(x.evidence_count||0)+'</td><td><span class="status">'+esc(x.status||'')+'</span></td></tr>';
      }).join('')+'</tbody></table>';
    }
    ['forecast','forecastMirror'].forEach(function(id){ var el=$(id); if(el) el.innerHTML=html; });
  }


  function renderConfidence(items){
    var html='<b>—</b><span>nog geen forecast</span>';
    if(items && items.length){
      var avg=items.reduce(function(a,x){return a+Number(x.confidence||0);},0)/items.length;
      var label = avg>=70 ? 'High confidence' : (avg>=50 ? 'Medium confidence' : 'Low confidence');
      html='<b>'+avg.toFixed(0)+'/100</b><span>'+label+'</span>';
    }
    ['confidenceDial','confidenceDialMirror'].forEach(function(id){ var el=$(id); if(el) el.innerHTML=html; });
  }

  function renderEvidence(f){
    var fields=[
      ['Regime', f && f.regime || '—'], ['Data completeness', f && f.data_completeness!=null ? val(f.data_completeness,1)+'%' : '—'],
      ['Funding rate', f && f.funding_rate!=null ? (Number(f.funding_rate)*100).toFixed(4)+'%' : '—'], ['Open interest 24h', f && f.open_interest_change_24h!=null ? val(f.open_interest_change_24h,2)+'%' : '—'],
      ['Long/short ratio', f && f.long_short_ratio!=null ? val(f.long_short_ratio,3) : '—'], ['Taker buy/sell', f && f.taker_buy_sell_ratio!=null ? val(f.taker_buy_sell_ratio,3) : '—'],
      ['Taker delta/CVD', f && f.taker_delta_ratio!=null ? (Number(f.taker_delta_ratio)*100).toFixed(2)+'%' : '—'], ['Basis premium', f && f.futures_basis_premium_pct!=null ? val(f.futures_basis_premium_pct,3)+'%' : '—'],
      ['Top trader pos.', f && f.top_position_long_short_ratio!=null ? val(f.top_position_long_short_ratio,3) : '—'], ['Spot spread', f && f.cross_exchange_spread_pct!=null ? val(f.cross_exchange_spread_pct,3)+'%' : '—'],
      ['Composite orderbook', f && f.orderbook_imbalance!=null ? (Number(f.orderbook_imbalance)*100).toFixed(1)+'% bid' : '—'], ['Fear & Greed', f && f.fear_greed!=null ? val(f.fear_greed,0) : '—'],
      ['Drawdown ATH', f && f.drawdown_from_ath!=null ? val(f.drawdown_from_ath,1)+'%' : '—'], ['Cycle progress', f && f.cycle_progress!=null ? (Number(f.cycle_progress)*100).toFixed(1)+'%' : '—'],
      ['Volume z-score', f && f.volume_zscore!=null ? val(f.volume_zscore,2) : '—'], ['Range %', f && f.range_pct!=null ? val(f.range_pct,2)+'%' : '—']
    ];
    var html=fields.map(function(r){return '<div class="evidence"><span>'+esc(r[0])+'</span><strong>'+esc(r[1])+'</strong></div>';}).join('');
    ['evidenceGrid','dashboardEvidenceGrid'].forEach(function(id){ var el=$(id); if(el) el.innerHTML=html; });
  }

  function renderKeyEvidence(f, orderbook, items){
    var avg = items && items.length ? items.reduce(function(a,x){return a+Number(x.bullish_probability||0.5);},0)/items.length : null;
    var rows=[
      ['Overall forecast bias', avg==null?'—':(avg>=0.5?'Bullish '+pctProb(avg):'Bearish '+pctProb(1-avg))],
      ['Market regime', f && f.regime || '—'], ['Data completeness', f && f.data_completeness!=null ? val(f.data_completeness,1)+'%' : '—'],
      ['Funding', f && f.funding_rate!=null ? (Number(f.funding_rate)*100).toFixed(4)+'%' : '—'], ['OI 24h', f && f.open_interest_change_24h!=null ? val(f.open_interest_change_24h,2)+'%' : '—'],
      ['Taker delta', f && f.taker_delta_ratio!=null ? (Number(f.taker_delta_ratio)*100).toFixed(2)+'%' : '—'], ['Composite orderbook', orderbook && orderbook.value!=null ? (Number(orderbook.value)*100).toFixed(1)+'% bid' : '—']
    ];
    var html=rows.map(function(r){return '<div class="key-row"><span>'+esc(r[0])+'</span><b>'+esc(r[1])+'</b></div>';}).join('');
    ['keyEvidenceList','keyEvidenceMirror'].forEach(function(id){ var el=$(id); if(el) el.innerHTML=html; });
  }


  function renderIntegrity(integrity){
    if(!integrity) return;
    var msg = integrity.status==='warning' ? ('integrity warning: '+(integrity.warnings||[]).join('; ')) : 'integrity ok';
    if(integrity.price_delta_pct!=null){ msg += ' · candle/ticker Δ '+Number(integrity.price_delta_pct).toFixed(2)+'%'; }
    if(integrity.status==='warning'){
      setText('sideSyncStatus','data check waarschuwing');
      setText('sideSyncPhase',msg.slice(0,180));
    }
  }

  function renderTables(data){
    var rows=data.data_health||[], el=$('healthGrid');
    if(el) el.innerHTML = rows.length ? rows.map(function(r){return '<div class="health-card"><b>'+esc(r.source)+'</b><span>'+esc(r.status)+'</span><small>'+esc(r.last_error||r.detail||'')+'</small></div>';}).join('') : '<div class="mini">Nog geen providerstatus.</div>';
    el=$('archiveBody'); if(el) el.innerHTML=(data.archive||[]).slice(0,80).map(function(x){return '<tr><td>'+esc(x.run_id)+'</td><td>'+esc(x.horizon)+'</td><td>'+money(x.start_price)+'</td><td>'+pctProb(x.bullish_probability)+'</td><td>'+money(x.expected_price)+'</td><td>'+money(x.actual_price)+'</td><td>'+esc(x.status||'')+'</td></tr>';}).join('');
    el=$('accuracyCards'); if(el) el.innerHTML=(data.accuracy&&data.accuracy.length)?data.accuracy.map(function(r){return '<div class="mini-card"><b>'+esc(r.horizon)+'</b><span>'+((Number(r.hitrate||0)*100).toFixed(1))+'%</span><small>'+esc(r.correct||0)+'/'+esc(r.total||0)+'</small></div>';}).join(''):'<div class="mini">Nog geen verlopen forecasts.</div>';
    el=$('modelBody'); if(el) el.innerHTML=(data.model_scores||[]).slice(0,50).map(function(r){return '<tr><td>'+esc(r.model_id)+'</td><td>'+esc(r.horizon)+'</td><td>'+((Number(r.hitrate||0)*100).toFixed(1))+'%</td><td>'+esc(r.total||0)+'</td></tr>';}).join('');
    ['orderbookComposite','dashboardOrderbookComposite'].forEach(function(oid){ el=$(oid); if(el) el.innerHTML=data.composite_orderbook?'<div class="big-metric">'+(Number(data.composite_orderbook.value||0)*100).toFixed(1)+'% bid</div><small>'+esc(data.composite_orderbook.metadata||'')+'</small>':'<div class="mini">Nog geen composite orderbook.</div>'; });
    var syncHtml = (data.sync_state||[]).map(function(x){return '<div><b>'+esc(x.key)+'</b><br><span>'+esc(x.value)+'</span></div>';}).join('');
    ['syncBox','syncStateBox'].forEach(function(id){ var box=$(id); if(box) box.innerHTML=syncHtml || '<div>Geen sync_state.</div>'; });
  }


  function renderHistoryMemory(hist, source){
    if(!hist) return;
    state.historyStatus = hist;
    var stored = Number(hist.stored_rows || 0);
    var target = Number(hist.target_rows || 70000);
    var cov = Number(hist.coverage_pct || 0);
    var remaining = Number(hist.remaining_rows || Math.max(0, target-stored));
    var complete = !!hist.complete;
    var running = !!hist.running;
    var label = hist.status_label || (complete ? 'Volledig geladen' : (running ? 'Automatisch laden' : 'In wachtrij'));
    var msg;
    if(complete){
      var lag = hist.latest_lag_hours==null ? null : Number(hist.latest_lag_hours);
      msg = 'Klaar · 100% · '+stored.toLocaleString()+' candles · alleen nieuwe candles bijwerken';
      if(lag!=null && isFinite(lag)) msg += ' · laatste candle ±'+lag.toFixed(1)+'u oud';
    } else if(running){
      msg = label+' · '+cov.toFixed(2)+'% · nog '+remaining.toLocaleString();
    } else {
      msg = label+' · '+cov.toFixed(2)+'% · '+stored.toLocaleString()+'/'+target.toLocaleString();
    }
    setText('historyMemoryStatus', complete ? 'Volledig geladen' : (stored.toLocaleString()+' / '+target.toLocaleString()));
    setText('historyMemoryPhase', msg + (source ? ' · '+source : ''));
    var bar=$('historyMemoryBar');
    if(bar){
      bar.style.width = Math.max(0, Math.min(100, cov)).toFixed(2)+'%';
      if(bar.parentElement) bar.parentElement.classList.toggle('complete', complete);
    }
    var btn=$('memoryBtn');
    if(btn){
      btn.textContent = complete ? 'History Loaded' : (running ? 'Auto Loading...' : 'Check Auto History');
      btn.disabled = running && !complete;
    }
  }

  async function pollHistoryMemory(force){
    if(state.historyPolling && !force) return;
    state.historyPolling = true;
    try{
      var data = await getJSON('/api/historical-memory/status', {}, 20000);
      var hist = data && (data.history || data.status || data.historical_memory);
      if(hist) renderHistoryMemory(hist, 'live');
      else setText('historyMemoryPhase','status endpoint gaf nog geen history-data terug');
    }catch(e){
      setText('historyMemoryStatus','history status wacht...');
      setText('historyMemoryPhase','server is bezig met history/backfill; nieuwe poging volgt automatisch · '+String(e.message||e).slice(0,120));
      log('failsafe_history_status_error',{message:String(e.message||e)});
    }finally{
      state.historyPolling = false;
    }
  }

  async function checkAutoHistory(){
    var btn=$('memoryBtn');
    if(btn){ btn.disabled=true; btn.textContent='Checking auto history...'; }
    setText('historyMemoryPhase','auto-daemon controleren/starten...');
    try{
      var res = await getJSON('/api/historical-memory/backfill?mode=daemon', {method:'POST'}, 10000);
      var hist = res && (res.status || res.history || (res.result && res.result.status));
      if(hist) renderHistoryMemory(hist, 'daemon actief');
      await pollHistoryMemory(true);
    }catch(e){
      setText('historyMemoryStatus','history check fout');
      setText('historyMemoryPhase',String(e.message||e).slice(0,160));
      alert('Historical Memory error: '+String(e.message||e));
      log('failsafe_history_check_error',{message:String(e.message||e)});
    }finally{
      setTimeout(function(){
        var h=state.historyStatus||{};
        if(btn){ btn.disabled=!!h.running && !h.complete; btn.textContent=h.complete?'History Loaded':(h.running?'Auto Loading...':'Check Auto History'); }
      }, 600);
    }
  }

  function renderDashboard(data){
    state.dashboard=data||{};
    var f=state.dashboard.latest_feature||{}, items=state.dashboard.latest_items||[];
    setText('btcPrice', money(state.dashboard.btc_price));
    setText('syncState', new Date().toLocaleTimeString());
    setText('topClock', new Date().toLocaleTimeString());
    setText('regimeCard', String(f.regime||'—').replace(/_/g,' '));
    setText('completenessCard', f.data_completeness==null?'Data —':'Data '+Number(f.data_completeness).toFixed(0)+'%');
    setText('fearCard', f.fear_greed==null?'—':Number(f.fear_greed).toFixed(0));
    var ms=((state.dashboard.sync_state||[]).find(function(x){return x.key==='manual_sync_status';})||{}).value;
    var ss=((state.dashboard.sync_state||[]).find(function(x){return x.key==='startup_sync_status';})||{}).value;
    setText('topDataLive','Data: '+(ms||ss||'sync'));
    renderForecast(items); renderConfidence(items); renderEvidence(f); renderKeyEvidence(f, state.dashboard.composite_orderbook, items); renderTables(state.dashboard); renderIntegrity(state.dashboard.data_integrity);
    if(state.dashboard.readiness && state.dashboard.readiness.historical_memory) renderHistoryMemory(state.dashboard.readiness.historical_memory, 'dashboard');
    if(items.length){ setText('sideSyncStatus','data zichtbaar'); setText('sideSyncPhase','forecast geladen: '+items.length+' horizons'); }
    else if(ss && String(ss).indexOf('auto')>=0){ setText('sideSyncStatus','auto-sync bezig'); setText('sideSyncPhase',ss); }
    else { setText('sideSyncStatus',state.dashboard.api_status||'dashboard'); setText('sideSyncPhase','wachten op automatische sync'); }
  }

  async function refresh(){
    if(state.refreshing) return;
    state.refreshing=true;
    try{
      // V10.5.1: first fetch a lightweight status payload so price/sync/integrity
      // stays visible even when the full dashboard is busy. A full-dashboard
      // timeout is now a soft warning, not a red app error.
      var status=null;
      try{
        status=await getJSON('/api/dashboard/status', {}, 10000);
        if(status && (!state.dashboard || status.btc_price || status.latest_feature)){
          var merged=Object.assign({}, state.dashboard||{}, status);
          renderDashboard(merged);
        }
      }catch(statusErr){
        log('failsafe_status_soft_error',{message:String(statusErr.message||statusErr)});
      }
      var data=await getJSON('/api/dashboard', {}, 20000);
      if(data && data.api_status==='busy' && state.dashboard && (state.dashboard.btc_price || (state.dashboard.latest_items||[]).length)){
        setText('sideSyncStatus','sync bezig');
        setText('sideSyncPhase','bestaande data blijft zichtbaar');
      } else {
        renderDashboard(data);
      }
      log('failsafe_dashboard_refresh',{items:(data.latest_items||[]).length, price:data.btc_price||null, status:data.api_status, integrity:(data.data_integrity&&data.data_integrity.status)||null});
    }catch(e){
      if(state.dashboard && (state.dashboard.btc_price || (state.dashboard.latest_items||[]).length)){
        setText('sideSyncStatus','dashboard ververst');
        setText('sideSyncPhase','full refresh later opnieuw; bestaande data blijft staan');
        log('failsafe_dashboard_soft_timeout',{message:String(e.message||e)});
      } else {
        setText('sideSyncStatus','api wacht op data');
        setText('sideSyncPhase',String(e.message||e).slice(0,160));
        log('failsafe_dashboard_error',{message:String(e.message||e)});
      }
    }finally{ state.refreshing=false; }
  }

  async function manualSync(){
    if(state.syncing) return;
    state.syncing=true;
    var btn=$('syncBtn');
    if(btn){ btn.disabled=true; btn.textContent='Syncing data...'; }
    setText('sideSyncStatus','syncing'); setText('sideSyncPhase','POST /api/sync gestart...');
    log('failsafe_sync_clicked');
    try{
      var data=await getJSON('/api/sync', {method:'POST'}, 180000);
      log('failsafe_sync_response',{created:data.created, run_id:data.run_id, reason:data.reason});
      setText('sideSyncStatus','sync klaar'); setText('sideSyncPhase',(data.reason||('run '+(data.run_id || (data.forecast&&data.forecast.run_id) || 'gemaakt'))));
      await refresh(); await loadMiniChart(true); await loadTimeMachineChart(true);
      setTimeout(refresh,1200); setTimeout(function(){loadMiniChart(true);},1500);
    }catch(e){
      setText('sideSyncStatus','sync error'); setText('sideSyncPhase',String(e.message||e).slice(0,180)); alert('Sync error: '+String(e.message||e)); log('failsafe_sync_error',{message:String(e.message||e)});
    }finally{
      state.syncing=false; if(btn){ setTimeout(function(){btn.disabled=false; btn.textContent='Sync + Forecast';},900); }
    }
  }

  function drawMiniChart(){
    var canvas=$('miniPriceChart'); if(!canvas) return;
    drawCandleChart(canvas, state.miniPoints, 'Data wordt automatisch opgehaald. Chart verschijnt na sync.', null);
  }
  async function loadMiniChart(force){
    try{
      var json=await getJSON('/api/time-machine/chart?timeframe=1h&limit=300', {}, 20000);
      state.miniPoints=json.points||[];
      drawMiniChart();
      log('failsafe_mini_chart',{count:state.miniPoints.length, live_fetch:!!json.live_fetch});
    }catch(e){ drawLineChart($('miniPriceChart'), [], 'Chart API error: '+String(e.message||e).slice(0,100)); }
  }
  function drawLineChart(canvas, pts, emptyText){
    if(!canvas) return;
    var ctx=canvas.getContext('2d'), dpr=window.devicePixelRatio||1, rect=canvas.getBoundingClientRect();
    var W=rect.width||canvas.width||900, H=rect.height||canvas.height||320;
    if(canvas.width!==Math.round(W*dpr)||canvas.height!==Math.round(H*dpr)){canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);}
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,W,H); ctx.fillStyle='#060a11'; ctx.fillRect(0,0,W,H);
    ctx.strokeStyle='rgba(255,255,255,.06)'; ctx.lineWidth=1;
    for(var i=0;i<6;i++){var y=22+i*(H-48)/5;ctx.beginPath();ctx.moveTo(30,y);ctx.lineTo(W-18,y);ctx.stroke();}
    for(i=0;i<8;i++){var x=30+i*(W-48)/7;ctx.beginPath();ctx.moveTo(x,22);ctx.lineTo(x,H-26);ctx.stroke();}
    if(!pts || pts.length<2){ ctx.fillStyle='#9aa8cf'; ctx.font='15px Segoe UI'; ctx.fillText(emptyText||'Geen chartdata.',24,45); return; }
    var vals=pts.map(function(p){return Number(p.close);}).filter(Number.isFinite), min=Math.min.apply(null,vals), max=Math.max.apply(null,vals), pad=28, w=W-pad*2, h=H-pad*2;
    function xx(i){return pad+(i/(pts.length-1))*w;} function yy(v){return pad+(1-(v-min)/(max-min||1))*h;}
    var grad=ctx.createLinearGradient(0,pad,0,pad+h); grad.addColorStop(0,'rgba(24,228,242,.35)'); grad.addColorStop(1,'rgba(24,228,242,.025)');
    ctx.beginPath(); pts.forEach(function(p,i){var X=xx(i),Y=yy(Number(p.close)); if(i===0)ctx.moveTo(X,Y); else ctx.lineTo(X,Y);}); ctx.lineTo(pad+w,pad+h);ctx.lineTo(pad,pad+h);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
    ctx.beginPath(); pts.forEach(function(p,i){var X=xx(i),Y=yy(Number(p.close)); if(i===0)ctx.moveTo(X,Y); else ctx.lineTo(X,Y);}); ctx.strokeStyle='#18e4f2';ctx.lineWidth=2.2;ctx.stroke();
    var last=pts[pts.length-1]; ctx.fillStyle='#2df27f'; ctx.beginPath(); ctx.arc(xx(pts.length-1),yy(Number(last.close)),4,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#eaf2ff'; ctx.font='bold 13px Segoe UI'; ctx.fillText(money(last.close), Math.max(10,xx(pts.length-1)-100), yy(Number(last.close))-10);
  }


  function drawCandleChart(canvas, pts, emptyText, selectedTs){
    if(!canvas) return;
    var ctx=canvas.getContext('2d'), dpr=window.devicePixelRatio||1, rect=canvas.getBoundingClientRect();
    var W=rect.width||canvas.width||900, H=rect.height||canvas.height||420;
    if(canvas.width!==Math.round(W*dpr)||canvas.height!==Math.round(H*dpr)){canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);}
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,W,H); ctx.fillStyle='#060a11'; ctx.fillRect(0,0,W,H);
    var clean=(pts||[]).filter(function(p){return p && isFinite(Number(p.timestamp_ms)) && isFinite(Number(p.open)) && isFinite(Number(p.high)) && isFinite(Number(p.low)) && isFinite(Number(p.close)) && Number(p.close)>0;}).sort(function(a,b){return Number(a.timestamp_ms)-Number(b.timestamp_ms);});
    var padL=78,padR=78,padT=22,padB=40, chartW=W-padL-padR, chartH=H-padT-padB;
    ctx.save();
    ctx.strokeStyle='rgba(255,255,255,.065)'; ctx.lineWidth=1;
    for(var gi=0;gi<6;gi++){var gy=padT+gi*chartH/5;ctx.beginPath();ctx.moveTo(padL,gy);ctx.lineTo(W-padR,gy);ctx.stroke();}
    for(gi=0;gi<9;gi++){var gx=padL+gi*chartW/8;ctx.beginPath();ctx.moveTo(gx,padT);ctx.lineTo(gx,padT+chartH);ctx.stroke();}
    if(clean.length<2){ ctx.fillStyle='#9aa8cf'; ctx.font='15px Segoe UI'; ctx.fillText(emptyText||'Geen chartdata.',padL,45); ctx.restore(); return; }
    var highs=clean.map(function(p){return Number(p.high);}), lows=clean.map(function(p){return Number(p.low);});
    var min=Math.min.apply(null,lows), max=Math.max.apply(null,highs); var span=(max-min)||1; min-=span*.055; max+=span*.055;
    var tMin = state.tmStartMs || Number(clean[0].timestamp_ms), tMax = state.tmEndMs || Number(clean[clean.length-1].timestamp_ms);
    if(!isFinite(tMin)||!isFinite(tMax)||tMax<=tMin){tMin=Number(clean[0].timestamp_ms); tMax=Number(clean[clean.length-1].timestamp_ms);}
    function xxTs(ts){return padL+((Number(ts)-tMin)/(tMax-tMin))*chartW;}
    function yy(v){return padT+(1-(Number(v)-min)/(max-min))*chartH;}
    function dateLab(ts){var d=new Date(ts); var days=(tMax-tMin)/86400000; if(days>520)return String(d.getFullYear()); if(days>90)return d.toLocaleDateString(undefined,{month:'short',year:'2-digit'}); if(days>2)return d.toLocaleDateString(undefined,{day:'2-digit',month:'short'}); return d.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'});}
    // Price scale left + right, like an exchange chart. Left is intentionally
    // present because Stijn wants to read the price inside the chart immediately.
    ctx.fillStyle='rgba(222,229,255,.78)'; ctx.font='11px Segoe UI, Arial'; ctx.textBaseline='middle';
    for(gi=0;gi<6;gi++){var price=max-(max-min)*gi/5, y=padT+gi*chartH/5, lab=money(price); ctx.fillText(lab,8,y); ctx.textAlign='right'; ctx.fillText(lab,W-8,y); ctx.textAlign='left';}
    ctx.textBaseline='alphabetic'; ctx.fillStyle='rgba(154,168,207,.76)';
    for(gi=0;gi<6;gi++){var ts=tMin+(tMax-tMin)*gi/5; ctx.fillText(dateLab(ts), padL+gi*chartW/5-22, H-14);}
    ctx.save(); ctx.beginPath(); ctx.rect(padL,padT,chartW,chartH); ctx.clip();
    // Volume strip
    var vmax=Math.max.apply(null, clean.map(function(p){return Number(p.volume||0);}).filter(Number.isFinite).concat([1]));
    clean.forEach(function(p,i){ var x=xxTs(p.timestamp_ms); if(x<padL-20||x>W-padR+20)return; var v=Number(p.volume||0), vh=(v/vmax)*Math.min(54,chartH*.16); ctx.fillStyle='rgba(60,150,170,.17)'; ctx.fillRect(x-1,padT+chartH-vh,2,vh); });
    // Determine candle width from real time spacing.
    var dif=[]; for(var di=1;di<Math.min(clean.length,80);di++) dif.push(Math.abs(xxTs(clean[di].timestamp_ms)-xxTs(clean[di-1].timestamp_ms))); var avg=dif.length?dif.reduce(function(a,b){return a+b;},0)/dif.length:5; var cw=Math.max(1.2, Math.min(13, avg*.68));
    clean.forEach(function(p){
      var o=Number(p.open), h=Number(p.high), l=Number(p.low), c=Number(p.close), x=xxTs(p.timestamp_ms); if(x<padL-18||x>W-padR+18) return;
      var up=c>=o, col=up?'#16d989':'#ff4d6d'; ctx.strokeStyle=col; ctx.fillStyle=col; ctx.lineWidth=1;
      ctx.beginPath(); ctx.moveTo(x,yy(h)); ctx.lineTo(x,yy(l)); ctx.stroke();
      var top=yy(Math.max(o,c)), bot=yy(Math.min(o,c)), bh=Math.max(1,bot-top); ctx.globalAlpha=.95; ctx.fillRect(x-cw/2,top,cw,bh); ctx.globalAlpha=1;
    });
    // Selected vertical marker
    if(selectedTs){ var sx=xxTs(selectedTs); if(sx>=padL&&sx<=W-padR){ ctx.strokeStyle='#ffcf5a'; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(sx,padT); ctx.lineTo(sx,padT+chartH); ctx.stroke(); }}
    // Last price line + label
    var last=clean[clean.length-1], ly=yy(Number(last.close)); ctx.strokeStyle='rgba(45,242,127,.45)'; ctx.setLineDash([4,4]); ctx.beginPath(); ctx.moveTo(padL,ly); ctx.lineTo(W-padR,ly); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle='#2df27f'; ctx.beginPath(); ctx.arc(xxTs(last.timestamp_ms),ly,4,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='rgba(45,242,127,.18)'; ctx.fillRect(6,ly-12,68,24); ctx.fillRect(W-74,ly-12,68,24); ctx.fillStyle='#eaf2ff'; ctx.font='bold 12px Segoe UI'; ctx.textAlign='left'; ctx.fillText(money(last.close),12,ly+4); ctx.textAlign='right'; ctx.fillText(money(last.close),W-10,ly+4); ctx.textAlign='left';
    // Crosshair + OHLC tooltip
    if(state.tmHover){ var hx=state.tmHover.x, hy=state.tmHover.y; if(hx>=padL&&hx<=W-padR&&hy>=padT&&hy<=padT+chartH){ ctx.strokeStyle='rgba(215,225,255,.35)'; ctx.lineWidth=1; ctx.setLineDash([3,3]); ctx.beginPath(); ctx.moveTo(hx,padT); ctx.lineTo(hx,padT+chartH); ctx.moveTo(padL,hy); ctx.lineTo(W-padR,hy); ctx.stroke(); ctx.setLineDash([]); var hts=tMin+((hx-padL)/chartW)*(tMax-tMin); var hp=clean.reduce(function(best,p){return Math.abs(Number(p.timestamp_ms)-hts)<Math.abs(Number(best.timestamp_ms)-hts)?p:best;},clean[0]); var tip='O '+money(hp.open)+'  H '+money(hp.high)+'  L '+money(hp.low)+'  C '+money(hp.close); ctx.fillStyle='rgba(8,13,25,.92)'; ctx.strokeStyle='rgba(63,141,255,.45)'; ctx.lineWidth=1; ctx.fillRect(padL+10,padT+8,Math.min(440,ctx.measureText(tip).width+24),30); ctx.strokeRect(padL+10,padT+8,Math.min(440,ctx.measureText(tip).width+24),30); ctx.fillStyle='#dbe6ff'; ctx.font='12px Segoe UI'; ctx.fillText(tip,padL+22,padT+28); }}
    ctx.restore();
    ctx.fillStyle='rgba(154,168,207,.85)'; ctx.font='11px Segoe UI'; ctx.fillText('Scroll = zoom · sleep = pan · gewone klik = backtest · '+state.tmTf.toUpperCase(), padL, H-6);
    ctx.restore();
  }

  async function loadTimeMachineChart(force){
    if(state.tmLoading && !force) return;
    var canvas=$('tmChart'); if(!canvas) return;
    state.tmLoading=true; setText('tmRange','Chart laden...');
    try{
      var now=Date.now();
      var rangeHours={'1M':24*31,'3M':24*92,'6M':24*184,'1Y':24*366,'ALL':null}[state.tmRangeKey] || null;
      var effectiveEnd = state.tmCustomEndMs || (now + (state.tmPanOffsetMs||0));
      if(effectiveEnd > now) effectiveEnd = now;
      var start = state.tmCustomStartMs || (rangeHours ? effectiveEnd - rangeHours*3600000 : null);
      var limit = state.tmRangeKey==='ALL' ? 20000 : (state.tmRangeKey==='1Y' ? 7000 : 3000);
      var url='/api/time-machine/chart?timeframe='+encodeURIComponent(state.tmTf)+'&limit='+limit;
      if(start) url += '&start_ms='+Math.floor(start)+'&end_ms='+Math.floor(effectiveEnd);
      var json=await getJSON(url, {}, 45000);
      state.tmPoints=(json.points||[]).filter(function(p){return p && isFinite(Number(p.timestamp_ms)) && isFinite(Number(p.close));});
      state.tmStartMs=json.range_start_ms || start || (state.tmPoints.length?Number(state.tmPoints[0].timestamp_ms):null);
      state.tmEndMs=json.range_end_ms || effectiveEnd || (state.tmPoints.length?Number(state.tmPoints[state.tmPoints.length-1].timestamp_ms):null);
      var src=json.native_required?'C++ native':'api';
      setText('tmRange', state.tmPoints.length+' '+state.tmTf.toUpperCase()+' candles · '+state.tmRangeKey+' · '+src+' · scroll=zoom · sleep=pan · klik=backtest');
      drawTimeMachineChart();
      log('failsafe_tm_chart',{count:state.tmPoints.length, raw_count:json.raw_count, native:!!json.native_required, live_fetch:!!json.live_fetch});
    }catch(e){ setText('tmRange','Chart error'); drawLineChart(canvas, [], 'Time Machine chart kon niet snel laden. Fout: '+String(e.message||e).slice(0,180)); }
    finally{ state.tmLoading=false; }
  }

  function drawTimeMachineChart(){
    var canvas=$('tmChart'); if(!canvas) return;
    drawCandleChart(canvas, state.tmPoints, 'Time Machine chart laadt na automatische sync.', state.tmSelected && state.tmSelected.timestamp_ms);
  }
  function nearestTmPoint(ev){
    var canvas=$('tmChart'); if(!canvas || !state.tmPoints.length) return null;
    var rect=canvas.getBoundingClientRect(), x=ev.clientX-rect.left, W=rect.width||canvas.width;
    var padL=78,padR=78, chartW=Math.max(1,W-padL-padR);
    var t0=state.tmStartMs || Number(state.tmPoints[0].timestamp_ms), t1=state.tmEndMs || Number(state.tmPoints[state.tmPoints.length-1].timestamp_ms);
    var wanted=t0+((x-padL)/chartW)*(t1-t0);
    return state.tmPoints.reduce(function(best,p){return Math.abs(Number(p.timestamp_ms)-wanted)<Math.abs(Number(best.timestamp_ms)-wanted)?p:best;}, state.tmPoints[0]);
  }
  async function runTimeMachine(point){
    if(!point || state.tmRunning) return;
    state.tmRunning=true;
    state.tmSelected=point; drawTimeMachineChart();
    setText('tmSelected','Geselecteerd: '+new Date(Number(point.timestamp_ms)).toLocaleString()+' · run bezig...');
    var summary=$('tmSummary'); if(summary) summary.innerHTML='<div class="mini">Time Machine run bezig...</div>';
    try{
      // V10.14.5: skip the separate /resolve request. The backend run route
      // resolves internally and can return instantly from its cache. This removes
      // the visible 10s resolve timeout/race while backfill is active.
      var cutoff = Number(point.timestamp_ms);
      var result=await getJSON('/api/time-machine/run', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({timestamp_ms:Number(cutoff), reveal:true, persist:true})}, 20000);
      state.tmResult=result; renderTimeMachineResult(result);
      log('failsafe_tm_run',{cutoff_ms:cutoff, items:(result.items||result.results||[]).length});
    }catch(e){
      if(summary) summary.innerHTML='<div class="empty-state">Time Machine error: '+esc(String(e.message||e).slice(0,220))+'</div>';
      setText('tmSelected','Time Machine error');
      log('failsafe_tm_error',{message:String(e.message||e)});
    } finally { state.tmRunning=false; }
  }
  function renderTimeMachineResult(result){
    var items=result.items || result.results || result.horizons || [];
    var body=$('tmBody');
    if(!result || result.ok===false){
      var reason=(result && (result.reason||result.error)) || 'Geen resultaat';
      if($('tmSummary')) $('tmSummary').innerHTML='<strong>Time Machine fout</strong><span>'+esc(reason)+'</span>';
      if(body) body.innerHTML='<tr><td colspan="7">'+esc(reason)+'</td></tr>';
      return;
    }
    var wins=items.filter(function(x){return outcomeTier(x).tier==='win';}).length;
    var partials=items.filter(function(x){return outcomeTier(x).tier==='partial';}).length;
    var known=items.filter(function(x){return ['win','partial','fail'].indexOf(outcomeTier(x).tier)>=0;}).length;
    var avgErr=items.filter(function(x){return x.target_gap_pct!=null;}).map(function(x){return Math.abs(Number(x.target_gap_pct));});
    var avgErrVal=avgErr.length?avgErr.reduce(function(a,b){return a+b;},0)/avgErr.length:null;
    var candle=result.selected_candle || {};
    var cutoff=result.cutoff_ms || result.timestamp_ms || (state.tmSelected && state.tmSelected.timestamp_ms);
    var verdict=known ? (wins+'/'+known+' WIN · '+partials+' PARTIAL') : 'geen score';
    var strip=items.map(function(x){ var o=outcomeTier(x); return '<div class="tm-horizon-chip '+esc(o.tier)+'"><b>'+esc(x.horizon)+'</b><span>'+esc(o.short)+'</span></div>'; }).join('');
    var cards=items.map(function(x){
      var bull=Number(x.bullish_probability==null?0.5:x.bullish_probability), dir=bull>=0.5?'omhoog':'omlaag', o=outcomeTier(x);
      var cls=o.tier==='win'?'win-card':(o.tier==='partial'?'partial-card':'fail-card');
      var evidence=x.evidence_count==null?'—':Number(x.evidence_count).toLocaleString();
      return '<div class="tm-target-card '+cls+'"><div class="tm-card-top"><b>'+esc(x.horizon)+'</b><em>'+esc(o.short)+'</em></div><strong>'+money(x.expected_price)+'</strong><span>'+(bull*100).toFixed(1)+'% '+dir+' · conf '+Number(x.confidence||0).toFixed(0)+'</span><small>'+esc(o.explain)+' · inv '+(x.invalidation_price==null?'—':money(x.invalidation_price))+'</small><small>evidence '+esc(evidence)+' · H/L '+(x.actual_high==null?'—':money(x.actual_high))+' / '+(x.actual_low==null?'—':money(x.actual_low))+'</small></div>';
    }).join('');
    var summary=$('tmSummary');
    if(summary){ summary.innerHTML=
      '<div class="tm-run-head"><strong>Time Machine Run</strong><span>'+esc(verdict)+' · V9.8 rijke weergave</span></div>'+ 
      '<div class="tm-run-context">'+
      '<div><label>Geselecteerd moment</label><b>'+(cutoff?new Date(Number(cutoff)).toLocaleString():'—')+'</b></div>'+
      '<div class="tm-click-price"><label>Klikprijs / startprijs</label><b>'+money(result.start_price || (state.tmSelected && state.tmSelected.close))+'</b><small>exacte close van de gekozen candle</small></div>'+
      '<div><label>Candle O/H/L/C</label><b>O '+money(candle.open || (state.tmSelected && state.tmSelected.open))+' · H '+money(candle.high || (state.tmSelected && state.tmSelected.high))+' · L '+money(candle.low || (state.tmSelected && state.tmSelected.low))+' · C '+money(candle.close || (state.tmSelected && state.tmSelected.close))+'</b></div>'+
      '<div><label>Score-regel</label><b>WIN = doel geraakt vóór invalidatie</b></div>'+
      '<div><label>Gem. afstand tot doel</label><b>'+(avgErrVal==null?'—':avgErrVal.toFixed(2)+'%')+'</b></div>'+
      '</div><div class="tm-horizon-strip">'+strip+'</div><div class="tm-target-grid">'+cards+'</div>'; }
    if(body){ body.innerHTML=items.map(function(x){
      var bull=Number(x.bullish_probability==null?0.5:x.bullish_probability), dir=bull>=0.5?'omhoog':'omlaag', actual=x.actual_move_pct==null?null:Number(x.actual_move_pct);
      return '<tr><td><b>'+esc(x.horizon)+'</b></td>'+
      '<td><b>'+(bull*100).toFixed(1)+'% '+dir+'</b><br><small>confidence '+Number(x.confidence||0).toFixed(0)+'/100</small></td>'+
      '<td><b>'+money(x.expected_price)+'</b><br><small>verwachte move '+pctMove(x.expected_move_pct)+'</small></td>'+
      '<td><b>slot '+money(x.actual_price)+'</b><br><small>'+esc(directionWordFromMove(actual))+' · '+(actual==null?'—':pctMove(actual))+'</small><br><small>high '+(x.actual_high==null?'—':money(x.actual_high))+' · low '+(x.actual_low==null?'—':money(x.actual_low))+'</small></td>'+
      '<td>'+targetHitBadge(x)+'<br><small>target touched: '+(x.target_touched===true?'ja':x.target_touched===false?'nee':'—')+'</small></td>'+
      '<td>'+invalidationCell(x)+'</td>'+
      '<td>'+targetGapCell(x)+'<br><small>richting: '+(x.direction_correct===true?'goed':x.direction_correct===false?'fout':'—')+' · extra context</small></td></tr>';
    }).join(''); }
    setText('tmSelected','Run klaar · '+items.length+' horizons getest · '+verdict);
    loadTmStats();
  }
  async function loadTmStats(){
    try{
      var data=await getJSON('/api/time-machine/stats', {}, 12000);
      var rows=data.rows || data.by_horizon || data.horizons || [];
      var total=data.total || rows.reduce(function(a,r){return a+Number(r.total||0);},0);
      var totalEl=$('tmStatsTotal');
      if(totalEl){
        var hit=data.hitrate==null?'—':(Number(data.hitrate)*100).toFixed(1)+'%';
        var hitp=data.hitrate_with_partial==null?'—':(Number(data.hitrate_with_partial)*100).toFixed(1)+'%';
        totalEl.textContent= total ? (total+' horizon-tests · '+hit+' WIN · '+hitp+' incl partial') : '0 tests';
      }
      var cards=$('tmStatsCards');
      if(cards){
        if(!rows.length){ cards.innerHTML='<div class="tm-stat-empty">Nog geen geregistreerde Time Machine tests. Elke klik/run telt straks mee.</div>'; return; }
        cards.innerHTML=rows.map(function(r){
          var hit=r.hitrate!=null?Number(r.hitrate):(r.win_rate!=null?Number(r.win_rate):0);
          var total=Number(r.total||0), win=Number(r.correct||r.win||r.wins||0), partial=Number(r.partial||r.partials||0), wrong=Number(r.wrong||r.fail||r.fails||Math.max(0,total-win-partial));
          return '<div class="tm-stat-card"><div><strong>'+esc(r.horizon)+'</strong><span>'+(hit*100).toFixed(1)+'%</span></div><div class="tm-stat-row"><b class="ok-pill">WIN '+win+'</b><b class="partial-pill">PARTIAL '+partial+'</b><b class="bad-pill">FAIL '+wrong+'</b><b>totaal '+total+'</b></div><small>target-score '+(r.avg_score==null?'—':Number(r.avg_score).toFixed(1)+'/100')+'<br>gem. afstand '+(r.avg_abs_error==null?'—':Number(r.avg_abs_error).toFixed(2)+'%')+'</small></div>';
        }).join('');
      }
    }catch(e){ log('failsafe_tm_stats_error',{message:String(e.message||e)}); }
  }


  async function createSeedExport(){
    var btn=$('seedExportBtn');
    if(btn){ btn.disabled=true; btn.textContent='Exporting Snapshot...'; }
    setText('historyMemoryPhase','seed-snapshot maken: echte DuckDB + 70k candles + Time Machine + learning-data + logs...');
    try{
      var res = await getJSON('/api/seed-export/create', {method:'POST'}, 180000);
      if(!res || res.ok===false) throw new Error((res && res.error) || 'seed export failed');
      var bytes = Number(res.bytes||0);
      var mb = bytes ? (bytes/1024/1024).toFixed(1)+' MB' : 'onbekende grootte';
      var rows = res.manifest && res.manifest.history ? Number(res.manifest.history.raw_candle_rows||res.manifest.history.stored_rows||0) : 0;
      setText('historyMemoryStatus','Seed snapshot klaar');
      setText('historyMemoryPhase','ZIP + map gemaakt · '+mb+' · candles '+rows.toLocaleString()+' · upload deze ZIP naar ChatGPT');
      try{ window.open('/api/seed-export/download', '_blank'); }catch(e){ location.href='/api/seed-export/download'; }
      log('failsafe_seed_export_created',{bytes:bytes, rows:rows, verification:res.verification});
    }catch(e){
      setText('historyMemoryStatus','seed snapshot fout');
      setText('historyMemoryPhase',String(e.message||e).slice(0,180));
      alert('Seed snapshot error: '+String(e.message||e));
      log('failsafe_seed_export_error',{message:String(e.message||e)});
    }finally{
      if(btn){ btn.disabled=false; btn.textContent='Export Seed Snapshot'; }
    }
  }

  function wire(){
    document.querySelectorAll('.app-nav button').forEach(function(btn){ btn.addEventListener('click', function(){ setPage(btn.getAttribute('data-page')||'dashboard'); }); });
    var sync=$('syncBtn'); if(sync) sync.addEventListener('click', manualSync);
    var forecast=$('forecastBtn'); if(forecast) forecast.addEventListener('click', async function(){ try{ setText('sideSyncStatus','forecasting'); await getJSON('/api/forecast',{method:'POST'},60000); await refresh(); }catch(e){alert('Forecast error: '+String(e.message||e));} });
    var memory=$('memoryBtn'); if(memory) memory.addEventListener('click', checkAutoHistory);
    var seedExport=$('seedExportBtn'); if(seedExport) seedExport.addEventListener('click', createSeedExport);

    document.querySelectorAll('.tv-timeframes button').forEach(function(btn){ btn.addEventListener('click', function(){
      state.tmTf=btn.getAttribute('data-tf')||'1h'; state.tmPanOffsetMs=0; state.tmCustomStartMs=null; state.tmCustomEndMs=null; state.tmSelected=null; state.tmResult=null; setText('tmSelected','Timeframe '+state.tmTf.toUpperCase()+' gekozen · klik een candle.');
      document.querySelectorAll('.tv-timeframes button').forEach(function(b){b.classList.toggle('active', b===btn);});
      var sel=$('tmTimeframe'); if(sel) sel.value=state.tmTf;
      loadTimeMachineChart(true);
    }); });
    var selTf=$('tmTimeframe'); if(selTf) selTf.addEventListener('change', function(){ state.tmTf=selTf.value||'1h'; state.tmPanOffsetMs=0; state.tmCustomStartMs=null; state.tmCustomEndMs=null; document.querySelectorAll('.tv-timeframes button').forEach(function(b){b.classList.toggle('active', b.getAttribute('data-tf')===state.tmTf);}); loadTimeMachineChart(true); });
    document.querySelectorAll('.tv-ranges button').forEach(function(btn){ btn.addEventListener('click', function(){
      state.tmRangeKey=btn.getAttribute('data-range')||'6M'; state.tmPanOffsetMs=0; state.tmCustomStartMs=null; state.tmCustomEndMs=null; state.tmSelected=null; state.tmResult=null; setText('tmSelected','Range '+state.tmRangeKey+' gekozen · klik een candle.');
      document.querySelectorAll('.tv-ranges button').forEach(function(b){b.classList.toggle('active', b===btn);});
      loadTimeMachineChart(true);
    }); });
    var reset=$('tmResetBtn'); if(reset) reset.addEventListener('click', function(){ state.tmRangeKey='ALL'; state.tmPanOffsetMs=0; state.tmCustomStartMs=null; state.tmCustomEndMs=null; document.querySelectorAll('.tv-ranges button').forEach(function(b){b.classList.toggle('active', b.getAttribute('data-range')==='ALL');}); loadTimeMachineChart(true); });
    var zoom=$('tmZoomOutBtn'); if(zoom) zoom.addEventListener('click', function(){ var order=['1M','3M','6M','1Y','ALL']; var i=order.indexOf(state.tmRangeKey); state.tmRangeKey=order[Math.min(order.length-1,i+1)]; state.tmPanOffsetMs=0; document.querySelectorAll('.tv-ranges button').forEach(function(b){b.classList.toggle('active', b.getAttribute('data-range')===state.tmRangeKey);}); loadTimeMachineChart(true); });

    var tm=$('tmChart');
    if(tm){
      tm.style.cursor='crosshair';
      tm.addEventListener('pointerdown', function(ev){
        state.tmDrag={x:ev.clientX,y:ev.clientY,t:Date.now(),moved:false,startOffset:state.tmPanOffsetMs||0,startMs:state.tmStartMs,endMs:state.tmEndMs};
        try{ tm.setPointerCapture(ev.pointerId); }catch(e){}
      });
      tm.addEventListener('pointermove', function(ev){
        var rect=tm.getBoundingClientRect(); state.tmHover={x:ev.clientX-rect.left,y:ev.clientY-rect.top};
        if(state.tmDrag){
          var dx=ev.clientX-state.tmDrag.x, dy=ev.clientY-state.tmDrag.y;
          if(Math.abs(dx)>5 || Math.abs(dy)>5){
            state.tmDrag.moved=true; tm.style.cursor='grabbing';
            var s0=state.tmDrag.startMs || state.tmStartMs, s1=state.tmDrag.endMs || state.tmEndMs;
            if(s0 && s1){ var span=s1-s0; var shift=-(dx/Math.max(1,rect.width||900))*span; state.tmStartMs=s0+shift; state.tmEndMs=s1+shift; drawTimeMachineChart(); }
          }
        } else { drawTimeMachineChart(); }
      });
      tm.addEventListener('mouseleave', function(){state.tmHover=null; drawTimeMachineChart();});
      tm.addEventListener('wheel', function(ev){
        ev.preventDefault();
        var rect=tm.getBoundingClientRect(), x=ev.clientX-rect.left, ratio=Math.max(0.02,Math.min(0.98,x/Math.max(1,rect.width||900)));
        var s0=state.tmStartMs, s1=state.tmEndMs; if(!s0||!s1||s1<=s0)return;
        var factor=ev.deltaY<0?0.76:1.32, span=(s1-s0)*factor, center=s0+ratio*(s1-s0);
        state.tmCustomStartMs=center-span*ratio; state.tmCustomEndMs=center+span*(1-ratio); state.tmStartMs=state.tmCustomStartMs; state.tmEndMs=state.tmCustomEndMs; state.tmRangeKey='CUSTOM';
        document.querySelectorAll('.tv-ranges button').forEach(function(b){b.classList.remove('active');});
        drawTimeMachineChart();
        clearTimeout(state.tmWheelTimer); state.tmWheelTimer=setTimeout(function(){loadTimeMachineChart(true);},260);
      }, {passive:false});
      tm.addEventListener('pointerup', function(ev){
        if(!state.tmDrag){ return; }
        var drag=state.tmDrag; state.tmDrag=null; tm.style.cursor='crosshair';
        var dx=ev.clientX-drag.x, dy=ev.clientY-drag.y;
        if(drag.moved || Math.abs(dx)>8 || Math.abs(dy)>8){
          state.tmCustomStartMs=state.tmStartMs; state.tmCustomEndMs=state.tmEndMs; state.tmRangeKey='CUSTOM';
          document.querySelectorAll('.tv-ranges button').forEach(function(b){b.classList.remove('active');});
          setText('tmSelected','Chart verschoven · klik zonder slepen om een candle te testen.');
          loadTimeMachineChart(true);
          log('failsafe_tm_pan',{dx:dx, custom_start_ms:Math.round(state.tmCustomStartMs||0), custom_end_ms:Math.round(state.tmCustomEndMs||0)});
          return;
        }
        runTimeMachine(nearestTmPoint(ev));
      });
      tm.addEventListener('pointercancel', function(){ state.tmDrag=null; tm.style.cursor='crosshair'; });
    }
    var tmRun=$('tmRunBtn'); if(tmRun) tmRun.addEventListener('click', function(){ runTimeMachine(state.tmSelected || (state.tmPoints.length?state.tmPoints[state.tmPoints.length-2]:null)); });
    var r100=$('tmRandomBtn'); if(r100) r100.addEventListener('click', function(){ runRandom(100); });
    var r1000=$('tmRandom1000Btn'); if(r1000) r1000.addEventListener('click', function(){ runRandom(1000); });
    window.addEventListener('resize', function(){ setTimeout(function(){drawMiniChart();drawTimeMachineChart();},120); });
  }
  async function pollRandomImport(batchId, n, started){
    if(!batchId) return;
    var summary=$('tmSummary');
    for(var i=0;i<90;i++){
      try{
        var st=await getJSON('/api/time-machine/random-status?batch_id='+encodeURIComponent(batchId),{},8000);
        var status=st.status||'running', pct=st.progress_pct==null?null:Number(st.progress_pct);
        if(summary && status!=='completed'){
          summary.innerHTML += '<div class="mini" style="margin-top:8px">Import/learning op achtergrond: '+esc(status)+' '+(pct==null?'':pct.toFixed(0)+'%')+'</div>';
        }
        if(status==='completed'){
          if(summary) summary.innerHTML += '<div class="mini" style="margin-top:8px;color:#21e6a7">Learning warehouse klaar · '+(((Date.now()-started)/1000).toFixed(1))+'s totaal</div>';
          await loadTmStats();
          return;
        }
        if(status==='error'){
          if(summary) summary.innerHTML += '<div class="mini" style="margin-top:8px;color:#ff5470">Import fout: '+esc(st.error||'onbekend')+'</div>';
          return;
        }
      }catch(e){}
      await new Promise(function(r){setTimeout(r,2000);});
    }
  }

  async function runRandom(n){
    setText('tmSelected','Random '+n+' gestart...');
    var summary=$('tmSummary'); if(summary) summary.innerHTML='<div class="tm-run-head"><strong>Random '+n+' tests draait...</strong><span>batch audit</span></div><span>Hij gebruikt lokale candles. Random 1000 kan even duren.</span>';
    var body=$('tmBody'); if(body) body.innerHTML='<tr><td colspan="7">Random '+n+' batch draait...</td></tr>';
    var b100=$('tmRandomBtn'), b1000=$('tmRandom1000Btn'); [b100,b1000].forEach(function(b){if(b)b.disabled=true;});
    var started=Date.now();
    try{
      var data=await getJSON('/api/time-machine/random-tests',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({count:n})},240000);
      var rowsObj=data.summary || {};
      var entries=Array.isArray(rowsObj)?rowsObj.map(function(r){return [r.horizon,r];}):Object.entries(rowsObj);
      var chips=entries.map(function(pair){ var h=pair[0], s=pair[1]||{}; var win=s.hitrate==null?'—':(Number(s.hitrate)*100).toFixed(1)+'%'; var withP=s.hitrate_with_partial==null?'—':(Number(s.hitrate_with_partial)*100).toFixed(1)+'%'; return '<div class="tm-horizon-chip '+(Number(s.correct||0)>Number(s.total||0)/2?'win':'partial')+'"><b>'+esc(h)+'</b><span>'+win+' WIN<br>'+withP+' incl</span></div>'; }).join('');
      var secs=((Date.now()-started)/1000).toFixed(1);
      if(summary) summary.innerHTML='<div class="tm-run-head"><strong>Random '+(data.count||n)+' tests</strong><span>'+secs+'s · batch '+(data.batch_id?esc(String(data.batch_id).slice(0,8)):'—')+'</span></div><div class="tm-horizon-strip">'+chips+'</div><span>WIN = doel geraakt vóór invalidatie. PARTIAL = dicht bij doel zonder invalidatie.</span>';
      if(body) body.innerHTML=entries.map(function(pair){ var h=pair[0], s=pair[1]||{}; return '<tr><td>'+esc(h)+'</td><td>'+(s.hitrate==null?'—':(Number(s.hitrate)*100).toFixed(1)+'% WIN')+'<br><small>'+(s.hitrate_with_partial==null?'—':(Number(s.hitrate_with_partial)*100).toFixed(1)+'% incl partial')+'</small></td><td>Avg score</td><td>'+(s.avg_score?Number(s.avg_score).toFixed(1):'—')+'</td><td>Total '+esc(s.total||0)+'</td><td>Err '+(s.avg_error?Number(s.avg_error).toFixed(2)+'%':'—')+'</td><td>partial '+esc(s.partial||0)+'</td></tr>'; }).join('');
      await loadTmStats();
      if(data.import_status==='background_started' || data.mode==='native_async_import') pollRandomImport(data.batch_id,n,started);
    }catch(e){ setText('tmSelected','Random error: '+String(e.message||e).slice(0,160)); if(summary) summary.innerHTML='<strong>Random batch fout</strong><span>'+esc(String(e.message||e))+'</span>'; }
    finally{ [b100,b1000].forEach(function(b){if(b)b.disabled=false;}); }
  }

  function bootMobilePwa(){
    try{
      if('serviceWorker' in navigator){
        navigator.serviceWorker.register('/service-worker.js').catch(function(e){ log('pwa_sw_register_error',{message:String(e)}); });
      }
      var installPrompt=null;
      window.addEventListener('beforeinstallprompt', function(e){
        e.preventDefault();
        installPrompt=e;
        var btn=$('mobileInstallBtn');
        if(btn){ btn.style.display='inline-flex'; btn.disabled=false; btn.textContent='Install iPhone App'; }
      });
      var btn=$('mobileInstallBtn');
      if(btn){
        btn.addEventListener('click', async function(){
          if(installPrompt){
            try{ installPrompt.prompt(); await installPrompt.userChoice; installPrompt=null; btn.textContent='App Install Ready'; }catch(e){}
          } else {
            alert('iPhone installatie:\n1. Open deze pagina in Safari.\n2. Tik op delen.\n3. Kies Zet op beginscherm.\n\nDaarna opent hij als mobile webapp.');
          }
        });
      }
      var isStandalone = window.matchMedia && window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
      document.documentElement.classList.toggle('pwa-standalone', !!isStandalone);
    }catch(e){ log('pwa_boot_error',{message:String(e)}); }
  }


  function boot(){
    window.__BEE_FAILSAFE_APP_ACTIVE=true;
    log('failsafe_full_boot',{main_booted:!!window.__BEE_MAIN_BOOTED});
    wire();
    bootMobilePwa();
    setPage((function(){try{return localStorage.getItem('bee_page')||'dashboard';}catch(e){return 'dashboard';}})());
    refresh(); pollHistoryMemory(true); loadMiniChart(true); loadTimeMachineChart(false); loadTmStats();
    setTimeout(refresh,1500); setTimeout(function(){pollHistoryMemory(true);},1800); setTimeout(refresh,5000); setTimeout(function(){pollHistoryMemory(true);},5200); setTimeout(function(){loadMiniChart(true);loadTimeMachineChart(false);},12000);
    setInterval(refresh,15000); setInterval(function(){pollHistoryMemory(false);},2500); setInterval(function(){loadMiniChart(true);},60000);
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot); else setTimeout(boot, 0);
})();