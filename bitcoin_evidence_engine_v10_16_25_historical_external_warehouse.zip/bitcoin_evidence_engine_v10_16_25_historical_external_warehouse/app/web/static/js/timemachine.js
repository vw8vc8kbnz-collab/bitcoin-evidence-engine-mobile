import {money,pctRaw} from './format.js';

let tmPoints=[];
let selected=null;
let timeframe='1h';
let fullMin=null, fullMax=null;
let viewStart=null, viewEnd=null;
let isDragging=false;
let dragStartX=0;
let dragStartRange=null;
let hoverPoint=null;
let activeRange='6M';
let tmInitialized=false;
let tmRunAbort=null;
let chartLoadSeq=0;
let chartReloadTimer=null;
let pointerDownX=0;
let pointerDownY=0;
let pointerDownAt=0;
let suppressNextClick=false;
let clickRunBusy=false;
const TF_LABELS={"1h":"1H","4h":"4H","1d":"1D","1w":"1W","1m":"1M"};
const RANGE_DAYS={"1M":31,"3M":93,"6M":186,"1Y":366};
function auditFrontend(action, detail={}){
  try{ fetch('/api/debug/frontend-event',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action, page:'time_machine', timeframe, activeRange, selected_ms:selected?.timestamp_ms||null, ...detail})}).catch(()=>{}); }catch(e){}
}

async function refreshNativeStatus(){
  try{
    const r=await fetch('/api/native/status',{cache:'no-store'});
    const st=await r.json();
    const el=document.getElementById('tmSelected');
    if(el) el.textContent = st.available ? 'C++ native core actief · chart/random draaien native' : 'C++ native core ontbreekt · run build_native_core.bat';
    document.body?.classList.toggle('native-core-missing', !st.available);
    return st;
  }catch(e){ return {available:false, message:String(e.message||e)}; }
}

export async function initTimeMachine(){
  const canvas=document.getElementById('tmChart');
  if(!canvas) return;
  await refreshNativeStatus();
  await loadChart();
  await loadStats();
  window.beeTimeMachineRefresh = async ()=>{ await loadChart(); drawChart(); await loadStats(); };
  if(tmInitialized) return;
  tmInitialized=true;
  // Use pointerup as the primary click handler. In Chrome/Edge app-mode a
  // canvas click can be swallowed after tiny mouse movement, especially when
  // wheel/drag listeners are active. Pointerup lets us decide ourselves:
  // small movement = select/run, real drag = pan only.
  canvas.addEventListener('pointerdown', onPointerDown, {passive:true});
  canvas.addEventListener('pointerup', onPointerUp, {passive:false});
  canvas.addEventListener('click', onClickChart);
  canvas.addEventListener('mousemove', onMouseMove);
  canvas.addEventListener('mouseleave', ()=>{ hoverPoint=null; drawChart(); });
  canvas.addEventListener('wheel', onWheel, {passive:false});
  canvas.addEventListener('mousedown', onDragStart);
  window.addEventListener('mousemove', onDragMove);
  window.addEventListener('mouseup', onDragEnd);
  document.getElementById('tmRunBtn')?.addEventListener('click', runSelected);
  document.getElementById('tmRandomBtn')?.addEventListener('click', ()=>runRandom(100));
  document.getElementById('tmRandom1000Btn')?.addEventListener('click', ()=>runRandom(1000));
  document.getElementById('tmTimeframe')?.addEventListener('change', async e=>{ await setTimeframe(e.target.value); });
  document.querySelectorAll('[data-tf]').forEach(btn=>btn.addEventListener('click', async ()=>{ await setTimeframe(btn.dataset.tf); }));
  document.querySelectorAll('[data-range]').forEach(btn=>btn.addEventListener('click', async ()=>{ await setRangePreset(btn.dataset.range); }));
  document.getElementById('tmZoomOutBtn')?.addEventListener('click', async ()=>{ zoomAroundCenter(2.2); await loadChart(); });
  document.getElementById('tmResetBtn')?.addEventListener('click', async ()=>{ activeRange='ALL'; applyRangeButtons(); if(fullMin!=null&&fullMax!=null){viewStart=fullMin;viewEnd=fullMax;} else {viewStart=null;viewEnd=null;} await loadChart(); });
}

async function setTimeframe(tf){
  timeframe=tf || '1h';
  const sel=document.getElementById('tmTimeframe'); if(sel) sel.value=timeframe;
  document.querySelectorAll('[data-tf]').forEach(b=>b.classList.toggle('active', b.dataset.tf===timeframe));
  selected=null;
  await loadChart();
}

async function setRangePreset(range){
  activeRange=range;
  applyRangeButtons();
  if(fullMax!=null && fullMin!=null){
    if(range==='ALL'){ viewStart=fullMin; viewEnd=fullMax; }
    else { const span=RANGE_DAYS[range]*24*3600*1000; viewEnd=fullMax; viewStart=Math.max(fullMin, fullMax-span); }
  }
  selected=null;
  await loadChart();
}
function applyRangeButtons(){document.querySelectorAll('[data-range]').forEach(b=>b.classList.toggle('active', b.dataset.range===activeRange));}

async function loadChart(){
  const seq=++chartLoadSeq;
  const chartLimit = activeRange==='ALL' ? '20000' : (activeRange==='1Y' ? '7000' : '3000');
  const qs=new URLSearchParams({timeframe, limit:chartLimit});
  if(viewStart!=null) qs.set('start_ms', String(Math.floor(viewStart)));
  if(viewEnd!=null) qs.set('end_ms', String(Math.floor(viewEnd)));
  try{
    const res=await fetch('/api/time-machine/chart?'+qs.toString(), {cache:'no-store'});
    const data=await res.json();
    if(!res.ok || data.ok===false || data.error){ throw new Error(data.reason||data.error||('HTTP '+res.status)); }
    if(seq!==chartLoadSeq) return;
    if(Array.isArray(data.points) && data.points.length){ tmPoints=data.points; }
    if(data.min_ts!=null) fullMin=Number(data.min_ts);
    if(data.max_ts!=null) fullMax=Number(data.max_ts);
    if(data.min_ts!=null && data.max_ts!=null && (viewStart==null || viewEnd==null)){
      const span=(RANGE_DAYS[activeRange]||186)*24*3600*1000;
      viewEnd=Number(data.max_ts);
      viewStart=activeRange==='ALL' ? Number(data.min_ts) : Math.max(Number(data.min_ts), Number(data.max_ts)-span);
      if(activeRange!=='ALL') return loadChart();
    }
    document.getElementById('tmRange').textContent = rangeLabel({...data, points:tmPoints, count:tmPoints.length});
  }catch(err){
    const el=document.getElementById('tmRange'); if(el) el.textContent='Chart-data/native fout: '+String(err.message||err); const sum=document.getElementById('tmSummary'); if(sum) sum.innerHTML='<strong>C++ native chart fout</strong><span>'+String(err.message||err)+'</span>';
  }
  drawChart();
}
function scheduleChartReload(delay=240){
  if(chartReloadTimer) clearTimeout(chartReloadTimer);
  chartReloadTimer=setTimeout(()=>{chartReloadTimer=null; loadChart();}, delay);
}

function rangeLabel(data){
  if(!data.min_ts) return 'Geen data geladen';
  const a=new Date(data.min_ts).toLocaleDateString();
  const b=new Date(data.max_ts).toLocaleDateString();
  return `${TF_LABELS[timeframe]||timeframe} · ${a} → ${b} · ${data.count} candles zichtbaar · ${data.raw_count} 1h candles in range`;
}

function drawChart(){
  const c=document.getElementById('tmChart'); if(!c) return; const ctx=c.getContext('2d');
  const dpr=window.devicePixelRatio||1;
  const parent=c.parentElement; const cssW=c.clientWidth||parent?.clientWidth||1300, cssH=c.clientHeight||parent?.clientHeight||430;
  if(c.width!==Math.floor(cssW*dpr) || c.height!==Math.floor(cssH*dpr)){ c.width=Math.floor(cssW*dpr); c.height=Math.floor(cssH*dpr); }
  ctx.setTransform(dpr,0,0,dpr,0,0);
  ctx.clearRect(0,0,cssW,cssH);
  const padL=66,padR=48,padT=26,padB=38,w=cssW-padL-padR,h=cssH-padT-padB;
  ctx.fillStyle='#070b12'; ctx.fillRect(0,0,cssW,cssH);
  drawGrid(ctx,padL,padT,w,h);
  if(!tmPoints.length){ ctx.fillStyle='#c8d5f5'; ctx.font='13px Inter, Segoe UI, Arial'; ctx.fillText('Geen historische candles. Klik Sync + Forecast; V8.3 vult ook oudere Binance 1h candles backwards.',40,54); return; }
  const prices=tmPoints.flatMap(p=>[Number(p.high),Number(p.low)]).filter(v=>v>0); const min=Math.min(...prices), max=Math.max(...prices);
  const yMin=min-(max-min)*0.08, yMax=max+(max-min)*0.08;
  const xForTs=ts=>padL+(Number(ts)-viewStart)/(viewEnd-viewStart)*w;
  const yFor=v=>padT+h-(Number(v)-yMin)/(yMax-yMin)*h;
  drawAxes(ctx,padL,padT,w,h,yMin,yMax);
  drawCandles(ctx, xForTs, yFor, padT, h);
  drawVolume(ctx, xForTs, padL, padT, w, h);
  drawSelection(ctx, xForTs, yFor, padT, h);
  drawHover(ctx, xForTs, yFor, padT, h);
}
function drawGrid(ctx,padL,padT,w,h){
  ctx.strokeStyle='rgba(120,140,170,.13)'; ctx.lineWidth=1;
  for(let i=0;i<6;i++){ const y=padT+i*h/5; ctx.beginPath(); ctx.moveTo(padL,y); ctx.lineTo(padL+w,y); ctx.stroke(); }
  for(let i=0;i<10;i++){ const x=padL+i*w/9; ctx.beginPath(); ctx.moveTo(x,padT); ctx.lineTo(x,padT+h); ctx.stroke(); }
}
function drawAxes(ctx,padL,padT,w,h,min,max){
  ctx.fillStyle='rgba(222,229,255,.62)'; ctx.font='11px Inter, Segoe UI, Arial';
  for(let i=0;i<6;i++){
    const price=max-(max-min)*(i/5); ctx.fillText('$'+price.toLocaleString('en-US',{maximumFractionDigits:0}), 10, padT+i*h/5+4);
  }
  for(let i=0;i<6;i++){
    const ts=viewStart+(viewEnd-viewStart)*i/5; const label=formatAxisDate(ts);
    ctx.fillText(label, padL+i*w/5-22, padT+h+25);
  }
}
function formatAxisDate(ts){
  const d=new Date(ts); const opts={day:'2-digit',month:'short'};
  const spanDays=(viewEnd-viewStart)/(24*3600*1000);
  if(spanDays>500) return String(d.getFullYear());
  if(spanDays>90) return d.toLocaleDateString(undefined,{month:'short',year:'2-digit'});
  if(spanDays>3) return d.toLocaleDateString(undefined,opts);
  return d.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'});
}
function candleWidth(xForTs){
  if(tmPoints.length<2) return 8;
  const xs=tmPoints.slice(0,Math.min(40,tmPoints.length)).map(p=>xForTs(p.timestamp_ms));
  let diffs=[]; for(let i=1;i<xs.length;i++) diffs.push(Math.abs(xs[i]-xs[i-1]));
  const avg=diffs.length?diffs.reduce((a,b)=>a+b,0)/diffs.length:8;
  return Math.max(2, Math.min(18, avg*0.62));
}
function drawCandles(ctx,xForTs,yFor,padT,h){
  const cw=candleWidth(xForTs);
  ctx.lineWidth=1;
  // Always render OHLC/candles. Even when many candles are visible, use thin
  // TradingView-like bars instead of switching to a line chart.
  tmPoints.forEach(p=>{
    const x=xForTs(p.timestamp_ms); if(x<50||x>ctx.canvas.clientWidth-35) return;
    const open=Number(p.open), close=Number(p.close), high=Number(p.high), low=Number(p.low);
    const up=close>=open; const color=up?'#16c784':'#ea3943';
    ctx.strokeStyle=color; ctx.fillStyle=color;
    const yh=yFor(high), yl=yFor(low), yo=yFor(open), yc=yFor(close);
    ctx.beginPath(); ctx.moveTo(x,yh); ctx.lineTo(x,yl); ctx.stroke();
    const top=Math.min(yo,yc), body=Math.max(1,Math.abs(yc-yo));
    if(cw < 3){ ctx.beginPath(); ctx.moveTo(x, yo); ctx.lineTo(x, yc); ctx.stroke(); } else { ctx.fillRect(x-cw/2, top, cw, body); }
  });
}
function drawVolume(ctx,xForTs,padL,padT,w,h){
  const vols=tmPoints.map(p=>Number(p.volume||0)); const vmax=Math.max(...vols,1); const vh=Math.min(70,h*.18); const base=padT+h;
  const cw=Math.max(1,candleWidth(xForTs)*0.7);
  tmPoints.forEach(p=>{ const x=xForTs(p.timestamp_ms); if(x<padL||x>padL+w)return; const up=Number(p.close)>=Number(p.open); const bar=(Number(p.volume||0)/vmax)*vh; ctx.fillStyle=up?'rgba(22,199,132,.26)':'rgba(234,57,67,.24)'; ctx.fillRect(x-cw/2, base-bar, cw, bar); });
}
function drawSelection(ctx, xForTs, yFor, padT, h){
  if(!selected) return; const x=xForTs(selected.timestamp_ms); if(x<40 || x>ctx.canvas.clientWidth-20) return;
  const y=yFor(Number(selected.close));
  ctx.strokeStyle='#f04bdc'; ctx.lineWidth=1.6; ctx.beginPath(); ctx.moveTo(x,padT); ctx.lineTo(x,padT+h); ctx.stroke();
  ctx.fillStyle='#22e7ff'; ctx.beginPath(); ctx.arc(x,y,5,0,Math.PI*2); ctx.fill();
}
function drawHover(ctx, xForTs, yFor, padT, h){
  if(!hoverPoint) return; const x=xForTs(hoverPoint.timestamp_ms), y=yFor(Number(hoverPoint.close));
  ctx.strokeStyle='rgba(255,255,255,.35)'; ctx.beginPath(); ctx.moveTo(x,padT); ctx.lineTo(x,padT+h); ctx.stroke();
  const txt=`${new Date(hoverPoint.timestamp_ms).toLocaleString()}  O ${money(hoverPoint.open)} H ${money(hoverPoint.high)} L ${money(hoverPoint.low)} C ${money(hoverPoint.close)}`;
  ctx.font='12px Inter, Segoe UI, Arial'; const tw=Math.min(ctx.measureText(txt).width+20, ctx.canvas.clientWidth-20);
  const bx=Math.min(Math.max(10,x-120), ctx.canvas.clientWidth-tw-10), by=Math.max(10,y-46);
  ctx.fillStyle='rgba(8,12,22,.96)'; roundRect(ctx,bx,by,tw,32,10); ctx.fill(); ctx.strokeStyle='rgba(75,110,170,.45)'; ctx.stroke();
  ctx.fillStyle='#e8edff'; ctx.fillText(txt,bx+10,by+20);
}
function roundRect(ctx,x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
function nearestByX(clientX){
  if(!tmPoints.length)return null; const c=document.getElementById('tmChart'), rect=c.getBoundingClientRect(); const padL=66,padR=48,w=rect.width-padL-padR;
  const ratio=Math.max(0,Math.min(1,(clientX-rect.left-padL)/w)); const target=viewStart+ratio*(viewEnd-viewStart);
  let lo=0, hi=tmPoints.length-1; while(lo<hi){ const mid=Math.floor((lo+hi)/2); if(Number(tmPoints[mid].timestamp_ms)<target) lo=mid+1; else hi=mid; }
  const a=tmPoints[Math.max(0,lo-1)], b=tmPoints[lo]; return !a || Math.abs(Number(b.timestamp_ms)-target)<Math.abs(Number(a.timestamp_ms)-target) ? b : a;
}
async function resolveExactHour(timestamp_ms, autoRun=false){
  const selectedLabel=document.getElementById('tmSelected'); if(selectedLabel) selectedLabel.textContent='Exact 1H candle zoeken...';
  try{
    const res=await fetch('/api/time-machine/resolve',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({timestamp_ms})});
    const data=await res.json();
    auditFrontend('tm_resolve_response', {ok:data.ok===true, resolved_ms:data.timestamp_ms||null, reason:data.reason||null});
    if(data.ok){ selected=data; if(selectedLabel) selectedLabel.textContent=`Geselecteerd: ${new Date(selected.timestamp_ms).toLocaleString()} · klikprijs ${money(selected.close)} · O/H/L/C ${money(selected.open)} / ${money(selected.high)} / ${money(selected.low)} / ${money(selected.close)}`; document.getElementById('tmSummary').innerHTML=`<div class="tm-run-head"><strong>Geselecteerd candle</strong><span>backtest start...</span></div><div class="tm-run-context"><div><label>Moment</label><b>${new Date(selected.timestamp_ms).toLocaleString()}</b></div><div class="tm-click-price"><label>Klikprijs / startprijs</label><b>${money(selected.close)}</b><small>exacte close van de gekozen 1H candle</small></div><div><label>Open / High</label><b>${money(selected.open)} / ${money(selected.high)}</b></div><div><label>Low / Close</label><b>${money(selected.low)} / ${money(selected.close)}</b></div></div>`; drawChart(); if(autoRun) await runSelected(); }
    else{ if(selectedLabel) selectedLabel.textContent=data.reason||'Geen exact uur gevonden'; document.getElementById('tmSummary').innerHTML=`<strong>Geen exact uur gevonden</strong><span>${data.reason||'Probeer een ander punt of sync eerst data.'}</span>`; }
  }catch(e){
    auditFrontend('tm_resolve_error', {message:String(e.message||e)});
    if(selectedLabel) selectedLabel.textContent='Klikfout: '+String(e.message||e);
    document.getElementById('tmSummary').innerHTML=`<strong>Time Machine klikfout</strong><span>${String(e.message||e)}</span>`;
  }
  drawChart();
}
function onPointerDown(e){ pointerDownX=e.clientX; pointerDownY=e.clientY; pointerDownAt=Date.now(); suppressNextClick=false; }
async function onPointerUp(e){
  const dx=Math.abs(e.clientX-pointerDownX), dy=Math.abs(e.clientY-pointerDownY);
  const moved=Math.max(dx,dy);
  if(moved<=3 && !clickRunBusy){
    e.preventDefault(); suppressNextClick=true;
    const p=nearestByX(e.clientX);
    auditFrontend('tm_pointer_select', {clientX:e.clientX, moved, point_ms:p?.timestamp_ms||null});
    if(!p){ const el=document.getElementById('tmSelected'); if(el) el.textContent='Geen candle gevonden onder deze klik.'; return; }
    clickRunBusy=true;
    try{ selected=p; await runBacktest(p.timestamp_ms); }
    finally{ setTimeout(()=>{ clickRunBusy=false; }, 250); }
  }else{ suppressNextClick=true; auditFrontend('tm_pointer_drag_end', {moved}); setTimeout(()=>{suppressNextClick=false;},350); }
}
function onClickChart(e){
  if(suppressNextClick){ suppressNextClick=false; return; }
  if(isDragging || clickRunBusy) return;
  const p=nearestByX(e.clientX);
  auditFrontend('tm_canvas_click_fallback', {clientX:e.clientX, point_ms:p?.timestamp_ms||null});
  if(!p)return;
  clickRunBusy=true;
  runBacktest(p.timestamp_ms).finally(()=>setTimeout(()=>{clickRunBusy=false;},250));
}
function onMouseMove(e){ hoverPoint=nearestByX(e.clientX); if(!isDragging) drawChart(); }
function onWheel(e){ e.preventDefault(); if(!viewStart||!viewEnd)return; const rect=e.currentTarget.getBoundingClientRect(); const ratio=Math.max(0,Math.min(1,(e.clientX-rect.left)/rect.width)); const center=viewStart+ratio*(viewEnd-viewStart); const factor=e.deltaY<0?0.78:1.28; const span=(viewEnd-viewStart)*factor; activeRange='CUSTOM'; applyRangeButtons(); setView(center-span*ratio, center+span*(1-ratio)); drawChart(); scheduleChartReload(900); }
function onDragStart(e){ isDragging=false; dragStartX=e.clientX; dragStartRange=[viewStart,viewEnd]; }
function onDragMove(e){ if(!dragStartRange||e.buttons!==1)return; const dx=e.clientX-dragStartX; if(Math.abs(dx)<7)return; isDragging=true; const c=document.getElementById('tmChart'); const span=dragStartRange[1]-dragStartRange[0]; const shift=-dx/(c.clientWidth||1300)*span; activeRange='CUSTOM'; applyRangeButtons(); setView(dragStartRange[0]+shift, dragStartRange[1]+shift); drawChart(); }
async function onDragEnd(){ if(isDragging){ suppressNextClick=true; scheduleChartReload(650); setTimeout(()=>{suppressNextClick=false;},450); } dragStartRange=null; setTimeout(()=>{isDragging=false;},80); }
function setView(a,b){ if(fullMin!=null&&fullMax!=null){ const minSpan=3600*1000*12; if(b-a<minSpan){ const mid=(a+b)/2; a=mid-minSpan/2; b=mid+minSpan/2; } if(a<fullMin){ b+=fullMin-a; a=fullMin; } if(b>fullMax){ a-=b-fullMax; b=fullMax; } a=Math.max(fullMin,a); b=Math.min(fullMax,b);} viewStart=a; viewEnd=b; }
function zoomAroundCenter(factor){ const mid=(viewStart+viewEnd)/2; const span=(viewEnd-viewStart)*factor; activeRange='CUSTOM'; applyRangeButtons(); setView(mid-span/2, mid+span/2); }

async function runBacktest(timestamp_ms){
  const p = selected && Number(selected.timestamp_ms)===Number(timestamp_ms) ? selected : (nearestByTimestamp(timestamp_ms) || {timestamp_ms:Number(timestamp_ms)});
  selected=p;
  const selectedLabel=document.getElementById('tmSelected');
  if(selectedLabel){
    const price = p.close!=null ? ` · klikprijs ${money(p.close)}` : '';
    selectedLabel.textContent=`Geselecteerd: ${new Date(Number(timestamp_ms)).toLocaleString()}${price} · native run start...`;
  }
  drawChart();
  return runSelected();
}
function nearestByTimestamp(timestamp_ms){
  if(!tmPoints.length) return null; const t=Number(timestamp_ms);
  return tmPoints.reduce((best,p)=>Math.abs(Number(p.timestamp_ms)-t)<Math.abs(Number(best.timestamp_ms)-t)?p:best, tmPoints[0]);
}

async function runSelected(){
  if(!selected){document.getElementById('tmSelected').textContent='Klik eerst een exact uurpunt op de chart.'; return;}
  document.getElementById('tmSummary').innerHTML='<strong>Time Machine draait...</strong><span>Forecast + werkelijkheid wordt berekend. Benodigde 1H-candles worden alleen rond dit punt opgehaald.</span>';
  const body=document.getElementById('tmBody'); if(body) body.innerHTML='<tr><td colspan="7">Backtest draait... even geduld.</td></tr>';
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),45000);
  try{ const res=await fetch('/api/time-machine/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({timestamp_ms:selected.timestamp_ms,reveal:true,persist:true}),signal:controller.signal}); clearTimeout(timer); const json=await res.json(); renderResult(json); await loadStats(); }
  catch(e){ clearTimeout(timer); document.getElementById('tmSummary').innerHTML=`<strong>Time Machine fout</strong><span>${e.name==='AbortError'?'De backtest duurde te lang. Probeer opnieuw of stuur de logs.':e.message}</span>`; }
}
function outcomeTier(x){
  if(x.target_reached===true || x.outcome_tier==='win') return {tier:'win', label:'✅ WIN', short:'WIN', explain:'doel geraakt vóór invalidatie'};
  if(x.outcome_tier==='partial' || x.partial_reached===true || (!x.invalidated && Number(x.total_score||0)>=55)) return {tier:'partial', label:'🟡 PARTIAL', short:'PARTIAL', explain:x.outcome_explain||'bijna raak zonder invalidatie'};
  if(x.invalidated===true) return {tier:'fail', label:'❌ FAIL', short:'FAIL', explain:'invalidatie geraakt'};
  if(x.target_reached===false) return {tier:'fail', label:'❌ FAIL', short:'FAIL', explain:'doel niet gehaald'};
  return {tier:'open', label:'○ OPEN', short:'OPEN', explain:'geen werkelijkheid'};
}
function targetHitBadge(x){ const o=outcomeTier(x); const cls=o.tier==='win'?'strong-hit':(o.tier==='partial'?'near':(o.tier==='fail'?'miss':'open')); return `<span class="tm-outcome ${cls}">${o.label}</span><small>${o.explain}</small>`; }
function invalidationCell(x){ if(x.invalidation_price==null)return `<span class="tm-outcome open">—</span><small>geen invalidatie</small>`; const bad=x.invalidated===true; return `<span class="tm-outcome ${bad?'miss':'strong-hit'}">${bad?'geraakt':'niet geraakt'}</span><small>${money(x.invalidation_price)} · ${x.invalidation_gap_pct==null?'—':Number(x.invalidation_gap_pct).toFixed(2)+'%'}</small>`; }
function targetGapCell(x){ const gap=x.target_gap_pct==null?null:Number(x.target_gap_pct); const err=gap==null?null:Math.abs(gap); const score=x.target_score==null?(x.total_score==null?null:Number(x.total_score)):Number(x.target_score); let label='—',cls='open'; if(err!=null){ if(x.target_reached){label='target bereikt';cls='strong-hit';} else if(err<=0.35){label='net niet';cls='near';} else if(err<=1.25){label='dichtbij';cls='near';} else {label='ver weg';cls='miss';}} return `<span class="tm-outcome ${cls}">${label}</span><small>${score==null?'—':score.toFixed(0)+'/100'} · afstand ${gap==null?'—':gap.toFixed(2)+'%'}</small>`; }
function directionWordFromMove(v){ const n=Number(v||0); if(Math.abs(n)<0.03)return 'vlak'; return n>0?'omhoog':'omlaag'; }
function renderResult(data){
  if(!data.ok){document.getElementById('tmSummary').innerHTML=`<strong>Time Machine fout</strong><span>${data.reason||'Geen resultaat'}</span>`; return;}
  const items=data.items||[]; 
  const wins=items.filter(x=>outcomeTier(x).tier==='win').length;
  const partials=items.filter(x=>outcomeTier(x).tier==='partial').length;
  const known=items.filter(x=>['win','partial','fail'].includes(outcomeTier(x).tier)).length;
  const avgErr=items.filter(x=>x.target_gap_pct!=null).map(x=>Math.abs(Number(x.target_gap_pct))); const avgErrVal=avgErr.length?avgErr.reduce((a,b)=>a+b,0)/avgErr.length:null; const candle=data.selected_candle||{};
  const verdict = known ? `${wins}/${known} WIN · ${partials} PARTIAL` : 'geen score';
  const strip=items.map(x=>{ const o=outcomeTier(x); return `<div class="tm-horizon-chip ${o.tier}"><b>${x.horizon}</b><span>${o.short}</span></div>`; }).join('');
  const cards=items.map(x=>{ 
    const bull=Number(x.bullish_probability||.5); 
    const dir=bull>=.5?'omhoog':'omlaag'; 
    const o=outcomeTier(x);
    const cls=o.tier==='win'?'win-card':(o.tier==='partial'?'partial-card':'fail-card');
    const evidence=x.evidence_count==null?'—':Number(x.evidence_count).toLocaleString();
    return `<div class="tm-target-card ${cls}"><div class="tm-card-top"><b>${x.horizon}</b><em>${o.short}</em></div><strong>${money(x.expected_price)}</strong><span>${(bull*100).toFixed(1)}% ${dir} · conf ${Number(x.confidence||0).toFixed(0)}</span><small>${o.explain} · inv ${x.invalidation_price==null?'—':money(x.invalidation_price)}</small><small>evidence ${evidence} · H/L ${x.actual_high==null?'—':money(x.actual_high)} / ${x.actual_low==null?'—':money(x.actual_low)}</small></div>`; 
  }).join('');
  document.getElementById('tmSummary').innerHTML=`
    <div class="tm-run-head"><strong>Time Machine Run</strong><span>${verdict} · direct overzicht</span></div>
    <div class="tm-run-context">
      <div><label>Geselecteerd moment</label><b>${new Date(data.cutoff_ms).toLocaleString()}</b></div>
      <div class="tm-click-price"><label>Klikprijs / startprijs</label><b>${money(data.start_price)}</b><small>exacte close van de gekozen 1H candle</small></div>
      <div><label>Candle O/H/L/C</label><b>O ${money(candle.open)} · H ${money(candle.high)} · L ${money(candle.low)} · C ${money(candle.close)}</b></div>
      <div><label>Score-regel</label><b>WIN = doel geraakt zonder invalidatie</b></div>
      <div><label>Gem. afstand tot doel</label><b>${avgErrVal==null?'—':avgErrVal.toFixed(2)+'%'}</b></div>
    </div><div class="tm-horizon-strip">${strip}</div><div class="tm-target-grid">${cards}</div>`;
  document.getElementById('tmBody').innerHTML=items.map(x=>{ const bull=Number(x.bullish_probability||.5); const dir=bull>=.5?'omhoog':'omlaag'; const actual=x.actual_move_pct==null?null:Number(x.actual_move_pct); return `<tr>
    <td><b>${x.horizon}</b></td>
    <td><b>${(bull*100).toFixed(1)}% ${dir}</b><br><small>confidence ${Number(x.confidence||0).toFixed(0)}/100</small></td>
    <td><b>${money(x.expected_price)}</b><br><small>verwachte move ${pctRaw(x.expected_move_pct)}</small></td>
    <td><b>slot ${money(x.actual_price)}</b><br><small>${directionWordFromMove(actual)} · ${actual==null?'—':pctRaw(actual)}</small><br><small>high ${x.actual_high==null?'—':money(x.actual_high)} · low ${x.actual_low==null?'—':money(x.actual_low)}</small></td>
    <td>${targetHitBadge(x)}<br><small>target touched: ${x.target_touched===true?'ja':x.target_touched===false?'nee':'—'}</small></td>
    <td>${invalidationCell(x)}</td>
    <td>${targetGapCell(x)}<br><small>richting: ${x.direction_correct===true?'goed':x.direction_correct===false?'fout':'—'} · extra context</small></td>
  </tr>`; }).join('');
}
async function pollRandomImport(batchId, count, started){
  if(!batchId) return;
  const summary=document.getElementById('tmSummary');
  for(let i=0;i<90;i++){
    try{
      const res=await fetch('/api/time-machine/random-status?batch_id='+encodeURIComponent(batchId));
      const st=await res.json();
      const status=st.status||'running';
      const pct=st.progress_pct==null?null:Number(st.progress_pct);
      if(summary && status!=='completed') summary.innerHTML += `<div class="mini" style="margin-top:8px">Import/learning op achtergrond: ${status} ${pct==null?'':pct.toFixed(0)+'%'}</div>`;
      if(status==='completed'){
        if(summary) summary.innerHTML += `<div class="mini" style="margin-top:8px;color:#21e6a7">Learning warehouse klaar · ${((Date.now()-started)/1000).toFixed(1)}s totaal</div>`;
        await loadStats();
        return;
      }
      if(status==='error'){
        if(summary) summary.innerHTML += `<div class="mini" style="margin-top:8px;color:#ff5470">Import fout: ${st.error||'onbekend'}</div>`;
        return;
      }
    }catch(e){}
    await new Promise(r=>setTimeout(r,2000));
  }
}

async function runRandom(count=100){
  const btn100=document.getElementById('tmRandomBtn'), btn1000=document.getElementById('tmRandom1000Btn');
  [btn100,btn1000].forEach(b=>{ if(b)b.disabled=true; });
  const started=Date.now();
  document.getElementById('tmSummary').innerHTML=`<div class="tm-run-head"><strong>Random ${count} tests draait...</strong><span>batch audit</span></div><span>C++ native batch-engine gebruikt lokale 1H-candles. Python fallback is uitgeschakeld; als native ontbreekt krijg je direct een duidelijke fout.</span>`;
  const body=document.getElementById('tmBody'); if(body) body.innerHTML=`<tr><td colspan="7">Random ${count} batch draait... even geduld.</td></tr>`;
  try{
    const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),180000);
    const res=await fetch('/api/time-machine/random-tests',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({count}),signal:controller.signal});
    clearTimeout(timer);
    const data=await res.json();
    if(!data.ok) throw new Error(data.reason||data.native_status?.message||'Random batch gaf geen resultaat');
    const summary=data.summary||{};
    const chips=Object.entries(summary).map(([h,s])=>{ const win=s.hitrate==null?'—':(s.hitrate*100).toFixed(1)+'%'; const withP=s.hitrate_with_partial==null?'—':(s.hitrate_with_partial*100).toFixed(1)+'%'; return `<div class="tm-horizon-chip ${Number(s.correct||0)>Number(s.total||0)/2?'win':'partial'}"><b>${h}</b><span>${win} WIN<br>${withP} incl</span></div>`; }).join('');
    const secs=((Date.now()-started)/1000).toFixed(1);
    document.getElementById('tmSummary').innerHTML=`<div class="tm-run-head"><strong>Random ${data.count||count} tests</strong><span>${secs}s · C++ native · batch ${data.batch_id?String(data.batch_id).slice(0,8):'—'}</span></div><div class="tm-horizon-strip">${chips}</div><span>WIN = doel geraakt vóór invalidatie. PARTIAL = dicht bij doel zonder invalidatie.</span>`;
    document.getElementById('tmBody').innerHTML=Object.entries(summary).map(([h,s])=>`<tr><td>${h}</td><td>${s.hitrate==null?'—':(s.hitrate*100).toFixed(1)+'% WIN'}<br><small>${s.hitrate_with_partial==null?'—':(s.hitrate_with_partial*100).toFixed(1)+'% incl partial</small></td><td>Avg score</td><td>${s.avg_score?Number(s.avg_score).toFixed(1):'—'}</td><td>Total ${s.total||0}</td><td>Err ${s.avg_error?Number(s.avg_error).toFixed(2)+'%':'—'}</td><td>partial ${s.partial||0}</td></tr>`).join('');
    await loadStats();
    if(data.import_status==='background_started' || data.mode==='native_async_import') pollRandomImport(data.batch_id,count,started);
  }catch(e){
    document.getElementById('tmSummary').innerHTML=`<strong>Random batch fout</strong><span>${e.name==='AbortError'?'Random batch duurde te lang. Stuur de logs.':String(e.message||e)}</span>`;
  }finally{
    [btn100,btn1000].forEach(b=>{ if(b)b.disabled=false; });
  }
}
async function loadStats(){ const el=document.getElementById('tmStatsCards'); if(!el)return; const res=await fetch('/api/time-machine/stats'); const data=await res.json(); const rows=data.rows||[]; if(!rows.length){ el.innerHTML='<div class="tm-stat-empty">Nog geen geregistreerde Time Machine tests. Elke klik/run telt straks mee.</div>'; const total=document.getElementById('tmStatsTotal'); if(total)total.textContent='0 tests'; return;} const total=document.getElementById('tmStatsTotal'); if(total){ const hit=data.hitrate==null?'—':(data.hitrate*100).toFixed(1)+'%'; const hitp=data.hitrate_with_partial==null?'—':(data.hitrate_with_partial*100).toFixed(1)+'%'; total.textContent=`${data.total||0} horizon-tests · ${hit} WIN · ${hitp} incl partial`; } el.innerHTML=rows.map(r=>{ const hit=r.hitrate==null?'—':(Number(r.hitrate)*100).toFixed(1)+'%'; return `<div class="tm-stat-card"><div><strong>${r.horizon}</strong><span>${hit}</span></div><div class="tm-stat-row"><b class="ok-pill">WIN ${r.correct||0}</b><b class="partial-pill">PARTIAL ${r.partial||0}</b><b class="bad-pill">FAIL ${r.wrong||0}</b><b>totaal ${r.total||0}</b></div><small>target-score ${r.avg_score==null?'—':Number(r.avg_score).toFixed(1)}/100<br>gem. afstand ${r.avg_abs_error==null?'—':Number(r.avg_abs_error).toFixed(2)+'%'}</small></div>`; }).join(''); }
