async function fetchWithTimeout(url, options={}, timeoutMs=8000){
  const controller = new AbortController();
  const startedAt = Date.now();
  const id = setTimeout(()=>controller.abort(), timeoutMs);
  try{
    const response = await fetch(url, {...options, signal: controller.signal});
    return response;
  } catch(err){
    const e = new Error(`${url} network/timeout error after ${Date.now()-startedAt}ms: ${err && err.message ? err.message : err}`);
    e.originalError = err;
    e.url = url;
    throw e;
  } finally { clearTimeout(id); }
}
async function asJsonOrThrow(r, label){
  if(!r.ok){
    let body='';
    try{ body = await r.text(); }catch(e){}
    throw new Error(`${label} failed (${r.status}) ${body.slice(0,280)}`);
  }
  return await r.json();
}
export async function getDashboard(){
  return asJsonOrThrow(await fetchWithTimeout('/api/dashboard', {cache:'no-store'}, 3500), 'Dashboard API');
}
export async function postFrontendEvent(payload){
  try{
    await fetchWithTimeout('/api/debug/frontend-event', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({...(payload||{}), browser_ts: Date.now()})
    }, 2500);
  }catch(e){
    console.warn('frontend-event logging failed', e);
  }
}
export async function syncNow(){
  return asJsonOrThrow(await fetchWithTimeout('/api/sync', {method:'POST', cache:'no-store'}, 180000), 'Sync');
}
export async function forceForecast(){
  return asJsonOrThrow(await fetchWithTimeout('/api/forecast', {method:'POST'}, 60000), 'Forecast');
}
export async function getEvidenceAttribution(minTotal=3){
  return asJsonOrThrow(await fetchWithTimeout('/api/evidence-attribution?min_total='+encodeURIComponent(minTotal), {cache:'no-store'}, 6000), 'Evidence attribution API');
}

export async function startHistoricalMemory(mode='daemon'){
  return asJsonOrThrow(await fetchWithTimeout('/api/historical-memory/backfill?mode='+encodeURIComponent(mode), {method:'POST', cache:'no-store'}, 180000), 'Historical Memory');
}
