window.__BEE_MAIN_BOOTED = true;
import {getDashboard, syncNow, forceForecast, getEvidenceAttribution, postFrontendEvent, startHistoricalMemory} from './api.js';
import {renderDashboard} from './render.js';
import {initTimeMachine} from './timemachine.js';

function showFrontendError(message){
  console.error(message);
  const status=document.getElementById('sideSyncStatus');
  const phase=document.getElementById('sideSyncPhase');
  const forecast=document.getElementById('forecast');
  if(status) status.textContent='frontend error';
  if(phase) phase.textContent=String(message).slice(0,120);
  if(forecast && !forecast.innerHTML.trim()) forecast.innerHTML='<div class="empty-state">Frontend renderfout: '+String(message).slice(0,300)+'</div>';
  postFrontendEvent({kind:'frontend_error',message:String(message),page:localStorage.getItem('bee_page')||'dashboard'});
}
window.addEventListener('error', e=>showFrontendError(e.message || e.error || 'unknown script error'));
window.addEventListener('unhandledrejection', e=>showFrontendError((e.reason && (e.reason.message || e.reason)) || 'unhandled promise rejection'));

function setPage(page){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const target=document.getElementById('page-'+page) || document.getElementById('page-dashboard');
  target.classList.add('active');
  document.querySelectorAll('.app-nav button').forEach(b=>b.classList.toggle('active', b.dataset.page===page));
  localStorage.setItem('bee_page', page);
  if(page==='dashboard') setTimeout(()=>renderMiniPriceChart(false), 80);
  if(page==='timemachine' && window.beeTimeMachineRefresh) setTimeout(()=>window.beeTimeMachineRefresh(), 120);
  if(page==='accuracy') setTimeout(()=>refreshAttribution(), 100);
}

document.querySelectorAll('.app-nav button').forEach(btn=>btn.addEventListener('click',()=>setPage(btn.dataset.page)));
setPage(localStorage.getItem('bee_page') || 'dashboard');
postFrontendEvent({kind:'frontend_boot', path:location.pathname, href:location.href, userAgent:navigator.userAgent});


async function refreshAttribution(){
  try{
    const data = await getEvidenceAttribution(3);
    renderAttribution(data);
  }catch(e){
    const el=document.getElementById('attributionPanel');
    if(el) el.innerHTML='<div class="mini">Attribution nog niet beschikbaar: '+e.message+'</div>';
  }
}
function renderAttribution(data){
  const top=document.getElementById('attributionPanel');
  const weak=document.getElementById('weakAttributionPanel');
  if(top){
    const rows=(data.top||[]).slice(0,24);
    top.innerHTML = rows.length ? `<div class="attr-grid">${rows.map(r=>`<div class="attr-card ${Number(r.hitrate)>=0.58?'attr-good':Number(r.hitrate)<=0.45?'attr-weak':''}"><b>${r.signal_label||r.signal_key}</b><span>${r.horizon} · ${(Number(r.hitrate||0)*100).toFixed(1)}% WIN</span><small>${r.wins||0}/${r.total||0} · score ${Number(r.avg_score||0).toFixed(0)} · afstand ${Number(r.avg_target_gap_pct||0).toFixed(2)}%</small></div>`).join('')}</div>` : '<div class="mini">Nog geen attribution-data. Doe Time Machine runs of Random 100 tests.</div>';
  }
  if(weak){
    const rows=(data.weak||[]).slice(0,16);
    weak.innerHTML = rows.length ? `<div class="attr-grid compact-attr">${rows.map(r=>`<div class="attr-card attr-weak"><b>${r.signal_label||r.signal_key}</b><span>${r.horizon} · ${(Number(r.hitrate||0)*100).toFixed(1)}% WIN</span><small>${r.wins||0}/${r.total||0} · vaak tegenbewijs</small></div>`).join('')}</div>` : '<div class="mini">Nog geen zwakke signalen gemeten.</div>';
  }
}

async function refresh(){
  try{
    const data = await getDashboard();
    try{ if(data && data.api_status==='busy'){ renderDashboard(data); return; } renderDashboard(data || {}); }
    catch(renderErr){ showFrontendError('RenderDashboard: '+(renderErr.message || renderErr)); }
  }
  catch(e){
    console.error(e);
    const s=document.getElementById('syncState'); if(s) s.textContent='API error';
    const forecast=document.getElementById('forecast');
    if(forecast && !forecast.innerHTML.trim()) forecast.innerHTML='<div class="empty-state">Dashboard API nog niet beschikbaar of fout: '+e.message+'</div>';
    const status=document.getElementById('sideSyncStatus'); if(status) status.textContent='api error';
    const phase=document.getElementById('sideSyncPhase'); if(phase) phase.textContent=e.message.slice(0,100);
  }
}

const syncButton = document.getElementById('syncBtn');
if(syncButton){
  postFrontendEvent({kind:'sync_button_present', id:'syncBtn', text:syncButton.textContent});
  syncButton.addEventListener('click', async()=>{
    const btn = document.getElementById('syncBtn');
    const status = document.getElementById('sideSyncStatus');
    const phase = document.getElementById('sideSyncPhase');
    const startedAt = Date.now();
    btn.textContent = 'Syncing data...'; btn.disabled = true;
    if(status) status.textContent = 'syncing';
    if(phase) phase.textContent = 'POST /api/sync gestart...';
    await postFrontendEvent({kind:'sync_button_clicked', href:location.href});
    console.info('[BEE] Sync + Forecast clicked; POST /api/sync starting');
    try{
      const res = await syncNow();
      await postFrontendEvent({kind:'sync_api_success', elapsed_ms:Date.now()-startedAt, response_summary:{created:res && res.created, run_id:res && res.run_id, reason:res && res.reason, forecast_created:res && res.forecast && res.forecast.created}});
      console.info('[BEE] Sync + Forecast response', res);
      if(res && res.forecast && res.forecast.created){
        btn.textContent = 'Forecast updated';
        if(status) status.textContent = 'completed';
        if(phase) phase.textContent = 'new run #' + res.forecast.run_id;
      } else if(res && res.reason){
        btn.textContent = 'Sync completed';
        if(status) status.textContent = res.status || 'completed';
        if(phase) phase.textContent = res.reason;
      } else {
        btn.textContent = 'Sync completed';
        if(status) status.textContent = 'completed';
        if(phase) phase.textContent = 'sync klaar, dashboard verversen';
      }
      await refresh();
      await renderMiniPriceChart(true);
      setTimeout(refresh, 1200);
      setTimeout(()=>renderMiniPriceChart(true), 1400);
    }
    catch(e){
      const msg = e && e.message ? e.message : String(e);
      await postFrontendEvent({kind:'sync_api_error', elapsed_ms:Date.now()-startedAt, message:msg, stack:e && e.stack});
      console.error('[BEE] Sync + Forecast error', e);
      alert('Sync + Forecast error: '+msg);
      if(status) status.textContent='error';
      if(phase) phase.textContent=msg.slice(0,160);
    }
    finally{ setTimeout(()=>{ btn.textContent='Sync + Forecast'; btn.disabled=false; }, 900); }
  });
} else {
  postFrontendEvent({kind:'sync_button_missing', selector:'#syncBtn'});
  console.error('[BEE] syncBtn not found; Sync + Forecast button is not wired.');
}

const forecastButton = document.getElementById('forecastBtn');
if(forecastButton) forecastButton.addEventListener('click', async()=>{
  forecastButton.textContent = 'Forecasting...'; forecastButton.disabled = true;
  try{ const res=await forceForecast(); await refresh(); if(res && res.reason) alert(res.reason); }
  catch(e){ alert('Forecast error: '+e.message); }
  finally{ forecastButton.textContent='Force Forecast'; forecastButton.disabled=false; }
});

const memoryButton = document.getElementById('memoryBtn');
if(memoryButton){
  memoryButton.addEventListener('click', async()=>{
    memoryButton.textContent = 'Checking auto history...'; memoryButton.disabled = true;
    const phase = document.getElementById('historyMemoryPhase');
    if(phase) phase.textContent = 'auto-daemon controleren/starten...';
    try{
      const res = await startHistoricalMemory('daemon');
      await refresh();
      const h = res && res.status ? res.status : (res && res.history ? res.history : null);
      if(h && phase) phase.textContent = `${h.stored_rows||0}/${h.target_rows||70000} · ${Number(h.coverage_pct||0).toFixed(2)}%`;
    }catch(e){
      alert('Historical Memory error: '+e.message);
      if(phase) phase.textContent = e.message.slice(0,120);
    }finally{
      setTimeout(()=>{ memoryButton.textContent='Check Auto History'; memoryButton.disabled=false; refresh(); }, 900);
    }
  });
}


refresh();
refreshAttribution();
let bootPolls=0;
const bootTimer=setInterval(()=>{ bootPolls++; refresh(); renderMiniPriceChart(); if(bootPolls>=40) clearInterval(bootTimer); }, 1500);
setInterval(refresh, 30000);
setInterval(refreshAttribution, 45000);
initTimeMachine();

let miniChartCache = [];
let miniChartInFlight = false;
let miniChartLastError = null;

function drawMiniPriceChart(pts, errorMessage){
  const canvas = document.getElementById('miniPriceChart');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const W = rect.width || 900, H = rect.height || 320;
  if(W <= 2 || H <= 2) return;
  if(canvas.width!==Math.round(W*dpr) || canvas.height!==Math.round(H*dpr)){
    canvas.width=Math.round(W*dpr); canvas.height=Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0);
  } else {
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  ctx.clearRect(0,0,W,H);
  ctx.fillStyle = '#060a11'; ctx.fillRect(0,0,W,H);
  ctx.strokeStyle='rgba(255,255,255,.045)'; ctx.lineWidth=1;
  for(let i=0;i<6;i++){ const yy=22+i*(H-48)/5; ctx.beginPath(); ctx.moveTo(30,yy); ctx.lineTo(W-18,yy); ctx.stroke(); }
  for(let i=0;i<8;i++){ const xx=30+i*(W-48)/7; ctx.beginPath(); ctx.moveTo(xx,22); ctx.lineTo(xx,H-26); ctx.stroke(); }
  if(!pts || pts.length < 2){
    ctx.fillStyle=errorMessage ? '#ff5578' : '#9aa8cf'; ctx.font='15px Segoe UI';
    ctx.fillText(errorMessage || 'Nog geen candles gesynct. Klik Sync + Forecast.', 24, 45);
    return;
  }
  const pad=28, w=W-pad*2, h=H-pad*2;
  const min=Math.min(...pts.map(p=>Number(p.low||p.close)).filter(Number.isFinite));
  const max=Math.max(...pts.map(p=>Number(p.high||p.close)).filter(Number.isFinite));
  const x=i=>pad+(i/(pts.length-1))*w; const y=v=>pad+(1-(v-min)/(max-min||1))*h;
  const grad=ctx.createLinearGradient(0,pad,0,pad+h); grad.addColorStop(0,'rgba(24,228,242,.35)'); grad.addColorStop(1,'rgba(24,228,242,.025)');
  ctx.beginPath(); pts.forEach((p,i)=>{ const xx=x(i), yy=y(Number(p.close)); if(i===0)ctx.moveTo(xx,yy); else ctx.lineTo(xx,yy); }); ctx.lineTo(pad+w,pad+h); ctx.lineTo(pad,pad+h); ctx.closePath(); ctx.fillStyle=grad; ctx.fill();
  ctx.beginPath(); pts.forEach((p,i)=>{ const xx=x(i), yy=y(Number(p.close)); if(i===0)ctx.moveTo(xx,yy); else ctx.lineTo(xx,yy); }); ctx.strokeStyle='#18e4f2'; ctx.lineWidth=2.2; ctx.stroke();
  const last=pts[pts.length-1]; ctx.fillStyle='#2df27f'; ctx.beginPath(); ctx.arc(x(pts.length-1),y(Number(last.close)),4,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#eaf2ff'; ctx.font='bold 13px Segoe UI'; ctx.fillText('$'+Number(last.close).toLocaleString(), Math.max(10,x(pts.length-1)-100), y(Number(last.close))-10);
}

async function renderMiniPriceChart(force=false){
  const canvas = document.getElementById('miniPriceChart');
  if(!canvas) return;
  if(miniChartCache.length) drawMiniPriceChart(miniChartCache, null);
  if(miniChartInFlight && !force) return;
  miniChartInFlight = true;
  try{
    const res = await fetch('/api/time-machine/chart?timeframe=1h&limit=260', {cache:'no-store'});
    const json = await res.json();
    const pts = json.points || [];
    if(pts.length >= 2){ miniChartCache = pts; miniChartLastError = null; drawMiniPriceChart(miniChartCache, null); }
    else if(!miniChartCache.length){ drawMiniPriceChart([], 'Nog geen candles gesynct. Klik Sync + Forecast.'); }
  }catch(e){
    miniChartLastError = e.message;
    if(miniChartCache.length) drawMiniPriceChart(miniChartCache, null);
    else drawMiniPriceChart([], 'Chart API error: '+e.message);
  }finally{ miniChartInFlight = false; }
}
setTimeout(()=>renderMiniPriceChart(true), 900);
setInterval(()=>renderMiniPriceChart(true), 60000);
window.addEventListener('resize',()=>setTimeout(()=>renderMiniPriceChart(false), 120));
