from __future__ import annotations
import asyncio

# One process-local lock is enough for this Windows local app. It prevents
# the startup sync, manual Sync+Forecast and dashboard polling from forcing
# concurrent provider/database writes.
sync_lock = asyncio.Lock()


# V10.14.5: Time Machine/chart interactions get priority over background
# historical backfill. Background jobs should pause briefly while this flag is set.
import threading
tm_priority_event = threading.Event()
