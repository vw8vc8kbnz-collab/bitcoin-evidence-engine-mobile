from __future__ import annotations
from datetime import datetime, timezone, timedelta

HORIZON_SECONDS = {
    "1h": 3600,
    "4h": 4*3600,
    "8h": 8*3600,
    "24h": 24*3600,
    "7d": 7*24*3600,
    "30d": 30*24*3600,
    "90d": 90*24*3600,
}

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

def to_ms(dt: datetime) -> int:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)

def from_ms(ms: int) -> datetime:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc)

def iso(dt: datetime | None) -> str | None:
    return dt.astimezone(timezone.utc).isoformat() if dt else None

def horizon_delta(horizon: str) -> timedelta:
    return timedelta(seconds=HORIZON_SECONDS[horizon])

def interval_ms(interval: str) -> int:
    return {"1m":60000,"5m":300000,"15m":900000,"1h":3600000,"4h":14400000,"1d":86400000}[interval]
