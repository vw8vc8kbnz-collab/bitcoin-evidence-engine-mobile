from __future__ import annotations
import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from app.core.config import settings

_LOGGER_CONFIGURED = False

def setup_logging() -> logging.Logger:
    global _LOGGER_CONFIGURED
    log_dir = settings.base_dir / 'logs'
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger('bee')
    if _LOGGER_CONFIGURED:
        return logger
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter('%(asctime)s | %(levelname)-7s | %(name)s | %(message)s')
    file_handler = RotatingFileHandler(log_dir / 'bee_runtime.log', maxBytes=5_000_000, backupCount=5, encoding='utf-8')
    file_handler.setFormatter(fmt)
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(fmt)
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    # Also capture uvicorn/app warnings in the same file.
    for name in ('uvicorn', 'uvicorn.error', 'uvicorn.access', 'fastapi'):
        other = logging.getLogger(name)
        other.setLevel(logging.INFO)
        other.addHandler(file_handler)
    _LOGGER_CONFIGURED = True
    logger.info('Logging initialized. Runtime log: %s', log_dir / 'bee_runtime.log')
    return logger

log = setup_logging()
