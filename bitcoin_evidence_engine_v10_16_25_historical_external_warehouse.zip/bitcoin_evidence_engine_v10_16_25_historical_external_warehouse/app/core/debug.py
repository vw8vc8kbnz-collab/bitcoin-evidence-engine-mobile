from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path
from app.core.config import settings
from app.core.logger import log


def _json_default(obj):
    try:
        if hasattr(obj, 'isoformat'):
            return obj.isoformat()
        if hasattr(obj, 'item'):
            return obj.item()
    except Exception:
        pass
    return str(obj)


def append_jsonl(filename: str, payload: dict) -> None:
    """Append machine-readable debug events next to bee_runtime.log.

    These files are intentionally simple JSONL so the user can zip the logs map
    and we can reconstruct exactly which providers/models/actions ran.
    """
    try:
        log_dir = settings.base_dir / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        row = {"at": datetime.now(timezone.utc).isoformat(), **(payload or {})}
        with (log_dir / filename).open('a', encoding='utf-8') as f:
            f.write(json.dumps(row, ensure_ascii=False, default=_json_default) + '\n')
    except Exception as exc:
        log.warning('Could not append debug jsonl %s: %s', filename, exc)


def write_json(filename: str, payload: dict) -> None:
    try:
        log_dir = settings.base_dir / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        with (log_dir / filename).open('w', encoding='utf-8') as f:
            json.dump({"written_at": datetime.now(timezone.utc).isoformat(), **(payload or {})}, f, ensure_ascii=False, indent=2, default=_json_default)
    except Exception as exc:
        log.warning('Could not write debug json %s: %s', filename, exc)
