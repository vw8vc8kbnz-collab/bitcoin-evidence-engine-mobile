from __future__ import annotations
import json
import numpy as np

# V5: the historical twin engine compares a richer evidence fingerprint.
# Missing values become 0 after robust scaling, but data_completeness is kept so
# the MetaJudge can reduce confidence when evidence sources are sparse.
FEATURE_KEYS = [
    "rsi_14",
    "ma50_distance",
    "ma200_distance",
    "volatility_24",
    "drawdown_from_ath",
    "cycle_progress",
    "fear_greed",
    "funding_rate",
    "open_interest_change_24h",
    "long_short_ratio",
    "taker_buy_sell_ratio",
    "orderbook_imbalance",
    "coinmetrics_mvrv",
]

class StateVectorBuilder:
    def vector_from_state_json(self, state_json: str | dict) -> np.ndarray:
        state = json.loads(state_json) if isinstance(state_json, str) else state_json
        vals=[]
        for k in FEATURE_KEYS:
            v = state.get(k)
            vals.append(0.0 if v is None else float(v))
        return np.array(vals, dtype=float)
