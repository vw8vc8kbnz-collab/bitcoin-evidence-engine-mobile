from __future__ import annotations

# V9.3 risk/target rules.
# Target = meaningful historical/volatility-calibrated move.
# Invalidation = wider opposite-side level, not the same tiny distance as target.
# This stops the Time Machine from failing every run because a normal wick
# touched an unrealistically tight invalidation.
INVALIDATION_FLOOR_PCT = {
    "1h": 0.55,
    "4h": 1.20,
    "8h": 1.80,
    "24h": 3.20,
    "7d": 8.50,
    "30d": 18.00,
    "90d": 35.00,
}
INVALIDATION_MULTIPLIER = {
    "1h": 2.4,
    "4h": 2.2,
    "8h": 2.1,
    "24h": 2.0,
    "7d": 1.8,
    "30d": 1.55,
    "90d": 1.35,
}

def invalidation_distance_pct(horizon: str, target_distance_pct: float) -> float:
    target_distance_pct = abs(float(target_distance_pct or 0.0))
    return max(INVALIDATION_FLOOR_PCT.get(horizon, 2.0), target_distance_pct * INVALIDATION_MULTIPLIER.get(horizon, 2.0))

def invalidation_price(start_price: float, expected_move_pct: float, horizon: str, target_distance_pct: float) -> tuple[float, float]:
    dist = invalidation_distance_pct(horizon, target_distance_pct)
    if float(expected_move_pct or 0.0) >= 0:
        return float(start_price) * (1 - dist / 100.0), dist
    return float(start_price) * (1 + dist / 100.0), dist
