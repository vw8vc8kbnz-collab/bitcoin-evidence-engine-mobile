from __future__ import annotations
import math
from app.db.database import db
from app.engine.twin_finder import HistoricalTwinFinder

HORIZON_BIAS = {
    '1h': 0.45, '4h': 0.65, '8h': 0.75, '24h': 0.9,
    '7d': 1.05, '30d': 1.25, '90d': 1.45,
}

class ModelArena:
    """Specialist model arena.

    V5 expands the arena with futures, orderbook and on-chain proxy models.
    Each model is small and inspectable. The MetaJudge combines them, so we can
    replace/upgrade individual models later without touching the rest.
    """
    def __init__(self):
        self.twin_finder = HistoricalTwinFinder()

    def run_models(self, horizon: str, current_price: float) -> list[dict]:
        latest = db.fetchone("""
            SELECT rsi_14, return_4, return_24, ma_50, ma_200, close, volatility_24,
                   volume_zscore, volume_ratio_24, range_pct, candle_body_pct,
                   drawdown_from_ath, cycle_progress, fear_greed, funding_rate,
                   open_interest_value, open_interest_change_24h, long_short_ratio,
                   taker_buy_sell_ratio, orderbook_imbalance, taker_delta_ratio, futures_basis_premium_pct,
                   top_position_long_short_ratio, top_account_long_short_ratio, cross_exchange_spread_pct,
                   spot_premium_kraken_pct, spot_premium_coinbase_pct, coinmetrics_mvrv,
                   realized_cap_usd, market_cap_usd, regime, data_completeness
            FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
        """)
        twin = self.twin_finder.find(horizon)
        models = [self._historical_twin_model(horizon, twin)]
        if latest:
            (rsi, ret4, ret24, ma50, ma200, close, vol24, vol_z, vol_ratio, range_pct, body_pct,
             dd, cycle, fg, funding, oi, oi_chg, long_short, taker_ratio, ob_imb, taker_delta, basis_premium,
             top_position_ratio, top_account_ratio, cross_spread, kraken_premium, coinbase_premium, mvrv,
             realized_cap, market_cap, regime, completeness) = latest
            futx = self.latest_futures_snapshot()
            models += [
                self._momentum_model(horizon, ret4, ret24),
                self._trend_model(horizon, close, ma50, ma200, regime),
                self._rsi_model(horizon, rsi, regime),
                self._cycle_model(horizon, cycle, dd),
                self._sentiment_model(horizon, fg),
                self._volatility_model(horizon, vol24),
                self._volume_model(horizon, vol_z, vol_ratio, ret4, ret24),
                self._range_expansion_model(horizon, range_pct, body_pct, ret4),
                self._mean_reversion_model(horizon, rsi, dd, close, ma50),
                self._funding_model(horizon, funding, long_short),
                self._open_interest_model(horizon, oi_chg, funding),
                self._orderbook_model(horizon, ob_imb, taker_ratio),
                self._onchain_mvrv_model(horizon, mvrv, close, realized_cap, market_cap),
                self._regime_model(horizon, regime, completeness),
                self._drawdown_pressure_model(horizon, dd, regime),
                self._ma_structure_model(horizon, close, ma50, ma200, dd),
                self._risk_confluence_model(horizon, fg, funding, long_short, ob_imb, dd),
                self._cycle_drawdown_confluence_model(horizon, cycle, dd, regime),
                self._breakout_retest_model(horizon, ret24, range_pct, close, ma50),
                self._futures_pressure_stack_model(horizon, funding, oi_chg, long_short, taker_ratio),
                self._liquidity_imbalance_model(horizon, ob_imb, range_pct, ret4),
                self._sentiment_exhaustion_model(horizon, fg, rsi, dd),
                self._trend_exhaustion_model(horizon, close, ma50, ma200, rsi, dd),
                self._basis_premium_model(horizon, futx.get('futures_basis_premium_pct'), futx.get('premium_last_funding_rate')),
                self._top_trader_position_model(horizon, futx.get('top_position_long_short_ratio'), futx.get('top_account_long_short_ratio'), funding),
                self._spot_futures_basis_model(horizon, close, futx.get('futures_mark_price'), futx.get('futures_index_price')),
                self._cvd_delta_model(horizon, taker_delta, taker_ratio, ret4),
                self._cross_exchange_spread_model(horizon, cross_spread, kraken_premium, coinbase_premium),
                self._evidence_cluster_model(horizon, regime, completeness, funding, oi_chg, ob_imb, taker_delta, fg, dd),
            ]
            alpha = self.latest_alpha_snapshot()
            models += [
                self._spot_aggression_model(horizon, alpha),
                self._futures_aggression_model(horizon, alpha, funding),
                self._large_trade_imbalance_model(horizon, alpha),
                self._leverage_flow_agreement_model(horizon, alpha, funding, oi_chg, taker_delta),
                self._multi_layer_alpha_stack_model(horizon, alpha, regime, completeness, funding, oi_chg, ob_imb, fg, dd),
            ]
        return [m for m in models if m]

    def _score_weight(self, model_id: str, horizon: str, base: float) -> float:
        row = db.fetchone("SELECT hitrate,total FROM model_scores WHERE model_id=? AND horizon=?", [model_id, horizon])
        horizon_factor = HORIZON_BIAS.get(horizon, 1.0)
        if not row:
            return base * horizon_factor
        hitrate,total = float(row[0]), int(row[1])
        maturity = min(total / 50, 1)
        return base * horizon_factor * (0.5 + hitrate) * (0.4 + 0.6*maturity)

    def _pack(self, model_id, name, horizon, bullish, move, confidence, evidence=0, base_weight=1.0, reason="", raw=None):
        return {
            "model_id": model_id, "name": name, "horizon": horizon,
            "bullish_probability": max(0.01, min(0.99, float(bullish))),
            "expected_move_pct": float(move),
            "confidence": max(0, min(100, float(confidence))),
            "evidence_count": int(evidence),
            "weight": self._score_weight(model_id, horizon, base_weight),
            "reason": reason,
            "raw": raw or {},
        }


    def latest_futures_snapshot(self, cutoff_ms: int | None = None) -> dict:
        """Small futures snapshot from raw_metric_points.

        With cutoff_ms, Time Machine gets only data known at that hour.
        Without cutoff_ms, live forecast gets latest known futures evidence.
        """
        metrics = [
            'futures_basis_premium_pct', 'premium_last_funding_rate',
            'current_open_interest_contracts', 'top_position_long_short_ratio',
            'top_account_long_short_ratio', 'futures_mark_price', 'futures_index_price'
        ]
        out = {}
        for metric in metrics:
            if cutoff_ms is None:
                row = db.fetchone("""
                    SELECT value FROM raw_metric_points
                    WHERE source='binance_futures' AND metric=?
                    ORDER BY timestamp_ms DESC LIMIT 1
                """, [metric])
            else:
                row = db.fetchone("""
                    SELECT value FROM raw_metric_points
                    WHERE source='binance_futures' AND metric=? AND timestamp_ms<=?
                    ORDER BY timestamp_ms DESC LIMIT 1
                """, [metric, int(cutoff_ms)])
            out[metric] = float(row[0]) if row and row[0] is not None else None
        return out


    def latest_alpha_snapshot(self, cutoff_ms: int | None = None) -> dict:
        """Latest optional alpha-flow metrics from raw_metric_points.

        These are deliberately stored outside the feature schema so the DB can
        accept new data layers without migrations. Live forecast gets latest;
        Time Machine may pass cutoff later when we make historical flow replay.
        """
        wanted = {
            'binance_spot_flow': ['trade_delta_ratio_recent', 'buy_sell_ratio_recent', 'large_trade_imbalance_recent', 'largest_trade_notional_recent'],
            'binance_futures_flow': ['trade_delta_ratio_recent', 'buy_sell_ratio_recent', 'large_trade_imbalance_recent', 'largest_trade_notional_recent'],
        }
        out = {}
        for src, metrics in wanted.items():
            for metric in metrics:
                if cutoff_ms is None:
                    row = db.fetchone("""
                        SELECT value FROM raw_metric_points
                        WHERE source=? AND metric=?
                        ORDER BY timestamp_ms DESC LIMIT 1
                    """, [src, metric])
                else:
                    row = db.fetchone("""
                        SELECT value FROM raw_metric_points
                        WHERE source=? AND metric=? AND timestamp_ms<=?
                        ORDER BY timestamp_ms DESC LIMIT 1
                    """, [src, metric, int(cutoff_ms)])
                out[f"{src}.{metric}"] = float(row[0]) if row and row[0] is not None else None
        return out

    def _historical_twin_model(self, horizon, twin):
        # V9.1: this is the core evidence model. It should not collapse to a
        # tiny move when history clearly shows larger conditional movement.
        evidence = int(twin.get("evidence_count", 0) or 0)
        prob = float(twin.get("bullish_probability", 0.5) or 0.5)
        move = float(twin.get("expected_move_pct", 0.0) or 0.0)
        conf = min(94, 22 + evidence / 3.0 + abs(prob-0.5)*80)
        # Higher base weight because this is the only model that directly asks:
        # “what happened after comparable historical moments?”
        return self._pack("M_TWIN", "Historical Twins", horizon, prob, move, conf, evidence, 2.65, "Diepe historische matches + werkelijke forward returns", twin)

    def _momentum_model(self, horizon, ret4, ret24):
        score = ((ret4 or 0)*0.42 + (ret24 or 0)*0.13)
        bullish = sigmoid(score/2)
        return self._pack("M_MOM", "Momentum", horizon, bullish, score*0.45, 42, 0, 0.75, "Recente returns en candle-pressure")

    def _trend_model(self, horizon, close, ma50, ma200, regime):
        if not close or not ma50 or not ma200:
            return self._pack("M_TREND","Trend",horizon,0.5,0,20,0,0.5,"Onvoldoende trenddata")
        d50=(close/ma50-1)*100; d200=(close/ma200-1)*100
        score=(d50*0.11+d200*0.055)
        if regime == 'bull_trend': score += 0.8
        if regime == 'bear_trend': score -= 0.8
        return self._pack("M_TREND", "Trend", horizon, sigmoid(score), score*0.7, 58, 0, 1.0, "Afstand tot MA50/MA200 + regime")

    def _rsi_model(self, horizon, rsi, regime):
        if rsi is None:
            return self._pack("M_RSI","RSI",horizon,0.5,0,20,0,0.35,"Geen RSI")
        if rsi < 30: bullish=.62; move=1.8
        elif rsi > 75: bullish=.42; move=-1.4
        else: bullish=.5+(rsi-50)/250; move=(rsi-50)/40
        if regime == 'bull_trend' and rsi > 50: bullish += 0.035
        if regime == 'bear_trend' and rsi < 50: bullish -= 0.035
        return self._pack("M_RSI", "RSI Regime", horizon, bullish, move, 45, 0, 0.65, "RSI overbought/oversold in huidig regime")

    def _cycle_model(self, horizon, cycle, dd):
        if cycle is None:
            return self._pack("M_CYCLE","4Y Cycle",horizon,0.5,0,20,0,0.6,"Geen cyclusdata")
        bullish = 0.52
        if 0.04 < cycle < 0.62: bullish = 0.63
        if 0.72 < cycle < 0.95: bullish = 0.45
        if dd is not None and dd < -50: bullish += 0.04
        move=(bullish-.5)*13
        base = 0.5 if horizon in ('1h','4h','8h') else 1.25
        return self._pack("M_CYCLE", "4-Year Cycle", horizon, bullish, move, 55, 0, base, "Relatieve positie t.o.v. halvingcyclus")

    def _sentiment_model(self, horizon, fg):
        if fg is None:
            return self._pack("M_SENT","Fear & Greed",horizon,0.5,0,10,0,0.2,"Sentimentbron nog leeg")
        if fg < 25: bullish=.59; move=1.25
        elif fg > 80: bullish=.43; move=-1.15
        else: bullish=.5+(fg-50)/520; move=(fg-50)/65
        return self._pack("M_SENT", "Fear & Greed", horizon, bullish, move, 32, 0, 0.4, "Contrarian sentimentlaag")

    def _volatility_model(self, horizon, vol24):
        if vol24 is None:
            return self._pack("M_VOL","Volatility",horizon,0.5,0,15,0,0.25,"Geen volatility")
        move = min(max(vol24,0),5) * 0.18
        return self._pack("M_VOL", "Volatility", horizon, 0.5, move, 25, 0, 0.3, "Range expansion / onzekerheid")

    def _funding_model(self, horizon, funding, long_short):
        if funding is None and long_short is None:
            return self._pack("M_FUND","Funding/Positioning",horizon,0.5,0,8,0,0.2,"Futures funding/ratio nog leeg")
        f = float(funding or 0)
        ls = float(long_short or 1)
        # positive extremes often become contrarian bearish; negative funding bullish.
        score = -f * 9500 + (1.0 - ls) * 0.10
        bullish = sigmoid(score)
        move = score * (0.7 if horizon in ('1h','4h','8h','24h') else 1.2)
        base = 1.25 if horizon in ('1h','4h','8h','24h') else 0.55
        return self._pack("M_FUND", "Funding / Long-Short", horizon, bullish, move, 46, 0, base, "Futures-positionering en funding-extremes", {"funding":funding,"long_short_ratio":long_short})

    def _open_interest_model(self, horizon, oi_chg, funding):
        if oi_chg is None:
            return self._pack("M_OI","Open Interest",horizon,0.5,0,8,0,0.25,"Open-interest data nog leeg")
        # Rising OI + positive funding = leverage risk; rising OI + negative funding = short squeeze risk.
        f = float(funding or 0)
        score = 0
        if oi_chg > 4 and f > 0.00015: score = -0.65
        elif oi_chg > 4 and f < -0.00005: score = 0.55
        elif oi_chg < -4: score = 0.05
        bullish = sigmoid(score)
        return self._pack("M_OI", "Open Interest", horizon, bullish, score*1.5, 40, 0, 1.0 if horizon in ('1h','4h','8h','24h') else 0.5, "Leverage buildup / flush risk", {"oi_change_24h":oi_chg,"funding":funding})

    def _orderbook_model(self, horizon, ob_imb, taker_ratio):
        if ob_imb is None and taker_ratio is None:
            return self._pack("M_OB","Orderbook/Flow",horizon,0.5,0,5,0,0.15,"Orderbook/flow nog leeg")
        score = ((float(ob_imb or 0.5)-0.5)*3.0) + ((float(taker_ratio or 1)-1)*0.35)
        bullish = sigmoid(score)
        return self._pack("M_OB", "Orderbook / Flow", horizon, bullish, score*0.8, 35, 0, 1.2 if horizon in ('1h','4h','8h') else 0.35, "Live depth imbalance en taker buy/sell pressure", {"orderbook_imbalance":ob_imb,"taker_buy_sell_ratio":taker_ratio})

    def _onchain_mvrv_model(self, horizon, mvrv, close, realized_cap, market_cap):
        if mvrv is None:
            return self._pack("M_MVRV","On-chain MVRV",horizon,0.5,0,5,0,0.2,"Coin Metrics MVRV/realized cap nog leeg")
        m = float(mvrv)
        if m < 1.1: bullish=.68; move=6.5
        elif m < 1.8: bullish=.60; move=3.0
        elif m > 4.0: bullish=.40; move=-4.5
        elif m > 3.0: bullish=.46; move=-2.0
        else: bullish=.53; move=0.8
        base = 0.25 if horizon in ('1h','4h','8h') else 1.55
        return self._pack("M_MVRV", "On-chain MVRV", horizon, bullish, move, 58, 0, base, "Market cap vs realized cap waarderingszone", {"mvrv":mvrv})

    def _regime_model(self, horizon, regime, completeness):
        mapping = {
            'bull_trend': (0.62, 2.6),
            'post_halving_accumulation': (0.60, 2.2),
            'bear_trend': (0.42, -2.5),
            'capitulation': (0.56, 1.8),
            'euphoria_risk': (0.45, -1.6),
            'transition': (0.50, 0.0),
        }
        bullish, move = mapping.get(regime or 'transition', (0.5, 0))
        conf = 25 + min(float(completeness or 0), 80) * 0.35
        return self._pack("M_REGIME", "Market Regime", horizon, bullish, move, conf, 0, 0.85, "Regime-classificatie + data completeness", {"regime":regime,"data_completeness":completeness})

    def _drawdown_pressure_model(self, horizon, dd, regime):
        if dd is None:
            return self._pack("M_DD", "Drawdown Pressure", horizon, 0.5, 0, 14, 0, 0.25, "Geen drawdown-context")
        d = float(dd)
        # Deep drawdowns are often longer-term bullish / shorter-term unstable. Near-ATH zones are riskier for longer horizons.
        if d < -55:
            bullish, move, conf = 0.58, 2.8, 50
        elif d < -35:
            bullish, move, conf = 0.55, 1.6, 44
        elif d > -8:
            bullish, move, conf = 0.47, -1.1, 42
        else:
            bullish, move, conf = 0.51, 0.25, 35
        if regime == 'capitulation':
            bullish += 0.04; move += 1.1
        base = 0.35 if horizon in ('1h','4h','8h') else 1.05
        return self._pack("M_DD", "Drawdown Pressure", horizon, bullish, move, conf, 0, base, "ATH-afstand en herstel-/riskzone", {"drawdown_from_ath": dd, "regime": regime})

    def _ma_structure_model(self, horizon, close, ma50, ma200, dd):
        if not close or not ma50 or not ma200:
            return self._pack("M_MASTRUCT", "MA Structure", horizon, 0.5, 0, 12, 0, 0.25, "Onvoldoende MA-structuur")
        d50 = (float(close)/float(ma50)-1)*100
        d200 = (float(close)/float(ma200)-1)*100
        slope_proxy = d50 - d200
        score = d50*0.05 + d200*0.03 + slope_proxy*0.025
        # overheated above both averages gets mildly contrarian on longer horizons
        if d50 > 18 and d200 > 45 and horizon in ('30d','90d'):
            score -= 0.9
        bullish = sigmoid(score)
        return self._pack("M_MASTRUCT", "MA Structure", horizon, bullish, score*0.9, 50, 0, 0.9, "MA50/MA200 structuur en overextension", {"d50_pct": d50, "d200_pct": d200})

    def _risk_confluence_model(self, horizon, fg, funding, long_short, ob_imb, dd):
        available = sum(v is not None for v in (fg, funding, long_short, ob_imb, dd))
        if available < 2:
            return self._pack("M_RISKCON", "Risk Confluence", horizon, 0.5, 0, 10, 0, 0.2, "Te weinig risicodatalagen")
        score = 0.0
        reasons = {}
        if fg is not None:
            # contrarian: extreme greed bearish, extreme fear bullish
            score += (50 - float(fg)) / 85
            reasons['fear_greed'] = fg
        if funding is not None:
            score += -float(funding) * 5500
            reasons['funding_rate'] = funding
        if long_short is not None:
            score += (1.0 - float(long_short)) * 0.18
            reasons['long_short_ratio'] = long_short
        if ob_imb is not None:
            score += (float(ob_imb)-0.5) * 1.7
            reasons['orderbook_imbalance'] = ob_imb
        if dd is not None and float(dd) < -40:
            score += 0.18
            reasons['deep_drawdown'] = dd
        bullish = sigmoid(score)
        base = 1.1 if horizon in ('1h','4h','8h','24h') else 0.75
        return self._pack("M_RISKCON", "Risk Confluence", horizon, bullish, score*1.6, 38 + available*7, 0, base, "Funding + sentiment + orderflow + drawdown samen", reasons)

    def _cycle_drawdown_confluence_model(self, horizon, cycle, dd, regime):
        if cycle is None or dd is None:
            return self._pack("M_CYCDD", "Cycle + Drawdown", horizon, 0.5, 0, 12, 0, 0.2, "Geen cycle/drawdown-combinatie")
        c, d = float(cycle), float(dd)
        score = 0.0
        if 0.12 <= c <= 0.58:
            score += 0.55
        if 0.70 <= c <= 0.95:
            score -= 0.45
        if d < -45:
            score += 0.30
        if d > -8 and c > 0.45:
            score -= 0.25
        if regime == 'bull_trend':
            score += 0.18
        elif regime == 'bear_trend':
            score -= 0.22
        bullish = sigmoid(score)
        base = 0.25 if horizon in ('1h','4h','8h') else 1.45
        return self._pack("M_CYCDD", "Cycle + Drawdown", horizon, bullish, score*3.2, 52, 0, base, "Halvingfase gewogen met ATH-drawdown", {"cycle_progress": cycle, "drawdown_from_ath": dd, "regime": regime})

    def _volume_model(self, horizon, vol_z, vol_ratio, ret4, ret24):
        if vol_z is None and vol_ratio is None:
            return self._pack("M_VOLUME", "Volume Pressure", horizon, 0.5, 0, 12, 0, 0.25, "Geen volume-context")
        vz = float(vol_z or 0)
        vr = float(vol_ratio or 1)
        recent = float(ret4 or ret24 or 0)
        # High volume confirms the short-term direction; extreme volume after dumps can become capitulation/relief.
        score = max(-2.5, min(2.5, recent / 3.0)) * min(max(vr - 1, 0), 2.5) * 0.55
        if vz > 2.5 and recent < -2:
            score += 0.25
        bullish = sigmoid(score)
        base = 1.0 if horizon in ('1h','4h','8h','24h') else 0.45
        return self._pack("M_VOLUME", "Volume Pressure", horizon, bullish, score*1.1, 36, 0, base, "Volume-spike + richting van recente candles", {"volume_zscore":vol_z,"volume_ratio_24":vol_ratio})

    def _range_expansion_model(self, horizon, range_pct, body_pct, ret4):
        if range_pct is None:
            return self._pack("M_RANGE", "Range Expansion", horizon, 0.5, 0, 10, 0, 0.2, "Geen candle-range data")
        rg = float(range_pct or 0)
        body = float(body_pct or 0)
        recent = float(ret4 or 0)
        score = 0.0
        if rg > 3.0:
            # Big range with positive close pressure = continuation short term; big range down = stress/risk.
            score += (1 if recent > 0 else -1) * min(rg/8, 1.2) * 0.55
        score += max(-1, min(1, body/1.8)) * 0.20
        bullish = sigmoid(score)
        base = 0.95 if horizon in ('1h','4h','8h') else 0.35
        return self._pack("M_RANGE", "Range Expansion", horizon, bullish, score*1.2, 32, 0, base, "Range expansion, wick/body pressure en korte continuation", {"range_pct":range_pct,"body_pct":body_pct})

    def _mean_reversion_model(self, horizon, rsi, dd, close, ma50):
        if rsi is None or not close or not ma50:
            return self._pack("M_REVERT", "Mean Reversion", horizon, 0.5, 0, 10, 0, 0.2, "Onvoldoende mean-reversion data")
        r = float(rsi); dist50 = (float(close)/float(ma50)-1)*100
        score = 0.0
        if r < 28 or dist50 < -12:
            score += 0.65
        elif r > 74 or dist50 > 16:
            score -= 0.60
        if dd is not None and float(dd) < -35 and r < 38:
            score += 0.18
        bullish = sigmoid(score)
        base = 0.75 if horizon in ('4h','8h','24h','7d') else 0.42
        return self._pack("M_REVERT", "Mean Reversion", horizon, bullish, score*1.8, 38, 0, base, "RSI + afstand tot MA50 voor herstel/overextension", {"rsi":rsi,"dist_ma50_pct":dist50})

    def _breakout_retest_model(self, horizon, ret24, range_pct, close, ma50):
        if ret24 is None or not close or not ma50:
            return self._pack("M_BREAKOUT", "Breakout / Retest", horizon, 0.5, 0, 10, 0, 0.2, "Onvoldoende breakout-context")
        r24=float(ret24); rg=float(range_pct or 0); d50=(float(close)/float(ma50)-1)*100
        score=0.0
        if r24 > 2.2 and d50 > 0: score += min(r24/8,1.1)*0.55 + min(rg/5,0.6)*0.18
        elif r24 < -2.2 and d50 < 0: score -= min(abs(r24)/8,1.1)*0.55 + min(rg/5,0.6)*0.18
        elif abs(d50) < 1.2 and abs(r24) < 1.2: score += 0.05
        bullish=sigmoid(score)
        base=0.95 if horizon in ('4h','8h','24h','7d') else 0.45
        return self._pack("M_BREAKOUT", "Breakout / Retest", horizon, bullish, score*1.9, 37, 0, base, "24h impuls + afstand tot MA50", {"ret24":ret24,"range_pct":range_pct,"d50_pct":d50})

    def _futures_pressure_stack_model(self, horizon, funding, oi_chg, long_short, taker_ratio):
        available=sum(v is not None for v in (funding, oi_chg, long_short, taker_ratio))
        if available < 2:
            return self._pack("M_FUTSTACK", "Futures Pressure Stack", horizon, 0.5, 0, 8, 0, 0.2, "Te weinig futures-pressure data")
        score=0.0; raw={}
        if funding is not None:
            f=float(funding); score += -f*4200; raw['funding_rate']=funding
        if oi_chg is not None:
            o=float(oi_chg); raw['oi_change_24h']=oi_chg
            if o>3 and funding is not None and float(funding)>0: score -= 0.22
            elif o>3 and funding is not None and float(funding)<0: score += 0.22
            elif o<-4: score += 0.06
        if long_short is not None:
            ls=float(long_short); score += (1.0-ls)*0.16; raw['long_short_ratio']=long_short
        if taker_ratio is not None:
            tr=float(taker_ratio); score += (tr-1.0)*0.28; raw['taker_buy_sell_ratio']=taker_ratio
        bullish=sigmoid(score)
        base=1.35 if horizon in ('1h','4h','8h','24h') else 0.45
        return self._pack("M_FUTSTACK", "Futures Pressure Stack", horizon, bullish, score*1.4, 32+available*8, 0, base, "Funding + OI + long/short + taker pressure gecombineerd", raw)

    def _liquidity_imbalance_model(self, horizon, ob_imb, range_pct, ret4):
        if ob_imb is None:
            return self._pack("M_LIQIMB", "Liquidity Imbalance", horizon, 0.5, 0, 7, 0, 0.15, "Geen composite orderbook imbalance")
        imb=float(ob_imb); rg=float(range_pct or 0); r4=float(ret4 or 0)
        score=(imb-0.5)*3.2
        if rg>2.0: score += (1 if r4>0 else -1)*0.12
        bullish=sigmoid(score)
        base=1.15 if horizon in ('1h','4h','8h') else 0.25
        return self._pack("M_LIQIMB", "Liquidity Imbalance", horizon, bullish, score*0.95, 34, 0, base, "Composite bid/ask pressure binnen relevante prijszones", {"orderbook_imbalance":ob_imb,"range_pct":range_pct})

    def _sentiment_exhaustion_model(self, horizon, fg, rsi, dd):
        available=sum(v is not None for v in (fg,rsi,dd))
        if available < 2:
            return self._pack("M_SENTEX", "Sentiment Exhaustion", horizon, 0.5, 0, 8, 0, 0.15, "Te weinig sentiment/exhaustion data")
        score=0.0; raw={}
        if fg is not None:
            f=float(fg); raw['fear_greed']=fg
            if f<18: score += 0.45
            elif f>82: score -= 0.45
        if rsi is not None:
            rr=float(rsi); raw['rsi']=rsi
            if rr<28: score += 0.25
            elif rr>76: score -= 0.25
        if dd is not None:
            d=float(dd); raw['drawdown_from_ath']=dd
            if d<-45: score += 0.18
            elif d>-6: score -= 0.12
        bullish=sigmoid(score)
        base=0.35 if horizon in ('1h','4h','8h') else 1.05
        return self._pack("M_SENTEX", "Sentiment Exhaustion", horizon, bullish, score*2.2, 30+available*8, 0, base, "Extreme fear/greed + RSI + drawdown als contrarian laag", raw)

    def _trend_exhaustion_model(self, horizon, close, ma50, ma200, rsi, dd):
        if not close or not ma50 or not ma200:
            return self._pack("M_TRENDEX", "Trend Exhaustion", horizon, 0.5, 0, 9, 0, 0.16, "Geen MA50/MA200 exhaustion-context")
        d50=(float(close)/float(ma50)-1)*100; d200=(float(close)/float(ma200)-1)*100; rr=float(rsi or 50); d=float(dd or 0)
        score=0.0
        if d50>14 and d200>35 and rr>68: score -= 0.55
        elif d50<-12 and d200<-25 and rr<34: score += 0.50
        elif d<-50 and rr<42: score += 0.22
        bullish=sigmoid(score)
        base=0.45 if horizon in ('1h','4h','8h') else 1.0
        return self._pack("M_TRENDEX", "Trend Exhaustion", horizon, bullish, score*2.0, 42, 0, base, "Overextension t.o.v. MA50/MA200 + RSI", {"d50_pct":d50,"d200_pct":d200,"rsi":rsi,"drawdown":dd})


    def _basis_premium_model(self, horizon, basis_premium_pct, premium_last_funding_rate):
        """Futures basis / premium layer.

        Positive premium + positive funding can mean crowded longs on short horizons.
        Negative premium or negative funding can create squeeze/relief potential.
        This model is deliberately horizon-aware: useful for 1h-24h, low weight for 30d/90d.
        """
        if basis_premium_pct is None and premium_last_funding_rate is None:
            return self._pack("M_BASIS", "Futures Basis/Premium", horizon, 0.5, 0, 8, 0, 0.18, "Geen basis/premium-data")
        basis = float(basis_premium_pct or 0)
        fund = float(premium_last_funding_rate or 0)
        score = 0.0
        # Premium is not inherently bearish; only extremes combined with funding are contrarian.
        if basis > 0.18 and fund > 0.0001:
            score -= min(basis / 1.2, 0.75)
        elif basis < -0.08 or fund < -0.00005:
            score += min(abs(basis) / 0.55 + abs(fund) * 2400, 0.75)
        else:
            score += max(-0.15, min(0.15, basis * 0.18 - fund * 700))
        bullish = sigmoid(score)
        base = 1.05 if horizon in ('1h','4h','8h','24h') else 0.30
        return self._pack("M_BASIS", "Futures Basis/Premium", horizon, bullish, score*1.25, 34, 0, base,
                          "Mark/index premium + funding crowding", {"basis_premium_pct": basis_premium_pct, "premium_last_funding_rate": premium_last_funding_rate})

    def _top_trader_position_model(self, horizon, top_position_ratio, top_account_ratio, funding):
        """Top-trader positioning layer from Binance futures global/top ratios."""
        available = sum(v is not None for v in (top_position_ratio, top_account_ratio, funding))
        if available < 1:
            return self._pack("M_TOPTRADER", "Top Trader Positioning", horizon, 0.5, 0, 7, 0, 0.14, "Geen top-trader positioning-data")
        score = 0.0; raw = {}
        if top_position_ratio is not None:
            r = float(top_position_ratio); raw['top_position_long_short_ratio'] = r
            # Extreme long crowding is contrarian; slight long bias is normal in bull markets.
            if r > 2.4: score -= 0.45
            elif r > 1.55: score -= 0.16
            elif r < 0.75: score += 0.28
        if top_account_ratio is not None:
            r = float(top_account_ratio); raw['top_account_long_short_ratio'] = r
            if r > 2.2: score -= 0.34
            elif r < 0.75: score += 0.22
        if funding is not None:
            f=float(funding); raw['funding_rate']=f
            score += -f * 2600
        bullish = sigmoid(score)
        base = 0.95 if horizon in ('1h','4h','8h','24h') else 0.25
        return self._pack("M_TOPTRADER", "Top Trader Positioning", horizon, bullish, score*1.20, 26+available*8, 0, base,
                          "Top-trader long/short crowding + funding", raw)

    def _spot_futures_basis_model(self, horizon, spot_close, futures_mark_price, futures_index_price):
        """Spot vs futures mark/index divergence.

        This is small-weight evidence. It mainly helps detect short-term stress where mark price
        deviates from index/spot, not a long-term prediction layer.
        """
        if not spot_close or futures_mark_price is None or futures_index_price is None:
            return self._pack("M_SPOTFUT", "Spot/Futures Divergence", horizon, 0.5, 0, 7, 0, 0.12, "Geen mark/index/spot-data")
        spot=float(spot_close); mark=float(futures_mark_price); idx=float(futures_index_price)
        mark_vs_index = (mark/idx - 1) * 100 if idx else 0.0
        mark_vs_spot = (mark/spot - 1) * 100 if spot else 0.0
        score = 0.0
        # Mild contrarian: futures trading too hot above spot/index can unwind.
        if mark_vs_index > 0.08 or mark_vs_spot > 0.10:
            score -= min(max(mark_vs_index, mark_vs_spot) * 2.2, 0.45)
        elif mark_vs_index < -0.08 or mark_vs_spot < -0.10:
            score += min(abs(min(mark_vs_index, mark_vs_spot)) * 2.2, 0.45)
        bullish = sigmoid(score)
        base = 0.85 if horizon in ('1h','4h','8h') else 0.18
        return self._pack("M_SPOTFUT", "Spot/Futures Divergence", horizon, bullish, score*1.1, 28, 0, base,
                          "Futures mark/index afwijking t.o.v. spot", {"mark_vs_index_pct": mark_vs_index, "mark_vs_spot_pct": mark_vs_spot})


    def _cvd_delta_model(self, horizon, taker_delta, taker_ratio, ret4):
        """CVD-style taker pressure from futures buy/sell volume.

        Binance public futures data provides taker buy and sell volume. We store a
        normalized delta ratio: positive means aggressive buyers dominate;
        negative means aggressive sellers dominate. Most useful on 1h-24h.
        """
        if taker_delta is None and taker_ratio is None:
            return self._pack("M_CVD", "CVD / Taker Delta", horizon, 0.5, 0, 8, 0, 0.18, "Geen taker-delta/CVD data")
        delta = float(taker_delta or 0)
        ratio = float(taker_ratio or 1)
        score = delta * 2.8 + (ratio - 1.0) * 0.24
        # if delta agrees with recent return, trend continuation; if divergent, lower confidence but still evidence
        recent = float(ret4 or 0)
        if recent > 0 and delta > 0: score += 0.08
        if recent < 0 and delta < 0: score -= 0.08
        bullish = sigmoid(score)
        base = 1.35 if horizon in ('1h','4h','8h','24h') else 0.35
        return self._pack("M_CVD", "CVD / Taker Delta", horizon, bullish, score*0.95, 40, 0, base,
                          "Agressieve futures-kopers vs verkopers", {"taker_delta_ratio": taker_delta, "taker_buy_sell_ratio": taker_ratio})

    def _cross_exchange_spread_model(self, horizon, cross_spread, kraken_premium, coinbase_premium):
        """Spot consensus/dispersion from Binance, Kraken and Coinbase.

        This is mostly a data-quality/stress layer: wide spread between exchanges
        means uncertainty/liquidity stress, not a directional edge by itself.
        """
        if cross_spread is None:
            return self._pack("M_XSPREAD", "Cross-Exchange Spread", horizon, 0.5, 0, 8, 0, 0.12, "Geen cross-exchange spot-spread")
        spread = float(cross_spread)
        kp = float(kraken_premium or 0)
        cp = float(coinbase_premium or 0)
        # Coinbase/Kraken premium above Binance can imply spot bid, but wide dispersion lowers conviction.
        premium_bias = max(-0.35, min(0.35, (kp + cp) * 1.2))
        stress_penalty = min(spread * 1.8, 0.22)
        score = premium_bias - stress_penalty * (1 if premium_bias >= 0 else -0.4)
        bullish = sigmoid(score)
        base = 0.55 if horizon in ('1h','4h','8h','24h') else 0.18
        return self._pack("M_XSPREAD", "Cross-Exchange Spread", horizon, bullish, score*0.7, 30, 0, base,
                          "Spotprijs-dispersie Binance/Kraken/Coinbase", {"cross_exchange_spread_pct": cross_spread, "kraken_premium_pct": kraken_premium, "coinbase_premium_pct": coinbase_premium})

    def _evidence_cluster_model(self, horizon, regime, completeness, funding, oi_chg, ob_imb, taker_delta, fg, dd):
        """Meta-style confluence model that only fires when several evidence layers agree.

        This is meant to create stronger >60/<40 probabilities only when the
        market has real multi-layer agreement. It prevents every forecast from
        staying glued to 50%, but it also does nothing when evidence is mixed.
        """
        score = 0.0; votes = 0; raw = {}
        if completeness is not None: raw['data_completeness'] = completeness
        if regime in ('bull_trend','post_halving_accumulation'):
            score += 0.35; votes += 1; raw['regime'] = regime
        elif regime in ('bear_trend','euphoria_risk'):
            score -= 0.35; votes += 1; raw['regime'] = regime
        if funding is not None:
            f=float(funding); raw['funding_rate']=f
            if f < -0.00005: score += 0.30; votes += 1
            elif f > 0.00018: score -= 0.30; votes += 1
        if oi_chg is not None:
            o=float(oi_chg); raw['oi_change_24h']=o
            if o > 4 and funding is not None and float(funding) < 0: score += 0.24; votes += 1
            elif o > 4 and funding is not None and float(funding) > 0: score -= 0.24; votes += 1
        if ob_imb is not None:
            im=float(ob_imb); raw['orderbook_imbalance']=im
            if im > 0.54: score += 0.20; votes += 1
            elif im < 0.46: score -= 0.20; votes += 1
        if taker_delta is not None:
            td=float(taker_delta); raw['taker_delta_ratio']=td
            if td > 0.08: score += 0.22; votes += 1
            elif td < -0.08: score -= 0.22; votes += 1
        if fg is not None:
            fear=float(fg); raw['fear_greed']=fear
            if fear < 20: score += 0.20; votes += 1
            elif fear > 82: score -= 0.20; votes += 1
        if dd is not None:
            d=float(dd); raw['drawdown_from_ath']=d
            if d < -45: score += 0.14; votes += 1
            elif d > -6: score -= 0.12; votes += 1
        if votes < 3:
            return self._pack("M_CLUSTER", "Evidence Cluster", horizon, 0.5, 0, 12, 0, 0.20, "Te weinig overeenkomende evidence-lagen", raw)
        bullish = sigmoid(score)
        conf = min(78, 24 + votes * 7 + max(0, float(completeness or 0)-50)*0.18)
        base = 1.45 if horizon in ('4h','8h','24h','7d') else 0.75
        return self._pack("M_CLUSTER", "Evidence Cluster", horizon, bullish, score*1.9, conf, votes, base,
                          "Confluence van regime, futures, orderflow, sentiment en drawdown", raw)


    def _spot_aggression_model(self, horizon, alpha):
        delta = alpha.get('binance_spot_flow.trade_delta_ratio_recent')
        ratio = alpha.get('binance_spot_flow.buy_sell_ratio_recent')
        if delta is None and ratio is None:
            return self._pack('M_SPOTAGG', 'Spot Aggression', horizon, 0.5, 0, 6, 0, 0.12, 'Geen spot tradeflow proxy')
        d = float(delta or 0)
        r = float(ratio or 1)
        score = d * 3.2 + (r - 1.0) * 0.18
        bullish = sigmoid(score)
        base = 1.05 if horizon in ('1h','4h','8h','24h') else 0.28
        return self._pack('M_SPOTAGG', 'Spot Aggression', horizon, bullish, score*0.85, 36, 1, base,
                          'Agressieve spot-kopers vs verkopers op recente Binance trades', {'spot_delta': delta, 'spot_buy_sell_ratio': ratio})

    def _futures_aggression_model(self, horizon, alpha, funding):
        delta = alpha.get('binance_futures_flow.trade_delta_ratio_recent')
        ratio = alpha.get('binance_futures_flow.buy_sell_ratio_recent')
        if delta is None and ratio is None:
            return self._pack('M_FUTAGG', 'Futures Aggression', horizon, 0.5, 0, 6, 0, 0.12, 'Geen futures tradeflow proxy')
        d = float(delta or 0)
        r = float(ratio or 1)
        score = d * 3.0 + (r - 1.0) * 0.14
        # If aggressive futures buying happens with already-positive funding, slightly reduce as crowded.
        f = float(funding or 0)
        if score > 0 and f > 0.00018:
            score *= 0.55
        if score < 0 and f < -0.00008:
            score *= 0.60
        bullish = sigmoid(score)
        base = 1.35 if horizon in ('1h','4h','8h','24h') else 0.28
        return self._pack('M_FUTAGG', 'Futures Aggression', horizon, bullish, score*0.95, 38, 1, base,
                          'Agressieve futures-kopers/verkopers met funding crowding-check', {'futures_delta': delta, 'futures_buy_sell_ratio': ratio, 'funding': funding})

    def _large_trade_imbalance_model(self, horizon, alpha):
        sd = alpha.get('binance_spot_flow.large_trade_imbalance_recent')
        fd = alpha.get('binance_futures_flow.large_trade_imbalance_recent')
        if sd is None and fd is None:
            return self._pack('M_LARGE', 'Large Trade Imbalance', horizon, 0.5, 0, 5, 0, 0.10, 'Geen large-trade imbalance')
        vals = [float(x) for x in (sd, fd) if x is not None]
        avg = sum(vals)/len(vals)
        score = avg * 2.4
        bullish = sigmoid(score)
        base = 1.0 if horizon in ('1h','4h','8h','24h') else 0.22
        conf = 28 + len(vals)*8
        return self._pack('M_LARGE', 'Large Trade Imbalance', horizon, bullish, score*0.80, conf, len(vals), base,
                          'Grote recente trades: koopdruk vs verkoopdruk', {'spot_large_imbalance': sd, 'futures_large_imbalance': fd})

    def _leverage_flow_agreement_model(self, horizon, alpha, funding, oi_chg, taker_delta):
        fd = alpha.get('binance_futures_flow.trade_delta_ratio_recent')
        if fd is None and taker_delta is None and funding is None and oi_chg is None:
            return self._pack('M_LEVFLOW', 'Leverage Flow Agreement', horizon, 0.5, 0, 5, 0, 0.10, 'Geen leverage-flow stack')
        score = 0.0; votes = 0; raw = {'funding': funding, 'oi_change_24h': oi_chg, 'futures_delta_recent': fd, 'taker_delta_feature': taker_delta}
        flow = float(fd if fd is not None else (taker_delta or 0))
        if flow > 0.06: score += 0.32; votes += 1
        elif flow < -0.06: score -= 0.32; votes += 1
        if oi_chg is not None and abs(float(oi_chg)) > 2:
            # OI expansion confirms trend if flow dominates; OI flush reduces conviction.
            score += (0.18 if flow > 0 else -0.18) if float(oi_chg) > 0 else 0.02
            votes += 1
        if funding is not None:
            f=float(funding)
            if f > 0.00020 and flow > 0: score -= 0.24; votes += 1
            elif f < -0.00008 and flow < 0: score += 0.18; votes += 1
            elif f < -0.00008 and flow > 0: score += 0.24; votes += 1
        if votes == 0:
            return self._pack('M_LEVFLOW', 'Leverage Flow Agreement', horizon, 0.5, 0, 8, 0, 0.12, 'Leverage-flow niet overtuigend', raw)
        bullish = sigmoid(score)
        base = 1.35 if horizon in ('1h','4h','8h','24h') else 0.30
        return self._pack('M_LEVFLOW', 'Leverage Flow Agreement', horizon, bullish, score*1.15, 26+votes*8, votes, base,
                          'Combinatie van futures-flow, OI en funding-crowding', raw)

    def _multi_layer_alpha_stack_model(self, horizon, alpha, regime, completeness, funding, oi_chg, ob_imb, fg, dd):
        """Higher-conviction confluence layer.

        This model only moves away from neutral when multiple independent layers
        agree. It is intentionally transparent and conservative: it should create
        stronger forecasts only when spot flow, futures flow, orderbook, sentiment
        and regime point the same way.
        """
        score = 0.0; votes = 0; raw = {}
        for key, weight in [('binance_spot_flow.trade_delta_ratio_recent',0.28), ('binance_futures_flow.trade_delta_ratio_recent',0.30), ('binance_spot_flow.large_trade_imbalance_recent',0.18), ('binance_futures_flow.large_trade_imbalance_recent',0.20)]:
            v = alpha.get(key); raw[key]=v
            if v is None: continue
            if float(v) > 0.07: score += weight; votes += 1
            elif float(v) < -0.07: score -= weight; votes += 1
        if ob_imb is not None:
            raw['orderbook_imbalance']=ob_imb
            if float(ob_imb) > 0.54: score += 0.18; votes += 1
            elif float(ob_imb) < 0.46: score -= 0.18; votes += 1
        if regime in ('bull_trend','post_halving_accumulation'):
            score += 0.22; votes += 1; raw['regime']=regime
        elif regime in ('bear_trend','euphoria_risk'):
            score -= 0.22; votes += 1; raw['regime']=regime
        if fg is not None:
            raw['fear_greed']=fg
            if float(fg) < 18: score += 0.16; votes += 1
            elif float(fg) > 82: score -= 0.16; votes += 1
        if funding is not None and oi_chg is not None:
            raw['funding']=funding; raw['oi_change_24h']=oi_chg
            if float(oi_chg) > 4 and float(funding) > 0.00018: score -= 0.20; votes += 1
            elif float(oi_chg) > 4 and float(funding) < -0.00005: score += 0.20; votes += 1
        if votes < 4:
            return self._pack('M_ALPHA_STACK', 'Multi-Layer Alpha Stack', horizon, 0.5, 0, 14, votes, 0.25, 'Te weinig onafhankelijke alpha-lagen tegelijk actief', raw)
        bullish = sigmoid(score)
        conf = min(86, 25 + votes*7 + max(0, float(completeness or 0)-55)*0.12)
        base = 1.8 if horizon in ('4h','8h','24h','7d') else 1.0
        return self._pack('M_ALPHA_STACK', 'Multi-Layer Alpha Stack', horizon, bullish, score*2.1, conf, votes, base,
                          'Sterke confluence uit spot-flow, futures-flow, orderbook, regime en sentiment', raw)


def sigmoid(x: float) -> float:
    try:
        return 1/(1+math.exp(-float(x)))
    except OverflowError:
        return 0.99 if x > 0 else 0.01
