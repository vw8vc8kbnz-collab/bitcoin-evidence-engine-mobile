from __future__ import annotations
import json
import numpy as np
import pandas as pd
from app.db.database import db
from app.engine.state_vector import FEATURE_KEYS
from app.core.time_utils import HORIZON_SECONDS

class HistoricalTwinFinder:
    def find(self, horizon: str, top_n: int = 120) -> dict:
        return self.find_at(horizon=horizon, cutoff_ms=None, top_n=top_n)

    def find_at(self, horizon: str, cutoff_ms: int | None = None, top_n: int = 120) -> dict:
        where_cutoff = "" if cutoff_ms is None else "AND timestamp_ms <= ?"
        params = [] if cutoff_ms is None else [int(cutoff_ms)]
        df = db.df(f"""
            SELECT timestamp_ms, close, state_json
            FROM features
            WHERE interval='1h' AND rsi_14 IS NOT NULL AND ma_50 IS NOT NULL {where_cutoff}
            ORDER BY timestamp_ms DESC
            LIMIT 5000
        """, params)
        df = df.sort_values("timestamp_ms").reset_index(drop=True)
        if len(df) < 250:
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0}
        current = df.iloc[-1]
        cur_vec = self._vec(current.state_json)
        steps = int(HORIZON_SECONDS[horizon] / 3600)
        if len(df) <= steps + 250:
            # Not enough history before the selected/current point to honestly test this horizon.
            # Return neutral instead of crashing; the UI will show evidence_count=0.
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0}
        hist = df.iloc[:-max(1, steps)].copy()
        if hist.empty:
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0}
        vectors = np.vstack([self._vec(s) for s in hist.state_json])
        # robust scale so one feature does not dominate
        med = np.nanmedian(vectors, axis=0)
        std = np.nanstd(vectors, axis=0)
        std[std == 0] = 1
        dist = np.linalg.norm((vectors - cur_vec) / std, axis=1)
        hist["distance"] = dist
        hist = hist.sort_values("distance").head(top_n)
        close_map = dict(zip(df.timestamp_ms, df.close))
        # dataframe is regular 1h, use positional lookup for outcome
        all_ts = list(df.timestamp_ms)
        pos = {int(ts): i for i, ts in enumerate(all_ts)}
        moves=[]; matches=[]
        closes = list(df.close)
        for _, r in hist.iterrows():
            i = pos.get(int(r.timestamp_ms))
            if i is None or i + steps >= len(closes): continue
            move = (float(closes[i+steps]) / float(r.close) - 1) * 100
            moves.append(move)
            matches.append({"timestamp_ms": int(r.timestamp_ms), "close": float(r.close), "future_move_pct": move, "distance": float(r.distance)})
        if not moves:
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0}
        arr=np.array(moves)
        return {
            "matches": matches[:50],
            "evidence_count": len(moves),
            "bullish_probability": float((arr > 0).mean()),
            "expected_move_pct": float(np.median(arr)),
            "avg_move_pct": float(np.mean(arr)),
            "worst_move_pct": float(np.min(arr)),
            "best_move_pct": float(np.max(arr)),
        }

    def _vec(self, state_json: str) -> np.ndarray:
        s=json.loads(state_json)
        return np.array([0.0 if s.get(k) is None else float(s.get(k)) for k in FEATURE_KEYS], dtype=float)
