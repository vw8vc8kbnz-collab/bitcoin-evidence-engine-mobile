from __future__ import annotations
from datetime import datetime, timezone
import httpx
from app.core.config import settings

class CoinbaseProvider:
    source = 'coinbase'
    base_url = 'https://api.exchange.coinbase.com'

    async def fetch_btc_usd_ticker(self) -> dict:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds, headers={'User-Agent':'BitcoinEvidenceEngine/10.16'}) as client:
            r = await client.get(f'{self.base_url}/products/BTC-USD/ticker')
            r.raise_for_status()
            x = r.json()
        return {'price': float(x.get('price') or 0), 'volume': float(x.get('volume') or 0), 'trade_id': x.get('trade_id')}

    async def fetch_btc_usd_candles(self, start_ms: int, end_ms: int, granularity: int = 3600) -> list[dict]:
        """Historical Coinbase BTC-USD candles.

        Coinbase Exchange public API caps candle responses to roughly 300 buckets.
        The caller must page in 300h chunks. Returned timestamps are normalized
        to millisecond open time and stored as raw external evidence, not as the
        primary Binance candle source.
        """
        start = datetime.fromtimestamp(int(start_ms)/1000, tz=timezone.utc).isoformat()
        end = datetime.fromtimestamp(int(end_ms)/1000, tz=timezone.utc).isoformat()
        params = {'granularity': int(granularity), 'start': start, 'end': end}
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds, headers={'User-Agent':'BitcoinEvidenceEngine/10.16'}) as client:
            r = await client.get(f'{self.base_url}/products/BTC-USD/candles', params=params)
            r.raise_for_status()
            raw = r.json()
        rows=[]
        for x in raw or []:
            # Coinbase returns [time, low, high, open, close, volume]
            try:
                ts = int(x[0]) * 1000
                rows.append({'timestamp_ms': ts, 'open': float(x[3]), 'high': float(x[2]), 'low': float(x[1]), 'close': float(x[4]), 'volume': float(x[5])})
            except Exception:
                continue
        return sorted(rows, key=lambda r: r['timestamp_ms'])
