from __future__ import annotations
from datetime import datetime, timezone
import httpx
from app.core.config import settings
from app.providers.base import ProviderResult

class BinanceProvider:
    source = "binance"
    base_url = "https://api.binance.com"

    async def fetch_klines(self, symbol: str, interval: str = "1h", start_ms: int | None = None, limit: int = 1000, end_ms: int | None = None, timeout_seconds: float | None = None) -> list[dict]:
        params = {"symbol": symbol, "interval": interval, "limit": min(limit, 1000)}
        if start_ms:
            params["startTime"] = start_ms
        if end_ms:
            params["endTime"] = end_ms
        timeout = float(timeout_seconds if timeout_seconds is not None else settings.request_timeout_seconds)
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get(f"{self.base_url}/api/v3/klines", params=params)
            r.raise_for_status()
            raw = r.json()
        return [
            {
                "source": self.source,
                "symbol": symbol,
                "interval": interval,
                "open_time": int(x[0]),
                "open": float(x[1]),
                "high": float(x[2]),
                "low": float(x[3]),
                "close": float(x[4]),
                "volume": float(x[5]),
                "close_time": int(x[6]),
                "quote_volume": float(x[7]),
                "trades": int(x[8]),
            }
            for x in raw
        ]

    async def fetch_ticker(self, symbol: str) -> dict:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/api/v3/ticker/24hr", params={"symbol": symbol})
            r.raise_for_status()
            x = r.json()
        return {"price": float(x["lastPrice"]), "change_pct": float(x["priceChangePercent"]), "volume": float(x["volume"])}

    async def fetch_orderbook(self, symbol: str, limit: int = 100) -> dict:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/api/v3/depth", params={"symbol": symbol, "limit": limit})
            r.raise_for_status()
            x = r.json()
        bids = [(float(p), float(q)) for p, q in x.get("bids", [])]
        asks = [(float(p), float(q)) for p, q in x.get("asks", [])]
        bid_notional = sum(p*q for p,q in bids)
        ask_notional = sum(p*q for p,q in asks)
        imbalance = bid_notional / (bid_notional + ask_notional) if bid_notional + ask_notional else 0.5
        spread = asks[0][0] - bids[0][0] if bids and asks else None
        return {"bid_notional": bid_notional, "ask_notional": ask_notional, "imbalance": imbalance, "spread": spread}

    async def fetch_recent_agg_trade_flow(self, symbol: str, limit: int = 1000) -> dict:
        """Recent spot trade-flow proxy from public aggregate trades.

        Binance aggregate trades expose whether the buyer was maker (`m`). If buyer
        is maker, the taker was selling; otherwise the taker was buying. This is
        not full exchange-level CVD, but it is a useful live proxy for aggressive
        spot flow. Stored as one compact metric snapshot by SyncService.
        """
        params = {"symbol": symbol, "limit": min(max(int(limit), 100), 1000)}
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/api/v3/aggTrades", params=params)
            r.raise_for_status()
            raw = r.json()
        buy_notional = 0.0
        sell_notional = 0.0
        large_buy = 0.0
        large_sell = 0.0
        largest = 0.0
        ts = int(datetime.now(timezone.utc).timestamp()*1000)
        for x in raw:
            price = float(x.get('p') or 0)
            qty = float(x.get('q') or 0)
            notional = price * qty
            ts = max(ts, int(x.get('T') or ts))
            if bool(x.get('m')):
                sell_notional += notional
                if notional >= 250_000:
                    large_sell += notional
            else:
                buy_notional += notional
                if notional >= 250_000:
                    large_buy += notional
            largest = max(largest, notional)
        total = buy_notional + sell_notional
        large_total = large_buy + large_sell
        return {
            'timestamp_ms': ts,
            'buy_notional': buy_notional,
            'sell_notional': sell_notional,
            'delta_ratio': ((buy_notional - sell_notional) / total) if total else 0.0,
            'buy_sell_ratio': (buy_notional / sell_notional) if sell_notional else None,
            'large_buy_notional': large_buy,
            'large_sell_notional': large_sell,
            'large_trade_imbalance': ((large_buy - large_sell) / large_total) if large_total else 0.0,
            'largest_trade_notional': largest,
            'trade_count': len(raw),
        }
