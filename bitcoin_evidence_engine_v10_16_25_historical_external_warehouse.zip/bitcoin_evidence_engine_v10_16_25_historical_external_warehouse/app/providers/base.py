from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass
class ProviderResult:
    source: str
    status: str
    rows_added: int = 0
    detail: dict[str, Any] | None = None
    error: str | None = None
