from __future__ import annotations
from datetime import datetime, timezone
import httpx
from app.core.config import settings

class FearGreedProvider:
    source = "alternative_me"
    async def fetch_latest(self) -> dict | None:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get("https://api.alternative.me/fng/", params={"limit": 1, "format": "json"})
            r.raise_for_status()
            data = r.json().get("data", [])
        if not data:
            return None
        x = data[0]
        return {"timestamp_ms": int(x["timestamp"])*1000, "value": float(x["value"]), "classification": x.get("value_classification")}

    async def fetch_history(self, limit: int = 0) -> list[dict]:
        """Historical Fear & Greed. alternative.me supports limit=0 for all rows.
        Returned timestamps are daily; FeatureEngine forward-fills within 7d only.
        """
        params={"limit": int(limit), "format":"json"}
        async with httpx.AsyncClient(timeout=max(settings.request_timeout_seconds, 20.0)) as client:
            r = await client.get("https://api.alternative.me/fng/", params=params)
            r.raise_for_status()
            data = r.json().get("data", [])
        out=[]
        for x in data:
            try:
                out.append({"timestamp_ms": int(x["timestamp"])*1000, "value": float(x["value"]), "classification": x.get("value_classification")})
            except Exception:
                pass
        return out
