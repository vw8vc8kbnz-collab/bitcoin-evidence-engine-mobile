from __future__ import annotations
import httpx
from app.core.config import settings

class KrakenProvider:
    source = "kraken"
    base_url = "https://api.kraken.com"

    async def fetch_btc_usd_ticker(self) -> dict:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/0/public/Ticker", params={"pair": "XBTUSD"})
            r.raise_for_status()
            data = r.json()["result"]
        key = next(iter(data.keys()))
        x = data[key]
        return {"price": float(x["c"][0]), "volume": float(x["v"][1])}

    async def fetch_btc_usd_ohlc(self, start_ms: int, interval: int = 60) -> list[dict]:
        """Historical Kraken XBT/USD OHLC.

        Kraken returns recent rows from `since` and may cap the amount. The daemon
        calls this incrementally and stores whatever the public endpoint allows.
        """
        since = max(0, int(start_ms)//1000)
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/0/public/OHLC", params={"pair":"XBTUSD", "interval": int(interval), "since": since})
            r.raise_for_status()
            data = r.json().get("result", {})
        key = next((k for k in data.keys() if k != 'last'), None)
        raw = data.get(key, []) if key else []
        rows=[]
        for x in raw or []:
            try:
                # [time, open, high, low, close, vwap, volume, count]
                ts = int(float(x[0])) * 1000
                rows.append({'timestamp_ms': ts, 'open': float(x[1]), 'high': float(x[2]), 'low': float(x[3]), 'close': float(x[4]), 'volume': float(x[6])})
            except Exception:
                continue
        return sorted(rows, key=lambda r: r['timestamp_ms'])
