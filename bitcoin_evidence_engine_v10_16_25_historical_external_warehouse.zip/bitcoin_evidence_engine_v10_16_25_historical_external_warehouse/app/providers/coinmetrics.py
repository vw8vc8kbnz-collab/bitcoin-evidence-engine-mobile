from __future__ import annotations
import httpx
from datetime import datetime, timezone, timedelta
from app.core.config import settings

class CoinMetricsProvider:
    source = "coinmetrics_community"
    base_url = "https://community-api.coinmetrics.io/v4"

    async def fetch_asset_metrics(self, metrics: list[str], days: int = 3000) -> list[dict]:
        """Fetch CoinMetrics asset metrics when explicitly enabled.

        V10.16.23 audit note: the public/community endpoint returned 403 on the VPS.
        Therefore this provider is disabled by default and will only run when the
        operator supplies BEE_COINMETRICS_ENABLED=1 and BEE_COINMETRICS_API_KEY.
        Without that, the app must not waste 20-35s waiting and must not pretend
        real on-chain data is available.
        """
        if not getattr(settings, 'coinmetrics_enabled', False) or not getattr(settings, 'coinmetrics_api_key', ''):
            raise RuntimeError('CoinMetrics disabled: missing BEE_COINMETRICS_API_KEY')
        start = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()
        params = {"assets":"btc", "metrics": ",".join(metrics), "frequency":"1d", "start_time": start, "api_key": settings.coinmetrics_api_key}
        timeout = max(float(getattr(settings, 'external_provider_timeout_seconds', 8.0)), 8.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get(f"{self.base_url}/timeseries/asset-metrics", params=params)
            r.raise_for_status()
            data = r.json().get("data", [])
        rows=[]
        for item in data:
            ts = int(datetime.fromisoformat(item["time"].replace("Z","+00:00")).timestamp()*1000)
            for m in metrics:
                val = item.get(m)
                if val is not None:
                    try: rows.append({"metric": m, "timestamp_ms": ts, "value": float(val)})
                    except ValueError: pass
        return rows
