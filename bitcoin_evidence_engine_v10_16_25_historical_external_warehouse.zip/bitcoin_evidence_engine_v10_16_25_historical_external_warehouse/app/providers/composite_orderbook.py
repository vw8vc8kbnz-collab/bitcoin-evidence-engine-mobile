from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Any
import httpx
from app.core.config import settings

@dataclass
class OrderBookSnapshot:
    exchange: str
    pair: str
    bids: list[tuple[float, float]]
    asks: list[tuple[float, float]]
    raw: dict[str, Any] | None = None

    @property
    def mid(self) -> float | None:
        if not self.bids or not self.asks:
            return None
        return (self.bids[0][0] + self.asks[0][0]) / 2

    @property
    def spread(self) -> float | None:
        if not self.bids or not self.asks:
            return None
        return self.asks[0][0] - self.bids[0][0]

class CompositeOrderBookProvider:
    """Multi-exchange orderbook collector.

    Public REST snapshots are used so V6 works without API keys. The forecast
    engine only receives a single composite signal, but we keep the per-exchange
    internals in metadata for debugging/data-health. Later we can swap REST for
    websockets without changing downstream feature/model code.
    """
    source = "composite_orderbook"

    async def fetch_all(self) -> dict:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds, headers={"User-Agent":"BitcoinEvidenceEngine/6.0"}) as client:
            tasks = [
                self._safe("binance", self._binance(client)),
                self._safe("coinbase", self._coinbase(client)),
                self._safe("kraken", self._kraken(client)),
                self._safe("okx", self._okx(client)),
                self._safe("bybit", self._bybit(client)),
            ]
            # Avoid importing asyncio in type constrained code? just import here.
            import asyncio
            results = await asyncio.gather(*tasks)
        books = [r for r in results if isinstance(r, OrderBookSnapshot) and r.mid]
        errors = [r for r in results if isinstance(r, dict) and r.get("error")]
        return self._composite(books, errors)

    async def _safe(self, name: str, coro):
        try:
            return await coro
        except Exception as exc:
            return {"exchange": name, "error": str(exc)[:300]}

    async def _binance(self, client: httpx.AsyncClient) -> OrderBookSnapshot:
        r = await client.get("https://api.binance.com/api/v3/depth", params={"symbol":"BTCUSDT", "limit":1000})
        r.raise_for_status()
        x = r.json()
        return OrderBookSnapshot("binance", "BTCUSDT", _levels(x.get("bids", [])), _levels(x.get("asks", [])), {"lastUpdateId": x.get("lastUpdateId")})

    async def _coinbase(self, client: httpx.AsyncClient) -> OrderBookSnapshot:
        r = await client.get("https://api.exchange.coinbase.com/products/BTC-USD/book", params={"level":2})
        r.raise_for_status()
        x = r.json()
        # Coinbase level 2 rows are [price, size, num-orders]
        return OrderBookSnapshot("coinbase", "BTC-USD", _levels(x.get("bids", [])), _levels(x.get("asks", [])), {"sequence": x.get("sequence")})

    async def _kraken(self, client: httpx.AsyncClient) -> OrderBookSnapshot:
        r = await client.get("https://api.kraken.com/0/public/Depth", params={"pair":"XBTUSD", "count":500})
        r.raise_for_status()
        x = r.json()
        if x.get("error"):
            raise RuntimeError("; ".join(x.get("error") or []))
        result = x.get("result") or {}
        first = next(iter(result.values())) if result else {}
        return OrderBookSnapshot("kraken", "XBTUSD", _levels(first.get("bids", [])), _levels(first.get("asks", [])), {})

    async def _okx(self, client: httpx.AsyncClient) -> OrderBookSnapshot:
        r = await client.get("https://www.okx.com/api/v5/market/books", params={"instId":"BTC-USDT", "sz":400})
        r.raise_for_status()
        x = r.json()
        if x.get("code") not in ("0", 0):
            raise RuntimeError(x.get("msg") or str(x)[:200])
        data = (x.get("data") or [{}])[0]
        return OrderBookSnapshot("okx", "BTC-USDT", _levels(data.get("bids", [])), _levels(data.get("asks", [])), {"ts": data.get("ts")})

    async def _bybit(self, client: httpx.AsyncClient) -> OrderBookSnapshot:
        r = await client.get("https://api.bybit.com/v5/market/orderbook", params={"category":"spot", "symbol":"BTCUSDT", "limit":200})
        r.raise_for_status()
        x = r.json()
        if str(x.get("retCode")) != "0":
            raise RuntimeError(x.get("retMsg") or str(x)[:200])
        data = x.get("result") or {}
        return OrderBookSnapshot("bybit", "BTCUSDT", _levels(data.get("b", [])), _levels(data.get("a", [])), {"ts": x.get("time")})

    def _composite(self, books: list[OrderBookSnapshot], errors: list[dict]) -> dict:
        if not books:
            return {"status":"error", "errors":errors, "exchange_count":0}
        mids = [b.mid for b in books if b.mid]
        global_mid = _weighted_median(mids) if mids else None
        bands = [0.0025, 0.005, 0.01, 0.02]
        band_metrics = {}
        total_bid_1 = total_ask_1 = 0.0
        exchange_details = []
        wall_candidates = []
        for book in books:
            mid = book.mid or global_mid
            spread = book.spread
            ex = {"exchange":book.exchange, "pair":book.pair, "mid":mid, "spread":spread, "bands":{}}
            for pct in bands:
                bid_notional = sum(p*q for p,q in book.bids if mid and p >= mid*(1-pct))
                ask_notional = sum(p*q for p,q in book.asks if mid and p <= mid*(1+pct))
                imb = bid_notional / (bid_notional + ask_notional) if bid_notional + ask_notional else 0.5
                key = f"{pct:.4f}"
                ex["bands"][key] = {"bid_notional":bid_notional, "ask_notional":ask_notional, "imbalance":imb}
                bm = band_metrics.setdefault(key, {"bid_notional":0.0, "ask_notional":0.0})
                bm["bid_notional"] += bid_notional
                bm["ask_notional"] += ask_notional
                if pct == 0.01:
                    total_bid_1 += bid_notional
                    total_ask_1 += ask_notional
            wall_candidates += _wall_candidates(book, global_mid or mid)
            exchange_details.append(ex)
        for key, bm in band_metrics.items():
            total = bm["bid_notional"] + bm["ask_notional"]
            bm["imbalance"] = bm["bid_notional"] / total if total else 0.5
        best_walls = sorted(wall_candidates, key=lambda x: x["notional"], reverse=True)[:12]
        composite_imbalance = band_metrics.get("0.0100", {}).get("imbalance", 0.5)
        composite_spread = _safe_avg([b.spread for b in books if b.spread is not None])
        return {
            "status":"ok",
            "exchange_count":len(books),
            "errors":errors,
            "mid": global_mid,
            "composite_imbalance": composite_imbalance,
            "composite_spread": composite_spread,
            "bid_notional_1pct": total_bid_1,
            "ask_notional_1pct": total_ask_1,
            "bands": band_metrics,
            "exchanges": exchange_details,
            "walls": best_walls,
        }

def _levels(rows: list) -> list[tuple[float, float]]:
    out=[]
    for row in rows:
        try:
            out.append((float(row[0]), float(row[1])))
        except Exception:
            continue
    return out

def _safe_avg(vals: list[float]) -> float | None:
    vals = [float(v) for v in vals if v is not None and math.isfinite(float(v))]
    return sum(vals)/len(vals) if vals else None

def _weighted_median(vals: list[float]) -> float | None:
    vals = sorted(float(v) for v in vals if v and math.isfinite(float(v)))
    if not vals: return None
    return vals[len(vals)//2]

def _wall_candidates(book: OrderBookSnapshot, mid: float | None) -> list[dict]:
    if not mid:
        return []
    candidates=[]
    for side, rows in (("bid", book.bids), ("ask", book.asks)):
        near=[(p,q,p*q) for p,q in rows if abs(p/mid-1) <= 0.025]
        if not near:
            continue
        notionals=[n for _,_,n in near]
        avg=sum(notionals)/len(notionals)
        threshold=max(avg*8, 2_000_000)  # avoid tiny false positives
        for p,q,n in near:
            if n >= threshold:
                candidates.append({"exchange":book.exchange,"side":side,"price":p,"btc":q,"notional":n,"distance_pct":(p/mid-1)*100})
    return candidates
