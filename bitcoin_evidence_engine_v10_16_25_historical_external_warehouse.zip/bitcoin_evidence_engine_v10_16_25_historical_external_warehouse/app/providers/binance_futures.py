from __future__ import annotations
from datetime import datetime, timezone, timedelta
import httpx
from app.core.config import settings

class BinanceFuturesProvider:
    """Public Binance USD-M futures market data provider.

    Everything here is treated as optional evidence. If Binance blocks an endpoint,
    SyncService records the error in Data Health and the engine continues.
    """
    source = "binance_futures"
    base_url = "https://fapi.binance.com"
    data_url = "https://fapi.binance.com/futures/data"

    async def fetch_funding_rate(self, symbol: str, start_ms: int | None = None, limit: int = 1000) -> list[dict]:
        params = {"symbol": symbol, "limit": min(limit, 1000)}
        if start_ms:
            params["startTime"] = int(start_ms)
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/fapi/v1/fundingRate", params=params)
            r.raise_for_status()
            raw = r.json()
        return [{"metric": "funding_rate", "timestamp_ms": int(x["fundingTime"]), "value": float(x["fundingRate"])} for x in raw]

    async def fetch_open_interest_hist(self, symbol: str, period: str = "1h", start_ms: int | None = None, limit: int = 500, end_ms: int | None = None) -> list[dict]:
        params = {"symbol": symbol, "period": period, "limit": min(limit, 500)}
        if start_ms:
            params["startTime"] = int(start_ms)
        if end_ms:
            params["endTime"] = int(end_ms)
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.data_url}/openInterestHist", params=params)
            r.raise_for_status()
            raw = r.json()
        rows=[]
        for x in raw:
            rows.append({"metric":"open_interest_contracts", "timestamp_ms": int(x["timestamp"]), "value": float(x.get("sumOpenInterest", 0))})
            if x.get("sumOpenInterestValue") is not None:
                rows.append({"metric":"open_interest_value", "timestamp_ms": int(x["timestamp"]), "value": float(x.get("sumOpenInterestValue", 0))})
        return rows

    async def fetch_global_long_short_ratio(self, symbol: str, period: str = "1h", limit: int = 500, start_ms: int | None = None, end_ms: int | None = None) -> list[dict]:
        params = {"symbol": symbol, "period": period, "limit": min(limit, 500)}
        if start_ms: params["startTime"] = int(start_ms)
        if end_ms: params["endTime"] = int(end_ms)
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.data_url}/globalLongShortAccountRatio", params=params)
            r.raise_for_status()
            raw = r.json()
        rows=[]
        for x in raw:
            ts = int(x["timestamp"])
            rows.append({"metric":"long_short_ratio", "timestamp_ms": ts, "value": float(x.get("longShortRatio", 0))})
            rows.append({"metric":"long_account_pct", "timestamp_ms": ts, "value": float(x.get("longAccount", 0))})
            rows.append({"metric":"short_account_pct", "timestamp_ms": ts, "value": float(x.get("shortAccount", 0))})
        return rows

    async def fetch_taker_long_short_ratio(self, symbol: str, period: str = "1h", limit: int = 500, start_ms: int | None = None, end_ms: int | None = None) -> list[dict]:
        params = {"symbol": symbol, "period": period, "limit": min(limit, 500)}
        if start_ms: params["startTime"] = int(start_ms)
        if end_ms: params["endTime"] = int(end_ms)
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.data_url}/takerlongshortRatio", params=params)
            r.raise_for_status()
            raw = r.json()
        rows=[]
        for x in raw:
            ts = int(x["timestamp"])
            buy = float(x.get("buyVol", 0) or 0)
            sell = float(x.get("sellVol", 0) or 0)
            rows.append({"metric":"taker_buy_sell_ratio", "timestamp_ms": ts, "value": float(x.get("buySellRatio", 0))})
            rows.append({"metric":"taker_buy_volume", "timestamp_ms": ts, "value": buy})
            rows.append({"metric":"taker_sell_volume", "timestamp_ms": ts, "value": sell})
            rows.append({"metric":"taker_delta_ratio", "timestamp_ms": ts, "value": ((buy - sell) / (buy + sell)) if (buy + sell) else 0.0})
        return rows


    async def fetch_premium_index(self, symbol: str) -> list[dict]:
        """Current mark/index/funding snapshot. Public USD-M endpoint.

        This adds an extra futures-evidence layer: basis/premium can show
        whether perpetual futures trade rich/cheap versus spot/index.
        """
        params = {"symbol": symbol}
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/fapi/v1/premiumIndex", params=params)
            r.raise_for_status()
            x = r.json()
        ts = int(x.get("time") or datetime.now(timezone.utc).timestamp()*1000)
        mark = float(x.get("markPrice") or 0)
        index = float(x.get("indexPrice") or 0)
        premium = ((mark / index - 1) * 100) if mark and index else 0.0
        return [
            {"metric":"futures_mark_price", "timestamp_ms": ts, "value": mark},
            {"metric":"futures_index_price", "timestamp_ms": ts, "value": index},
            {"metric":"futures_basis_premium_pct", "timestamp_ms": ts, "value": premium},
            {"metric":"premium_last_funding_rate", "timestamp_ms": ts, "value": float(x.get("lastFundingRate") or 0)},
        ]

    async def fetch_open_interest_current(self, symbol: str) -> list[dict]:
        params = {"symbol": symbol}
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/fapi/v1/openInterest", params=params)
            r.raise_for_status()
            x = r.json()
        ts = int(x.get("time") or datetime.now(timezone.utc).timestamp()*1000)
        return [{"metric":"current_open_interest_contracts", "timestamp_ms": ts, "value": float(x.get("openInterest") or 0)}]

    async def fetch_top_long_short_position_ratio(self, symbol: str, period: str = "1h", limit: int = 500, start_ms: int | None = None, end_ms: int | None = None) -> list[dict]:
        params = {"symbol": symbol, "period": period, "limit": min(limit, 500)}
        if start_ms: params["startTime"] = int(start_ms)
        if end_ms: params["endTime"] = int(end_ms)
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.data_url}/topLongShortPositionRatio", params=params)
            r.raise_for_status()
            raw = r.json()
        rows=[]
        for x in raw:
            ts = int(x["timestamp"])
            rows.append({"metric":"top_position_long_short_ratio", "timestamp_ms": ts, "value": float(x.get("longShortRatio", 0))})
            rows.append({"metric":"top_position_long_account", "timestamp_ms": ts, "value": float(x.get("longAccount", 0))})
            rows.append({"metric":"top_position_short_account", "timestamp_ms": ts, "value": float(x.get("shortAccount", 0))})
        return rows

    async def fetch_top_long_short_account_ratio(self, symbol: str, period: str = "1h", limit: int = 500, start_ms: int | None = None, end_ms: int | None = None) -> list[dict]:
        params = {"symbol": symbol, "period": period, "limit": min(limit, 500)}
        if start_ms: params["startTime"] = int(start_ms)
        if end_ms: params["endTime"] = int(end_ms)
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.data_url}/topLongShortAccountRatio", params=params)
            r.raise_for_status()
            raw = r.json()
        rows=[]
        for x in raw:
            ts = int(x["timestamp"])
            rows.append({"metric":"top_account_long_short_ratio", "timestamp_ms": ts, "value": float(x.get("longShortRatio", 0))})
            rows.append({"metric":"top_account_long_account", "timestamp_ms": ts, "value": float(x.get("longAccount", 0))})
            rows.append({"metric":"top_account_short_account", "timestamp_ms": ts, "value": float(x.get("shortAccount", 0))})
        return rows

    async def fetch_recent_liquidations(self, symbol: str, limit: int = 1000) -> list[dict]:
        # allForceOrders is a public market-data endpoint on Binance Futures, but
        # availability/rate limits vary. We store recent liquidation notional by event time.
        params = {"symbol": symbol, "limit": min(limit, 1000)}
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/fapi/v1/allForceOrders", params=params)
            r.raise_for_status()
            raw = r.json()
        rows=[]
        for x in raw:
            ts = int(x.get("time") or x.get("updateTime") or 0)
            if not ts: continue
            side = str(x.get("side", "")).upper()
            qty = float(x.get("executedQty") or x.get("origQty") or 0)
            price = float(x.get("averagePrice") or x.get("price") or 0)
            notional = qty * price
            metric = "liquidation_buy_notional" if side == "BUY" else "liquidation_sell_notional"
            rows.append({"metric": metric, "timestamp_ms": ts, "value": notional})
        return rows

    async def fetch_recent_agg_trade_flow(self, symbol: str, limit: int = 1000) -> dict:
        """Recent USD-M futures trade-flow proxy from public aggregate trades."""
        params = {"symbol": symbol, "limit": min(max(int(limit), 100), 1000)}
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/fapi/v1/aggTrades", params=params)
            r.raise_for_status()
            raw = r.json()
        buy_notional = 0.0
        sell_notional = 0.0
        large_buy = 0.0
        large_sell = 0.0
        largest = 0.0
        ts = int(datetime.now(timezone.utc).timestamp()*1000)
        for x in raw:
            price = float(x.get('p') or 0)
            qty = float(x.get('q') or 0)
            notional = price * qty
            ts = max(ts, int(x.get('T') or ts))
            if bool(x.get('m')):
                sell_notional += notional
                if notional >= 500_000:
                    large_sell += notional
            else:
                buy_notional += notional
                if notional >= 500_000:
                    large_buy += notional
            largest = max(largest, notional)
        total = buy_notional + sell_notional
        large_total = large_buy + large_sell
        return {
            'timestamp_ms': ts,
            'buy_notional': buy_notional,
            'sell_notional': sell_notional,
            'delta_ratio': ((buy_notional - sell_notional) / total) if total else 0.0,
            'buy_sell_ratio': (buy_notional / sell_notional) if sell_notional else None,
            'large_buy_notional': large_buy,
            'large_sell_notional': large_sell,
            'large_trade_imbalance': ((large_buy - large_sell) / large_total) if large_total else 0.0,
            'largest_trade_notional': largest,
            'trade_count': len(raw),
        }
