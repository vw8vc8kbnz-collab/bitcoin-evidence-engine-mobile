from __future__ import annotations
import httpx
from app.core.config import settings

class CoinGeckoProvider:
    source = "coingecko"
    base_url = "https://api.coingecko.com/api/v3"

    async def fetch_market_chart(self, days: int = 365) -> list[dict]:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/coins/bitcoin/market_chart", params={"vs_currency":"usd", "days": days})
            r.raise_for_status()
            data = r.json()
        # returns price/marketcap/volume points. We store price as metric fallback.
        return [{"timestamp_ms": int(t), "value": float(v)} for t, v in data.get("prices", [])]
