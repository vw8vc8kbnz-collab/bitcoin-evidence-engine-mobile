#!/usr/bin/env bash
set -euo pipefail
PORT="${PORT:-8787}"
echo "Processes:"
ps aux | grep -i "uvicorn app.main:app\|bee_native_core" | grep -v grep || true
echo ""
echo "Health:"
curl -fsS "http://127.0.0.1:${PORT}/api/health" || curl -fsS "http://127.0.0.1:${PORT}/health" || true
echo ""
echo "Last server.log lines:"
tail -80 server.log 2>/dev/null || true
