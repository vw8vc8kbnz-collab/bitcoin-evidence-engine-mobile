#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "== Bitcoin Evidence Engine VPS bootstrap v10.16.3 no-token =="
sudo apt-get update
sudo apt-get install -y curl unzip git build-essential g++ nginx python3 python3-venv python3-pip

# Ubuntu 26.x can try to build pandas/duckdb from source with system Python.
# Use uv + Python 3.12 so normal binary wheels are used.
if ! command -v uv >/dev/null 2>&1; then
  curl -LsSf https://astral.sh/uv/install.sh | sh
fi
export PATH="$HOME/.local/bin:$PATH"
uv python install 3.12
rm -rf .venv
uv venv .venv --python 3.12
. .venv/bin/activate
uv pip install -r requirements.txt
./build_native_core_linux.sh
mkdir -p "$HOME/bitcoin_evidence_data" logs native_core/bin
echo "OK. Start met: bash start_oracle.sh"
