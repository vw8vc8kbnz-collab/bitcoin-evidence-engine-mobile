#!/usr/bin/env bash
set -euo pipefail
PORT="${PORT:-8787}"
echo "Stopping Bitcoin Evidence Engine on port ${PORT}..."
PIDS="$(pgrep -f "uvicorn app.main:app.*--port ${PORT}" || true)"
if [ -z "$PIDS" ]; then
  PIDS="$(lsof -ti tcp:${PORT} 2>/dev/null || true)"
fi
if [ -z "$PIDS" ]; then
  echo "No running process found."
  exit 0
fi
echo "$PIDS" | xargs -r kill
sleep 1
LEFT="$(echo "$PIDS" | xargs -r ps -p 2>/dev/null | awk 'NR>1{print $1}' || true)"
if [ -n "$LEFT" ]; then
  echo "$LEFT" | xargs -r kill -9 || true
fi
echo "Stopped."
