@echo off
cd /d %~dp0
echo This removes only the dependency marker. Next start.bat will reinstall/check packages.
del .deps_installed 2>nul
echo Done. Now run start.bat again.
pause
