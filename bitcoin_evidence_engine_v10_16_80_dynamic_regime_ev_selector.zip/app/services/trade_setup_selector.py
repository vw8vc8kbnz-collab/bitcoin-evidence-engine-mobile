from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl
from app.db.database import db

HORIZON_HOURS = {'1h':1, '4h':4, '8h':8, '24h':24, '7d':24*7, '30d':24*30, '90d':24*90}


def _finite(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        if math.isfinite(x):
            return x
    except Exception:
        pass
    return default


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


class TradeSetupSelector:
    """Unified Time Machine + Forecast trade setup selector.

    v10.16.80 rebuilds the selector after the DeepSeek audit: dynamic regime-aware thresholds, honest EV/PF-driven filtering, contextual RR/target/stop instead of a rigid fixed RR, and specific NO_TRADE reasons:
    LONG / SHORT / NO TRADE, entry, learned win price, invalidation, RR,
    market potential in dollars, and outcome evaluation in Time Machine.

    This class is deliberately shared by live Forecast and Time Machine export
    enrichment.  The same rules and same learned DB context are used in both
    places, so forecast can no longer drift away from Time Machine training.
    """

    MIN_RR = 1.15
    BASE_RR = 1.50


    def __init__(self):
        self._range_cache: dict[str, dict[str, float]] = {}

    def _recent_range_stats(self, horizon: str) -> dict[str, float]:
        horizon = str(horizon)
        if horizon in self._range_cache:
            return self._range_cache[horizon]
        h = max(1, int(HORIZON_HOURS.get(horizon, 24)))
        # Do not use future information in live forecast.  This is historical
        # distribution of realised moves over all available candles.  It tells
        # the engine what BTC can realistically move for this horizon.
        # Keep the query bounded so mobile VPS stays responsive.
        try:
            frame = db.df("""
                WITH c AS (
                    SELECT row_number() OVER (ORDER BY open_time) rn, open_time, close, high, low
                    FROM raw_candles
                    WHERE source='binance' AND symbol=? AND interval='1h'
                    ORDER BY open_time DESC LIMIT 20000
                ), ordered AS (
                    SELECT * FROM c ORDER BY rn
                )
                SELECT a.close AS entry_price,
                       b.close AS exit_price,
                       (SELECT MAX(x.high) FROM ordered x WHERE x.rn>a.rn AND x.rn<=a.rn+?) AS max_high,
                       (SELECT MIN(x.low) FROM ordered x WHERE x.rn>a.rn AND x.rn<=a.rn+?) AS min_low
                FROM ordered a
                JOIN ordered b ON b.rn=a.rn+?
                WHERE a.close IS NOT NULL AND a.close>0 AND b.close IS NOT NULL
                LIMIT 12000
            """, [settings.symbol, h, h, h])
            if frame.empty:
                raise RuntimeError('empty range stats')
            import pandas as pd
            entry = frame['entry_price'].astype(float).clip(lower=1e-9)
            up = ((frame['max_high'].astype(float) - entry) / entry * 100.0).abs()
            down = ((entry - frame['min_low'].astype(float)) / entry * 100.0).abs()
            abs_close = ((frame['exit_price'].astype(float) - entry) / entry * 100.0).abs()
            favorable = pd.concat([up, down], axis=0).dropna()
            out = {
                'median_range_pct': float(favorable.quantile(0.50)),
                'p65_range_pct': float(favorable.quantile(0.65)),
                'p75_range_pct': float(favorable.quantile(0.75)),
                'p85_range_pct': float(favorable.quantile(0.85)),
                'median_close_move_pct': float(abs_close.dropna().quantile(0.50)),
                'samples': int(len(frame)),
            }
        except Exception as exc:
            # Safe fallback based on horizon only. Used only when DB statistics
            # are unavailable; the note makes it auditable.
            base = {'1h':0.55,'4h':1.05,'8h':1.55,'24h':2.6,'7d':6.5,'30d':14.0,'90d':27.0}.get(horizon,2.0)
            out = {'median_range_pct':base*0.65,'p65_range_pct':base*0.85,'p75_range_pct':base,'p85_range_pct':base*1.25,'median_close_move_pct':base*0.45,'samples':0,'fallback_error':str(exc)[:180]}
        self._range_cache[horizon] = out
        return out

    def _context_from_item(self, item: dict) -> dict:
        f = dict(item.get('feature_snapshot') or {})
        return {
            'regime': str(f.get('regime') or f.get('regime_code') or item.get('regime') or 'unknown'),
            'volatility_24': _finite(f.get('volatility_24') or f.get('volatility') or f.get('range_pct'), 0.0),
            'range_pct': _finite(f.get('range_pct'), 0.0),
            'trend': _finite(f.get('return_24') or f.get('return_4') or f.get('trend'), 0.0),
            'data_completeness': _finite(f.get('data_completeness'), 0.0),
        }

    def _market_potential_pct(self, item: dict, horizon: str, direction: str) -> tuple[float, dict]:
        stats = self._recent_range_stats(horizon)
        ctx = self._context_from_item(item)
        expected = abs(_finite(item.get('expected_move_pct'), 0.0))
        conf = _finite(item.get('confidence'), 50.0)
        h = max(1, int(HORIZON_HOURS.get(horizon, 24)))
        # Vol/range context can expand or contract the historical range.  This
        # is what makes 1h sometimes choose $400 and sometimes $1000+ instead of
        # fixed scalp targets.
        vol_hint = max(ctx['range_pct'], ctx['volatility_24'] * math.sqrt(min(h,24)/24.0))
        hist_p = stats['p65_range_pct']
        if conf >= 70:
            hist_p = stats['p75_range_pct']
        if conf >= 80:
            hist_p = stats['p85_range_pct']
        # Directional conviction should not create unrealistic targets alone,
        # but if expected move is bigger than the median range, respect part of it.
        potential = max(hist_p, expected * 1.35, vol_hint * 1.15)
        # For weak confidence, keep the potential conservative.
        if conf < 55:
            potential *= 0.72
        elif conf < 62:
            potential *= 0.88
        # Horizon-specific sanity caps, still broad enough for real BTC moves.
        caps = {'1h':1.6,'4h':3.2,'8h':4.8,'24h':8.0,'7d':18.0,'30d':38.0,'90d':70.0}
        potential = _clamp(potential, 0.03, caps.get(str(horizon), 15.0))
        return potential, {'range_stats': stats, 'context': ctx, 'vol_hint_pct': round(vol_hint,6)}

    def _regime_bucket(self, ctx: dict, horizon: str) -> str:
        """Classify context into a small audit-friendly regime bucket.

        This is deliberately transparent: it is not a black-box claim. It gives
        the selector different behaviour in trend / range / high-vol / low-vol
        environments so NO_TRADE is not just a fixed fear threshold.
        """
        vol = abs(_finite(ctx.get('volatility_24'), 0.0))
        rng = abs(_finite(ctx.get('range_pct'), 0.0))
        trend = _finite(ctx.get('trend'), 0.0)
        regime_txt = str(ctx.get('regime') or '').lower()
        h = max(1, int(HORIZON_HOURS.get(str(horizon), 24)))
        trend_abs = abs(trend)
        vol_score = max(vol, rng)
        if any(k in regime_txt for k in ['crash','panic','extreme','capitulation']):
            return 'stress_high_vol'
        if vol_score >= (1.25 if h <= 4 else 2.2 if h <= 24 else 5.0):
            if trend_abs >= (0.35 if h <= 4 else 0.9 if h <= 24 else 2.5):
                return 'trend_high_vol'
            return 'range_high_vol'
        if trend_abs >= (0.22 if h <= 4 else 0.65 if h <= 24 else 1.8):
            return 'trend_normal'
        if vol_score <= (0.28 if h <= 4 else 0.75 if h <= 24 else 2.0):
            return 'range_low_vol'
        return 'range_normal'

    def _dynamic_policy(self, horizon: str, regime_bucket: str, confidence: float, sample: int) -> dict:
        """Return dynamic gates for the selector.

        DeepSeek correctly identified that simply raising NO_TRADE thresholds made
        the engine afraid but not profitable.  This policy gives each horizon and
        regime a different gate, and allows more trades in regimes where BTC has
        enough movement potential while still requiring positive EV.
        """
        h = str(horizon)
        # Base values are intentionally less paralysing than v10.16.79, because
        # quality is now driven by EV + realized potential + reason-specific gates.
        base_conf = {'1h':57,'4h':58,'8h':58,'24h':59,'7d':60,'30d':61,'90d':62}.get(h,59)
        base_quality = {'1h':58,'4h':59,'8h':60,'24h':61,'7d':62,'30d':63,'90d':64}.get(h,61)
        base_ev = {'1h':0.010,'4h':0.018,'8h':0.025,'24h':0.040,'7d':0.085,'30d':0.160,'90d':0.260}.get(h,0.04)
        base_potential = {'1h':0.28,'4h':0.55,'8h':0.78,'24h':1.15,'7d':2.5,'30d':5.5,'90d':9.0}.get(h,1.0)
        rr_target = {'1h':1.25,'4h':1.35,'8h':1.45,'24h':1.50,'7d':1.55,'30d':1.60,'90d':1.65}.get(h,1.5)
        # Regime adjustments: trend regimes can accept slightly lower confidence
        # if target/EV are good; choppy high-vol regimes demand better evidence.
        if regime_bucket in ('trend_high_vol','trend_normal'):
            base_conf -= 2
            base_quality -= 3
            base_ev *= 0.85
            rr_target += 0.10
        elif regime_bucket in ('range_high_vol','stress_high_vol'):
            base_conf += 2
            base_quality += 2
            base_ev *= 1.15
            rr_target += 0.15
        elif regime_bucket == 'range_low_vol':
            base_conf += 1
            base_potential *= 0.85
            rr_target -= 0.05
        # If historical range sample is thin, do not trust aggressive setups.
        if sample < 500:
            base_conf += 2
            base_quality += 3
            base_ev *= 1.2
        # Very high confidence should not automatically force a trade, but it
        # can relax the quality gate slightly if EV/RR pass.
        if confidence >= 72:
            base_quality -= 2
        if confidence >= 80:
            base_quality -= 3
        return {
            'min_conf': max(50.0, float(base_conf)),
            'min_quality': max(45.0, float(base_quality)),
            'min_ev': float(base_ev),
            'min_potential': float(base_potential),
            'rr_target': max(1.10, float(rr_target)),
        }

    def _no_trade_reason(self, *, conf: float, min_conf: float, ev_pct: float, min_ev: float, potential_pct: float, min_potential: float, rr: float, min_rr: float, quality: float, min_quality: float, move_abs: float, regime_bucket: str) -> str:
        reasons=[]
        if conf < min_conf:
            reasons.append('low_confidence')
        if ev_pct < min_ev:
            reasons.append('negative_or_weak_expected_value')
        if potential_pct < min_potential:
            reasons.append('insufficient_market_potential')
        if rr < min_rr:
            reasons.append('insufficient_risk_reward')
        if quality < min_quality:
            reasons.append('low_quality_score')
        if move_abs < 0.05:
            reasons.append('weak_directional_move')
        if regime_bucket in ('range_high_vol','stress_high_vol'):
            reasons.append('choppy_or_stress_regime_requires_extra_edge')
        return 'no_trade_' + '__'.join(reasons[:4] or ['edge_not_confirmed'])

    def select(self, item: dict, horizon: str | None = None, *, live: bool = False) -> dict:
        horizon = str(horizon or item.get('horizon') or '1h')
        entry = _finite(item.get('entry_price') or item.get('start_price') or item.get('current_price'), 0.0)
        if entry <= 0:
            return {**item, 'setup_action':'NO_TRADE', 'no_trade':True, 'setup_reason':'missing_entry_price'}

        move = _finite(item.get('expected_move_pct'), 0.0)
        conf = _finite(item.get('confidence'), 50.0)
        side = 'LONG' if move >= 0 else 'SHORT'
        potential_pct, meta = self._market_potential_pct(item, horizon, side)
        potential_usd = entry * potential_pct / 100.0
        ctx = meta.get('context') or self._context_from_item(item)
        regime_bucket = self._regime_bucket(ctx, horizon)
        sample = int(meta.get('range_stats',{}).get('samples') or 0)
        policy = self._dynamic_policy(horizon, regime_bucket, conf, sample)

        # Dynamic target selection.  No hardcoded $400/$1000 target: the dollar
        # move follows BTC price, realised historical range, volatility/regime,
        # and model conviction.  This can produce small targets in dead ranges
        # and much larger targets when the market has proven range potential.
        conviction = _clamp((conf - 50.0) / 35.0, 0.0, 1.0)
        move_abs = abs(move)
        raw_target_pct = max(
            potential_pct * (0.46 + 0.28 * conviction),
            move_abs * (1.05 + 0.30 * conviction),
        )
        # Estimate market noise/invalidation from recent volatility/range.  This
        # is not a fixed RR stop; it is a contextual invalidation distance.  If
        # the market cannot support enough target beyond normal noise, reject.
        noise_pct = max(
            0.055 if horizon == '1h' else 0.11 if horizon == '4h' else 0.16,
            _finite(ctx.get('range_pct'), 0.0) * 0.34,
            _finite(ctx.get('volatility_24'), 0.0) * (0.34 if HORIZON_HOURS.get(horizon,24) <= 4 else 0.48),
            (meta.get('range_stats') or {}).get('median_close_move_pct', 0.0) * 0.38,
        )
        desired_rr = policy['rr_target']
        # If target is too close relative to normal noise, try to expand target
        # up to realistic potential. If still impossible, NO_TRADE.
        target_pct = min(max(raw_target_pct, noise_pct * desired_rr), potential_pct * 0.94)
        stop_pct = max(noise_pct, target_pct / desired_rr)
        # When stop is forced wider than target/RR by noise, the real RR drops.
        if stop_pct > target_pct / max(self.MIN_RR, 1e-9):
            # Try once to expand target to maintain minimal RR.
            target_pct = min(max(target_pct, stop_pct * self.MIN_RR), potential_pct * 0.96)
        target_usd = entry * target_pct / 100.0
        stop_usd = entry * stop_pct / 100.0
        rr = target_usd / stop_usd if stop_usd > 0 else 0.0

        if side == 'LONG':
            target_price = entry + target_usd
            stop_price = entry - stop_usd
        else:
            target_price = entry - target_usd
            stop_price = entry + stop_usd

        # Honest EV using planned target/stop and confidence, but confidence is
        # penalised when the move is tiny or the regime is choppy.  This prevents
        # high hitrate / bad-RR scalp gaming.
        effective_conf = conf
        if regime_bucket in ('range_high_vol','stress_high_vol'):
            effective_conf -= 4.0
        if potential_pct < policy['min_potential']:
            effective_conf -= 3.0
        effective_conf = _clamp(effective_conf, 5.0, 92.0)
        ev_pct = (effective_conf/100.0)*target_pct - (1.0-effective_conf/100.0)*stop_pct

        # Quality is now an interpretable composite, not a magic strict number.
        quality = 50.0
        quality += (effective_conf - 50.0) * 0.95
        quality += min(10.0, math.log10(max(10, sample)) * 2.2)
        quality += min(13.0, (ev_pct / max(policy['min_ev'], 1e-9)) * 4.0) if ev_pct > 0 else ev_pct * 18.0
        quality += min(9.0, (rr - 1.0) * 7.0)
        quality += min(7.0, move_abs * 0.65)
        if regime_bucket in ('trend_high_vol','trend_normal'):
            quality += 4.0
        if regime_bucket in ('range_high_vol','stress_high_vol'):
            quality -= 4.0
        if potential_pct < policy['min_potential']:
            quality -= 8.0
        if rr < self.MIN_RR:
            quality -= 12.0

        action_ok = (
            rr >= self.MIN_RR and
            conf >= policy['min_conf'] and
            ev_pct >= policy['min_ev'] and
            potential_pct >= policy['min_potential'] and
            quality >= policy['min_quality']
        )
        action = side if action_ok else 'NO_TRADE'
        reason = 'dynamic_valid_ev_rr_regime_setup' if action_ok else self._no_trade_reason(
            conf=conf, min_conf=policy['min_conf'], ev_pct=ev_pct, min_ev=policy['min_ev'],
            potential_pct=potential_pct, min_potential=policy['min_potential'], rr=rr, min_rr=self.MIN_RR,
            quality=quality, min_quality=policy['min_quality'], move_abs=move_abs, regime_bucket=regime_bucket,
        )

        out = dict(item)
        out.update({
            'setup_engine_version':'v10.16.80_dynamic_regime_ev_selector',
            'setup_action': action,
            'trade_action': action,
            'no_trade': action == 'NO_TRADE',
            'setup_side_candidate': side,
            'setup_regime_bucket': regime_bucket,
            'setup_quality': round(quality,3),
            'setup_min_quality': policy['min_quality'],
            'market_potential_pct': round(potential_pct,6),
            'market_potential_usd': round(potential_usd,2),
            'setup_target_price': round(target_price,2),
            'setup_target_distance_pct': round(target_pct,6),
            'setup_target_distance_usd': round(target_usd,2),
            'setup_invalidation_price': round(stop_price,2),
            'setup_invalidation_distance_pct': round(stop_pct,6),
            'setup_invalidation_distance_usd': round(stop_usd,2),
            'setup_rr': round(rr or 0.0,4),
            'setup_rr_target_dynamic': round(desired_rr,4),
            'setup_expected_value_pct': round(ev_pct,6),
            'setup_effective_confidence': round(effective_conf,3),
            'setup_min_confidence': policy['min_conf'],
            'setup_min_expected_value_pct': policy['min_ev'],
            'setup_min_market_potential_pct': policy['min_potential'],
            'setup_reason': reason,
            'setup_context_json': {**meta, 'regime_bucket': regime_bucket, 'dynamic_policy': policy, 'noise_pct': round(noise_pct,6)},
        })
        if not live:
            self.evaluate_historical_setup(out)
        return out

    def evaluate_historical_setup(self, item: dict) -> dict:
        action = str(item.get('setup_action') or 'NO_TRADE')
        entry = _finite(item.get('start_price') or item.get('entry_price'), 0.0)
        high = _finite(item.get('actual_high'), entry)
        low = _finite(item.get('actual_low'), entry)
        actual = _finite(item.get('actual_price'), entry)
        if entry <= 0:
            item.update({'setup_outcome':'unscored_missing_entry'})
            return item
        side = item.get('setup_side_candidate') or ('LONG' if _finite(item.get('expected_move_pct'),0)>=0 else 'SHORT')
        target = _finite(item.get('setup_target_price'), entry)
        stop = _finite(item.get('setup_invalidation_price'), entry)
        if side == 'LONG':
            mfe = max(0.0, high-entry)
            mae = max(0.0, entry-low)
            target_hit = high >= target
            stop_hit = low <= stop
            exit_usd = actual-entry
        else:
            mfe = max(0.0, entry-low)
            mae = max(0.0, high-entry)
            target_hit = low <= target
            stop_hit = high >= stop
            exit_usd = entry-actual
        target_usd = abs(target-entry)
        stop_usd = abs(stop-entry)
        # Without tick sequence inside large horizons, both-hit is ambiguous.
        # Score it conservatively as invalidated to avoid training fake edge.
        valid_trade_existed = bool(target_hit and not stop_hit)
        no_trade_correct = None
        if action == 'NO_TRADE':
            no_trade_correct = not valid_trade_existed
            setup_outcome = 'no_trade_correct' if no_trade_correct else 'no_trade_missed_valid_trade'
            return_pct = 0.0
        else:
            if target_hit and not stop_hit:
                setup_outcome = 'target_hit_first_or_only'
                return_pct = target_usd/entry*100.0
            elif stop_hit:
                setup_outcome = 'stop_hit_or_ambiguous'
                return_pct = -stop_usd/entry*100.0
            else:
                setup_outcome = 'neither_hit_mark_to_horizon'
                return_pct = exit_usd/entry*100.0
        item.update({
            'setup_target_hit': bool(target_hit),
            'setup_stop_hit': bool(stop_hit),
            'setup_both_hit_ambiguous': bool(target_hit and stop_hit),
            'setup_mfe_usd': round(mfe,2),
            'setup_mae_usd': round(mae,2),
            'setup_mfe_pct': round(mfe/entry*100.0,6),
            'setup_mae_pct': round(mae/entry*100.0,6),
            'setup_return_pct': round(return_pct,6),
            'setup_valid_trade_existed': valid_trade_existed,
            'no_trade_correct': no_trade_correct,
            'setup_outcome': setup_outcome,
        })
        return item

    def select_many(self, items: list[dict]) -> list[dict]:
        return [self.select(i, str(i.get('horizon') or '1h'), live=False) for i in items]
