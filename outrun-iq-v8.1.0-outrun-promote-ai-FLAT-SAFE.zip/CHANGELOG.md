# Outrun IQ v8.1.0 — Outrun Promote AI

Gebouwd bovenop v8.0.1 Buyer Home v2.

## Nieuw
- Outrun Promote AI-campagnebuilder: partners kiezen doel/budget/producten, AI maakt campagnevarianten.
- Promotion creatives met 5 varianten per campagne: titel, subtitel, CTA, badge, stijl, predicted CTR en confidence.
- Home bovenkant omgebouwd naar AI Discovery Carousel: afwisseling tussen productfoto’s, AI-selecties, collecties en subtiele promoted campagnes.
- Promoted zichtbaarheid wordt impressie-/relevantiegedreven voorbereid, niet één bedrijf de hele dag bovenaan.
- Partner Promoten-tab uitgebreid met hero, workflow-uitleg, creative preview en variant-overzicht.
- OpenAI wordt gebruikt voor premium campagnecopy; rules fallback blijft veilig als API niet beschikbaar is.
- DeepSeek/rules blijven leidend voor ranking/relevantie/promotieboost.

## Belangrijk
- AI Vinder CTA onderaan Home blijft behouden.
- Home blijft rustig: geen extra zoekbalk en geen losse welkomstkaart bovenaan.
- Promotie is subtiel: budget telt mee, relevantie/dealkwaliteit blijven leidend.
