# Outrun IQ v8.1.0 — Outrun Promote AI

Deze versie bouwt het eerste echte Outrun Promote AI-fundament in.

## Inbegrepen
- AI Discovery Carousel op Home.
- Partner Promote-tab met AI-campagnebuilder.
- AI-campagnevarianten met predicted CTR/confidence.
- Campaign creatives opgeslagen in `promotionCampaigns`.
- Subtiele promoted kaarten voorbereid voor Home, categorieën, zoeken en AI Vinder.
- Service worker cache: `oiq-v8-1-0`.

## Deploy
Gebruik de meegegeven Termius-regel in de chat. `.env`, `data/`, `runtime_uploads/`, `public/uploads/`, `node_modules/` en `.next/` worden niet overschreven.
