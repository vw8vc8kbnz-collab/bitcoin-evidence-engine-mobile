import { read, mutate } from "@/lib/store";
import type { AiDecision, Listing, PromotionCampaign, PromotionCreative, Seller, User } from "@/lib/types";
import { aiJson, providerPlan } from "./router";

const DAY = 864e5;
const clamp = (n: number, a = 0, b = 100) => Math.max(a, Math.min(b, n));
const discount = (l: Listing) => l.newPrice > 0 ? clamp((1 - l.price / l.newPrice) * 100) : 0;
const ageDays = (iso: string) => Math.max(0, (Date.now() - +new Date(iso)) / DAY);

function freshness(l: Listing) { return clamp(100 - ageDays(l.createdAt) * 8); }
function stockPressure(l: Listing) { return l.stock <= 1 ? 100 : l.stock <= 3 ? 72 : l.stock <= 8 ? 38 : 15; }
function sellerTrust(l: Listing, sellers: Seller[]) { return sellers.find(s => s.slug === l.sellerSlug)?.trusted ? 94 : 68; }


export type DiscoveryCard = {
  id: string;
  kind: "campaign" | "collection" | "product" | "deal";
  title: string;
  subtitle: string;
  badge?: string;
  cta: string;
  href: string;
  style: "premium_dark" | "clean_light" | "product_grid" | "collection" | "urgent";
  image?: string;
  fallback?: Listing["fallback"];
  productImages?: { src?: string; fallback: Listing["fallback"] }[];
  price?: number;
  discount?: number;
  sellerName?: string;
  promoted?: boolean;
  reason?: string;
};

const creativeStyles: PromotionCreative["style"][] = ["premium_dark", "collection", "product_grid", "clean_light", "urgent"];

function fallbackCreatives(input: { seller?: Seller; listings: Listing[]; objective: PromotionCampaign["objective"]; name: string }): PromotionCreative[] {
  const sellerName = input.seller?.name ?? "Outrun Partner";
  const cats = Array.from(new Set(input.listings.map(l => l.category))).slice(0, 2).join(" & ");
  const bestDiscount = Math.max(0, ...input.listings.map(l => Math.round((1 - l.price / l.newPrice) * 100)));
  const count = input.listings.length;
  const base = [
    {
      title: input.name || `${sellerName} Outlet Selectie`,
      subtitle: `${count || "Nieuwe"} gecontroleerde deals${bestDiscount ? ` tot ${bestDiscount}% korting` : ""}.`,
      cta: "Bekijk collectie",
      style: "premium_dark" as const,
      badge: "Partner Spotlight",
      predictedCtr: 3.8,
      confidence: 76,
      reason: "Premium donkere campagnekaart met duidelijke partnerbelofte.",
    },
    {
      title: `${sellerName} vandaag uitgelicht`,
      subtitle: cats ? `Nieuwe voorraad in ${cats}.` : "Nieuwe outletvoorraad van een geverifieerde partner.",
      cta: "Naar store",
      style: "collection" as const,
      badge: "Outrun Promote",
      predictedCtr: 3.2,
      confidence: 72,
      reason: "Collectievariant focust op partner en aanbodbreedte.",
    },
    {
      title: input.listings[0]?.title ? `${input.listings[0].title}` : "Laatste stuks beschikbaar",
      subtitle: input.listings[0] ? `${sellerName} · ${input.listings[0].condition} · ${input.listings[0].pickupCity}` : "Schaarse voorraad die snel weg kan zijn.",
      cta: "Bekijk deal",
      style: "product_grid" as const,
      badge: "AI Selectie",
      predictedCtr: 4.1,
      confidence: 70,
      reason: "Productgerichte variant voor kopers die direct op dealniveau klikken.",
    },
    {
      title: `Nieuw binnen bij ${sellerName}`,
      subtitle: `${count || 1} deals uit gecontroleerde voorraad.`,
      cta: "Bekijk nieuw",
      style: "clean_light" as const,
      badge: "Nieuw",
      predictedCtr: 2.9,
      confidence: 68,
      reason: "Rustige variant voor minder advertentiegevoel.",
    },
    {
      title: bestDiscount ? `Tot ${bestDiscount}% goedkoper` : "Sneller verkopen",
      subtitle: `AI toont deze campagne alleen waar hij relevant is.`,
      cta: "Ontdek deals",
      style: "urgent" as const,
      badge: "Slimme boost",
      predictedCtr: 3.5,
      confidence: 74,
      reason: "Urgentievariant voor beperkte voorraad en korting.",
    },
  ];
  return base.map((x, i) => ({ id: `v${i + 1}`, ...x }));
}

export async function generatePromotionCreatives(input: { seller?: Seller; listings: Listing[]; objective: PromotionCampaign["objective"]; name: string; kind: PromotionCampaign["kind"] }): Promise<{ variants: PromotionCreative[]; provider: string }> {
  const system = `Je bent Outrun Promote AI. Maak exact 5 premium campagnevarianten voor een subtiele homepage/discovery campagne. Geef uitsluitend JSON: {"variants":[{"title":"","subtitle":"","cta":"","style":"premium_dark|clean_light|product_grid|collection|urgent","badge":"","predictedCtr":0,"confidence":0,"reason":""}]}. Geen schreeuwerige advertenties, geen misleiding, geen claims zonder basis. Nederlands. Max titel 42 tekens, subtitle 90 tekens.`;
  const res = await aiJson<{ variants: Omit<PromotionCreative, "id">[] }>({
    task: "copy",
    provider: "openai",
    system,
    user: {
      partner: input.seller?.name,
      type: input.kind,
      campagneNaam: input.name,
      doel: input.objective,
      producten: input.listings.slice(0, 8).map(l => ({ titel: l.title, categorie: l.category, prijs: l.price, nieuwprijs: l.newPrice, conditie: l.condition, voorraad: l.stock, plaats: l.pickupCity })),
    },
    temperature: 0.45,
    timeoutMs: 14_000,
  });
  if (res.ok && res.data?.variants?.length) {
    const variants = res.data.variants.slice(0, 5).map((v, i) => ({
      id: `v${i + 1}`,
      title: String(v.title || input.name || "Outrun Promote").slice(0, 52),
      subtitle: String(v.subtitle || "Geselecteerd door Outrun AI.").slice(0, 110),
      cta: String(v.cta || "Bekijk collectie").slice(0, 30),
      style: creativeStyles.includes(v.style as PromotionCreative["style"]) ? v.style as PromotionCreative["style"] : "premium_dark",
      badge: v.badge ? String(v.badge).slice(0, 28) : "Outrun Promote",
      predictedCtr: Math.max(1, Math.min(12, Number(v.predictedCtr) || 3.5)),
      confidence: Math.max(50, Math.min(96, Math.round(Number(v.confidence) || 74))),
      reason: String(v.reason || "AI-campagnevariant voor subtiele zichtbaarheid.").slice(0, 160),
    }));
    return { variants, provider: res.provider };
  }
  return { variants: fallbackCreatives(input), provider: "rules" };
}

function sellerListings(sellerSlug: string, listings: Listing[], campaign: PromotionCampaign) {
  if (campaign.kind === "listing") return listings.filter(l => l.id === campaign.listingId);
  if (campaign.kind === "category") return listings.filter(l => l.sellerSlug === sellerSlug && l.category === campaign.category).slice(0, 6);
  return listings.filter(l => l.sellerSlug === sellerSlug).slice(0, 6);
}

function campaignToCard(c: PromotionCampaign, listings: Listing[], sellers: Seller[]): DiscoveryCard | null {
  const seller = sellers.find(s => s.slug === c.sellerSlug);
  const related = sellerListings(c.sellerSlug, listings, c);
  if (!seller || related.length === 0) return null;
  const variant = c.creativeVariants?.find(v => v.id === c.selectedVariantId) ?? c.creativeVariants?.[0] ?? fallbackCreatives({ seller, listings: related, objective: c.objective, name: c.name })[0];
  const primary = related[0];
  const bestDiscount = Math.max(0, ...related.map(l => Math.round((1 - l.price / l.newPrice) * 100)));
  return {
    id: `campaign-${c.id}`,
    kind: "campaign",
    title: variant.title,
    subtitle: variant.subtitle,
    badge: variant.badge ?? "Partner Spotlight",
    cta: variant.cta || "Bekijk collectie",
    href: c.kind === "listing" && c.listingId ? `/listing/${c.listingId}` : `/store/${seller.slug}`,
    style: variant.style,
    image: seller.banner || primary.photos[0],
    fallback: primary.fallback,
    productImages: related.slice(0, 4).map(l => ({ src: l.photos[0], fallback: l.fallback })),
    sellerName: seller.name,
    promoted: true,
    discount: bestDiscount,
    reason: variant.reason,
  };
}

export function dealQualityScore(l: Listing, sellers: Seller[]) {
  const d = discount(l);
  const score =
    d * 0.28 +
    clamp(l.confidence) * 0.22 +
    clamp(l.conditionScore * 10) * 0.18 +
    sellerTrust(l, sellers) * 0.14 +
    freshness(l) * 0.10 +
    stockPressure(l) * 0.08;
  return Math.round(clamp(score));
}

export function promotionBoost(l: Listing, campaigns: PromotionCampaign[]) {
  const now = Date.now();
  const active = campaigns.filter(c => c.status === "active" && +new Date(c.startsAt) <= now && (!c.endsAt || +new Date(c.endsAt) >= now));
  const hits = active.filter(c =>
    c.sellerSlug === l.sellerSlug && (
      c.kind === "seller" ||
      (c.kind === "listing" && c.listingId === l.id) ||
      (c.kind === "category" && c.category === l.category)
    )
  );
  if (!hits.length) return { boost: 0, campaignIds: [] as string[] };
  // Promotie is een subtiele factor, nooit een garantie op plek 1.
  const budget = hits.reduce((a, c) => a + Math.min(25, Math.max(0, c.budgetDaily)), 0);
  return { boost: Math.min(14, 5 + budget * 0.35), campaignIds: hits.map(h => h.id) };
}

function preferenceScore(l: Listing, prefCats: Set<string>, savedIds: Set<string>) {
  let s = 0;
  if (prefCats.has(l.category)) s += 28;
  if (savedIds.has(l.id)) s += 10;
  if (l.stock <= 1) s += 5;
  return s;
}

function diversify(list: Listing[], maxPerSeller = 2) {
  const seen = new Map<string, number>();
  const out: Listing[] = [];
  for (const l of list) {
    const n = seen.get(l.sellerSlug) ?? 0;
    if (n >= maxPerSeller) continue;
    out.push(l); seen.set(l.sellerSlug, n + 1);
  }
  return out.length >= Math.min(4, list.length) ? out : list;
}

export async function logAiDecision(input: Omit<AiDecision, "id" | "at">) {
  return mutate(db => {
    db.aiDecisions ??= [];
    db.aiDecisions.push({ id: Math.random().toString(36).slice(2, 10), at: new Date().toISOString(), ...input });
    if (db.aiDecisions.length > 3000) db.aiDecisions.splice(0, db.aiDecisions.length - 3000);
  });
}

export async function buildHomeBrain(user?: User | null) {
  const db = await read();
  const listings = db.listings.filter(l => l.status === "active" && l.stock > 0);
  const sellers = db.sellers;
  const campaigns = db.promotionCampaigns ?? [];
  const saved = user ? db.saved.filter(s => s.userId === user.id) : [];
  const orders = user ? db.orders.filter(o => o.buyerId === user.id) : [];
  const savedIds = new Set(saved.map(s => s.listingId));
  const prefCats = new Set<string>();
  for (const s of saved) { const l = listings.find(x => x.id === s.listingId); if (l) prefCats.add(l.category); }
  for (const o of orders) { const l = listings.find(x => x.id === o.listingId); if (l) prefCats.add(l.category); }

  const ranked = listings.map(l => {
    const dq = dealQualityScore(l, sellers);
    const promo = promotionBoost(l, campaigns);
    const personal = preferenceScore(l, prefCats, savedIds);
    const score = dq * 0.48 + personal * 0.24 + freshness(l) * 0.10 + stockPressure(l) * 0.07 + promo.boost + Math.random() * 1.5;
    return { l, score, dq, personal, promo };
  }).sort((a, b) => b.score - a.score);

  const aiPicks = diversify(ranked.map(x => x.l), 2).slice(0, 8);
  const hero = aiPicks.slice(0, 5);
  const newListings = [...listings].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 10);
  const lastChance = ranked.filter(x => x.l.stock <= 2).map(x => x.l).slice(0, 8);
  const trending = [...ranked].sort((a, b) => (b.l.views + b.dq) - (a.l.views + a.dq)).map(x => x.l).slice(0, 8);
  const dealOfDay = [...ranked].sort((a, b) => b.dq - a.dq)[0]?.l;
  const promoted = ranked.filter(x => x.promo.boost > 0).slice(0, 6);
  const partnerSpotlight = promoted[0]?.l ?? null;
  const now = Date.now();
  const activeCampaigns = campaigns
    .filter(c => c.status === "active" && +new Date(c.startsAt) <= now && (!c.endsAt || +new Date(c.endsAt) >= now))
    .sort((a, b) => (b.budgetDaily + b.clicks * 0.4 + b.impressions * 0.002) - (a.budgetDaily + a.clicks * 0.4 + a.impressions * 0.002));
  const campaignCards = activeCampaigns.map(c => campaignToCard(c, listings, sellers)).filter((x): x is DiscoveryCard => Boolean(x)).slice(0, 4);
  const collectionCards: DiscoveryCard[] = [
    { id: "collection-ai", kind: "collection", title: "Beste prijsbewijs", subtitle: "Deals met sterke korting én hoge AI-score.", badge: "AI Collectie", cta: "Bekijk collectie", href: "/zoeken?sort=score", style: "collection" },
    { id: "collection-under250", kind: "collection", title: "Onder €250", subtitle: "Lage instap, gecontroleerde voorraad.", badge: "Collectie", cta: "Bekijk deals", href: "/zoeken?max=250", style: "clean_light" },
    { id: "collection-last", kind: "collection", title: "Laatste stuks", subtitle: "Voorraad die snel weg kan zijn.", badge: "Schaarste", cta: "Bekijk laatste", href: "/zoeken?q=laatste", style: "urgent" },
  ];
  const discoveryCards: DiscoveryCard[] = [
    ...campaignCards.slice(0, 1),
    ...hero.slice(0, 1).map(l => ({ id: `hero-${l.id}`, kind: "product" as const, title: l.title, subtitle: `AI gekozen · Deal Score ${dealQualityScore(l, sellers)}/100 · ${l.pickupCity}`, badge: "Voor jou", cta: "Bekijk deal", href: `/listing/${l.id}`, style: "premium_dark" as const, image: l.photos[0], fallback: l.fallback, price: l.price, discount: Math.round((1 - l.price / l.newPrice) * 100), sellerName: sellers.find(s => s.slug === l.sellerSlug)?.name })),
    ...campaignCards.slice(1, 3),
    ...collectionCards.slice(0, 2),
  ].slice(0, 6);

  void logAiDecision({
    agent: "home_builder",
    provider: "hybrid",
    userId: user?.id,
    role: user?.role,
    context: "home-render",
    subjectType: "home",
    confidence: listings.length ? 86 : 40,
    reason: `Home samengesteld uit ${listings.length} live producten met rules + promotieboost.`,
    features: { liveListings: listings.length, aiPicks: aiPicks.length, promoted: promoted.length, campaignCards: campaignCards.length, discoveryCards: discoveryCards.length, prefCats: prefCats.size },
  }).catch(() => undefined);

  return { hero, aiPicks, newListings, lastChance, trending, dealOfDay, partnerSpotlight, promoted: promoted.map(x => x.l), discoveryCards, prefCats };
}

export function aiProviderMatrix() {
  return ["vinder", "copy", "partner_coach", "deal_quality", "ranking", "home_builder", "promotion", "inventory"].map(task => ({
    task,
    plan: providerPlan(task as Parameters<typeof providerPlan>[0]),
  }));
}

export async function promotionAdvice(input: { listing: Listing; seller: Seller | undefined }) {
  const system = `Je bent Outrun Promotion AI. Geef uitsluitend JSON: {"promote":true,"budgetDaily":0,"confidence":0,"reason":"","expectedViews":0,"objective":""}. Wees conservatief. Promotie mag nooit irritant zijn; alleen zinvol als product extra zichtbaarheid nodig heeft.`;
  const res = await aiJson<{ promote: boolean; budgetDaily: number; confidence: number; reason: string; expectedViews: number; objective: string }>({
    task: "promotion",
    system,
    user: { titel: input.listing.title, categorie: input.listing.category, prijs: input.listing.price, nieuwprijs: input.listing.newPrice, views: input.listing.views, voorraad: input.listing.stock, conditie: input.listing.conditionScore, partner: input.seller?.name },
    temperature: 0.1,
    timeoutMs: 12_000,
  });
  if (res.ok && res.data) return { ...res.data, provider: res.provider };
  const dq = dealQualityScore(input.listing, input.seller ? [input.seller] : []);
  return { promote: input.listing.views < 20 && input.listing.stock > 0, budgetDaily: dq > 78 ? 5 : 8, confidence: 68, reason: "Rules-advies: weinig views en voldoende voorraad.", expectedViews: 180, objective: "Meer relevante bezoekers", provider: "rules" };
}
