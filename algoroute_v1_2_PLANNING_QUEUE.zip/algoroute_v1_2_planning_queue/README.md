# AlgoRoute v1.2 Planning Queue Engine

Nieuw:
- Planning Queue als echte businesslaag tussen Import Studio en Optimizer.
- Orders met leverdatum, tijdvenster, lostijd, prioriteit, pallets/rolcontainers en gewicht.
- Filters op leverdag en status.
- Order detailpaneel met readiness checks.
- Capacity pre-check voor beschikbare vloot.
- Import commit stuurt orders richting Planning Queue endpoint.

Nog niet:
- Nog geen persistente database.
- Nog geen echte optimizer/OSRM.
- Nog geen drag/drop batch assignment.
