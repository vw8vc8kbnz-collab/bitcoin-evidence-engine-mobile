# AlgoRoute v1.2 update

Upload `algoroute_v1_2_PLANNING_QUEUE.zip` naar GitHub en gebruik het updateblok uit ChatGPT.
