#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "== Bitcoin Evidence Engine Oracle bootstrap =="
sudo apt-get update
sudo apt-get install -y python3 python3-venv python3-pip build-essential g++ git curl unzip nginx
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
./build_native_core_linux.sh
mkdir -p "$HOME/bitcoin_evidence_data" logs
echo "OK. Test starten met: . .venv/bin/activate && bash start_oracle.sh"
