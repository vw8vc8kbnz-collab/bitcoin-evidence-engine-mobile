#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVICE=/etc/systemd/system/bitcoin-evidence-engine.service
TOKEN="${BEE_ACCESS_TOKEN:-}"
if [ -z "$TOKEN" ]; then
  TOKEN="$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(24))
PY
)"
fi
cat > .env.oracle <<EOF
BEE_CLOUD_MODE=1
BEE_FORCE_MOBILE=1
BEE_HOST=0.0.0.0
PORT=8787
BEE_DATA_DIR=$HOME/bitcoin_evidence_data
BEE_ACCESS_TOKEN=$TOKEN
EOF
sudo tee "$SERVICE" >/dev/null <<EOF
[Unit]
Description=Bitcoin Evidence Engine Cloud Mobile
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env.oracle
ExecStart=$APP_DIR/.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8787 --proxy-headers
Restart=always
RestartSec=5
User=$USER

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable bitcoin-evidence-engine
sudo systemctl restart bitcoin-evidence-engine
echo "Service geïnstalleerd en gestart."
echo "Jouw mobile access token:"
echo "$TOKEN"
echo "Bewaar deze token. Op je iPhone vul je hem één keer in."
