RoomBudget v1.0.9 Dev Assets + Prompt

- Dev mode: /dev/assets
- Customer prompt on upload
- Visual assets editable without new build
- AI remains mock by default and cost-safe
