from __future__ import annotations

import json
import uuid
import pandas as pd
from datetime import datetime, timezone
from typing import Any

from app.db.database import db
from app.core.debug import append_jsonl, write_json
from app.core.logger import log


FEATURE_FIELDS = [
    "rsi_14", "return_4", "return_24", "ma_50", "ma_200", "close", "volatility_24",
    "volume_zscore", "volume_ratio_24", "range_pct", "candle_body_pct", "drawdown_from_ath",
    "cycle_progress", "fear_greed", "funding_rate", "open_interest_value", "open_interest_change_24h",
    "long_short_ratio", "taker_buy_sell_ratio", "orderbook_imbalance", "taker_delta_ratio",
    "futures_basis_premium_pct", "top_position_long_short_ratio", "top_account_long_short_ratio",
    "cross_exchange_spread_pct", "spot_premium_kraken_pct", "spot_premium_coinbase_pct",
    "coinmetrics_mvrv", "realized_cap_usd", "market_cap_usd", "regime", "data_completeness",
]


def _finite_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        x = float(value)
        if x != x or x in (float("inf"), float("-inf")):
            return None
        return x
    except Exception:
        return None


def _bucket(name: str, value: Any, cuts: list[tuple[float, str]], default: str = "unknown") -> tuple[str, str]:
    v = _finite_float(value)
    if v is None:
        return f"{name}:unknown", f"{name} unknown"
    for cut, label in cuts:
        if v <= cut:
            return f"{name}:{label}", f"{name} {label}"
    return f"{name}:{default}", f"{name} {default}"


class TimeMachineLearningService:
    """Durable learning warehouse for Time Machine outcomes.

    V10.5 goal:
    - every manual click and Random 100/1000 item stores the market context at the cutoff;
    - every signal/feature bucket gets win/partial/fail statistics by horizon and regime;
    - this layer is append/upsert based and must never break the Time Machine UI.
    """

    def feature_tuple_to_dict(self, feature_tuple) -> dict[str, Any]:
        if feature_tuple is None:
            return {}
        values = list(feature_tuple)
        data: dict[str, Any] = {}
        for i, name in enumerate(FEATURE_FIELDS):
            data[name] = values[i] if i < len(values) else None
        return self._clean_dict(data)

    def feature_snapshots_for_cutoffs(self, cutoff_ms_values: list[int], *, rebuild_if_empty: bool = False) -> dict[int, dict[str, Any]]:
        """Return the best known feature row at or before each cutoff.

        This is the missing V10.11 bridge: native C++ returns fast price-action
        outcomes, Python enriches those outcomes in one vectorized pass with the
        evidence warehouse (regime, RSI, funding, OI, long/short, sentiment, etc.).
        No per-horizon provider calls and no live-data leakage: only feature rows
        with timestamp_ms <= cutoff_ms are joined.
        """
        cutoffs = sorted({int(x) for x in (cutoff_ms_values or []) if x})
        if not cutoffs:
            return {}
        min_ms, max_ms = min(cutoffs), max(cutoffs)
        select_cols = ", ".join(["timestamp_ms"] + FEATURE_FIELDS + ["state_json"])
        def load_features():
            return db.df(f"""
                SELECT {select_cols}
                FROM features
                WHERE interval='1h' AND timestamp_ms <= ? AND timestamp_ms >= ?
                ORDER BY timestamp_ms ASC
            """, [max_ms, max(0, min_ms - 14*86400000)])
        feat = load_features()
        if feat.empty and rebuild_if_empty:
            try:
                from app.engine.feature_engine import FeatureEngine
                rebuilt = FeatureEngine().rebuild()
                append_jsonl("time_machine_learning_audit.jsonl", {"event":"feature_rebuild_for_learning", "rebuilt":rebuilt, "cutoffs":len(cutoffs)})
                feat = load_features()
            except Exception as exc:
                append_jsonl("time_machine_learning_audit.jsonl", {"event":"feature_rebuild_for_learning_failed", "error":str(exc)})
        if feat.empty:
            append_jsonl("time_machine_learning_audit.jsonl", {"event":"feature_lookup_empty_no_rebuild", "cutoffs":len(cutoffs), "min_ms":min_ms, "max_ms":max_ms, "rebuild_if_empty":bool(rebuild_if_empty)})
            fallback = self._fallback_feature_snapshots_from_candles(cutoffs)
            if fallback:
                append_jsonl("time_machine_learning_audit.jsonl", {"event":"feature_lookup_empty_used_ohlc_fallback_v10143", "fallback":len(fallback)})
            return fallback
        req = pd.DataFrame({"cutoff_ms": cutoffs}).sort_values("cutoff_ms")
        feat = feat.sort_values("timestamp_ms")
        merged = pd.merge_asof(req, feat, left_on="cutoff_ms", right_on="timestamp_ms", direction="backward", tolerance=14*86400000)
        out: dict[int, dict[str, Any]] = {}
        for _, row in merged.iterrows():
            cutoff = int(row.get("cutoff_ms"))
            if pd.isna(row.get("timestamp_ms")):
                continue
            d: dict[str, Any] = {}
            for name in FEATURE_FIELDS:
                d[name] = row.get(name)
            d["feature_timestamp_ms"] = int(row.get("timestamp_ms"))
            d["feature_lag_ms"] = int(cutoff - int(row.get("timestamp_ms")))
            sj = row.get("state_json")
            if isinstance(sj, str) and sj:
                try:
                    d["state_json"] = json.loads(sj)
                except Exception:
                    d["state_json"] = sj
            out[cutoff] = self._clean_dict(d)
        append_jsonl("time_machine_learning_audit.jsonl", {"event":"feature_lookup_bulk", "cutoffs":len(cutoffs), "matched":len(out), "feature_rows":len(feat)})
        if len(out) < len(cutoffs):
            fallback = self._fallback_feature_snapshots_from_candles([c for c in cutoffs if c not in out])
            out.update(fallback)
            if fallback:
                append_jsonl("time_machine_learning_audit.jsonl", {"event":"feature_lookup_ohlc_fallback_v10143", "requested":len(cutoffs), "fallback":len(fallback), "matched_total":len(out)})
        return out

    def _fallback_feature_snapshots_from_candles(self, cutoff_ms_values: list[int]) -> dict[int, dict[str, Any]]:
        """Build honest OHLC-only snapshots when the feature table has not caught up yet.

        This is not fake external data. It uses only candles available at/before
        the cutoff and leaves provider fields unknown/neutral. It prevents the
        Learning Warehouse from recording `{}` snapshots while the 8Y feature
        warehouse is still being rebuilt in the background.
        """
        cutoffs = sorted({int(x) for x in (cutoff_ms_values or []) if x})
        if not cutoffs:
            return {}
        min_ms, max_ms = min(cutoffs), max(cutoffs)
        try:
            candles = db.df("""
                SELECT open_time AS timestamp_ms, close, high, low, volume
                FROM raw_candles
                WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h'
                  AND open_time >= ? AND open_time <= ?
                ORDER BY open_time ASC
            """, [max(0, min_ms - 260*86400000), max_ms])
        except Exception as exc:
            append_jsonl("time_machine_learning_audit.jsonl", {"event":"feature_ohlc_fallback_failed_v10143", "error":str(exc)})
            return {}
        if candles is None or candles.empty:
            return {}
        try:
            candles = candles.sort_values("timestamp_ms").copy()
            close = candles["close"].astype(float)
            delta = close.diff()
            gain = delta.clip(lower=0).rolling(14).mean()
            loss = (-delta.clip(upper=0)).rolling(14).mean()
            rs = gain / loss.replace(0, float('nan'))
            candles["rsi_14"] = 100 - (100 / (1 + rs))
            candles["return_4"] = close.pct_change(4) * 100
            candles["return_24"] = close.pct_change(24) * 100
            candles["ma_50"] = close.rolling(50).mean()
            candles["ma_200"] = close.rolling(200).mean()
            candles["volatility_24"] = candles["return_24"].rolling(24).std()
            vol = candles["volume"].astype(float)
            candles["volume_zscore"] = (vol - vol.rolling(48).mean()) / vol.rolling(48).std().replace(0, float('nan'))
            candles["range_pct"] = ((candles["high"].astype(float) - candles["low"].astype(float)) / close) * 100
            candles["drawdown_from_ath"] = (close / close.cummax() - 1) * 100
        except Exception as exc:
            append_jsonl("time_machine_learning_audit.jsonl", {"event":"feature_ohlc_calc_failed_v10143", "error":str(exc)})
        req = pd.DataFrame({"cutoff_ms": cutoffs}).sort_values("cutoff_ms")
        merged = pd.merge_asof(req, candles.sort_values("timestamp_ms"), left_on="cutoff_ms", right_on="timestamp_ms", direction="backward", tolerance=14*86400000)
        out: dict[int, dict[str, Any]] = {}
        for _, row in merged.iterrows():
            if pd.isna(row.get("timestamp_ms")):
                continue
            cutoff = int(row.get("cutoff_ms"))
            close_v = _finite_float(row.get("close"))
            ma50 = _finite_float(row.get("ma_50"))
            ma200 = _finite_float(row.get("ma_200"))
            dd = _finite_float(row.get("drawdown_from_ath")) or 0.0
            if close_v and ma50 and ma200 and close_v > ma50 > ma200 and dd > -20:
                regime = "bull_trend"
            elif close_v and ma50 and ma200 and close_v < ma50 < ma200 and dd < -35:
                regime = "bear_trend"
            elif dd < -55:
                regime = "capitulation"
            else:
                regime = "transition"
            d = {name: None for name in FEATURE_FIELDS}
            for name in ["rsi_14","return_4","return_24","ma_50","ma_200","close","volatility_24","volume_zscore","range_pct","drawdown_from_ath"]:
                d[name] = _finite_float(row.get(name))
            d["regime"] = regime
            d["data_completeness"] = 35.0
            d["feature_timestamp_ms"] = int(row.get("timestamp_ms"))
            d["feature_lag_ms"] = int(cutoff - int(row.get("timestamp_ms")))
            d["feature_source"] = "ohlc_fallback_v10143"
            out[cutoff] = self._clean_dict(d)
        return out

    def record_items(
        self,
        *,
        batch_id: str,
        source: str,
        items: list[dict],
        feature_by_cutoff: dict[int, dict] | None = None,
    ) -> None:
        """Persist Time Machine outcomes as a real learning warehouse.

        V10.11 changes the important part: native C++ is fast, but previous
        builds stored learning one signal at a time. Random 100 produced ~10k
        signal updates and Python/DuckDB became the bottleneck. This method now:
        1) enriches native items with feature snapshots in one bulk lookup;
        2) inserts snapshots in one batch;
        3) aggregates all signal deltas in memory;
        4) writes only one upsert per signal/horizon/regime bucket.
        """
        if not items:
            return
        feature_by_cutoff = feature_by_cutoff or {}
        # Native C++ results intentionally contain price-action outcomes only.
        # Enrich them here with the feature/evidence context at the cutoff.
        try:
            missing_cutoffs = [int(i.get("cutoff_ms") or 0) for i in items if i.get("actual_price") is not None and not (i.get("feature_snapshot") or feature_by_cutoff.get(int(i.get("cutoff_ms") or 0)))]
            if missing_cutoffs:
                feature_by_cutoff.update(self.feature_snapshots_for_cutoffs(missing_cutoffs))
        except Exception as exc:
            append_jsonl("time_machine_learning_audit.jsonl", {"event":"feature_enrichment_failed", "batch_id":batch_id, "error":str(exc)})

        now = datetime.now(timezone.utc)
        snapshot_rows = []
        signal_agg: dict[tuple[str, str, str], dict[str, Any]] = {}
        model_agg: dict[tuple[str, str], dict[str, Any]] = {}
        signal_events = 0
        try:
            for item in items:
                if item.get("actual_price") is None:
                    continue
                cutoff_ms = int(item.get("cutoff_ms") or 0)
                feature = self._clean_dict(item.get("feature_snapshot") or feature_by_cutoff.get(cutoff_ms) or {})
                horizon = str(item.get("horizon") or "unknown")
                regime = str(feature.get("regime") or "unknown")
                cutoff_iso = item.get("cutoff_iso") or (datetime.fromtimestamp(cutoff_ms / 1000, tz=timezone.utc).isoformat() if cutoff_ms else None)
                model_context = {"contributions": item.get("contributions") or item.get("model_contributions") or [], "native_mode": item.get("native_mode") or item.get("mode")}
                price_context = self._price_context(item)
                provider_context = self._provider_context(feature)
                snapshot_rows.append([
                    str(uuid.uuid4()), batch_id, source, now, cutoff_ms, cutoff_iso, horizon,
                    _finite_float(item.get("start_price")), regime, _finite_float(feature.get("data_completeness")),
                    json.dumps(feature, default=str), json.dumps(price_context, default=str), json.dumps(provider_context, default=str), json.dumps(model_context, default=str),
                    item.get("outcome_tier") or ("win" if item.get("target_reached") else "partial" if item.get("partial_reached") else "fail"),
                    bool(item.get("target_reached")), bool(item.get("partial_reached")), bool(item.get("invalidated")),
                    bool(item.get("direction_correct")), _finite_float(item.get("total_score")),
                    _finite_float(item.get("target_gap_pct")), _finite_float(item.get("price_error_pct")),
                ])
                for sig in self._signals_for_item(item, feature):
                    key = (sig["key"], horizon, regime)
                    rec = signal_agg.setdefault(key, {
                        "signal_key": sig["key"], "signal_label": sig.get("label"), "signal_type": sig.get("type"),
                        "horizon": horizon, "regime": regime, "total": 0, "wins": 0, "partials": 0, "fails": 0,
                        "score_sum": 0.0, "gap_sum": 0.0,
                    })
                    win = bool(item.get("target_reached"))
                    partial = bool(item.get("partial_reached")) or (not win and _finite_float(item.get("total_score")) is not None and float(item.get("total_score") or 0) >= 55.0)
                    rec["total"] += 1
                    rec["wins"] += int(win)
                    rec["partials"] += int(partial)
                    rec["fails"] += int(not win and not partial)
                    rec["score_sum"] += _finite_float(item.get("total_score")) or 0.0
                    rec["gap_sum"] += abs(_finite_float(item.get("target_gap_pct")) or 0.0)
                    signal_events += 1
                self._aggregate_model_scores(model_agg, item, horizon)

            if snapshot_rows:
                db.executemany("""
                    INSERT OR REPLACE INTO time_machine_feature_snapshots
                    (snapshot_id, batch_id, source, created_at, cutoff_ms, cutoff_iso, horizon, start_price,
                     regime, data_completeness, feature_json, price_context_json, provider_context_json,
                     model_context_json, outcome_tier, target_reached, partial_reached, invalidated,
                     direction_correct, total_score, target_gap_pct, price_error_pct)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?::JSON, ?::JSON, ?::JSON, ?::JSON, ?, ?, ?, ?, ?, ?, ?, ?)
                """, snapshot_rows)
            self._bulk_update_signal_scores(signal_agg, now)
            self._bulk_update_model_scores(model_agg, now)
            append_jsonl("time_machine_learning_audit.jsonl", {
                "event": "learning_items_recorded_v1011", "batch_id": batch_id, "source": source,
                "snapshots": len(snapshot_rows), "signal_events": signal_events, "signal_buckets": len(signal_agg),
                "model_buckets": len(model_agg),
                "feature_enriched": sum(1 for r in snapshot_rows if r[10] and r[10] != '{}'),
            })
        except Exception as exc:
            log.exception("Time Machine learning warehouse failed: %s", exc)
            append_jsonl("time_machine_learning_audit.jsonl", {"event": "learning_failed", "batch_id": batch_id, "source": source, "error": str(exc)})


    def _aggregate_model_scores(self, model_agg: dict[tuple[str, str], dict[str, Any]], item: dict, horizon: str) -> None:
        """Update model-level reliability from Time Machine outcomes.

        This is deliberately direction-based per model. Target/win scoring is
        owned by the full forecast item; model_scores tells the arena which
        specialist directions were historically useful per horizon.
        """
        actual_move = _finite_float(item.get('actual_move_pct'))
        if actual_move is None:
            return
        for c in (item.get('contributions') or item.get('model_contributions') or []):
            mid = str(c.get('model_id') or c.get('name') or '').strip()
            if not mid:
                continue
            # Missing-data diagnostics stay in exports/signals but should not train weights.
            if c.get('data_available') is False or float(c.get('weight') or 0.0) <= 0:
                continue
            pred_move = _finite_float(c.get('expected_move_pct'))
            prob = _finite_float(c.get('bullish_probability'))
            if pred_move is None:
                pred_move = ((prob or 0.5) - 0.5) * 2.0
            pred_up = pred_move >= 0
            actual_up = actual_move >= 0
            key = (mid, horizon)
            rec = model_agg.setdefault(key, {"model_id": mid, "horizon": horizon, "total": 0, "correct": 0, "abs_error_sum": 0.0})
            rec["total"] += 1
            rec["correct"] += int(pred_up == actual_up)
            rec["abs_error_sum"] += abs(actual_move - float(pred_move or 0.0))

    def _bulk_update_model_scores(self, model_agg: dict[tuple[str, str], dict[str, Any]], now) -> None:
        if not model_agg:
            return
        rows = []
        for rec in model_agg.values():
            old = db.fetchone("""
                SELECT total, correct, avg_price_error_pct
                FROM model_scores WHERE model_id=? AND horizon=?
            """, [rec["model_id"], rec["horizon"]])
            if old:
                ototal, ocorrect = int(old[0] or 0), int(old[1] or 0)
                old_err_sum = float(old[2] or 0.0) * ototal
            else:
                ototal = ocorrect = 0
                old_err_sum = 0.0
            ntotal = ototal + int(rec["total"])
            ncorrect = ocorrect + int(rec["correct"])
            err = (old_err_sum + float(rec["abs_error_sum"])) / ntotal if ntotal else 0.0
            rows.append([rec["model_id"], rec["horizon"], ntotal, ncorrect, ncorrect / ntotal if ntotal else 0.5, err, now])
        db.executemany("""
            INSERT OR REPLACE INTO model_scores
            (model_id, horizon, total, correct, hitrate, avg_price_error_pct, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, rows)

    def _bulk_update_signal_scores(self, signal_agg: dict[tuple[str, str, str], dict[str, Any]], now) -> None:
        if not signal_agg:
            return
        rows = []
        for rec in signal_agg.values():
            old = db.fetchone("""
                SELECT total, wins, partials, fails, avg_score, avg_target_gap_pct
                FROM time_machine_signal_scores
                WHERE signal_key=? AND horizon=? AND regime=?
            """, [rec["signal_key"], rec["horizon"], rec["regime"]])
            if old:
                ototal, owins, opartials, ofails = int(old[0] or 0), int(old[1] or 0), int(old[2] or 0), int(old[3] or 0)
                old_score_sum = float(old[4] or 0.0) * ototal
                old_gap_sum = float(old[5] or 0.0) * ototal
            else:
                ototal = owins = opartials = ofails = 0
                old_score_sum = old_gap_sum = 0.0
            ntotal = ototal + int(rec["total"])
            nwins = owins + int(rec["wins"])
            npartials = opartials + int(rec["partials"])
            nfails = ofails + int(rec["fails"])
            avg_score = (old_score_sum + float(rec["score_sum"])) / ntotal if ntotal else 0.0
            avg_gap = (old_gap_sum + float(rec["gap_sum"])) / ntotal if ntotal else 0.0
            rows.append([
                rec["signal_key"], rec.get("signal_label"), rec.get("signal_type"), rec["horizon"], rec["regime"],
                ntotal, nwins, npartials, nfails, nwins / ntotal if ntotal else 0.0,
                (nwins + npartials) / ntotal if ntotal else 0.0, avg_score, avg_gap, now,
            ])
        db.executemany("""
            INSERT OR REPLACE INTO time_machine_signal_scores
            (signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
             hitrate, hitrate_with_partial, avg_score, avg_target_gap_pct, last_seen_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, rows)

    def leaderboard(self, min_total: int = 5, limit: int = 100) -> dict:
        top = db.df("""
            SELECT signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
                   hitrate, hitrate_with_partial, avg_score, avg_target_gap_pct, last_seen_at
            FROM time_machine_signal_scores
            WHERE total >= ?
            ORDER BY hitrate_with_partial DESC, total DESC, avg_score DESC
            LIMIT ?
        """, [int(min_total), int(limit)]).to_dict("records")
        weak = db.df("""
            SELECT signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
                   hitrate, hitrate_with_partial, avg_score, avg_target_gap_pct, last_seen_at
            FROM time_machine_signal_scores
            WHERE total >= ?
            ORDER BY hitrate_with_partial ASC, total DESC, avg_score ASC
            LIMIT ?
        """, [int(min_total), int(limit // 2)]).to_dict("records")
        by_horizon = db.df("""
            SELECT horizon, signal_key, signal_label, signal_type, regime, total, wins, partials, fails,
                   hitrate, hitrate_with_partial, avg_score, avg_target_gap_pct
            FROM time_machine_signal_scores
            WHERE total >= ?
            QUALIFY ROW_NUMBER() OVER (PARTITION BY horizon ORDER BY hitrate_with_partial DESC, total DESC, avg_score DESC) <= 10
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END,
                     hitrate_with_partial DESC, total DESC
        """, [int(min_total)]).to_dict("records")
        coverage = db.df("""
            SELECT horizon, regime, COUNT(*) AS snapshots,
                   AVG(data_completeness) AS avg_data_completeness,
                   AVG(CASE WHEN target_reached THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(CASE WHEN target_reached OR partial_reached THEN 1.0 ELSE 0.0 END) AS hitrate_with_partial,
                   AVG(total_score) AS avg_score
            FROM time_machine_feature_snapshots
            GROUP BY horizon, regime
            ORDER BY snapshots DESC
            LIMIT 80
        """).to_dict("records")
        data = {"top": top, "weak": weak, "by_horizon": by_horizon, "coverage": coverage}
        write_json("last_time_machine_learning.json", data)
        return data

    def _signals_for_item(self, item: dict, feature: dict) -> list[dict]:
        signals: list[dict] = []
        horizon = str(item.get("horizon") or "unknown")
        regime = str(feature.get("regime") or "unknown")
        signals.append({"key": f"regime:{regime}", "label": f"Regime {regime}", "type": "regime", "metadata": {"regime": regime}})
        signals.append(self._sig_bucket("data_completeness", feature.get("data_completeness"), [(35, "low"), (65, "medium"), (85, "good")], "rich"))
        signals.append(self._sig_bucket("rsi_14", feature.get("rsi_14"), [(30, "oversold"), (45, "weak"), (55, "neutral"), (70, "strong")], "overbought"))
        signals.append(self._trend_signal(feature))
        signals.append(self._sig_bucket("drawdown_from_ath", abs(_finite_float(feature.get("drawdown_from_ath")) or 0), [(10, "near_high"), (30, "normal_dd"), (55, "deep_dd")], "capitulation_dd"))
        signals.append(self._sig_bucket("volatility_24", feature.get("volatility_24"), [(0.7, "quiet"), (1.8, "normal"), (3.5, "hot")], "extreme"))
        signals.append(self._sig_bucket("volume_zscore", feature.get("volume_zscore"), [(-1.0, "low"), (1.0, "normal"), (2.5, "high")], "extreme"))
        signals.append(self._sig_bucket("funding_rate", feature.get("funding_rate"), [(-0.0005, "negative"), (0.0005, "neutral"), (0.002, "positive")], "overheated"))
        signals.append(self._sig_bucket("open_interest_change_24h", feature.get("open_interest_change_24h"), [(-3, "falling"), (3, "flat"), (10, "rising")], "surging"))
        signals.append(self._sig_bucket("long_short_ratio", feature.get("long_short_ratio"), [(0.85, "short_crowded"), (1.15, "balanced"), (1.60, "long_crowded")], "extreme_long"))
        signals.append(self._sig_bucket("taker_delta_ratio", feature.get("taker_delta_ratio"), [(-0.15, "sell_pressure"), (0.15, "balanced"), (0.40, "buy_pressure")], "extreme_buy"))
        signals.append(self._sig_bucket("orderbook_imbalance", feature.get("orderbook_imbalance"), [(0.45, "ask_heavy"), (0.55, "balanced"), (0.65, "bid_heavy")], "extreme_bid"))
        signals.append(self._sig_bucket("spot_coinbase_premium", feature.get("spot_premium_coinbase_pct"), [(-0.05, "discount"), (0.05, "flat"), (0.20, "premium")], "strong_premium"))
        signals.append(self._sig_bucket("spot_cross_exchange_spread", feature.get("cross_exchange_spread_pct"), [(0.03, "tight"), (0.12, "normal"), (0.35, "wide")], "stress"))
        prob = (_finite_float(item.get("bullish_probability")) or 0.5) * 100
        signals.append(self._sig_bucket("forecast_edge_abs", abs(prob - 50), [(2.5, "neutral"), (7.5, "light"), (15, "strong")], "extreme"))
        signals.append(self._sig_bucket("confidence", item.get("confidence"), [(35, "low"), (55, "medium"), (75, "high")], "very_high"))
        for c in item.get("contributions") or []:
            mid = str(c.get("model_id") or c.get("name") or "unknown_model")
            name = str(c.get("name") or mid)
            signals.append({"key": f"model:{mid}", "label": f"Model {name}", "type": "model", "metadata": c})
        # Deduplicate; include horizon in metadata, not key, because table already groups by horizon.
        out, seen = [], set()
        for sig in signals:
            if not sig or sig["key"] in seen:
                continue
            sig.setdefault("metadata", {})["horizon"] = horizon
            seen.add(sig["key"])
            out.append(sig)
        return out

    def _sig_bucket(self, name: str, value: Any, cuts: list[tuple[float, str]], default: str) -> dict:
        key, label = _bucket(name, value, cuts, default)
        return {"key": key, "label": label, "type": "feature_bucket", "metadata": {name: _finite_float(value)}}

    def _trend_signal(self, feature: dict) -> dict:
        close = _finite_float(feature.get("close"))
        ma50 = _finite_float(feature.get("ma_50"))
        ma200 = _finite_float(feature.get("ma_200"))
        if close and ma50 and ma200:
            if close > ma50 > ma200:
                label = "bull_stack"
            elif close < ma50 < ma200:
                label = "bear_stack"
            elif close > ma200:
                label = "above_ma200_mixed"
            else:
                label = "below_ma200_mixed"
        else:
            label = "unknown"
        return {"key": f"trend:{label}", "label": f"Trend {label}", "type": "trend", "metadata": {"close": close, "ma_50": ma50, "ma_200": ma200}}

    def _update_signal_score(self, *, horizon: str, regime: str, signal: dict, item: dict, now) -> None:
        row = db.fetchone("""
            SELECT total, wins, partials, fails, avg_score, avg_target_gap_pct
            FROM time_machine_signal_scores
            WHERE signal_key=? AND horizon=? AND regime=?
        """, [signal["key"], horizon, regime])
        if row:
            total, wins, partials, fails = int(row[0] or 0), int(row[1] or 0), int(row[2] or 0), int(row[3] or 0)
            avg_score, avg_gap = float(row[4] or 0), float(row[5] or 0)
        else:
            total = wins = partials = fails = 0
            avg_score = avg_gap = 0.0
        win = bool(item.get("target_reached"))
        partial = bool(item.get("partial_reached")) or (not win and _finite_float(item.get("total_score")) is not None and float(item.get("total_score") or 0) >= 55.0)
        fail = not win and not partial
        score = _finite_float(item.get("total_score")) or 0.0
        gap = abs(_finite_float(item.get("target_gap_pct")) or 0.0)
        nt = total + 1
        nw, npart, nf = wins + int(win), partials + int(partial), fails + int(fail)
        db.execute("""
            INSERT OR REPLACE INTO time_machine_signal_scores
            (signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
             hitrate, hitrate_with_partial, avg_score, avg_target_gap_pct, last_seen_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            signal["key"], signal.get("label"), signal.get("type"), horizon, regime,
            nt, nw, npart, nf, nw / nt if nt else 0.0, (nw + npart) / nt if nt else 0.0,
            (avg_score * total + score) / nt, (avg_gap * total + gap) / nt, now,
        ])

    def _price_context(self, item: dict) -> dict:
        keys = ["start_price", "expected_price", "expected_move_pct", "invalidation_price", "actual_price", "actual_high", "actual_low", "actual_move_pct"]
        return {k: _finite_float(item.get(k)) for k in keys}

    def _provider_context(self, feature: dict) -> dict:
        provider_keys = [
            "fear_greed", "funding_rate", "open_interest_value", "open_interest_change_24h",
            "long_short_ratio", "taker_buy_sell_ratio", "taker_delta_ratio", "orderbook_imbalance",
            "futures_basis_premium_pct", "cross_exchange_spread_pct", "spot_premium_kraken_pct",
            "spot_premium_coinbase_pct", "coinmetrics_mvrv",
        ]
        return {k: feature.get(k) for k in provider_keys}

    def _clean_dict(self, data: dict) -> dict:
        out = {}
        for k, v in (data or {}).items():
            if isinstance(v, (dict, list, tuple)):
                out[str(k)] = v
            else:
                fv = _finite_float(v)
                out[str(k)] = fv if fv is not None else v
        return out
