from __future__ import annotations
import os, webbrowser, asyncio, traceback, logging
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
from app.core.config import settings
from app.api.routes import router
from app.services.data_foundation_service import DataFoundationService
from app.db.database import db
from app.core.time_utils import utc_now
from app.core.logger import log
from app.core.runtime_locks import sync_lock

app = FastAPI(title=settings.app_name)
app.include_router(router)

web_dir = Path(__file__).parent / "web"
app.mount("/static", StaticFiles(directory=str(web_dir / "static")), name="static")

@app.get("/")
def index():
    if os.environ.get("BEE_FORCE_MOBILE") == "1":
        return FileResponse(str(web_dir / "mobile.html"))
    return FileResponse(str(web_dir / "index.html"))

@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(str(web_dir / "manifest.webmanifest"), media_type="application/manifest+json")

@app.get("/service-worker.js")
def service_worker():
    return FileResponse(str(web_dir / "service-worker.js"), media_type="application/javascript")

@app.get("/mobile")
def mobile_index():
    return FileResponse(str(web_dir / "mobile.html"))

async def delayed_auto_sync_job() -> None:
    """V10.4 clean startup data pipeline.

    The app opens immediately. Two seconds later we run the Data Foundation:
    critical candles/ticker first, forecast second, optional evidence in a
    separate capped background phase. Optional providers can never block visible
    price/chart/Time Machine basics.
    """
    await asyncio.sleep(2.0)
    if os.environ.get("BEE_DISABLE_AUTO_SYNC") == "1":
        log.info("Auto-sync disabled by BEE_DISABLE_AUTO_SYNC=1")
        return
    if sync_lock.locked():
        log.info("Auto-sync skipped because sync_lock is already active")
        return
    foundation = DataFoundationService()
    try:
        log.info("V10.16.16 Reset Batches Export auto-sync started")
        async with sync_lock:
            result = await asyncio.wait_for(foundation.run_forecast_pipeline(source="startup"), timeout=45.0)
        log.info("V10.16.16 auto-sync finished. created=%s run=%s reason=%s", result.get("created"), result.get("run_id"), result.get("reason"))
        # V10.11: do not start heavy optional evidence immediately after boot.
        # In V10.7/V10.8 the background futures/features phase could hold the DuckDB
        # lock long enough for /api/dashboard/status and Time Machine resolve to
        # timeout. Keep the UI/snappy chart layer first. Extra evidence is now
        # started manually by Sync + Forecast, or can be enabled for experiments
        # with BEE_ENABLE_STARTUP_EVIDENCE=1.
        if os.environ.get("BEE_ENABLE_STARTUP_EVIDENCE") == "1":
            asyncio.create_task(foundation.delayed_background_evidence(delay_seconds=75.0))
        # V10.15.1: historical memory is automatically completed by its own startup task, not
        # chained to forecast success. Calling it here too is safe because the
        # daemon has a global single-run lock, but this path is intentionally no
        # longer the only way the 70k memory completion can start.
        if bool(settings.historical_auto_complete_on_startup) and os.environ.get("BEE_DISABLE_HISTORY_BACKFILL") != "1":
            asyncio.create_task(foundation.sync_historical_memory_background())
    except asyncio.TimeoutError:
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["startup_sync_status", "timeout_45s", utc_now()])
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["sync_phase", "auto_sync_timeout", utc_now()])
        log.exception("V10.16.16 auto-sync timed out after 45s")
    except Exception as exc:
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["startup_sync_status", "error: "+str(exc)[:300], utc_now()])
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["sync_phase", "auto_sync_error", utc_now()])
        log.exception("V10.16.16 auto-sync failed: %s", exc)


async def delayed_historical_memory_job() -> None:
    """Automatically start the 70k-candle memory daemon independently from forecast startup.

    V10.15.5 note: in older builds, if the startup forecast pipeline timed out
    before the historical-memory task was scheduled, the app could remain stuck
    around a small partial warehouse. This task starts separately and the daemon
    itself handles the single-run lock.
    """
    await asyncio.sleep(float(settings.historical_daemon_autostart_delay_seconds))
    if os.environ.get("BEE_DISABLE_HISTORY_BACKFILL") == "1":
        log.info("Historical memory daemon disabled by BEE_DISABLE_HISTORY_BACKFILL=1")
        return
    try:
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["historical_memory_autostart", "auto_startup_enabled", utc_now()])
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["historical_memory", "automatic startup loading queued", utc_now()])
        foundation = DataFoundationService()
        await foundation.sync_historical_memory_background()
    except Exception as exc:
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["historical_memory_autostart", "error: "+str(exc)[:300], utc_now()])
        log.exception("Historical memory daemon startup failed: %s", exc)

@app.on_event("startup")
async def startup():
    # Open instantly, then auto-fill data in the background.
    log.info("Server startup complete. Dashboard is available. V10.16.16 Reset Batches Export will start sync + history completion shortly.")
    try:
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["startup_sync_status", "queued", utc_now()])
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["sync_phase", "phase_0_queued", utc_now()])
    except Exception as exc:
        log.warning("Could not write startup sync_state: %s", exc)
    asyncio.create_task(delayed_auto_sync_job())
    asyncio.create_task(delayed_historical_memory_job())
    if os.environ.get("BEE_AUTO_OPEN") == "1":
        webbrowser.open(f"http://{settings.host}:{settings.port}")

if __name__ == "__main__":
    uvicorn.run("app.main:app", host=settings.host, port=settings.port, reload=False)
