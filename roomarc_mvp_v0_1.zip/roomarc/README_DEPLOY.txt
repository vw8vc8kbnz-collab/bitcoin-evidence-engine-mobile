ROOMARC MVP v0.1

Mobile-first PWA for the social interior platform concept.

Contains:
- FastAPI backend
- SQLAlchemy database models
- room/home follow system
- following feed
- room timeline
- saves
- local media upload endpoint
- React/Vite mobile PWA frontend
- demo seed data

Install on VPS:

cd ~
rm -rf roomarc
unzip roomarc_mvp_v0_1.zip -d roomarc
cd roomarc
cp .env.example .env
./scripts/install.sh
./scripts/run_dev.sh

Open:
http://SERVER-IP:8899

Health check:
curl http://127.0.0.1:8899/api/health

Demo login:
demo@roomarc.local
demo123

Important:
- This build uses SQLite by default for easy MVP testing.
- Before public beta, switch DATABASE_URL to PostgreSQL.
- Before real users, switch media storage from local dev to Cloudflare R2.
- Do not run this inside the Bitcoin Evidence Engine current folder.
- Keep BEE and Roomarc as separate services.

Suggested VPS folder:
/home/ubuntu/roomarc

Suggested future production:
- nginx reverse proxy
- systemd service
- PostgreSQL
- Cloudflare R2
- HTTPS via Cloudflare
