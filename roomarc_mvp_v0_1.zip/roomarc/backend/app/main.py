import os, uuid, shutil, datetime, jwt
from pathlib import Path
from typing import Optional, List
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy import create_engine, Column, String, DateTime, ForeignKey, Text, Integer, UniqueConstraint
from sqlalchemy.orm import declarative_base, sessionmaker, relationship, Session
import hashlib, secrets
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parents[2]
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./roomarc.db')
JWT_SECRET = os.getenv('JWT_SECRET', 'dev-secret')
MEDIA_DIR = Path(os.getenv('MEDIA_DIR', str(ROOT/'storage'/'media')))
FRONTEND_DIST = Path(os.getenv('FRONTEND_DIST', str(ROOT.parent/'frontend'/'dist')))
MEDIA_DIR.mkdir(parents=True, exist_ok=True)
engine = create_engine(DATABASE_URL, connect_args={'check_same_thread': False} if DATABASE_URL.startswith('sqlite') else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()
def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 120000)
    return f'pbkdf2_sha256${salt}${dk.hex()}'

def verify_password(password: str, stored: str) -> bool:
    try:
        algo, salt, digest = stored.split('$', 2)
        if algo != 'pbkdf2_sha256': return False
        dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 120000)
        return secrets.compare_digest(dk.hex(), digest)
    except Exception:
        return False

class User(Base):
    __tablename__='users'
    id=Column(String, primary_key=True, default=lambda:str(uuid.uuid4()))
    email=Column(String, unique=True, nullable=False)
    username=Column(String, unique=True, nullable=False)
    display_name=Column(String, nullable=False)
    password_hash=Column(String, nullable=False)
    avatar_url=Column(String)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

class Home(Base):
    __tablename__='homes'
    id=Column(String, primary_key=True, default=lambda:str(uuid.uuid4()))
    owner_user_id=Column(String, ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    title=Column(String, nullable=False)
    slug=Column(String, unique=True, nullable=False)
    description=Column(Text, default='')
    style_text=Column(String, default='')
    cover_url=Column(String, default='')
    created_at=Column(DateTime, default=datetime.datetime.utcnow)
    owner=relationship('User')

class Room(Base):
    __tablename__='rooms'
    id=Column(String, primary_key=True, default=lambda:str(uuid.uuid4()))
    home_id=Column(String, ForeignKey('homes.id', ondelete='CASCADE'), nullable=False)
    name=Column(String, nullable=False)
    room_type=Column(String, default='')
    cover_url=Column(String, default='')
    sort_order=Column(Integer, default=0)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)
    home=relationship('Home')

class RoomUpdate(Base):
    __tablename__='room_updates'
    id=Column(String, primary_key=True, default=lambda:str(uuid.uuid4()))
    room_id=Column(String, ForeignKey('rooms.id', ondelete='CASCADE'), nullable=False)
    media_url=Column(String, nullable=False)
    caption=Column(Text, default='')
    phase_label=Column(String, default='')
    created_at=Column(DateTime, default=datetime.datetime.utcnow)
    room=relationship('Room')

class FollowHome(Base):
    __tablename__='follows_home'
    user_id=Column(String, ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    home_id=Column(String, ForeignKey('homes.id', ondelete='CASCADE'), primary_key=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

class FollowRoom(Base):
    __tablename__='follows_room'
    user_id=Column(String, ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    room_id=Column(String, ForeignKey('rooms.id', ondelete='CASCADE'), primary_key=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

class Save(Base):
    __tablename__='saves'
    user_id=Column(String, ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    update_id=Column(String, ForeignKey('room_updates.id', ondelete='CASCADE'), primary_key=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

Base.metadata.create_all(bind=engine)
app = FastAPI(title='Roomarc API', version='0.1.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])
app.mount('/media', StaticFiles(directory=str(MEDIA_DIR)), name='media')

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()

def token_for(u):
    return jwt.encode({'sub':u.id,'email':u.email,'exp':datetime.datetime.utcnow()+datetime.timedelta(days=30)}, JWT_SECRET, algorithm='HS256')

def current_user(request: Request, s: Session=Depends(db)):
    auth=request.headers.get('authorization','')
    if not auth.startswith('Bearer '): raise HTTPException(401,'Not authenticated')
    try: data=jwt.decode(auth.split(' ',1)[1], JWT_SECRET, algorithms=['HS256'])
    except Exception: raise HTTPException(401,'Invalid token')
    u=s.get(User, data['sub'])
    if not u: raise HTTPException(401,'User not found')
    return u

class LoginIn(BaseModel): email:str; password:str
class RegisterIn(BaseModel): email:str; password:str; username:str; display_name:str
class HomeIn(BaseModel): title:str; description:str=''; style_text:str=''; cover_url:str=''
class RoomIn(BaseModel): name:str; room_type:str=''; cover_url:str=''
class UpdateIn(BaseModel): media_url:str; caption:str=''; phase_label:str=''

def slugify(v):
    base=''.join(c.lower() if c.isalnum() else '-' for c in v).strip('-') or 'home'
    while '--' in base: base=base.replace('--','-')
    return base[:60]

def counts_home(s, home_id):
    return {'rooms':s.query(Room).filter_by(home_id=home_id).count(),'followers':s.query(FollowHome).filter_by(home_id=home_id).count(),'updates':s.query(RoomUpdate).join(Room).filter(Room.home_id==home_id).count()}

def ser_update(s,u,up):
    r=up.room; h=r.home
    return {'id':up.id,'media_url':up.media_url,'caption':up.caption,'phase_label':up.phase_label,'created_at':up.created_at.isoformat(), 'room':{'id':r.id,'name':r.name,'cover_url':r.cover_url}, 'home':{'id':h.id,'title':h.title,'slug':h.slug,'cover_url':h.cover_url}, 'saved': bool(s.get(Save, {'user_id':u.id,'update_id':up.id})) if u else False, 'following_room': bool(s.get(FollowRoom, {'user_id':u.id,'room_id':r.id})) if u else False, 'following_home': bool(s.get(FollowHome, {'user_id':u.id,'home_id':h.id})) if u else False}

@app.get('/api/health')
def health(): return {'ok':True,'app':'Roomarc','version':'0.1.0'}

@app.post('/api/auth/register')
def register(x:RegisterIn, s:Session=Depends(db)):
    if s.query(User).filter((User.email==x.email)|(User.username==x.username)).first(): raise HTTPException(409,'Email or username already exists')
    u=User(email=x.email, username=x.username, display_name=x.display_name, password_hash=hash_password(x.password))
    s.add(u); s.commit(); s.refresh(u)
    return {'token':token_for(u),'user':{'id':u.id,'email':u.email,'username':u.username,'display_name':u.display_name}}

@app.post('/api/auth/login')
def login(x:LoginIn, s:Session=Depends(db)):
    u=s.query(User).filter_by(email=x.email).first()
    if not u or not verify_password(x.password,u.password_hash): raise HTTPException(401,'Wrong credentials')
    return {'token':token_for(u),'user':{'id':u.id,'email':u.email,'username':u.username,'display_name':u.display_name}}

@app.get('/api/auth/me')
def me(u:User=Depends(current_user)): return {'id':u.id,'email':u.email,'username':u.username,'display_name':u.display_name}

@app.post('/api/seed-demo')
def seed(s:Session=Depends(db)):
    u=s.query(User).filter_by(email='demo@roomarc.local').first()
    if not u:
        u=User(email='demo@roomarc.local', username='demo', display_name='Demo Creator', password_hash=hash_password('demo123'))
        s.add(u); s.commit(); s.refresh(u)
    if not s.query(Home).filter_by(slug='the-atelier-house').first():
        h=Home(owner_user_id=u.id,title='The Atelier House',slug='the-atelier-house',description='A calm city home evolving room by room.',style_text='Japandi / warm minimal / natural textures',cover_url='https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80')
        s.add(h); s.commit(); s.refresh(h)
        rooms=[('Living Room','living','https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80'),('Kitchen','kitchen','https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=1200&q=80'),('Bedroom','bedroom','https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?auto=format&fit=crop&w=1200&q=80')]
        for i,(name,typ,img) in enumerate(rooms):
            r=Room(home_id=h.id,name=name,room_type=typ,cover_url=img,sort_order=i); s.add(r); s.commit(); s.refresh(r)
            phases=['Empty shell','Walls finished','Furniture placed','Styled'] if i==0 else ['First layout','Materials chosen','Details added']
            imgs=[img,'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80','https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&w=1200&q=80','https://images.unsplash.com/photo-1615873968403-89e068629265?auto=format&fit=crop&w=1200&q=80']
            for j,p in enumerate(phases):
                up=RoomUpdate(room_id=r.id,media_url=imgs[j%len(imgs)],phase_label=p,caption=f'{name} update: {p.lower()}.')
                s.add(up)
        s.commit()
    return {'ok':True,'demo_login':'demo@roomarc.local / demo123'}

@app.get('/api/homes')
def homes(s:Session=Depends(db), u:User=Depends(current_user)):
    return [{**{'id':h.id,'title':h.title,'slug':h.slug,'description':h.description,'style_text':h.style_text,'cover_url':h.cover_url}, **counts_home(s,h.id), 'following':bool(s.get(FollowHome,{'user_id':u.id,'home_id':h.id}))} for h in s.query(Home).order_by(Home.created_at.desc()).all()]

@app.post('/api/homes')
def create_home(x:HomeIn, s:Session=Depends(db), u:User=Depends(current_user)):
    base=slugify(x.title); slug=base; n=2
    while s.query(Home).filter_by(slug=slug).first(): slug=f'{base}-{n}'; n+=1
    h=Home(owner_user_id=u.id,title=x.title,slug=slug,description=x.description,style_text=x.style_text,cover_url=x.cover_url)
    s.add(h); s.commit(); s.refresh(h); return {'id':h.id,'slug':h.slug}

@app.get('/api/homes/{slug}')
def get_home(slug:str, s:Session=Depends(db), u:User=Depends(current_user)):
    h=s.query(Home).filter_by(slug=slug).first()
    if not h: raise HTTPException(404,'Home not found')
    rooms=[]
    for r in s.query(Room).filter_by(home_id=h.id).order_by(Room.sort_order).all():
        rooms.append({'id':r.id,'name':r.name,'room_type':r.room_type,'cover_url':r.cover_url,'followers':s.query(FollowRoom).filter_by(room_id=r.id).count(),'updates':s.query(RoomUpdate).filter_by(room_id=r.id).count(),'following':bool(s.get(FollowRoom,{'user_id':u.id,'room_id':r.id}))})
    return {'id':h.id,'title':h.title,'slug':h.slug,'description':h.description,'style_text':h.style_text,'cover_url':h.cover_url,'owner':h.owner.display_name,'stats':counts_home(s,h.id),'following':bool(s.get(FollowHome,{'user_id':u.id,'home_id':h.id})),'rooms':rooms}

@app.post('/api/homes/{home_id}/follow')
def follow_home(home_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    if not s.get(Home,home_id): raise HTTPException(404,'Home not found')
    if not s.get(FollowHome,{'user_id':u.id,'home_id':home_id}): s.add(FollowHome(user_id=u.id,home_id=home_id)); s.commit()
    return {'following':True}

@app.delete('/api/homes/{home_id}/follow')
def unfollow_home(home_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    f=s.get(FollowHome,{'user_id':u.id,'home_id':home_id})
    if f: s.delete(f); s.commit()
    return {'following':False}

@app.post('/api/homes/{home_id}/rooms')
def create_room(home_id:str, x:RoomIn, s:Session=Depends(db), u:User=Depends(current_user)):
    h=s.get(Home,home_id)
    if not h or h.owner_user_id!=u.id: raise HTTPException(404,'Home not found')
    r=Room(home_id=home_id,name=x.name,room_type=x.room_type,cover_url=x.cover_url,sort_order=s.query(Room).filter_by(home_id=home_id).count())
    s.add(r); s.commit(); s.refresh(r); return {'id':r.id}

@app.get('/api/rooms/{room_id}')
def get_room(room_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    r=s.get(Room,room_id)
    if not r: raise HTTPException(404,'Room not found')
    ups=s.query(RoomUpdate).filter_by(room_id=room_id).order_by(RoomUpdate.created_at.asc()).all()
    return {'id':r.id,'name':r.name,'room_type':r.room_type,'cover_url':r.cover_url,'home':{'id':r.home.id,'title':r.home.title,'slug':r.home.slug},'followers':s.query(FollowRoom).filter_by(room_id=r.id).count(),'following':bool(s.get(FollowRoom,{'user_id':u.id,'room_id':r.id})),'updates':[ser_update(s,u,x) for x in ups]}

@app.post('/api/rooms/{room_id}/follow')
def follow_room(room_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    if not s.get(Room,room_id): raise HTTPException(404,'Room not found')
    if not s.get(FollowRoom,{'user_id':u.id,'room_id':room_id}): s.add(FollowRoom(user_id=u.id,room_id=room_id)); s.commit()
    return {'following':True}

@app.delete('/api/rooms/{room_id}/follow')
def unfollow_room(room_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    f=s.get(FollowRoom,{'user_id':u.id,'room_id':room_id})
    if f: s.delete(f); s.commit()
    return {'following':False}

@app.post('/api/rooms/{room_id}/updates')
def create_update(room_id:str, x:UpdateIn, s:Session=Depends(db), u:User=Depends(current_user)):
    r=s.get(Room,room_id)
    if not r or r.home.owner_user_id!=u.id: raise HTTPException(404,'Room not found')
    up=RoomUpdate(room_id=room_id,media_url=x.media_url,caption=x.caption,phase_label=x.phase_label)
    s.add(up); s.commit(); s.refresh(up); return {'id':up.id}

@app.get('/api/feed/following')
def feed(s:Session=Depends(db), u:User=Depends(current_user)):
    home_ids=[x.home_id for x in s.query(FollowHome).filter_by(user_id=u.id).all()]
    room_ids=[x.room_id for x in s.query(FollowRoom).filter_by(user_id=u.id).all()]
    q=s.query(RoomUpdate).join(Room)
    if home_ids or room_ids:
        q=q.filter((Room.home_id.in_(home_ids)) | (Room.id.in_(room_ids)))
    ups=q.order_by(RoomUpdate.created_at.desc()).limit(50).all()
    if not ups: ups=s.query(RoomUpdate).order_by(RoomUpdate.created_at.desc()).limit(20).all()
    return [ser_update(s,u,x) for x in ups]

@app.post('/api/updates/{update_id}/save')
def save(update_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    if not s.get(RoomUpdate,update_id): raise HTTPException(404,'Update not found')
    if not s.get(Save,{'user_id':u.id,'update_id':update_id}): s.add(Save(user_id=u.id,update_id=update_id)); s.commit()
    return {'saved':True}

@app.delete('/api/updates/{update_id}/save')
def unsave(update_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    sv=s.get(Save,{'user_id':u.id,'update_id':update_id})
    if sv: s.delete(sv); s.commit()
    return {'saved':False}

@app.get('/api/me/saves')
def saves(s:Session=Depends(db), u:User=Depends(current_user)):
    ids=[x.update_id for x in s.query(Save).filter_by(user_id=u.id).all()]
    ups=s.query(RoomUpdate).filter(RoomUpdate.id.in_(ids)).order_by(RoomUpdate.created_at.desc()).all() if ids else []
    return [ser_update(s,u,x) for x in ups]

@app.post('/api/media/upload')
def upload(file:UploadFile=File(...), u:User=Depends(current_user)):
    ext=Path(file.filename or 'upload.jpg').suffix.lower() or '.jpg'
    name=f'{uuid.uuid4()}{ext}'
    path=MEDIA_DIR/name
    with path.open('wb') as f: shutil.copyfileobj(file.file,f)
    return {'url':f'/media/{name}','storage':'local-dev'}

# SPA fallback
if FRONTEND_DIST.exists():
    app.mount('/assets', StaticFiles(directory=str(FRONTEND_DIST/'assets')), name='assets')
    @app.get('/{full_path:path}')
    def spa(full_path:str):
        p=FRONTEND_DIST/full_path
        if p.exists() and p.is_file(): return FileResponse(str(p))
        return FileResponse(str(FRONTEND_DIST/'index.html'))
