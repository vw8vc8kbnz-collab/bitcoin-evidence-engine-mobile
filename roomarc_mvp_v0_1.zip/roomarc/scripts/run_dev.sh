#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -f .env ]; then cp .env.example .env; fi
. .venv/bin/activate
set -a
. .env
set +a
cd backend
exec python -m uvicorn app.main:app --host "${ROOMARC_HOST:-0.0.0.0}" --port "${ROOMARC_PORT:-8899}"
