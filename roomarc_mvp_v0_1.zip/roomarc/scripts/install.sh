#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON_BIN="${PYTHON_BIN:-python3}"
if [ ! -d .venv ]; then
  "$PYTHON_BIN" -m venv .venv
fi
. .venv/bin/activate
python -m pip install --upgrade pip
pip install -r backend/requirements.txt
if command -v npm >/dev/null 2>&1; then
  cd frontend
  npm install
  npm run build
else
  echo "npm not found; backend will still run, but frontend build was skipped."
fi
