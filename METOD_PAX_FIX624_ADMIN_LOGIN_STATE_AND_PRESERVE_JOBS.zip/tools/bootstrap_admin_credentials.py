#!/usr/bin/env python3
"""Bootstrap or rotate METOD/PAX live admin credentials on the VPS.

Safe production behavior:
- Prompts for the admin password with hidden input by default (no plaintext in shell history).
- Stores only a PBKDF2-SHA256 hash in /etc/adzaagt/metod-pax/admin_credentials.live.json.
- Atomically replaces any old hash, after writing a timestamped .bak backup.
- Sets file permissions to 0600.
- Ensures metod-pax.env points to the live credentials file and disables staging bypass.

Usage:
  sudo python3 tools/bootstrap_admin_credentials.py

Optional non-interactive/random modes are available for emergency automation, but the default is the
recommended Termius flow: type the password on the server, hidden by getpass.
"""
from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
import secrets
import shutil
import string
import time
from pathlib import Path

DEFAULT_CREDS_PATH = Path('/etc/adzaagt/metod-pax/admin_credentials.live.json')
DEFAULT_ENV_PATH = Path('/etc/adzaagt/metod-pax/metod-pax.env')
ALPHABET = string.ascii_letters + string.digits + '!@#$%_-'


def make_password(length: int = 24) -> str:
    return ''.join(secrets.choice(ALPHABET) for _ in range(max(20, length)))


def hash_password(password: str, iterations: int = 260_000) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), iterations).hex()
    return f'pbkdf2_sha256${iterations}${salt}${dk}'


def parse_env_lines(path: Path) -> list[str]:
    if not path.exists():
        return []
    return path.read_text(encoding='utf-8', errors='ignore').splitlines()


def upsert_env(path: Path, updates: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    old_lines = parse_env_lines(path)
    remove_keys = set(updates)
    new_lines: list[str] = []
    for line in old_lines:
        stripped = line.strip()
        if not stripped or stripped.startswith('#') or '=' not in stripped:
            new_lines.append(line)
            continue
        key = stripped.split('=', 1)[0].strip()
        if key in remove_keys:
            continue
        new_lines.append(line)
    for key, value in updates.items():
        new_lines.append(f'{key}={value}')
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text('\n'.join(new_lines).rstrip() + '\n', encoding='utf-8')
    os.replace(tmp, path)


def backup_existing(path: Path) -> Path | None:
    if not path.exists():
        return None
    stamp = time.strftime('%Y%m%d_%H%M%S')
    backup = path.with_name(path.name + f'.bak_{stamp}')
    shutil.copy2(path, backup)
    os.chmod(backup, 0o600)
    return backup


def read_password_interactively(min_length: int) -> str:
    pw1 = getpass.getpass('Nieuw admin wachtwoord: ')
    pw2 = getpass.getpass('Herhaal admin wachtwoord: ')
    if pw1 != pw2:
        raise SystemExit('ERROR: wachtwoorden zijn niet gelijk. Er is niets aangepast.')
    if len(pw1) < min_length:
        raise SystemExit(f'ERROR: wachtwoord moet minimaal {min_length} tekens zijn. Er is niets aangepast.')
    return pw1


def main() -> int:
    ap = argparse.ArgumentParser(description='Create or rotate METOD/PAX live admin credentials safely.')
    ap.add_argument('--path', default=str(DEFAULT_CREDS_PATH), help='Credentials JSON path')
    ap.add_argument('--env-file', default=str(DEFAULT_ENV_PATH), help='metod-pax.env path')
    ap.add_argument('--username', default='admin', help='Admin username')
    ap.add_argument('--password', default=None, help='Admin password. Avoid this in shell history; interactive is safer.')
    ap.add_argument('--generate', action='store_true', help='Generate a random password and print it once')
    ap.add_argument('--length', type=int, default=24, help='Generated password length')
    ap.add_argument('--min-length', type=int, default=12, help='Minimum password length for interactive/password mode')
    ap.add_argument('--no-env-update', action='store_true', help='Do not update metod-pax.env')
    ap.add_argument('--no-backup', action='store_true', help='Do not back up an existing credentials file')
    args = ap.parse_args()

    path = Path(args.path)
    env_path = Path(args.env_file)
    username = args.username.strip() or 'admin'

    generated = False
    if args.password is not None:
        if len(args.password) < args.min_length:
            raise SystemExit(f'ERROR: wachtwoord moet minimaal {args.min_length} tekens zijn. Er is niets aangepast.')
        password = args.password
    elif args.generate:
        password = make_password(args.length)
        generated = True
    else:
        password = read_password_interactively(args.min_length)

    path.parent.mkdir(parents=True, exist_ok=True)
    backup = None if args.no_backup else backup_existing(path)

    obj = {'username': username, 'password_hash': hash_password(password)}
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)
    os.chmod(path, 0o600)

    if not args.no_env_update:
        upsert_env(env_path, {
            'ADMIN_CREDENTIALS_FILE': str(path),
            'ADMIN_STAGING_OPEN': '0',
        })

    print(f'OK: admin credentials opgeslagen: {path}')
    print(f'OK: username: {username}')
    print('OK: password_hash is PBKDF2-SHA256; plaintext wachtwoord is niet opgeslagen.')
    print('OK: rechten gezet op chmod 600.')
    if backup:
        print(f'OK: oude hash backup: {backup}')
    if not args.no_env_update:
        print(f'OK: env bijgewerkt: {env_path}')
    if generated:
        print('GENERATED_ADMIN_PASSWORD:', password)
        print('SLA DIT WACHTWOORD DIRECT OP. Het is niet terug te halen uit de hash.')
    print('Herstart daarna: sudo systemctl restart metod-pax')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
