#!/usr/bin/env python3
"""METOD/PAX final production preflight checks."""
from __future__ import annotations
import json, os, sys
from pathlib import Path

APP_DIR = Path(os.environ.get('APP_DIR', '/opt/adzaagt/metod-pax'))
ENV_FILE = Path(os.environ.get('METOD_ENV_FILE', '/etc/adzaagt/metod-pax/metod-pax.env'))
CREDS = Path(os.environ.get('ADMIN_CREDENTIALS_FILE', '/etc/adzaagt/metod-pax/admin_credentials.live.json'))

def read_env(path: Path) -> dict[str, str]:
    out = {}
    if path.exists():
        for line in path.read_text(errors='ignore').splitlines():
            line=line.strip()
            if not line or line.startswith('#') or '=' not in line: continue
            k,v=line.split('=',1)
            out[k.strip()] = v.strip().strip('"').strip("'")
    return out

def fail(msg: str, errors: list[str]):
    errors.append(msg)
    print('FAIL:', msg)

def ok(msg: str):
    print('OK:  ', msg)

def main() -> int:
    errors=[]
    env=read_env(ENV_FILE)
    if env.get('PRODUCTION_HARDENING') == '1': ok('PRODUCTION_HARDENING=1')
    else: fail('PRODUCTION_HARDENING must be 1', errors)
    if env.get('ADMIN_STAGING_OPEN','0') in ('0','false','False','') : ok('ADMIN_STAGING_OPEN disabled')
    else: fail('ADMIN_STAGING_OPEN must be 0', errors)
    if env.get('PUBLIC_JOB_MAX_CONCURRENT') == '1': ok('PUBLIC_JOB_MAX_CONCURRENT=1')
    else: fail('PUBLIC_JOB_MAX_CONCURRENT should be 1 for current VPS/final baseline', errors)
    if env.get('PUBLIC_JOB_MAX_CONCURRENT_PER_IP') == '1': ok('PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1')
    else: fail('PUBLIC_JOB_MAX_CONCURRENT_PER_IP should be 1 for current VPS/final baseline', errors)
    if env.get('ALLOWED_ORIGINS'): ok('ALLOWED_ORIGINS set')
    else: fail('ALLOWED_ORIGINS missing', errors)
    if env.get('ALLOWED_ADMIN_ORIGINS'): ok('ALLOWED_ADMIN_ORIGINS set')
    else: fail('ALLOWED_ADMIN_ORIGINS missing', errors)
    cpath = Path(env.get('ADMIN_CREDENTIALS_FILE') or str(CREDS))
    if cpath.exists():
        try:
            data=json.loads(cpath.read_text())
            if str(data.get('password_hash','')).startswith('pbkdf2_sha256$'):
                ok('admin credentials hash is PBKDF2-SHA256')
            else:
                fail('admin credentials must contain password_hash starting with pbkdf2_sha256$', errors)
            mode = cpath.stat().st_mode & 0o777
            if mode == 0o600: ok('admin credentials chmod 600')
            else: fail(f'admin credentials permissions are {oct(mode)}, expected 0o600', errors)
        except Exception as e:
            fail(f'cannot read credentials JSON: {e}', errors)
    else:
        fail(f'admin credentials file missing: {cpath}', errors)
    if (APP_DIR/'app'/'server_py.py').exists(): ok('server_py.py present')
    else: fail('server_py.py missing at app/server_py.py', errors)
    print('\nRESULT:', 'PASS' if not errors else f'FAIL ({len(errors)} issue(s))')
    return 1 if errors else 0
if __name__ == '__main__':
    raise SystemExit(main())
