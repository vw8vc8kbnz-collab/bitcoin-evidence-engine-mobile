/* FIX325: second safe split prep - render helpers */
(function(){
  function drawEmpty(ctx, w, h){
    if(!ctx) return;
    ctx.save();
    ctx.fillStyle = 'rgba(234,243,238,.9)';
    ctx.font = '800 16px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto';
    ctx.textAlign = 'center';
    ctx.fillText('Kies rechts een type + maat om te starten', w/2, h/2 - 12);
    ctx.fillStyle = 'rgba(200,215,208,.90)';
    ctx.font = '13px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto';
    ctx.fillText('Je ziet hier direct het front met boringen, maatvoering, verlengen en spiegeling.', w/2, h/2 + 12);
    ctx.restore();
  }

  window.ToolARenderHelpers = {
    drawEmpty: drawEmpty
  };
})();
