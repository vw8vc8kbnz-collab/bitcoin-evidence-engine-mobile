(function(){
  const expected = [
    ['ToolAStateHelpers','helper'],
    ['ToolAAlertHelpers','helper'],
    ['ToolADomHelpers','helper'],
    ['ToolATemplateHelpers','helper'],
    ['ToolAMiscHelpers','helper'],
    ['ToolAViewMathHelpers','view-helper'],
    ['ToolARenderHelpers','view-helper'],
    ['ToolATemplateViewHelpers','view-helper'],
    ['ToolAValidators','validators'],
    ['ToolACoreSelectors','core-selectors'],
    ['ToolAPanelEditContext','panel-edit-context'],
    ['ToolAPanelFormState','panel-form-state'],
    ['ToolAPanelFormApply','panel-form-apply'],
    ['ToolATypeSizeDecisions','type-size-decisions'],
    ['ToolAFooterDecisions','footer-decisions'],
    ['ToolAFooterViewState','footer-view-state'],
    ['ToolAFooterApply','footer-apply'],
    ['ToolAExtraPanelViewState','extra-panel-view-state'],
    ['ToolAExtraPanelMutations','extra-panel-mutations'],
    ['ToolAExtraPanelFormApply','extra-panel-form-apply'],
    ['ToolAExtraPanelSubmitFlow','extra-panel-submit-flow'],
    ['ToolAPanelMutations','panel-mutations'],
    ['ToolAPanelSubmitFlow','panel-submit-flow'],
    ['ToolAPanelBootstrapMutations','panel-bootstrap-mutations'],
    ['ToolAPanelBootstrapApply','panel-bootstrap-apply'],
    ['ToolAMaterialBatchMutations','material-batch-mutations'],
    ['ToolACustomerValidation','customer-validation'],
    ['ToolAGrainValidation','grain-validation'],
    ['ToolAPanelControlsApply','panel-controls-apply'],
    ['ToolAPanelsViewModels','panels-view-models'],
    ['ToolAPanelRowViewModels','panel-row-view-models'],
    ['ToolACoreReadHelpers','mini-core-read'],
    ['ToolAModuleRegistry','registry'],
    ['ToolARuntimeGuard','guard'],
    ['ToolAEntry','core-adapter'],
    ['ToolARouteFooter','core-adapter'],
    ['ToolAPanelsEntry','core-adapter']
  ];

  function getReport(){
    const present = {};
    expected.forEach(([name, role], idx) => {
      present[name] = {
        role,
        expectedIndex: idx,
        loaded: typeof window[name] !== 'undefined'
      };
    });
    const loadedCount = Object.values(present).filter(v => v.loaded).length;
    const missing = Object.entries(present).filter(([,v]) => !v.loaded).map(([k]) => k);
    return {
      ts: new Date().toISOString(),
      ok: missing.length === 0,
      loadedCount,
      total: expected.length,
      missing,
      modules: present
    };
  }

  function printReport(){
    const report = getReport();
    const status = report.ok ? 'OK' : 'WARN';
    console.log(`[ToolA Load Contract] ${status}`, report);
    return report;
  }

  window.ToolALoadContract = { expected, getReport, printReport };
})();

;try{ window.ToolALoadContract && window.ToolALoadContract.addRequirement && window.ToolALoadContract.addRequirement('ToolAPanelDockState'); }catch(_){ }

;try{ window.ToolALoadContract && window.ToolALoadContract.addRequirement && window.ToolALoadContract.addRequirement('ToolAPanelRowViewModels'); }catch(_){ }

;try{ window.ToolALoadContract && window.ToolALoadContract.addRequirement && window.ToolALoadContract.addRequirement('ToolAExtraPanelMutations'); }catch(_){ }

;try{ window.ToolALoadContract && window.ToolALoadContract.addRequirement && window.ToolALoadContract.addRequirement('ToolAPanelMutations'); }catch(_){ }

;try{ window.ToolALoadContract && window.ToolALoadContract.addRequirement && window.ToolALoadContract.addRequirement('ToolAPanelUiState'); }catch(_){ }

;try{ window.ToolALoadContract && window.ToolALoadContract.addRequirement && window.ToolALoadContract.addRequirement('ToolAExtraPanelSubmitFlow'); }catch(_){ }

;try{ window.ToolALoadContract && window.ToolALoadContract.addRequirement && window.ToolALoadContract.addRequirement('ToolAPanelControlsApply'); }catch(_){ }

;try{ window.ToolALoadContract && window.ToolALoadContract.addRequirement && window.ToolALoadContract.addRequirement('ToolAExtraPanelFormApply'); }catch(_){ }

;try{ window.ToolALoadContract && window.ToolALoadContract.addRequirement && window.ToolALoadContract.addRequirement('ToolAPanelBootstrapApply'); }catch(_){ }
