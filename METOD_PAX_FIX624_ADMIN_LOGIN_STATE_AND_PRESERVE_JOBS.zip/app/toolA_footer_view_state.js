(function(){
  function buttonState(input, fallbackLabel){
    const cfg = input && typeof input === 'object' ? input : {};
    return {
      display: cfg.show ? 'inline-flex' : 'none',
      disabled: !!cfg.disabled,
      text: cfg.label || fallbackLabel
    };
  }

  function normalizeDecision(decision){
    const d = decision && typeof decision === 'object' ? decision : {};
    return {
      step: String(d.step || 'material'),
      prev: buttonState({ show:d.showPrev, disabled:d.prevDisabled, label:d.prevLabel }, 'Vorige stap'),
      next: buttonState({ show:d.showNext, disabled:d.nextDisabled, label:d.nextLabel }, 'Volgende stap'),
      overview: buttonState({ show:d.showOverview, disabled:d.overviewDisabled, label:d.overviewLabel }, 'Overzicht'),
      addInline: {
        disabled: !!d.addInlineDisabled,
        text: d.addInlineLabel || '+ Toevoegen aan lijst',
        editing: !!d.addInlineEditing,
        classes: { isEditing: !!d.addInlineEditing }
      }
    };
  }

  function getViewState(decision){
    return normalizeDecision(decision);
  }

  window.ToolAFooterViewState = {
    getViewState,
    normalizeDecision
  };
})();
