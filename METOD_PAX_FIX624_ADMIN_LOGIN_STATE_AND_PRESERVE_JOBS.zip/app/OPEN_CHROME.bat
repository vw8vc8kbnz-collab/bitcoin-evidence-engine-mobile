@echo off
setlocal EnableExtensions
set "PYTHONDONTWRITEBYTECODE=1"
cd /d "%~dp0"
title METOD Chrome Launcher

set "URL_MAIN=http://127.0.0.1:8787"
echo [METOD] OPEN_CHROME starting...
echo [METOD] URL_MAIN=%URL_MAIN%

set "CHROME_EXE="

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined CHROME_EXE if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined CHROME_EXE if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "CHROME_EXE=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"

REM If Chrome still not found, just open default browser (never fail hard)
if not defined CHROME_EXE (
  echo [METOD] Chrome not found, opening default browser instead.
  start "" "%URL_MAIN%"
  exit /b 0
)

echo [METOD] CHROME_EXE=%CHROME_EXE%

REM Launch Chrome (no delayed expansion, safe with Program Files (x86))
start "" "%CHROME_EXE%" --new-window "%URL_MAIN%"
exit /b 0
