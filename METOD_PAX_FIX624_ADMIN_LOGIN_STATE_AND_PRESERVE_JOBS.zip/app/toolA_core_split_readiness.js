(function(){
  function hasFn(obj, name){ return !!(obj && typeof obj[name] === 'function'); }
  function hasVal(name){ return typeof window[name] !== 'undefined' && window[name] !== null; }

  const domains = {
    routing: {
      description: 'Wizard route and step transitions',
      blockers: {
        showStep: hasFn(window, 'showStep'),
        setStep: hasFn(window, 'setStep'),
        renderFooterForStep: hasFn(window, 'renderFooterForStep'),
        ToolAEntry: !!window.ToolAEntry,
        ToolARouteFooter: !!window.ToolARouteFooter,
      },
      safeForFirstCoreSplit: false,
      reason: 'Still coupled to live step transitions and footer state.'
    },
    panels: {
      description: 'Step 2 selection, bootstrap and panel edit logic',
      blockers: {
        ToolAPanelsEntry: !!window.ToolAPanelsEntry,
        renderCart: hasFn(window, 'renderCart'),
        startEditCartItem: hasFn(window, 'startEditCartItem') || hasFn(window, '__startEditCartItem'),
        bootstrapSelection: hasFn(window, '__bootstrapPanelSelectionForActiveMaterial'),
        removeMaterialBatch: hasFn(window, '__removeMaterialBatch') || hasFn(window, 'removeMaterialBatch'),
        setActiveMaterial: hasFn(window, '__setActiveMaterial') || hasFn(window, 'setActiveMaterial')
      },
      safeForFirstCoreSplit: false,
      reason: 'Still coupled to step-2 runtime state, edit mode and material bootstrap.'
    },
    coreState: {
      description: 'Read-only state and DOM selectors around the current UI',
      candidates: {
        ToolAStateHelpers: !!window.ToolAStateHelpers,
        ToolACoreSelectors: !!window.ToolACoreSelectors,
        ToolAPanelEditContext: !!window.ToolAPanelEditContext,
        ToolAPanelFormState: !!window.ToolAPanelFormState,
        ToolAFooterDecisions: !!window.ToolAFooterDecisions,
        ToolAExtraPanelViewState: !!window.ToolAExtraPanelViewState,
        ensureStateShape: hasFn(window.ToolAStateHelpers, 'ensureStateShape'),
        getWizardSnapshot: hasFn(window.ToolACoreSelectors, 'getWizardSnapshot'),
        getPanelEditTargetId: hasFn(window.ToolAStateHelpers, 'getPanelEditTargetId'),
        getPanelEditContext: hasFn(window.ToolAPanelEditContext, 'getContext'),
        getPanelResetSnapshot: hasFn(window.ToolAPanelFormState, 'getResetSnapshot'),
        getPanelEditPrefillSnapshot: hasFn(window.ToolAPanelFormState, 'getEditPrefillSnapshot'),
        getExtraPanelPreviewSnapshot: hasFn(window.ToolAExtraPanelViewState, 'getPreviewSnapshot'),
        ToolAExtraPanelFormApply: !!window.ToolAExtraPanelFormApply,
        applyExtraPanelPrefill: hasFn(window.ToolAExtraPanelFormApply, 'applyPrefill'),
        applyExtraPanelReset: hasFn(window.ToolAExtraPanelFormApply, 'applyReset'),
        ToolAPanelUiState: !!window.ToolAPanelUiState,
        getPanelControlsState: hasFn(window.ToolAPanelUiState, 'getControlsState'),
        getCustomLabelState: hasFn(window.ToolAPanelUiState, 'getCustomLabelState'),
        ToolAPanelControlsApply: !!window.ToolAPanelControlsApply,
        applyPanelControlsState: hasFn(window.ToolAPanelControlsApply, 'apply'),
        getPanelEditGroupKey: hasFn(window.ToolAStateHelpers, 'getPanelEditGroupKey'),
        getPanelEditOriginalCount: hasFn(window.ToolAStateHelpers, 'getPanelEditOriginalCount')
      },
      safeForFirstCoreSplit: true,
      reason: 'Read-only selectors/helpers already live outside the core and are good mini-core split candidates.'
    },
    routeState: {
      description: 'Pure route state decisions without live navigation side effects',
      candidates: {
        ToolARouteState: !!window.ToolARouteState,
        normalizeStep: hasFn(window.ToolARouteState, 'normalizeStep'),
        getShowStepPlan: hasFn(window.ToolARouteState, 'getShowStepPlan'),
        getPrevStep: hasFn(window.ToolARouteState, 'getPrevStep'),
        getNextStep: hasFn(window.ToolARouteState, 'getNextStep'),
        getStepbarTarget: hasFn(window.ToolARouteState, 'getStepbarTarget')
      },
      safeForFirstCoreSplit: true,
      reason: 'Route normalization and prev/next/stepbar decisions are now separable while showStep live DOM flow stays inline.'
    },
    footerDecisions: {
      description: 'Pure footer button decision logic without DOM mutations',
      candidates: {
        ToolAFooterDecisions: !!window.ToolAFooterDecisions,
        ToolAFooterViewState: !!window.ToolAFooterViewState,
        ToolAFooterApply: !!window.ToolAFooterApply,
        ToolAExtraPanelViewState: !!window.ToolAExtraPanelViewState,
        getDecision: hasFn(window.ToolAFooterDecisions, 'getDecision'),
        getDecisionForStep: hasFn(window.ToolAFooterDecisions, 'getDecisionForStep'),
        getFooterViewState: hasFn(window.ToolAFooterViewState, 'getViewState'),
        applyFooterViewState: hasFn(window.ToolAFooterApply, 'applyViewState')
      },
      safeForFirstCoreSplit: true,
      reason: 'Footer decision state is now separable as pure read-only logic while the live footer DOM stays inline.'
    },
    validators: {
      description: 'Pure validation and normalization helpers without DOM mutations',
      candidates: {
        ToolAValidators: !!window.ToolAValidators,
        clampInt: hasFn(window.ToolAValidators, 'clampInt'),
        sanitizeValue: hasFn(window.ToolAValidators, 'sanitizeValue'),
        hasValidEmailShape: hasFn(window.ToolAValidators, 'hasValidEmailShape')
      },
      safeForFirstCoreSplit: true,
      reason: 'Small pure normalizers and validators are safe split candidates and help reduce inline rule duplication.'
    },
    customerValidation: {
      description: 'Customer-step required field decision layer without DOM invalid-state mutations',
      candidates: {
        ToolACustomerValidation: !!window.ToolACustomerValidation,
        getRequiredPlan: hasFn(window.ToolACustomerValidation, 'getRequiredPlan'),
        getInvalidMessage: hasFn(window.ToolACustomerValidation, 'getInvalidMessage')
      },
      safeForFirstCoreSplit: true,
      reason: 'Customer required-field rules are now separable while inline DOM invalid-state rendering stays in toolA.html.'
    },
    panelsViewModels: {
      description: 'Pure step-2 display models for material chips, extra panels and dock tabs',
      candidates: {
        ToolAPanelsViewModels: !!window.ToolAPanelsViewModels,
        ToolAPanelRowViewModels: !!window.ToolAPanelRowViewModels,
        getMaterialChipModels: hasFn(window.ToolAPanelsViewModels, 'getMaterialChipModels'),
        getPanelDockTabModel: hasFn(window.ToolAPanelsViewModels, 'getPanelDockTabModel'),
        getExtraPanelCardModels: hasFn(window.ToolAPanelsViewModels, 'getExtraPanelCardModels'),
        getCartGroupRowModel: hasFn(window.ToolAPanelRowViewModels, 'getCartGroupRowModel'),
        getExtraRowModel: hasFn(window.ToolAPanelRowViewModels, 'getExtraRowModel')
      },
      safeForFirstCoreSplit: true,
      reason: 'Display-only models are now separable without moving panel add/edit/reset mutations.'
    },
    extraPanelOverlay: {
      description: 'Extra-panel overlay option and preview read state without overlay mutations',
      candidates: {
        ToolAExtraPanelViewState: !!window.ToolAExtraPanelViewState,
        ToolAExtraPanelMutations: !!window.ToolAExtraPanelMutations,
        getMaterialOptionsState: hasFn(window.ToolAExtraPanelViewState, 'getMaterialOptionsState'),
        getPreviewSnapshot: hasFn(window.ToolAExtraPanelViewState, 'getPreviewSnapshot'),
        getExtraPanelEditPrefillSnapshot: hasFn(window.ToolAExtraPanelMutations, 'getEditPrefillSnapshot'),
        getExtraPanelResetFormState: hasFn(window.ToolAExtraPanelMutations, 'getResetFormState'),
        getExtraPanelUpsertPlan: hasFn(window.ToolAExtraPanelMutations, 'getUpsertPlan')
      },
      safeForFirstCoreSplit: true,
      reason: 'Overlay material options and preview snapshots are now separable without moving extra-panel upsert/reset mutations.'
    },
    panelMutations: {
      description: 'Standard panel add/update mutation adapter without moving step-2 live flow',
      candidates: {
        ToolAPanelMutations: !!window.ToolAPanelMutations,
        buildItem: hasFn(window.ToolAPanelMutations, 'buildItem'),
        getUpsertPlan: hasFn(window.ToolAPanelMutations, 'getUpsertPlan'),
        applyUpsert: hasFn(window.ToolAPanelMutations, 'applyUpsert')
      },
      safeForFirstCoreSplit: false,
      reason: 'Small mutation adapter is separable, but the live step-2 add/update flow still remains inline.'
    },
    panelSubmitFlow: {
      description: 'Standard panel submit flow adapter for mutation planning and post-submit actions',
      candidates: {
        ToolAPanelSubmitFlow: !!window.ToolAPanelSubmitFlow,
        clampCount: hasFn(window.ToolAPanelSubmitFlow, 'clampCount'),
        getMutationPlan: hasFn(window.ToolAPanelSubmitFlow, 'getMutationPlan'),
        getPostSubmitPlan: hasFn(window.ToolAPanelSubmitFlow, 'getPostSubmitPlan'),
        getSubmitPlan: hasFn(window.ToolAPanelSubmitFlow, 'getSubmitPlan')
      },
      safeForFirstCoreSplit: false,
      reason: 'Submit planning is now separable, but live validation, template fit checks and refresh timing still remain inline.'
    },
    panelBootstrapMutations: {
      description: 'Bootstrap/reset mutation adapter for step-2 selection and empty-material resets',
      candidates: {
        ToolAPanelBootstrapMutations: !!window.ToolAPanelBootstrapMutations,
        getBootstrapPlan: hasFn(window.ToolAPanelBootstrapMutations, 'getBootstrapPlan'),
        getNoMaterialsResetState: hasFn(window.ToolAPanelBootstrapMutations, 'getNoMaterialsResetState'),
        ToolAPanelBootstrapApply: !!window.ToolAPanelBootstrapApply,
        applyBootstrap: hasFn(window.ToolAPanelBootstrapApply, 'applyBootstrap'),
        applyNoMaterialsReset: hasFn(window.ToolAPanelBootstrapApply, 'applyNoMaterialsReset')
      },
      safeForFirstCoreSplit: false,
      reason: 'Bootstrap/reset planning is now separable, but live DOM dispatch, preview refresh and route timing remain inline.'
    },
    preview: {
      description: 'Template parsing and preview rendering helpers',
      candidates: {
        ToolATemplateHelpers: !!window.ToolATemplateHelpers,
        ToolATemplateViewHelpers: !!window.ToolATemplateViewHelpers,
        ToolARenderHelpers: !!window.ToolARenderHelpers,
        ToolAViewMathHelpers: !!window.ToolAViewMathHelpers,
      },
      safeForFirstCoreSplit: true,
      reason: 'Already separated enough; continue treating as safe outer layer, not sensitive core.'
    },
    uiInfra: {
      description: 'Alerts, overlays and misc UI infra',
      candidates: {
        ToolAAlertHelpers: !!window.ToolAAlertHelpers,
        ToolADomHelpers: !!window.ToolADomHelpers,
        ToolAMiscHelpers: !!window.ToolAMiscHelpers,
      },
      safeForFirstCoreSplit: true,
      reason: 'Stable helper layer, already proven safe.'
    }
  };

  function getMiniCoreSplitCandidates(){
    return [
      {
        name: 'Read-only panel edit selectors',
        from: 'toolA.html',
        target: 'core-read-state layer',
        notes: 'Only selectors/state readers, no mutation or route behavior.'
      },
      {
        name: 'Pure current-step readers',
        from: 'toolA.html / route-footer helpers',
        target: 'core-read-state layer',
        notes: 'Safe only if kept read-only and not allowed to trigger navigation.'
      },
      {
        name: 'Panel/material label derivation that still sits near core',
        from: 'toolA.html',
        target: 'existing state helper layer',
        notes: 'Acceptable if no step-2 bootstrap side effects are moved.'
      }
    ];
  }

  function getReport(){
    const report = {
      ts: new Date().toISOString(),
      coreReadyForDirectSplit: false,
      message: 'Core is not ready for direct split; only mini read-only core prep is currently safe.',
      globals: {
        state: hasVal('state'),
        panelDock: hasVal('panelDock'),
        panelDockLauncher: hasVal('panelDockLauncher'),
        ToolAEntry: hasVal('ToolAEntry'),
        ToolAPanelsEntry: hasVal('ToolAPanelsEntry'),
        ToolARouteFooter: hasVal('ToolARouteFooter')
      },
      domains,
      safeMiniCoreCandidates: getMiniCoreSplitCandidates()
    };
    report.ok = Object.values(report.globals).every(Boolean);
    return report;
  }

  function printReport(){
    const report = getReport();
    try {
      console.groupCollapsed('[ToolA Core Split Readiness] ' + (report.ok ? 'OK' : 'WARN'));
      console.log(report);
      console.groupEnd();
    } catch(_){ }
    return report;
  }

  window.ToolACoreSplitReadiness = { getReport, printReport };
})();

;try{ window.ToolACoreSplitReadiness && window.ToolACoreSplitReadiness.addNote && window.ToolACoreSplitReadiness.addNote('Panel dock read/filter state externalized.'); }catch(_){ }

;try{ window.ToolACoreSplitReadiness && window.ToolACoreSplitReadiness.addNote && window.ToolACoreSplitReadiness.addNote('Panel dock row display models externalized.'); }catch(_){ }

;try{ window.ToolACoreSplitReadiness && window.ToolACoreSplitReadiness.addNote && window.ToolACoreSplitReadiness.addNote('Extra-panel mutation adapter externalized for prefill/reset/upsert planning.'); }catch(_){ }

;try{ window.ToolACoreSplitReadiness && window.ToolACoreSplitReadiness.addNote && window.ToolACoreSplitReadiness.addNote('Standard panel mutation adapter externalized for item build + upsert planning.'); }catch(_){ }


;try{ window.ToolACoreSplitReadiness && window.ToolACoreSplitReadiness.addNote && window.ToolACoreSplitReadiness.addNote('Bootstrap/reset planning externalized for step-2 selection and empty-material fallback.'); }catch(_){ }


;try{ window.ToolACoreSplitReadiness && window.ToolACoreSplitReadiness.addNote && window.ToolACoreSplitReadiness.addNote('Route state decisions externalized for showStep normalization and prev/next/stepbar targeting.'); }catch(_){ }

;try{ window.ToolACoreSplitReadiness && window.ToolACoreSplitReadiness.addNote && window.ToolACoreSplitReadiness.addNote('Extra-panel submit planning externalized for validation + mutation + post-submit actions.'); }catch(_){ }
