@echo off
setlocal EnableExtensions
set "PYTHONDONTWRITEBYTECODE=1"
cd /d "%~dp0"
title METOD Worker
echo [METOD] Starting queue worker...
py -3 server_py.py --worker
echo.
echo [METOD] Worker stopped.
pause
