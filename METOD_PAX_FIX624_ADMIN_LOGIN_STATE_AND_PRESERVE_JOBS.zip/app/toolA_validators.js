(function(){
  const FIELD_RULES = {
    customLabelInput: { kind:'text', label:'paneelnaam' },
    extraName: { kind:'text', label:'omschrijving' },
    custFirstName: { kind:'text', label:'voornaam' },
    custLastName: { kind:'text', label:'achternaam' },
    custCompany: { kind:'text', label:'bedrijfsnaam' },
    custBillingAddress: { kind:'text', label:'straatnaam' },
    custShippingAddress: { kind:'text', label:'bezorgadres' },
    custPostcode: { kind:'postcode', label:'postcode' },
    custHouseNumber: { kind:'houseNumber', label:'huisnummer' }
  };

  function clone(value){
    try{ if(typeof structuredClone === 'function') return structuredClone(value); }catch(_){ }
    try{ return JSON.parse(JSON.stringify(value)); }catch(_){ return value; }
  }

  function clampInt(v, min, max){
    const n = parseInt(String(v == null ? '' : v).trim() || '0', 10);
    if(!Number.isFinite(n)) return min;
    return Math.max(min, Math.min(max, n));
  }

  function normalizeQty(v, fallback){
    const fb = Number.isFinite(Number(fallback)) ? Number(fallback) : 1;
    const trimmed = String(v == null ? '' : v).trim();
    if(trimmed === '') return fb;
    return clampInt(trimmed, 1, 999);
  }

  function sanitizeValue(value, kind){
    let s = String(value || '');
    s = s.replace(/[\x00-\x1F\x7F]/g, ' ');
    if(kind === 'email'){
      s = s.replace(/\s+/g, '');
      s = s.replace(/[^A-Za-z0-9@._+\-]/g, '');
      return s;
    }
    if(kind === 'postcode'){
      s = s.replace(/[^A-Za-z0-9 ]+/g, '').toUpperCase();
      s = s.replace(/\s+/g, ' ').trimStart();
      return s;
    }
    if(kind === 'houseNumber'){
      s = s.replace(/[^0-9A-Za-z \-]+/g, '');
      s = s.replace(/\s+/g, ' ').trimStart();
      return s;
    }
    s = s.replace(/[\/:*?"<>|@€$£¥~{}\[\]\^+=!]+/g, ' ');
    try{
      s = s.replace(/[^\p{L}\p{N} .,_-]/gu, '');
    }catch(_){
      s = s.replace(/[^A-Za-z0-9À-ÿ .,_-]/g, '');
    }
    s = s.replace(/\s+/g, ' ').trimStart();
    return s;
  }

  function getHintText(rule){
    if(!rule) return 'Gebruik alleen letters, cijfers, spaties en eenvoudige tekens zoals - , . of _.';
    if(rule.kind === 'email') return 'Gebruik een geldig e-mailadres. Letters, cijfers en tekens zoals @ . - _ en + zijn toegestaan.';
    if(rule.kind === 'postcode') return 'Gebruik alleen letters, cijfers en spaties in de postcode.';
    if(rule.kind === 'houseNumber') return 'Gebruik alleen cijfers, letters en een streepje in het huisnummer.';
    return 'Gebruik alleen letters, cijfers, spaties en eenvoudige tekens zoals - , . of _. Tekens zoals @ € ? ! / ^ < > $ £ ¥ ~ | \\ { } [ ] * + = en slimme aanhalingstekens zijn niet toegestaan.';
  }

  function hasValidEmailShape(value){
    const clean = sanitizeValue(value, 'email');
    return !!clean && /^[A-Za-z0-9._+\-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(clean);
  }

  function isRequiredValueReady(value, kind){
    const clean = sanitizeValue(value, kind || 'text');
    return !!String(clean || '').trim();
  }

  function getFieldRule(id){
    return FIELD_RULES[id] ? clone(FIELD_RULES[id]) : null;
  }

  window.ToolAValidators = {
    FIELD_RULES: clone(FIELD_RULES),
    getFieldRules(){ return clone(FIELD_RULES); },
    getFieldRule,
    clampInt,
    normalizeQty,
    sanitizeValue,
    getHintText,
    hasValidEmailShape,
    isRequiredValueReady
  };
})();
