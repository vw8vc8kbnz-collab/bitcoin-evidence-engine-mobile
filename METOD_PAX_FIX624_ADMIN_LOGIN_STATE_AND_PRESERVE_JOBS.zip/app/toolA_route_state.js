(function(){
  'use strict';

  const ALLOWED_STEPS = ['material','panels','grain','customer','overview'];

  function norm(v){ return v == null ? '' : String(v).trim(); }

  function normalizeStep(step){
    const s = norm(step);
    return ALLOWED_STEPS.includes(s) ? s : 'material';
  }

  function getShowStepPlan(input){
    const requestedStep = normalizeStep(input?.requestedStep);
    const prevStep = normalizeStep(input?.prevStep || 'material');
    const sameStep = prevStep === requestedStep;
    const priceLocked = !!input?.priceLocked;
    return {
      allowedSteps: ALLOWED_STEPS.slice(),
      requestedStep,
      prevStep,
      sameStep,
      blockedByPriceLock: priceLocked,
      shouldRememberDockBeforeLeave: prevStep === 'panels' && requestedStep !== 'panels',
      overviewReturnStep: requestedStep === 'overview'
        ? (['material','panels','grain','customer'].includes(prevStep) ? prevStep : 'customer')
        : null,
      shouldOpenGrain: requestedStep === 'grain',
      shouldOpenOverview: requestedStep === 'overview',
      shouldResetRightScroll: !sameStep && (requestedStep === 'material' || requestedStep === 'panels' || requestedStep === 'customer')
    };
  }

  function getPrevStep(currentStep, overviewReturnStep){
    const step = normalizeStep(currentStep);
    if(step === 'panels') return 'material';
    if(step === 'grain') return 'panels';
    if(step === 'customer') return 'grain';
    if(step === 'overview'){
      const ret = norm(overviewReturnStep);
      return ['material','panels','grain','customer'].includes(ret) ? ret : 'customer';
    }
    return 'material';
  }

  function getNextStep(currentStep, opts){
    const step = normalizeStep(currentStep);
    const hasMaterial = !!opts?.hasMaterial;
    const hasPanels = !!opts?.hasPanels;
    const customerValid = !!opts?.customerValid;
    if(step === 'material') return hasMaterial ? 'panels' : null;
    if(step === 'panels') return hasPanels ? 'grain' : null;
    if(step === 'customer') return customerValid ? 'overview' : null;
    return null;
  }

  function getStepbarTarget(step, opts){
    const target = normalizeStep(step);
    const hasMaterial = !!opts?.hasMaterial;
    const hasPanels = !!opts?.hasPanels;
    if(target === 'material') return 'material';
    if(target === 'panels') return hasMaterial ? 'panels' : null;
    if(target === 'grain' || target === 'customer' || target === 'overview') return hasPanels ? target : null;
    return null;
  }

  window.ToolARouteState = {
    ALLOWED_STEPS: ALLOWED_STEPS.slice(),
    normalizeStep,
    getShowStepPlan,
    getPrevStep,
    getNextStep,
    getStepbarTarget
  };
})();
