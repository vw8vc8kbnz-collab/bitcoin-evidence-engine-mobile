(function(){
  function toStr(v){ return v == null ? '' : String(v); }
  function toNum(v, fallback){
    const n = Number(v);
    return Number.isFinite(n) ? n : (fallback == null ? 0 : fallback);
  }
  function clone(value){
    try{
      if (typeof structuredClone === 'function') return structuredClone(value);
    }catch(_){ }
    try{ return JSON.parse(JSON.stringify(value)); }catch(_){ return value; }
  }
  function uniq(values){ return Array.from(new Set((values || []).filter(Boolean))); }

  function getMaterialChipModels(state, options){
    const s = state || window.state || {};
    const opts = options || {};
    const batches = Array.isArray(s.materialBatches) ? s.materialBatches : [];
    const activeKey = toStr(s.activeMaterialKey || '').trim();
    const titleForBatch = typeof opts.titleForBatch === 'function'
      ? opts.titleForBatch
      : (batch => toStr(batch?.mat?.productName || batch?.mat?.articleNumber || batch?.mat?.decorName || batch?.key || '').trim());
    return batches.map(batch => {
      const key = toStr(batch?.key || '').trim();
      const title = titleForBatch(batch);
      return {
        key,
        title,
        active: !!(key && key === activeKey),
        removeKey: key,
        batch: clone(batch)
      };
    });
  }

  function getExtraPanelsSummary(state){
    const s = state || window.state || {};
    const items = Array.isArray(s.extraPanels) ? s.extraPanels : [];
    return {
      lineCount: items.length,
      qtyCount: items.reduce((acc, item) => acc + Math.max(1, toNum(item?.qty, 1)), 0),
      hasItems: items.length > 0,
      items: clone(items)
    };
  }

  function getExtraPanelCardModels(state, options){
    const s = state || window.state || {};
    const opts = options || {};
    const materialLabelForKey = typeof opts.materialLabelForKey === 'function' ? opts.materialLabelForKey : (k => toStr(k));
    const edgeTextFor = typeof opts.edgeTextFor === 'function' ? opts.edgeTextFor : (() => '');
    const items = Array.isArray(s.extraPanels) ? s.extraPanels : [];
    return items.map((panel, index) => {
      const width = Math.round(toNum(panel?.w, 0));
      const height = Math.round(toNum(panel?.h, 0));
      const qty = Math.max(1, toNum(panel?.qty, 1));
      const title = toStr(panel?.name || '').trim() || `Overig paneel ${width}×${height}`;
      const materialKey = toStr(panel?.materialKey || panel?.material || '').trim();
      const materialLabel = materialLabelForKey(materialKey);
      const edgeText = edgeTextFor(panel?.edge || 'none', width, height);
      return {
        index,
        id: panel?.id || null,
        qty,
        width,
        height,
        title,
        materialKey,
        materialLabel,
        articleNumber: toStr(panel?.articleNumber || '').trim(),
        edgeText,
        line2: `${qty}× · ${width}×${height} mm · ${materialLabel} · Artikel: ${toStr(panel?.articleNumber || '').trim()} · Kantenband: ${edgeText}`,
        panel: clone(panel)
      };
    });
  }

  function getPanelDockTabModel(state, options){
    const s = state || window.state || {};
    const opts = options || {};
    const getMaterialName = typeof opts.getMaterialName === 'function' ? opts.getMaterialName : (k => toStr(k));
    const cart = Array.isArray(s.cart) ? s.cart : [];
    const extraPanels = Array.isArray(s.extraPanels) ? s.extraPanels : [];
    const matKeys = uniq([
      ...cart.map(it => toStr(it?.materialKey || '').trim()),
      ...extraPanels.map(it => toStr(it?.materialKey || it?.material || '').trim())
    ]);
    const ui = s.ui || {};
    const preferredTab = ui.panelDockTab === 'material' && ui.panelDockMaterialKey ? 'material' : 'all';
    const resolvedKey = matKeys.includes(toStr(ui.panelDockMaterialKey || '').trim()) ? toStr(ui.panelDockMaterialKey || '').trim() : (matKeys[0] || null);
    const chips = [{ type:'all', label:'Alle onderdelen', active: preferredTab === 'all' }];
    matKeys.forEach(key => {
      chips.push({ type:'material', key, label:getMaterialName(key), active: preferredTab === 'material' && key === resolvedKey });
    });
    return {
      visible: matKeys.length > 1,
      materialKeys: matKeys,
      selectedTab: preferredTab,
      selectedMaterialKey: resolvedKey,
      chips
    };
  }

  window.ToolAPanelsViewModels = {
    getMaterialChipModels,
    getExtraPanelsSummary,
    getExtraPanelCardModels,
    getPanelDockTabModel
  };
})();
