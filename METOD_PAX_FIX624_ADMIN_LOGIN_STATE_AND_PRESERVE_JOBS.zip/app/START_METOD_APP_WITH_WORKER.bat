@echo off
setlocal EnableExtensions
set "PYTHONDONTWRITEBYTECODE=1"
cd /d "%~dp0"
title METOD Launcher (Server + Worker)
echo.
echo [METOD] Starting server...
start "METOD Server" cmd /k "py -3 server_py.py"
timeout /t 1 >nul
echo [METOD] Starting worker...
start "METOD Worker" cmd /k "py -3 server_py.py --worker"
timeout /t 1 >nul
echo [METOD] Opening Tool A in browser...
start "" "http://127.0.0.1:8787/"
echo.
echo [METOD] Done. Close the server/worker windows to stop.
endlocal
