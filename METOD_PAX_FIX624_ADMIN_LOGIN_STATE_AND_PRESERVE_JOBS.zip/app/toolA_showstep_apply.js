(function(){
  function fallbackEnterPanelsStep(ctx){
    try{ ctx.ensureCustomLabelHook && ctx.ensureCustomLabelHook(); }catch(_){ }
    try{ ctx.refreshCustomLabelVisibility && ctx.refreshCustomLabelVisibility(); }catch(_){ }
    try{ ctx.syncDefaultPanelTypeSelection && ctx.syncDefaultPanelTypeSelection(); }catch(_){ }
    try{ ctx.enableControlsIfReady && ctx.enableControlsIfReady(); }catch(_){ }
    try{
      const hasMat = !!(ctx.state && ctx.state.activeMaterialKey);
      if(hasMat && ctx.bootstrapPanelSelectionForActiveMaterial){
        const forceBootstrap = !!window.__forcePanelBootstrap;
        try{ ctx.bootstrapPanelSelectionForActiveMaterial(forceBootstrap); }catch(_){ }
        window.__forcePanelBootstrap = false;
      }
    }catch(_){ }
    try{ if(ctx.typeSel && typeof ctx.typeSel.__appleSync === 'function') ctx.typeSel.__appleSync(); }catch(_){ }
    try{ if(ctx.sizeSel && typeof ctx.sizeSel.__appleSync === 'function') ctx.sizeSel.__appleSync(); }catch(_){ }
    try{
      if(ctx.panelDock){ ctx.panelDock.style.display = 'flex'; }
      if(ctx.panelDockLauncher){ ctx.panelDockLauncher.style.display = 'inline-flex'; }
      const cartCount = Array.isArray(ctx.state?.cart) ? ctx.state.cart.length : 0;
      const extraCount = Array.isArray(ctx.state?.extraPanels)
        ? ctx.state.extraPanels.reduce((a,p)=> a + Math.max(1, Number(p?.qty)||1), 0)
        : 0;
      const dockTotal = cartCount + extraCount;
      const shouldRestoreDock = dockTotal > 0 && (ctx.prevStep === 'grain' || ctx.prevStep === 'overview') && !!window.__panelDockWasOpenBeforeRoute;
      if(typeof ctx.setPanelDockOpen === 'function'){
        if(shouldRestoreDock) ctx.setPanelDockOpen(true);
        else if(!dockTotal) ctx.setPanelDockOpen(false);
      }
    }catch(_){ }
  }

  function handlePanelsEnter(ctx){
    if(ctx.step !== 'panels') return;
    try{
      if(window.ToolAPanelsEntry && typeof window.ToolAPanelsEntry.onEnterPanelsStep === 'function'){
        window.ToolAPanelsEntry.onEnterPanelsStep(ctx.prevStep);
        return;
      }
    }catch(_){ }
    fallbackEnterPanelsStep(ctx);
  }

  function applyRightScroll(ctx){
    try{
      if(!ctx.rightScroll) return;
      if(ctx.sameStep){
        ctx.rightScroll.scrollTop = ctx.prevRightScrollTop || 0;
        if(typeof ctx.stabilizeRightScroll === 'function') ctx.stabilizeRightScroll(14);
      }else if((ctx.routePlan && ctx.routePlan.shouldResetRightScroll) || ctx.step==='material' || ctx.step==='panels' || ctx.step==='customer'){
        ctx.rightScroll.scrollTop = 0;
      }
    }catch(_){ }
  }

  function execute(ctx){
    try{ if(ctx.step !== 'grain' && typeof ctx.closeGrain === 'function') ctx.closeGrain(); }catch(_){ }
    try{ if(ctx.step !== 'overview' && typeof ctx.closeOverview === 'function') ctx.closeOverview(); }catch(_){ }
    try{ if(typeof ctx.setStep === 'function') ctx.setStep(ctx.step); }catch(_){ }
    try{ if(typeof ctx.renderFooterForStep === 'function') ctx.renderFooterForStep(ctx.step); }catch(_){ }
    try{ if(typeof ctx.syncPanelDockChrome === 'function') ctx.syncPanelDockChrome(); }catch(_){ }
    handlePanelsEnter(ctx);
    applyRightScroll(ctx);
    try{
      if(ctx.step === 'grain' && typeof ctx.openGrain === 'function'){
        ctx.openGrain();
        return { didOpenStepOverlay: true };
      }
      if(ctx.step === 'overview' && typeof ctx.openOverview === 'function'){
        ctx.openOverview();
        return { didOpenStepOverlay: true };
      }
    }catch(_){ }
    return { didOpenStepOverlay: false };
  }

  window.ToolAShowStepApply = {
    execute,
    handlePanelsEnter,
    applyRightScroll
  };
})();
