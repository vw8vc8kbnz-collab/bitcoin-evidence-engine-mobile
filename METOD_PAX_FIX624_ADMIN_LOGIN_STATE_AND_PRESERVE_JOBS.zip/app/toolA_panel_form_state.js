(function(){
  function toStr(v){ return v == null ? '' : String(v); }
  function toNum(v, fallback){
    const n = Number(v);
    return Number.isFinite(n) ? n : (fallback == null ? 0 : fallback);
  }

  function getResetSnapshot(opts){
    const o = opts || {};
    const hingeValue = toStr(o.hingeValue || o.currentHingeValue || 'left').trim() || 'left';
    return {
      qty: 1,
      extTop: 0,
      extBot: 0,
      hinge: hingeValue,
      customLabel: '',
      clearEdit: true
    };
  }

  function getEditPrefillSnapshot(item, opts){
    const it = item || {};
    const o = opts || {};
    const originalCount = Math.max(1, Math.round(toNum(o.originalCount, 1)));
    return {
      type: toStr(it.type).trim(),
      templateId: toStr(it.templateId).trim(),
      qty: originalCount,
      hinge: toStr(it.hinge || 'left').trim() || 'left',
      extTop: toNum(it.extTop, 0),
      extBot: toNum(it.extBot, 0),
      customLabel: (function(){
        const custom = toStr(it.customName || it.customLabel).trim();
        if(custom) return custom;
        const label = toStr(it.label).trim();
        const base = toStr(it.baseLabel || it.templateId).trim();
        return (label && label != base) ? label : '';
      })(),
      showStep: 'panels'
    };
  }

  function getPrefillDispatchPlan(snapshot){
    const snap = snapshot || getEditPrefillSnapshot();
    return {
      dispatchTypeChange: !!snap.type,
      dispatchSizeChange: !!snap.templateId,
      dispatchQtyInput: true,
      dispatchHingeChange: true,
      dispatchExtTopInput: true,
      dispatchExtBotInput: true,
      dispatchCustomLabelInput: true,
      showStep: toStr(snap.showStep || 'panels').trim() || 'panels'
    };
  }

  window.ToolAPanelFormState = {
    getResetSnapshot,
    getEditPrefillSnapshot,
    getPrefillDispatchPlan
  };
})();
