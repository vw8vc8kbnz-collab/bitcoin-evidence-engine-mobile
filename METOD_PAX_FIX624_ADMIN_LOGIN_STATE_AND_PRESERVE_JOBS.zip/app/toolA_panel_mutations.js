(function(){
  function toStr(v){ return v == null ? '' : String(v); }
  function toNum(v, fallback){
    const n = Number(v);
    return Number.isFinite(n) ? n : (fallback == null ? 0 : fallback);
  }
  function bool(v){ return !!v; }

  function buildItem(input){
    const i = input || {};
    return {
      id: toStr(i.id || ''),
      templateId: toStr(i.templateId || ''),
      label: toStr(i.label || ''),
      baseLabel: toStr(i.baseLabel || ''),
      customLabel: toStr(i.customLabel || ''),
      customName: toStr(i.customName || ''),
      type: toStr(i.type || ''),
      kind: toStr(i.kind || ''),
      supportsHinge: bool(i.supportsHinge),
      qty: Math.max(1, Math.round(toNum(i.qty, 1))),
      hinge: toStr(i.hinge || ''),
      extTop: toNum(i.extTop, 0),
      extBot: toNum(i.extBot, 0),
      material: toStr(i.material || i.decorName || ''),
      materialCode: toStr(i.materialCode || ''),
      articleNumber: toStr(i.articleNumber || ''),
      materialKey: toStr(i.materialKey || ''),
      decorName: toStr(i.decorName || i.material || ''),
      thicknessMm: toNum(i.thicknessMm, 18),
      rotationAllowed: bool(i.rotationAllowed),
      edge: toStr(i.edge || 'none') || 'none',
      cmW: toNum(i.cmW, 0),
      cmH: toNum(i.cmH, 0),
      realW: toNum(i.realW, 0),
      realH: toNum(i.realH, 0)
    };
  }

  function getUpsertPlan(opts){
    const o = opts || {};
    const count = Math.max(1, Math.round(toNum(o.count, 1)));
    const editId = toStr(o.editId || '');
    const editGroupKey = toStr(o.editGroupKey || '');
    return {
      mode: editGroupKey ? 'replace-group' : (editId ? 'replace' : 'append'),
      editId,
      editGroupKey,
      count,
      idPrefix: toStr(o.idPrefix || ''),
      timestamp: toNum(o.timestamp, Date.now()) || Date.now()
    };
  }

  function makeId(plan, index){
    return `${toStr(plan.idPrefix || 'panel')}_${toNum(plan.timestamp, Date.now())}_${Math.max(1, toNum(index, 1))}`;
  }

  function groupKeyForItem(it){
    try{
      const hinge = (it && (it.type==='deur' || it.type==='pax_deur' || it.supportsHinge || it.kind==='Hoekkast')) ? String(it.hinge||'') : '';
      const customName = String(it?.customName || it?.customLabel || '').trim();
      const effectiveName = customName || String(it?.label || it?.baseLabel || it?.templateId || '');
      return [
        String(it?.type||''),
        String(it?.materialKey||it?.materialCode||it?.articleNumber||''),
        String(it?.baseLabel||it?.label||it?.templateId||''),
        effectiveName,
        String(Number(it?.cmW ?? Math.round(Number(it?.realW||0)))||0),
        String(Number(it?.cmH ?? Math.round(Number(it?.realH||0)))||0),
        String(Number(it?.extTop||0)||0),
        String(Number(it?.extBot||0)||0),
        hinge
      ].join('||');
    }catch(_){ return String(it?.id||''); }
  }

  function applyUpsert(previousItems, itemInput, planInput){
    const arr = Array.isArray(previousItems) ? previousItems.slice() : [];
    const plan = planInput || getUpsertPlan();
    const item = buildItem(itemInput);
    if(plan.mode === 'replace-group' && plan.editGroupKey){
      const kept = arr.filter(x => groupKeyForItem(x) !== String(plan.editGroupKey));
      const added = [];
      for(let i = 0; i < plan.count; i++){
        const nextItem = { ...item, id: makeId(plan, i + 1) };
        kept.push(nextItem);
        added.push(nextItem);
      }
      return { items: kept, mode: 'replace-group', addedCount: added.length, added };
    }
    if(plan.mode === 'replace' && plan.editId){
      const idx = arr.findIndex(x => String(x?.id || '') === String(plan.editId));
      if(idx >= 0){
        const prev = arr[idx] || {};
        const nextItem = { ...prev, ...item, id: prev.id || plan.editId };
        arr[idx] = nextItem;
        return { items: arr, mode: 'replace', replaced: true, item: nextItem, index: idx };
      }
      const appended = { ...item, id: item.id || makeId(plan, 1) };
      arr.push(appended);
      return { items: arr, mode: 'replace-fallback-append', replaced: false, item: appended, index: arr.length - 1 };
    }
    const added = [];
    for(let i = 0; i < plan.count; i++){
      const nextItem = { ...item, id: makeId(plan, i + 1) };
      arr.push(nextItem);
      added.push(nextItem);
    }
    return { items: arr, mode: 'append', addedCount: added.length, added };
  }

  window.ToolAPanelMutations = {
    buildItem,
    getUpsertPlan,
    applyUpsert,
    groupKeyForItem
  };
})();
