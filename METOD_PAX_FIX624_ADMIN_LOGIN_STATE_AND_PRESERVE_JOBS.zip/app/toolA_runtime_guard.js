/* FIX326: Tool A runtime guard
   Non-invasive runtime audit for helper/view layers.
   Does not change wizard behavior; only reports readiness.
*/
(function(){
  function hasFn(obj, name){ return !!(obj && typeof obj[name] === 'function'); }
  function collect(){
    const report = {
      ts: new Date().toISOString(),
      layers: {
        safeHelpers: {
          present: !!window.ToolAStateHelpers && !!window.ToolAAlertHelpers && !!window.ToolADomHelpers && !!window.ToolATemplateHelpers && !!window.ToolAMiscHelpers,
          details: {
            ToolAStateHelpers: !!window.ToolAStateHelpers,
            ToolAAlertHelpers: !!window.ToolAAlertHelpers,
            ToolADomHelpers: !!window.ToolADomHelpers,
            ToolATemplateHelpers: !!window.ToolATemplateHelpers,
            ToolAMiscHelpers: !!window.ToolAMiscHelpers,
          }
        },
        safeView: {
          present: !!window.ToolAViewMathHelpers && !!window.ToolARenderHelpers && !!window.ToolATemplateViewHelpers,
          details: {
            ToolAViewMathHelpers: !!window.ToolAViewMathHelpers,
            ToolARenderHelpers: !!window.ToolARenderHelpers,
            ToolATemplateViewHelpers: !!window.ToolATemplateViewHelpers,
          }
        },
        sensitive: {
          ToolAEntry: !!window.ToolAEntry,
          ToolAPanelsEntry: !!window.ToolAPanelsEntry,
          ToolARouteFooter: !!window.ToolARouteFooter,
        }
      },
      exports: {
        state: {
          ensureStateShape: hasFn(window.ToolAStateHelpers,'ensureStateShape'),
          refreshExtraMaterialOptions: hasFn(window.ToolAStateHelpers,'refreshExtraMaterialOptions'),
        },
        alerts: {
          showToolAlert: hasFn(window.ToolAAlertHelpers,'showToolAlert'),
          closeToolAlert: hasFn(window.ToolAAlertHelpers,'closeToolAlert'),
        },
        dom: {
          setOverlayVisible: hasFn(window.ToolADomHelpers,'setOverlayVisible'),
          hideAllOverlays: hasFn(window.ToolADomHelpers,'hideAllOverlays'),
        },
        template: {
          parseDXFMinimal: hasFn(window.ToolATemplateHelpers,'parseDXFMinimal'),
          buildTemplate: hasFn(window.ToolATemplateHelpers,'buildTemplate'),
        },
        misc: {
          moneyEUR: hasFn(window.ToolAMiscHelpers,'moneyEUR'),
          showSavingToast: hasFn(window.ToolAMiscHelpers,'showSavingToast'),
        },
        render: {
          drawEmpty: hasFn(window.ToolARenderHelpers,'drawEmpty'),
        },
        templateView: {
          dxfBBox: hasFn(window.ToolATemplateViewHelpers,'dxfBBox'),
          mirrorX: hasFn(window.ToolATemplateViewHelpers,'mirrorX'),
        },
        coreSelectors: {
          getCurrentStep: hasFn(window.ToolACoreSelectors,'getCurrentStep'),
          getPanelFormSnapshot: hasFn(window.ToolACoreSelectors,'getPanelFormSnapshot'),
          getWizardSnapshot: hasFn(window.ToolACoreSelectors,'getWizardSnapshot'),
        },
        panelEditContext: {
          getContext: hasFn(window.ToolAPanelEditContext,'getContext'),
          isEditingGroup: hasFn(window.ToolAPanelEditContext,'isEditingGroup'),
          getAddButtonState: hasFn(window.ToolAPanelEditContext,'getAddButtonState'),
        },
        footerViewState: {
          getViewState: hasFn(window.ToolAFooterViewState,'getViewState'),
          normalizeDecision: hasFn(window.ToolAFooterViewState,'normalizeDecision'),
        },
        footerApply: {
          ensureButtons: hasFn(window.ToolAFooterApply,'ensureButtons'),
          applyViewState: hasFn(window.ToolAFooterApply,'applyViewState'),
        },
        panelFormState: {
          getResetSnapshot: hasFn(window.ToolAPanelFormState,'getResetSnapshot'),
          getEditPrefillSnapshot: hasFn(window.ToolAPanelFormState,'getEditPrefillSnapshot'),
          getPrefillDispatchPlan: hasFn(window.ToolAPanelFormState,'getPrefillDispatchPlan'),
        },
        panelFormApply: {
          applyPrefill: hasFn(window.ToolAPanelFormApply,'applyPrefill'),
          applyReset: hasFn(window.ToolAPanelFormApply,'applyReset'),
        },
        typeSizeDecisions: {
          getPreferredPanelType: hasFn(window.ToolATypeSizeDecisions,'getPreferredPanelType'),
          getSizeOptionGroups: hasFn(window.ToolATypeSizeDecisions,'getSizeOptionGroups'),
          getPreferredTemplateId: hasFn(window.ToolATypeSizeDecisions,'getPreferredTemplateId'),
          getTypeSizeUiState: hasFn(window.ToolATypeSizeDecisions,'getTypeSizeUiState'),
        },
        footerDecisions: {
          getDecision: hasFn(window.ToolAFooterDecisions,'getDecision'),
          getDecisionForStep: hasFn(window.ToolAFooterDecisions,'getDecisionForStep'),
        },
        extraPanelViewState: {
          getMaterialOptionsState: hasFn(window.ToolAExtraPanelViewState,'getMaterialOptionsState'),
          getPreviewSnapshot: hasFn(window.ToolAExtraPanelViewState,'getPreviewSnapshot'),
        },
        extraPanelMutations: {
          getEditPrefillSnapshot: hasFn(window.ToolAExtraPanelMutations,'getEditPrefillSnapshot'),
          getResetFormState: hasFn(window.ToolAExtraPanelMutations,'getResetFormState'),
          buildItem: hasFn(window.ToolAExtraPanelMutations,'buildItem'),
          getUpsertPlan: hasFn(window.ToolAExtraPanelMutations,'getUpsertPlan'),
          applyUpsert: hasFn(window.ToolAExtraPanelMutations,'applyUpsert'),
        },
        extraPanelFormApply: {
          applyPrefill: hasFn(window.ToolAExtraPanelFormApply,'applyPrefill'),
          applyReset: hasFn(window.ToolAExtraPanelFormApply,'applyReset'),
        },
        extraPanelSubmitFlow: {
          clampQty: hasFn(window.ToolAExtraPanelSubmitFlow,'clampQty'),
          getValidation: hasFn(window.ToolAExtraPanelSubmitFlow,'getValidation'),
          getMutationPlan: hasFn(window.ToolAExtraPanelSubmitFlow,'getMutationPlan'),
          getPostSubmitPlan: hasFn(window.ToolAExtraPanelSubmitFlow,'getPostSubmitPlan'),
          getSubmitPlan: hasFn(window.ToolAExtraPanelSubmitFlow,'getSubmitPlan'),
        },
        panelMutations: {
          buildItem: hasFn(window.ToolAPanelMutations,'buildItem'),
          getUpsertPlan: hasFn(window.ToolAPanelMutations,'getUpsertPlan'),
          applyUpsert: hasFn(window.ToolAPanelMutations,'applyUpsert'),
        },
        panelSubmitFlow: {
          clampCount: hasFn(window.ToolAPanelSubmitFlow,'clampCount'),
          getMutationPlan: hasFn(window.ToolAPanelSubmitFlow,'getMutationPlan'),
          getPostSubmitPlan: hasFn(window.ToolAPanelSubmitFlow,'getPostSubmitPlan'),
          getSubmitPlan: hasFn(window.ToolAPanelSubmitFlow,'getSubmitPlan'),
        },
        panelBootstrapMutations: {
          getBootstrapPlan: hasFn(window.ToolAPanelBootstrapMutations,'getBootstrapPlan'),
          getNoMaterialsResetState: hasFn(window.ToolAPanelBootstrapMutations,'getNoMaterialsResetState'),
        },
        customerValidation: {
          getRequiredPlan: hasFn(window.ToolACustomerValidation,'getRequiredPlan'),
          getInvalidMessage: hasFn(window.ToolACustomerValidation,'getInvalidMessage'),
        },

        materialBatchMutations: {
          getPlan: hasFn(window.ToolAMaterialBatchMutations,'getPlan'),
          filterByMaterial: hasFn(window.ToolAMaterialBatchMutations,'filterByMaterial')
        },
        panelUiState: {
          getControlsState: hasFn(window.ToolAPanelUiState,'getControlsState'),
          resolveTypeKind: hasFn(window.ToolAPanelUiState,'resolveTypeKind'),
          getCustomLabelState: hasFn(window.ToolAPanelUiState,'getCustomLabelState'),
        },
        panelControlsApply: {
          normalizeControlsState: hasFn(window.ToolAPanelControlsApply,'normalizeControlsState'),
          apply: hasFn(window.ToolAPanelControlsApply,'apply'),
        },
        validators: {
          clampInt: hasFn(window.ToolAValidators,'clampInt'),
          sanitizeValue: hasFn(window.ToolAValidators,'sanitizeValue'),
          hasValidEmailShape: hasFn(window.ToolAValidators,'hasValidEmailShape'),
        },
        panelsViewModels: {
          getMaterialChipModels: hasFn(window.ToolAPanelsViewModels,'getMaterialChipModels'),
          getPanelDockTabModel: hasFn(window.ToolAPanelsViewModels,'getPanelDockTabModel'),
          getExtraPanelCardModels: hasFn(window.ToolAPanelsViewModels,'getExtraPanelCardModels'),
        },
        panelRowViewModels: {
          getCartGroupRowModel: hasFn(window.ToolAPanelRowViewModels,'getCartGroupRowModel'),
          getExtraRowModel: hasFn(window.ToolAPanelRowViewModels,'getExtraRowModel'),
        },
        viewMath: {
          polygonArea: hasFn(window.ToolAViewMathHelpers,'polygonArea'),
          computeBounds: hasFn(window.ToolAViewMathHelpers,'computeBounds'),
        }
      }
    };
    report.ok = Object.values(report.exports).every(group => Object.values(group).every(Boolean));
    return report;
  }

  function printReport(){
    const report = collect();
    try{
      console.groupCollapsed('[ToolA Runtime Guard] ' + (report.ok ? 'OK' : 'WARN'));
      console.log(report);
      console.groupEnd();
    }catch(_){ }
    return report;
  }

  window.ToolARuntimeGuard = { getReport: collect, printReport: printReport };

  try{
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      setTimeout(printReport, 0);
    } else {
      document.addEventListener('DOMContentLoaded', function(){ setTimeout(printReport, 0); }, { once:true });
    }
  }catch(_){ }
})();

;try{ window.ToolARuntimeGuard && window.ToolARuntimeGuard.addCheck && window.ToolARuntimeGuard.addCheck('ToolAPanelDockState', function(){ return !!(window.ToolAPanelDockState && typeof window.ToolAPanelDockState.getTabState === 'function'); }); }catch(_){ }

;try{ window.ToolARuntimeGuard && window.ToolARuntimeGuard.addCheck && window.ToolARuntimeGuard.addCheck('ToolAPanelRowViewModels', function(){ return !!(window.ToolAPanelRowViewModels && typeof window.ToolAPanelRowViewModels.getCartGroupRowModel === 'function'); }); }catch(_){ }

;try{ window.ToolARuntimeGuard && window.ToolARuntimeGuard.addCheck && window.ToolARuntimeGuard.addCheck('ToolAExtraPanelMutations', function(){ return !!(window.ToolAExtraPanelMutations && typeof window.ToolAExtraPanelMutations.applyUpsert === 'function'); }); }catch(_){ }

;try{ window.ToolARuntimeGuard && window.ToolARuntimeGuard.addCheck && window.ToolARuntimeGuard.addCheck('ToolAExtraPanelSubmitFlow', function(){ return !!(window.ToolAExtraPanelSubmitFlow && typeof window.ToolAExtraPanelSubmitFlow.getSubmitPlan === 'function'); }); }catch(_){ }

;try{ window.ToolARuntimeGuard && window.ToolARuntimeGuard.addCheck && window.ToolARuntimeGuard.addCheck('ToolAMaterialBatchMutations', function(){ return !!(window.ToolAMaterialBatchMutations && typeof window.ToolAMaterialBatchMutations.getPlan === 'function'); }); }catch(_){ }

;try{ window.ToolARuntimeGuard && window.ToolARuntimeGuard.addCheck && window.ToolARuntimeGuard.addCheck('ToolAGrainValidation', function(){ return !!(window.ToolAGrainValidation && typeof window.ToolAGrainValidation.getDropValidation === 'function'); }); }catch(_){ }
