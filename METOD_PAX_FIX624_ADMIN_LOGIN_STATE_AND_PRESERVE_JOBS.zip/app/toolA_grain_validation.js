(function(){
  function num(v){
    const n = Number(v||0);
    return Number.isFinite(n) ? n : 0;
  }

  function noGrainMessage(){
    return 'Dit paneel heeft geen doorlopende houtnerf.';
  }

  function incompatibleWidthMessage(groupWidthCm, itemWidthCm){
    return `Kan niet: sleep alleen panelen met dezelfde breedte in dezelfde nerf-set. Deze set is ${num(groupWidthCm)} cm breed en dit paneel is ${num(itemWidthCm)} cm breed.`;
  }

  function getDropValidation(input){
    const cfg = input && typeof input === 'object' ? input : {};
    if(!cfg.isGrainCapable){
      return { ok:false, code:'not_grain_capable', message:noGrainMessage() };
    }
    const groupWidthCm = num(cfg.groupWidthCm);
    const itemWidthCm = num(cfg.itemWidthCm);
    if(groupWidthCm && groupWidthCm !== itemWidthCm){
      return { ok:false, code:'width_mismatch', message:incompatibleWidthMessage(groupWidthCm, itemWidthCm) };
    }
    return { ok:true, code:'ok', message:'' };
  }

  function panelTooLargeMessage(input){
    const cfg = input && typeof input === 'object' ? input : {};
    const label = String(cfg.label || 'paneel');
    return `Paneel '${label}' past niet op de plaat (${Math.round(num(cfg.panelWidthMm))}×${Math.round(num(cfg.panelHeightMm))}mm > ${Math.round(num(cfg.usableWidthMm))}×${Math.round(num(cfg.usableHeightMm))}mm bruikbaar, marge ${num(cfg.marginMm)}mm).`;
  }

  function mixedWidthsMessage(groupId){
    return `Doorlopende nerf groep ${String(groupId||'')} bevat panelen met verschillende breedtes. Alleen panelen met dezelfde breedte kunnen een nerf-set vormen.`;
  }

  function totalTooLongMessage(groupId, totalHeightMm, usableHeightMm, marginMm){
    return `Doorlopende nerf groep ${String(groupId||'')} is te lang voor de plaathoogte (${Math.round(num(totalHeightMm))}mm > ${Math.round(num(usableHeightMm))}mm bruikbaar, marge ${num(marginMm)}mm).`;
  }

  function groupTooWideMessage(groupId, maxWidthMm, usableWidthMm, marginMm){
    return `Doorlopende nerf groep ${String(groupId||'')} is te breed voor de plaatbreedte (${Math.round(num(maxWidthMm))}mm > ${Math.round(num(usableWidthMm))}mm bruikbaar, marge ${num(marginMm)}mm).`;
  }

  function getGroupValidation(input){
    const cfg = input && typeof input === 'object' ? input : {};
    if(cfg.panelWidthMm != null && cfg.panelHeightMm != null){
      if(num(cfg.panelWidthMm) > num(cfg.usableWidthMm) + 0.01 || num(cfg.panelHeightMm) > num(cfg.usableHeightMm) + 0.01){
        return { ok:false, code:'panel_too_large', message:panelTooLargeMessage(cfg) };
      }
    }
    const uniqueWidths = Array.isArray(cfg.uniqueWidths) ? Array.from(new Set(cfg.uniqueWidths.map(num))) : [];
    if(uniqueWidths.length > 1){
      return { ok:false, code:'mixed_widths', message:mixedWidthsMessage(cfg.groupId) };
    }
    if(cfg.totalHeightMm != null && num(cfg.totalHeightMm) > num(cfg.usableHeightMm) + 0.01){
      return { ok:false, code:'too_long', message:totalTooLongMessage(cfg.groupId, cfg.totalHeightMm, cfg.usableHeightMm, cfg.marginMm) };
    }
    if(cfg.maxWidthMm != null && num(cfg.maxWidthMm) > num(cfg.usableWidthMm) + 0.01){
      return { ok:false, code:'too_wide', message:groupTooWideMessage(cfg.groupId, cfg.maxWidthMm, cfg.usableWidthMm, cfg.marginMm) };
    }
    return { ok:true, code:'ok', message:'' };
  }

  function getIncompleteSetAlert(){
    return {
      title: 'Nerf-set nog niet compleet',
      body: 'Sleep minimaal 2 panelen in een nerf-set.',
      details: 'Sleep nog een paneel met dezelfde breedte naar deze set.'
    };
  }

  window.ToolAGrainValidation = {
    noGrainMessage,
    incompatibleWidthMessage,
    getDropValidation,
    panelTooLargeMessage,
    mixedWidthsMessage,
    totalTooLongMessage,
    groupTooWideMessage,
    getGroupValidation,
    getIncompleteSetAlert
  };
})();
