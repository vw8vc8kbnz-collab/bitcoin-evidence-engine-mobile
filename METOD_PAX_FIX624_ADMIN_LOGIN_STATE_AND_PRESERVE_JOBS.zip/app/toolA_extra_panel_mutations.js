(function(){
  function toStr(v){ return v == null ? '' : String(v); }
  function toNum(v, fallback){
    const n = Number(v);
    return Number.isFinite(n) ? n : (fallback == null ? 0 : fallback);
  }

  function getEditPrefillSnapshot(panel, opts){
    const p = panel || {};
    return {
      editIndex: Number.isFinite(Number(opts?.index)) ? Number(opts.index) : null,
      showEditHint: true,
      buttonLabel: '✓ Wijzigingen opslaan',
      name: toStr(p.name),
      w: toNum(p.w, ''),
      h: toNum(p.h, ''),
      qty: Math.max(1, toNum(p.qty, 1)),
      materialKey: toStr(p.materialKey || p.material),
      edge: toStr(p.edge || 'none') || 'none'
    };
  }

  function getResetFormState(opts){
    return {
      editIndex: null,
      showEditHint: false,
      buttonLabel: toStr(opts?.buttonLabel || '+ Toevoegen') || '+ Toevoegen',
      name: '',
      w: '',
      h: '',
      qty: '1',
      edge: toStr(opts?.defaultEdge || 'none') || 'none'
    };
  }

  function buildItem(input){
    const i = input || {};
    return {
      name: toStr(i.name || ''),
      w: Math.round(toNum(i.w, 0)),
      h: Math.round(toNum(i.h, 0)),
      qty: Math.max(1, Math.round(toNum(i.qty, 1))),
      materialKey: toStr(i.materialKey || i.material || ''),
      material: toStr(i.materialKey || i.material || ''),
      articleNumber: toStr(i.articleNumber || ''),
      thicknessMm: toNum(i.thicknessMm, 0),
      edge: toStr(i.edge || 'none') || 'none'
    };
  }

  function getUpsertPlan(opts){
    const o = opts || {};
    const hasEditIndex = Number.isFinite(Number(o.editIndex)) && Number(o.editIndex) >= 0;
    return {
      mode: hasEditIndex ? 'replace' : 'append',
      index: hasEditIndex ? Number(o.editIndex) : null,
      idPrefix: toStr(o.idPrefix || 'EX_') || 'EX_'
    };
  }

  function withId(item, plan, previousItems){
    const arr = Array.isArray(previousItems) ? previousItems : [];
    const next = Object.assign({}, item || {});
    if(plan?.mode === 'replace' && Number.isFinite(plan?.index)){
      next.id = arr[plan.index]?.id || next.id || (String(plan.idPrefix||'EX_') + Date.now() + Math.random());
      return next;
    }
    next.id = next.id || (String(plan?.idPrefix||'EX_') + Date.now() + Math.random());
    return next;
  }

  function applyUpsert(previousItems, item, plan){
    const arr = Array.isArray(previousItems) ? previousItems.slice() : [];
    const p = plan || getUpsertPlan();
    const nextItem = withId(item, p, arr);
    if(p.mode === 'replace' && Number.isFinite(p.index) && p.index >= 0){
      arr[p.index] = nextItem;
    } else {
      arr.push(nextItem);
    }
    return { items: arr, item: nextItem, replaced: p.mode === 'replace', index: p.mode === 'replace' ? p.index : (arr.length - 1) };
  }

  window.ToolAExtraPanelMutations = {
    getEditPrefillSnapshot,
    getResetFormState,
    buildItem,
    getUpsertPlan,
    applyUpsert
  };
})();
