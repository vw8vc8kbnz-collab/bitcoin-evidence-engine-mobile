(function(){
  function toNum(v){
    const n = Number(v);
    return Number.isFinite(n) ? n : NaN;
  }

  function clampQty(v){
    const n = Math.round(Number(v || 1));
    return Number.isFinite(n) && n > 0 ? n : 1;
  }

  function getValidation(opts){
    const width = toNum(opts && opts.width);
    const height = toNum(opts && opts.height);
    const qty = clampQty(opts && opts.qty);
    const minWidthMm = Math.max(1, Number((opts && opts.minWidthMm) || 40));

    if(!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0){
      return {
        ok: false,
        width: NaN,
        height: NaN,
        qty,
        alertMessage: 'Vul een geldige breedte en hoogte in (mm).'
      };
    }

    if(width < minWidthMm){
      return {
        ok: false,
        width,
        height,
        qty,
        alertMessage: `Overige panelen moeten minimaal ${minWidthMm} mm breed zijn. Vul een breedte van ${minWidthMm} mm of groter in.`
      };
    }

    return {
      ok: true,
      width: Math.round(width),
      height: Math.round(height),
      qty,
      alertMessage: ''
    };
  }

  function getMutationPlan(opts){
    const rawEditIndex = opts && Object.prototype.hasOwnProperty.call(opts, 'editIndex') ? opts.editIndex : null;
    const hasEditIndex = rawEditIndex !== null && rawEditIndex !== undefined && rawEditIndex !== '';
    const editIndexNum = hasEditIndex ? Number(rawEditIndex) : NaN;
    const resolvedEditIndex = Number.isInteger(editIndexNum) && editIndexNum >= 0 ? editIndexNum : null;
    return {
      mode: resolvedEditIndex !== null ? 'replace' : 'append',
      editIndex: resolvedEditIndex,
      materialKey: String((opts && opts.materialKey) || ''),
      idPrefix: String((opts && opts.idPrefix) || 'EX_')
    };
  }

  function getPostSubmitPlan(opts){
    return {
      rerenderExtraPanels: !(opts && opts.rerenderExtraPanels === false),
      syncChecks: !(opts && opts.syncChecks === false),
      redrawExtraPreviewBeforeReset: !(opts && opts.redrawExtraPreviewBeforeReset === false),
      resetForm: !(opts && opts.resetForm === false),
      redrawExtraPreviewAfterReset: !(opts && opts.redrawExtraPreviewAfterReset === false),
      clearEditIndex: !(opts && opts.clearEditIndex === false)
    };
  }

  function getSubmitPlan(opts){
    return {
      validation: getValidation(opts),
      mutation: getMutationPlan(opts),
      postSubmit: getPostSubmitPlan(opts)
    };
  }

  window.ToolAExtraPanelSubmitFlow = {
    clampQty,
    getValidation,
    getMutationPlan,
    getPostSubmitPlan,
    getSubmitPlan
  };
})();
