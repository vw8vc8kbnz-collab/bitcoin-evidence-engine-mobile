(function(){
  const w = window;

  function getPrevTarget(step, overviewReturnStep){
    try{
      if(w.ToolARouteState && typeof w.ToolARouteState.getPrevStep === 'function'){
        return w.ToolARouteState.getPrevStep(step || 'material', overviewReturnStep || 'customer');
      }
    }catch(_){ }
    return null;
  }

  function getNextTarget(step, ctx){
    try{
      if(w.ToolARouteState && typeof w.ToolARouteState.getNextStep === 'function'){
        return w.ToolARouteState.getNextStep(step || 'material', ctx || {});
      }
    }catch(_){ }
    return null;
  }

  function bindWizardFooter(opts){
    const prevBtn = opts && opts.prevBtn;
    const nextBtn = opts && opts.nextBtn;
    const overviewBtn = opts && opts.overviewBtn;
    const showStep = opts && opts.showStep;
    const getCurrentStepFallback = (opts && opts.getCurrentStep) || (() => (w.__metod_uiStep || 'material'));

    function getCurrentStep(){
      try{
        const direct = (nextBtn && nextBtn.dataset && nextBtn.dataset.currentStep) ||
          (prevBtn && prevBtn.dataset && prevBtn.dataset.currentStep) ||
          (overviewBtn && overviewBtn.dataset && overviewBtn.dataset.currentStep) ||
          (document.getElementById('wizardFooterInner') && document.getElementById('wizardFooterInner').dataset && document.getElementById('wizardFooterInner').dataset.currentStep) ||
          '';
        if(direct) return String(direct);
      }catch(_){ }
      try{ return getCurrentStepFallback() || 'material'; }catch(_){ return 'material'; }
    }
    const getOverviewReturnStep = (opts && opts.getOverviewReturnStep) || (() => (w.__overviewReturnStep || 'customer'));
    const hasMaterialSelected = (opts && opts.hasMaterialSelected) || (() => false);
    const hasPanels = (opts && opts.hasPanels) || (() => false);
    const validateCustomerStepRequired = (opts && opts.validateCustomerStepRequired) || (() => true);

    if(prevBtn && !prevBtn.__bound){
      prevBtn.addEventListener('click', ()=>{
        const step = getCurrentStep() || 'material';
        const target = getPrevTarget(step, getOverviewReturnStep()) || 'material';
        try{ showStep && showStep(target); }catch(_){ }
      });
      prevBtn.__bound = true;
    }

    if(nextBtn && !nextBtn.__bound){
      nextBtn.addEventListener('click', ()=>{
        const step = getCurrentStep() || 'material';
        if(step === 'customer'){
          if(!validateCustomerStepRequired()) return;
          const target = getNextTarget(step, {
            hasMaterial: !!hasMaterialSelected(),
            hasPanels: !!hasPanels(),
            customerValid: true
          });
          if(target){
            try{ showStep && showStep(target); }catch(_){ }
          }
          return;
        }
        const target = getNextTarget(step, {
          hasMaterial: !!hasMaterialSelected(),
          hasPanels: !!hasPanels(),
          customerValid: false
        });
        if(target){
          try{ showStep && showStep(target); }catch(_){ }
        }
      });
      nextBtn.__bound = true;
    }

    if(overviewBtn && !overviewBtn.__bound){
      overviewBtn.addEventListener('click', ()=>{
        if(!hasPanels()) return;
        try{ showStep && showStep('overview'); }catch(_){ }
      });
      overviewBtn.__bound = true;
    }

    return { prev: prevBtn || null, next: nextBtn || null, overview: overviewBtn || null };
  }

  function bindOverviewBackButtons(opts){
    const closeBtn = opts && opts.closeBtn;
    const backBtn = opts && opts.backBtn;
    const closeOverview = opts && opts.closeOverview;
    const showStep = opts && opts.showStep;
    const getOverviewReturnStep = (opts && opts.getOverviewReturnStep) || (() => (w.__overviewReturnStep || 'customer'));

    function backFromOverview(){
      try{ closeOverview && closeOverview(); }catch(_){ }
      let ret = getOverviewReturnStep() || 'customer';
      ret = getPrevTarget('overview', ret) || ret || 'customer';
      try{ showStep && showStep(ret); }catch(_){ try{ showStep && showStep('customer'); }catch(__){} }
    }

    if(closeBtn && !closeBtn.__bound){
      closeBtn.addEventListener('click', backFromOverview);
      closeBtn.__bound = true;
    }
    if(backBtn && !backBtn.__bound){
      backBtn.addEventListener('click', backFromOverview);
      backBtn.__bound = true;
    }

    return { close: closeBtn || null, back: backBtn || null };
  }

  const api = {
    version: 'FIX392_TOOLA_FOOTER_BINDINGS_PHASE54',
    bindWizardFooter,
    bindOverviewBackButtons
  };

  w.ToolAFooterBindings = api;
  try{ console.log('[ToolA Footer Bindings OK]', api.version); }catch(_){ }
})();
