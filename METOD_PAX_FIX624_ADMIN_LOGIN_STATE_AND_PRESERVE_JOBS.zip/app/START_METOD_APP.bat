@echo off
setlocal EnableExtensions
set "PYTHONDONTWRITEBYTECODE=1"
cd /d "%~dp0"
title METOD Launcher

echo.
echo [METOD] Logs: "%CD%\launcher_log.txt"
echo [METOD] Launcher starting...>> "%cd%\launcher_log.txt"
echo [METOD] Launcher starting...

REM Start server in a new window so we can continue (and keep server window open)
echo [METOD] Starting server window...
echo [METOD] Starting server window...>> "%cd%\launcher_log.txt"
start "METOD Server" /D "%cd%" cmd /k "%cd%\RUN_SERVER.bat"

REM Start worker in a new window
if exist "%cd%\RUN_WORKER.bat" (
  echo [METOD] Starting worker window...
  echo [METOD] Starting worker window...>> "%cd%\launcher_log.txt"
  start "METOD Worker" /min /D "%cd%" cmd /k "%cd%\RUN_WORKER.bat"
) else (
  echo [METOD] WARN: RUN_WORKER.bat not found, worker not started.
  echo [METOD] WARN: RUN_WORKER.bat not found, worker not started.>> "%cd%\launcher_log.txt"
)

REM Give the server a moment to bind the port
REM Wait for server to bind port 8787 (max ~30s)
set "OK="
for /L %%i in (1,1,30) do (
  powershell -NoProfile -Command "try { $c = New-Object Net.Sockets.TcpClient; $iar = $c.BeginConnect('127.0.0.1',8787,$null,$null); $ok = $iar.AsyncWaitHandle.WaitOne(500,$false); if($ok){$c.EndConnect($iar)}; $c.Close(); if($ok){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>&1
  if not errorlevel 1 (set "OK=1" & goto :SERVER_OK)
  timeout /t 1 /nobreak >nul
)
:SERVER_OK
if not defined OK (echo [METOD] WARN: server did not respond yet, opening Chrome anyway.)

echo.
echo [METOD] Opening Chrome...
echo [METOD] Opening Chrome...>> "%cd%\launcher_log.txt"

call "%cd%\OPEN_CHROME.bat" >> "%cd%\launcher_log.txt" 2>&1
if errorlevel 1 (
  echo [METOD] Chrome launch FAILED. See launcher_log.txt
  echo [METOD] Chrome launch FAILED.>> "%cd%\launcher_log.txt"
  pause
) else (
  echo [METOD] Chrome launch OK.
  echo [METOD] Chrome launch OK.>> "%cd%\launcher_log.txt"
)

REM Admin opens alleen handmatig via /admin

echo.
echo [METOD] Launcher finished. You can close this window.
pause
endlocal
