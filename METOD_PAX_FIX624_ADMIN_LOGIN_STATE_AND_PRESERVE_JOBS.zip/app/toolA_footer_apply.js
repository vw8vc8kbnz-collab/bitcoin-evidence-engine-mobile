(function(){
  function mkBtn(id, label, primary){
    const b = document.createElement('button');
    b.id = id;
    b.type = 'button';
    b.className = primary ? 'btn btnPrimary' : 'btn';
    b.textContent = label;
    return b;
  }

  function ensureButtons(input){
    const cfg = input && typeof input === 'object' ? input : {};
    const footerInner = cfg.footerInner || null;
    const existing = cfg.existing && typeof cfg.existing === 'object' ? cfg.existing : {};
    if(!footerInner) return {
      prev: existing.prev || null,
      overview: existing.overview || null,
      next: existing.next || null
    };

    let prev = existing.prev || document.getElementById('wizardPrevBtn');
    let overview = existing.overview || document.getElementById('wizardOverviewBtn');
    let next = existing.next || document.getElementById('wizardNextBtn');

    if(!prev){ prev = mkBtn('wizardPrevBtn', 'Vorige stap', false); footerInner.appendChild(prev); }
    if(!overview){ overview = mkBtn('wizardOverviewBtn', 'Overzicht', false); footerInner.appendChild(overview); }
    if(!next){ next = mkBtn('wizardNextBtn', 'Volgende stap', true); footerInner.appendChild(next); }

    return { prev, overview, next };
  }

  function applyButton(btn, state, fallbackText){
    if(!btn) return;
    const s = state && typeof state === 'object' ? state : {};
    btn.style.display = s.display || 'none';
    btn.disabled = !!s.disabled;
    btn.textContent = s.text || fallbackText;
  }

  function applyInlineAdd(addInline, state){
    if(!addInline) return;
    const s = state && typeof state === 'object' ? state : {};
    addInline.disabled = !!s.disabled;
    addInline.textContent = s.text || '+ Toevoegen aan lijst';
    addInline.classList.toggle('is-editing', !!(s.classes && s.classes.isEditing));
  }

  function applyViewState(input){
    const cfg = input && typeof input === 'object' ? input : {};
    const buttons = cfg.buttons && typeof cfg.buttons === 'object' ? cfg.buttons : {};
    const viewState = cfg.viewState && typeof cfg.viewState === 'object' ? cfg.viewState : {};

    applyButton(buttons.prev, viewState.prev, 'Vorige stap');
    applyButton(buttons.next, viewState.next, 'Volgende stap');
    applyButton(buttons.overview, viewState.overview, 'Overzicht');
    applyInlineAdd(cfg.addInline || null, viewState.addInline || null);

    return {
      prev: buttons.prev || null,
      next: buttons.next || null,
      overview: buttons.overview || null,
      addInline: cfg.addInline || null,
      viewState
    };
  }

  window.ToolAFooterApply = {
    ensureButtons,
    applyViewState
  };
})();
