(function(){
  function toStr(v, fb){ return String(v == null ? (fb == null ? '' : fb) : v); }
  function toNum(v, fb){
    const n = Number(v);
    return Number.isFinite(n) ? n : Number(fb == null ? 0 : fb);
  }
  function clampCount(v){
    const n = parseInt(v, 10);
    return Math.max(1, Number.isFinite(n) ? n : 1);
  }
  function resolveCustomName(input){
    const t = input?.template;
    const allowCustomName = !!(t && (t.type === 'deur' || t.type === 'pax_deur' || t.type === 'lade' || t.supportsHinge));
    const customNameRaw = toStr(input?.customLabelInput?.value || input?.liveForm?.customLabel || '').trim();
    return {
      allowCustomName,
      customNameRaw,
      finalLabel: (allowCustomName && customNameRaw) ? customNameRaw : toStr(t?.label, '')
    };
  }
  function buildPanelItemInput(input){
    const state = input?.state || {};
    const t = input?.template || {};
    const naming = resolveCustomName(input);
    return {
      templateId: t.id,
      label: naming.finalLabel,
      baseLabel: t.label,
      customLabel: naming.allowCustomName ? naming.customNameRaw : '',
      customName: naming.allowCustomName ? naming.customNameRaw : '',
      type: t.type,
      kind: toStr(t.kind || ''),
      supportsHinge: !!t.supportsHinge,
      qty: 1,
      hinge: toStr(input?.liveForm?.hinge || state?.selection?.hinge || 'left'),
      extTop: toNum(input?.liveForm?.extTop || state?.selection?.extTop || 0, 0),
      extBot: toNum(input?.liveForm?.extBot || state?.selection?.extBot || 0, 0),
      material: toStr(state?.material?.decorName || ''),
      materialCode: toStr(state?.material?.materialCode || ''),
      articleNumber: toStr(state?.material?.articleNumber || ''),
      materialKey: toStr(state?.activeMaterialKey || ''),
      decorName: toStr(state?.material?.decorName || ''),
      thicknessMm: toNum(state?.material?.thicknessMm, 18),
      rotationAllowed: !state?.grainEnabled,
      edge: toStr(state?.selection?.edge || 'none') || 'none',
      cmW: toNum(t.cmW, 0),
      cmH: toNum(t.cmH, 0),
      realW: toNum(t.realW, 0),
      realH: toNum(t.realH, 0)
    };
  }
  function resolveEditState(input){
    const submitPlan = input?.submitPlan || {};
    const fallback = input?.editStateFallback || {};
    const resolvedEditTargetId = toStr(submitPlan?.mutation?.editId || fallback.targetId || '').trim();
    const resolvedEditGroupKeyRaw = toStr(fallback.groupKey || '').trim();
    const resolvedEditOriginalCount = toNum(fallback.originalCount, 0);
    const addBtn = input?.addBtn || null;
    const forceEditMode = !!(
      resolvedEditTargetId ||
      resolvedEditGroupKeyRaw ||
      resolvedEditOriginalCount > 0 ||
      (addBtn && /wijzigingen/i.test(toStr(addBtn.textContent || '')))
    );
    return {
      targetId: resolvedEditTargetId,
      groupKey: resolvedEditGroupKeyRaw,
      originalCount: resolvedEditOriginalCount,
      forceEditMode
    };
  }
  function applyEditMutation(input){
    const state = input?.state || {};
    const panelItemInput = input?.panelItemInput || {};
    const submitPlan = input?.submitPlan || {};
    const editState = input?.editState || {};
    const qty = clampCount(input?.resolvedQty);
    const sourceItems = Array.isArray(state.cart) ? state.cart.slice() : [];
    const targetItem = editState.targetId ? (sourceItems.find(x => toStr(x?.id || '') === editState.targetId) || null) : null;
    const panelMutationAdapter = input?.panelMutationAdapter || null;
    const editGroupKeyLive = toStr(editState.groupKey || (targetItem && panelMutationAdapter && typeof panelMutationAdapter.groupKeyForItem === 'function' ? panelMutationAdapter.groupKeyForItem(targetItem) : '') || '').trim();
    const kept = editGroupKeyLive
      ? sourceItems.filter(x => (panelMutationAdapter && typeof panelMutationAdapter.groupKeyForItem === 'function' ? panelMutationAdapter.groupKeyForItem(x) : toStr(x?.id || '')) !== editGroupKeyLive)
      : (editState.targetId ? sourceItems.filter(x => toStr(x?.id || '') !== editState.targetId) : sourceItems);
    const idPrefix = toStr(submitPlan?.mutation?.idPrefix || input?.idPrefix || 'panel');
    const baseTs = toNum(submitPlan?.mutation?.timestamp, Date.now()) || Date.now();
    const nextItems = kept.slice();
    for(let i = 0; i < qty; i++){
      nextItems.push({ ...panelItemInput, id: `${idPrefix}_${baseTs}_${i + 1}` });
    }
    state.cart = nextItems;
    try{ state.selection.qty = qty; }catch(_){ }
    const post = submitPlan?.postSubmit || { clearEditMode:true, scheduleDraftSaveCount:1, pulseMessage:'Paneel bijgewerkt.' };
    if(post.clearEditMode && typeof input?.setPanelEditMode === 'function'){
      try{ input.setPanelEditMode(null, 0); }catch(_){ }
    }
    for(let i = 0; i < Math.max(1, toNum(post.scheduleDraftSaveCount, 0) || 0); i++){
      try{ input?.scheduleDraftSave && input.scheduleDraftSave(); }catch(_){ }
    }
    try{ if(post.pulseMessage && typeof input?.pulsePanelDock === 'function') input.pulsePanelDock(post.pulseMessage); }catch(_){ }
  }
  function applyAppendMutation(input){
    const state = input?.state || {};
    const panelItemInput = input?.panelItemInput || {};
    const submitPlan = input?.submitPlan || {};
    const panelMutationAdapter = input?.panelMutationAdapter || null;
    const resolvedQty = clampCount(input?.resolvedQty);
    const idPrefix = toStr(submitPlan?.mutation?.idPrefix || input?.idPrefix || 'panel');
    const baseTs = toNum(submitPlan?.mutation?.timestamp, Date.now()) || Date.now();
    if(panelMutationAdapter && typeof panelMutationAdapter.getUpsertPlan === 'function' && typeof panelMutationAdapter.applyUpsert === 'function'){
      const plan = panelMutationAdapter.getUpsertPlan({
        count: toNum(submitPlan?.mutation?.count, resolvedQty) || resolvedQty,
        idPrefix,
        timestamp: baseTs
      });
      const result = panelMutationAdapter.applyUpsert(state.cart || [], panelItemInput, plan);
      state.cart = Array.isArray(result?.items) ? result.items : (state.cart || []);
      const post = submitPlan?.postSubmit || { scheduleDraftSaveCount: Math.max(1, toNum(result?.addedCount, 0) || 0) };
      const saveCount = Math.max(1, toNum(post.scheduleDraftSaveCount, Math.max(1, toNum(result?.addedCount, 0) || 0)) || Math.max(1, toNum(result?.addedCount, 0) || 0));
      for(let i = 0; i < saveCount; i++){
        try{ input?.scheduleDraftSave && input.scheduleDraftSave(); }catch(_){ }
      }
      return;
    }
    const n = toNum(submitPlan?.mutation?.count, resolvedQty) || resolvedQty;
    state.cart = Array.isArray(state.cart) ? state.cart : [];
    for(let i = 0; i < n; i++){
      state.cart.push({ ...panelItemInput, id: `${idPrefix}_${baseTs}_${i + 1}` });
    }
    const post = submitPlan?.postSubmit || { scheduleDraftSaveCount: n };
    for(let i = 0; i < Math.max(1, toNum(post.scheduleDraftSaveCount, n) || n); i++){
      try{ input?.scheduleDraftSave && input.scheduleDraftSave(); }catch(_){ }
    }
  }
  function applyPostSubmit(input){
    const submitPlan = input?.submitPlan || {};
    const post = submitPlan?.postSubmit || { rerenderCart:true, rerenderExtraPanels:true, syncExtraChecks:true, redrawExtraPreview:true };
    try{ if(post.rerenderCart && typeof input?.renderCart === 'function') input.renderCart(); }catch(_){ }
    try{ if(post.rerenderExtraPanels && typeof input?.renderExtraPanels === 'function') input.renderExtraPanels(); }catch(_){ }
    try{ if(post.syncExtraChecks && typeof input?.syncChecksFromSelect === 'function') input.syncChecksFromSelect(); }catch(_){ }
    try{ if(post.redrawExtraPreview && typeof input?.drawExtraPreview === 'function') input.drawExtraPreview(); }catch(_){ }
  }
  function execute(input){
    const state = input?.state || null;
    if(!state) return { ok:false, reason:'missing-state' };
    const hasMaterial = !!(state.material && (state.activeMaterialKey || state.material.materialCode || state.material.articleNumber || state.material.decorName));
    if(!hasMaterial){
      try{ if(typeof input?.flashWarn === 'function') input.flashWarn('Selecteer eerst een materiaal. Zonder materiaal kunnen we geen prijs en nesting maken.'); }catch(_){ }
      try{ if(input?.matSearch && typeof input.matSearch.focus === 'function') input.matSearch.focus(); }catch(_){ }
      return { ok:false, reason:'missing-material' };
    }
    const t = input?.template || null;
    if(!t) return { ok:false, reason:'missing-template' };
    try{
      if(typeof input?.validatePanelFits === 'function'){
        const extTop = toNum(state?.selection?.extTop, 0);
        const extBot = toNum(state?.selection?.extBot, 0);
        const wMm = toNum(t.realW, 0);
        const hMm = toNum(t.realH, 0) + extTop + extBot;
        const rotationAllowed = (state?.grainEnabled === false);
        if(!input.validatePanelFits(wMm, hMm, toStr(state.activeMaterialKey || ''), rotationAllowed)){
          return { ok:false, reason:'sheet-fit-invalid' };
        }
      }
    }catch(_){ }
    const liveForm = input?.liveForm || null;
    const resolvedQty = clampCount(input?.qtyElement?.value || liveForm?.qty || state?.selection?.qty);
    try{ state.selection.qty = resolvedQty; }catch(_){ }
    const panelSubmitFlow = input?.panelSubmitFlow || null;
    const submitPlan = panelSubmitFlow && typeof panelSubmitFlow.getSubmitPlan === 'function'
      ? panelSubmitFlow.getSubmitPlan({
          editId: input?.editStateFallback?.targetId,
          qty: resolvedQty,
          idPrefix: (state?.selection?.templateId || t.id || 'panel'),
          timestamp: Date.now()
        })
      : { mutation:{ count:resolvedQty, timestamp:Date.now(), idPrefix:(state?.selection?.templateId || t.id || 'panel') }, postSubmit:{ rerenderCart:true, rerenderExtraPanels:true, syncExtraChecks:true, redrawExtraPreview:true } };
    const panelItemInput = buildPanelItemInput({ ...input, template:t, liveForm, state });
    const editState = resolveEditState({ ...input, submitPlan });
    if(editState.forceEditMode){
      applyEditMutation({ ...input, state, submitPlan, panelItemInput, editState, resolvedQty, idPrefix:(state?.selection?.templateId || t.id || 'panel') });
    }else{
      applyAppendMutation({ ...input, state, submitPlan, panelItemInput, resolvedQty, idPrefix:(state?.selection?.templateId || t.id || 'panel') });
    }
    applyPostSubmit({ ...input, submitPlan });
    return { ok:true, mode: editState.forceEditMode ? 'edit' : 'append', submitPlan, editState, resolvedQty };
  }

  window.ToolAPanelSubmitApply = {
    resolveCustomName,
    buildPanelItemInput,
    resolveEditState,
    applyEditMutation,
    applyAppendMutation,
    applyPostSubmit,
    execute
  };
})();
