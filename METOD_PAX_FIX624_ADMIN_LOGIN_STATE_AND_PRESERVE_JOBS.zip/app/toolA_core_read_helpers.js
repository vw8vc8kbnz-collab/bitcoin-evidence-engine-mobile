(function(){
  function toStr(v){ return v == null ? '' : String(v); }
  function getCurrentStep(){
    try{ return toStr(window.__metod_uiStep || document.body?.dataset?.uiStep || 'material') || 'material'; }catch(_){ return 'material'; }
  }
  function getActiveMaterialKey(state){
    try{ return toStr(state?.activeMaterialKey || state?.selection?.materialKey || '').trim(); }catch(_){ return ''; }
  }
  function hasActiveMaterial(state){
    try{
      const mat = state?.material || null;
      return !!(getActiveMaterialKey(state) || mat?.materialCode || mat?.articleNumber || mat?.decorName || mat?.productName);
    }catch(_){ return false; }
  }
  function getSelectedType(state, typeSel){
    try{
      const fromState = toStr(state?.selection?.type || '').trim();
      if(fromState) return fromState;
      const el = typeSel || document.getElementById('typeSel');
      return toStr(el?.value || '').trim();
    }catch(_){ return ''; }
  }
  function getSelectedSize(state, sizeSel){
    try{
      const fromState = toStr(state?.selection?.size || state?.selection?.sizeLabel || '').trim();
      if(fromState) return fromState;
      const el = sizeSel || document.getElementById('sizeSel');
      return toStr(el?.value || '').trim();
    }catch(_){ return ''; }
  }
  function getSelectedTemplateId(state){
    try{ return toStr(state?.selection?.templateId || '').trim(); }catch(_){ return ''; }
  }
  function getMaterialBatchCount(state){
    try{ return Array.isArray(state?.materialBatches) ? state.materialBatches.length : 0; }catch(_){ return 0; }
  }
  function getPanelsCount(state){
    try{ return Array.isArray(state?.cart) ? state.cart.length : 0; }catch(_){ return 0; }
  }
  function getOtherPanelsCount(state){
    try{ return Array.isArray(state?.specialPanels) ? state.specialPanels.length : 0; }catch(_){ return 0; }
  }
  function getEditSnapshot(state, typeSel, sizeSel){
    return {
      step: getCurrentStep(),
      activeMaterialKey: getActiveMaterialKey(state),
      hasActiveMaterial: hasActiveMaterial(state),
      selectedType: getSelectedType(state, typeSel),
      selectedSize: getSelectedSize(state, sizeSel),
      selectedTemplateId: getSelectedTemplateId(state),
      materialBatchCount: getMaterialBatchCount(state),
      panelsCount: getPanelsCount(state),
      otherPanelsCount: getOtherPanelsCount(state)
    };
  }
  window.ToolACoreReadHelpers = {
    getCurrentStep,
    getActiveMaterialKey,
    hasActiveMaterial,
    getSelectedType,
    getSelectedSize,
    getSelectedTemplateId,
    getMaterialBatchCount,
    getPanelsCount,
    getOtherPanelsCount,
    getEditSnapshot
  };
})();
