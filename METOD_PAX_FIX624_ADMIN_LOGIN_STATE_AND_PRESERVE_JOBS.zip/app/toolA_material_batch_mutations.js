(function(g){
  function toKey(v){ return String(v == null ? '' : v); }
  function filterByMaterial(items, materialKey){
    const key = toKey(materialKey);
    return Array.isArray(items) ? items.filter(it => toKey(it && it.materialKey) !== key) : [];
  }
  function getPlan(opts){
    opts = opts || {};
    const key = toKey(opts.key);
    const state = opts.state || {};
    const currentCart = Array.isArray(state.cart) ? state.cart : [];
    const currentExtra = Array.isArray(state.extraPanels) ? state.extraPanels : [];
    const currentBatches = Array.isArray(state.materialBatches) ? state.materialBatches : [];

    const nextCart = filterByMaterial(currentCart, key);
    const nextExtra = filterByMaterial(currentExtra, key);
    const nextBatches = currentBatches.filter(b => toKey(b && b.key) !== key);
    const hasAnyMaterialsLeft = nextBatches.length > 0;
    const wasActive = toKey(state.activeMaterialKey) === key;
    const nextActiveMaterialKey = wasActive ? (nextBatches[0] ? toKey(nextBatches[0].key) : null) : state.activeMaterialKey || null;

    return {
      key,
      nextState: {
        cart: nextCart,
        extraPanels: nextExtra,
        materialBatches: nextBatches,
        activeMaterialKey: nextActiveMaterialKey
      },
      hasAnyMaterialsLeft,
      shouldSetActiveMaterial: wasActive,
      nextActiveMaterialKey,
      shouldRunInlineRefresh: !wasActive,
      refresh: {
        renderMaterialBatches: !wasActive,
        renderCart: !wasActive,
        renderExtraPanels: !wasActive,
        drawExtraPreview: !wasActive,
        updateButtons: !wasActive,
        updateWizardBanner: !wasActive,
        scheduleDraftSave: !wasActive
      }
    };
  }

  g.ToolAMaterialBatchMutations = {
    getPlan,
    filterByMaterial
  };
})(window);
