(function(){
  'use strict';

  function getControlsState(state){
    const route = String(state?.route || '');
    const ready = route === 'metod';
    const material = state?.material || null;
    const hasMaterial = !!(material && (state?.activeMaterialKey || material?.materialCode || material?.articleNumber || material?.decorName));
    const hasCart = Array.isArray(state?.cart) && state.cart.length > 0;
    const type = state?.selection?.type || '';
    const templateId = state?.selection?.templateId || '';
    return {
      ready,
      hasMaterial,
      enablePanels: !!(ready && hasMaterial),
      addEnabled: !!(ready && hasMaterial && type && templateId),
      grainEnabled: !!(ready && hasMaterial),
      grainNextEnabled: !!(ready && hasMaterial && hasCart),
      extraOverlayEnabled: !!(ready && hasMaterial),
      overviewEnabled: !!(ready && hasCart)
    };
  }

  function resolveTypeKind(input){
    const rawValue = String(input?.rawValue || '').trim().toLowerCase();
    if(rawValue) return rawValue;
    const selectedText = String(input?.selectedText || '').trim().toLowerCase();
    if(selectedText.includes('pax')) return 'pax_deur';
    if(selectedText.includes('lade')) return 'lade';
    if(selectedText.includes('deur') || selectedText.includes('door')) return 'deur';
    if(selectedText.includes('overige')) return 'special';
    return String(input?.stateType || '').trim().toLowerCase();
  }

  function getCustomLabelState(input){
    const typeKind = resolveTypeKind(input);
    const show = (typeKind === 'deur' || typeKind === 'pax_deur' || typeKind === 'lade' || typeKind === 'special');
    return {
      typeKind,
      show,
      clearValueOnHide: !show
    };
  }

  const api = { getControlsState, resolveTypeKind, getCustomLabelState };
  window.ToolAPanelUiState = api;
})();
