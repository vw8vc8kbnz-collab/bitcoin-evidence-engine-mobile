@echo off
setlocal EnableExtensions
set "PYTHONDONTWRITEBYTECODE=1"
cd /d "%~dp0"

set "LOG=%~dp0server_log.txt"
echo [METOD] Starting Python server... > "%LOG%"

REM --- Find a working Python command (robust against Microsoft Store aliases)
set "PY_EXE="
set "PY_ARG="

REM 1) Microsoft Store alias path (often present when App Execution Alias is enabled)
if exist "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" call :try_path "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" ""

REM 2) Standard launchers on PATH
if not defined PY_EXE call :try_cmd py -3
if not defined PY_EXE call :try_cmd py
if not defined PY_EXE call :try_cmd python
if not defined PY_EXE call :try_cmd python3

if not defined PY_EXE (
  echo [METOD] ERROR: Python not found or not runnable.>> "%LOG%"
  echo [METOD] ERROR: Python not found or not runnable.
  echo( - Install Python from python.org, or enable the Windows Python App Execution Alias.
  pause
  exit /b 1
)

echo [METOD] Using: %PY_EXE% %PY_ARG%>> "%LOG%"
echo [METOD] Using: %PY_EXE% %PY_ARG%

REM --- Run server (unbuffered so logs flush)
if "%PY_ARG%"=="" (
  "%PY_EXE%" -u "%~dp0server_py.py" >> "%LOG%" 2>&1
) else (
  "%PY_EXE%" %PY_ARG% -u "%~dp0server_py.py" >> "%LOG%" 2>&1
)

exit /b %errorlevel%

REM ========= helpers =========

:try_cmd
set "C_EXE=%~1"
set "C_ARG=%~2"
where "%C_EXE%" >nul 2>nul || goto :eof

REM Test that it actually runs
if "%C_ARG%"=="" (
  "%C_EXE%" -c "import sys" >nul 2>nul || goto :eof
) else (
  "%C_EXE%" %C_ARG% -c "import sys" >nul 2>nul || goto :eof
)

set "PY_EXE=%C_EXE%"
set "PY_ARG=%C_ARG%"
goto :eof

:try_path
set "C_PATH=%~1"
set "C_ARG=%~2"
if not exist "%C_PATH%" goto :eof

if "%C_ARG%"=="" (
  "%C_PATH%" -c "import sys" >nul 2>nul || goto :eof
) else (
  "%C_PATH%" %C_ARG% -c "import sys" >nul 2>nul || goto :eof
)

set "PY_EXE=%C_PATH%"
set "PY_ARG=%C_ARG%"
goto :eof
