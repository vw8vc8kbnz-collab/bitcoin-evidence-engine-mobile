(function(){
  function setSelectValue(el, value){
    try{
      if(!el) return;
      el.value = value == null ? '' : String(value);
      if(typeof el.__appleSync === 'function') el.__appleSync();
    }catch(_){ }
  }
  function setInputValue(el, value){
    try{ if(el) el.value = value; }catch(_){ }
  }
  function dispatchChange(el){
    try{ if(el) el.dispatchEvent(new Event('change', { bubbles:true })); }catch(_){ }
  }
  function applyBootstrap(input){
    const selection = input?.selection || null;
    const ui = input?.ui || null;
    const needsReset = !!input?.needsReset;
    const state = input?.state || null;
    const typeSel = input?.typeSel || null;
    const sizeSel = input?.sizeSel || null;
    const qty = input?.qty || null;
    const extTop = input?.extTop || null;
    const extBot = input?.extBot || null;
    const addBtn = input?.addBtn || null;
    const syncDefaultPanelTypeSelection = input?.syncDefaultPanelTypeSelection;
    const populateSizeDropdown = input?.populateSizeDropdown;
    const refreshCustomLabelVisibility = input?.refreshCustomLabelVisibility;
    const ensureTemplateLoadedById = input?.ensureTemplateLoadedById;
    const draw = input?.draw;

    if(selection && state){
      state.selection = state.selection || {};
      state.selection.type = selection.type;
      state.selection.templateId = selection.templateId;
      state.selection.qty = selection.qty;
      state.selection.extTop = selection.extTop;
      state.selection.extBot = selection.extBot;
    }

    if(needsReset){
      setSelectValue(typeSel, ui && 'typeValue' in ui ? ui.typeValue : '');
      try{
        if(sizeSel){
          sizeSel.innerHTML = (ui && ui.sizePlaceholder) ? ui.sizePlaceholder : '<option value="">— Kies maat —</option>';
        }
      }catch(_){ }
      setSelectValue(sizeSel, ui && 'sizeValue' in ui ? ui.sizeValue : '');
      setInputValue(extTop, ui && 'extTop' in ui ? ui.extTop : 0);
      setInputValue(extBot, ui && 'extBot' in ui ? ui.extBot : 0);
      try{ if(typeof syncDefaultPanelTypeSelection === 'function') syncDefaultPanelTypeSelection(); }catch(_){ }
      try{ if(typeof populateSizeDropdown === 'function') populateSizeDropdown(); }catch(_){ }
    }else{
      setSelectValue(typeSel, ui && 'typeValue' in ui ? ui.typeValue : (state && state.selection ? state.selection.type : ''));
      setSelectValue(sizeSel, ui && 'sizeValue' in ui ? ui.sizeValue : (state && state.selection ? state.selection.templateId : ''));
    }

    try{ if(addBtn) addBtn.disabled = !((ui && 'addEnabled' in ui) ? ui.addEnabled : !!(state && state.selection && state.activeMaterialKey && state.selection.type && state.selection.templateId)); }catch(_){ }
    try{ if(typeof refreshCustomLabelVisibility === 'function') refreshCustomLabelVisibility(); }catch(_){ }
    dispatchChange(typeSel);
    try{
      if(typeof ensureTemplateLoadedById === 'function' && state && state.selection && state.selection.templateId){
        ensureTemplateLoadedById(state.selection.templateId).then(function(){ try{ if(typeof draw === 'function') draw(); }catch(_){ } try{ if(typeof refreshCustomLabelVisibility === 'function') refreshCustomLabelVisibility(); }catch(_){ } });
      } else {
        try{ if(typeof draw === 'function') draw(); }catch(_){ }
        try{ if(typeof refreshCustomLabelVisibility === 'function') refreshCustomLabelVisibility(); }catch(_){ }
      }
    }catch(_){ }
  }

  function applyNoMaterialsReset(input){
    const reset = input?.reset || null;
    const state = input?.state || null;
    const typeSel = input?.typeSel || null;
    const sizeSel = input?.sizeSel || null;
    const qty = input?.qty || null;
    const extTop = input?.extTop || null;
    const extBot = input?.extBot || null;
    const addBtn = input?.addBtn || null;
    const renderStep2MaterialSummary = input?.renderStep2MaterialSummary;
    const renderMaterialBatches = input?.renderMaterialBatches;
    const renderMaterialBatchesStep2 = input?.renderMaterialBatchesStep2;
    const renderCart = input?.renderCart;
    const renderExtraPanels = input?.renderExtraPanels;
    const drawPreview = input?.drawPreview;
    const drawExtraPreview = input?.drawExtraPreview;
    const showStep = input?.showStep;
    const setStep = input?.setStep;
    const renderFooterForStep = input?.renderFooterForStep;
    const updateButtons = input?.updateButtons;
    const updateWizardBanner = input?.updateWizardBanner;

    try{
      if(state){
        state.materialBatches = [];
        state.activeMaterialKey = null;
        state.material = null;
        state.selection = state.selection || {};
      }
      const sel = reset && reset.selection ? reset.selection : { type:null, templateId:null, qty:1, extTop:0, extBot:0, customLabel:'', materialKey:null, materialName:null };
      state.selection.type = sel.type;
      state.selection.templateId = sel.templateId;
      state.selection.qty = sel.qty;
      state.selection.extTop = sel.extTop;
      state.selection.extBot = sel.extBot;
      state.selection.customLabel = sel.customLabel;
      state.selection.materialKey = null;
      state.selection.materialName = null;
    }catch(_){ }
    setSelectValue(typeSel, reset && reset.ui && 'typeValue' in reset.ui ? reset.ui.typeValue : '');
    try{ if(sizeSel){ sizeSel.innerHTML = (reset && reset.ui && reset.ui.sizePlaceholder) ? reset.ui.sizePlaceholder : '<option value="">— Kies maat —</option>'; } }catch(_){ }
    setSelectValue(sizeSel, reset && reset.ui && 'sizeValue' in reset.ui ? reset.ui.sizeValue : '');
    setInputValue(qty, reset && reset.ui && 'qty' in reset.ui ? reset.ui.qty : 1);
    setInputValue(extTop, reset && reset.ui && 'extTop' in reset.ui ? reset.ui.extTop : 0);
    setInputValue(extBot, reset && reset.ui && 'extBot' in reset.ui ? reset.ui.extBot : 0);
    try{ if(addBtn) addBtn.disabled = true; }catch(_){ }
    try{ if(typeof renderStep2MaterialSummary === 'function') renderStep2MaterialSummary(); }catch(_){ }
    try{ if(typeof renderMaterialBatches === 'function') renderMaterialBatches(); }catch(_){ }
    try{ if(typeof renderMaterialBatchesStep2 === 'function') renderMaterialBatchesStep2(); }catch(_){ }
    try{ 
      const wrap = document.getElementById('matChosenStep2');
      const chips = document.getElementById('matChosenStep2Chips');
      if(wrap) wrap.style.display = 'none';
      if(chips) chips.innerHTML = '';
      const chosen = document.getElementById('matChosen');
      if(chosen) chosen.style.display = 'none';
    }catch(_){ }
    try{ if(typeof renderCart === 'function') renderCart(); }catch(_){ }
    try{ if(typeof renderExtraPanels === 'function') renderExtraPanels(); }catch(_){ }
    try{ if(typeof updateButtons === 'function') updateButtons(); }catch(_){ }
    try{ if(typeof updateWizardBanner === 'function') updateWizardBanner(); }catch(_){ }
    try{ if(typeof drawPreview === 'function') drawPreview(); }catch(_){ }
    try{ if(typeof drawExtraPreview === 'function') drawExtraPreview(); }catch(_){ }
    try{ if(typeof setStep === 'function') setStep('material'); }catch(_){ }
    try{ if(typeof renderFooterForStep === 'function') renderFooterForStep('material'); }catch(_){ }
    try{ if(typeof showStep === 'function') setTimeout(function(){ try{ showStep('material'); }catch(_){ } }, 0); }catch(_){ }
  }

  window.ToolAPanelBootstrapApply = {
    applyBootstrap,
    applyNoMaterialsReset
  };
})();
