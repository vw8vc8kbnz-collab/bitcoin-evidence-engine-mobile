(function(){
  const w = window;

  function call(fn, args, fallback){
    try{
      if(typeof fn === 'function') return fn.apply(null, args || []);
    }catch(err){
      console.warn('ToolAPanelsEntry call failed', err);
    }
    return fallback;
  }

  function totalDockItems(){
    try{
      if (w.ToolACoreSelectors && typeof w.ToolACoreSelectors.getCartSnapshot === 'function') {
        const snap = w.ToolACoreSelectors.getCartSnapshot(w.state);
        return Number(snap?.standardCount || 0) + Number(snap?.extraQty || 0);
      }
      const cart = Array.isArray(w.state?.cart) ? w.state.cart.length : 0;
      const extras = Array.isArray(w.state?.extraPanels) ? w.state.extraPanels.reduce((a,p)=> a + Math.max(1, Number(p?.qty)||1), 0) : 0;
      return cart + extras;
    }catch(_){ return 0; }
  }

  function resolveRaw(){
    return {
      bootstrap: w.__bootstrapPanelSelectionForActiveMaterial || null,
      resetFields: w.__resetPanelEntryFields || null,
      removeMaterial: w.__removeMaterialBatch || null,
      setDockOpen: w.setPanelDockOpen || null,
      setActiveMaterial: w.__setActiveMaterial || null
    };
  }

  const api = {
    version: 'FIX301_TOOLA_PANELS_ENTRYPOINTS_LAZY_RAW_HOOKS',
    get raw(){ return resolveRaw(); },
    bootstrapSelection(force){
      const raw = resolveRaw();
      const out = call(raw.bootstrap, [!!force], false);
      try{ w.__forcePanelBootstrap = false; }catch(_){ }
      return out;
    },
    resetEntry(){
      const raw = resolveRaw();
      return call(raw.resetFields, [], null);
    },
    removeMaterial(key){
      const raw = resolveRaw();
      return call(raw.removeMaterial, [key], null);
    },
    activateMaterial(key){
      const raw = resolveRaw();
      return call(raw.setActiveMaterial, [key], null);
    },
    syncAppleSelects(){
      try{ if(typeof w.typeSel !== 'undefined' && w.typeSel && typeof w.typeSel.__appleSync === 'function') w.typeSel.__appleSync(); }catch(_){ }
      try{ if(typeof w.sizeSel !== 'undefined' && w.sizeSel && typeof w.sizeSel.__appleSync === 'function') w.sizeSel.__appleSync(); }catch(_){ }
    },
    syncDockOnPanelsEntry(prevStep){
      try{
        if(w.panelDock){ w.panelDock.style.display = 'flex'; }
        if(w.panelDockLauncher){ w.panelDockLauncher.style.display = 'inline-flex'; }
        const dockTotal = totalDockItems();
        const shouldRestoreDock = dockTotal > 0 && (prevStep === 'grain' || prevStep === 'overview') && !!w.__panelDockWasOpenBeforeRoute;
        const raw = resolveRaw();
        if(typeof raw.setDockOpen === 'function'){
          if(shouldRestoreDock) raw.setDockOpen(true);
          else if(!dockTotal) raw.setDockOpen(false);
        }
      }catch(_){ }
    },
    onEnterPanelsStep(prevStep){
      try{ if(typeof w.ensureCustomLabelHook === 'function') w.ensureCustomLabelHook(); }catch(_){ }
      try{ if(typeof w.syncDefaultPanelTypeSelection === 'function') w.syncDefaultPanelTypeSelection(); }catch(_){ }
      try{ if(typeof w.enableControlsIfReady === 'function') w.enableControlsIfReady(); }catch(_){ }
      try{
        const hasMat = !!(w.state && w.state.activeMaterialKey);
        const isPrefillingEdit = !!w.__prefillingPanelEdit;
        const hasEditTarget = !!(w.__panelEditTargetId || (typeof w.resolvePanelEditTargetId === 'function' && w.resolvePanelEditTargetId()));
        const skipBootstrapForEdit = !!w.__skipPanelBootstrapForEdit;
        if(hasMat && !isPrefillingEdit && !hasEditTarget && !skipBootstrapForEdit){
          const forceBootstrap = !!w.__forcePanelBootstrap;
          api.bootstrapSelection(forceBootstrap);
        }
      }catch(_){ }
      try{ w.__skipPanelBootstrapForEdit = false; }catch(_){ }
      api.syncAppleSelects();
      api.syncDockOnPanelsEntry(prevStep);
    }
  };

  w.ToolAPanelsEntry = api;
  w.__ToolAPanelsEntryVersion = api.version;
})();
