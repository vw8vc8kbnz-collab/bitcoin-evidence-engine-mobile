(function(){
  function safeArray(v){ return Array.isArray(v) ? v : []; }
  function safeString(v){ return v == null ? '' : String(v); }
  function qtyOf(v){ const n = Number(v); return Number.isFinite(n) && n > 0 ? Math.max(1, n) : 1; }
  function uniqueMaterialKeys(state){
    const keys = [
      ...safeArray(state && state.cart).map(it => safeString(it && it.materialKey)),
      ...safeArray(state && state.extraPanels).map(it => safeString((it && (it.materialKey || it.material)) || ''))
    ].filter(Boolean);
    return Array.from(new Set(keys));
  }
  function getTabState(state){
    const ui = (state && state.ui) || {};
    const matKeys = uniqueMaterialKeys(state);
    let panelDockTab = safeString(ui.panelDockTab || 'all') || 'all';
    let panelDockMaterialKey = safeString(ui.panelDockMaterialKey || '') || (matKeys[0] || null);
    if(panelDockMaterialKey && !matKeys.includes(panelDockMaterialKey)) panelDockMaterialKey = matKeys[0] || null;
    if(panelDockTab === 'material' && !panelDockMaterialKey) panelDockTab = 'all';
    return { matKeys, panelDockTab, panelDockMaterialKey };
  }
  function inSelectedMaterial(materialKey, tabState){
    if(!tabState || tabState.panelDockTab === 'all') return true;
    return safeString(materialKey) === safeString(tabState.panelDockMaterialKey || '');
  }
  function getFilteredCollections(state){
    const tabState = getTabState(state);
    return {
      tabState,
      filteredCart: safeArray(state && state.cart).filter(it => inSelectedMaterial(it && it.materialKey, tabState)),
      filteredExtraPanels: safeArray(state && state.extraPanels).filter(it => inSelectedMaterial(it && (it.materialKey || it.material), tabState))
    };
  }
  function getSectionState(state){
    const filtered = getFilteredCollections(state);
    const cartCount = filtered.filteredCart.length;
    const extraQtyCount = filtered.filteredExtraPanels.reduce((a, p) => a + qtyOf(p && p.qty), 0);
    const useSplit = !!(cartCount && filtered.filteredExtraPanels.length);
    return {
      tabState: filtered.tabState,
      cartCount,
      extraQtyCount,
      extraLineCount: filtered.filteredExtraPanels.length,
      useSplit,
      showMaterialHint: filtered.tabState.panelDockTab === 'material' && !!filtered.tabState.panelDockMaterialKey
    };
  }
  window.ToolAPanelDockState = {
    uniqueMaterialKeys,
    getTabState,
    inSelectedMaterial,
    getFilteredCollections,
    getSectionState
  };
})();
