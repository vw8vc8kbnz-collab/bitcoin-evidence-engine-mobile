(function(){
  function toStr(v){ return v == null ? '' : String(v); }
  function toNum(v, fallback){
    const n = Number(v);
    return Number.isFinite(n) ? n : (fallback == null ? 0 : fallback);
  }
  function getCatalog(state){
    try{ return (state && state.catalog && typeof state.catalog === 'object') ? state.catalog : {}; }catch(_){ return {}; }
  }
  function getTemplateMap(state){
    try{ return (state && state.templates instanceof Map) ? state.templates : new Map(); }catch(_){ return new Map(); }
  }
  function templateDisplayName(item){
    // For the size dropdown, show only the DXF/template filename, not the category/folder prefix.
    // Example: "Deuren METOD/Metod deur 20x80.dxf" -> "Metod deur 20x80".
    const raw = toStr(item?.sourceName || item?.fileName || item?.label).trim();
    const base = raw.split(/[\\/]/).pop() || raw;
    return base.replace(/\.dxf$/i,'').trim() || base || raw;
  }
  function getAvailableTypes(state){
    const catalog = getCatalog(state);
    return Object.keys(catalog).filter(k => Array.isArray(catalog[k]) && catalog[k].length > 0);
  }
  function getCatalogList(state, type){
    const key = toStr(type).trim();
    const catalog = getCatalog(state);
    const list = Array.isArray(catalog[key]) ? catalog[key].slice() : [];
    return list;
  }
  function getTemplateTypeFromSelection(state, templateId){
    const targetId = toStr(templateId || state?.selection?.templateId).trim();
    if(!targetId) return '';
    try{
      const tpl = getTemplateMap(state).get(targetId) || null;
      return toStr(tpl?.type).trim();
    }catch(_){ return ''; }
  }
  function getPreferredPanelType(state){
    const available = getAvailableTypes(state);
    let nextType = toStr(state?.selection?.type).trim();
    if(nextType && available.includes(nextType)) return nextType;

    const tplType = getTemplateTypeFromSelection(state);
    if(tplType && available.includes(tplType)) return tplType;

    if(available.includes('deur')) return 'deur';
    if(available.includes('pax_deur')) return 'pax_deur';
    if(available.includes('lade')) return 'lade';
    return available[0] || '';
  }
  function buildSpecialGroups(list){
    const byKind = {};
    list.forEach(item => {
      const kind = toStr(item?.kind).trim() || 'Special';
      if(!byKind[kind]) byKind[kind] = [];
      byKind[kind].push(item);
    });
    return Object.keys(byKind).sort().map(kind => ({
      key: kind,
      label: kind,
      items: byKind[kind].map(item => ({
        templateId: toStr(item?.templateId).trim(),
        label: templateDisplayName(item),
        raw: item
      }))
    }));
  }
  function buildGroupedWidthGroups(list){
    const byWidth = {};
    list.forEach(item => {
      const cmW = toNum(item?.cmW, null);
      const key = Number.isFinite(cmW) ? String(cmW) : '0';
      if(!byWidth[key]) byWidth[key] = [];
      byWidth[key].push(item);
    });
    return Object.keys(byWidth)
      .map(k => Number(k))
      .sort((a,b)=>a-b)
      .map(cmW => ({
        key: String(cmW),
        label: `Breedte ${cmW} cm`,
        items: byWidth[String(cmW)]
          .slice()
          .sort((a,b)=>toNum(a?.cmH, 0)-toNum(b?.cmH, 0))
          .map(item => ({
            templateId: toStr(item?.templateId).trim(),
            label: templateDisplayName(item),
            raw: item
          }))
      }));
  }
  function getSizeOptionGroups(state, type){
    const key = toStr(type).trim();
    const list = getCatalogList(state, key);
    if(key === 'special') return buildSpecialGroups(list);
    return buildGroupedWidthGroups(list);
  }
  function getFlatSizeOptions(state, type){
    return getSizeOptionGroups(state, type).flatMap(group => Array.isArray(group?.items) ? group.items : []);
  }
  function getPreferredTemplateId(state, type, currentTemplateId){
    const currentId = toStr(currentTemplateId || state?.selection?.templateId).trim();
    const options = getFlatSizeOptions(state, type);
    if(currentId && options.some(item => toStr(item?.templateId).trim() === currentId)) return currentId;
    const first = options.find(item => toStr(item?.templateId).trim());
    return toStr(first?.templateId).trim();
  }
  function getTypeSizeUiState(state, type, templateId){
    const key = toStr(type).trim();
    const tplId = toStr(templateId).trim();
    let templateSupportsHinge = false;
    try{
      const tpl = tplId ? (getTemplateMap(state).get(tplId) || null) : null;
      templateSupportsHinge = !!(tpl && (tpl.supportsHinge || tpl.type === 'deur' || tpl.type === 'pax_deur' || tpl.kind === 'Hoekkast'));
    }catch(_){ }
    return {
      hingeEnabled: !!((key === 'deur' || key === 'pax_deur') || templateSupportsHinge),
      addEnabled: !!(key && tplId && toStr(state?.activeMaterialKey).trim()),
      hasTemplate: !!tplId,
      hasType: !!key
    };
  }
  function getDecisionSnapshot(state){
    const type = getPreferredPanelType(state);
    const groups = getSizeOptionGroups(state, type);
    const templateId = getPreferredTemplateId(state, type, state?.selection?.templateId);
    return {
      type,
      groups,
      templateId,
      ui: getTypeSizeUiState(state, type, templateId)
    };
  }

  window.ToolATypeSizeDecisions = {
    getAvailableTypes,
    getCatalogList,
    getPreferredPanelType,
    getSizeOptionGroups,
    getFlatSizeOptions,
    getPreferredTemplateId,
    getTypeSizeUiState,
    getDecisionSnapshot
  };
})();
