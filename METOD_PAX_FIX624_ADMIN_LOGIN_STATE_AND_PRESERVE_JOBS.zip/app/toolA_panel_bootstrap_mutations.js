(function(){
  function toStr(v){ return v == null ? '' : String(v); }
  function toNum(v, fallback){
    const n = Number(v);
    return Number.isFinite(n) ? n : (fallback == null ? 0 : fallback);
  }
  function defaultClampInt(v, min, max){
    const n = Math.round(toNum(v, min == null ? 0 : min));
    const lo = Number.isFinite(Number(min)) ? Number(min) : n;
    const hi = Number.isFinite(Number(max)) ? Number(max) : n;
    return Math.max(lo, Math.min(hi, n));
  }

  function getBootstrapPlan(opts){
    const state = opts?.state || {};
    const selection = state.selection || {};
    const catalog = state.catalog || {};
    const clampInt = typeof opts?.clampInt === 'function' ? opts.clampInt : defaultClampInt;
    const force = !!opts?.force;
    const activeMaterialKey = toStr(state.activeMaterialKey || '');
    const hasMaterial = !!(activeMaterialKey && state.material);
    const validTypes = Object.keys(catalog).filter(k => Array.isArray(catalog[k]) && catalog[k].length > 0);
    const currentType = toStr(selection.type || '').trim();
    let needsReset = force;
    if(!currentType || !validTypes.includes(currentType)) needsReset = true;
    const currentList = (!needsReset && currentType) ? (catalog[currentType] || []) : [];
    const currentTemplateId = toStr(selection.templateId || '').trim();
    if(!currentTemplateId || !currentList.some(x => toStr(x?.templateId || '') === currentTemplateId)) needsReset = true;

    const nextType = needsReset ? '' : currentType;
    const nextTemplateId = needsReset ? '' : currentTemplateId;
    const qty = clampInt(selection.qty || 1, 1, 999);
    const resetSelection = {
      type: '',
      templateId: '',
      qty,
      extTop: 0,
      extBot: 0
    };
    const keepSelection = {
      type: nextType,
      templateId: nextTemplateId,
      qty,
      extTop: toNum(selection.extTop, 0),
      extBot: toNum(selection.extBot, 0)
    };
    return {
      hasMaterial,
      validTypes,
      needsReset,
      selection: needsReset ? resetSelection : keepSelection,
      ui: {
        typeValue: nextType,
        sizeValue: nextTemplateId,
        sizePlaceholder: '<option value="">— Kies maat —</option>',
        extTop: needsReset ? 0 : keepSelection.extTop,
        extBot: needsReset ? 0 : keepSelection.extBot,
        addEnabled: !!(activeMaterialKey && nextType && nextTemplateId)
      }
    };
  }

  function getNoMaterialsResetState(opts){
    const currentSelection = opts?.selection || {};
    const clampInt = typeof opts?.clampInt === 'function' ? opts.clampInt : defaultClampInt;
    return {
      selection: {
        type: null,
        templateId: null,
        qty: clampInt(currentSelection.qty || 1, 1, 999),
        extTop: 0,
        extBot: 0,
        customLabel: ''
      },
      ui: {
        typeValue: '',
        sizeValue: '',
        sizePlaceholder: '<option value="">— Kies maat —</option>',
        qty: 1,
        extTop: 0,
        extBot: 0,
        addEnabled: false
      }
    };
  }

  window.ToolAPanelBootstrapMutations = {
    getBootstrapPlan,
    getNoMaterialsResetState
  };
})();
