(function(){
  function toStr(v, fb){ return String(v == null ? (fb == null ? '' : fb) : v); }
  function toNum(v, fb){
    const n = Number(v);
    return Number.isFinite(n) ? n : Number(fb == null ? 0 : fb);
  }
  function clampQty(v){
    const n = Math.round(Number(v || 1));
    return Number.isFinite(n) && n > 0 ? n : 1;
  }
  function buildSubmitPlan(input){
    const submitFlow = input?.submitFlow || null;
    const els = input?.elements || {};
    if(submitFlow && typeof submitFlow.getSubmitPlan === 'function'){
      return submitFlow.getSubmitPlan({
        width: els.extraW?.value,
        height: els.extraH?.value,
        qty: els.extraQty?.value,
        editIndex: input?.editIndex,
        materialKey: els.extraMat?.value,
        idPrefix: toStr(input?.constants?.idPrefix || 'EX_') || 'EX_',
        minWidthMm: Math.max(1, toNum(input?.constants?.minWidthMm, 40)),
        rerenderExtraPanels: true,
        syncChecks: true,
        redrawExtraPreviewBeforeReset: true,
        resetForm: true,
        redrawExtraPreviewAfterReset: true,
        clearEditIndex: true
      });
    }
    return null;
  }
  function fallbackValidation(input){
    const els = input?.elements || {};
    const widthRaw = Number(els.extraW?.value);
    const heightRaw = Number(els.extraH?.value);
    const minWidth = Math.max(1, toNum(input?.constants?.minWidthMm, 40));
    return {
      ok: Number.isFinite(widthRaw) && Number.isFinite(heightRaw) && widthRaw > 0 && heightRaw > 0 && widthRaw >= minWidth,
      width: Math.round(widthRaw || 0),
      height: Math.round(heightRaw || 0),
      qty: clampQty(els.extraQty?.value),
      alertMessage: widthRaw < minWidth
        ? `Overige panelen moeten minimaal ${minWidth} mm breed zijn. Vul een breedte van ${minWidth} mm of groter in.`
        : 'Vul een geldige breedte en hoogte in (mm).'
    };
  }
  function buildRawItem(input, validation){
    const els = input?.elements || {};
    const hooks = input?.hooks || {};
    const mk = toStr(els.extraMat?.value || '').trim();
    const materialArticleNumberKey = hooks?.materialArticleNumberKey;
    const materialArticleNumber = hooks?.materialArticleNumber;
    const materialThicknessKey = hooks?.materialThicknessKey;
    const resolvedThickness = (typeof materialThicknessKey === 'function')
      ? materialThicknessKey(mk)
      : input?.constants?.defaultThicknessMm;
    return {
      name: toStr(els.extraName?.value || ''),
      w: validation.width,
      h: validation.height,
      qty: validation.qty,
      materialKey: mk,
      material: mk,
      articleNumber: (typeof materialArticleNumberKey === 'function' ? materialArticleNumberKey(mk) : '') || (typeof materialArticleNumber === 'function' ? materialArticleNumber(mk) : ''),
      thicknessMm: toNum(resolvedThickness, input?.constants?.defaultThicknessMm ?? 18),
      edge: toStr(els.extraEdge?.value || 'none') || 'none'
    };
  }
  function resolveEditIndex(v){
    if(v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isInteger(n) && n >= 0 ? n : null;
  }
  function normalizeMutationPlan(plan, editIndex, idPrefix, mutationAdapter){
    const base = plan && typeof plan === 'object' ? Object.assign({}, plan) : {};
    const resolvedIndex = base.index != null ? resolveEditIndex(base.index) : resolveEditIndex(base.editIndex);
    if(base.mode !== 'replace' && base.mode !== 'append'){
      base.mode = resolvedIndex == null ? 'append' : 'replace';
    }
    base.index = resolvedIndex;
    base.editIndex = resolvedIndex;
    base.idPrefix = toStr(base.idPrefix || idPrefix || 'EX_') || 'EX_';
    if(base.mode === 'replace' && resolvedIndex == null && mutationAdapter && typeof mutationAdapter.getUpsertPlan === 'function'){
      const adapterPlan = mutationAdapter.getUpsertPlan({ editIndex, idPrefix: base.idPrefix }) || {};
      const adapterIndex = adapterPlan.index != null ? resolveEditIndex(adapterPlan.index) : resolveEditIndex(adapterPlan.editIndex);
      base.index = adapterIndex;
      base.editIndex = adapterIndex;
      base.mode = adapterIndex == null ? 'append' : 'replace';
    }
    return base;
  }
  function applyMutation(input, item, submitPlan){
    const state = input?.state || {};
    const mutationAdapter = input?.mutationAdapter || null;
    const idPrefix = toStr(input?.constants?.idPrefix || 'EX_') || 'EX_';
    const editIndex = resolveEditIndex(input?.editIndex);
    const mutationPlan = normalizeMutationPlan((submitPlan && submitPlan.mutation) || ((mutationAdapter && typeof mutationAdapter.getUpsertPlan === 'function')
      ? mutationAdapter.getUpsertPlan({ editIndex, idPrefix })
      : { mode: editIndex === null ? 'append' : 'replace', index: editIndex, idPrefix }), editIndex, idPrefix, mutationAdapter);
    const applied = (mutationAdapter && typeof mutationAdapter.applyUpsert === 'function')
      ? mutationAdapter.applyUpsert(state.extraPanels, item, mutationPlan)
      : null;
    if(applied && Array.isArray(applied.items)){
      state.extraPanels = applied.items;
      return { applied: true, mutationPlan, result: applied };
    }
    state.extraPanels = Array.isArray(state.extraPanels) ? state.extraPanels : [];
    if(editIndex === null){
      item.id = item.id || (idPrefix + Date.now() + Math.random());
      state.extraPanels.push(item);
    }else{
      item.id = state.extraPanels[editIndex]?.id || (idPrefix + Date.now() + Math.random());
      state.extraPanels[editIndex] = item;
    }
    return { applied: false, mutationPlan, result: null };
  }
  function applyPostSubmit(input, submitPlan){
    const hooks = input?.hooks || {};
    const postSubmit = (submitPlan && submitPlan.postSubmit) || { rerenderExtraPanels:true, syncChecks:true, redrawExtraPreviewBeforeReset:true, resetForm:true, redrawExtraPreviewAfterReset:true, clearEditIndex:true };
    try{ if(postSubmit.rerenderExtraPanels && typeof hooks.renderExtraPanels === 'function') hooks.renderExtraPanels(); }catch(_){ }
    try{ if(postSubmit.rerenderExtraPanels && typeof hooks.renderCart === 'function') hooks.renderCart(); }catch(_){ }
    try{ if(postSubmit.syncChecks && typeof hooks.syncChecksFromSelect === 'function') hooks.syncChecksFromSelect(); }catch(_){ }
    try{ if(postSubmit.redrawExtraPreviewBeforeReset && typeof hooks.drawExtraPreview === 'function') hooks.drawExtraPreview(); }catch(_){ }
    try{ if(postSubmit.clearEditIndex){ if(typeof hooks.setEditIndex === 'function') hooks.setEditIndex(null); } }catch(_){ }
    try{ if(postSubmit.resetForm && typeof hooks.resetExtraForm === 'function') hooks.resetExtraForm(); }catch(_){ }
    try{ if(postSubmit.redrawExtraPreviewAfterReset && typeof hooks.drawExtraPreview === 'function') hooks.drawExtraPreview(); }catch(_){ }
    return postSubmit;
  }
  function execute(input){
    const hooks = input?.hooks || {};
    const state = input?.state || null;
    if(!state) return { ok:false, reason:'missing-state' };
    const submitPlan = buildSubmitPlan(input);
    const validation = (submitPlan && submitPlan.validation) ? submitPlan.validation : fallbackValidation(input);
    try{ if(typeof hooks.updateExtraEdgeLabels === 'function') hooks.updateExtraEdgeLabels(); }catch(_){ }
    if(!validation.ok){
      try{ alert(validation.alertMessage || 'Vul een geldige breedte en hoogte in (mm).'); }catch(_){ }
      return { ok:false, reason:'invalid-dimensions', validation, submitPlan };
    }
    try{
      const mkTmp = toStr(input?.elements?.extraMat?.value || '');
      const rotationAllowed = (state?.grainEnabled === false);
      if(typeof hooks.validatePanelFits === 'function' && !hooks.validatePanelFits(validation.width, validation.height, mkTmp, rotationAllowed)){
        return { ok:false, reason:'sheet-fit-invalid', validation, submitPlan };
      }
    }catch(_){ }
    const rawItem = buildRawItem(input, validation);
    const item = (input?.mutationAdapter && typeof input.mutationAdapter.buildItem === 'function') ? input.mutationAdapter.buildItem(rawItem) : rawItem;
    try{ if(typeof hooks.clearAllGrainAssignments === 'function') hooks.clearAllGrainAssignments(); }catch(_){ }
    const mutation = applyMutation(input, item, submitPlan);
    const postSubmit = applyPostSubmit(input, submitPlan);
    return { ok:true, submitPlan, validation, item, mutation, postSubmit };
  }

  window.ToolAExtraPanelSubmitApply = {
    buildSubmitPlan,
    fallbackValidation,
    buildRawItem,
    applyMutation,
    applyPostSubmit,
    execute
  };
})();
