(function(){
  function esc(s){
    return String(s == null ? '' : s)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#39;');
  }

  function grainSuffix(rep, grainGroups){
    try{
      if(!rep || !rep.grainGroupId) return '';
      const groups = Array.isArray(grainGroups) ? grainGroups : [];
      const hit = groups.find(g => String(g?.id||'') === String(rep.grainGroupId||''));
      const total = Math.max(1, Array.isArray(hit?.items) ? hit.items.length : 0) || '?';
      return ` · Nerfgroep ${esc(rep.grainGroupId)} (${rep.grainOrder||1}/${total||'?'})`;
    }catch(_){ return ''; }
  }

  function getCartGroupRowModel(group, opts){
    const rep = group?.rep || {};
    const items = Array.isArray(group?.items) ? group.items : [];
    const count = Math.max(1, items.length || 0);
    const editContext = opts?.editContext || null;
    const isEditingGroup = typeof opts?.isEditingGroup === 'function' ? opts.isEditingGroup : null;
    const isEditing = !!(isEditingGroup && editContext ? isEditingGroup(group, editContext) : false);
    const hingeText = (rep.type === 'deur' || rep.type === 'pax_deur' || rep.supportsHinge || rep.kind === 'Hoekkast') ? ` · ${rep.hinge === 'left' ? 'scharnier links' : 'scharnier rechts'}` : '';
    const extTop = Number(rep.extTop) || 0;
    const extBot = Number(rep.extBot) || 0;
    return {
      title: String(rep.label || ''),
      count,
      isEditing,
      metaText: `${count}× · ${esc(`${rep.cmW}×${rep.cmH} cm`)}${hingeText} · verlengen +${extTop} / +${extBot}${grainSuffix(rep, opts?.grainGroups)}`
    };
  }

  function getExtraRowModel(p, idx, opts){
    const qty = Math.max(1, Number(p?.qty) || 1);
    const title = String((p?.name || '').trim() || `Overig paneel ${p?.w||0}×${p?.h||0}`);
    const getMaterialLabel = typeof opts?.getMaterialLabel === 'function' ? opts.getMaterialLabel : (v => String(v||''));
    const getEdgeText = typeof opts?.getEdgeText === 'function' ? opts.getEdgeText : (() => '');
    const materialText = getMaterialLabel(p?.materialKey || p?.material || '');
    const edgeText = getEdgeText(p?.edge || 'none', Number(p?.w||0), Number(p?.h||0));
    return {
      index: Number.isFinite(Number(idx)) ? Number(idx) : null,
      qty,
      title,
      metaText: `${qty}× · ${esc(`${p?.w||0}×${p?.h||0} mm`)} · ${esc(materialText)} · kantenband: ${esc(edgeText)}`
    };
  }

  window.ToolAPanelRowViewModels = {
    getCartGroupRowModel,
    getExtraRowModel
  };
})();
