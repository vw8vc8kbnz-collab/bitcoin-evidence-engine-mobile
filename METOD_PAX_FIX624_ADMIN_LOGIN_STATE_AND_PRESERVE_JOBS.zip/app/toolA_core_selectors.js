(function(){
  function toStr(v){ return v == null ? '' : String(v); }
  function toNum(v, fallback){
    const n = Number(v);
    return Number.isFinite(n) ? n : (fallback == null ? 0 : fallback);
  }
  function clone(value){
    try{
      if (typeof structuredClone === 'function') return structuredClone(value);
    }catch(_){ }
    try{ return JSON.parse(JSON.stringify(value)); }catch(_){ return value; }
  }
  function byId(id){
    try{ return document.getElementById(id); }catch(_){ return null; }
  }
  function getState(){
    try{
      const s = window.state || null;
      if (s && window.ToolAStateHelpers && typeof window.ToolAStateHelpers.ensureStateShape === 'function') {
        try{ window.ToolAStateHelpers.ensureStateShape(s); }catch(_){ }
      }
      return s;
    }catch(_){ return null; }
  }
  function getCurrentStep(){
    try{
      const step = toStr(window.__metod_uiStep || document.body?.dataset?.uiStep || getState()?.ui?.step || 'material').trim();
      return step || 'material';
    }catch(_){ return 'material'; }
  }
  function getActiveMaterialKey(state){
    const s = state || getState();
    try{ return toStr(s?.activeMaterialKey || s?.selection?.materialKey || '').trim(); }catch(_){ return ''; }
  }
  function getMaterialBatches(state){
    const s = state || getState();
    try{ return Array.isArray(s?.materialBatches) ? s.materialBatches.slice() : []; }catch(_){ return []; }
  }
  function getActiveMaterialBatch(state){
    const s = state || getState();
    const key = getActiveMaterialKey(s);
    try{
      if (!key) return null;
      if (window.ToolAStateHelpers && typeof window.ToolAStateHelpers.getMaterialBatchByKey === 'function') {
        return window.ToolAStateHelpers.getMaterialBatchByKey(s, key) || null;
      }
      return getMaterialBatches(s).find(b => toStr(b?.key) === key) || null;
    }catch(_){ return null; }
  }
  function getMaterialContext(state){
    const s = state || getState();
    const activeBatch = getActiveMaterialBatch(s);
    const material = s?.material || activeBatch?.mat || null;
    return {
      activeMaterialKey: getActiveMaterialKey(s),
      activeBatchKey: toStr(activeBatch?.key || '').trim(),
      activeBatch: activeBatch ? clone(activeBatch) : null,
      activeMaterial: material ? clone(material) : null,
      materialBatchCount: getMaterialBatches(s).length,
      hasActiveMaterial: !!(material && (getActiveMaterialKey(s) || material.materialCode || material.articleNumber || material.decorName || material.productName))
    };
  }
  function getPanelFormSnapshot(state){
    const s = state || getState();
    const typeSel = byId('typeSel');
    const sizeSel = byId('sizeSel');
    const qty = byId('qty');
    const hingeSel = byId('hingeSel');
    const extTop = byId('extTop');
    const extBot = byId('extBot');
    const customLabelInput = byId('customLabelInput');
    const extraDesc = byId('extraDesc');
    const extraMat = byId('extraMat');
    const doorOptions = byId('doorOptions');
    const customLabelWrap = byId('customLabelWrap');
    return {
      selectedType: toStr(s?.selection?.type || typeSel?.value || '').trim(),
      selectedSize: toStr(s?.selection?.size || s?.selection?.sizeLabel || sizeSel?.value || '').trim(),
      selectedTemplateId: toStr(s?.selection?.templateId || '').trim(),
      qtyRaw: toStr(qty?.value ?? s?.selection?.qty ?? '').trim(),
      qty: Math.max(0, toNum(qty?.value ?? s?.selection?.qty ?? 0, 0)),
      hinge: toStr(s?.selection?.hinge || hingeSel?.value || '').trim(),
      extTop: toNum(extTop?.value ?? s?.selection?.extTop ?? 0, 0),
      extBot: toNum(extBot?.value ?? s?.selection?.extBot ?? 0, 0),
      customLabel: toStr(customLabelInput?.value || '').trim(),
      extraDescription: toStr(extraDesc?.value || '').trim(),
      extraMaterialKey: toStr(extraMat?.value || '').trim(),
      edge: toStr(s?.selection?.edge || '').trim(),
      controlsReady: !!(typeSel && sizeSel),
      typeDisabled: !!typeSel?.disabled,
      sizeDisabled: !!sizeSel?.disabled,
      qtyDisabled: !!qty?.disabled,
      doorOptionsVisible: !!(doorOptions && doorOptions.style.display !== 'none'),
      customLabelVisible: !!(customLabelWrap && customLabelWrap.style.display !== 'none')
    };
  }
  function getCartSnapshot(state){
    const s = state || getState();
    const cart = Array.isArray(s?.cart) ? s.cart : [];
    const extraPanels = Array.isArray(s?.extraPanels) ? s.extraPanels : [];
    const standardQty = cart.reduce((acc, item) => acc + Math.max(1, toNum(item?.qty, 1)), 0);
    const extraQty = extraPanels.reduce((acc, item) => acc + Math.max(1, toNum(item?.qty, 1)), 0);
    return {
      standardCount: cart.length,
      extraCount: extraPanels.length,
      standardQty,
      extraQty,
      totalLineCount: cart.length + extraPanels.length,
      totalQty: standardQty + extraQty,
      hasPanels: (cart.length + extraPanels.length) > 0,
      cart: clone(cart),
      extraPanels: clone(extraPanels)
    };
  }
  function getEditSnapshot(state){
    const s = state || getState();
    try{
      if (window.ToolAPanelEditContext && typeof window.ToolAPanelEditContext.getContext === 'function') {
        const ctx = window.ToolAPanelEditContext.getContext({ state: s });
        return {
          targetId: ctx?.targetId || null,
          groupKey: ctx?.groupKey || null,
          originalCount: Number(ctx?.originalCount || 0),
          isEditing: !!ctx?.isEditing,
          currentStep: toStr(ctx?.currentStep || getCurrentStep()).trim() || 'material',
          activeMaterialKey: toStr(ctx?.activeMaterialKey || getActiveMaterialKey(s)).trim()
        };
      }
    }catch(_){ }
    let targetId = null, groupKey = null, originalCount = 0;
    try{ targetId = window.ToolAStateHelpers?.getPanelEditTargetId?.() ?? window.__panelEditTargetId ?? null; }catch(_){ targetId = null; }
    try{ groupKey = window.ToolAStateHelpers?.getPanelEditGroupKey?.() ?? window.__panelEditGroupKey ?? null; }catch(_){ groupKey = null; }
    try{ originalCount = window.ToolAStateHelpers?.getPanelEditOriginalCount?.() ?? Number(window.__panelEditOriginalCount || 0); }catch(_){ originalCount = 0; }
    return {
      targetId,
      groupKey,
      originalCount: Number(originalCount || 0),
      isEditing: !!(targetId || groupKey),
      currentStep: getCurrentStep(),
      activeMaterialKey: getActiveMaterialKey(s)
    };
  }
  function getCustomerSnapshot(state){
    const s = state || getState();
    const checkout = s?.checkout || {};
    const customer = checkout?.customer || {};
    const getVal = (id, fallback='') => toStr(byId(id)?.value || fallback).trim();
    const shipSameEl = byId('custShipSame');
    return {
      firstName: getVal('custFirstName', customer.firstName || ''),
      lastName: getVal('custLastName', customer.lastName || ''),
      company: getVal('custCompany', customer.company || customer.companyName || ''),
      email: getVal('custEmail', customer.email || ''),
      phone: getVal('custPhone', customer.phone || ''),
      billingAddress: getVal('custBillingAddress', customer.billingAddress || customer.invoiceAddress || ''),
      shippingAddress: getVal('custShippingAddress', customer.shippingAddress || customer.deliveryAddress || customer.address1 || ''),
      postcode: getVal('custPostcode', customer.postcode || ''),
      houseNumber: getVal('custHouseNumber', customer.houseNumber || ''),
      note: getVal('custNote', checkout.note || ''),
      shippingSameAsBilling: shipSameEl ? !!shipSameEl.checked : (customer.shippingSameAsBilling !== false),
      restCarry: checkout.restCarry !== false,
      requiredReady: !!(getVal('custPostcode', customer.postcode || '') && getVal('custHouseNumber', customer.houseNumber || ''))
    };
  }
  function getGrainSnapshot(state){
    const s = state || getState();
    const grain = s?.grain || {};
    const groups = Array.isArray(grain.groups) ? grain.groups : [];
    return {
      enabled: s?.grainEnabled !== false,
      selectedGroupId: grain.selectedGroupId || null,
      includeExtraPanels: !!grain.includeExtraPanels,
      groupCount: groups.length,
      validGroupCount: groups.filter(g => Array.isArray(g?.items) && g.items.length > 1).length,
      groups: clone(groups)
    };
  }
  function getWizardSnapshot(state){
    const s = state || getState();
    const material = getMaterialContext(s);
    const cart = getCartSnapshot(s);
    const customer = getCustomerSnapshot(s);
    const grain = getGrainSnapshot(s);
    const edit = getEditSnapshot(s);
    return {
      currentStep: getCurrentStep(),
      material,
      cart,
      customer,
      grain,
      edit,
      canEnterPanels: material.hasActiveMaterial,
      canEnterGrain: cart.hasPanels,
      canEnterCustomer: cart.hasPanels,
      canEnterOverview: cart.hasPanels && customer.requiredReady
    };
  }
  window.ToolACoreSelectors = {
    getState,
    getCurrentStep,
    getActiveMaterialKey,
    getMaterialBatches,
    getActiveMaterialBatch,
    getMaterialContext,
    getPanelFormSnapshot,
    getCartSnapshot,
    getEditSnapshot,
    getCustomerSnapshot,
    getGrainSnapshot,
    getWizardSnapshot
  };
})();
