(function(){
  function toStr(v){ return v == null ? '' : String(v); }
  function toNum(v){ const n = Number(v); return Number.isFinite(n) ? n : NaN; }
  function edgeMaskFromValue(value){
    const map = { top:false, right:false, bottom:false, left:false };
    const raw = toStr(value).trim().toLowerCase();
    if(!raw || raw === 'none') return map;
    if(raw === 'all') return { top:true, right:true, bottom:true, left:true };
    if(raw === 'lr') return { top:false, right:true, bottom:false, left:true };
    if(raw === 'tb') return { top:true, right:false, bottom:true, left:false };
    const bitMatch = raw.match(/^t([01])r([01])b([01])l([01])$/);
    if(bitMatch){
      return {
        top: bitMatch[1] === '1',
        right: bitMatch[2] === '1',
        bottom: bitMatch[3] === '1',
        left: bitMatch[4] === '1'
      };
    }
    raw.split(',').map(s => s.trim()).filter(Boolean).forEach(part => {
      if(part === 'top') map.top = true;
      else if(part === 'right') map.right = true;
      else if(part === 'bottom') map.bottom = true;
      else if(part === 'left') map.left = true;
    });
    return map;
  }

  function getMaterialOptionsState(state, options){
    const s = state || window.state || {};
    const opts = options || {};
    const currentValue = toStr(opts.currentValue).trim();
    const batches = Array.isArray(s.materialBatches) ? s.materialBatches : [];
    const labelFor = typeof opts.materialLabelMat === 'function'
      ? opts.materialLabelMat
      : (mat => toStr(mat?.decorName || mat?.productName || mat?.articleNumber || ''));
    if(!batches.length){
      return {
        disabled: true,
        options: [],
        selectedValue: '',
        emptyLabel: '— kies eerst een materiaal —'
      };
    }
    const optionsList = batches.map(batch => ({
      value: toStr(batch?.key).trim(),
      label: toStr(labelFor(batch?.mat || { decorName: batch?.key })).trim() || toStr(batch?.key).trim(),
      batch
    }));
    const activeKey = toStr(s.activeMaterialKey).trim();
    const selectedValue = optionsList.some(opt => opt.value === currentValue)
      ? currentValue
      : (optionsList.some(opt => opt.value === activeKey) ? activeKey : optionsList[0].value);
    return {
      disabled: false,
      options: optionsList,
      selectedValue,
      emptyLabel: '— kies eerst een materiaal —'
    };
  }

  function getPreviewSnapshot(input){
    const src = input || {};
    const width = toNum(src.width);
    const height = toNum(src.height);
    const edge = toStr(src.edge).trim() || 'none';
    const hasDimensions = Number.isFinite(width) && Number.isFinite(height) && width > 0 && height > 0;
    return {
      width: hasDimensions ? width : NaN,
      height: hasDimensions ? height : NaN,
      edge,
      edgeMask: edgeMaskFromValue(edge),
      hasDimensions,
      emptyHint: toStr(src.emptyHint).trim() || 'Vul breedte en hoogte in om preview te zien.'
    };
  }

  window.ToolAExtraPanelViewState = {
    getMaterialOptionsState,
    getPreviewSnapshot
  };
})();
