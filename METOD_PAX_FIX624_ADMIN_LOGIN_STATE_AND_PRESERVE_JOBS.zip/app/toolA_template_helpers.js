(function(){
  function makeDynamicTypeKey(folderLabel){
    const raw = String(folderLabel||'').trim().toLowerCase();
    if(!raw) return 'special';
    return 'cat_' + raw
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 48);
  }

  function parseMetaFromFilename(name){
    const raw = String(name||'').trim();
    const parts = raw.split('/').filter(Boolean);
    const folderLabel = (parts.length>1 ? String(parts[0]).trim() : '');
    const folder = folderLabel.toLowerCase();
    const baseRaw = (parts.length>0 ? parts[parts.length-1] : raw);
    const base = String(baseRaw).toLowerCase().replace(/\.dxf$/i,'').trim();

    let type = 'special';
    if(folder === 'deuren pax') type = 'pax_deur';
    else if(folder === 'deuren metod') type = 'deur';
    else if(folder === 'ladefront metod') type = 'lade';
    else if(folder === 'overige panelen') type = 'special';
    else if(folderLabel) type = makeDynamicTypeKey(folderLabel);
    else {
      if(base.startsWith('pax')) type = 'pax_deur';
      else if(base.includes('deur')) type = 'deur';
      else if(base.includes('lade')) type = base.includes('apothekerslade') ? 'special' : 'lade';
    }

    const m = base.match(/(\d+(?:[\.,]\d+)?)\s*[x×]\s*(\d+(?:[\.,]\d+)?)/);
    const cmW = m ? parseFloat(String(m[1]).replace(',','.')) : null;
    const cmH = m ? parseFloat(String(m[2]).replace(',','.')) : null;

    let kind = null;
    if(base.includes('apothekerslade')) kind = 'Apothekerslade';
    else if(base.includes('hoekkast')) kind = 'Hoekkast';
    else if(type==='lade') kind = 'Ladefront';
    else if(type==='deur') kind = 'Deur';
    else if(type==='pax_deur') kind = 'Deur PAX';
    else kind = folderLabel || 'Special';

    return { type, cmW, cmH, kind, folderLabel };
  }

  function parseDXFMinimal(text){
    const lines = String(text||'').replace(/\r/g,'').split('\n');
    const pairs = [];
    for(let i=0;i<lines.length-1;i+=2){
      const code = lines[i].trim();
      const val = (lines[i+1] ?? '').trim();
      if(code === '') continue;
      const ncode = parseInt(code,10);
      if(Number.isFinite(ncode)) pairs.push([ncode, val]);
    }

    let inEntities = false;
    const circles = [];
    const arcs = [];
    const lwpolys = [];
    const polys = [];
    const linesEnt = [];

    let i = 0;
    while(i < pairs.length){
      const [c,v] = pairs[i];
      if(c===0 && v==='SECTION'){
        const n1 = pairs[i+1];
        const n2 = pairs[i+2];
        if(n1 && n2 && n1[0]===2 && n1[1]==='ENTITIES') inEntities = true;
        i += 1;
      }
      if(c===0 && v==='ENDSEC') inEntities = false;

      if(inEntities && c===0){
        const entType = v;
        if(entType === 'CIRCLE'){
          const ent = readEntity(pairs, i);
          circles.push({x: ent.x ?? 0, y: ent.y ?? 0, r: ent.r ?? 0});
          i = ent.next;
          continue;
        }
        if(entType === 'ARC'){
          const ent = readArc(pairs, i);
          arcs.push({x: ent.x ?? 0, y: ent.y ?? 0, r: ent.r ?? 0, startDeg: ent.startDeg ?? 0, endDeg: ent.endDeg ?? 0});
          i = ent.next;
          continue;
        }
        if(entType === 'LWPOLYLINE'){
          const ent = readLWPolyline(pairs, i);
          if(ent.points.length) lwpolys.push(ent);
          i = ent.next;
          continue;
        }
        if(entType === 'POLYLINE'){
          const ent = readPolyline(pairs, i);
          if(ent.points.length) polys.push(ent);
          i = ent.next;
          continue;
        }
        if(entType === 'LINE'){
          const ent = readLine(pairs, i);
          linesEnt.push(ent.line);
          i = ent.next;
          continue;
        }
      }
      i++;
    }

    return { circles, arcs, lwpolys, polys, lines: linesEnt };
  }

  function readEntity(pairs, startIdx){
    let x=null,y=null,r=null;
    let i = startIdx+1;
    while(i < pairs.length){
      const [c,v] = pairs[i];
      if(c===0) break;
      if(c===10) x = parseFloat(v);
      if(c===20) y = parseFloat(v);
      if(c===40) r = parseFloat(v);
      i++;
    }
    return {x,y,r,next:i};
  }

  function readArc(pairs, startIdx){
    let x=null,y=null,r=null,startDeg=0,endDeg=0;
    let i = startIdx+1;
    while(i < pairs.length){
      const [c,v] = pairs[i];
      if(c===0) break;
      if(c===10) x = parseFloat(v);
      if(c===20) y = parseFloat(v);
      if(c===40) r = parseFloat(v);
      if(c===50) startDeg = parseFloat(v);
      if(c===51) endDeg = parseFloat(v);
      i++;
    }
    return {x,y,r,startDeg,endDeg,next:i};
  }

  function readLine(pairs, startIdx){
    let x1=null,y1=null,x2=null,y2=null;
    let i = startIdx+1;
    while(i < pairs.length){
      const [c,v] = pairs[i];
      if(c===0) break;
      if(c===10) x1 = parseFloat(v);
      if(c===20) y1 = parseFloat(v);
      if(c===11) x2 = parseFloat(v);
      if(c===21) y2 = parseFloat(v);
      i++;
    }
    return { line: {x1:x1??0,y1:y1??0,x2:x2??0,y2:y2??0}, next:i };
  }

  function readLWPolyline(pairs, startIdx){
    let closed = false;
    const pts = [];
    let i = startIdx+1;
    let currX = null;
    while(i < pairs.length){
      const [c,v] = pairs[i];
      if(c===0) break;
      if(c===70){
        const flags = parseInt(v,10) || 0;
        closed = (flags & 1) === 1;
      }
      if(c===10){ currX = parseFloat(v); }
      if(c===20){
        const y = parseFloat(v);
        if(currX !== null) pts.push({x: currX, y});
        currX = null;
      }
      i++;
    }
    return { points: pts, closed, next: i };
  }

  function readPolyline(pairs, startIdx){
    let closed = false;
    const pts = [];
    let i = startIdx+1;
    while(i < pairs.length){
      const [c,v] = pairs[i];
      if(c===0 && v==='VERTEX'){
        let vx=null,vy=null;
        i++;
        while(i < pairs.length){
          const [cc,vv] = pairs[i];
          if(cc===0) break;
          if(cc===10) vx = parseFloat(vv);
          if(cc===20) vy = parseFloat(vv);
          i++;
        }
        if(vx!==null && vy!==null) pts.push({x:vx,y:vy});
        continue;
      }
      if(c===70){
        const flags = parseInt(v,10) || 0;
        closed = (flags & 1) === 1;
      }
      if(c===0 && (v==='SEQEND' || v==='ENDSEC')) break;
      if(c===0 && v!=='VERTEX') break;
      i++;
    }
    return { points: pts, closed, next: i };
  }

  

  function buildTemplate(filename, meta, geom){
    const safeMeta = meta || {};
    const safeGeom = geom || { circles:[], lwpolys:[], polys:[], lines:[] };
    const circles = Array.isArray(safeGeom.circles) ? safeGeom.circles : [];
    const arcs = Array.isArray(safeGeom.arcs) ? safeGeom.arcs : [];
    const outlinePts = [];
    function pushPt(x,y){ if(Number.isFinite(x) && Number.isFinite(y)) outlinePts.push({x,y}); }
    for(const lp of (Array.isArray(safeGeom.lwpolys)?safeGeom.lwpolys:[])){
      for(const p of (Array.isArray(lp.points)?lp.points:[])) pushPt(Number(p.x), Number(p.y));
    }
    for(const pl of (Array.isArray(safeGeom.polys)?safeGeom.polys:[])){
      for(const p of (Array.isArray(pl.points)?pl.points:[])) pushPt(Number(p.x), Number(p.y));
    }
    for(const ln of (Array.isArray(safeGeom.lines)?safeGeom.lines:[])){
      pushPt(Number(ln.x1), Number(ln.y1));
      pushPt(Number(ln.x2), Number(ln.y2));
    }
    let minX=0, minY=0, maxX=0, maxY=0;
    if(outlinePts.length){
      minX = Math.min(...outlinePts.map(p=>p.x));
      maxX = Math.max(...outlinePts.map(p=>p.x));
      minY = Math.min(...outlinePts.map(p=>p.y));
      maxY = Math.max(...outlinePts.map(p=>p.y));
    }else{
      const w = Number(safeMeta.cmW || 0) * 10;
      const h = Number(safeMeta.cmH || 0) * 10;
      minX = 0; minY = 0; maxX = w; maxY = h;
    }
    const realW = Math.max(0, Math.round(maxX - minX)) || Math.max(0, Number(safeMeta.cmW || 0) * 10);
    const realH = Math.max(0, Math.round(maxY - minY)) || Math.max(0, Number(safeMeta.cmH || 0) * 10);
    const sourceName = String(filename||'').trim();
    const label = sourceName.replace(/\.dxf$/i,'').trim() || sourceName;
    const normMinX = Number.isFinite(minX) ? minX : 0;
    const normMinY = Number.isFinite(minY) ? minY : 0;
    return {
      id: makeTemplateId(sourceName),
      label,
      sourceName,
      fileName: sourceName,
      type: safeMeta.type || 'special',
      kind: safeMeta.kind || 'Special',
      supportsHinge: true,
      cmW: safeMeta.cmW != null ? Number(safeMeta.cmW) : Math.round(realW/10),
      cmH: safeMeta.cmH != null ? Number(safeMeta.cmH) : Math.round(realH/10),
      realW,
      realH,
      outline: { minX:0, maxX:realW, minY:0, maxY:realH },
      holes: circles.map(c=>({
        x:(Number(c.x)||0) - normMinX,
        y:(Number(c.y)||0) - normMinY,
        r:Number(c.r)||0
      })),
      holeArcs: arcs.map(a=>({
        x:(Number(a.x)||0) - normMinX,
        y:(Number(a.y)||0) - normMinY,
        r:Number(a.r)||0,
        startDeg:Number(a.startDeg)||0,
        endDeg:Number(a.endDeg)||0
      }))
    };
  }

  function makeTemplateId(filename){
    return String(filename||'')
      .toLowerCase()
      .replace(/\.dxf$/,'')
      .replace(/[^a-z0-9]+/g,'_')
      .replace(/^_+|_+$/g,'');
  }

  window.ToolATemplateHelpers = {
    parseMetaFromFilename,
    parseDXFMinimal,
    buildTemplate,
    makeTemplateId
  };
})();
