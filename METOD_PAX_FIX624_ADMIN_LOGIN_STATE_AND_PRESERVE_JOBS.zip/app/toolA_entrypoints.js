(function(){
  const w = window;
  const STEP_SET = new Set(['material','panels','grain','customer','overview']);

  function call(fn, args, fallback){
    try{
      if(typeof fn === 'function') return fn.apply(null, args || []);
    }catch(err){
      console.warn('ToolAEntry call failed', err);
    }
    return fallback;
  }

  function resolveRaw(){
    return {
      showStep: w.__showWizardStep || w.showStep || null,
      renderFooter: w.renderFooterForStep || w.__renderWizardFooter || null,
      setDockOpen: w.setPanelDockOpen || null,
      restoreIdle: w.restoreIdleToolStateAfterStartError || null,
      startEdit: w.__startEditCartItem || null,
      setEditMode: w.__setPanelEditMode || null,
      renderCart: w.renderCart || null
    };
  }

  const entry = {
    version: 'FIX308_TOOLA_ENTRYPOINTS_NON_INVASIVE_PHASE7',
    get raw(){ return resolveRaw(); },
    getCurrentStep(){
      try{
        const step = (w.ToolACoreSelectors && typeof w.ToolACoreSelectors.getCurrentStep === 'function')
          ? String(w.ToolACoreSelectors.getCurrentStep() || 'material')
          : String(w.__metod_uiStep || w.document?.body?.dataset?.uiStep || 'material');
        return STEP_SET.has(step) ? step : 'material';
      }catch(_){ return 'material'; }
    },
    safeRenderFooter(step){
      const raw = resolveRaw();
      const target = STEP_SET.has(String(step||'')) ? String(step) : entry.getCurrentStep();
      return call(raw.renderFooter, [target], null);
    },
    goToStep(step, opts){
      const raw = resolveRaw();
      const target = STEP_SET.has(String(step||'')) ? String(step) : 'material';
      const out = call(raw.showStep, [target], null);
      if(!(opts && opts.skipFooter)){
        try{ entry.safeRenderFooter(target); }catch(_){ }
      }
      return out;
    },
    setDockOpen(open){
      const raw = resolveRaw();
      return call(raw.setDockOpen, [!!open], null);
    },
    enterPanelEdit(itemId){
      const raw = resolveRaw();
      return call(raw.startEdit, [itemId], null);
    },
    clearPanelEdit(){
      const raw = resolveRaw();
      call(raw.setEditMode, [null, 0, null], null);
      call(raw.renderCart, [], null);
      try{ entry.safeRenderFooter('panels'); }catch(_){ }
    },
    restoreIdleAfterServerError(){
      const raw = resolveRaw();
      return call(raw.restoreIdle, [], null);
    }
  };

  w.ToolAEntry = entry;
  w.__ToolAEntryVersion = entry.version;
})();
