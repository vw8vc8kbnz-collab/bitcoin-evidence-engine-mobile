(function(){
  const BASE_REQUIRED_IDS = ['custFirstName','custLastName','custEmail','custPhone','custBillingAddress','custPostcode','custHouseNumber'];
  const LABELS = {
    custFirstName: 'Voornaam',
    custLastName: 'Achternaam',
    custEmail: 'E-mail',
    custPhone: 'Telefoonnummer',
    custBillingAddress: 'Factuuradres',
    custPostcode: 'Postcode',
    custHouseNumber: 'Huisnummer',
    custShippingAddress: 'Bezorgadres'
  };

  function getRequiredPlan(opts){
    opts = opts || {};
    const shipSameChecked = !!opts.shipSameChecked;
    const needShip = !shipSameChecked;
    const requiredIds = BASE_REQUIRED_IDS.slice();
    if(needShip) requiredIds.push('custShippingAddress');
    return {
      baseIds: BASE_REQUIRED_IDS.slice(),
      needShip,
      requiredIds,
      labels: Object.assign({}, LABELS)
    };
  }

  function getInvalidMessage(fieldId){
    const label = LABELS[fieldId] || 'Dit veld';
    return label + ' is verplicht';
  }

  window.ToolACustomerValidation = {
    getRequiredPlan,
    getInvalidMessage
  };
})();
