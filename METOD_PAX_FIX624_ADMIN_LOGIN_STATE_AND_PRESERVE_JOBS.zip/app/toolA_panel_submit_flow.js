(function(){
  function clampCount(v){
    const n = parseInt(v, 10);
    return Math.max(1, Number.isFinite(n) ? n : 1);
  }
  function getMutationPlan(opts){
    opts = opts || {};
    const isEditing = !!(opts.editId || opts.editGroupKey);
    const count = clampCount(opts.qty);
    return {
      isEditing,
      count,
      idPrefix: String(opts.idPrefix || 'panel'),
      timestamp: Number(opts.timestamp || Date.now()),
      editId: isEditing ? String(opts.editId || '') : null
    };
  }
  function getPostSubmitPlan(opts){
    opts = opts || {};
    const isEditing = !!opts.isEditing;
    const count = clampCount(opts.count);
    return {
      clearEditMode: isEditing,
      scheduleDraftSaveCount: isEditing ? 1 : count,
      pulseMessage: isEditing ? 'Paneel bijgewerkt.' : null,
      rerenderCart: true,
      rerenderExtraPanels: true,
      syncExtraChecks: true,
      redrawExtraPreview: true,
      stayOnPanels: true
    };
  }
  function getSubmitPlan(opts){
    const mutation = getMutationPlan(opts);
    return {
      mutation,
      postSubmit: getPostSubmitPlan({ isEditing: mutation.isEditing, count: mutation.count })
    };
  }
  window.ToolAPanelSubmitFlow = { clampCount, getMutationPlan, getPostSubmitPlan, getSubmitPlan };
})();
