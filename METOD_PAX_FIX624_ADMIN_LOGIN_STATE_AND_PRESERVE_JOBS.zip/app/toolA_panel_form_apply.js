(function(){
  function toStr(v, fb){ return String(v == null ? (fb == null ? '' : fb) : v); }
  function toNum(v, fb){ const n = Number(v); return Number.isFinite(n) ? n : Number(fb || 0); }
  function dispatch(el, type){ try{ if(el && type) el.dispatchEvent(new Event(type, { bubbles:true })); }catch(_){ } }

  function applyPrefill(input){
    const state = input && input.state;
    const snapshot = (input && input.snapshot) || {};
    const plan = (input && input.plan) || {};
    const elements = (input && input.elements) || {};
    if(!state || !state.selection) return false;

    state.selection.type = toStr(snapshot.type, '');
    if(elements.typeSel){ elements.typeSel.value = state.selection.type; if(plan.dispatchTypeChange) dispatch(elements.typeSel, 'change'); }

    state.selection.templateId = toStr(snapshot.templateId, '');
    if(elements.sizeSel){ elements.sizeSel.value = state.selection.templateId; if(plan.dispatchSizeChange) dispatch(elements.sizeSel, 'change'); }

    state.selection.qty = Math.max(1, toNum(snapshot.qty, 1) || 1);
    if(elements.qty){ elements.qty.value = String(state.selection.qty); if(plan.dispatchQtyInput) dispatch(elements.qty, 'input'); }

    state.selection.hinge = toStr(snapshot.hinge, 'left') || 'left';
    if(elements.hingeSel){ elements.hingeSel.value = state.selection.hinge; if(plan.dispatchHingeChange) dispatch(elements.hingeSel, 'change'); }

    state.selection.extTop = toNum(snapshot.extTop, 0) || 0;
    state.selection.extBot = toNum(snapshot.extBot, 0) || 0;
    if(elements.extTop){ elements.extTop.value = String(state.selection.extTop); if(plan.dispatchExtTopInput) dispatch(elements.extTop, 'input'); }
    if(elements.extBot){ elements.extBot.value = String(state.selection.extBot); if(plan.dispatchExtBotInput) dispatch(elements.extBot, 'input'); }

    if(elements.customLabelInput){ elements.customLabelInput.value = toStr(snapshot.customLabel, ''); if(plan.dispatchCustomLabelInput) dispatch(elements.customLabelInput, 'input'); }
    return true;
  }

  function applyReset(input){
    const state = input && input.state;
    const snapshot = (input && input.snapshot) || {};
    const elements = (input && input.elements) || {};
    const setPanelEditMode = (input && input.setPanelEditMode) || ((typeof window !== 'undefined' && typeof window.__setPanelEditMode === 'function') ? window.__setPanelEditMode : null);
    const refreshCustomLabelVisibility = input && input.refreshCustomLabelVisibility;
    if(!state || !state.selection) return false;

    if(elements.qty) elements.qty.value = String(Math.max(1, toNum(snapshot.qty, 1) || 1));
    if(elements.extTop) elements.extTop.value = String(toNum(snapshot.extTop, 0) || 0);
    if(elements.extBot) elements.extBot.value = String(toNum(snapshot.extBot, 0) || 0);
    if(elements.hingeSel) elements.hingeSel.value = toStr(snapshot.hinge, 'left') || 'left';
    if(elements.customLabelInput) elements.customLabelInput.value = toStr(snapshot.customLabel, '');
    if(snapshot.clearEdit && typeof setPanelEditMode === 'function'){ try{ setPanelEditMode(null, 0); }catch(_){ } }
    try{ if(snapshot.clearEdit && typeof window !== 'undefined'){ window.__panelEditSnapshot = null; window.__panelEditLiveForm = null; window.__panelEditKnownName = ''; window.__panelEditTouchedFields = { qty:false, hinge:false, extTop:false, extBot:false, customLabel:false }; } }catch(_){ }

    state.selection.qty = Math.max(1, toNum(snapshot.qty, 1) || 1);
    state.selection.extTop = toNum(snapshot.extTop, 0) || 0;
    state.selection.extBot = toNum(snapshot.extBot, 0) || 0;
    state.selection.hinge = toStr(snapshot.hinge, 'left') || 'left';

    dispatch(elements.qty, 'input');
    dispatch(elements.extTop, 'input');
    dispatch(elements.extBot, 'input');
    dispatch(elements.hingeSel, 'change');
    dispatch(elements.customLabelInput, 'input');
    try{ if(typeof refreshCustomLabelVisibility === 'function') refreshCustomLabelVisibility(); }catch(_){ }
    return true;
  }

  window.ToolAPanelFormApply = { applyPrefill, applyReset };
})();
