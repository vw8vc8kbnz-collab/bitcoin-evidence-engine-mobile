/* FIX324: low-risk view/math helper extraction */
(function(){
  function polygonArea(pts){
    var a = 0;
    pts = Array.isArray(pts) ? pts : [];
    for(var i=0;i<pts.length;i++){
      var p = pts[i] || {x:0,y:0};
      var q = pts[(i+1)%pts.length] || {x:0,y:0};
      a += (Number(p.x)||0)*(Number(q.y)||0) - (Number(q.x)||0)*(Number(p.y)||0);
    }
    return a/2;
  }

  function computeBounds(pts){
    pts = Array.isArray(pts) ? pts : [];
    var minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    for(var i=0;i<pts.length;i++){
      var p = pts[i] || {x:0,y:0};
      var x = Number(p.x)||0;
      var y = Number(p.y)||0;
      if(x<minX) minX=x;
      if(y<minY) minY=y;
      if(x>maxX) maxX=x;
      if(y>maxY) maxY=y;
    }
    if(!pts.length){
      minX=minY=maxX=maxY=0;
    }
    return {minX:minX,minY:minY,maxX:maxX,maxY:maxY};
  }

  window.ToolAViewMathHelpers = {
    polygonArea: polygonArea,
    computeBounds: computeBounds
  };
})();
