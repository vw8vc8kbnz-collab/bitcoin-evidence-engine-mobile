(function(){
  const STEP_SET = new Set(['material','panels','grain','customer','overview']);

  function safeStep(step){
    const raw = String(step || '').trim();
    if (STEP_SET.has(raw)) return raw;
    try{
      const current = window.ToolACoreSelectors && typeof window.ToolACoreSelectors.getCurrentStep === 'function'
        ? String(window.ToolACoreSelectors.getCurrentStep() || 'material').trim()
        : 'material';
      return STEP_SET.has(current) ? current : 'material';
    }catch(_){ return 'material'; }
  }

  function getWizardSnapshot(){
    try{
      if (window.ToolACoreSelectors && typeof window.ToolACoreSelectors.getWizardSnapshot === 'function') {
        return window.ToolACoreSelectors.getWizardSnapshot();
      }
    }catch(_){ }
    return {
      material: { hasActiveMaterial: !!(typeof window.hasMaterialSelected === 'function' && window.hasMaterialSelected()) },
      cart: { hasPanels: !!(typeof window.hasPanels === 'function' && window.hasPanels()) },
      customer: { requiredReady: !!(typeof window.validateCustomerStepRequired === 'function' && window.validateCustomerStepRequired()) },
      edit: { isEditing: !!window.__panelEditTargetId }
    };
  }

  function getDecision(step, overrides){
    const targetStep = safeStep(step);
    const snapshot = getWizardSnapshot() || {};
    const materialReady = !!(snapshot.material && snapshot.material.hasActiveMaterial);
    const hasPanels = !!(snapshot.cart && snapshot.cart.hasPanels);
    const customerReady = !!(snapshot.customer && snapshot.customer.requiredReady);
    const isEditing = !!(snapshot.edit && snapshot.edit.isEditing);

    const decision = {
      step: targetStep,
      showPrev: false,
      prevLabel: 'Vorige stap',
      prevDisabled: false,
      showNext: false,
      nextLabel: 'Volgende stap',
      nextDisabled: false,
      showOverview: false,
      overviewLabel: 'Overzicht',
      overviewDisabled: false,
      addInlineDisabled: targetStep !== 'panels',
      addInlineLabel: isEditing ? '✓ Wijzigingen opslaan' : '+ Toevoegen aan lijst',
      addInlineEditing: isEditing,
      guards: {
        materialReady,
        hasPanels,
        customerReady,
        isEditing
      }
    };

    if (targetStep === 'material') {
      decision.showNext = true;
      decision.nextDisabled = !materialReady;
    } else if (targetStep === 'panels') {
      decision.showPrev = true;
      decision.showNext = true;
      decision.nextDisabled = !hasPanels;
      decision.addInlineDisabled = !materialReady;
    } else if (targetStep === 'grain') {
      decision.showPrev = true;
    } else if (targetStep === 'customer') {
      decision.showPrev = true;
      decision.showNext = true;
      decision.nextDisabled = false;
    } else if (targetStep === 'overview') {
      decision.showPrev = true;
      decision.prevLabel = 'Terug';
    }

    if (overrides && typeof overrides === 'object') {
      return Object.assign({}, decision, overrides);
    }
    return decision;
  }

  window.ToolAFooterDecisions = {
    getDecision,
    getDecisionForStep: getDecision
  };
})();
