@echo off
set "PYTHONDONTWRITEBYTECODE=1"
REM === Admin credentials ===
set ADMIN_USER=admin
set ADMIN_PASS=change-me

REM === Start server (use Python launcher if available) ===
start "" http://127.0.0.1:8787/
start "" http://127.0.0.1:8787/admin

REM Prefer py -3 on Windows, fallback to python
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 server_py.py
) else (
  python server_py.py
)

pause
