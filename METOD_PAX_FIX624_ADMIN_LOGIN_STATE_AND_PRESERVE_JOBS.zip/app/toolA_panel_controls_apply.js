(function(){
  'use strict';

  function setDisabled(el, disabled){
    try{ if(el) el.disabled = !!disabled; }catch(_){ }
  }

  function applyElements(elements, disabled){
    (Array.isArray(elements) ? elements : []).forEach(el => setDisabled(el, disabled));
  }

  function normalizeControlsState(input){
    const s = input || {};
    return {
      ready: !!s.ready,
      hasMaterial: !!s.hasMaterial,
      enablePanels: !!s.enablePanels,
      addEnabled: !!s.addEnabled,
      grainEnabled: !!s.grainEnabled,
      grainNextEnabled: !!s.grainNextEnabled,
      extraOverlayEnabled: !!s.extraOverlayEnabled,
      overviewEnabled: !!s.overviewEnabled
    };
  }

  function apply(input){
    const state = normalizeControlsState(input && input.state);
    const refs = (input && input.refs) || {};
    applyElements(refs.panelControls, !state.enablePanels);
    setDisabled(refs.matSearch, !state.ready);
    setDisabled(refs.grainToggle, !state.grainEnabled);
    setDisabled(refs.addBtn, !state.addEnabled);
    setDisabled(refs.grainBtn, !state.grainNextEnabled);
    setDisabled(refs.extraOverlayBtn, !state.extraOverlayEnabled);
    setDisabled(refs.overviewBtn, !state.overviewEnabled);
    return state;
  }

  const api = { setDisabled, applyElements, normalizeControlsState, apply };
  window.ToolAPanelControlsApply = api;
})();
