#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

static constexpr const char* CORE_VERSION = "cpp-core-v1.1-gls-local-search";

struct Order { std::string id, number, customer, delivery_date, tw_start, tw_end; double lat=0, lon=0, service_min=15, weight_kg=0, volume_m3=0; int pallets=0, rolls=0, priority=0; };
struct Vehicle { std::string id, name, status; double max_weight_kg=1e12, max_volume_m3=1e12; int max_pallets=1000000, max_rolls=1000000; };
struct StopPlan { Order order; double eta_min=0; double leg_km=0; std::string warning; };
struct RoutePlan { Vehicle vehicle; std::vector<int> order_idx; std::vector<StopPlan> stops; double distance_km=0,duration_min=0,weight_kg=0,volume_m3=0; int pallets=0,rolls=0,time_window_warnings=0; };

static std::vector<std::string> split(const std::string& s,char d){std::vector<std::string> o;std::string c;std::stringstream ss(s);while(std::getline(ss,c,d))o.push_back(c);while(!s.empty()&&s.back()==d)o.push_back("");return o;}
static double to_double(const std::string& s,double def=0){try{double v=std::stod(s);return std::isfinite(v)?v:def;}catch(...){return def;}}
static int to_int(const std::string& s,int def=0){try{return std::stoi(s);}catch(...){return def;}}
static double haversine_km(double lon1,double lat1,double lon2,double lat2){const double R=6371.0,deg=M_PI/180.0;double p1=lat1*deg,p2=lat2*deg,dp=(lat2-lat1)*deg,dl=(lon2-lon1)*deg;double a=std::sin(dp/2)*std::sin(dp/2)+std::cos(p1)*std::cos(p2)*std::sin(dl/2)*std::sin(dl/2);return R*2.0*std::asin(std::sqrt(std::max(0.0,a)));}
static int parse_time_min(const std::string& s,int def=-1){if(s.size()<4)return def;std::string t=s;std::replace(t.begin(),t.end(),'.',':');auto p=split(t,':');if(p.size()<2)return def;int h=to_int(p[0],-1),m=to_int(p[1],-1);if(h<0||h>23||m<0||m>59)return def;return h*60+m;}
static std::string json_escape(const std::string& s){std::ostringstream o;for(char c:s){switch(c){case '"':o<<"\\\"";break;case '\\':o<<"\\\\";break;case '\b':o<<"\\b";break;case '\f':o<<"\\f";break;case '\n':o<<"\\n";break;case '\r':o<<"\\r";break;case '\t':o<<"\\t";break;default: if((unsigned char)c<0x20)o<<" ";else o<<c;}}return o.str();}

static double node_dist(const std::vector<Order>& orders,int a,int b,double depot_lon,double depot_lat){
    double alon=a<0?depot_lon:orders[a].lon, alat=a<0?depot_lat:orders[a].lat;
    double blon=b<0?depot_lon:orders[b].lon, blat=b<0?depot_lat:orders[b].lat;
    return haversine_km(alon,alat,blon,blat);
}
static double route_distance(const std::vector<int>& r,const std::vector<Order>& orders,double depot_lon,double depot_lat){
    if(r.empty()) return 0; double d=node_dist(orders,-1,r[0],depot_lon,depot_lat); for(size_t i=1;i<r.size();++i)d+=node_dist(orders,r[i-1],r[i],depot_lon,depot_lat); d+=node_dist(orders,r.back(),-1,depot_lon,depot_lat); return d;
}
static bool fits_load(const RoutePlan& r,const Vehicle& v,const Order& o){return r.weight_kg+o.weight_kg<=v.max_weight_kg+1e-9&&r.volume_m3+o.volume_m3<=v.max_volume_m3+1e-9&&r.pallets+o.pallets<=v.max_pallets&&r.rolls+o.rolls<=v.max_rolls;}
static void add_load(RoutePlan& r,const Order& o){r.weight_kg+=o.weight_kg;r.volume_m3+=o.volume_m3;r.pallets+=o.pallets;r.rolls+=o.rolls;}

static double route_time_penalty(const std::vector<int>& r,const std::vector<Order>& orders,double depot_lon,double depot_lat,double speed,double start_min){
    double clock=start_min, lon=depot_lon, lat=depot_lat, penalty=0;
    for(int idx:r){const auto& o=orders[idx]; double leg=haversine_km(lon,lat,o.lon,o.lat); clock += leg/speed*60.0; int tws=parse_time_min(o.tw_start,-1), twe=parse_time_min(o.tw_end,-1); if(tws>=0&&clock<tws) penalty += (tws-clock)*0.10; if(twe>=0&&clock>twe) penalty += (clock-twe)*8.0; clock += std::max(0.0,o.service_min); lon=o.lon; lat=o.lat;} return penalty/60.0; // km-equivalent-ish
}
static double route_objective(const std::vector<int>& r,const std::vector<Order>& orders,double depot_lon,double depot_lat,double speed,double start_min){ return route_distance(r,orders,depot_lon,depot_lat)+route_time_penalty(r,orders,depot_lon,depot_lat,speed,start_min); }

static bool improve_2opt(std::vector<int>& r,const std::vector<Order>& orders,double depot_lon,double depot_lat,double speed,double start_min){
    if(r.size()<4) return false; bool changed=false; double best=route_objective(r,orders,depot_lon,depot_lat,speed,start_min);
    for(size_t i=0;i+1<r.size();++i){ for(size_t k=i+1;k<r.size();++k){ auto cand=r; std::reverse(cand.begin()+i,cand.begin()+k+1); double c=route_objective(cand,orders,depot_lon,depot_lat,speed,start_min); if(c+1e-7<best){r.swap(cand); return true;}}}
    return changed;
}
static bool improve_oropt(std::vector<int>& r,const std::vector<Order>& orders,double depot_lon,double depot_lat,double speed,double start_min){
    if(r.size()<3) return false; double best=route_objective(r,orders,depot_lon,depot_lat,speed,start_min);
    for(size_t i=0;i<r.size();++i){ int node=r[i]; auto base=r; base.erase(base.begin()+i); for(size_t pos=0;pos<=base.size();++pos){ if(pos==i) continue; auto cand=base; cand.insert(cand.begin()+pos,node); double c=route_objective(cand,orders,depot_lon,depot_lat,speed,start_min); if(c+1e-7<best){r.swap(cand); return true;}}}
    return false;
}
static void local_search(std::vector<int>& r,const std::vector<Order>& orders,double depot_lon,double depot_lat,double speed,double start_min){
    int it=0; while(it++<250){ bool ok=false; ok = improve_2opt(r,orders,depot_lon,depot_lat,speed,start_min) || ok; ok = improve_oropt(r,orders,depot_lon,depot_lat,speed,start_min) || ok; if(!ok) break; }
}

static void finalize_route(RoutePlan& route,const std::vector<Order>& orders,double depot_lon,double depot_lat,double speed,double start_min){
    route.stops.clear(); route.distance_km=0; route.duration_min=0; route.time_window_warnings=0; double lon=depot_lon, lat=depot_lat, clock=start_min;
    for(int idx:route.order_idx){const auto& o=orders[idx]; double leg=haversine_km(lon,lat,o.lon,o.lat); route.distance_km+=leg; clock += leg/speed*60.0; std::string warning; int tws=parse_time_min(o.tw_start,-1), twe=parse_time_min(o.tw_end,-1); if(tws>=0&&clock<tws){clock=tws; warning="wacht_tot_tijdvenster";} if(twe>=0&&clock>twe){warning="tijdvenster_risico"; route.time_window_warnings++;} route.stops.push_back({o,clock,leg,warning}); clock += std::max(0.0,o.service_min); lon=o.lon; lat=o.lat;}
    if(!route.order_idx.empty()){double back=haversine_km(lon,lat,depot_lon,depot_lat); route.distance_km+=back; clock += back/speed*60.0;} route.duration_min=clock-start_min;
}

int main(){
    double depot_lon=4.9041,depot_lat=52.3676; std::vector<Vehicle> vehicles; std::vector<Order> orders; std::string line;
    while(std::getline(std::cin,line)){ if(line.empty())continue; auto p=split(line,'\t'); if(p.empty())continue; if(p[0]=="DEPOT"&&p.size()>=3){depot_lon=to_double(p[1],depot_lon);depot_lat=to_double(p[2],depot_lat);} else if(p[0]=="VEH"&&p.size()>=9){Vehicle v; v.id=p[1];v.name=p[2];v.max_weight_kg=to_double(p[3],1e12);v.max_volume_m3=to_double(p[4],1e12);v.max_pallets=to_int(p[5],1000000);v.max_rolls=to_int(p[6],1000000);v.status=p[7];vehicles.push_back(v);} else if(p[0]=="ORD"&&p.size()>=16){Order o; o.id=p[1];o.number=p[2];o.customer=p[3];o.lon=to_double(p[4]);o.lat=to_double(p[5]);o.delivery_date=p[6];o.tw_start=p[7];o.tw_end=p[8];o.service_min=to_double(p[9],15);o.weight_kg=to_double(p[10],0);o.volume_m3=to_double(p[11],0);o.pallets=to_int(p[12],0);o.rolls=to_int(p[13],0);o.priority=to_int(p[14],0);orders.push_back(o);} }
    const double speed=62.0, start_min=8*60.0; std::vector<bool> used(orders.size(),false); std::vector<RoutePlan> routes; std::vector<Order> unplanned;
    // Enterprise-style heuristic: farthest seed + cheapest insertion + 2-opt/or-opt local search.
    for(const auto& v:vehicles){ RoutePlan route; route.vehicle=v; int seed=-1; double far=-1; for(size_t i=0;i<orders.size();++i){ if(used[i])continue; if(!fits_load(route,v,orders[i]))continue; double d=node_dist(orders,-1,(int)i,depot_lon,depot_lat); if(d>far){far=d;seed=(int)i;}} if(seed<0) continue; route.order_idx.push_back(seed); used[seed]=true; add_load(route,orders[seed]);
        while(true){ int best_order=-1; size_t best_pos=0; double best_delta=std::numeric_limits<double>::infinity(); double base=route_objective(route.order_idx,orders,depot_lon,depot_lat,speed,start_min);
            for(size_t i=0;i<orders.size();++i){ if(used[i])continue; if(!fits_load(route,v,orders[i]))continue; for(size_t pos=0;pos<=route.order_idx.size();++pos){ auto cand=route.order_idx; cand.insert(cand.begin()+pos,(int)i); double obj=route_objective(cand,orders,depot_lon,depot_lat,speed,start_min); double priority_bonus=orders[i].priority*0.25; double delta=obj-base-priority_bonus; if(delta<best_delta){best_delta=delta;best_order=(int)i;best_pos=pos;}} }
            if(best_order<0) break; route.order_idx.insert(route.order_idx.begin()+best_pos,best_order); used[best_order]=true; add_load(route,orders[best_order]); local_search(route.order_idx,orders,depot_lon,depot_lat,speed,start_min);
        }
        local_search(route.order_idx,orders,depot_lon,depot_lat,speed,start_min); finalize_route(route,orders,depot_lon,depot_lat,speed,start_min); if(!route.order_idx.empty()) routes.push_back(route);
    }
    for(size_t i=0;i<orders.size();++i) if(!used[i]) unplanned.push_back(orders[i]);
    double total_km=0,total_min=0; int total_stops=0,warnings=0; for(const auto& r:routes){total_km+=r.distance_km;total_min+=r.duration_min;total_stops+=(int)r.stops.size();warnings+=r.time_window_warnings;}
    std::cout<<std::fixed<<std::setprecision(3); std::cout<<"{\"ok\":true,\"core_version\":\""<<CORE_VERSION<<"\",\"algorithm\":\"farthest_seed_cheapest_insertion_2opt_oropt_local_search\",\"routes\":[";
    for(size_t ri=0;ri<routes.size();++ri){const auto& r=routes[ri]; if(ri)std::cout<<","; double wu=r.vehicle.max_weight_kg>0&&r.vehicle.max_weight_kg<1e11?r.weight_kg/r.vehicle.max_weight_kg:0; double vu=r.vehicle.max_volume_m3>0&&r.vehicle.max_volume_m3<1e11?r.volume_m3/r.vehicle.max_volume_m3:0; double pu=r.vehicle.max_pallets>0&&r.vehicle.max_pallets<100000?(double)r.pallets/r.vehicle.max_pallets:0; double ru=r.vehicle.max_rolls>0&&r.vehicle.max_rolls<100000?(double)r.rolls/r.vehicle.max_rolls:0; double load_util=std::max(std::max(wu,vu),std::max(pu,ru)); std::cout<<"{\"vehicle_id\":\""<<json_escape(r.vehicle.id)<<"\",\"vehicle_name\":\""<<json_escape(r.vehicle.name)<<"\","; std::cout<<"\"distance_m\":"<<(long long)std::round(r.distance_km*1000.0)<<",\"duration_s\":"<<(long long)std::round(r.duration_min*60.0)<<","; std::cout<<"\"load\":{\"weight_kg\":"<<r.weight_kg<<",\"volume_m3\":"<<r.volume_m3<<",\"europallets\":"<<r.pallets<<",\"roll_containers\":"<<r.rolls<<",\"utilization\":"<<load_util<<"},"; std::cout<<"\"warnings\":"<<r.time_window_warnings<<",\"stops\":["; for(size_t si=0;si<r.stops.size();++si){const auto& s=r.stops[si]; if(si)std::cout<<","; int eta_h=((int)std::round(s.eta_min))/60, eta_m=((int)std::round(s.eta_min))%60; std::ostringstream eta; eta<<std::setw(2)<<std::setfill('0')<<eta_h<<":"<<std::setw(2)<<eta_m; std::cout<<"{\"order_id\":\""<<json_escape(s.order.id)<<"\",\"order_number\":\""<<json_escape(s.order.number)<<"\",\"customer_name\":\""<<json_escape(s.order.customer)<<"\","; std::cout<<"\"eta\":\""<<eta.str()<<"\",\"leg_distance_m\":"<<(long long)std::round(s.leg_km*1000.0)<<",\"warning\":\""<<json_escape(s.warning)<<"\"}";} std::cout<<"]}";}
    std::cout<<"],\"unplanned\":["; for(size_t i=0;i<unplanned.size();++i){if(i)std::cout<<","; std::cout<<"{\"order_id\":\""<<json_escape(unplanned[i].id)<<"\",\"order_number\":\""<<json_escape(unplanned[i].number)<<"\",\"reason\":\"past_niet_binnen_voertuigcapaciteit_of_routes\"}";} std::cout<<"],\"summary\":{\"routes\":"<<routes.size()<<",\"planned_stops\":"<<total_stops<<",\"unplanned_stops\":"<<unplanned.size()<<",\"total_distance_m\":"<<(long long)std::round(total_km*1000.0)<<",\"total_duration_s\":"<<(long long)std::round(total_min*60.0)<<",\"time_window_warnings\":"<<warnings<<"}}\n";
    return 0;
}
