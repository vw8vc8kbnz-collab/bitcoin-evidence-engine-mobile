# AlgoRoute v1.8.11 Mapping Address Fix

Fixes Mapping Studio responsive layout and validates address as a group: full address OR street+city/postcode OR GPS. Province mapping remains included.
