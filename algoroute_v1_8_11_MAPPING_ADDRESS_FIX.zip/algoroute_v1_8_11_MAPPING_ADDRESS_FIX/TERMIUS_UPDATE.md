cd /home/ubuntu

rm -rf algoroute_latest
rm -f algoroute_v1_8_11_MAPPING_ADDRESS_FIX.zip

wget -O /home/ubuntu/algoroute_v1_8_11_MAPPING_ADDRESS_FIX.zip \
"https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/algoroute_v1_8_11_MAPPING_ADDRESS_FIX.zip"

mkdir -p /home/ubuntu/algoroute_latest
unzip -o /home/ubuntu/algoroute_v1_8_11_MAPPING_ADDRESS_FIX.zip -d /home/ubuntu/algoroute_latest

cd /home/ubuntu/algoroute_latest/algoroute_v1_8_11_MAPPING_ADDRESS_FIX

chmod +x scripts/install.sh scripts/setup_osrm_nl.sh
sudo ./scripts/install.sh

sudo docker compose down --remove-orphans || true
sudo docker rm -f algoroute-api algoroute-web algoroute-nginx 2>/dev/null || true
sudo docker compose up -d --build --force-recreate

curl http://localhost:8787/api/health
curl http://localhost:8787/api/routing/status
curl http://localhost:8787/api/optimizer/status
curl http://localhost:8787/api/import/fields
