# Outrun IQ v8.4.13 — Logo Transparency & AI CTA Polish

- Vervangt de zichtbare logo-lockup door de echte transparante Outrun IQ lockup zonder wit vlak.
- Ververst app-icon assets vanuit de officiële logo-pack.
- Maakt de microtekst op de donkere “AI deal van de dag”-kaart beter leesbaar door witte/lichte tekst te gebruiken.
- Zet de compacte AI Vinder-tegel terug onderaan Home als rustige CTA naar AI Vinder.
- Behoudt v8.4.12 als basis: simpele Home, compactere AI-tekst en categoriehub.
