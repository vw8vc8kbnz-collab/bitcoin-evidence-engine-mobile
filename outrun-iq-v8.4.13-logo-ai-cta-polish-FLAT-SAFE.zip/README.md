# Outrun IQ v8.4.13

Flat safe deployment build. Basis: v8.4.12 Simple AI & Categories Polish.

Belangrijkste correcties:
- echte transparante Outrun IQ lockup zonder witte achtergrond;
- echte app-icon assets uit logo-pack;
- beter leesbare microcopy op donkere AI deal-kaarten;
- compacte AI Vinder CTA terug op Home.
