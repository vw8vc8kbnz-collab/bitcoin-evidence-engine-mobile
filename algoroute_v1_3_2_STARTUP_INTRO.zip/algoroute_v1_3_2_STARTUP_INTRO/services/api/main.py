import os, json, math
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

APP_VERSION = "1.3.0"
STORE_DIR = Path(os.getenv("ALGOROUTE_STORE", "/app/store"))
STORE_DIR.mkdir(parents=True, exist_ok=True)
OSRM_URL = os.getenv("OSRM_URL", "http://host.docker.internal:5000").rstrip("/")

app = FastAPI(title="AlgoRoute API", version=APP_VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def load_json(name, default):
    path = STORE_DIR / name
    if not path.exists():
        path.write_text(json.dumps(default, indent=2), encoding="utf-8")
    return json.loads(path.read_text(encoding="utf-8"))

def save_json(name, data):
    (STORE_DIR / name).write_text(json.dumps(data, indent=2), encoding="utf-8")

@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": APP_VERSION, "time": datetime.now(timezone.utc).isoformat()}

async def osrm_probe():
    try:
        async with httpx.AsyncClient(timeout=2.5) as client:
            r = await client.get(f"{OSRM_URL}/route/v1/driving/5.2913,52.1326;5.2920,52.1330", params={"overview":"false"})
            return r.status_code == 200, None if r.status_code == 200 else f"OSRM HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)

@app.get("/api/routing/status")
async def routing_status():
    ok, err = await osrm_probe()
    return {"available": ok, "url": OSRM_URL, "message": "OSRM Nederland is actief" if ok else f"OSRM nog niet actief: {err}. Run scripts/setup_osrm_nl.sh op de VPS."}

class RouteRequest(BaseModel):
    coordinates: List[List[float]]

@app.post("/api/routing/route")
async def routing_route(req: RouteRequest):
    if len(req.coordinates) < 2:
        raise HTTPException(400, "Minimaal twee coördinaten nodig")
    coord_str = ";".join([f"{c[0]},{c[1]}" for c in req.coordinates])
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(f"{OSRM_URL}/route/v1/driving/{coord_str}", params={"overview":"full","geometries":"geojson","steps":"false"})
            if r.status_code != 200:
                raise HTTPException(503, f"OSRM route error {r.status_code}: {r.text[:180]}")
            data = r.json()
            route = data["routes"][0]
            return {"ok": True, "distance_m": route["distance"], "duration_s": route["duration"], "geometry": route["geometry"]}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(503, f"OSRM niet bereikbaar: {e}")

class MatrixRequest(BaseModel):
    coordinates: List[List[float]]

@app.post("/api/routing/matrix")
async def routing_matrix(req: MatrixRequest):
    if len(req.coordinates) < 2:
        raise HTTPException(400, "Minimaal twee coördinaten nodig")
    coord_str = ";".join([f"{c[0]},{c[1]}" for c in req.coordinates])
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.get(f"{OSRM_URL}/table/v1/driving/{coord_str}", params={"annotations":"duration,distance"})
            if r.status_code != 200:
                raise HTTPException(503, f"OSRM matrix error {r.status_code}: {r.text[:180]}")
            data = r.json()
            return {"ok": True, "durations": data.get("durations"), "distances": data.get("distances")}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(503, f"OSRM niet bereikbaar: {e}")

@app.get("/api/map/state")
def map_state():
    return {
        "center": [5.2913, 52.1326], "zoom": 6.7,
        "vehicles": load_json("vehicles.json", []),
        "routes": load_json("routes.json", []),
        "events": load_json("events.json", []),
        "traffic_segments": load_json("traffic_segments.json", []),
        "message": "Geen dummydata. Kaart vult zodra routes/voertuigen bestaan."
    }

@app.get("/api/vehicles")
def vehicles(): return load_json("vehicles.json", [])

@app.get("/api/routes")
def routes(): return load_json("routes.json", [])

@app.get("/api/planning/queue")
def planning_queue():
    orders = load_json("orders.json", [])
    return {"version": APP_VERSION, "orders": orders, "summary": {"count": len(orders), "ready": len([o for o in orders if o.get("status") == "ready"])}}

@app.post("/api/planning/optimize")
async def optimize(payload: dict):
    orders = load_json("orders.json", [])
    vehicles = load_json("vehicles.json", [])
    routable = [o for o in orders if o.get("longitude") and o.get("latitude")]
    if not orders:
        return {"ok": False, "reason": "Planning Queue is leeg. Importeer orders of koppel ERP."}
    if not vehicles:
        return {"ok": False, "reason": "Geen voertuigen beschikbaar. Voeg voertuigen toe in Wagenpark."}
    if len(routable) < 2:
        return {"ok": False, "reason": "Te weinig geocodeerde orders. PDOK/BAG geocoding komt in volgende stap."}
    return {"ok": False, "reason": "Optimizer V1 is voorbereid. OSRM matrix is beschikbaar via /api/routing/matrix; C++ optimizer volgt als volgende build."}

FIELD_CATEGORIES = ["Order","Klant","Adres","Tijdvenster","Producten","Gewicht & Volume","Pallets & Rolcontainers","Planning","Service","Instructies","Tracking","Finance","Custom"]
@app.get("/api/import/fields")
def import_fields():
    return {"version": APP_VERSION, "categories": FIELD_CATEGORIES, "message": "Volledige veldcatalogus en Smart Mapping Engine frontend actief."}

@app.post("/api/import/commit")
def import_commit(payload: dict):
    # placeholder persistence contract: validated normalized orders will be committed here later
    orders = payload.get("orders") or []
    if orders:
        existing = load_json("orders.json", [])
        existing.extend(orders)
        save_json("orders.json", existing)
    return {"ok": True, "orders_created": len(orders), "status": "committed_to_planning_queue"}

@app.get("/api/integrations/catalog")
def integrations_catalog():
    return {"connectors": [
        {"id":"csv_excel", "name":"CSV / Excel", "status":"active_foundation"},
        {"id":"custom_api", "name":"Custom API / Webhooks", "status":"foundation"},
        {"id":"odoo", "name":"Odoo", "status":"planned"},
        {"id":"exact", "name":"Exact Online", "status":"planned"},
        {"id":"afas", "name":"AFAS", "status":"planned"},
        {"id":"woocommerce", "name":"WooCommerce", "status":"planned"}
    ]}
