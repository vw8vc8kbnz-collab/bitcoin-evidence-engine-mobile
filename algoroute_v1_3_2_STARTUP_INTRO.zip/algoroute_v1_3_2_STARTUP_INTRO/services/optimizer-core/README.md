# AlgoRoute Optimizer Core

v1.3 reserves the native optimizer layer. Next build connects OSRM matrix output to C++ clustering, vehicle assignment and constraint scoring.
