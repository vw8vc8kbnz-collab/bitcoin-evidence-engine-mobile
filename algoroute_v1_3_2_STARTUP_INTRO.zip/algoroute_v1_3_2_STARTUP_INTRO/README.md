# AlgoRoute v1.3.2 STARTUP INTRO

## Nieuw
- Claude intro-video geïntegreerd als echte startup overlay.
- Intro speelt bij elke app-start/page-load af.
- Daarna fade/blur overgang naar de software.
- Skip-knop en automatische fallback toegevoegd voor browsers waar autoplay hapert.
- OSRM foundation en officiële groene logo-assets blijven behouden.

## Testen
- Open `/` en controleer of de intro start.
- Wacht tot de intro klaar is of klik `Overslaan`.
- Check of `/api/health` werkt.
