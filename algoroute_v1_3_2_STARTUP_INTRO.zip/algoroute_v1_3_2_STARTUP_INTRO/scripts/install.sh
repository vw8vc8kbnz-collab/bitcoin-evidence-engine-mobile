#!/usr/bin/env bash
set -e
mkdir -p data/store data/osrm
for f in vehicles routes events traffic_segments orders; do
  [ -f "data/store/$f.json" ] || echo "[]" > "data/store/$f.json"
done
echo "AlgoRoute install prepared. No dummydata inserted."
