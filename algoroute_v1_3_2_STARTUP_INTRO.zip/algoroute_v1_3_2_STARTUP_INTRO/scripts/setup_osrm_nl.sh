#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p data/osrm
cd data/osrm
PBF="netherlands-latest.osm.pbf"
if [ ! -f "$PBF" ]; then
  echo "Downloading Netherlands OSM extract..."
  wget -O "$PBF" "https://download.geofabrik.de/europe/netherlands-latest.osm.pbf"
fi
if [ ! -f "netherlands-latest.osrm" ]; then
  echo "Preparing OSRM data. This can take a while..."
  sudo docker run --rm -t -v "$(pwd):/data" osrm/osrm-backend osrm-extract -p /opt/car.lua /data/$PBF
  sudo docker run --rm -t -v "$(pwd):/data" osrm/osrm-backend osrm-partition /data/netherlands-latest.osrm
  sudo docker run --rm -t -v "$(pwd):/data" osrm/osrm-backend osrm-customize /data/netherlands-latest.osrm
fi
sudo docker rm -f algoroute-osrm 2>/dev/null || true
sudo docker run -d --name algoroute-osrm --restart unless-stopped -p 5000:5000 -v "$(pwd):/data" osrm/osrm-backend osrm-routed --algorithm mld /data/netherlands-latest.osrm
echo "OSRM should be live at http://localhost:5000"
