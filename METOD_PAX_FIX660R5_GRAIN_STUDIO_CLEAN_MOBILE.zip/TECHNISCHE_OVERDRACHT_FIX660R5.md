# Technische overdracht — FIX660R5 Clean Mobile Grain Studio

## Golden input
FIX660R4 / `FIX660_GRAIN_STUDIO`, exact geverifieerd via hashes van toolA.html, server_py.py, Grain Studio renderer/CSS/mobile controller/math.

## Autoritatieve stacksemantiek
`state.grain.groups[].items` is BOTTOM -> TOP.
- index 0 = positie 1 = onderste fysieke paneel.
- append = nieuw paneel bovenop de stapel.
- `grainOrder = index + 1` blijft productie-waarheid.
- DOM/canvas zijn TOP -> BOTTOM en gebruiken daarom uitsluitend een presentation reverse.
- Reorder schrijft de omgekeerde DOM-volgorde terug naar `g.items`.

## Mobile drawer
Breakpoint: <= 900px, gelijk aan de mobiele nerflayout.
Collapsed state: `translateY(calc(100% - 14px))`; inhoud is visibility:hidden/pointer-events:none, alleen handle blijft bedienbaar.
Overlay-open forceert closed state. Open state rendert de preview opnieuw.

## Preview selection
De renderer gebruikt `selectedGroupId` indien geldig. Is die leeg/stale, dan wordt eerst een gevulde groep van het actieve materiaal gekozen, daarna de eerste beschikbare groep. De keuze wordt teruggeschreven naar `selectedGroupId`.

## Cache-contract
`toolA_grain_studio_math.js?v=660r5`
`toolA_grain_studio_renderer.js?v=660r5`
`toolA_grain_mobile_scale.js?v=660r5`
`toolA_grain_studio.css?v=660r5`

## Onaangeroerd
Geen wijzigingen aan pricing_helpers.py, catalog_importer.py, catalog_taxonomy.py, dxf_nesting_optimizer.py, material swatch renderer, submit/idempotency/security contract of VPS URL/poort.
