#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="FIX660R5"
STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${METOD_PAX_APP_DIR:-/opt/adzaagt/metod-pax}"
PUBLIC_ORIGIN="${PUBLIC_ORIGIN:-http://51.195.102.180:8790}"
ADMIN_ORIGIN="${ADMIN_ORIGIN:-${PUBLIC_ORIGIN}}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-/etc/adzaagt/metod-pax/admin_credentials.live.json}"
TS="$(date +%Y%m%d_%H%M%S)"
LOG="/tmp/METOD_PAX_FIX660R5_DEPLOY_${TS}.log"
APP_BACKUP="${APP_DIR}_backup_before_FIX660R5_${TS}"
CONFIG_TAR="/var/backups/metod-pax/FIX660R5_outer_config_${TS}.tar"
HAD_APP=0
LIVE_TOUCHED=0
SUCCESS=0

info(){ echo "[$VERSION] $*"; }
fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }

rollback(){
  local rc=$?
  if [[ "$SUCCESS" -eq 1 ]]; then
    info "Deploy succesvol. Log: $LOG"
    return 0
  fi
  echo "[$VERSION] INSTALLATIE MISLUKT (code $rc). Log: $LOG" >&2
  echo "[$VERSION] Staging blijft voor diagnose: $STAGE" >&2
  if [[ "$LIVE_TOUCHED" -eq 1 ]]; then
    echo "[$VERSION] Automatische app/config-rollback wordt uitgevoerd..." >&2
    set +e
    if [[ "$HAD_APP" -eq 1 && -d "$APP_BACKUP" ]]; then
      sudo rm -rf "$APP_DIR"
      sudo cp -a "$APP_BACKUP" "$APP_DIR"
    elif [[ "$HAD_APP" -eq 0 ]]; then
      sudo rm -rf "$APP_DIR"
    fi
    if [[ -f "$CONFIG_TAR" ]]; then
      sudo rm -rf /etc/adzaagt/metod-pax
      sudo rm -f /etc/systemd/system/metod-pax.service
      sudo rm -f /etc/systemd/system/metod-pax-certbot-renew.service /etc/systemd/system/metod-pax-certbot-renew.timer
      sudo rm -f /etc/systemd/system/timers.target.wants/metod-pax-certbot-renew.timer
      sudo rm -f /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790
      sudo rm -f /etc/nginx/sites-available/metod-pax-https /etc/nginx/sites-enabled/metod-pax-https
      sudo rm -f /etc/nginx/sites-available/metod-pax-acme-ip /etc/nginx/sites-enabled/metod-pax-acme-ip
      sudo tar -xpf "$CONFIG_TAR" -C /
    fi
    sudo systemctl daemon-reload || true
    if sudo nginx -t; then sudo systemctl reload nginx || true; fi
    if [[ -f /etc/systemd/system/metod-pax.service ]]; then sudo systemctl restart metod-pax.service || true; fi
    if [[ -e /etc/systemd/system/timers.target.wants/metod-pax-certbot-renew.timer ]]; then sudo systemctl start metod-pax-certbot-renew.timer || true; fi
    echo "[$VERSION] Rollbackpoging afgerond." >&2
    set -e
  fi
  return "$rc"
}
trap rollback EXIT
exec > >(tee -a "$LOG") 2>&1

[[ "$PUBLIC_ORIGIN" == 'http://51.195.102.180:8790' ]] || fail "PUBLIC_ORIGIN moet voor deze compatibility release exact http://51.195.102.180:8790 zijn"
[[ "$ADMIN_ORIGIN" == "$PUBLIC_ORIGIN" ]] || fail "ADMIN_ORIGIN moet gelijk zijn aan PUBLIC_ORIGIN"
[[ -f "$CREDS_FILE" ]] || fail "Bestaande externe Admin credentials ontbreken: $CREDS_FILE"
for cmd in rsync python3 sha256sum grep tar curl nginx systemctl; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
sudo -v
sudo test -r "$CREDS_FILE" || fail "Admin credentials zijn niet root-leesbaar: $CREDS_FILE"

# Prove the existing golden service is healthy before touching anything.
if [[ -d "$APP_DIR/app" ]]; then
  sudo systemctl is-active --quiet metod-pax.service || fail "Bestaande metod-pax.service is vóór deploy niet actief"
  curl -fsS http://127.0.0.1:8790/ -o /dev/null || fail "Bestaande Tool A op :8790 geeft vóór deploy geen HTTP succes"
  curl -fsS http://127.0.0.1:8792/api/materials/library -o /dev/null || fail "Bestaande backend :8792 is vóór deploy niet gezond"
  LIVE_MARKER="$(grep -m1 "__PERFORMANCE_BUILD" "$APP_DIR/app/server_py.py" 2>/dev/null || true)"
  case "$LIVE_MARKER" in
    *"FIX660_GRAIN_STUDIO"*)
      # The current user baseline is FIX660R4. The family marker is intentionally stable,
      # so require the immutable R4 source fingerprint before any state is touched.
      R4_OK=1
      [[ "$(sha256sum "$APP_DIR/app/toolA.html" | awk '{print $1}')" == "cb1e46faaa2e272cd45a479a653c5947effee783c84bd04bdaffaa914fea8f3f" ]] || R4_OK=0
      [[ "$(sha256sum "$APP_DIR/app/server_py.py" | awk '{print $1}')" == "058b4692aa251ff1c4a92489d639da60027e28bd120a2ab362eec8c3a63f122f" ]] || R4_OK=0
      [[ "$(sha256sum "$APP_DIR/app/toolA_grain_studio_renderer.js" | awk '{print $1}')" == "4d14dd7fed7b186d3341d28dd6b4040a8bf270cadf63b0448c45d26e4987de08" ]] || R4_OK=0
      [[ "$(sha256sum "$APP_DIR/app/toolA_grain_studio.css" | awk '{print $1}')" == "fad08f4f33e9e4e1fa0387bf3531b8464e8a5a52649d0b116b6158eaabe7c29d" ]] || R4_OK=0
      [[ "$(sha256sum "$APP_DIR/app/toolA_grain_mobile_scale.js" | awk '{print $1}')" == "f55cf5561dec34d5a5433eb5057575101bcad48634396983b70aab673c07dee8" ]] || R4_OK=0
      [[ "$(sha256sum "$APP_DIR/app/toolA_grain_studio_math.js" | awk '{print $1}')" == "db9c993cdebe87ad240b5f9abad770c4c8ab9afe825b11c35a1fbdbb103bcc68" ]] || R4_OK=0
      if [[ "$R4_OK" -eq 1 ]]; then
        info "Exacte FIX660R4 live baseline bevestigd; clean mobile Grain Studio upgrade toegestaan."
      else
        # Idempotent rerun is allowed only if the immutable target UI already matches stage.
        TARGET_OK=1
        for f in toolA.html server_py.py toolA_grain_studio_renderer.js toolA_grain_studio.css toolA_grain_mobile_scale.js toolA_grain_studio_math.js; do
          [[ -f "$APP_DIR/app/$f" && "$(sha256sum "$APP_DIR/app/$f" | awk '{print $1}')" == "$(sha256sum "$STAGE/app/$f" | awk '{print $1}')" ]] || TARGET_OK=0
        done
        [[ "$TARGET_OK" -eq 1 ]] || fail "Live FIX660 family marker gevonden, maar bronhashes zijn niet exact FIX660R4 en ook niet de staged FIX660R5-doelbuild; deploy stopt fail-closed"
        info "Exacte FIX660R5-doelbuild staat al live; veilige idempotente refresh toegestaan."
      fi
      ;;
    *)
      fail "FIX660R5 accepteert uitsluitend de exacte FIX660R4 live baseline of een reeds aanwezige exacte FIX660R5-doelbuild; live marker: ${LIVE_MARKER:-onbekend}"
      ;;
  esac
fi

# Extracted release integrity and clean-tree contracts.
(cd "$STAGE" && sha256sum -c SHA256SUMS.txt >/dev/null)
python3 - "$STAGE" <<'PY'
from pathlib import Path
import json,sys
root=Path(sys.argv[1])
bad=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and ('__pycache__' in p.parts or p.suffix.lower() in {'.pyc','.bak','.csv'})]
if bad: raise SystemExit(f'Onschone staged release: {bad[:20]}')
lib=json.loads((root/'app/material_library.json').read_text(encoding='utf-8'))
assert lib.get('source')=='CSV_CATALOG_ONLY' and lib.get('records')==[]
assert lib.get('pricingModel')=='catalog_sell_price_incl_vat_v2'
print('Release integrity/CSV-only seed/pricing-v2: OK')
PY

# All application regressions run before live files are touched.
python3 -m py_compile "$STAGE"/app/*.py "$STAGE"/tools/*.py
bash -n "$STAGE/DEPLOY_FIX660.sh"
bash -n "$STAGE/INSTALL_FIX660R5_FROM_STAGE.sh"
if command -v node >/dev/null; then for f in "$STAGE"/app/*.js; do node --check "$f" >/dev/null; done; fi
python3 "$STAGE/tools/fix660_regression.py"

PREFLIGHT_ENV="$STAGE/.production-preflight.env"
cat > "$PREFLIGHT_ENV" <<EOF2
APP_ENV=production
PRODUCTION_HARDENING=1
ADMIN_HASH_ONLY=1
ADMIN_STAGING_OPEN=0
ADMIN_CREDENTIALS_FILE=$CREDS_FILE
LEGACY_HTTP_COMPAT=1
LEGACY_HTTP_ORIGIN=$PUBLIC_ORIGIN
TRUSTED_PROXY_IPS=127.0.0.1,::1
ALLOWED_ORIGINS=$PUBLIC_ORIGIN
ALLOWED_ADMIN_ORIGINS=$ADMIN_ORIGIN
PUBLIC_JSON_MAX_BYTES=16777216
SUBMIT_MAX_BYTES=8388608
PUBLIC_DXF_BLOB_MAX_BYTES=2097152
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
EOF2
sudo env APP_DIR="$STAGE" METOD_ENV_FILE="$PREFLIGHT_ENV" python3 "$STAGE/tools/final_preflight.py"
rm -f "$PREFLIGHT_ENV"
# Validation imports/py_compile may create bytecode in staging. Never copy test artifacts live.
find "$STAGE" -type d -name '__pycache__' -prune -exec rm -rf {} +
find "$STAGE" -type f -name '*.pyc' -delete
info "FIX660 preflight groen. Nu pas live backup/switch."

if [[ -d "$APP_DIR/app" ]]; then
  HAD_APP=1
  sudo cp -a "$APP_DIR" "$APP_BACKUP"
  info "Volledige appbackup: $APP_BACKUP"
fi
sudo mkdir -p "$(dirname "$CONFIG_TAR")"
TAR_INPUTS=()
for f in /etc/adzaagt/metod-pax /etc/systemd/system/metod-pax.service \
         /etc/systemd/system/metod-pax-certbot-renew.service /etc/systemd/system/metod-pax-certbot-renew.timer \
         /etc/systemd/system/timers.target.wants/metod-pax-certbot-renew.timer \
         /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790 \
         /etc/nginx/sites-available/metod-pax-https /etc/nginx/sites-enabled/metod-pax-https \
         /etc/nginx/sites-available/metod-pax-acme-ip /etc/nginx/sites-enabled/metod-pax-acme-ip; do
  [[ -e "$f" || -L "$f" ]] && TAR_INPUTS+=("${f#/}")
done
if ((${#TAR_INPUTS[@]})); then
  sudo tar -cpf "$CONFIG_TAR" -C / "${TAR_INPUTS[@]}"
else
  sudo tar -cpf "$CONFIG_TAR" --files-from /dev/null
fi
info "Externe configbackup: $CONFIG_TAR"
LIVE_TOUCHED=1

sudo mkdir -p "$APP_DIR/app/jobs" "$APP_DIR/app/requests" "$APP_DIR/app/queue" "$APP_DIR/app/archive" \
  "$APP_DIR/app/backups" "$APP_DIR/app/drafts" "$APP_DIR/app/system" "$APP_DIR/app/decor_media" "$APP_DIR/app/config"

# Existing live state always wins; release seeds are only for a truly fresh install.
if [[ ! -f "$APP_DIR/app/material_library.json" ]]; then sudo install -m 0640 "$STAGE/app/material_library.json" "$APP_DIR/app/material_library.json"; fi
if [[ ! -f "$APP_DIR/app/config/pricing_active.json" ]]; then sudo install -m 0640 "$STAGE/app/config/pricing_active.json" "$APP_DIR/app/config/pricing_active.json"; fi
if [[ ! -d "$APP_DIR/app/embedded_dxfs" && -d "$STAGE/app/embedded_dxfs" ]]; then sudo cp -a "$STAGE/app/embedded_dxfs" "$APP_DIR/app/embedded_dxfs"; fi
if [[ ! -f "$APP_DIR/app/embedded_dxfs_manifest.json" && -f "$STAGE/app/embedded_dxfs_manifest.json" ]]; then sudo cp -a "$STAGE/app/embedded_dxfs_manifest.json" "$APP_DIR/app/embedded_dxfs_manifest.json"; fi

sudo rsync -a --delete "$STAGE/" "$APP_DIR/" \
  --exclude 'app/jobs/' \
  --exclude 'app/requests/' \
  --exclude 'app/queue/' \
  --exclude 'app/archive/' \
  --exclude 'app/backups/' \
  --exclude 'app/drafts/' \
  --exclude 'app/system/' \
  --exclude 'app/decor_media/' \
  --exclude 'app/material_library.json' \
  --exclude 'app/config/pricing_active.json' \
  --exclude 'app/config/pricing_versions/' \
  --exclude 'app/config/pricing_audit.jsonl' \
  --exclude 'app/embedded_dxfs/' \
  --exclude 'app/embedded_dxfs_manifest.json' \
  --exclude '.production-preflight.env'

sudo chmod +x "$APP_DIR/DEPLOY_FIX660.sh" "$APP_DIR/INSTALL_FIX660R5_FROM_STAGE.sh" "$APP_DIR"/tools/*.py
sudo env \
  PUBLIC_ORIGIN="$PUBLIC_ORIGIN" \
  ADMIN_ORIGIN="$ADMIN_ORIGIN" \
  ADMIN_CREDENTIALS_FILE="$CREDS_FILE" \
  METOD_PAX_APP_DIR="$APP_DIR" \
  bash "$APP_DIR/DEPLOY_FIX660.sh"

# Final smoke: same URL and same port, new build marker.
# IMPORTANT: never pipe curl into `grep -q` while `pipefail` is active. `grep -q`
# may exit as soon as it finds the marker, which closes the pipe while curl is
# still writing and makes curl return 23 (CURLE_WRITE_ERROR). Download fully
# first, then inspect the completed response.
SMOKE_BACKEND="$(mktemp /tmp/metod_fix660_backend_smoke_XXXXXX.html)"
SMOKE_PROXY="$(mktemp /tmp/metod_fix660_proxy_smoke_XXXXXX.html)"
curl -fsS "http://127.0.0.1:8792/toolA.html?v=660r5" -o "$SMOKE_BACKEND"
grep -Fq 'FIX660_GRAIN_STUDIO' "$SMOKE_BACKEND"
grep -Fq 'FIX660R5_CLEAN_MOBILE_GRAIN' "$SMOKE_BACKEND"
curl -fsS -H 'Host: 51.195.102.180:8790' "http://127.0.0.1:8790/toolA.html?v=660r5" -o "$SMOKE_PROXY"
grep -Fq 'FIX660_GRAIN_STUDIO' "$SMOKE_PROXY"
grep -Fq 'FIX660R5_CLEAN_MOBILE_GRAIN' "$SMOKE_PROXY"
rm -f "$SMOKE_BACKEND" "$SMOKE_PROXY"
sudo systemctl is-active --quiet metod-pax.service
sudo nginx -t

SUCCESS=1
info "FIX660 ACTIEF en alle checks groen. (FIX660R5 installer; compact closed drawer + reliable preview + bottom-up stack)"
info "Tool A ONGEWIJZIGD: http://51.195.102.180:8790/"
info "Admin ONGEWIJZIGD:  http://51.195.102.180:8790/admin/"
info "Appbackup: $APP_BACKUP"
info "Configbackup: $CONFIG_TAR"
