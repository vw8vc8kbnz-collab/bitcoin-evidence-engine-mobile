(function(root){
  'use strict';
  if(root.__FIX660R5_GRAIN_MOBILE__) return;
  root.__FIX660R5_GRAIN_MOBILE__='FIX660R5_CLEAN_MOBILE_GRAIN';
  root.__TOOLA_GRAIN_PREVIEW_BUILD='FIX660R5_CLEAN_MOBILE_GRAIN';

  const MQ='(max-width:900px)';
  const q=(id)=>document.getElementById(id);
  const isMobile=()=>!!(root.matchMedia&&root.matchMedia(MQ).matches);
  const esc=(v)=>typeof root._esc==='function'?root._esc(v):String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
  const roundMm=(v)=>Math.round(Number(v||0)*1000)/1000;
  const fmt=(v)=>{const x=Number(v||0);return Math.abs(x-Math.round(x))<.01?String(Math.round(x)):x.toFixed(1).replace('.',',');};
  const sameWidth=(a,b)=>{try{return root.ToolAGrainStudioMath?root.ToolAGrainStudioMath.sameWidthMm(a,b):Math.abs(Number(a)-Number(b))<=.001;}catch(_){return Math.abs(Number(a)-Number(b))<=.001;}};
  const entry=(ref)=>{try{return typeof root.getGrainEntryByRef==='function'?root.getGrainEntryByRef(ref):null;}catch(_){return null;}};
  const widthMm=(e)=>roundMm(e&&e.widthMm);
  const heightMm=(e)=>Math.max(1,Number(e&&e.baseHeightMm||0)+Math.max(0,Number(e&&e.extTop||0))+Math.max(0,Number(e&&e.extBot||0)));
  const materialKey=()=>{try{return root.grainOverlaySelectedMaterialKey();}catch(_){return '';}};

  function ensureSelectedGroup(preferWithItems=true){
    try{
      root.ensureStateShape();
      const grain=root.state&&root.state.grain;if(!grain)return null;
      const mk=String(materialKey()||'');
      let list=(grain.groups||[]).filter(g=>!mk||String(g&&g.materialKey||'')===mk);
      if(!list.length)return null;
      let g=list.find(x=>String(x&&x.id||'')===String(grain.selectedGroupId||''))||null;
      if(!g&&preferWithItems)g=list.find(x=>(x&&x.items||[]).length)||null;
      if(!g)g=list[0]||null;
      if(g)grain.selectedGroupId=g.id;
      return g;
    }catch(_){return null;}
  }

  function groupWidth(g){
    let w=roundMm(g&&g.widthMm);
    if(!w&&g&&(g.items||[]).length){const e=entry(g.items[0]);w=widthMm(e);if(w){g.widthMm=w;g.widthCm=w/10;}}
    return w;
  }
  function groupHeight(g){return (g&&g.items||[]).reduce((sum,ref)=>{const e=entry(ref);return sum+(e?heightMm(e):0);},0);}
  function groupSummary(g){const w=groupWidth(g),h=groupHeight(g),count=(g&&g.items||[]).length;return `${w?fmt(w)+' mm':'—'} · ${count} ${count===1?'paneel':'panelen'}${h?' · '+fmt(h)+' mm hoog':''}`;}

  function openWidthStore(){const key=String(materialKey()||'default');root.__fix660OpenWidths=root.__fix660OpenWidths||{};root.__fix660OpenWidths[key]=root.__fix660OpenWidths[key]||{};return root.__fix660OpenWidths[key];}

  function refreshAll(){
    try{root.syncGroupOrders();}catch(_){}
    try{root.rebuildGrainWidthOptions();}catch(_){}
    try{root.rebuildGrainEligible();}catch(_){}
    try{root.rebuildGrainGroups();}catch(_){}
    try{root.renderCart();}catch(_){}
    try{root.syncPanelDockChrome();}catch(_){}
    try{root.renderExtraPanels();}catch(_){}
    try{root.syncChecksFromSelect();}catch(_){}
    try{root.drawExtraPreview();}catch(_){}
    try{root.drawGrainPreview();}catch(_){}
    try{root.setGrainMsg('');}catch(_){}
  }

  function targetGroup(){
    let g=ensureSelectedGroup(false);
    if(g)return g;
    try{root.newGroup();return ensureSelectedGroup(false);}catch(_){return null;}
  }

  function addMany(refs,requested){
    try{
      const g=targetGroup();if(!g)return;
      const entries=(refs||[]).map(entry).filter(Boolean).filter(e=>!e.grainGroupId);
      if(!entries.length)return;
      const count=requested==='all'?entries.length:Math.max(1,Math.min(entries.length,Number(requested)||1));
      let added=0,gw=groupWidth(g);
      for(let i=0;i<entries.length&&added<count;i++){
        const e=entries[i],w=widthMm(e);if(!root.isGrainCapable(e.raw))continue;
        if(gw&&!sameWidth(gw,w)){try{root.setGrainMsg('Dit paneel heeft niet exact dezelfde werkelijke breedte als de actieve nerf-set.');}catch(_){}break;}
        if(!gw){gw=w;g.widthMm=w;g.widthCm=w/10;}
        const ref=String(e.ref||'');if(!ref||g.items.map(String).includes(ref))continue;
        // Authoritative order is BOTTOM -> TOP. Appending therefore stacks the new panel above the previous one.
        g.items.push(ref);added++;
      }
      if(added){root.state.grain.selectedGroupId=g.id;root.syncGroupOrders();refreshAll();}
    }catch(_){}
  }

  const baseEligible=root.rebuildGrainEligible;
  const baseGroups=root.rebuildGrainGroups;
  const basePreview=root.drawGrainPreview;

  function renderMobileEligible(){
    const host=q('grainEligible'),countEl=q('grainEligibleCount'),toggle=q('grainIncludeExtraToggle'),widthSel=q('grainWidthSel');
    if(!host||!countEl)return;
    host.innerHTML='';const eligible=root.getGrainEligibleEntries();countEl.textContent=String(eligible.length);if(toggle)toggle.checked=!!root.grainExtrasEnabled();
    if(!eligible.length){const d=document.createElement('div');d.className='help';d.textContent='Geen panelen beschikbaar voor doorlopende nerf.';host.appendChild(d);return;}
    const byWidth=new Map();eligible.forEach(e=>{const w=widthMm(e);if(!byWidth.has(w))byWidth.set(w,[]);byWidth.get(w).push(e);});
    let widths=Array.from(byWidth.keys()).sort((a,b)=>a-b);const filter=widthSel?widthSel.value:'all';if(filter&&filter!=='all')widths=widths.filter(w=>sameWidth(w,Number(filter)));
    const store=openWidthStore();if(widths.length&&!widths.some(w=>store[String(w)]))store[String(widths[0])]=true;
    widths.forEach(w=>{
      const entries=byWidth.get(w)||[],available=entries.filter(e=>!e.grainGroupId).length;
      const section=document.createElement('section');section.className='fix649WidthAccordion'+(store[String(w)]?' is-open':'');
      const head=document.createElement('button');head.type='button';head.className='fix649WidthHeader';head.setAttribute('aria-expanded',store[String(w)]?'true':'false');head.innerHTML=`<strong>${esc(fmt(w))} mm</strong><span class="fix649WidthCount">${available}/${entries.length}</span><span class="fix649Chevron">⌄</span>`;
      const body=document.createElement('div');body.className='fix649WidthBody';head.addEventListener('click',()=>{store[String(w)]=!store[String(w)];section.classList.toggle('is-open',!!store[String(w)]);head.setAttribute('aria-expanded',store[String(w)]?'true':'false');});section.append(head,body);
      [{key:'cart',title:'METOD panelen'},{key:'extra',title:'Overige panelen'}].forEach(sec=>{
        const secEntries=entries.filter(e=>e.kind===sec.key);if(!secEntries.length)return;
        const label=document.createElement('div');label.className='fix649SectionLabel';label.textContent=sec.title;body.appendChild(label);
        const groups=root._groupGrainDisplayEntries(secEntries).sort((a,b)=>String(a&&a.rep&&a.rep.label||'').localeCompare(String(b&&b.rep&&b.rep.label||'')));
        groups.forEach(group=>{
          const rep=group.rep,total=Math.max(1,group.items.length),free=group.items.filter(x=>!x.grainGroupId);
          const row=document.createElement('div');row.className='fix649PanelRow';
          const main=document.createElement('div');main.className='fix649PanelMain';main.innerHTML=`<div class="fix649PanelName">${esc(rep.label)}</div><div class="fix649PanelMeta">${esc(fmt(widthMm(rep)))} × ${esc(fmt(heightMm(rep)))} mm${esc(root.grainDoorDirectionLabel(rep.raw))}${esc(root.grainExtLabel(rep.raw))}${rep.kind==='extra'?' · overig':''}</div><div class="fix649PanelAvailability">${free.length} van ${total} beschikbaar</div>`;
          const actions=document.createElement('div');actions.className='fix649AddActions';[['+1',1,true],['+5',5,false],['Alles','all',false]].forEach(spec=>{const b=document.createElement('button');b.type='button';b.className='fix649AddBtn'+(spec[2]?' is-primary':'');b.textContent=spec[0];b.disabled=!free.length;b.addEventListener('click',ev=>{ev.stopPropagation();addMany(free.map(x=>x.ref),spec[1]);});actions.appendChild(b);});
          row.append(main,actions);body.appendChild(row);
        });
      });host.appendChild(section);
    });
  }

  function mini(e){const box=document.createElement('div');box.className='fix660PanelMiniBox';const shape=document.createElement('div');shape.className='fix660PanelMiniShape';const w=Math.max(1,widthMm(e)),h=Math.max(1,heightMm(e)),sc=Math.min(28/w,34/h);shape.style.width=Math.max(4,w*sc)+'px';shape.style.height=Math.max(3,h*sc)+'px';box.appendChild(shape);return box;}

  function updateVisualBadges(body){
    const rows=Array.from(body.querySelectorAll('.fix660GroupItem')),total=rows.length;
    rows.forEach((el,i)=>{const pos=total-i;el.dataset.position=String(pos);const b=el.querySelector('.fix660OrderBadge');if(b)b.textContent=String(pos);const m=el.querySelector('.fix660Position');if(m)m.textContent=`positie ${pos}/${total}`;});
  }

  function bindTouchReorder(handle,item,body,g){
    let active=false,startY=0,moved=false;
    const finish=(ev)=>{if(!active)return;active=false;try{handle.releasePointerCapture(ev.pointerId);}catch(_){}item.classList.remove('is-dragging');document.body.classList.remove('fix660GrainReordering');if(moved){const visual=Array.from(body.querySelectorAll('.fix660GroupItem')).map(el=>String(el.dataset.ref||'')).filter(Boolean);g.items=visual.reverse();root.syncGroupOrders();refreshAll();}moved=false;};
    handle.addEventListener('pointerdown',ev=>{if(ev.button!=null&&ev.button!==0)return;active=true;moved=false;startY=ev.clientY;try{handle.setPointerCapture(ev.pointerId);}catch(_){}item.classList.add('is-dragging');document.body.classList.add('fix660GrainReordering');ev.preventDefault();});
    handle.addEventListener('pointermove',ev=>{if(!active)return;if(Math.abs(ev.clientY-startY)>5)moved=true;let target=document.elementFromPoint(ev.clientX,ev.clientY);target=target&&target.closest&&target.closest('.fix660GroupItem');if(!target||target===item||target.parentElement!==body)return;const r=target.getBoundingClientRect();body.insertBefore(item,ev.clientY<r.top+r.height/2?target:target.nextSibling);updateVisualBadges(body);});
    handle.addEventListener('pointerup',finish);handle.addEventListener('pointercancel',finish);
  }

  function renderMobileGroups(){
    const host=q('grainGroups');if(!host)return;host.innerHTML='';
    const mk=String(materialKey()||'');let list=(root.state.grain.groups||[]).filter(g=>!mk||String(g.materialKey||'')===mk);ensureSelectedGroup();
    if(!list.length){const no=document.createElement('div');no.className='help';no.textContent='Nog geen nerf-set. Voeg een paneel toe; de eerste set wordt automatisch gemaakt.';host.appendChild(no);try{root.drawGrainPreview();}catch(_){}return;}
    list.forEach(g=>{
      const selected=String(root.state.grain.selectedGroupId||'')===String(g.id||'');const wrap=document.createElement('section');wrap.className='fix649GroupAccordion'+(selected?' is-selected':'');wrap.dataset.groupId=g.id;
      const header=document.createElement('div');header.className='fix649GroupHeader';const select=document.createElement('button');select.type='button';select.className='fix649GroupSelect';select.innerHTML=`<span class="fix649GroupTitle">Nerfgroep ${esc(g.id)}</span><span class="fix649GroupMeta">${esc(groupSummary(g))}</span>`;
      const count=document.createElement('span');count.className='fix649WidthCount';count.textContent=String((g.items||[]).length);const del=document.createElement('button');del.type='button';del.className='fix649GroupDelete';del.title='Verwijder nerf-set';del.setAttribute('aria-label','Verwijder nerf-set');del.textContent='×';header.append(select,count,del);wrap.appendChild(header);
      const body=document.createElement('div');body.className='fix649GroupBody fix660GroupBody';const hint=document.createElement('div');hint.className='fix649GroupHint';hint.textContent='Onder → boven · positie 1 is het onderste paneel';body.appendChild(hint);
      if(!(g.items||[]).length){const e=document.createElement('div');e.className='fix649GroupEmpty';e.textContent='Voeg het onderste paneel als eerste toe.';body.appendChild(e);}else{
        // Visual list is TOP -> BOTTOM; semantic production list remains BOTTOM -> TOP.
        g.items.slice().reverse().forEach(ref=>{
          const semanticIndex=g.items.map(String).indexOf(String(ref)),position=semanticIndex+1,e=entry(ref);if(!e)return;
          const item=document.createElement('div');item.className='fix660GroupItem'+(String(root.__fix660SelectedGrainRef||'')===String(ref)?' is-selected':'');item.dataset.ref=String(ref);item.dataset.groupId=String(g.id);item.dataset.position=String(position);
          const badge=document.createElement('div');badge.className='fix660OrderBadge';badge.textContent=String(position);item.append(badge,mini(e));
          const main=document.createElement('button');main.type='button';main.className='fix660GroupItemMain';main.innerHTML=`<span class="fix649GroupItemName">${esc(e.label)}</span><span class="fix649GroupItemMeta">${esc(fmt(widthMm(e)))} × ${esc(fmt(heightMm(e)))} mm${esc(root.grainDoorDirectionLabel(e.raw))}${esc(root.grainExtLabel(e.raw))}${e.kind==='extra'?' · overig':''} · <span class="fix660Position">positie ${position}/${g.items.length}</span></span>`;main.addEventListener('click',()=>{root.__fix660SelectedGrainRef=String(ref);root.state.grain.selectedGroupId=g.id;renderMobileGroups();root.drawGrainPreview();});item.appendChild(main);
          const drag=document.createElement('button');drag.type='button';drag.className='fix660DragHandle';drag.setAttribute('aria-label','Sleep om te stapelen');drag.title='Sleep om te stapelen';drag.innerHTML='<span></span><span></span><span></span>';item.appendChild(drag);
          const rm=document.createElement('button');rm.type='button';rm.className='fix660RemoveBtn';rm.setAttribute('aria-label','Verwijder uit nerf-set');rm.title='Verwijder uit nerf-set';rm.textContent='×';rm.addEventListener('click',ev=>{ev.stopPropagation();root.removeFromGroup(g.id,ref);});item.appendChild(rm);body.appendChild(item);bindTouchReorder(drag,item,body,g);
        });
      }
      wrap.appendChild(body);select.addEventListener('click',()=>{root.state.grain.selectedGroupId=g.id;renderMobileGroups();root.drawGrainPreview();});del.addEventListener('click',ev=>{ev.stopPropagation();root.state.grain.groups=root.state.grain.groups.filter(x=>x.id!==g.id);if(root.state.grain.selectedGroupId===g.id)root.state.grain.selectedGroupId=null;ensureSelectedGroup();refreshAll();});host.appendChild(wrap);
    });
  }

  function installOverrides(){
    root.rebuildGrainEligible=function(){if(isMobile())return renderMobileEligible();return typeof baseEligible==='function'?baseEligible():undefined;};
    root.rebuildGrainGroups=function(){if(isMobile())return renderMobileGroups();return typeof baseGroups==='function'?baseGroups():undefined;};
    root.drawGrainPreview=function(){ensureSelectedGroup();const out=typeof basePreview==='function'?basePreview():undefined;syncSummary();return out;};
  }

  function syncSummary(){const el=q('fix649PreviewSummary');if(!el)return;const g=ensureSelectedGroup();el.textContent=g?`Nerfgroep ${g.id} · ${groupSummary(g)}`:'Nog geen nerf-set geselecteerd.';}

  let drawer=null,handle=null,arrow=null,actions=null,dragging=false,startY=0,startOffset=0,suppressClick=false;
  const PEEK=14;
  const travel=()=>drawer?Math.max(0,drawer.getBoundingClientRect().height-PEEK):0;
  const expanded=()=>!!(drawer&&drawer.classList.contains('fix660DrawerOpen'));
  function setTransform(offset){if(!drawer)return;drawer.style.transform=`translateY(${Math.max(0,Math.min(travel(),offset))}px)`;}
  function setDrawer(open,instant=false){if(!drawer)return;drawer.classList.toggle('fix660DrawerOpen',!!open);drawer.classList.toggle('fix660DrawerClosed',!open);drawer.style.removeProperty('transform');if(arrow)arrow.textContent=open?'⌄':'⌃';drawer.setAttribute('aria-expanded',open?'true':'false');root.__fix660GrainDrawerOpen=!!open;if(open){ensureSelectedGroup();syncSummary();try{root.drawGrainPreview();}catch(_){}if(!instant)setTimeout(()=>{try{root.drawGrainPreview();}catch(_){}},220);}}
  function buildActions(){if(!isMobile()||actions)return;const modal=document.querySelector('#grainOverlay .modal');if(!modal)return;actions=document.createElement('div');actions.className='fix660MobileActions';const c=document.createElement('button');c.type='button';c.className='btn';c.textContent='Annuleren';c.addEventListener('click',()=>q('grainCancelBtn')&&q('grainCancelBtn').click());const a=document.createElement('button');a.type='button';a.className='btn btnPrimary';a.textContent='Toepassen';a.addEventListener('click',()=>q('grainApplyBtn')&&q('grainApplyBtn').click());actions.append(c,a);modal.appendChild(actions);}
  function initDrawer(forceClosed=false){
    if(!isMobile())return;drawer=document.querySelector('#grainOverlay .grainPreviewCard');if(!drawer)return;drawer.classList.add('fix660PreviewDrawer');handle=q('fix660DrawerHandle')||drawer.querySelector('.fix660DrawerHandle');arrow=handle&&handle.querySelector('.fix660DrawerArrow');
    const old=q('fix649PreviewToggle');if(old)old.hidden=true;
    if(handle&&!handle.dataset.fix660r5Bound){handle.dataset.fix660r5Bound='1';handle.addEventListener('click',ev=>{if(suppressClick){suppressClick=false;return;}ev.preventDefault();setDrawer(!expanded());});handle.addEventListener('pointerdown',ev=>{if(ev.button!=null&&ev.button!==0)return;dragging=true;suppressClick=false;startY=ev.clientY;startOffset=expanded()?0:travel();drawer.classList.add('fix660DrawerDragging');try{handle.setPointerCapture(ev.pointerId);}catch(_){}ev.preventDefault();});handle.addEventListener('pointermove',ev=>{if(!dragging)return;const dy=ev.clientY-startY;if(Math.abs(dy)>5)suppressClick=true;setTransform(startOffset+dy);});const finish=ev=>{if(!dragging)return;dragging=false;drawer.classList.remove('fix660DrawerDragging');try{handle.releasePointerCapture(ev.pointerId);}catch(_){}const current=Math.max(0,Math.min(travel(),startOffset+(ev.clientY-startY)));setDrawer(current<travel()*.52,true);};handle.addEventListener('pointerup',finish);handle.addEventListener('pointercancel',finish);}
    buildActions();if(forceClosed){root.__fix660GrainDrawerOpen=false;setDrawer(false,true);}else setDrawer(!!root.__fix660GrainDrawerOpen,true);syncSummary();
  }
  function teardown(){if(drawer){drawer.classList.remove('fix660PreviewDrawer','fix660DrawerOpen','fix660DrawerClosed','fix660DrawerDragging');drawer.style.removeProperty('transform');}if(actions){actions.remove();actions=null;}drawer=null;handle=null;arrow=null;}
  function hookOpen(){try{const original=root.openGrainOverlay;if(typeof original==='function'&&!original.__fix660r5Hook){const wrapped=function(){root.__fix660GrainDrawerOpen=false;const out=original.apply(this,arguments);requestAnimationFrame(()=>{if(isMobile()){ensureSelectedGroup();initDrawer(true);try{root.rebuildGrainGroups();root.drawGrainPreview();}catch(_){}}});return out;};wrapped.__fix660r5Hook=true;root.openGrainOverlay=wrapped;}}catch(_){} }
  function viewportChanged(){try{if(isMobile())initDrawer(false);else teardown();if(q('grainOverlay')&&q('grainOverlay').style.display!=='none'){root.rebuildGrainEligible();root.rebuildGrainGroups();root.drawGrainPreview();}}catch(_){} }
  function focusRef(ref){root.__fix660SelectedGrainRef=String(ref||'');try{root.rebuildGrainGroups();root.drawGrainPreview();}catch(_){}setTimeout(()=>{try{const el=document.querySelector(`#grainGroups .fix660GroupItem[data-ref="${CSS.escape(String(ref||''))}"]`);if(el)el.scrollIntoView({behavior:'smooth',block:'center'});}catch(_){}},20);}

  function start(){installOverrides();hookOpen();if(isMobile())initDrawer(true);try{const mq=root.matchMedia(MQ);if(mq.addEventListener)mq.addEventListener('change',viewportChanged);else if(mq.addListener)mq.addListener(viewportChanged);}catch(_){}try{const ov=q('grainOverlay');if(ov&&root.MutationObserver)new MutationObserver(()=>{if(isMobile()&&ov.style.display!=='none')requestAnimationFrame(()=>{ensureSelectedGroup();initDrawer(false);});}).observe(ov,{attributes:true,attributeFilter:['style','class']});}catch(_){} }

  root.ToolAGrainStudioMobile=Object.freeze({BUILD:'FIX660R5_CLEAN_MOBILE_GRAIN',focusRef,openPreview(){if(isMobile()){initDrawer(false);setDrawer(true);}},closePreview(){if(isMobile())setDrawer(false);},ensureSelectedGroup});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})(window);
