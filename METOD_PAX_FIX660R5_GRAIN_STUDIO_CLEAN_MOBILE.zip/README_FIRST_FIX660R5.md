# METOD/PAX FIX660R5 — Clean Mobile Grain Studio

Doel: de mobiele Doorlopende Nerf-flow rustiger, betrouwbaarder en eenduidig bottom-to-top maken bovenop de live FIX660R4 baseline.

## Functionele wijzigingen
- Mobile header sterk gecomprimeerd; lange dubbele uitleg verwijderd.
- Nerf-preview is standaard volledig dicht: alleen de compacte handle is zichtbaar boven de vaste actiebar.
- Preview opent/sluit via tap of verticale drag en wordt bij iedere nieuwe overlay-open opnieuw gesloten.
- Preview kiest automatisch een bestaande actieve/gevulde nerfgroep; geen onterechte lege “selecteer een nerf-set” toestand meer.
- `g.items` blijft autoritatief BOTTOM -> TOP: positie 1 is fysiek onderaan.
- Nieuw paneel wordt geappend en komt dus fysiek boven de bestaande stapel.
- Zowel de mobile custom renderer als de basis/desktop renderer projecteren de lijst TOP -> BOTTOM op scherm, zonder de productievolgorde te veranderen.
- Drag/reorder vertaalt visuele TOP -> BOTTOM volgorde terug naar semantische BOTTOM -> TOP volgorde.
- Alle Grain Studio assets krijgen een nieuwe `v=660r5` cachebuster zodat iOS/Safari geen oude R2/R3/R4 UI-module kan hergebruiken.

## Niet gewijzigd
Pricing/mixed VAT, CSV library/taxonomy, optimizer, submitflow, security, materiaal-swatch contract en publieke URL/poorten zijn niet gewijzigd.

## Baseline/deploy
De installer accepteert uitsluitend een exact hash-gecontroleerde FIX660R4 live baseline, of een reeds exact gelijke FIX660R5 target voor idempotente rerun. Marker-only upgrades zijn verboden.
