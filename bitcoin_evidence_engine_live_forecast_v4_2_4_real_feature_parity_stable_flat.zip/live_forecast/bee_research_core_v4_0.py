from __future__ import annotations

VERSION = "v4.2.3_research_core_feature_parity_model_stats"

MODEL_STATS = {
    "cycle_reversal": {
        "30d": {"historical_winrate": 0.65, "oos_winrate": 0.61, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
        "90d": {"historical_winrate": 0.68, "oos_winrate": 0.62, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
    },
    "elite_reversal": {
        "30d": {"historical_winrate": 0.73, "oos_winrate": 0.66, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
        "90d": {"historical_winrate": 0.95, "oos_winrate": 0.90, "sample_size": "elite_overlap_adjusted_approx", "profit_factor": None, "ev": None},
    },
    "reversal": {
        "30d": {"historical_winrate": 0.62, "oos_winrate": 0.58, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
        "90d": {"historical_winrate": 0.70, "oos_winrate": 0.64, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
    },
}

def _f(row, key, default=0.0):
    try:
        v = row.get(key, default)
        if v is None: return default
        return float(v)
    except Exception:
        return default

def _base_result(row):
    close = _f(row, "close", _f(row, "price", 0.0))
    return {
        "action":"NO_TRADE", "decision":"NO_TRADE", "specialist":"none", "tier":"none", "horizon":"none", "prob":0.0,
        "entry_price": close, "take_profit": None, "stop_loss": None,
        "exit_policy":"none", "levels_label":"none", "reason":"NO_ENGINE_TRIGGER", "priority":0,
        "diagnostics": {}, "notify": False
    }

def cycle_debug(row):
    fg = _f(row, "fear_greed", 50)
    mom4 = _f(row, "mom_4h", _f(row, "return_4", 0))
    dd = _f(row, "drawdown_from_ath", 0)
    risk_on = bool(row.get("risk_on", False))
    gate = (fg < 25 and mom4 > 0)
    fear_bonus = max(0.0, min(1.0, (25.0 - fg) / 25.0)) * 0.12
    dd_bonus = 0.04 if dd < -30 else 0.0
    risk_bonus = 0.02 if risk_on else 0.0
    prob = min(0.88, 0.62 + fear_bonus + dd_bonus + risk_bonus)
    return {"applies": gate, "prob": round(prob, 6), "reason": f"CYCLE_GATE_{'OK' if gate else 'FAIL'} fear_greed={fg:.2f}<25 mom_4h={mom4:.6f}>0; CORE_PROB=0.62+fear_bonus({fear_bonus:.4f})+dd_bonus({dd_bonus:.2f})+risk_bonus({risk_bonus:.2f})"}

def elite_reversal_debug(row):
    fg = _f(row, "fear_greed", 50); dd = _f(row,"drawdown_from_ath",0); rsi = _f(row,"rsi_14",50); mom4=_f(row,"mom_4h", _f(row,"return_4",0))
    gate = (fg <= 18 and dd <= -30 and rsi <= 38 and mom4 > -0.02)
    prob = 0.78 + max(0, (18-fg)/18)*0.08 + (0.04 if dd <= -40 else 0) + (0.03 if rsi <= 32 else 0)
    prob = min(0.95, prob)
    return {"applies": gate, "prob": round(prob,6), "reason": f"ELITE_GATE_{'OK' if gate else 'FAIL'} fg={fg:.2f}<=18 dd={dd:.2f}<=-30 rsi={rsi:.2f}<=38 mom4={mom4:.6f}>-0.02"}

def reversal_debug(row):
    fg = _f(row,"fear_greed",50); dd=_f(row,"drawdown_from_ath",0); rsi=_f(row,"rsi_14",50); r24=_f(row,"return_24",0)
    gate = (fg < 30 and dd < -20 and rsi < 50 and r24 > -0.03)
    prob = 0.60 + max(0, (30-fg)/30)*0.08 + (0.03 if dd < -35 else 0) + (0.02 if r24 > 0 else 0)
    prob = min(0.82, prob)
    return {"applies": gate, "prob": round(prob,6), "reason": f"REVERSAL_GATE_{'OK' if gate else 'FAIL'} fg={fg:.2f}<30 dd={dd:.2f}<-20 rsi={rsi:.2f}<50 return_24={r24:.6f}>-0.03"}

def _levels(entry, horizon="30d"):
    # Indicative monitor levels only; not fixed validated exit policy.
    return round(entry*1.18,2), round(entry*0.90,2)

def _tier(prob):
    if prob >= 0.78: return "elite"
    if prob >= 0.66: return "strong"
    if prob >= 0.62: return "push"
    return "watch"

def decide_all(row):
    entry = _f(row,"close", _f(row,"price",0.0))
    outputs=[]
    for name, dbgfn, priority in [
        ("cycle_reversal", cycle_debug, 2),
        ("elite_reversal", elite_reversal_debug, 3),
        ("reversal", reversal_debug, 1),
    ]:
        d = dbgfn(row)
        out = {"specialist": name, "applies": d["applies"], "prob": d["prob"], "reason": d["reason"], "priority": priority}
        outputs.append(out)
    active = [o for o in outputs if o["applies"]]
    if not active:
        res = _base_result(row); res["diagnostics"]={"engine_outputs":outputs}; return res
    best = sorted(active, key=lambda x:(x["priority"], x["prob"]), reverse=True)[0]
    tp, sl = _levels(entry, "30d")
    res = {
        "action":"LONG", "decision":"LONG", "specialist": best["specialist"], "tier": _tier(best["prob"]), "horizon":"30d", "prob": best["prob"],
        "entry_price": round(entry,2), "take_profit": tp, "stop_loss": sl,
        "exit_policy":"wide_trailing_paper", "levels_label":"indicative_monitoring_levels_not_fixed_exit", "reason": best["reason"],
        "priority": best["priority"], "diagnostics":{"engine_outputs":outputs}, "notify": True
    }
    return res
