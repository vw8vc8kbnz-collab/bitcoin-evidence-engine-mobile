#!/usr/bin/env bash
cd /home/ubuntu/bitcoin-engine-deploy/current/live_forecast && . ../.venv/bin/activate
while true; do python bee_live_forecast_v4_1_paper.py --once || true; sleep 3600; done
