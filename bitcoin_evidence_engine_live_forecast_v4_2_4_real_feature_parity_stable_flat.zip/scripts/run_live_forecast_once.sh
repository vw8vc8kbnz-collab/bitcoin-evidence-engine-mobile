#!/usr/bin/env bash
cd /home/ubuntu/bitcoin-engine-deploy/current/live_forecast && . ../.venv/bin/activate && python bee_live_forecast_v4_1_paper.py --once
