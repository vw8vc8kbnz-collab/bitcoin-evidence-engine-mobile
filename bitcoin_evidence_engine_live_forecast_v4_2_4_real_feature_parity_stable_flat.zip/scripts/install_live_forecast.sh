#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv || true
. .venv/bin/activate
pip install -q -r live_forecast/requirements.txt
mkdir -p live_forecast/state live_forecast/logs live_forecast/cache
printf '✅ Live forecast install OK.\n'
