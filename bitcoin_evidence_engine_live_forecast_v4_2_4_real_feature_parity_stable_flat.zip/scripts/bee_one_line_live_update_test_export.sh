#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/bitcoin-engine-deploy/current
printf '[1/9] Installing live forecast...\n'
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh
cd live_forecast
. ../.venv/bin/activate
printf '[2/9] Version...\n'
python bee_live_forecast_v4_1_paper.py --version
printf '[3/9] Real production feature parity test...\n'
python bee_live_forecast_v4_1_paper.py --feature-parity-test
printf '[4/9] Golden test...\n'
python bee_live_forecast_v4_1_paper.py --golden-test
printf '[5/9] Basic ntfy test...\n'
python bee_live_forecast_v4_1_paper.py --test-ntfy
printf '[6/9] Trade ntfy test with model stats...\n'
python bee_live_forecast_v4_1_paper.py --test-trade-ntfy
printf '[7/9] Inspect live data and record status...\n'
python bee_live_forecast_v4_1_paper.py --inspect-live-data
printf '[8/9] Export debug ZIP...\n'
python bee_live_forecast_v4_1_paper.py --export-debug
printf '[9/9] Done. Download: /home/ubuntu/bee_latest_export.zip\n'
ls -lah /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export.zip || true
