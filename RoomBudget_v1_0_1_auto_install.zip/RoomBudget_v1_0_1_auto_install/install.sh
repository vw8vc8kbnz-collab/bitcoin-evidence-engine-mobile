#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${ROOMBUDGET_APP_DIR:-/opt/roombudget}"
PORT="${ROOMBUDGET_PORT:-8899}"
SERVICE="roombudget.service"
PYTHON_BIN="${ROOMBUDGET_PYTHON:-$(command -v python3 || true)}"
if [ -z "$PYTHON_BIN" ]; then echo "ERROR: python3 not found"; exit 1; fi
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

echo "============================================================"
echo "RoomBudget v1.0.1 automatic installer"
echo "============================================================"
echo "This installer only manages: $SERVICE"
echo "Install dir: $APP_DIR"
echo "Port: $PORT"
echo "Existing other services are not stopped or modified."
echo "============================================================"

# warn but do not kill other apps if port is used by another process
if command -v ss >/dev/null 2>&1; then
  if ss -ltn | awk '{print $4}' | grep -q ":${PORT}$"; then
    echo "WARNING: Port $PORT is already in use."
    echo "If this is an old RoomBudget process, restart will replace it."
    echo "If another app uses it, rerun with another port, e.g. ROOMBUDGET_PORT=8901 ./install.sh"
  fi
fi

sudo mkdir -p "$APP_DIR"
# Preserve .env and storage/db/uploads across updates
if [ -f "$APP_DIR/.env" ]; then
  cp "$APP_DIR/.env" /tmp/roombudget.env.backup
fi
if [ -d "$APP_DIR/app/storage" ]; then
  sudo mkdir -p /tmp/roombudget_storage_backup
  sudo rsync -a "$APP_DIR/app/storage/" /tmp/roombudget_storage_backup/ || true
fi
if [ -d "$APP_DIR/app/static/uploads" ]; then
  sudo mkdir -p /tmp/roombudget_uploads_backup
  sudo rsync -a "$APP_DIR/app/static/uploads/" /tmp/roombudget_uploads_backup/ || true
fi

sudo rsync -a --delete \
  --exclude '.venv' \
  --exclude '.env' \
  --exclude 'app/storage' \
  --exclude 'app/static/uploads' \
  ./ "$APP_DIR/"

sudo mkdir -p "$APP_DIR/app/storage" "$APP_DIR/app/static/uploads"
if [ -d /tmp/roombudget_storage_backup ]; then sudo rsync -a /tmp/roombudget_storage_backup/ "$APP_DIR/app/storage/" || true; fi
if [ -d /tmp/roombudget_uploads_backup ]; then sudo rsync -a /tmp/roombudget_uploads_backup/ "$APP_DIR/app/static/uploads/" || true; fi
sudo chown -R "$USER":"$USER" "$APP_DIR"
cd "$APP_DIR"

if [ ! -d .venv ]; then
  "$PYTHON_BIN" -m venv .venv
fi
.venv/bin/python -m pip install --upgrade pip
.venv/bin/pip install --only-binary=:all: -r requirements.txt

if [ -f /tmp/roombudget.env.backup ]; then
  cp /tmp/roombudget.env.backup .env
  # ensure current port in env follows installer input if user changed it
  if grep -q '^ROOMBUDGET_PORT=' .env; then
    sed -i "s/^ROOMBUDGET_PORT=.*/ROOMBUDGET_PORT=$PORT/" .env
  else
    echo "ROOMBUDGET_PORT=$PORT" >> .env
  fi
else
  SECRET="$(.venv/bin/python - <<'PY'
import secrets
print(secrets.token_urlsafe(48))
PY
)"
  cat > .env <<ENV
ROOMBUDGET_PORT=$PORT
ROOMBUDGET_SECRET_KEY=$SECRET
ROOMBUDGET_AI_PROVIDER=mock
ROOMBUDGET_AI_ENABLED=true
ROOMBUDGET_FREE_RENDERS_PER_USER=1
ROOMBUDGET_MAX_DAILY_RENDERS_GLOBAL=100
ROOMBUDGET_MAX_MONTHLY_AI_EUR=100
ENV
fi

sudo tee /etc/systemd/system/$SERVICE >/dev/null <<UNIT
[Unit]
Description=RoomBudget PWA
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/.venv/bin/uvicorn app.main:app --host 0.0.0.0 --port $PORT
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable $SERVICE >/dev/null
sudo systemctl restart $SERVICE
sleep 2

echo "============================================================"
echo "RoomBudget service status"
echo "============================================================"
sudo systemctl status $SERVICE --no-pager -l || true

echo "============================================================"
echo "Health check"
echo "============================================================"
if curl -fsS "http://127.0.0.1:$PORT/health"; then
  echo
  echo "OK: RoomBudget is live on port $PORT"
else
  echo "ERROR: health check failed. Logs:"
  sudo journalctl -u $SERVICE -n 80 --no-pager || true
  exit 1
fi

echo "Open: http://YOUR_VPS_IP:$PORT"
