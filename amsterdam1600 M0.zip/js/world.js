// M0-wereld: een procedureel, deterministisch "test-Amsterdam".
// Dit is bewust GEEN historische kaart — die komt in M1 via de
// Tiled-pipeline (Pieter Bast 1599). Dit terrein bestaat alleen om de
// renderer te bewijzen met een herkenbare geografie:
//   - het IJ als brede waterband in het noorden (bovenkant kaart)
//   - de Amstel die vanuit het zuiden de stad in slingert
//   - een middeleeuwse kern met straten en bouwgrond
//   - een singelgracht (verdedigingsmoat) om de kern
//   - veenweidegebied met sloten daarbuiten
import { GRID, T, SEED } from './config.js';
import { fnoise, hash2d } from './rng.js';

export function generateWorld() {
  const tiles = new Uint8Array(GRID * GRID);

  // Stadskern-parameters
  const CX = 128;
  const CY = 66;
  const CORE_R = 40;

  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const n = fnoise(x / 13, y / 13, SEED);
      let t;

      // 1. Het IJ: noordelijke waterband met gerafelde oever
      const ijEdge = 24 + 9 * fnoise(x / 9, 3.7, SEED ^ 0x11);
      if (y < ijEdge) {
        t = T.IJ;
      } else {
        // 2. De Amstel: slingert van zuid naar het IJ
        const ax = CX + 13 * Math.sin(y / 33) + 5 * Math.sin(y / 11 + 2.1);
        const aw = 3.2 + 1.4 * fnoise(y / 7, 8.8, SEED ^ 0x22);
        const inAmstel = Math.abs(x - ax) < aw;

        // 3. Stadskern-afstand (licht elliptisch, platter in noord-zuid)
        const dx = x - CX;
        const dy = (y - CY) * 1.12;
        const d = Math.sqrt(dx * dx + dy * dy);

        if (inAmstel) {
          t = T.CANAL;
        } else if (d >= CORE_R && d < CORE_R + 3 && y > ijEdge + 2) {
          // 4. Singelgracht: moat rond de middeleeuwse stad
          t = T.CANAL;
        } else if (d < CORE_R) {
          // 5. Binnen de kern: straten + bouwgrond
          const ring = d % 13;
          const angle = Math.atan2(dy, dx);
          const k = (angle + Math.PI) / (Math.PI / 7);
          const radial = Math.abs(k - Math.round(k)) * d < 0.85;
          if ((ring < 1.5 && d > 5) || (radial && d > 7)) {
            t = T.STREET;
          } else if (n > 0.74) {
            t = T.GRASS; // hofjes en tuinen
          } else {
            t = T.DIRT;
          }
        } else {
          // 6. Buitengebied: veenweide met ontwateringssloten
          const sloot = (y % 16 === 8) && fnoise(x / 21, y / 3, SEED ^ 0x33) > 0.3;
          if (sloot) t = T.CANAL;
          else t = n > 0.56 ? T.GRASS : T.MARSH;
        }
      }

      tiles[y * GRID + x] = t;
    }
  }

  return tiles;
}

export function tileAt(tiles, x, y) {
  if (x < 0 || y < 0 || x >= GRID || y >= GRID) return -1;
  return tiles[y * GRID + x];
}

// Deterministische visuele variant per tegel (spriteselectie).
export function variantAt(x, y) {
  return hash2d(x, y, SEED ^ 0x77) < 0.5 ? 0 : 1;
}
