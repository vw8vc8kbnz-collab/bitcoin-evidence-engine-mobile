// Renderer met twee paden:
//   zoom ≥ OVERVIEW_CUTOFF → per zichtbare tegel één drawImage (geculled)
//   zoom <  OVERVIEW_CUTOFF → één drawImage van de vooraf gerenderde
//                             overzichtskaart. Zo blijft volledig
//                             uitzoomen 60 fps op een telefoon.
import {
  GRID, HALF_W, HALF_H, TILE_W, TILE_H, T,
  OVERVIEW_CUTOFF, OVERVIEW_SCALE, WATER_FRAMES, WATER_FRAME_MS,
} from './config.js';
import { variantAt } from './world.js';

// Wereld-schermruimte spant: sx ∈ [−GRID·HALF_W, +GRID·HALF_W], sy ∈ [0, GRID·TILE_H]
const WORLD_SX_MIN = -GRID * HALF_W;
const WORLD_SW = GRID * TILE_W;
const WORLD_SH = GRID * TILE_H;

export class Renderer {
  constructor(ctx, world, tileset) {
    this.ctx = ctx;
    this.world = world;
    this.sprites = tileset.sprites;
    this.selectionSprite = tileset.selection;
    this.selected = null;     // [tx, ty] of null
    this.overview = null;     // offscreen canvas, lazy gebouwd
    this.drawnTiles = 0;      // debug-teller
  }

  // Hele kaart één keer klein renderen (≈ 2048×1024). Eén keer ~100–300 ms
  // bij het opstarten; daarna is ver uitzoomen gratis.
  buildOverview() {
    const c = document.createElement('canvas');
    c.width = Math.ceil(WORLD_SW * OVERVIEW_SCALE);
    c.height = Math.ceil(WORLD_SH * OVERVIEW_SCALE);
    const octx = c.getContext('2d');
    octx.imageSmoothingEnabled = false;

    const w = TILE_W * OVERVIEW_SCALE;
    const h = TILE_H * OVERVIEW_SCALE;
    for (let y = 0; y < GRID; y++) {
      for (let x = 0; x < GRID; x++) {
        const t = this.world[y * GRID + x];
        const frames = this.sprites[t];
        const sprite = frames[t === T.IJ || t === T.CANAL ? 0 : variantAt(x, y)];
        const sx = ((x - y) * HALF_W - WORLD_SX_MIN) * OVERVIEW_SCALE;
        const sy = (x + y) * HALF_H * OVERVIEW_SCALE;
        octx.drawImage(sprite, sx - w / 2, sy, w, h);
      }
    }
    this.overview = c;
  }

  draw(cam, tMs) {
    const { ctx } = this;
    ctx.fillStyle = '#141a19';
    ctx.fillRect(0, 0, cam.w, cam.h);

    if (cam.zoom < OVERVIEW_CUTOFF && this.overview) {
      this.drawOverview(cam);
    } else {
      this.drawTiles(cam, tMs);
    }
    this.drawSelection(cam);
  }

  drawOverview(cam) {
    const [px, py] = cam.worldToScreen(WORLD_SX_MIN, 0);
    this.ctx.imageSmoothingEnabled = true;
    this.ctx.drawImage(this.overview, px, py, WORLD_SW * cam.zoom, WORLD_SH * cam.zoom);
    this.drawnTiles = 1;
  }

  drawTiles(cam, tMs) {
    const { ctx, world, sprites } = this;
    const [x0, x1, y0, y1] = cam.visibleTileBounds();
    const waterFrame = Math.floor(tMs / WATER_FRAME_MS) % WATER_FRAMES;

    const dw = TILE_W * cam.zoom;
    const dh = TILE_H * cam.zoom;
    ctx.imageSmoothingEnabled = cam.zoom < 1;

    let drawn = 0;
    // Painter's order: y buiten, x binnen — irrelevant voor platte tegels,
    // maar dit is exact de sortering die gebouwen in M2 nodig hebben.
    for (let y = y0; y <= y1; y++) {
      const row = y * GRID;
      for (let x = x0; x <= x1; x++) {
        const t = world[row + x];
        const isWater = t === T.IJ || t === T.CANAL;
        const sprite = sprites[t][isWater ? waterFrame : variantAt(x, y)];
        const [px, py] = cam.worldToScreen((x - y) * HALF_W, (x + y) * HALF_H);
        if (px < -dw || px > cam.w + dw || py < -dh || py > cam.h + dh) continue;
        ctx.drawImage(sprite, px - dw / 2, py, dw, dh);
        drawn++;
      }
    }
    this.drawnTiles = drawn;
  }

  drawSelection(cam) {
    if (!this.selected) return;
    const [x, y] = this.selected;
    const [px, py] = cam.worldToScreen((x - y) * HALF_W, (x + y) * HALF_H);
    const dw = TILE_W * cam.zoom;
    const dh = TILE_H * cam.zoom;
    this.ctx.drawImage(this.selectionSprite, px - dw / 2, py, dw, dh);
  }
}
