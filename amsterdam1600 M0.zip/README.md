# Amsterdam 1600 — Canal Sovereign · M0

Mobile-first isometrische managementsim (GDD v2). Deze milestone is het
**render-fundament**: 256×256 grid, touch-camera, procedureel test-Amsterdam.
Framework-vrij, ES modules, geen build-step — zelfde filosofie als
Configurator Studio.

## Wat M0 bewijst
- Isometrische projectie + painter's sort (y→x), exact zoals gebouwen in M2 nodig hebben
- Viewport-culling + voorgerenderde sprites → 60 fps op mobiel
- Overzichtskaart-fallback bij ver uitzoomen (hele kaart = 1 drawImage)
- Touch: 1 vinger pan, 2 vingers pinch-zoom, tik = tegel selecteren
- Deterministische wereldgeneratie (seed 1600): IJ, Amstel, stadskern met straten, singelgracht, veenweide met sloten

## Lokaal / VPS draaien
```
node server.js              # poort 9600
PORT=9700 node server.js    # andere poort
```

## Deploy (GitHub → VPS → Termius)
Zip in je repo zetten, dan op de VPS:

```
cd ~/apps/<jouw-repo> && git pull && sudo mkdir -p /var/www/amsterdam1600 && sudo unzip -o amsterdam1600_M0.zip -d /var/www/amsterdam1600 && pm2 start /var/www/amsterdam1600/server.js --name amsterdam1600 || pm2 restart amsterdam1600 && pm2 save
```

Daarna op je telefoon: `http://51.195.102.180:9600`

> Poort 9600 is vrij naast je bestaande services (8700 Outrun OS, 8787 BEE,
> 8899 Roomarc, 9999 Configurator). Server stuurt `Cache-Control: no-store`,
> dus Safari-cache is geen issue — gewoon verversen na elke deploy.

## Testchecklist M0 (op je telefoon)
- [ ] Kaart in beeld < 1 s, geen witte flits
- [ ] FPS-teller linksboven toont ~60 bij pannen op zoom 0.9
- [ ] Pinch tot maximaal uitzoomen: hele kaart zichtbaar, fps blijft hoog
- [ ] Tik op een tegel → coördinaat + typenaam ("Veenmoeras", "Grachtwater", …)
- [ ] Water animeert subtiel (3 frames)
- [ ] Geen scroll-bounce of pagina-zoom (iOS)

## Structuur
```
index.html / style.css      schil + HUD
js/config.js                alle constanten (grid, zoom, tegeltypes)
js/rng.js                   seeded RNG + hash-noise (determinisme-regel)
js/world.js                 wereldgeneratie (M1: vervangen door Tiled-kaart Pieter Bast)
js/tiles.js                 sprite-prerendering naar offscreen canvases
js/camera.js                iso-wiskunde, picking, zoom-rond-punt
js/input.js                 pointer events: pan / pinch / tap
js/renderer.js              culled tegel-loop + overzichtskaart
js/main.js                  wiring, loop, fps, HUD
server.js                   zero-dep static server, no-store
```

## Volgende milestone (M1)
Kaartlader: Pieter Bast (1599) overtrekken in Tiled → JSON → `world.js`
vervangen door echte kaartdata. Herkenbaar Amsterdam op het scherm.
