# Outrun IQ v0.1 Foundation VPS Ready

Run locally:

```bash
python3 server.py
```

Health:

```bash
curl -s http://127.0.0.1:8795/api/health
```

This package is the first custom foundation build: premium buyer homepage, product grid/detail, checkout trust flow, seller dashboard, AI pricing upload flow, language switcher and seller intake endpoint.
