# AlgoRoute v1.2.1 — Navigation Flow + Smart Mapping Engine

## Nieuw
- Sidebar opnieuw logisch ingedeeld in Operations, Resources en Management.
- Import Studio is geen los hoofdmenu-item meer, maar onderdeel van de Planning workflow.
- Planning subflow: Import → Mapping → Queue → Optimize → Publish.
- Load Optimization toegevoegd als eigen hoofdmodule.
- Smart Mapping Engine sterk uitgebreid met fuzzy matching, synoniemen NL/EN, spelfout-tolerantie en waarde-detectie.
- Mapping toont confidence scores zoals 94% / waarschijnlijk / zeer zeker.
- Backend voorbereid voor `/api/import/suggest-mapping` en `/api/integrations/catalog`.
- Integraties worden voorbereid voor Odoo, Exact Online, AFAS, WooCommerce, CSV/SFTP, Custom API en webhooks.

## Nog niet
- Integraties zijn nog catalogus/architectuur, nog geen echte ERP-koppeling.
- Mapping learning is nog lokaal via templates/localStorage, nog niet database-persistent.
- Planning Optimize en Publish zijn nog workflow placeholders.

## Testen
1. Open Planning.
2. Bekijk subflow tabs.
3. Open Import/Mapping en laad voorbeeld CSV.
4. Controleer dat kolommen automatisch worden gekoppeld met confidence scores.
5. Zoek in Smart Field Picker op fout gespelde of Engelse termen.
6. Check API's:
   - `/api/import/fields`
   - `/api/import/suggest-mapping`
   - `/api/integrations/catalog`
