from datetime import datetime, timezone
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="AlgoRoute API", version="1.2.1")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

VEHICLES = [
    {"id":"veh-01","name":"Bus 01","driver":"Milan","plate":"V-123-AB","status":"on_time","speed":62,"eta":"16:12","stops_done":3,"stops_total":8,"load":"5/6 pallets","progress":58,"lng":4.9041,"lat":52.3676,"heading":35},
    {"id":"veh-02","name":"Bus 02","driver":"Pieter","plate":"V-456-CD","status":"delay","speed":48,"eta":"15:44","stops_done":5,"stops_total":10,"load":"7/8 RC","progress":72,"lng":4.4777,"lat":51.9244,"heading":70},
    {"id":"veh-03","name":"Bus 03","driver":"Sanne","plate":"V-789-EF","status":"on_time","speed":54,"eta":"17:05","stops_done":2,"stops_total":9,"load":"4/6 pallets","progress":33,"lng":5.1214,"lat":52.0907,"heading":-20},
    {"id":"veh-04","name":"Bus 04","driver":"Jeroen","plate":"V-321-GH","status":"critical","speed":0,"eta":"18:22","stops_done":1,"stops_total":7,"load":"vol","progress":18,"lng":5.4697,"lat":51.4416,"heading":0},
]

ROUTES = [
    {"id":"route-01","vehicle_id":"veh-01","name":"Noord-Holland Premium","km":184,"duration":"6u 12m","risk":"low","color":"#5baa32","coordinates":[[4.9041,52.3676],[4.821,52.363],[4.735,52.377],[4.6462,52.3874],[4.665,52.474],[4.703,52.555],[4.7486,52.6324],[4.865,52.655],[5.059,52.642],[5.022,52.551],[4.953,52.448],[4.872,52.337]],"stops":[
        {"seq":1,"city":"Amsterdam","eta":"08:42","status":"done","lng":4.9041,"lat":52.3676},
        {"seq":2,"city":"Haarlem","eta":"09:30","status":"done","lng":4.6462,"lat":52.3874},
        {"seq":3,"city":"Alkmaar","eta":"11:15","status":"current","lng":4.7486,"lat":52.6324},
        {"seq":4,"city":"Hoorn","eta":"12:05","status":"planned","lng":5.059, "lat":52.642},
        {"seq":5,"city":"Amsterdam-Zuid","eta":"14:20","status":"planned","lng":4.872,"lat":52.337}
    ]},
    {"id":"route-02","vehicle_id":"veh-02","name":"Rotterdam / Den Haag","km":211,"duration":"7u 05m","risk":"medium","color":"#8a3ffc","coordinates":[[4.4777,51.9244],[4.392,51.965],[4.3571,52.0116],[4.3007,52.0705],[4.365,52.038],[4.4792,51.9225],[4.636,52.014],[4.780,52.166],[4.8952,52.3702]],"stops":[
        {"seq":1,"city":"Rotterdam","eta":"09:10","status":"done","lng":4.4777,"lat":51.9244},
        {"seq":2,"city":"Den Haag","eta":"10:40","status":"current","lng":4.3007,"lat":52.0705},
        {"seq":3,"city":"Delft","eta":"12:10","status":"planned","lng":4.3571,"lat":52.0116}
    ]},
    {"id":"route-03","vehicle_id":"veh-04","name":"Brabant EV Route","km":268,"duration":"8u 02m","risk":"high","color":"#f97316","coordinates":[[5.4697,51.4416],[5.394,51.516],[5.3037,51.6905],[5.206,51.660],[5.0913,51.5555],[5.015,51.702],[4.982,51.890],[4.8952,52.3702]],"stops":[
        {"seq":1,"city":"Eindhoven","eta":"10:05","status":"done","lng":5.4697,"lat":51.4416},
        {"seq":2,"city":"Tilburg","eta":"12:35","status":"current","lng":5.0913,"lat":51.5555},
        {"seq":3,"city":"Den Bosch","eta":"14:05","status":"planned","lng":5.3037,"lat":51.6905}
    ]},
]

EVENTS = [
    {"id":"e1","title":"A16 vertraging +18 min","route":"Rotterdam / Den Haag","type":"traffic","severity":"medium"},
    {"id":"e2","title":"Bus 04 volledig beladen","route":"Brabant EV Route","type":"load","severity":"critical"},
    {"id":"e3","title":"3 stops binnen belofte-window","route":"Noord-Holland Premium","type":"promise","severity":"ok"},
    {"id":"e4","title":"EV-range marge laag: 22% batterij","route":"Brabant EV Route","type":"ev","severity":"critical"},
]

@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": "1.2.1", "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/map/state")
def map_state():
    return {"center": [5.2913, 52.1326], "zoom": 6.8, "vehicles": VEHICLES, "routes": ROUTES, "events": EVENTS, "traffic_segments": [
        {"id":"traffic-a16","status":"orange","label":"A16 +18 min","coordinates":[[4.392,51.965],[4.3571,52.0116],[4.3007,52.0705]]},
        {"id":"traffic-a2","status":"red","label":"A2 incident","coordinates":[[5.015,51.702],[4.982,51.890],[4.8952,52.3702]]}
    ]}

@app.get("/api/vehicles")
def vehicles():
    return VEHICLES

@app.get("/api/routes")
def routes():
    return ROUTES


PLANNING_ORDERS = [
    {"id":"ord-1001","order_number":"ORD-1001","customer_name":"De Vries Keukens","city":"Amsterdam","postal_code":"1015CJ","delivery_date":"2026-06-28","time_window_start":"08:00","time_window_end":"11:00","window_label":"08:00-11:00","product":"Keukenfronten","quantity":4,"total_weight_kg":320,"euro_pallets":2,"roll_containers":0,"unload_minutes":25,"priority":2,"status":"ready","readiness":["address_ok","time_window_ok","load_ok"],"warnings":[],"notes":"Bel 30 min vooraf","two_person_required":True,"tracking_allowed":True},
    {"id":"ord-1002","order_number":"ORD-1002","customer_name":"Studio Wonen","city":"Rotterdam","postal_code":"3011AD","delivery_date":"2026-06-28","time_window_start":"10:00","time_window_end":"13:00","window_label":"10:00-13:00","product":"Witgoed set","quantity":2,"total_weight_kg":180,"euro_pallets":1,"roll_containers":1,"unload_minutes":35,"priority":1,"status":"ready","readiness":["address_ok","time_window_ok","load_ok"],"warnings":[],"notes":"Levering achterom","two_person_required":True,"tracking_allowed":True},
    {"id":"ord-1003","order_number":"ORD-1003","customer_name":"Bouwmarkt Zuid","city":"Eindhoven","postal_code":"5611EC","delivery_date":"2026-06-28","time_window_start":"13:00","time_window_end":"16:00","window_label":"13:00-16:00","product":"Sanitair pallet","quantity":1,"total_weight_kg":540,"euro_pallets":3,"roll_containers":0,"unload_minutes":45,"priority":3,"status":"attention","readiness":["address_ok","time_window_ok"],"warnings":["Zware order: check voertuigcapaciteit"],"notes":"Lossen bij magazijndeur","two_person_required":False,"tracking_allowed":True},
    {"id":"ord-1004","order_number":"ORD-1004","customer_name":"Interieur Lijn","city":"Utrecht","postal_code":"3511AC","delivery_date":"2026-06-29","time_window_start":"09:00","time_window_end":"12:00","window_label":"09:00-12:00","product":"Maatwerk kast","quantity":1,"total_weight_kg":260,"euro_pallets":0,"roll_containers":2,"unload_minutes":55,"priority":2,"status":"ready","readiness":["address_ok","time_window_ok","load_ok"],"warnings":[],"notes":"Lift aanwezig, montageploeg nodig","two_person_required":True,"tracking_allowed":True},
    {"id":"ord-1005","order_number":"ORD-1005","customer_name":"Project Noord","city":"Groningen","postal_code":"9711AA","delivery_date":"2026-06-29","time_window_start":"","time_window_end":"","window_label":"Geen tijdslot","product":"Bouwmateriaal","quantity":8,"total_weight_kg":760,"euro_pallets":4,"roll_containers":0,"unload_minutes":40,"priority":1,"status":"incomplete","readiness":["address_ok","load_ok"],"warnings":["Tijdvenster ontbreekt"],"notes":"Mag middag indien nodig","two_person_required":False,"tracking_allowed":False},
]

IMPORT_FIELD_CATEGORIES = [
    "Order", "Klant", "Adres", "Tijdvenster", "Producten", "Gewicht & Volume",
    "Pallets & Rolcontainers", "Planning", "Service", "Instructies", "Tracking", "Finance", "Custom"
]

@app.get("/api/import/fields")
def import_fields():
    return {
        "version": "1.1.0",
        "categories": IMPORT_FIELD_CATEGORIES,
        "message": "Frontend bevat de volledige Smart Field Picker catalogus; backend endpoint is klaar voor centrale veldcatalogus."
    }

@app.post("/api/import/validate")
def import_validate(payload: dict):
    rows = payload.get("rows", [])
    mapping = payload.get("mapping", {})
    mapped = [v.get("key") for v in mapping.values() if isinstance(v, dict)]
    errors = []
    if "order_number" not in mapped:
        errors.append({"row": "mapping", "message": "Ordernummer ontbreekt"})
    if "customer_name" not in mapped:
        errors.append({"row": "mapping", "message": "Klantnaam ontbreekt"})
    if "full_address" not in mapped and not ({"postal_code", "city"} <= set(mapped)):
        errors.append({"row": "mapping", "message": "Adres ontbreekt: gebruik Volledig adres of Postcode + Plaats"})
    return {"valid": max(0, len(rows) - 1 - len(errors)), "warnings": 0, "errors": errors}

@app.post("/api/import/commit")
def import_commit(payload: dict):
    return {"ok": True, "status": "queued_for_planning", "orders_created": max(0, len(payload.get("rows", [])) - 1)}


@app.post("/api/import/suggest-mapping")
def suggest_mapping(payload: dict):
    headers = payload.get("headers", [])
    sample_row = payload.get("sample_row", [])
    # Frontend performs rich fuzzy/value detection. Backend endpoint exists for future central/AI mapping service.
    return {"ok": True, "engine": "smart_mapping_v1", "columns": len(headers), "message": "Client-side fuzzy mapping active; backend endpoint reserved for ERP/API normalization."}

@app.get("/api/integrations/catalog")
def integrations_catalog():
    return {"connectors": [
        {"id":"csv", "name":"CSV / Excel", "status":"active"},
        {"id":"odoo", "name":"Odoo", "status":"planned"},
        {"id":"exact", "name":"Exact Online", "status":"planned"},
        {"id":"afas", "name":"AFAS", "status":"planned"},
        {"id":"woocommerce", "name":"WooCommerce", "status":"planned"},
        {"id":"custom_api", "name":"Custom API / Webhooks", "status":"planned"}
    ]}

@app.get("/api/planning/queue")
def planning_queue():
    dates = sorted({o.get("delivery_date") or "ongepland" for o in PLANNING_ORDERS})
    total_weight = sum(o.get("total_weight_kg",0) for o in PLANNING_ORDERS)
    total_pallets = sum(o.get("euro_pallets",0) for o in PLANNING_ORDERS)
    total_rc = sum(o.get("roll_containers",0) for o in PLANNING_ORDERS)
    return {
        "version":"1.2.0",
        "orders": PLANNING_ORDERS,
        "dates": dates,
        "summary": {
            "orders_total": len(PLANNING_ORDERS),
            "ready": len([o for o in PLANNING_ORDERS if o["status"] == "ready"]),
            "attention": len([o for o in PLANNING_ORDERS if o["status"] == "attention"]),
            "incomplete": len([o for o in PLANNING_ORDERS if o["status"] == "incomplete"]),
            "total_weight_kg": total_weight,
            "total_euro_pallets": total_pallets,
            "total_roll_containers": total_rc,
            "available_euro_pallets": 18,
            "available_roll_containers": 18,
            "available_weight_kg": 5200
        }
    }

@app.post("/api/planning/queue/import")
def planning_queue_import(payload: dict):
    # First persistent version will store these in DB. This endpoint normalizes mapped import rows into planning-ready order objects.
    rows = payload.get("rows", [])
    return {"ok": True, "status":"queued", "orders_queued": max(0, len(rows)-1), "target":"planning_queue"}

