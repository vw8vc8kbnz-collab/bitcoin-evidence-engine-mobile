#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bitcoin Evidence Engine — V4.1 Live Forecast Loop (Paper Mode)

Doel:
- Draait op de bestaande server als simpele Python-loop.
- Haalt live marktdata op.
- Bouwt een row-dict met dezelfde veldnamen als de V4.0 backtest.
- Draait exact dezelfde decision core via bee_research_core_v4_0.decide(row).
- Meldt alleen paper-forecast signalen via ntfy en logt alles lokaal.

Belangrijke scope V4.1:
- GEEN automatische handel.
- Alleen actieve engines uit de walk-forward analyse:
  cycle_reversal, elite_reversal, reversal.
- Continuation en funding-squeeze worden wel diagnostisch berekend door de core,
  maar in fase 1 niet genotificeerd.
- Standaard daily check; funding-squeeze snelle loop komt pas later.

Standaard library only: urllib, json, csv, time, datetime, statistics.
"""
import argparse
import csv
import datetime as _dt
import json
import math
import os
import sys
import time
import traceback
import urllib.parse
import urllib.request
from pathlib import Path

try:
    import bee_research_core_v4_0 as core
except Exception as e:
    print("FOUT: bee_research_core_v4_0.py staat niet naast dit script of importeert niet:", e)
    raise

VERSION = "v4.1.5_live_paper_regime_debug_fix"
APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "bee_live_config.json"
CONFIG_EXAMPLE_PATH = APP_DIR / "bee_live_config.example.json"
STATE_PATH = APP_DIR / "bee_live_state.json"
SIGNAL_LOG_PATH = APP_DIR / "bee_live_signals.jsonl"
SYSTEM_LOG_PATH = APP_DIR / "bee_live_system.log"
GOLDEN_FEATURE_LOG = APP_DIR / "bee_live_last_feature_snapshot.json"

DEFAULT_CONFIG = {
    "ntfy_topic": "",
    "ntfy_server": "https://ntfy.sh",
    "alpha_vantage_api_key": "",
    "check_interval_hours": 24,
    "active_specialists": ["cycle_reversal", "elite_reversal", "reversal"],
    "min_notify_tier": "push",
    "dedup_days_by_specialist": {"cycle_reversal": 7, "elite_reversal": 14, "reversal": 14},
    "binance_base_urls": ["https://api.binance.com", "https://api.binance.us"],
    "use_coinbase_premium": True,
    "paper_only": True,
    "macro_cache_hours": 24,
    "fear_greed_cache_hours": 12,
    "btc_1h_limit": 1000,
    "btc_1d_limit": 1000,
    "min_closed_1h_candles": 220,
    "include_trade_plan_in_ntfy": True,
    "live_exit_policy": "wide_trailing_paper",
}

TIER_RANK = {"none": 0, "watch": 1, "push": 2, "strong": 3, "elite": 4}
ACTIVE_SCOPE_NOTE = "V4.1 phase 1 live paper: only CycleReversal, EliteReversal, Reversal notify. No trading."


# Historical model metrics used only for context in notifications.
# These are NOT used as live decision inputs. They are copied from the V4.0/V3.4 research export.
# all_history = all available historical rows in the research CSV for that model/timeframe.
# oos_walk_forward = train-gated walk-forward summary where available; smaller but more honest.
MODEL_TIMEFRAME_STATS = {
    "cycle_reversal": {
        "24h": {"n": 7865, "winrate": 49.9, "avg_return_pct": 0.74, "pf": 1.51, "source": "all_history"},
        "7d":  {"n": 7850, "winrate": 60.7, "avg_return_pct": 5.66, "pf": 2.72, "source": "all_history"},
        "30d": {"n": 7830, "winrate": 79.5, "avg_return_pct": 21.66, "pf": 10.44, "source": "all_history"},
        "90d": {"n": 7361, "winrate": 91.6, "avg_return_pct": 38.86, "pf": 29.24, "source": "all_history"},
    },
    "elite_reversal": {
        "24h": {"n": 2231, "winrate": 54.7, "avg_return_pct": 1.53, "pf": 2.39, "source": "all_history"},
        "7d":  {"n": 2231, "winrate": 71.8, "avg_return_pct": 9.59, "pf": 8.35, "source": "all_history"},
        "30d": {"n": 2231, "winrate": 82.7, "avg_return_pct": 23.22, "pf": 17.27, "source": "all_history"},
        "90d": {"n": 2175, "winrate": 94.9, "avg_return_pct": 40.98, "pf": 54.56, "source": "all_history"},
    },
    "reversal": {
        "24h": {"n": 3311, "winrate": 58.0, "avg_return_pct": 2.06, "pf": 3.23, "source": "all_history"},
        "7d":  {"n": 3311, "winrate": 60.2, "avg_return_pct": 7.74, "pf": 5.16, "source": "all_history"},
        "30d": {"n": 3311, "winrate": 76.6, "avg_return_pct": 19.47, "pf": 13.50, "source": "all_history"},
        "90d": {"n": 3311, "winrate": 91.8, "avg_return_pct": 37.65, "pf": 59.16, "source": "all_history"},
    },
}

OOS_WALK_FORWARD_STATS = {
    # Small sample but more honest: train-gated walk-forward OOS from V4.0 summary.
    "cycle_reversal": {"n": 45, "winrate": 57.8, "avg_return_pct": 9.62, "pf_note": "fold PFs: 3.45 / 5.05 / 2.86", "source": "walk_forward_oos_2024_2026"},
    "elite_reversal": {"n": 15, "winrate": 73.3, "avg_return_pct": 14.42, "pf": 5.61, "source": "walk_forward_oos_2026_only"},
    "reversal": {"n": 16, "winrate": 62.5, "avg_return_pct": 3.92, "pf_note": "2026 PF 1.80; 2023 n=2", "source": "walk_forward_oos_2023_2026"},
}


def get_model_stats(spec, horizon):
    spec = (spec or "").lower()
    horizon = horizon or ""
    return (MODEL_TIMEFRAME_STATS.get(spec) or {}).get(horizon) or {}


def get_oos_stats(spec):
    return OOS_WALK_FORWARD_STATS.get((spec or "").lower()) or {}


def _fmt_usd(v):
    try:
        return "$" + format(float(v), ",.0f")
    except Exception:
        return "n/a"


def build_trade_plan(row, decision, cfg=None):
    """Build the paper trade plan shown in ntfy.

    This is NOT execution logic. It gives a paper entry/TP/SL snapshot so the alert is usable.
    Live phase 1 uses wide trailing as the safety policy. Therefore TP is shown as an
    indicative historical move target, while SL is the initial wide-trailing invalidation level.
    """
    cfg = cfg or {}
    spec = decision.get("selected_specialist") or "none"
    action = decision.get("decision") or "NO_TRADE"
    horizon = decision.get("primary_horizon") or "none"
    entry = row.get("close")
    try:
        entry_f = float(entry)
    except Exception:
        entry_f = None
    stats = get_model_stats(spec, horizon)
    avg_pct = stats.get("avg_return_pct")
    try:
        avg_pct_f = float(avg_pct)
    except Exception:
        avg_pct_f = None
    try:
        trail_pct = float(core.recommended_trailing_pct(spec))
    except Exception:
        trail_pct = 18.0
    tp = sl = None
    if entry_f is not None:
        # Use a conservative minimum TP if no stats are available; active models should have stats.
        effective_tp_pct = avg_pct_f if avg_pct_f is not None else 10.0
        if action == "LONG":
            tp = entry_f * (1.0 + effective_tp_pct / 100.0)
            sl = entry_f * (1.0 - trail_pct / 100.0)
        elif action == "SHORT":
            tp = entry_f * (1.0 - abs(effective_tp_pct) / 100.0)
            sl = entry_f * (1.0 + trail_pct / 100.0)
    return {
        "model": spec,
        "action": action,
        "timeframe": horizon,
        "exit_policy": cfg.get("live_exit_policy", "wide_trailing_paper"),
        "entry_price": entry_f,
        "take_profit_price": tp,
        "stoploss_price": sl,
        "take_profit_pct": avg_pct_f,
        "initial_trailing_stop_pct": trail_pct,
        "stats_all_history": stats,
        "stats_oos_walk_forward": get_oos_stats(spec),
        "note": "TP is an indicative historical-average target; V4.1 paper exit policy is wide trailing, not automatic trading.",
    }



def utc_now():
    return _dt.datetime.now(_dt.UTC).replace(microsecond=0).replace(tzinfo=None)


def utc_from_timestamp(ts):
    return _dt.datetime.fromtimestamp(float(ts), _dt.UTC).replace(microsecond=0).replace(tzinfo=None)


def iso_now():
    return utc_now().isoformat() + "Z"


def log(msg):
    line = f"{iso_now()} {msg}"
    print(line)
    try:
        with open(SYSTEM_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def load_json(path, default):
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                merged = dict(default)
                merged.update(data)
                return merged
    except Exception as e:
        log(f"WARN load_json failed for {path}: {e}")
    return dict(default)


def save_json(path, data):
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    os.replace(tmp, path)


def load_config():
    cfg = load_json(CONFIG_PATH, DEFAULT_CONFIG)
    # env overrides, so secrets do not need to live in the file
    cfg["ntfy_topic"] = os.environ.get("BEE_NTFY_TOPIC", cfg.get("ntfy_topic", ""))
    cfg["alpha_vantage_api_key"] = os.environ.get("ALPHAVANTAGE_API_KEY", cfg.get("alpha_vantage_api_key", ""))
    return cfg


def load_state():
    default = {"created_at": iso_now(), "last_notified": {}, "cache": {}, "last_decision": None}
    return load_json(STATE_PATH, default)


def save_state(state):
    save_json(STATE_PATH, state)


def http_json(url, timeout=20, headers=None):
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "BEE-LiveForecast/4.1.4"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8")
    return json.loads(raw)


def fetch_binance_klines(symbol="BTCUSDT", interval="1h", limit=1000, base_urls=None):
    base_urls = base_urls or ["https://api.binance.com", "https://api.binance.us"]
    last_err = None
    for base in base_urls:
        url = f"{base}/api/v3/klines?" + urllib.parse.urlencode({"symbol": symbol, "interval": interval, "limit": int(limit)})
        try:
            data = http_json(url, timeout=20)
            out = []
            now_ms = int(time.time() * 1000)
            for k in data:
                # Binance kline: [open_time, open, high, low, close, volume, close_time, ...]
                close_time = int(k[6])
                # skip still-open candle
                if close_time > now_ms:
                    continue
                out.append({
                    "open_time_ms": int(k[0]),
                    "close_time_ms": close_time,
                    "dt": utc_from_timestamp(int(k[0]) / 1000.0).isoformat() + "Z",
                    "open": float(k[1]),
                    "high": float(k[2]),
                    "low": float(k[3]),
                    "close": float(k[4]),
                    "volume": float(k[5]),
                })
            if out:
                return out
        except Exception as e:
            last_err = e
            log(f"WARN Binance klines failed base={base} interval={interval}: {e}")
    raise RuntimeError(f"All Binance kline endpoints failed: {last_err}")


def fetch_funding(base_urls=None):
    # Futures endpoint is only available on global Binance. If blocked, return cached/missing.
    urls = ["https://fapi.binance.com/fapi/v1/fundingRate?symbol=BTCUSDT&limit=20"]
    last_err = None
    for url in urls:
        try:
            data = http_json(url, timeout=20)
            if data:
                latest = data[-1]
                return {"funding_rate": float(latest.get("fundingRate", 0.0)), "funding_time": latest.get("fundingTime")}
        except Exception as e:
            last_err = e
            log(f"WARN funding fetch failed: {e}")
    raise RuntimeError(f"funding fetch failed: {last_err}")


def fetch_fear_greed():
    data = http_json("https://api.alternative.me/fng/?limit=10&format=json", timeout=20)
    rows = data.get("data") or []
    if not rows:
        raise RuntimeError("alternative.me returned no fear&greed data")
    latest = rows[0]
    return {"fear_greed": float(latest.get("value")), "fear_greed_label": latest.get("value_classification"), "fear_greed_ts": latest.get("timestamp")}


def fetch_spy_weekly(api_key):
    if not api_key:
        raise RuntimeError("Alpha Vantage key missing. Set ALPHAVANTAGE_API_KEY or config alpha_vantage_api_key.")
    params = {"function": "TIME_SERIES_WEEKLY", "symbol": "SPY", "apikey": api_key}
    url = "https://www.alphavantage.co/query?" + urllib.parse.urlencode(params)
    data = http_json(url, timeout=25)
    series = data.get("Weekly Time Series")
    if not series:
        raise RuntimeError("Alpha Vantage weekly SPY missing. Response keys: " + ",".join(data.keys()))
    dates = sorted(series.keys())
    if len(dates) < 2:
        raise RuntimeError("not enough SPY weekly bars")
    # Use only completed weekly closes. AlphaVantage weekly bar updates after week close; daily loop cache is fine.
    d1, d0 = dates[-1], dates[-2]
    c1 = float(series[d1]["4. close"])
    c0 = float(series[d0]["4. close"])
    ret = (c1 / c0 - 1.0) * 100.0
    return {"spx_close": c1, "spx_ret_1w_calc": ret, "spx_week_date": d1, "spx_prev_week_date": d0, "macro_safe": abs(ret) <= core.MACRO_ABS_CLAMP, "macro_source": "alpha_vantage_spy_weekly"}


def fetch_coinbase_premium(binance_close):
    data = http_json("https://api.exchange.coinbase.com/products/BTC-USD/ticker", timeout=20)
    cb = float(data.get("price"))
    prem = (cb / binance_close - 1.0) * 100.0 if binance_close else None
    return {"coinbase_price": cb, "coinbase_premium_pct": prem}


def cache_get_or_fetch(state, cache_key, max_age_hours, fetch_fn):
    cache = state.setdefault("cache", {})
    item = cache.get(cache_key)
    now_ts = time.time()
    if item and isinstance(item, dict):
        age_h = (now_ts - float(item.get("fetched_ts", 0))) / 3600.0
        if age_h <= max_age_hours and item.get("data") is not None:
            return item["data"], True
    data = fetch_fn()
    cache[cache_key] = {"fetched_ts": now_ts, "fetched_at": iso_now(), "data": data}
    return data, False


def sma(vals, n):
    if len(vals) < n:
        return None
    chunk = vals[-n:]
    return sum(chunk) / float(n)


def pct(now, prev):
    if now is None or prev in (None, 0):
        return None
    return (now / prev - 1.0) * 100.0


def rsi(closes, period=14):
    if len(closes) < period + 1:
        return None
    gains = []
    losses = []
    window = closes[-(period+1):]
    for a, b in zip(window[:-1], window[1:]):
        diff = b - a
        if diff >= 0:
            gains.append(diff); losses.append(0.0)
        else:
            gains.append(0.0); losses.append(-diff)
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))


def stdev(vals):
    vals = [v for v in vals if v is not None]
    if len(vals) < 2:
        return None
    m = sum(vals) / len(vals)
    return math.sqrt(sum((v-m)*(v-m) for v in vals) / (len(vals)-1))


def infer_regime(close, ma50, ma200, drawdown, fear_greed, rsi_14=None, return_24=None, return_4=None):
    """Live-only regime heuristic with explicit recovery states.

    V4.1.4 classified every deep drawdown + low fear as `capitulation`.
    That was too aggressive: a market can still be deeply below ATH while already
    rebounding (RSI high, 24h return positive). This caused confusing live debug
    output such as regime=capitulation while RSI was ~61.

    We keep the backtest-compatible labels for the decision core, but add more
    precise live labels so NO_TRADE diagnostics become truthful:
      - capitulation: active panic/selloff, low fear plus weak momentum/RSI
      - fear_recovery: deep drawdown + low fear, but rebound already underway
      - bear_trend: below long MA or deep fear without active panic
      - bull_trend / transition
    """
    deep_dd = drawdown is not None and drawdown <= -35.0
    low_fear = fear_greed is not None and fear_greed < 30.0
    extreme_fear = fear_greed is not None and fear_greed < 20.0
    weak_rsi = rsi_14 is not None and rsi_14 < 40.0
    strong_rsi = rsi_14 is not None and rsi_14 >= 55.0
    selloff_24h = return_24 is not None and return_24 <= -2.0
    rebound_24h = return_24 is not None and return_24 >= 0.5
    rebound_4h = return_4 is not None and return_4 > 0.0

    if deep_dd and low_fear:
        if extreme_fear and (weak_rsi or selloff_24h):
            return "capitulation"
        if strong_rsi or rebound_24h or rebound_4h:
            return "fear_recovery"
        return "bear_trend"
    if close is not None and ma200 is not None and close < ma200:
        return "bear_trend"
    if drawdown is not None and drawdown <= -25.0 and fear_greed is not None and fear_greed < 35.0:
        return "bear_trend"
    if close is not None and ma50 is not None and ma200 is not None and close > ma50 and ma50 > ma200:
        return "bull_trend"
    return "transition"


def explain_regime(row):
    return {
        "regime": row.get("regime"),
        "fear_greed": row.get("fear_greed"),
        "drawdown_from_ath": row.get("drawdown_from_ath"),
        "rsi_14": row.get("rsi_14"),
        "return_24": row.get("return_24"),
        "return_4": row.get("return_4"),
        "explanation": (
            "active capitulation requires extreme fear plus weak RSI or negative 24h selloff; "
            "deep drawdown with rebound/strong RSI is classified as fear_recovery, not capitulation"
        ),
    }


def build_live_row(candles_1h, candles_1d, market):
    if len(candles_1h) < 220:
        raise RuntimeError(f"Need at least 220 closed 1h candles, got {len(candles_1h)}")
    closes = [c["close"] for c in candles_1h]
    highs = [c["high"] for c in candles_1h]
    lows = [c["low"] for c in candles_1h]
    vols = [c["volume"] for c in candles_1h]
    last = candles_1h[-1]
    close = closes[-1]
    # Drawdown from recent daily ATH. Live loop can later switch to persistent all-time high if desired.
    daily_highs = [c["high"] for c in candles_1d] if candles_1d else highs
    recent_ath = max(daily_highs) if daily_highs else max(highs)
    drawdown = (close / recent_ath - 1.0) * 100.0 if recent_ath else None
    rets_24 = []
    for i in range(max(1, len(closes)-24), len(closes)):
        rets_24.append(pct(closes[i], closes[i-1]) if i > 0 else None)
    vol24 = stdev(rets_24)
    volume_z = None
    if len(vols) >= 50:
        m = sum(vols[-50:]) / 50.0
        sd = stdev(vols[-50:]) or 0.0
        volume_z = (vols[-1] - m) / sd if sd > 0 else 0.0
    ma20 = sma(closes, 20); ma50 = sma(closes, 50); ma200 = sma(closes, 200)
    rsi14 = rsi(closes, 14)
    ret1 = pct(closes[-1], closes[-2]) if len(closes) >= 2 else None
    ret4 = pct(closes[-1], closes[-5]) if len(closes) >= 5 else None
    ret24 = pct(closes[-1], closes[-25]) if len(closes) >= 25 else None
    fg = market.get("fear_greed")
    row = {
        "version": VERSION,
        "open_time": last.get("open_time_ms"),
        "dt": last.get("dt"),
        "open": last.get("open"),
        "high": last.get("high"),
        "low": last.get("low"),
        "close": close,
        "return_1": ret1,
        "return_4": ret4,
        "return_24": ret24,
        "past_ret_4h": ret4,
        "past_ret_24h": ret24,
        "past_ret_7d": pct(closes[-1], closes[-169]) if len(closes) >= 169 else None,
        "past_ret_30d": pct(closes[-1], closes[-721]) if len(closes) >= 721 else None,
        "ma_20": ma20,
        "ma_50": ma50,
        "ma_200": ma200,
        "rsi_14": rsi14,
        "volatility_24": vol24,
        "volume_zscore": volume_z,
        "drawdown_from_ath": drawdown,
        "fear_greed": fg,
        "funding_rate": market.get("funding_rate"),
        "coinbase_premium_pct": market.get("coinbase_premium_pct"),
        "spx_close": market.get("spx_close"),
        "spx_ret_1d": market.get("spx_ret_1w_calc"),
        "spx_ret_1w_calc": market.get("spx_ret_1w_calc"),
        "macro_safe": bool(market.get("macro_safe")),
        "macro_source": market.get("macro_source", "live"),
        "macro_bad": not bool(market.get("macro_safe")),
    }
    row["regime"] = infer_regime(close, ma50, ma200, drawdown, fg, rsi14, ret24, ret4)
    row["regime_debug"] = explain_regime(row)
    return row


def fetch_all_and_build_row(cfg, state):
    cache = state.setdefault("cache", {})
    try:
        candles_1h = fetch_binance_klines(interval="1h", limit=int(cfg.get("btc_1h_limit", 1000)), base_urls=cfg.get("binance_base_urls"))
        cache["btc_1h_live"] = {"fetched_ts": time.time(), "fetched_at": iso_now(), "data": candles_1h}
    except Exception as e:
        cached = cache.get("btc_1h_live", {}).get("data")
        if cached:
            log(f"WARN BTC 1h fetch failed; using cached candles: {e}")
            candles_1h = cached
        else:
            raise
    try:
        candles_1d = fetch_binance_klines(interval="1d", limit=int(cfg.get("btc_1d_limit", 1000)), base_urls=cfg.get("binance_base_urls"))
        cache["btc_1d_live"] = {"fetched_ts": time.time(), "fetched_at": iso_now(), "data": candles_1d}
    except Exception as e:
        cached = cache.get("btc_1d_live", {}).get("data")
        if cached:
            log(f"WARN BTC 1d fetch failed; using cached candles: {e}")
            candles_1d = cached
        else:
            raise
    market = {}
    # Fear & greed cache.
    try:
        fg, cached = cache_get_or_fetch(state, "fear_greed", float(cfg.get("fear_greed_cache_hours", 12)), fetch_fear_greed)
        market.update(fg); market["fear_greed_cached"] = cached
    except Exception as e:
        log(f"WARN fear&greed failed: {e}")
        cached = state.get("cache", {}).get("fear_greed", {}).get("data")
        if cached:
            market.update(cached); market["fear_greed_cached_after_error"] = True
    # Macro cache.
    try:
        macro, cached = cache_get_or_fetch(state, "macro_spy_weekly", float(cfg.get("macro_cache_hours", 24)), lambda: fetch_spy_weekly(cfg.get("alpha_vantage_api_key")))
        market.update(macro); market["macro_cached"] = cached
    except Exception as e:
        log(f"WARN macro failed; continuation will abstain: {e}")
        cached = state.get("cache", {}).get("macro_spy_weekly", {}).get("data")
        if cached:
            market.update(cached); market["macro_cached_after_error"] = True
        else:
            market.update({"macro_safe": False, "spx_ret_1w_calc": None, "macro_source": "missing_live"})
    # Funding diagnostic. Not notified in phase 1, but keep for feature parity.
    try:
        funding = fetch_funding(cfg.get("binance_base_urls"))
        market.update(funding)
    except Exception as e:
        log(f"WARN funding failed; using 0/None: {e}")
        market.setdefault("funding_rate", None)
    # Coinbase premium optional.
    if cfg.get("use_coinbase_premium", True):
        try:
            market.update(fetch_coinbase_premium(candles_1h[-1]["close"]))
        except Exception as e:
            log(f"WARN coinbase premium failed; using 0.0 fallback: {e}")
            market.setdefault("coinbase_premium_pct", 0.0)
    else:
        market.setdefault("coinbase_premium_pct", 0.0)
    cache["market_live"] = {"fetched_ts": time.time(), "fetched_at": iso_now(), "data": market}
    row = build_live_row(candles_1h, candles_1d, market)
    return row, market


def validate_candle_sequence(candles, expected_interval_ms):
    result = {"count": len(candles), "ok": True, "gaps": 0, "duplicates": 0, "unsorted": 0, "first_dt": None, "last_dt": None, "last_close": None}
    if not candles:
        result["ok"] = False
        result["error"] = "no candles"
        return result
    result["first_dt"] = candles[0].get("dt")
    result["last_dt"] = candles[-1].get("dt")
    result["last_close"] = candles[-1].get("close")
    prev = None
    seen = set()
    for c in candles:
        ts = int(c.get("open_time_ms", 0))
        if ts in seen:
            result["duplicates"] += 1
        seen.add(ts)
        if prev is not None:
            if ts < prev:
                result["unsorted"] += 1
            diff = ts - prev
            if abs(diff - expected_interval_ms) > 1000:
                result["gaps"] += 1
        for key in ("open", "high", "low", "close", "volume"):
            try:
                float(c.get(key))
            except Exception:
                result["ok"] = False
                result.setdefault("bad_values", []).append({"dt": c.get("dt"), "key": key, "value": c.get(key)})
        prev = ts
    if result["gaps"] or result["duplicates"] or result["unsorted"]:
        result["ok"] = False
    return result


def model_diagnostics(row, decision):
    """Compact model-by-model diagnostics for live debugging.

    This does not change the decision. It only explains why the active phase-1
    engines did or did not trigger.
    """
    fg = row.get("fear_greed")
    dd = row.get("drawdown_from_ath")
    rsi_v = row.get("rsi_14")
    mom4 = row.get("past_ret_4h")
    ret24 = row.get("return_24")
    regime = row.get("regime")
    funding = row.get("funding_rate")
    premium = row.get("coinbase_premium_pct")

    cycle_reasons = []
    if fg is None: cycle_reasons.append("NO_FEAR_GREED")
    elif fg >= 30: cycle_reasons.append("FEAR_NOT_LOW_ENOUGH_FOR_CYCLE")
    if mom4 is None: cycle_reasons.append("NO_4H_MOMENTUM")
    elif mom4 <= 0: cycle_reasons.append("4H_MOMENTUM_NOT_POSITIVE")
    if dd is not None and dd > -30: cycle_reasons.append("DRAWDOWN_NOT_DEEP_FOR_BONUS")

    reversal_reasons = []
    if regime not in ("capitulation", "bear_trend"):
        reversal_reasons.append("REGIME_NOT_ACTIVE_REVERSAL")
    if fg is None: reversal_reasons.append("NO_FEAR_GREED")
    elif fg >= 30: reversal_reasons.append("FEAR_NOT_LOW_ENOUGH_FOR_REVERSAL")
    if not ((funding is not None and funding < 0) or (premium is not None and premium > 0)):
        reversal_reasons.append("NO_NEGATIVE_FUNDING_OR_POSITIVE_COINBASE_PREMIUM")

    elite_reasons = []
    if not decision.get("cycle_early_recovery_long"):
        elite_reasons.append("CYCLE_NOT_ACTIVE")
    if not (decision.get("reversal_applies") or decision.get("continuation_applies")):
        elite_reasons.append("NO_REVERSAL_OR_CONTINUATION_CONFLUENCE")

    # Soft scores for visibility only; not used by the core.
    def clamp(x):
        try: return max(0.0, min(1.0, float(x)))
        except Exception: return None
    cycle_soft = 0.0
    if fg is not None: cycle_soft += max(0.0, (35.0 - fg) / 35.0) * 0.45
    if mom4 is not None and mom4 > 0: cycle_soft += 0.25
    if dd is not None and dd < -30: cycle_soft += 0.20
    if ret24 is not None and ret24 > 0: cycle_soft += 0.10
    reversal_soft = 0.0
    if fg is not None: reversal_soft += max(0.0, (35.0 - fg) / 35.0) * 0.30
    if dd is not None: reversal_soft += max(0.0, min(1.0, abs(dd) / 60.0)) * 0.25
    if regime in ("capitulation", "bear_trend", "fear_recovery"): reversal_soft += 0.20
    if funding is not None and funding < 0: reversal_soft += 0.15
    if premium is not None and premium > 0: reversal_soft += 0.10

    return {
        "cycle_reversal": {
            "applies": bool(decision.get("cycle_early_recovery_long")),
            "prob": decision.get("cycle_prob_long"),
            "reason": decision.get("cycle_reason"),
            "soft_score_debug": round(clamp(cycle_soft) or 0, 3),
            "reject_reasons": cycle_reasons or ["OK"],
        },
        "reversal": {
            "applies": bool(decision.get("reversal_applies")),
            "prob": decision.get("reversal_prob"),
            "soft_score_debug": round(clamp(reversal_soft) or 0, 3),
            "reject_reasons": reversal_reasons or ["OK"],
        },
        "elite_reversal": {
            "applies": bool(decision.get("selected_specialist") == "elite_reversal" or decision.get("confluence_elite_long")),
            "confluence_elite_long": decision.get("confluence_elite_long"),
            "soft_score_debug": round(((clamp(cycle_soft) or 0) + (clamp(reversal_soft) or 0)) / 2.0, 3),
            "reject_reasons": elite_reasons or ["OK"],
        },
        "context": {
            "regime": regime,
            "regime_debug": row.get("regime_debug"),
            "fear_greed": fg,
            "drawdown_from_ath": dd,
            "rsi_14": rsi_v,
            "return_24": ret24,
            "past_ret_4h": mom4,
            "funding_rate": funding,
            "coinbase_premium_pct": premium,
        },
    }


def decision_debug_summary(row, decision):
    spec = decision.get("selected_specialist") or "none"
    out = {
        "action": decision.get("decision"),
        "specialist": spec,
        "tier": decision.get("tier"),
        "horizon": decision.get("primary_horizon"),
        "price": row.get("close"),
        "fear_greed": row.get("fear_greed"),
        "regime": row.get("regime"),
        "regime_debug": row.get("regime_debug"),
        "drawdown_from_ath": row.get("drawdown_from_ath"),
        "rsi_14": row.get("rsi_14"),
        "return_24": row.get("return_24"),
        "coinbase_premium_pct": row.get("coinbase_premium_pct"),
        "funding_rate": row.get("funding_rate"),
        "model_diagnostics": model_diagnostics(row, decision),
        "model_fields": {},
        "likely_reject_reason": None,
    }
    for k, v in decision.items():
        if any(tok in k for tok in ("cycle", "reversal", "elite", "confluence", "score", "reason", "applies")):
            if isinstance(v, (str, int, float, bool)) or v is None:
                out["model_fields"][k] = v
    if decision.get("decision") == "NO_TRADE":
        diags = out["model_diagnostics"]
        reasons = []
        for name in ("cycle_reversal", "elite_reversal", "reversal"):
            rr = diags.get(name, {}).get("reject_reasons") or []
            reasons.append(f"{name}:" + ",".join(rr))
        out["likely_reject_reason"] = " | ".join(reasons)
    return out

def inspect_live_data(cfg, state):
    row, market = fetch_all_and_build_row(cfg, state)
    cache = state.setdefault("cache", {})
    candles_1h = cache.get("btc_1h_live", {}).get("data") or []
    candles_1d = cache.get("btc_1d_live", {}).get("data") or []
    decision = core.decide(row)
    save_json(GOLDEN_FEATURE_LOG, {"created_at": iso_now(), "mode": "inspect-live-data", "row": row, "market": market, "decision": decision})
    report = {
        "ok": True,
        "version": VERSION,
        "btc_1h": validate_candle_sequence(candles_1h, 3600_000),
        "btc_1d": validate_candle_sequence(candles_1d, 86400_000),
        "fear_greed": {"value": market.get("fear_greed"), "label": market.get("fear_greed_label"), "cached": market.get("fear_greed_cached") or market.get("fear_greed_cached_after_error", False)},
        "macro": {"source": market.get("macro_source"), "safe": market.get("macro_safe"), "spx_ret_1w_calc": market.get("spx_ret_1w_calc")},
        "funding": {"funding_rate": market.get("funding_rate")},
        "coinbase": {"premium_pct": market.get("coinbase_premium_pct"), "price": market.get("coinbase_price")},
        "features": {k: row.get(k) for k in ["dt","close","ma_50","ma_200","rsi_14","return_1","return_4","return_24","past_ret_7d","drawdown_from_ath","regime","fear_greed","coinbase_premium_pct","funding_rate","regime_debug"]},
        "decision_debug": decision_debug_summary(row, decision),
    }
    report["ok"] = bool(report["btc_1h"].get("ok") and report["btc_1d"].get("ok") and row.get("close") is not None and row.get("fear_greed") is not None)
    print(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False))
    save_state(state)
    return report


def simulate_from_cache(cfg, state):
    cache = state.setdefault("cache", {})
    candles_1h = cache.get("btc_1h_live", {}).get("data")
    candles_1d = cache.get("btc_1d_live", {}).get("data")
    market = cache.get("market_live", {}).get("data")
    if not candles_1h or not candles_1d or not market:
        raise RuntimeError("No complete live cache found. Run --inspect-live-data or --test-fetch first.")
    row = build_live_row(candles_1h, candles_1d, market)
    decision = core.decide(row)
    print(json.dumps({"mode": "simulate-from-cache", "row_dt": row.get("dt"), "features": {k: row.get(k) for k in ["close","ma_50","ma_200","rsi_14","return_24","drawdown_from_ath","regime","fear_greed"]}, "decision_debug": decision_debug_summary(row, decision), "trade_plan": build_trade_plan(row, decision, cfg)}, indent=2, sort_keys=True, ensure_ascii=False))


def simulate_scenario(cfg, state, scenario):
    cache = state.setdefault("cache", {})
    try:
        candles_1h = cache.get("btc_1h_live", {}).get("data")
        candles_1d = cache.get("btc_1d_live", {}).get("data")
        market = cache.get("market_live", {}).get("data")
        if not candles_1h or not candles_1d or not market:
            row, market = fetch_all_and_build_row(cfg, state)
        else:
            row = build_live_row(candles_1h, candles_1d, market)
    except Exception as exc:
        # Scenario simulation must also work when the VPS has no fresh API cache or
        # when external APIs are temporarily down. Use a deterministic synthetic
        # baseline row and then apply the requested scenario override.
        market = {"source": "synthetic_fallback", "fetch_error": str(exc)}
        base_price = 64276.12
        row = {
            "version": VERSION,
            "dt": iso_now(),
            "open": base_price,
            "high": base_price * 1.01,
            "low": base_price * 0.99,
            "close": base_price,
            "return_1": 0.0,
            "return_4": 0.0,
            "return_24": 0.0,
            "past_ret_4h": 0.0,
            "past_ret_24h": 0.0,
            "past_ret_7d": 0.0,
            "past_ret_30d": 0.0,
            "ma_20": base_price,
            "ma_50": base_price * 0.99,
            "ma_200": base_price * 1.01,
            "rsi_14": 50.0,
            "volatility_24": 1.0,
            "volume_zscore": 0.0,
            "drawdown_from_ath": -20.0,
            "fear_greed": 50.0,
            "funding_rate": 0.0,
            "coinbase_premium_pct": 0.0,
            "spx_ret_1w_calc": 0.0,
            "macro_safe": True,
            "macro_source": "synthetic_fallback",
            "macro_bad": False,
            "regime": "transition",
            "regime_debug": {"scenario": "synthetic_fallback", "fetch_error": str(exc)},
        }
    scenario = (scenario or "panic").lower()
    if scenario in ("panic", "capitulation", "elite"):
        row.update({
            "fear_greed": 12.0,
            "drawdown_from_ath": -38.0,
            "rsi_14": 27.0,
            "regime": "capitulation",
            "regime_debug": {"scenario": "panic", "explanation": "forced synthetic panic setup"},
            "return_4": 2.4,
            "past_ret_4h": 2.4,
            "return_24": -5.8,
            "past_ret_24h": -5.8,
            "past_ret_7d": -18.0,
            "funding_rate": -0.00015,
            "coinbase_premium_pct": 0.10,
            "macro_safe": True,
        })
    elif scenario in ("neutral", "no_trade"):
        row.update({"fear_greed": 55.0, "drawdown_from_ath": -8.0, "rsi_14": 52.0, "regime": "transition", "regime_debug": {"scenario": "neutral", "explanation": "forced synthetic neutral setup"}, "return_24": 0.5, "past_ret_24h": 0.5})
    else:
        raise RuntimeError(f"Unknown scenario {scenario}. Use panic or neutral.")
    decision = core.decide(row)
    print(json.dumps({"mode": "simulate-scenario", "scenario": scenario, "features": {k: row.get(k) for k in ["close","fear_greed","drawdown_from_ath","rsi_14","regime","return_24","past_ret_7d","funding_rate","coinbase_premium_pct"]}, "decision_debug": decision_debug_summary(row, decision), "trade_plan": build_trade_plan(row, decision, cfg)}, indent=2, sort_keys=True, ensure_ascii=False))


def golden_row_test(cfg, state, target_dt):
    # Optional golden test. Put a CSV named bee_golden_rows.csv in live_forecast/ or provide BEE_GOLDEN_CSV.
    # The CSV should contain historical feature columns from the research export.
    csv_path = Path(os.environ.get("BEE_GOLDEN_CSV", "")) if os.environ.get("BEE_GOLDEN_CSV") else APP_DIR / "bee_golden_rows.csv"
    if not csv_path.exists():
        raise RuntimeError("Golden CSV not found. Put bee_golden_rows.csv next to the script or set BEE_GOLDEN_CSV=/path/to/BTC_alle_lagen_gecombineerd.csv")
    wanted = (target_dt or "").replace(" ", "T").replace("Z", "")[:13]
    found = None
    with open(csv_path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            dt = (r.get("dt") or r.get("open_time") or "").replace(" ", "T").replace("Z", "")[:13]
            if dt == wanted:
                found = r; break
    if not found:
        raise RuntimeError(f"No golden row found for hour {wanted} in {csv_path}")
    # Convert selected columns and run core directly. This verifies decision-core compatibility on a historical row.
    row = {}
    for k, v in found.items():
        if v is None or v == "":
            row[k] = None
        else:
            try:
                row[k] = float(v)
            except Exception:
                row[k] = v
    decision = core.decide(row)
    print(json.dumps({"mode": "golden-row", "csv": str(csv_path), "target_dt": target_dt, "matched_dt": row.get("dt") or row.get("open_time"), "features": {k: row.get(k) for k in ["close","ma_50","ma_200","rsi_14","return_24","drawdown_from_ath","regime","fear_greed"]}, "decision_debug": decision_debug_summary(row, decision)}, indent=2, sort_keys=True, ensure_ascii=False))


def active_decision_only(decision, cfg):
    active = set(cfg.get("active_specialists") or [])
    spec = decision.get("selected_specialist") or "none"
    if decision.get("decision") == "NO_TRADE":
        return False
    return spec in active


def should_notify(decision, cfg, state):
    if not active_decision_only(decision, cfg):
        return False, "not_active_scope_or_no_trade"
    tier = decision.get("tier") or "none"
    min_tier = cfg.get("min_notify_tier", "push")
    if TIER_RANK.get(tier, 0) < TIER_RANK.get(min_tier, 2):
        return False, "below_min_tier"
    spec = decision.get("selected_specialist")
    last_map = state.setdefault("last_notified", {})
    last = last_map.get(spec)
    now = utc_now()
    dedup_days = float((cfg.get("dedup_days_by_specialist") or {}).get(spec, 7))
    if last:
        try:
            last_dt = _dt.datetime.fromisoformat(last.get("notified_at", "").replace("Z", ""))
            age_days = (now - last_dt).total_seconds() / 86400.0
            last_tier = last.get("tier", "none")
            if age_days < dedup_days and TIER_RANK.get(tier, 0) <= TIER_RANK.get(last_tier, 0):
                return False, f"dedup_{age_days:.1f}d_since_{spec}_{last_tier}"
        except Exception:
            pass
    return True, "new_signal"


def format_signal_message(row, decision, market, cfg=None):
    cfg = cfg or {}
    spec = decision.get("selected_specialist")
    price = row.get("close")
    fg = row.get("fear_greed")
    regime = row.get("regime")
    horizon = decision.get("primary_horizon")
    tier = decision.get("tier")
    prob = decision.get("prob")
    setup = decision.get("setup_type")
    plan = build_trade_plan(row, decision, cfg)
    hist = plan.get("stats_all_history") or {}
    oos = plan.get("stats_oos_walk_forward") or {}
    parts = [
        f"BEE LIVE PAPER SIGNAL — {spec}",
        f"Model: {spec} | Setup: {setup}",
        f"Action: {decision.get('decision')} | Tier: {tier} | Timeframe: {horizon}",
        f"BTC: {_fmt_usd(price)}" if isinstance(price, (int, float)) else f"BTC: {price}",
        "",
        "PAPER TRADE PLAN",
        f"Entry: {_fmt_usd(plan.get('entry_price'))}",
        f"Take profit / target: {_fmt_usd(plan.get('take_profit_price'))} ({plan.get('take_profit_pct'):.2f}% historical avg move)" if isinstance(plan.get('take_profit_pct'), (int, float)) else f"Take profit / target: {_fmt_usd(plan.get('take_profit_price'))}",
        f"Stoploss / initial trailing stop: {_fmt_usd(plan.get('stoploss_price'))} ({plan.get('initial_trailing_stop_pct'):.1f}% trail)",
        f"Exit policy: {plan.get('exit_policy')}",
        "",
        "MODEL HISTORY",
        f"All historical data — {spec} / {horizon}: n={hist.get('n','?')} | winrate={hist.get('winrate','?')}% | avg={hist.get('avg_return_pct','?')}% | PF={hist.get('pf','?')}",
        f"Walk-forward OOS: n={oos.get('n','?')} | winrate={oos.get('winrate','?')}% | avg={oos.get('avg_return_pct','?')}% | PF={oos.get('pf', oos.get('pf_note','?'))}",
        "",
        f"Regime: {regime} | Fear&Greed: {fg}",
        f"Probability/core score: {prob:.3f}" if isinstance(prob, (int, float)) else f"Probability/core score: {prob}",
        "",
        "Paper forecast only — no automatic trade.",
        "TP/SL are paper levels for monitoring, not an exchange order.",
        ACTIVE_SCOPE_NOTE,
    ]
    if spec == "cycle_reversal":
        parts.append(f"Cycle reason: {decision.get('cycle_reason')} | mom4h={decision.get('cycle_mom_4h')} | mom7d={decision.get('cycle_mom_7d')}")
    if spec in ("reversal", "elite_reversal"):
        parts.append(f"Reversal applies: {decision.get('reversal_applies')} | cycle early: {decision.get('cycle_early_recovery_long')} | confluence: {decision.get('bullish_confluence_label')}")
    return "\n".join(parts)

def send_ntfy(cfg, title, message, priority="default", tags="chart_with_upwards_trend"):
    topic = (cfg.get("ntfy_topic") or "").strip()
    if not topic or topic == "PASTE_PRIVATE_NTFY_TOPIC_HERE":
        log("Ntfy topic missing; signal logged but not pushed.")
        return False
    server = (cfg.get("ntfy_server") or "https://ntfy.sh").rstrip("/")
    url = f"{server}/{urllib.parse.quote(topic)}"
    data = message.encode("utf-8")
    headers = {"Title": title, "Priority": priority, "Tags": tags, "User-Agent": "BEE-LiveForecast/4.1.4"}
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=15) as resp:
        resp.read()
    return True


def append_signal_log(payload):
    with open(SIGNAL_LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(payload, sort_keys=True, ensure_ascii=False) + "\n")


def run_once(cfg, state, force_notify=False):
    row, market = fetch_all_and_build_row(cfg, state)
    decision = core.decide(row)
    snapshot = {"created_at": iso_now(), "row": row, "decision": decision, "market": market, "version": VERSION}
    save_json(GOLDEN_FEATURE_LOG, snapshot)
    state["last_decision"] = snapshot
    log(f"Decision: {decision.get('decision')} specialist={decision.get('selected_specialist')} tier={decision.get('tier')} horizon={decision.get('primary_horizon')} price={row.get('close')}")
    notify, reason = should_notify(decision, cfg, state)
    if force_notify:
        notify = True; reason = "forced_test"
    payload = {
        "logged_at": iso_now(),
        "version": VERSION,
        "notify_reason": reason,
        "paper_only": True,
        "row": row,
        "decision": decision,
        "trade_plan": build_trade_plan(row, decision, cfg),
        "market": market,
        "active_scope": cfg.get("active_specialists"),
    }
    append_signal_log(payload)
    if notify:
        title = f"BEE {decision.get('selected_specialist')} {decision.get('decision')} {decision.get('tier')}"
        priority = "high" if decision.get("tier") == "elite" else "default"
        msg = format_signal_message(row, decision, market, cfg)
        try:
            pushed = send_ntfy(cfg, title, msg, priority=priority)
            payload["ntfy_pushed"] = pushed
        except Exception as e:
            payload["ntfy_error"] = str(e)
            log(f"WARN ntfy failed: {e}")
        spec = decision.get("selected_specialist") or "unknown"
        state.setdefault("last_notified", {})[spec] = {"notified_at": iso_now(), "tier": decision.get("tier"), "decision": decision.get("decision"), "price": row.get("close")}
    save_state(state)
    return payload


def test_ntfy(cfg):
    msg = "BEE V4.1.4 ntfy test — paper forecast loop is configured. No trading."
    send_ntfy(cfg, "BEE V4.1.4 test", msg, priority="default", tags="test_tube")
    log("Sent ntfy test message.")


def test_fetch(cfg, state):
    row, market = fetch_all_and_build_row(cfg, state)
    print(json.dumps({
        "ok": True,
        "version": VERSION,
        "price": row.get("close"),
        "dt": row.get("dt"),
        "fear_greed": row.get("fear_greed"),
        "regime": row.get("regime"),
        "row_keys": sorted(list(row.keys())),
        "market_keys": sorted(list(market.keys())),
    }, indent=2, sort_keys=True, ensure_ascii=False))
    save_state(state)
    log("Fetch/build test OK.")


def main():
    parser = argparse.ArgumentParser(description="BEE V4.1.4 Live Forecast Loop — paper mode + data simulation/golden tests")
    parser.add_argument("--once", action="store_true", help="Run one forecast iteration and exit")
    parser.add_argument("--loop", action="store_true", help="Run forever with check_interval_hours")
    parser.add_argument("--daemon", action="store_true", help="Alias for --loop")
    parser.add_argument("--test-ntfy", action="store_true", help="Send one dummy ntfy test and exit")
    parser.add_argument("--test-fetch", action="store_true", help="Fetch live data, build feature row, print result, then exit")
    parser.add_argument("--force-notify", action="store_true", help="Force notify even if no active signal; for testing only")
    parser.add_argument("--inspect-live-data", action="store_true", help="Fetch live data and print full validation/feature/decision inspection")
    parser.add_argument("--simulate-from-cache", action="store_true", help="Run decision again from last cached API payloads without new API calls")
    parser.add_argument("--simulate-scenario", choices=["panic", "neutral"], help="Override current row into a synthetic scenario to test model/ntfy behavior")
    parser.add_argument("--golden-row", help="Run decision on a historical row from bee_golden_rows.csv or BEE_GOLDEN_CSV for feature/core consistency")
    args = parser.parse_args()

    if not CONFIG_PATH.exists():
        log(f"Config not found: {CONFIG_PATH.name}. Copy bee_live_config.example.json to bee_live_config.json and fill ntfy/api settings.")
        if CONFIG_EXAMPLE_PATH.exists():
            log(f"Example config exists: {CONFIG_EXAMPLE_PATH}")
    cfg = load_config()
    state = load_state()
    log(f"Starting {VERSION}. Paper only={cfg.get('paper_only')} active={cfg.get('active_specialists')}")
    if args.inspect_live_data:
        inspect_live_data(cfg, state); return
    if args.simulate_from_cache:
        simulate_from_cache(cfg, state); return
    if args.simulate_scenario:
        simulate_scenario(cfg, state, args.simulate_scenario); return
    if args.golden_row:
        golden_row_test(cfg, state, args.golden_row); return
    if args.test_ntfy:
        test_ntfy(cfg); return
    if args.test_fetch:
        test_fetch(cfg, state); return
    if args.daemon:
        args.loop = True
    if args.once or not args.loop:
        run_once(cfg, state, force_notify=args.force_notify)
        return
    interval = max(1.0, float(cfg.get("check_interval_hours", 24))) * 3600.0
    while True:
        try:
            state = load_state()
            run_once(cfg, state)
        except KeyboardInterrupt:
            raise
        except Exception as e:
            log("LOOP ERROR: " + str(e))
            log(traceback.format_exc())
        log(f"Sleeping {interval/3600.0:.1f}h")
        time.sleep(interval)


if __name__ == "__main__":
    main()
