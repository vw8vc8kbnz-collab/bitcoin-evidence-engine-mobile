import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { eur } from "@/lib/types";
import { Mark } from "@/components/icons";
import { PromoteCreate } from "@/components/PromoteCreate";
import { inventoryPromotionCoach, promotionAdvice } from "@/lib/ai/brain";
import { getPartnerWallet } from "@/lib/data";
import { PromotionActions } from "@/components/PromotionActions";

export const dynamic = "force-dynamic";

export default async function Promoten() {
  const db = await read();
  const user = await getUser();
  const seller = db.sellers.find((s) => s.slug === user?.partnerSlug);
  const listings = db.listings
    .filter((l) => l.sellerSlug === user?.partnerSlug && l.status === "active")
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const campaigns = (db.promotionCampaigns ?? [])
    .filter((c) => c.sellerSlug === user?.partnerSlug)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const wallet = user?.partnerSlug ? await getPartnerWallet(user.partnerSlug) : null;
  const advice = listings[0]
    ? await promotionAdvice({ listing: listings[0], seller })
    : null;
  const coach = await inventoryPromotionCoach({ seller, listings });
  const active = campaigns.filter((c) => c.status === "active");
  const totalBudget = active.reduce((a, c) => a + c.budgetDaily, 0);
  const totalViews = campaigns.reduce((a, c) => a + c.impressions, 0);
  const totalClicks = campaigns.reduce((a, c) => a + c.clicks, 0);
  return (
    <main className="page partnerScreen promoteScreen promoteAIPage">
      <header className="hd">
        <Link href="/partner" className="lock" style={{ color: "#fff" }}>
          <Mark glow />
          Outrun <b>Promote</b>
        </Link>
        <span className="sp" />
        <span className="mini" style={{ color: "#8B96A0" }}>
          AI CAMPAGNES
        </span>
      </header>

      <section className="partnerHero promoteHero promoteHeroAI">
        <span className="eyebrow">OUTRUN PROMOTE AI</span>
        <h1>Laat AI je campagne ontwerpen.</h1>
        <p>
          Kies producten, doel en budget. Outrun maakt automatisch meerdere
          premium campagnevarianten en toont ze subtiel door de app heen waar ze
          relevant zijn.
        </p>
        <div className="promoteHeroStats">
          <span>
            <b>{eur((wallet?.summary.availableCents ?? 0) / 100)}</b>
            <small>beschikbaar</small>
          </span>
          <span>
            <b>{eur((wallet?.summary.reservedCents ?? 0) / 100)}</b>
            <small>gereserveerd</small>
          </span>
          <span>
            <b>{eur(totalBudget)}</b>
            <small>/dag actief</small>
          </span>
          <span>
            <b>{active.length}</b>
            <small>campagnes</small>
          </span>
          <span>
            <b>{totalViews}</b>
            <small>views</small>
          </span>
          <span>
            <b>{totalClicks}</b>
            <small>kliks</small>
          </span>
        </div>
      </section>

      <section className="walletCorePanel">
        <span className="eyebrow">FINANCIËN · PAYMENT ENGINE</span>
        <h2>Gebruik beschikbaar saldo direct voor campagnes.</h2>
        <p>Outrun toont saldo en campagnebudget via de Payment Engine. Stripe beheert later het echte geld; Outrun reserveert alleen campagnebudget via het grootboek.</p>
        <div className="walletMiniGrid"><span><b>{eur((wallet?.summary.availableCents ?? 0) / 100)}</b><small>beschikbaar</small></span><span><b>{eur((wallet?.summary.reservedCents ?? 0) / 100)}</b><small>campagnes gereserveerd</small></span></div>
      </section>

      {advice && (
        <article className="promoteAdvice promoteAdviceAI">
          <span className="eyebrow">PROMOTION AI ADVIES</span>
          <b>{advice.promote ? "Promoten is zinvol" : "Nog niet promoten"}</b>
          <p>{advice.reason}</p>
          <small>
            Advies: {eur(advice.budgetDaily)}/dag · verwacht +
            {advice.expectedViews} views · confidence {advice.confidence}% ·{" "}
            {advice.provider}
          </small>
        </article>
      )}

      <section className="promoteCoachPanel">
        <span className="eyebrow">PARTNER COACH AI · {coach.provider}</span>
        <h2>Jouw AI-marketeer</h2>
        <p>{coach.summary}</p>
        <div className="coachAdviceList">
          {coach.advice.slice(0, 3).map((a) => {
            const l = listings.find((x) => x.id === a.listingId);
            return (
              <article key={a.listingId}>
                <b>{l?.title ?? a.listingId}</b>
                <span>
                  {a.action === "promote"
                    ? "Promoten"
                    : a.action === "improve"
                      ? "Verbeteren"
                      : "Wachten"}{" "}
                  · {eur(a.budgetDaily)}/dag · conf. {a.confidence}%
                </span>
                <small>{a.reason}</small>
              </article>
            );
          })}
        </div>
      </section>

      <div className="dsec">
        <h2>Nieuwe AI-campagne</h2>
        <span>5 VARIANTEN</span>
      </div>
      <PromoteCreate
        listings={listings.map((l) => ({
          id: l.id,
          title: l.title,
          category: l.category,
        }))}
      />

      <section className="promoteHow">
        <article>
          <b>1. AI ontwerpt</b>
          <span>Copy, badge, CTA en kaartstijl.</span>
        </article>
        <article>
          <b>2. AI test</b>
          <span>Varianten krijgen voorspelde CTR.</span>
        </article>
        <article>
          <b>3. AI verdeelt</b>
          <span>Budget telt mee, relevantie wint.</span>
        </article>
      </section>

      <div className="dsec">
        <h2>Campagnes</h2>
        <span>{campaigns.length}</span>
      </div>
      <div className="inventoryList promoteCampaignList">
        {campaigns.length === 0 && (
          <p className="note">
            Nog geen campagnes. Start klein met €5–€10 per dag.
          </p>
        )}
        {campaigns.map((c) => {
          const selected =
            c.creativeVariants?.find((v) => v.id === c.selectedVariantId) ??
            c.creativeVariants?.[0];
          return (
            <article
              key={c.id}
              className="partnerItem promoteCampaign promoteCampaignAI"
            >
              <div className="partnerItemMain">
                <span className="promoGlyph">🚀</span>
                <span className="partnerItemText">
                  <b>{c.name}</b>
                  <span>
                    {c.kind.toUpperCase()} · {c.objective.replaceAll("_", " ")}{" "}
                    · {c.status.toUpperCase()}
                  </span>
                </span>
                <span className="partnerAmount">
                  {eur(c.budgetDaily)}/d
                  <i>
                    {c.impressions} views · {c.clicks} kliks
                  </i>
                </span>
              </div>
              {selected && (
                <div className="creativePreview">
                  <span>
                    <small>{selected.badge}</small>
                    <b>{selected.title}</b>
                    <em>{selected.subtitle}</em>
                  </span>
                  <i>
                    CTR {selected.predictedCtr}% · conf. {selected.confidence}%
                  </i>
                </div>
              )}
              {!!c.creativeVariants?.length && (
                <div className="creativeVariants">
                  {c.creativeVariants.map((v) => (
                    <span
                      key={v.id}
                      className={v.id === c.selectedVariantId ? "on" : ""}
                    >
                      {v.id.toUpperCase()} · {v.style.replaceAll("_", " ")}
                    </span>
                  ))}
                </div>
              )}
              <PromotionActions campaign={c} />
            </article>
          );
        })}
      </div>
    </main>
  );
}
