# Outrun IQ v8.4.0

Deze versie introduceert de Payment Engine: een toekomstbestendige betaalarchitectuur waarin Stripe Connect de eerste provider is, maar niet hard door de app verweven zit.

Belangrijk principe:

```text
Outrun UI / AI Brain / Marketplace
  → Wallet Engine
  → Payment Engine
  → Provider Adapter
  → Stripe / later Mollie / Adyen / Mangopay
```

Zie `docs/PAYMENT_ENGINE.md` voor de technische blauwdruk.
