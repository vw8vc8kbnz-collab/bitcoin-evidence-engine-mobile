# v8.4.0 Payment Engine & Provider Adapter Foundation

- Payment Engine toegevoegd als provider-onafhankelijke laag.
- Stripe Connect blijft de eerste echte provider, maar UI/business logic praat niet direct met Stripe.
- Test-provider blijft veilig voor pilot zonder echt geld.
- Provider-adapterstructuur voorbereid voor Mollie, Adyen en Mangopay.
- Partner Financiën-pagina herschreven: beschikbaar saldo, escrow, campagnebudgetten, providerstatus, AI financieel advies en grootboek.
- Nieuwe API: `/api/partner/finance`.
- Nieuwe beheerstatus API: `/api/admin/payments/status`.
- Documentatie toegevoegd: `docs/PAYMENT_ENGINE.md`.
- AI blijft advieslaag: geen zelfstandig geld verplaatsen.
