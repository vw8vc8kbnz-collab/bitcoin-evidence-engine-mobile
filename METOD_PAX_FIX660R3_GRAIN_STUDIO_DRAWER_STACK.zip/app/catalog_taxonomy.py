#!/usr/bin/env python3
"""Private taxonomy/enrichment layer for the CSV-only METOD/PAX material library.

FIX658 contract
---------------
The website CSV stays authoritative for *membership*, dimensions, thickness, image source
and gross sheet price.  This module may only add presentation metadata to records that
already exist in that CSV.  It never creates products and never changes commercial data.

A private article-number registry lets verified metadata survive later CSV publications.
Unknown/new products are classified only when a deterministic rule is strong enough;
otherwise they become REVIEW_REQUIRED instead of being guessed into a customer filter.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import unicodedata
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = 1
RULESET_VERSION = 'fix658-taxonomy-2026-08-08-v1'

FAMILIES = (
    'Hout', 'Uni', 'Steen & beton', 'Metaal', 'Textiel & leer',
    'Grafisch', 'Fantasie', 'Onbekend',
)
PUBLIC_FAMILIES = tuple(x for x in FAMILIES if x != 'Onbekend')
SUBSTRATES = ('MDF', 'SPAANPLAAT', 'MULTIPLEX', 'OVERIG', 'ONBEKEND')
SUBSTRATE_LABELS = {
    'MDF': 'MDF',
    'SPAANPLAAT': 'Spaanplaat',
    'MULTIPLEX': 'Multiplex',
    'OVERIG': 'Overig',
    'ONBEKEND': 'Onbekend',
}


def _plain(value: Any) -> str:
    text = unicodedata.normalize('NFKD', str(value or ''))
    text = ''.join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r'[^a-z0-9]+', ' ', text.lower()).strip()


def _norm_collection(value: Any) -> str:
    # Split the sales-name suffix *before* punctuation is normalized away.
    raw = str(value or '').split('/')[0]
    s = _plain(raw)
    for token in ('vochtwerend', 'fsc', 'mfc'):
        s = re.sub(rf'\b{token}\b', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def _first_matching_token(name: str, pattern: str) -> str:
    for raw in re.split(r'\s+', str(name or '')):
        token = re.sub(r'[^A-Za-z0-9]', '', raw).upper()
        if re.fullmatch(pattern, token):
            return token
    return ''


def extract_manufacturer_code(product_name: str, brand: str = '') -> str:
    """Extract a public manufacturer decor code, never the private article number."""
    name = str(product_name or '')
    b = str(brand or '').strip().lower()
    if b == 'decolegno':
        # Both "DecoLegno UB54 ..." and "DecoLegno MDF HM08 ..." occur.
        m = re.search(r'\bDECOLEGNO\s+(?:MDF\s+)?([A-Z]{1,3}\d{2,4})\b', name, re.I)
        return m.group(1).upper() if m else ''
    if b == 'unilin':
        # Ignore carrier/marketing tokens and take the first Evola-like code.
        skip = {'UNILIN','EVOLA','MDF','V313','SPAANPLAAT','SPAAN','MFC','BRANDVERTRAGEND'}
        for raw in re.split(r'\s+', name):
            tok = re.sub(r'[^A-Za-z0-9]', '', raw).upper()
            if not tok or tok in skip:
                continue
            if re.fullmatch(r'(?:0[A-Z]{1,2}\d{2,3}|[A-Z]{1,3}\d{2,3}|\d{3,5})', tok):
                return tok
        return ''
    return ''


def extract_collection(product_name: str, brand: str = '') -> str:
    name = str(product_name or '').strip()
    b = str(brand or '').strip().lower()
    if b == 'decolegno':
        m = re.search(r'^DecoLegno\s+(?:MDF\s+)?[A-Z]{1,3}\d{2,4}\s+(.+?)(?:\s+MFC)?$', name, re.I)
        if m:
            raw = re.sub(r'\b(?:FSC|MFC|Vochtwerend)\b', ' ', m.group(1), flags=re.I)
            return re.sub(r'\s+', ' ', raw).strip(' /')
    if b == 'unilin':
        return 'Evola'
    if b == 'shinnoki':
        return 'Shinnoki'
    return ''


def classification_fingerprint(record: dict[str, Any]) -> str:
    """Fingerprint only classification-relevant identity; price/size changes stay reusable."""
    name = str(record.get('productName') or record.get('publicName') or '')
    brand = str(record.get('brand') or '')
    code = extract_manufacturer_code(name, brand)
    collection = extract_collection(name, brand)
    # Product identity only: price, size and classifier version are intentionally excluded.
    # AUTO_VERIFIED entries are separately gated by taxonomyRulesetVersion so a ruleset
    # upgrade re-evaluates them; ADMIN VERIFIED overrides survive ruleset upgrades as long
    # as the actual product identity is unchanged.
    payload = '\x1f'.join((_plain(brand), _plain(name), _plain(code), _plain(collection)))
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()


# Official DecoLegno Look & Feel / collection rules verified against decolegno.nl.
# Mixed collections are handled by code-specific rules below rather than by secondary tags.
_DECO_COLLECTION_FAMILY = {
    'alpaca': 'Textiel & leer',
    'ametis': 'Textiel & leer',
    'alter': 'Hout',
    'ares': 'Steen & beton',
    'bruciato': 'Hout',
    'ceppo': 'Hout',
    'cheope': 'Grafisch',
    'concreta': 'Steen & beton',
    'corteccia': 'Hout',
    'decobasic': 'Uni',
    'doga': 'Hout',
    'esperia': 'Hout',
    'frassino': 'Hout',
    'fusion': 'Textiel & leer',
    'fronda': 'Hout',
    'idea': 'Metaal',
    'italianstone': 'Steen & beton',
    'jiometori': 'Grafisch',
    'matrice': 'Hout',
    'matrix': 'Hout',
    'metallic': 'Metaal',
    'millenium': 'Hout',
    'mosaico': 'Textiel & leer',
    'nadir': 'Textiel & leer',
    'okobo': 'Hout',
    'ovatta': 'Uni',
    'paglia': 'Metaal',
    'pembroke': 'Hout',
    'penelope': 'Textiel & leer',
    'piombo': 'Uni',
    'poro noce': 'Hout',
    'primofiore': 'Textiel & leer',
    'quercia': 'Hout',
    'reflex': 'Textiel & leer',
    'sable': 'Hout',
    'sbalzo': 'Grafisch',
    'sherwood': 'Hout',
    'spessart': 'Hout',
    'tivoli': 'Hout',
    'toucher': 'Metaal',
    'tranche': 'Hout',
    'yosemite': 'Hout',
}

# Current official Unilin Evola families.  0U/0UD and 0W codes are solid/uni ranges;
# 0H is wood.  0F is "other materials" and therefore needs explicit decor semantics.
_UNILIN_STONE_CODES = {
    '0F252','0F253','0F254','0F255','0F256','0F257','0F258','0F259','0F260','0F261','0F264',
    '0F976','0F985','0F989',
}
_UNILIN_TEXTILE_CODES = {'0F599','0F600','0F601','0F602','0F981'}
_UNILIN_METAL_CODES = {'0F987','0F992','0F993','0F994','760'}
_UNILIN_UNI_CODES = {'00025','00113','00551','00625','0F589'}
_UNILIN_WOOD_CODES = {'747','766'}


def _substrate_for(record: dict[str, Any], brand: str, name_plain: str) -> tuple[str, str, float]:
    """Return substrate enum, source, confidence."""
    if re.search(r'\bmdf\b', name_plain):
        return 'MDF', 'EXPLICIT_PRODUCT_NAME', 1.0
    if 'multiplex' in name_plain or name_plain.startswith('gefineerd berken '):
        return 'MULTIPLEX', 'EXPLICIT_PRODUCT_NAME', 0.99
    if re.search(r'\b(?:mfc|spaanplaat|spaan)\b', name_plain):
        return 'SPAANPLAAT', 'EXPLICIT_PRODUCT_NAME', 1.0
    if brand == 'DecoLegno':
        # The active 18 mm Cleaf decorative range is decorspaanplaat except the Piombo MDF
        # range, whose names explicitly contain MDF and are caught above.
        return 'SPAANPLAAT', 'OFFICIAL_DECOLEGNO_TYPE_RULE', 0.99
    if brand == 'Unilin':
        # Active Evola decorative boards without an MDF marker are melamine-faced chipboard.
        return 'SPAANPLAAT', 'OFFICIAL_UNILIN_CARRIER_RULE', 0.98
    if brand == 'Shinnoki':
        # Current Shinnoki rows explicitly say MDF; this only guards future naming drift.
        return 'MDF', 'SHINNOKI_RANGE_RULE', 0.97
    return 'ONBEKEND', 'NO_SAFE_SUBSTRATE_RULE', 0.0


def _deco_family(code: str, collection: str) -> tuple[str, str, float]:
    c = _norm_collection(collection)
    # Mixed official collections: one exact primary family per decor.
    if c == 'maloja':
        return ('Steen & beton' if code == 'FB11' else 'Hout', 'OFFICIAL_DECOLEGNO_MALOJA', 1.0)
    if c == 'talco':
        return ('Steen & beton' if code.startswith(('FB','FC')) else 'Uni', 'OFFICIAL_DECOLEGNO_TALCO', 1.0)
    if c == 'taranta':
        return ('Metaal' if code in {'FD36','FD37','FD38','FD49'} else 'Steen & beton', 'OFFICIAL_DECOLEGNO_TARANTA', 1.0)
    if c == 'traccia':
        if code in {'FD36','FD37','FD38','FD49'}:
            fam = 'Metaal'
        elif code == 'LS69':
            fam = 'Hout'
        elif code == 'UA94':
            fam = 'Uni'
        elif code == 'UB20':
            fam = 'Grafisch'
        else:
            return 'Onbekend', 'MIXED_COLLECTION_UNKNOWN_CODE', 0.0
        return fam, 'OFFICIAL_DECOLEGNO_TRACCIA', 1.0
    if c == 'riga':
        if code.startswith(('LR','LS')):
            return 'Hout', 'OFFICIAL_DECOLEGNO_RIGA', 1.0
        if code == 'UB20':
            return 'Grafisch', 'OFFICIAL_DECOLEGNO_RIGA', 1.0
        return 'Onbekend', 'MIXED_COLLECTION_UNKNOWN_CODE', 0.0
    fam = _DECO_COLLECTION_FAMILY.get(c)
    if fam:
        return fam, 'OFFICIAL_DECOLEGNO_COLLECTION', 0.99
    return 'Onbekend', 'UNKNOWN_DECOLEGNO_COLLECTION', 0.0


def _unilin_family(code: str, name_plain: str) -> tuple[str, str, float]:
    if code.startswith('0H'):
        return 'Hout', 'OFFICIAL_UNILIN_CODE_FAMILY', 1.0
    if code.startswith(('0U','0UD','0WA','0WE','CWE')) or code == 'U129':
        return 'Uni', 'OFFICIAL_UNILIN_CODE_FAMILY', 1.0
    if code in _UNILIN_UNI_CODES:
        return 'Uni', 'OFFICIAL_UNILIN_DECOR_RULE', 1.0
    if code in _UNILIN_WOOD_CODES:
        return 'Hout', 'OFFICIAL_UNILIN_DECOR_RULE', 1.0
    if code in _UNILIN_STONE_CODES:
        return 'Steen & beton', 'OFFICIAL_UNILIN_DECOR_RULE', 1.0
    if code in _UNILIN_TEXTILE_CODES:
        return 'Textiel & leer', 'OFFICIAL_UNILIN_DECOR_RULE', 1.0
    if code in _UNILIN_METAL_CODES:
        return 'Metaal', 'OFFICIAL_UNILIN_DECOR_RULE', 1.0
    # Conservative semantic fallback for a *new* Unilin decor. It may auto-verify only
    # when the product name itself is unambiguous; otherwise Admin review is required.
    if code.startswith('0F'):
        if re.search(r'\b(?:concrete|beton|stone|steen|marble|marmer|travertin|lime|cement)\b', name_plain):
            return 'Steen & beton', 'EXPLICIT_UNILIN_PRODUCT_NAME', 0.97
        if re.search(r'\b(?:woven|weave|linen|linnen|fabric|textile|wool)\b', name_plain):
            return 'Textiel & leer', 'EXPLICIT_UNILIN_PRODUCT_NAME', 0.97
        if re.search(r'\b(?:brushed|metallic|metal|aluminium|aluminum|bronze|steel|gold)\b', name_plain):
            return 'Metaal', 'EXPLICIT_UNILIN_PRODUCT_NAME', 0.97
    return 'Onbekend', 'UNKNOWN_UNILIN_DECOR', 0.0


def _generic_family(name_plain: str) -> tuple[str, str, float]:
    # Ordered from strongest construction/product phrases to weaker visuals.
    if 'grondeerfolie' in name_plain:
        return 'Uni', 'EXPLICIT_PRODUCT_NAME', 1.0
    if re.search(r'\b(?:gefineerd|fineer|veneer)\b', name_plain):
        return 'Hout', 'EXPLICIT_PRODUCT_NAME', 1.0
    wood = r'\b(?:oak|eiken|eik|walnut|noten|beuken|beech|essen|ash|grenen|pine|teak|wenge|zebrano|bamboe|bamboo|kersen|cherry|mahonie|sapele|eucalyptus|esdoorn|maple|acacia|iepen|elm|afrormosia)\b'
    stone = r'\b(?:steen|stone|beton|concrete|marmer|marble|graniet|granite|travertin|terrazzo|cement)\b'
    metal = r'\b(?:metaal|metal|metallic|aluminium|aluminum|staal|steel|koper|copper|brons|bronze)\b'
    textile = r'\b(?:textiel|textile|stof|fabric|woven|linnen|linen|leer|leather)\b'
    if re.search(wood, name_plain): return 'Hout', 'EXPLICIT_PRODUCT_NAME', 0.98
    if re.search(stone, name_plain): return 'Steen & beton', 'EXPLICIT_PRODUCT_NAME', 0.98
    if re.search(metal, name_plain): return 'Metaal', 'EXPLICIT_PRODUCT_NAME', 0.98
    if re.search(textile, name_plain): return 'Textiel & leer', 'EXPLICIT_PRODUCT_NAME', 0.98
    if re.search(r'\b(?:uni|effen|solid|wit|white|zwart|black)\b', name_plain):
        return 'Uni', 'EXPLICIT_PRODUCT_NAME', 0.95
    return 'Onbekend', 'NO_SAFE_FAMILY_RULE', 0.0


def classify_taxonomy(record: dict[str, Any]) -> dict[str, Any]:
    name = str(record.get('productName') or record.get('publicName') or '').strip()
    brand = str(record.get('brand') or '').strip()
    name_plain = _plain(name)
    code = extract_manufacturer_code(name, brand)
    collection = extract_collection(name, brand)

    substrate, substrate_source, substrate_conf = _substrate_for(record, brand, name_plain)
    if brand == 'DecoLegno':
        family, family_source, family_conf = _deco_family(code, collection)
    elif brand == 'Unilin':
        family, family_source, family_conf = _unilin_family(code, name_plain)
    elif brand == 'Shinnoki':
        family, family_source, family_conf = 'Hout', 'SHINNOKI_RANGE_RULE', 1.0
    else:
        family, family_source, family_conf = _generic_family(name_plain)

    confidence = min(family_conf, substrate_conf)
    status = 'AUTO_VERIFIED' if family in PUBLIC_FAMILIES and substrate != 'ONBEKEND' and confidence >= 0.95 else 'REVIEW_REQUIRED'
    source = family_source if family_source == substrate_source else f'{family_source}+{substrate_source}'
    return {
        'primaryVisualFamily': family,
        'visualFamily': family,
        'visualTags': [family] if family in PUBLIC_FAMILIES else [],
        'substrateType': substrate,
        'substrateLabel': SUBSTRATE_LABELS.get(substrate, 'Onbekend'),
        'manufacturerCode': code,
        'collection': collection,
        'taxonomyStatus': status,
        'taxonomySource': source,
        'taxonomyConfidence': round(float(confidence), 4),
        'taxonomyRulesetVersion': RULESET_VERSION,
        'classificationFingerprint': classification_fingerprint(record),
    }


def _clean_registry_entry(entry: Any) -> dict[str, Any] | None:
    if not isinstance(entry, dict):
        return None
    family = str(entry.get('primaryVisualFamily') or '')
    substrate = str(entry.get('substrateType') or '')
    fp = str(entry.get('classificationFingerprint') or '')
    if family not in FAMILIES or substrate not in SUBSTRATES or not re.fullmatch(r'[a-f0-9]{64}', fp):
        return None
    out = dict(entry)
    out['visualFamily'] = family
    out['visualTags'] = [family] if family in PUBLIC_FAMILIES else []
    out['substrateLabel'] = SUBSTRATE_LABELS.get(substrate, 'Onbekend')
    manual_family = str(out.get('taxonomyManualFamilyOverride') or '').strip()
    if manual_family in PUBLIC_FAMILIES:
        out['taxonomyManualFamilyOverride'] = manual_family
    else:
        out.pop('taxonomyManualFamilyOverride', None)
    return out


def load_registry(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    try:
        obj = json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
    except Exception:
        obj = {}
    values = obj.get('byArticle') if isinstance(obj, dict) and isinstance(obj.get('byArticle'), dict) else {}
    by_article: dict[str, dict[str, Any]] = {}
    for article, entry in values.items():
        clean = _clean_registry_entry(entry)
        if str(article).strip() and clean:
            by_article[str(article).strip()] = clean
    return {'schemaVersion': SCHEMA_VERSION, 'rulesetVersion': RULESET_VERSION, 'byArticle': by_article}


def save_registry(path: str | Path, registry: dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    by_article = registry.get('byArticle') if isinstance(registry, dict) and isinstance(registry.get('byArticle'), dict) else {}
    clean: dict[str, dict[str, Any]] = {}
    for article, entry in by_article.items():
        normalized = _clean_registry_entry(entry)
        if str(article).strip() and normalized:
            clean[str(article).strip()] = normalized
    payload = {'schemaVersion': SCHEMA_VERSION, 'rulesetVersion': RULESET_VERSION, 'byArticle': dict(sorted(clean.items()))}
    tmp = p.with_name(p.name + f'.tmp.{os.getpid()}')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, p)


def enrich_catalog_records(records: Iterable[dict[str, Any]], registry: dict[str, Any] | None = None) -> tuple[list[dict[str, Any]], dict[str, Any], list[dict[str, Any]]]:
    reg = registry if isinstance(registry, dict) else {'byArticle': {}}
    by_article = reg.get('byArticle') if isinstance(reg.get('byArticle'), dict) else {}
    enriched: list[dict[str, Any]] = []
    review: list[dict[str, Any]] = []
    counts = {'total': 0, 'reused': 0, 'autoVerified': 0, 'adminVerified': 0, 'reviewRequired': 0}

    for source in records or []:
        if not isinstance(source, dict):
            continue
        rec = dict(source)
        article = str(rec.get('articleNo') or '').strip()
        fp = classification_fingerprint(rec)
        previous = _clean_registry_entry(by_article.get(article)) if article else None
        previous_status = str(previous.get('taxonomyStatus') or '') if previous else ''
        previous_ruleset = str(previous.get('taxonomyRulesetVersion') or '') if previous else ''
        can_reuse = bool(
            previous
            and previous.get('classificationFingerprint') == fp
            and (
                previous_status == 'VERIFIED'
                or (previous_status == 'AUTO_VERIFIED' and previous_ruleset == RULESET_VERSION)
            )
        )
        if can_reuse:
            tax = dict(previous)
            tax['taxonomyRegistryReused'] = True
            counts['reused'] += 1
            if previous_status == 'VERIFIED': counts['adminVerified'] += 1
            else: counts['autoVerified'] += 1
        else:
            tax = classify_taxonomy(rec)
            tax['taxonomyRegistryReused'] = False
            if tax['taxonomyStatus'] == 'AUTO_VERIFIED': counts['autoVerified'] += 1
        # Taxonomy is additive only. Never touch CSV truth fields here.
        for key in (
            'primaryVisualFamily','visualFamily','visualTags','substrateType','substrateLabel',
            'manufacturerCode','collection','taxonomyStatus','taxonomySource','taxonomyConfidence',
            'taxonomyRulesetVersion','classificationFingerprint','taxonomyRegistryReused','taxonomyManualFamilyOverride',
        ):
            rec[key] = tax.get(key)
        if rec.get('taxonomyStatus') == 'REVIEW_REQUIRED':
            counts['reviewRequired'] += 1
            review.append({
                'articleNo': article,
                'productName': str(rec.get('productName') or ''),
                'brand': str(rec.get('brand') or ''),
                'manufacturerCode': str(rec.get('manufacturerCode') or ''),
                'collection': str(rec.get('collection') or ''),
                'suggestedFamily': str(rec.get('primaryVisualFamily') or 'Onbekend'),
                'suggestedSubstrate': str(rec.get('substrateType') or 'ONBEKEND'),
                'reason': str(rec.get('taxonomySource') or 'Geen veilige classificatieregel.'),
            })
        enriched.append(rec)
        counts['total'] += 1

    counts['verified'] = counts['total'] - counts['reviewRequired']
    counts['complete'] = counts['reviewRequired'] == 0 and counts['total'] > 0
    return enriched, counts, review


def taxonomy_summary(records: Iterable[dict[str, Any]]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    counts = {'total': 0, 'reused': 0, 'autoVerified': 0, 'adminVerified': 0, 'reviewRequired': 0}
    review: list[dict[str, Any]] = []
    for rec in records or []:
        if not isinstance(rec, dict):
            continue
        counts['total'] += 1
        status = str(rec.get('taxonomyStatus') or '')
        if rec.get('taxonomyRegistryReused'):
            counts['reused'] += 1
        if status == 'VERIFIED':
            counts['adminVerified'] += 1
        elif status == 'AUTO_VERIFIED':
            counts['autoVerified'] += 1
        else:
            counts['reviewRequired'] += 1
            review.append({
                'articleNo': str(rec.get('articleNo') or ''),
                'productName': str(rec.get('productName') or ''),
                'brand': str(rec.get('brand') or ''),
                'manufacturerCode': str(rec.get('manufacturerCode') or ''),
                'collection': str(rec.get('collection') or ''),
                'suggestedFamily': str(rec.get('primaryVisualFamily') or 'Onbekend'),
                'suggestedSubstrate': str(rec.get('substrateType') or 'ONBEKEND'),
                'reason': str(rec.get('taxonomySource') or 'Geen veilige classificatieregel.'),
            })
    counts['verified'] = counts['total'] - counts['reviewRequired']
    counts['complete'] = counts['reviewRequired'] == 0 and counts['total'] > 0
    return counts, review


def apply_admin_override(record: dict[str, Any], family: str, substrate: str) -> dict[str, Any]:
    fam = str(family or '').strip()
    sub = str(substrate or '').strip().upper()
    if fam not in PUBLIC_FAMILIES:
        raise ValueError('Ongeldige primaire decorfamilie.')
    if sub not in {'MDF','SPAANPLAAT','MULTIPLEX','OVERIG'}:
        raise ValueError('Ongeldig dragermateriaal.')
    rec = dict(record)
    rec.update({
        'primaryVisualFamily': fam,
        'visualFamily': fam,
        'visualTags': [fam],
        'substrateType': sub,
        'substrateLabel': SUBSTRATE_LABELS[sub],
        'taxonomyStatus': 'VERIFIED',
        'taxonomySource': 'ADMIN_VERIFIED_OVERRIDE',
        'taxonomyConfidence': 1.0,
        'taxonomyRulesetVersion': RULESET_VERSION,
        'classificationFingerprint': classification_fingerprint(rec),
        'taxonomyRegistryReused': False,
    })
    return rec


def apply_admin_family_override(record: dict[str, Any], family: str) -> dict[str, Any]:
    """Override only the public filter family; never alter CSV truth or substrate.

    The override is persisted in the private taxonomy registry and survives future CSV
    imports while the product classification fingerprint remains the same.
    """
    fam = str(family or '').strip()
    if fam not in PUBLIC_FAMILIES:
        raise ValueError('Ongeldige primaire decorfamilie.')
    rec = dict(record)
    sub = str(rec.get('substrateType') or '').strip().upper()
    if sub not in SUBSTRATES or sub == 'ONBEKEND':
        raise ValueError('Dragermateriaal is niet veilig vastgesteld; controleer eerst de classificatie.')
    rec.update({
        'primaryVisualFamily': fam,
        'visualFamily': fam,
        'visualTags': [fam],
        'decorType': fam,
        'taxonomyStatus': 'VERIFIED',
        'taxonomySource': 'ADMIN_VERIFIED_FAMILY_OVERRIDE',
        'taxonomyConfidence': 1.0,
        'taxonomyRulesetVersion': RULESET_VERSION,
        'classificationFingerprint': classification_fingerprint(rec),
        'taxonomyRegistryReused': False,
        'taxonomyManualFamilyOverride': fam,
    })
    return rec


def clear_admin_family_override(record: dict[str, Any]) -> dict[str, Any]:
    """Return the filter family to the deterministic classifier without touching substrate.

    Reset is refused when the automatic classifier cannot safely determine a public
    family. That prevents an active product from silently becoming 'Onbekend'.
    """
    rec = dict(record)
    automatic = classify_taxonomy(rec)
    fam = str(automatic.get('primaryVisualFamily') or '').strip()
    if fam not in PUBLIC_FAMILIES:
        raise ValueError('Automatische classificatie is voor dit product niet eenduidig; kies handmatig een filtercategorie.')
    sub = str(rec.get('substrateType') or '').strip().upper()
    if sub not in SUBSTRATES or sub == 'ONBEKEND':
        raise ValueError('Dragermateriaal is niet veilig vastgesteld; automatische reset is niet mogelijk.')

    # Preserve the already-verified substrate. Only the family is reset.
    rec.update({
        'primaryVisualFamily': fam,
        'visualFamily': fam,
        'visualTags': [fam],
        'decorType': fam,
        'taxonomyStatus': 'AUTO_VERIFIED',
        'taxonomySource': str(automatic.get('taxonomySource') or 'AUTO_CLASSIFIER'),
        'taxonomyConfidence': float(automatic.get('taxonomyConfidence') or 0.0),
        'taxonomyRulesetVersion': RULESET_VERSION,
        'classificationFingerprint': classification_fingerprint(rec),
        'taxonomyRegistryReused': False,
    })
    rec.pop('taxonomyManualFamilyOverride', None)
    return rec


def registry_with_records(registry: dict[str, Any] | None, records: Iterable[dict[str, Any]]) -> dict[str, Any]:
    out = load_registry('/__definitely_missing__')
    if isinstance(registry, dict) and isinstance(registry.get('byArticle'), dict):
        out['byArticle'].update(registry['byArticle'])
    for rec in records or []:
        if not isinstance(rec, dict): continue
        article = str(rec.get('articleNo') or '').strip()
        if not article: continue
        entry = {k: rec.get(k) for k in (
            'primaryVisualFamily','substrateType','substrateLabel','manufacturerCode','collection',
            'taxonomyStatus','taxonomySource','taxonomyConfidence','taxonomyRulesetVersion','classificationFingerprint',
            'taxonomyManualFamilyOverride',
        )}
        if entry.get('taxonomyStatus') in {'VERIFIED','AUTO_VERIFIED'}:
            out['byArticle'][article] = entry
    return out
