#!/usr/bin/env python3
"""Backfill FIX658 taxonomy into an existing CSV-only live material library.

No catalog membership, opaque ID, image source, sheet dimension, thickness or price field
may change.  The tool fails closed when any active record cannot be classified safely.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app'
if str(APP) not in sys.path:
    sys.path.insert(0, str(APP))

from catalog_taxonomy import RULESET_VERSION, enrich_catalog_records, load_registry, registry_with_records, save_registry

PROTECTED_FIELDS = (
    'articleNo','materialCode','productName','decorName','publicName','publicMaterialId',
    'thicknessMm','sheetLen','sheetWid','sellPriceInclVatPerSheet','sellPriceExVatPerSheet',
    'priceVatRate','priceSource','imageSourceUrls','imageSourceUrl','dimensionSource','catalogSource',
    'active','published','archived','sourceKind',
)


def atomic_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f'.tmp.{os.getpid()}')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--library', default=str(APP / 'material_library.json'))
    ap.add_argument('--registry', default=str(APP / 'system' / 'catalog_taxonomy_registry.json'))
    args = ap.parse_args()
    library = Path(args.library)
    registry_path = Path(args.registry)
    obj = json.loads(library.read_text(encoding='utf-8'))
    if obj.get('source') != 'CSV_CATALOG_ONLY':
        raise SystemExit('FIX658 backfill weigert: material_library.json is niet CSV_CATALOG_ONLY.')
    records = obj.get('records')
    if not isinstance(records, list):
        raise SystemExit('FIX658 backfill weigert: records ontbreekt.')
    originals = [copy.deepcopy(r) for r in records]
    registry = load_registry(registry_path)
    enriched, summary, review = enrich_catalog_records(records, registry)
    if review:
        names = ', '.join(str(x.get('productName') or x.get('articleNo') or '')[:70] for x in review[:8])
        raise SystemExit(f'FIX658 backfill geblokkeerd: {len(review)} product(en) vereisen classificatiecontrole: {names}')
    if len(enriched) != len(originals):
        raise SystemExit('FIX658 backfill veranderde onverwacht het aantal records.')
    for before, after in zip(originals, enriched):
        for field in PROTECTED_FIELDS:
            if before.get(field) != after.get(field):
                raise SystemExit(f'FIX658 backfill probeerde beschermd veld {field!r} te wijzigen voor {before.get("productName")!r}.')
        after['decorType'] = after.get('primaryVisualFamily') or after.get('visualFamily') or 'Onbekend'
        after['visualFamily'] = after['decorType']
        after['visualTags'] = [after['decorType']]
    obj['records'] = enriched
    obj['decorLibrarySchemaVersion'] = max(4, int(obj.get('decorLibrarySchemaVersion') or 0))
    li = obj.get('lastCatalogImport') if isinstance(obj.get('lastCatalogImport'), dict) else {}
    li = dict(li)
    li['taxonomyVerified'] = int(summary.get('verified') or 0)
    li['taxonomyReviewRequired'] = int(summary.get('reviewRequired') or 0)
    li['taxonomyRulesetVersion'] = RULESET_VERSION
    obj['lastCatalogImport'] = li
    new_registry = registry_with_records(registry, enriched)
    # Registry first is safe: orphan private metadata never activates a public product.
    save_registry(registry_path, new_registry)
    atomic_json(library, obj)
    print(json.dumps({'ok': True, 'records': len(enriched), 'taxonomy': summary}, ensure_ascii=False))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
