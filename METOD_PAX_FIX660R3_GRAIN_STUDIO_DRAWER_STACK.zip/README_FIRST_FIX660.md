# METOD/PAX Tool A — FIX660 GRAIN STUDIO

Datum: 2026-08-12
Baseline: FIX659R2_MOBILE_POLISH_SMART_QTY
Nieuwe build: FIX660_GRAIN_STUDIO

## Doel
FIX660 vernieuwt uitsluitend de Doorlopende Nerf UX/renderlaag. De bestaande productie-, prijs-, library-, optimizer-, submit- en securitycontracten blijven behouden.

## Belangrijkste wijzigingen
- Mobile nerf-preview is een onafhankelijke bottom drawer met sleep/tap-handle.
- Invoer blijft tile-based maar toont echte mm-afmetingen, positie en true-aspect miniatuur.
- Panelen in een groep zijn via touch drag-and-drop te herschikken.
- Preview gebruikt echte paneelverhoudingen met één uniforme mm->px schaal voor de hele groep.
- Een 597x97 lade blijft dus werkelijk veel lager dan een 597x1997 deur.
- Preview toont dezelfde DXF-boringen en arcs als Stap 2, inclusief scharnier-mirroring en adaptief 1px CNC-contrast.
- Preview toont het daadwerkelijk toegewezen materiaal via de FIX659 swatch-renderer.
- Kleine panelen worden nooit kunstmatig groter gemaakt; maatlabels zitten in een aparte collision-safe rail.
- Nerfgroepbreedte wordt hard gevalideerd op de echte widthMm, niet op nominale cm-labels.
- 597 mm en 596 mm kunnen niet in dezelfde groep. Alle panelen in een nerfgroep moeten exact dezelfde werkelijke breedte hebben.
- Nieuwe nerfgroepen krijgen altijd een uniek Gxx-id, ook nadat eerder een groep is verwijderd.

## Mobile flow
De invoer blijft het hoofdscherm. Onderaan staat de ingeklapte preview-drawer. Trek/tik de handle omhoog om de actieve nerfgroep groot te bekijken. Annuleren/Toepassen blijven altijd bereikbaar in de vaste onderste actiebalk.

## Niet gewijzigd
- Publieke URL: http://51.195.102.180:8790/
- Admin: http://51.195.102.180:8790/admin/
- Nginx :8790 -> Python 127.0.0.1:8792
- mixed-VAT v2 / CSV-plaatprijs reeds incl. BTW
- CSV-only Decor Library + taxonomy/handmatige filteroverride
- optimizer/nesting
- finalization/submit-idempotency
- Bearer token/SSE/securitycontracten

## Deploymentveiligheid
De installer accepteert bij een bestaande installatie alleen exact FIX659R2 als live baseline. Preflight, regressies, backup en state-preserving switch gebeuren vóór/om de live omschakeling; bij mislukking volgt automatische rollback.
