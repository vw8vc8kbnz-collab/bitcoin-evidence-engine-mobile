# METOD/PAX FIX660R3 — Mobile Grain Drawer + Bottom-Up Stack

FIX660R3 is de gecorrigeerde Grain Studio release bovenop de bestaande FIX660 applicatielogica.

## Waarom R3
Op sommige iPhone/mobile viewports schakelde de bestaande nerfinterface al naar de mobiele layout (`<=900px`), terwijl de nieuwe bottom-drawer controller alleen activeerde op `<=700px`. Daardoor bleef de previewkaart inline staan en verscheen de slider niet.

R3 maakt deze grens één waarheid (`<=900px`) en initialiseert de drawer opnieuw wanneer de nerfoverlay wordt geopend. De drawerhandle staat daarnaast statisch in de HTML en de mobiele CSS positioneert de previewkaart rechtstreeks als fixed bottom drawer, zodat de oude inline fallback niet meer stil kan terugkeren.

## Definitieve stacklogica
`grain.items` / `grainOrder` is semantisch **onder naar boven**:
- eerste toegevoegd paneel = positie 1 = onderaan;
- tweede toegevoegd paneel = positie 2 = erboven;
- ieder volgend paneel stapelt verder omhoog.

DOM/canvas tekenen fysiek van boven naar beneden. Daarom wordt alleen de visuele projectie omgedraaid. Touch drag-to-reorder vertaalt de fysieke schermvolgorde terug naar de autoritatieve bottom-to-top volgorde voordat `grainOrder` wordt gesynchroniseerd.

## Niet gewijzigd
- prijs/mixed-VAT v2;
- CSV-only library/taxonomy;
- optimizer;
- finalization/submit-idempotency;
- security/SSE/Bearer-tokencontract;
- publieke URL `http://51.195.102.180:8790/`;
- harde exact-`widthMm` nerfgroepvalidatie.
