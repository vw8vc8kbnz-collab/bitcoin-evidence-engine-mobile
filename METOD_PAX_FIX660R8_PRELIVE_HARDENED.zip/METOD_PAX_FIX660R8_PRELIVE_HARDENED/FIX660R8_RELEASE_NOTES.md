# FIX660R8 release notes

Datum: 12 augustus 2026  
Build: `FIX660R8_PRELIVE_HARDENED`  
Basis: FIX660R7 pre-live audit

## Productie- en prijsintegriteit

- De publieke jobpayload wordt server-side opnieuw opgebouwd uit opaque materiaal-ID, actieve catalogus, live pricing en de ingebedde DXF-library.
- Paneelvelden zijn strict finite; aantallen, kantenbandcodes, nerfposities, dikte en plaatmaat hebben vaste contracten.
- DXF/CSV-bboxafwijking, onbekende machining, overlap, buiten-plaatgeometrie en exportfouten zijn fatal.
- ARC-hoeken roteren correct op 0/90/180/270 graden.
- Nerfpositie 1 is fysiek de onderste positie en ongelijke groepsbreedtes worden geweigerd.
- Clientpricing en clientgekozen productiepolicy hebben geen autoriteit meer.
- Finalisatie bindt input, optimizeroutputs, exacte identities/counts en alle downloadbare artifacts aan SHA-256.
- Status, submit en Admin-download falen gesloten bij ontbrekende of gemanipuleerde finalisatie.

## Security en privacy

- Job- en request-ID's gebruiken een strict allowlistcontract met vaste-root containment.
- Public quote-output is minimaal; productie-, prijs- en materiaalinterne data blijven Admin-only.
- Admin gebruikt in productie individuele accounts, TOTP MFA, HttpOnly sessiecookies, idle/absolute TTL, logout/revocation en server-derived actorlogging.
- Basic auth is in productie uitgeschakeld; login voert dummy PBKDF2/TOTP uit voor onbekende gebruikers.
- CSP gebruikt nonces en statische/DXF-responses gebruiken een beperkte allowlist en `nosniff`.
- Nginx normaliseert client-IP en begrenst jobs, login, SSE, requests en connecties.
- Staging bindt standaard alleen aan loopback; een remote bind vereist een expliciete CIDR-allowlist.
- Clientlogs zijn klein, geratelimit, geredigeerd, roterend en vereisen een jobtoken wanneer een job wordt genoemd.
- Catalogusafbeeldingen valideren DNS één keer en verbinden via het gepinde publieke IP met TLS-SNI/certificaatcontrole op de originele host.

## State, deploy en herstel

- Mutable state staat buiten de immutable release onder `/var/lib/metod-pax`.
- Migratie gebeurt naar een sibling stagingmap en wordt atomisch gepubliceerd na durable markerwrite.
- Releases zijn immutable; de current-symlink wordt atomisch gewisseld.
- Maintenance/drain voorkomt gemengde assets en verlies van deploy-windowdata.
- Rollback wijzigt code/config, nooit live state.
- Backups omvatten de volledige noodzakelijke state, gebruiken een schema-2 manifest met size/SHA-256 per bestand en worden na creatie byte-voor-byte herverifieerd.
- Restore weigert traversal, symlinks, extra/dubbele leden, hashverschillen en bestaande targets; publicatie gebeurt pas na een tweede hashcontrole.
- Kritieke writes gebruiken durable temp-write/replace/fsync; JSONL-logs hebben cross-process locking en rotatie.

## Catalogus en operations

- Cataloguspreview geeft een reviewhash over CSV, warnings, exclusions, errors, samenvatting, taxonomie en genormaliseerde records.
- Publicatie vereist dezelfde reviewhash en maakt een signoff die aan de actieve libraryhash is gebonden.
- Readiness controleert catalogus, signoff, pricing, schrijfbaarheid, vrije bytes/inodes, DXF-library en restore/offsite-evidence in productie.
- Runtimecontract, stdlib-only requirements, CycloneDX-SBOM, reproduceerbare artifactbuilder en CI releasegate zijn toegevoegd.

## Bewuste incompatibiliteiten

- De auth-loze StickerTool-route is 410 Gone.
- Per materiaaljob bestaat nog maar één authoritative `output/stickertool.json`; oude `stickers.json`-spiegels zijn verwijderd.
- Admin kan uitsluitend files downloaden die in een geldige finalization-hashlijst staan. Oude debuglogs en inputbestanden zijn niet meer via outputknoppen bereikbaar.
- Legacy queue-items worden niet opnieuw geoptimaliseerd; onveilig hervatwerk gaat naar handmatige controle.

## Geen productiecertificaat

Deze build is een pre-live candidate. De resterende externe gates staan in `GO_LIVE_GATES_FIX660R8.md` en kunnen niet met alleen broncode worden afgetekend.
