from __future__ import annotations

"""Shared fail-closed safety primitives for METOD/PAX FIX660R8.

This module intentionally has no third-party dependencies.  It is imported by both
the HTTP service and the optimizer so the same rules apply at every trust boundary.
"""

import hashlib
import json
import math
import os
import re
import secrets
import shutil
import threading
from pathlib import Path
from typing import Any, Iterable, Optional

try:  # POSIX production hosts
    import fcntl  # type: ignore
except Exception:  # pragma: no cover - Windows development fallback
    fcntl = None


class ContractError(ValueError):
    """Raised when untrusted data violates a production contract."""


JOB_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$")
REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$")
PART_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$")
PUBLIC_MATERIAL_ID_RE = re.compile(r"^decor_[a-f0-9]{20,40}$")
GRAIN_GROUP_RE = re.compile(r"^(G[0-9]{3}):([1-9][0-9]{0,3})$")

_APPEND_LOCK = threading.RLock()


def _reject_json_constant(value: str) -> None:
    raise ContractError(f"Non-finite JSON constant is forbidden: {value}")


def ensure_finite_json(value: Any, path: str = "$") -> None:
    """Recursively reject NaN/Infinity and unsupported JSON value types."""

    if value is None or isinstance(value, (str, bool, int)):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ContractError(f"Non-finite number at {path}")
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            ensure_finite_json(item, f"{path}[{index}]")
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise ContractError(f"Non-string object key at {path}")
            ensure_finite_json(item, f"{path}.{key}")
        return
    raise ContractError(f"Unsupported JSON value at {path}: {type(value).__name__}")


def strict_json_loads(text: str | bytes) -> Any:
    if isinstance(text, bytes):
        text = text.decode("utf-8", errors="strict")
    value = json.loads(str(text), parse_constant=_reject_json_constant)
    ensure_finite_json(value)
    return value


def strict_json_load(path: Path) -> Any:
    return strict_json_loads(Path(path).read_bytes())


def strict_json_dumps(value: Any, *, indent: Optional[int] = None) -> str:
    ensure_finite_json(value)
    return json.dumps(value, ensure_ascii=False, indent=indent, allow_nan=False)


def finite_number(
    value: Any,
    *,
    field: str,
    minimum: Optional[float] = None,
    maximum: Optional[float] = None,
) -> float:
    if isinstance(value, bool):
        raise ContractError(f"{field} must be a finite number")
    try:
        number = float(value)
    except Exception as exc:
        raise ContractError(f"{field} must be a finite number") from exc
    if not math.isfinite(number):
        raise ContractError(f"{field} must be a finite number")
    if minimum is not None and number < minimum:
        raise ContractError(f"{field} must be >= {minimum}")
    if maximum is not None and number > maximum:
        raise ContractError(f"{field} must be <= {maximum}")
    return number


def strict_integer(
    value: Any,
    *,
    field: str,
    minimum: Optional[int] = None,
    maximum: Optional[int] = None,
) -> int:
    number = finite_number(value, field=field)
    if not number.is_integer():
        raise ContractError(f"{field} must be an integer")
    integer = int(number)
    if minimum is not None and integer < minimum:
        raise ContractError(f"{field} must be >= {minimum}")
    if maximum is not None and integer > maximum:
        raise ContractError(f"{field} must be <= {maximum}")
    return integer


def strict_bool(value: Any, *, field: str) -> bool:
    if isinstance(value, bool):
        return value
    raw = str(value or "").strip().lower()
    if raw in {"1", "true"}:
        return True
    if raw in {"0", "false"}:
        return False
    raise ContractError(f"{field} must be exactly true/false or 1/0")


def _validate_identifier(value: Any, regex: re.Pattern[str], label: str) -> str:
    raw = str(value or "").strip()
    if not regex.fullmatch(raw):
        raise ContractError(f"Invalid {label}")
    return raw


def validate_job_id(value: Any) -> str:
    return _validate_identifier(value, JOB_ID_RE, "job id")


def validate_request_id(value: Any) -> str:
    return _validate_identifier(value, REQUEST_ID_RE, "request id")


def validate_part_id(value: Any) -> str:
    return _validate_identifier(value, PART_ID_RE, "PartId")


def validate_public_material_id(value: Any) -> str:
    return _validate_identifier(value, PUBLIC_MATERIAL_ID_RE, "public material id")


def validate_grain_group(value: Any) -> tuple[str, int] | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    match = GRAIN_GROUP_RE.fullmatch(raw)
    if not match:
        raise ContractError("GrainGroup must match G001:1")
    return match.group(1), int(match.group(2))


def resolve_identifier_child(root: Path, identifier: str, *, kind: str = "job") -> Path:
    """Resolve a validated identifier directly below a fixed global root."""

    if kind == "request":
        safe = validate_request_id(identifier)
    else:
        safe = validate_job_id(identifier)
    root_resolved = Path(root).resolve()
    target = (root_resolved / safe).resolve()
    if target.parent != root_resolved:
        raise ContractError(f"Invalid {kind} path")
    return target


def resolve_relative_file(root: Path, relative: str) -> Path:
    raw = str(relative or "").strip().replace("\\", "/")
    if not raw or raw.startswith("/") or re.match(r"^[A-Za-z]:", raw):
        raise ContractError("Invalid relative path")
    parts = raw.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise ContractError("Invalid relative path")
    root_resolved = Path(root).resolve()
    target = root_resolved.joinpath(*parts).resolve()
    if target == root_resolved or root_resolved not in target.parents:
        raise ContractError("Path escapes fixed root")
    return target


def fsync_directory(path: Path) -> None:
    """Durably publish directory-entry changes on POSIX filesystems."""

    if os.name == "nt":
        return
    fd = os.open(str(path), os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def durable_write_bytes(path: Path, data: bytes, *, mode: Optional[int] = None) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.parent / f".{path.name}.tmp.{os.getpid()}.{secrets.token_hex(6)}"
    try:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        fd = os.open(str(tmp), flags, mode if mode is not None else 0o640)
        try:
            with os.fdopen(fd, "wb", closefd=False) as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.close(fd)
        except Exception:
            try:
                os.close(fd)
            except Exception:
                pass
            raise
        if mode is not None:
            os.chmod(tmp, mode)
        os.replace(tmp, path)
        fsync_directory(path.parent)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass


def durable_write_text(path: Path, text: str, *, mode: Optional[int] = None) -> None:
    durable_write_bytes(Path(path), str(text).encode("utf-8"), mode=mode)


def durable_write_json(path: Path, value: Any, *, mode: Optional[int] = None) -> None:
    durable_write_text(Path(path), strict_json_dumps(value, indent=2) + "\n", mode=mode)


def durable_copy_file(source: Path, destination: Path, *, mode: Optional[int] = None) -> None:
    """Copy a file through an fsynced temporary file and atomically publish it."""

    source = Path(source)
    destination = Path(destination)
    if not source.is_file():
        raise ContractError(f"Copy source is not a file: {source.name}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.parent / f".{destination.name}.tmp.{os.getpid()}.{secrets.token_hex(6)}"
    try:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        fd = os.open(str(tmp), flags, mode if mode is not None else 0o640)
        try:
            with open(source, "rb") as source_handle, os.fdopen(fd, "wb", closefd=False) as target_handle:
                shutil.copyfileobj(source_handle, target_handle, length=1024 * 1024)
                target_handle.flush()
                os.fsync(target_handle.fileno())
            os.close(fd)
        except Exception:
            try:
                os.close(fd)
            except Exception:
                pass
            raise
        if mode is not None:
            os.chmod(tmp, mode)
        os.replace(tmp, destination)
        fsync_directory(destination.parent)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass


def append_jsonl_locked(path: Path, value: Any, *, max_bytes: Optional[int] = None) -> None:
    """Append one durable JSONL record with thread and cross-process locking."""

    line = (strict_json_dumps(value) + "\n").encode("utf-8")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with _APPEND_LOCK:
        with open(path, "a+b", buffering=0) as handle:
            if fcntl is not None:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                if max_bytes is not None:
                    handle.seek(0, os.SEEK_END)
                    if handle.tell() + len(line) > int(max_bytes):
                        raise ContractError(f"JSONL quota exceeded for {path.name}")
                handle.write(line)
                os.fsync(handle.fileno())
            finally:
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def append_jsonl_rotating(path: Path, value: Any, *, max_bytes: int, backups: int = 5) -> None:
    """Durably append to a bounded JSONL history with cross-process rotation."""

    line = (strict_json_dumps(value) + "\n").encode("utf-8")
    path = Path(path)
    limit = max(1024, int(max_bytes))
    keep = max(1, min(20, int(backups)))
    if len(line) > limit:
        raise ContractError(f"JSONL record exceeds quota for {path.name}")
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.parent / f".{path.name}.rotate.lock"
    with _APPEND_LOCK:
        with open(lock_path, "a+b", buffering=0) as lock_handle:
            if fcntl is not None:
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
            try:
                current_size = path.stat().st_size if path.exists() else 0
                if current_size + len(line) > limit:
                    oldest = path.parent / f"{path.name}.{keep}"
                    oldest.unlink(missing_ok=True)
                    for index in range(keep - 1, 0, -1):
                        source = path.parent / f"{path.name}.{index}"
                        if source.exists():
                            os.replace(source, path.parent / f"{path.name}.{index + 1}")
                    if path.exists():
                        os.replace(path, path.parent / f"{path.name}.1")
                    fsync_directory(path.parent)
                with open(path, "ab", buffering=0) as handle:
                    handle.write(line)
                    os.fsync(handle.fileno())
                fsync_directory(path.parent)
            finally:
                if fcntl is not None:
                    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)


def durable_create_json_exclusive(path: Path, value: Any, *, mode: int = 0o600) -> bool:
    """Create an fsynced JSON file exactly once.

    Returns ``False`` when the target already exists.  No temporary rename is used:
    ``O_EXCL`` is the cross-process idempotency boundary and the parent directory is
    fsynced before success is reported.
    """

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = (strict_json_dumps(value, indent=2) + "\n").encode("utf-8")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    try:
        fd = os.open(str(path), flags, mode)
    except FileExistsError:
        return False
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        fsync_directory(path.parent)
        return True
    except Exception:
        try:
            path.unlink(missing_ok=True)
            fsync_directory(path.parent)
        except Exception:
            pass
        raise


def tail_text_lines(path: Path, limit: int, *, max_scan_bytes: int = 2 * 1024 * 1024) -> list[str]:
    """Read only the bounded tail of a potentially large log file."""

    path = Path(path)
    if not path.exists() or limit <= 0:
        return []
    with open(path, "rb") as handle:
        handle.seek(0, os.SEEK_END)
        end = handle.tell()
        start = max(0, end - max(1, int(max_scan_bytes)))
        handle.seek(start)
        data = handle.read(end - start)
    if start > 0:
        first_newline = data.find(b"\n")
        data = data[first_newline + 1 :] if first_newline >= 0 else b""
    return data.decode("utf-8", errors="replace").splitlines()[-int(limit) :]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha256_files(paths: Iterable[Path], *, relative_to: Optional[Path] = None) -> dict[str, str]:
    base = Path(relative_to).resolve() if relative_to is not None else None
    out: dict[str, str] = {}
    for item in sorted((Path(p) for p in paths), key=lambda p: str(p)):
        resolved = item.resolve()
        key = resolved.relative_to(base).as_posix() if base is not None else str(resolved)
        out[key] = sha256_file(resolved)
    return out
