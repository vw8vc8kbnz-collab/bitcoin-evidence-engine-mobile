#!/usr/bin/env python3
from __future__ import annotations

"""Executable FIX660R8 production-safety regression tests.

The suite intentionally uses real embedded METOD DXF templates for the golden
grain job.  It is dependency-free and safe to run from a release staging tree.
"""

import json
import hashlib
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
sys.path.insert(0, str(APP))

import dxf_nesting_optimizer as optimizer  # noqa: E402
import catalog_importer  # noqa: E402
from dxf_geometry import entity_type, split_entities  # noqa: E402
from panel_contract import parse_panels_csv  # noqa: E402
from safety_contracts import (  # noqa: E402
    ContractError,
    append_jsonl_rotating,
    resolve_identifier_child,
    resolve_relative_file,
    sha256_file,
    strict_json_loads,
)


HEADER = "PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;MaterialCode;GrainGroup;RotationAllowed;H1;H2;W1;W2\n"


def minimal_jpeg(width: int = 2, height: int = 2) -> bytes:
    return (
        b'\xff\xd8\xff\xc0\x00\x11\x08'
        + int(height).to_bytes(2, 'big')
        + int(width).to_bytes(2, 'big')
        + b'\x03\x01\x11\x00\x02\x11\x00\x03\x11\x00\xff\xd9'
    )


def pricing() -> dict:
    return {
        "currency": "EUR",
        "defaults": {"sheetMarginMm": 6.5, "nestingGapMm": 13.0, "kerfMm": 3.2},
        "materials": [
            {
                "materialCode": "MAT_18",
                "thicknessMm": 18,
                "sheetSizeMm": {"width": 2800, "height": 2070},
                "purchasePricePerSheet": 100,
                "sellPriceExVatPerSheet": 150,
                "sellPriceInclVatPerSheet": 181.5,
                "materialPriceBasis": "TEST_FIXTURE",
            }
        ],
        "edgeBanding": {
            "defaultLossPercent": 10,
            "codes": [{"code": 1, "purchasePricePerUnit": 2.5}],
        },
    }


class SafetyContractTests(unittest.TestCase):
    def test_strict_json_rejects_non_finite(self) -> None:
        for raw in ('{"x": NaN}', '{"x": Infinity}', '{"x": -Infinity}'):
            with self.assertRaises(ContractError):
                strict_json_loads(raw)

    def test_paths_reject_traversal(self) -> None:
        root = Path("/tmp/fix660r8-jobs")
        for value in ("..", "../../victim", "a/b", "a\\b", ""):
            with self.assertRaises(ContractError):
                resolve_identifier_child(root, value)
        for value in ("../quote.json", "/etc/passwd", "a/../../b", "a\\..\\b"):
            with self.assertRaises(ContractError):
                resolve_relative_file(root / "JOB_1", value)

    def test_panel_contract_rejects_adversarial_values(self) -> None:
        valid = HEADER + "A;A;1;397;597;18;MAT_18;;false;0;0;0;0\n"
        self.assertEqual(len(parse_panels_csv(valid, allowed_edge_codes={0, 1})), 1)
        invalid_rows = [
            "A;A;1;NaN;597;18;MAT_18;;false;0;0;0;0",
            "A;A;1.5;397;597;18;MAT_18;;false;0;0;0;0",
            "A;A;1;397;597;18;MAT_18;;maybe;0;0;0;0",
            "A;A;1;397;597;18;MAT_18;;false;-1;0;0;0",
            "A;A;1;397;597;18;MAT_18;;false;2;0;0;0",
        ]
        for row in invalid_rows:
            with self.subTest(row=row), self.assertRaises(ContractError):
                parse_panels_csv(HEADER + row + "\n", allowed_edge_codes={0, 1})

        mixed = HEADER + "\n".join(
            (
                "A;A;1;397;597;18;MAT_18;G001:1;false;0;0;0;0",
                "B;B;1;797;596;18;MAT_18;G001:2;false;0;0;0;0",
            )
        ) + "\n"
        with self.assertRaises(ContractError):
            parse_panels_csv(mixed, allowed_edge_codes={0, 1})

    def test_arc_angles_rotate_for_every_quadrant(self) -> None:
        source = ROOT / "app/embedded_dxfs/Overige panelen/Metod Hoekkast 2-2.dxf"
        part = optimizer.load_part(source, {})

        def angles(flat: list[tuple[int, str]]) -> list[list[float]]:
            return [
                [float(value) for code, value in entity if code in {50, 51}]
                for entity in split_entities(flat)
                if entity_type(entity) == "ARC"
            ]

        original = angles(part.drill_pairs)
        self.assertEqual(len(original), 2)
        for rotation in (0, 90, 180, 270):
            transformed = optimizer.rotate_translate_pairs(
                part.drill_pairs, rotation, 0, 0, part.w, part.h
            )
            expected = [[(value + rotation) % 360 for value in pair] for pair in original]
            actual = angles(transformed)
            for actual_pair, expected_pair in zip(actual, expected):
                for actual_value, expected_value in zip(actual_pair, expected_pair):
                    self.assertAlmostEqual(actual_value, expected_value, places=7)

    def test_no_machining_dropping_fallback_exists(self) -> None:
        self.assertFalse(hasattr(optimizer, "write_simple_sheet_dxf"))

    def test_catalog_image_dns_is_pinned_and_private_ips_fail_closed(self) -> None:
        public_info = [(2, 1, 6, '', ('93.184.216.34', 443))]
        private_info = [(2, 1, 6, '', ('127.0.0.1', 443))]
        with mock.patch.object(catalog_importer.socket, 'getaddrinfo', return_value=private_info):
            with self.assertRaises(ValueError):
                catalog_importer.validate_remote_image_url('https://adzaagt.nl/image.jpg')

        calls: list[tuple[str, str]] = []

        class FakeSocket:
            def settimeout(self, _value):
                return None

        class FakeResponse:
            status = 200

            def __init__(self):
                self._data = minimal_jpeg()
                self._chunks = [self._data, b'']

            def getheader(self, name):
                return str(len(self._data)) if name == 'Content-Length' else None

            def read(self, _size):
                return self._chunks.pop(0)

        class FakeConnection:
            def __init__(self, host, pinned_ip, *, timeout):
                calls.append((host, pinned_ip))
                self.sock = FakeSocket()

            def request(self, _method, _target, headers=None):
                self.headers = headers or {}

            def getresponse(self):
                return FakeResponse()

            def close(self):
                return None

        with mock.patch.object(catalog_importer.socket, 'getaddrinfo', return_value=public_info), mock.patch.object(
            catalog_importer, '_PinnedHTTPSConnection', FakeConnection
        ):
            result = catalog_importer.download_catalog_image('https://adzaagt.nl/image.jpg')
        self.assertEqual(calls, [('adzaagt.nl', '93.184.216.34')])
        self.assertEqual(result['mime'], 'image/jpeg')
        self.assertEqual((result['width'], result['height']), (2, 2))

        oversized_png = (
            b'\x89PNG\r\n\x1a\n\x00\x00\x00\x0dIHDR'
            + (10_000).to_bytes(4, 'big')
            + (10_000).to_bytes(4, 'big')
            + b'\x08\x02\x00\x00\x00'
        )
        with self.assertRaises(ValueError):
            catalog_importer._validated_image_dimensions(oversized_png, 'image/png')

    def test_catalog_cache_detects_tampering(self) -> None:
        with tempfile.TemporaryDirectory(prefix='fix660r8_catalog_cache_') as temp:
            folder = Path(temp)
            data = minimal_jpeg()
            payload = {
                'data': data,
                'mime': 'image/jpeg',
                'sha256': hashlib.sha256(data).hexdigest(),
                'bytes': len(data),
            }
            catalog_importer.atomic_write_cached_image(folder, payload)
            self.assertIsNotNone(catalog_importer.read_cached_image(folder))
            (folder / 'catalog.img').write_bytes(data + b'tamper')
            self.assertIsNone(catalog_importer.read_cached_image(folder))

    def test_bounded_jsonl_rotates_without_dropping_new_record(self) -> None:
        with tempfile.TemporaryDirectory(prefix='fix660r8_log_rotation_') as temp:
            path = Path(temp) / 'audit.jsonl'
            for index in range(12):
                append_jsonl_rotating(
                    path,
                    {'index': index, 'padding': 'x' * 180},
                    max_bytes=1024,
                    backups=2,
                )
            self.assertTrue(path.is_file())
            self.assertTrue(path.with_name('audit.jsonl.1').is_file())
            current_records = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
            self.assertEqual(current_records[-1]['index'], 11)
            self.assertLessEqual(path.stat().st_size, 1024)


class GoldenOptimizerTests(unittest.TestCase):
    def _run_job(self, panel_rows: str, templates: dict[str, Path]) -> tuple[subprocess.CompletedProcess[str], Path, tempfile.TemporaryDirectory[str]]:
        holder: tempfile.TemporaryDirectory[str] = tempfile.TemporaryDirectory(prefix="fix660r8_test_")
        root = Path(holder.name)
        input_dir = root / "input"
        parts_dir = input_dir / "dxf_parts"
        output_dir = root / "output"
        parts_dir.mkdir(parents=True)
        (input_dir / "job.json").write_text(json.dumps({"grainEnabled": True}), encoding="utf-8")
        (input_dir / "pricing.json").write_text(json.dumps(pricing()), encoding="utf-8")
        (input_dir / "panels.csv").write_text(HEADER + panel_rows, encoding="utf-8")
        for part_id, template in templates.items():
            shutil.copyfile(template, parts_dir / f"{part_id}.dxf")
        result = subprocess.run(
            [sys.executable, str(APP / "dxf_nesting_optimizer.py"), "--input", str(input_dir), "--output", str(output_dir)],
            cwd=str(ROOT),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=60,
            check=False,
        )
        return result, output_dir, holder

    def test_three_panel_grain_order_and_manifest(self) -> None:
        templates = {
            "GRAIN_A": ROOT / "app/embedded_dxfs/Deuren METOD/Metod deur 60x40.dxf",
            "GRAIN_B": ROOT / "app/embedded_dxfs/Deuren METOD/Metod deur 60x80.dxf",
            "GRAIN_C": ROOT / "app/embedded_dxfs/Ladefront METOD/Metod lade 60x20.dxf",
        }
        rows = "\n".join(
            (
                "GRAIN_A;A;1;397;597;18;MAT_18;G001:1;false;0;0;0;0",
                "GRAIN_B;B;1;797;597;18;MAT_18;G001:2;false;0;0;0;0",
                "GRAIN_C;C;1;197;597;18;MAT_18;G001:3;false;0;0;0;0",
            )
        ) + "\n"
        result, output, holder = self._run_job(rows, templates)
        self.addCleanup(holder.cleanup)
        self.assertEqual(result.returncode, 0, msg=result.stderr)
        report = json.loads((output / "report.json").read_text(encoding="utf-8"))
        placements = json.loads((output / "placements.json").read_text(encoding="utf-8"))["placements"]
        by_id = {item["partId"]: item for item in placements}
        self.assertLess(by_id["GRAIN_A"]["y_mm"], by_id["GRAIN_B"]["y_mm"])
        self.assertLess(by_id["GRAIN_B"]["y_mm"], by_id["GRAIN_C"]["y_mm"])
        self.assertEqual({item["rotation_deg"] for item in placements}, {0})
        self.assertTrue(report["ok"])
        self.assertTrue(report["placementValidation"]["grainPositionOneIsLowestY"])

        manifest_path = output / "optimizer_manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        self.assertEqual(manifest["counts"]["requestedInstances"], 3)
        self.assertEqual(manifest["counts"]["placements"], 3)
        self.assertEqual(report["optimizerManifestSha256"], sha256_file(manifest_path))
        for relative, expected_hash in manifest["outputsSha256"].items():
            self.assertEqual(sha256_file(output / relative), expected_hash)

    def test_bbox_mismatch_is_fatal_and_publishes_no_sheet(self) -> None:
        template = ROOT / "app/embedded_dxfs/Ladefront METOD/Metod lade 80x40.dxf"
        rows = "BAD;Bad;1;397;597;18;MAT_18;;false;0;0;0;0\n"
        result, output, holder = self._run_job(rows, {"BAD": template})
        self.addCleanup(holder.cleanup)
        self.assertNotEqual(result.returncode, 0)
        report = json.loads((output / "report.json").read_text(encoding="utf-8"))
        self.assertFalse(report["ok"])
        self.assertIn("differs from CSV", report["exception"])
        sheets = list((output / "sheets").glob("*.dxf")) if (output / "sheets").exists() else []
        self.assertEqual(sheets, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
