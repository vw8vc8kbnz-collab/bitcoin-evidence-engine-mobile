# Outrun IQ v8.0.1 — Buyer Home v2

- Home opnieuw opgebouwd als rustige AI-curated etalage.
- Zoekbalk blijft weg van Home; zoeken leeft in Categorieën/AI Vinder.
- Welkomstkaart toont persoonlijke AI-selectie en aantal relevante deals.
- AI Picks zijn grotere premium kaarten met partner, score en conditie.
- Partner Spotlight voorbereid als subtiele Outrun Promote-positie.
- Secties zijn deduplicated: hetzelfde product verschijnt niet steeds opnieuw op Home.
- Collecties toegevoegd om 50.000+ artikelen niet als lange lijst te laten voelen.
- AI Vinder CTA opnieuw geplaatst als rustige einde-flow.
- Service worker cache bumped naar v8.0.1.
