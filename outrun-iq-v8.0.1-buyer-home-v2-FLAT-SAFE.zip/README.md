# Outrun IQ v8.0.1 — Buyer Home v2

Gebouwd bovenop v8.0.0 AI Foundation.

Nieuw:
- Home v2 met compacte persoonlijke AI-welkomstkaart.
- Persoonlijke hero/slideshow blijft, maar Home voelt minder als herhaalde productlijst.
- AI Picks groter en rijker vormgegeven.
- Partner Spotlight als premium Outrun Promote-plek.
- Nieuw binnen, Trending en Laatste stuks dedupliceren tegen eerdere Home-secties.
- Collecties toegevoegd voor rustige ontdekstructuur.
- AI Vinder CTA onderaan als premium ingang.
- Design blijft rustig en niet te druk.
