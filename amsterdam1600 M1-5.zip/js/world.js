// De wereld: Amsterdam 1662 — de voltooide Grachtengordel.
// Analytische stadsopbouw: alles binnen straal R.wall en de boog-sweep
// is stad; de Plantage (oostsector) is tuinen; daarbuiten rustige
// weilanden — géén moeras. De wal is een ster met bastions en molens.
import { GRID, T, OBJ, SEED } from './config.js';
import { fnoise, hash2d } from './rng.js';
import { strokePolyline, fillPolygon, fillRect } from './mapbuild.js';
import MAP from './maps/amsterdam1662.js';

function shoreLinear(x) {
  const s = MAP.ijShore;
  return s.y0 + ((s.y1 - s.y0) * (x - s.x0)) / (s.x1 - s.x0);
}
function shoreY(x) {
  return shoreLinear(x) + 4 * fnoise(x / 18, 3.7, SEED ^ 0x11);
}

const DEG = 180 / Math.PI;

export function generateWorld() {
  const { C, SWEEP, R } = MAP;
  const tiles = new Uint8Array(GRID * GRID);

  // 1. Basis: rustige weilanden (geen moeras, geen slotenraster) + stad
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const i = y * GRID + x;
      const dx = x - C.x, dy = y - C.y;
      const r = Math.sqrt(dx * dx + dy * dy);
      const a = Math.atan2(dy, dx) * DEG;
      const inSweep = a > SWEEP.a1 && a < SWEEP.a0;
      if (r < R.wall && inSweep && y > shoreY(x) - 1) {
        // binnen de wal: Plantage = tuinen, de rest dichte bebouwing
        tiles[i] = a < MAP.plantageMaxAngle && r > R.singel ? T.GRASS : T.BLOCK;
      } else {
        const n = fnoise(x / 34, y / 34, SEED);
        tiles[i] = n > 0.62 ? T.GRASS : (n > 0.3 ? T.GRASS : T.DIRT);
      }
    }
  }

  // 2. Het IJ
  for (let x = 0; x < GRID; x++) {
    const edge = shoreY(x);
    for (let y = 0; y < edge; y++) tiles[y * GRID + x] = T.IJ;
  }

  // 3. Haveneilanden in het IJ
  for (const isl of MAP.islands) {
    fillPolygon(tiles, isl.poly, () => T.BLOCK);
  }

  // 4. IJ-kade (havenfront)
  for (let x = MAP.harbor.x0; x <= MAP.harbor.x1; x++) {
    const edge = Math.floor(shoreY(x));
    for (let y = edge; y < edge + 3; y++) {
      const i = y * GRID + x;
      if (i >= 0 && tiles[i] !== T.IJ) tiles[i] = T.QUAY;
    }
  }

  // 5. De stervormige omwalling: gracht (moat), wal, en puntbastions
  const bastionApices = [];
  strokePolyline(tiles, MAP.arc(MAP.wall.moatR, SWEEP.a0, SWEEP.a1, 3), 9, T.CANAL);
  strokePolyline(tiles, MAP.arc(MAP.wall.r, SWEEP.a0, SWEEP.a1, 3), 4, T.WALL);
  for (let a = SWEEP.a0 - 4; a > SWEEP.a1 + 2; a -= MAP.wall.bastionEveryDeg) {
    const b0 = MAP.at(a - MAP.wall.bastionHalfDeg, MAP.wall.r);
    const b1 = MAP.at(a + MAP.wall.bastionHalfDeg, MAP.wall.r);
    const apex = MAP.at(a, MAP.wall.r + MAP.wall.bastionOut);
    fillPolygon(tiles, [b0, apex, b1], () => T.WALL);
    bastionApices.push(apex);
  }

  // 6. Straten en pleinen
  for (const s of MAP.streets) strokePolyline(tiles, s.pts, s.w, T.STREET);
  for (const p of MAP.plazas) fillRect(tiles, ...p.rect, T.STREET);
  for (const isl of MAP.islands) strokePolyline(tiles, isl.spine, 1.8, T.STREET);

  // 6b. Steegjes: fijne korrel, oost-west om de ~10 rijen, verspringend
  for (let row = 0; row < GRID; row += 10) {
    for (let x = 1; x < GRID - 1; x++) {
      const jitter = (hash2d((x / 22) | 0, row, SEED ^ 0x66) * 5) | 0;
      const y = row + jitter;
      if (y < 1 || y >= GRID - 1) continue;
      const i = y * GRID + x;
      if (tiles[i] === T.BLOCK) tiles[i] = T.STREET;
    }
  }

  // 7. Waterlopen (na de wal: de Amstel snijdt de wal en de moat open)
  for (const c of MAP.canals) strokePolyline(tiles, c.pts, c.w, T.CANAL);

  // 8. Paalwerk in het IJ (strak op de lineaire oever)
  for (const p of MAP.palisade) {
    for (let x = p.x0; x <= p.x1; x++) {
      const period = p.dash + p.gap;
      if ((x - p.x0) % period >= p.dash) continue;
      const y = Math.floor(shoreLinear(x)) + p.yOffset;
      if (y >= 0 && tiles[y * GRID + x] === T.IJ) tiles[y * GRID + x] = T.WALL;
    }
  }

  // 9. Kades langs alle grachten
  const withQuays = new Uint8Array(tiles);
  for (let y = 1; y < GRID - 1; y++) {
    for (let x = 1; x < GRID - 1; x++) {
      const i = y * GRID + x;
      if (tiles[i] !== T.BLOCK) continue;
      if (
        tiles[i - 1] === T.CANAL || tiles[i + 1] === T.CANAL ||
        tiles[i - GRID] === T.CANAL || tiles[i + GRID] === T.CANAL
      ) {
        withQuays[i] = T.QUAY;
      }
    }
  }

  // 10. Binnenhoven (dieper dan 4 tegels van open ruimte)
  const depth = new Uint8Array(GRID * GRID);
  const isOpen = (t) => t !== T.BLOCK;
  for (let d = 1; d <= 4; d++) {
    for (let y = 1; y < GRID - 1; y++) {
      for (let x = 1; x < GRID - 1; x++) {
        const i = y * GRID + x;
        if (withQuays[i] !== T.BLOCK || depth[i] !== 0) continue;
        const nb = [i - 1, i + 1, i - GRID, i + GRID];
        for (const j of nb) {
          if ((d === 1 && isOpen(withQuays[j])) || (d > 1 && depth[j] === d - 1)) {
            depth[i] = d;
            break;
          }
        }
      }
    }
  }
  const out = withQuays;
  for (let i = 0; i < out.length; i++) {
    if (out[i] === T.BLOCK && depth[i] === 0) {
      out[i] = hash2d(i % GRID, (i / GRID) | 0, SEED ^ 0x88) < 0.7 ? T.GRASS : T.DIRT;
    }
  }

  // 11. Objectlaag
  const objects = new Uint8Array(GRID * GRID);
  const openTypes = new Set([T.STREET, T.QUAY]);
  for (let y = 1; y < GRID - 1; y++) {
    for (let x = 1; x < GRID - 1; x++) {
      const i = y * GRID + x;
      const t = out[i];
      const dx = x - C.x, dy = y - C.y;
      const r = Math.sqrt(dx * dx + dy * dy);
      if (t === T.BLOCK) {
        if (
          openTypes.has(out[i - 1]) || openTypes.has(out[i + 1]) ||
          openTypes.has(out[i - GRID]) || openTypes.has(out[i + GRID])
        ) {
          objects[i] = OBJ.HOUSE;
        }
        continue;
      }
      // de wal in 3D: aarden borstwering op elke waltegel op land
      if (t === T.WALL && y > shoreY(x) - 1) {
        objects[i] = OBJ.RAMPART;
        continue;
      }
      // bomen: hoven en Plantage vol, grachtenkades hier en daar, buiten weinig
      if (t === T.GRASS) {
        const inCity = r < R.wall;
        const dens = inCity ? (Math.atan2(dy, dx) * DEG < MAP.plantageMaxAngle && r > R.singel ? 0.2 : 0.13) : 0.006;
        if (hash2d(x, y, SEED ^ 0xA1) < dens) objects[i] = OBJ.TREE;
      } else if (t === T.QUAY && r > R.singel - 4 && r < R.lijnbaans + 4) {
        if (hash2d(x, y, SEED ^ 0xA7) < 0.07) objects[i] = OBJ.TREE;
      }
    }
  }

  // het IJ vól schepen, en scheepjes in de grachten
  for (let y = 2; y < GRID; y++) {
    for (let x = 4; x < GRID - 4; x++) {
      const i = y * GRID + x;
      if (objects[i]) continue;
      const h = hash2d(x, y, SEED ^ 0xB2);
      if (out[i] === T.IJ && y > 6 && y < shoreY(x) - 2 && h < 0.016) {
        objects[i] = h < 0.009 ? OBJ.SHIP_L : OBJ.SHIP_S;
      } else if (out[i] === T.CANAL && h < 0.008) {
        objects[i] = OBJ.SHIP_S;
      }
    }
  }

  // molens op de bastionpunten — het silhouet van de kaart
  for (let k = 0; k < bastionApices.length; k++) {
    if (k % 2 === 1) continue;
    const [bx, by] = bastionApices[k];
    if (by > shoreY(bx)) objects[by * GRID + bx] = OBJ.MILL;
  }

  // landmarks
  const OBJ_BY_NAME = { tower: OBJ.TOWER, church: OBJ.CHURCH, mill: OBJ.MILL };
  for (const lm of MAP.landmarks) {
    objects[lm.y * GRID + lm.x] = OBJ_BY_NAME[lm.obj] || OBJ.TOWER;
  }

  return { tiles: out, objects };
}

export function tileAt(tiles, x, y) {
  if (x < 0 || y < 0 || x >= GRID || y >= GRID) return -1;
  return tiles[y * GRID + x];
}

export function variantAt(x, y) {
  return (hash2d(x, y, SEED ^ 0x77) * 3) | 0;
}
