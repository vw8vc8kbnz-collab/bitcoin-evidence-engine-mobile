ROOMARC MVP v0.3.0
Nederlandse app + Instagram-achtige Home Profiles + Roomarc Studio + verbeterde Room Page.

Upload deze ZIP naar GitHub en gebruik de update-command uit ChatGPT.
De installer pakt automatisch uit naar ~/roomarc, maakt een venv, installeert dependencies en start de app op poort 8899.

Demo-login:
demo@roomarc.local
demo123

Open:
http://SERVER-IP:8899

Belangrijk:
- Roomarc draait los van Bitcoin Evidence Engine.
- Media staat nu lokaal in ~/roomarc_data/media.
- Voor publieke beta later Cloudflare R2 koppelen.
