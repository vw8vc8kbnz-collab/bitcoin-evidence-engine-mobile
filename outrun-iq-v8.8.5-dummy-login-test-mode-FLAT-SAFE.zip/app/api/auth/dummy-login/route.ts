import { NextResponse, type NextRequest } from "next/server";
import { randomUUID } from "node:crypto";
import { mutate } from "@/lib/store";
import { createSession, SESSION_COOKIE, hashPassword } from "@/lib/auth";
import type { User, Seller } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function dummyEnabled() {
  return process.env.DUMMY_LOGIN_ENABLED === "true" || process.env.NEXT_PUBLIC_DUMMY_LOGIN_ENABLED === "true";
}

function makeDummyPassword() {
  return hashPassword(`dummy-${Date.now()}-${Math.random()}`);
}

export async function POST(req: NextRequest) {
  if (!dummyEnabled()) {
    return NextResponse.json({ error: "Dummy login staat uit" }, { status: 404 });
  }

  const b = await req.json().catch(() => ({}));
  const accountType = b.accountType === "zakelijk" ? "zakelijk" : "persoonlijk";
  const now = new Date().toISOString();
  let userId = "";

  const result = await mutate(db => {
    if (accountType === "zakelijk") {
      const email = "dummy-partner@outrun.test";
      let u = db.users.find(x => x.email === email && x.role === "partner");
      let seller = db.sellers.find(x => x.slug === "dummy-outlet");

      if (!seller) {
        const sellerRecord: Seller = {
          slug: "dummy-outlet",
          name: "Dummy Outlet Partner",
          city: "Castricum",
          kvk: "00000000",
          contactPerson: "Test gebruiker",
          businessEmail: email,
          businessPhone: "",
          deliveryOptions: ["Bezorging in overleg", "Ophalen"],
          shippingCost: 0,
          payout: { bankStatus: "verified", ibanMasked: "NL** TEST 0000" },
          stripeConnect: { status: "not_started" },
          support: { email, returnsInfo: "Testmodus: retourvoorwaarden niet actief." },
          about: "Testpartner voor Outrun IQ dummy login. Alleen gebruiken op staging/test.",
          address: { street: "Outletstraat 12", postcode: "1234 AB", city: "Castricum" },
          trusted: true,
          createdAt: now,
          payment: { provider: "test", onboardingStatus: "complete", payoutsEnabled: false },
        };
        db.sellers.push(sellerRecord);
        seller = sellerRecord;
      }

      if (!u) {
        const hp = makeDummyPassword();
        const user: User = {
          id: randomUUID(),
          email,
          name: "Dummy Partner",
          passHash: hp.passHash,
          salt: hp.salt,
          role: "partner",
          partnerSlug: seller.slug,
          partnerProfile: {
            companyName: seller.name,
            kvk: "00000000",
            city: seller.city,
            status: "approved",
            termsAcceptedAt: now,
            appliedAt: now,
            decidedAt: now,
          },
          createdAt: now,
        };
        db.users.push(user);
        u = user;
      } else {
        u.partnerSlug = seller.slug;
        u.partnerProfile = {
          companyName: u.partnerProfile?.companyName || seller.name,
          kvk: u.partnerProfile?.kvk || "00000000",
          city: u.partnerProfile?.city || seller.city,
          status: "approved",
          termsAcceptedAt: u.partnerProfile?.termsAcceptedAt || now,
          appliedAt: u.partnerProfile?.appliedAt || now,
          decidedAt: u.partnerProfile?.decidedAt || now,
        };
      }

      userId = u.id;
      return { role: u.role, partner: true, partnerPending: false, name: u.name };
    }

    const email = "dummy-koper@outrun.test";
    let u = db.users.find(x => x.email === email && x.role === "consument");
    if (!u) {
      const hp = makeDummyPassword();
      const user: User = {
        id: randomUUID(),
        email,
        name: "Dummy Koper",
        passHash: hp.passHash,
        salt: hp.salt,
        role: "consument",
        createdAt: now,
      };
      db.users.push(user);
      u = user;
    }
    userId = u.id;
    return { role: u.role, partner: false, partnerPending: false, name: u.name };
  });

  const { token, expires } = await createSession(userId);
  const res = NextResponse.json({ ok: true, dummy: true, ...result });
  res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", expires });
  return res;
}
