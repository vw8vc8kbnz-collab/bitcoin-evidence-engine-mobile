# Changelog

## v8.8.5 — Dummy Login Test Mode

- Testmodus toegevoegd voor dummy-login zonder e-mail/wachtwoord.
- Login-scherm blijft zichtbaar; alleen bij `NEXT_PUBLIC_DUMMY_LOGIN_ENABLED=true` verschijnt een testknop.
- Serverroute `/api/auth/dummy-login` werkt alleen als `DUMMY_LOGIN_ENABLED=true` of `NEXT_PUBLIC_DUMMY_LOGIN_ENABLED=true` staat.
- Dummy koperaccount en dummy partneraccount worden veilig in `data/db.json` aangemaakt/hergebruikt.
- Zakelijke dummy-login maakt/hergebruikt een approved testpartner `dummy-outlet`, zodat de Partner Hub direct testbaar is.
- Default in `.env.example` blijft false; productie kan dit eenvoudig weer uitzetten.
