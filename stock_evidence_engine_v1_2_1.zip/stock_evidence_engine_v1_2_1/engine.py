#!/usr/bin/env python3
import csv, json, math, sys, zipfile
from datetime import datetime, timezone
from pathlib import Path

VERSION='v1.2.1'
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; EXPORTS=ROOT/'exports'
DATA.mkdir(exist_ok=True); EXPORTS.mkdir(exist_ok=True)

THEMES={
 'BB':['ai','robotics','cybersecurity','automotive software','qnx'],
 'PLTR':['ai','defense','government','data platform'],
 'IONQ':['quantum','compute','next-gen'],
 'SOUN':['ai','voice ai','automotive ai'],
 'AI':['enterprise ai','ai software'],
 'BBAI':['ai','defense','analytics'],
 'RKLB':['space','defense','launch'],
 'SMR':['nuclear','energy'],
 'ACHR':['evtol','aviation','mobility'],
 'JOBY':['evtol','aviation','mobility'],
 'HOOD':['fintech','retail trading'],
 'COIN':['crypto','bitcoin'],
 'MARA':['crypto','bitcoin mining'],
 'RIOT':['crypto','bitcoin mining'],
 'AMD':['ai chips','semiconductor','datacenter'],
 'NVDA':['ai chips','semiconductor','datacenter'],
 'TSLA':['ev','robotics','ai'],
 'RIVN':['ev','automotive'],
 'LCID':['ev','automotive'],
 'UPST':['ai lending','fintech']
}

CATALYST_WORDS={
 'ai':18,'robotics':16,'quantum':16,'defense':14,'space':12,'crypto':10,'bitcoin':10,
 'semiconductor':12,'datacenter':10,'nuclear':10,'evtol':10,'contract':12,
 'partnership':10,'guidance':12,'earnings':8
}

SECTOR_BENCH={
 'AMD':'QQQ','NVDA':'QQQ','PLTR':'QQQ','SOUN':'QQQ','AI':'QQQ','BBAI':'QQQ','UPST':'QQQ','HOOD':'QQQ','COIN':'QQQ',
 'TSLA':'QQQ','IONQ':'QQQ','BB':'QQQ','RKLB':'QQQ','ACHR':'QQQ','JOBY':'QQQ','RIVN':'QQQ','LCID':'QQQ','MARA':'QQQ','RIOT':'QQQ','SMR':'SPY'
}

def safe_float(x, default=0.0):
    try:
        if x is None or (isinstance(x,float) and math.isnan(x)): return default
        return float(x)
    except Exception: return default

def download_prices(ticker, period):
    try:
        import yfinance as yf
        df=yf.download(ticker, period=period, interval='1d', auto_adjust=True, progress=False)
        if df is None or df.empty: return []
        if hasattr(df.columns,'levels'):
            df.columns=[c[0] if isinstance(c, tuple) else c for c in df.columns]
        rows=[]
        for idx,r in df.iterrows():
            rows.append({'date':str(idx.date()), 'open':safe_float(r.get('Open')), 'high':safe_float(r.get('High')), 'low':safe_float(r.get('Low')), 'close':safe_float(r.get('Close')), 'volume':safe_float(r.get('Volume'))})
        return rows
    except Exception as e:
        print(f'[SEE] WARN {ticker}: yfinance failed: {e}')
        return []

def ma(vals,n,i):
    if i+1<n: return None
    return sum(vals[i-n+1:i+1])/n

def pct(a,b):
    return (a/b-1)*100 if b else 0.0

def ret(rows,i,h):
    if i+h>=len(rows): return None
    a=rows[i]['close']; b=rows[i+h]['close']
    if not a: return None
    return pct(b,a)

def by_date(rows):
    return {r['date']: r for r in rows}

def bench_return(bench_map, date, days=20):
    # bench_map contains ordered rows under _rows plus by-date access.
    rows=bench_map.get('_rows', [])
    idx=bench_map.get('_idx', {}).get(date)
    if idx is None or idx<days: return 0.0
    return pct(rows[idx]['close'], rows[idx-days]['close'])

def regime_for_date(date, spy_map, qqq_map):
    def one(bm):
        rows=bm.get('_rows',[]); idx=bm.get('_idx',{}).get(date)
        if idx is None or idx<50: return {'above50':False,'mom20':0.0,'score':35}
        closes=[r['close'] for r in rows]
        m50=ma(closes,50,idx)
        mom20=pct(closes[idx], closes[idx-20]) if idx>=20 else 0.0
        above=bool(m50 and closes[idx]>m50)
        score=50 + (18 if above else -18) + max(-15,min(15,mom20*1.2))
        return {'above50':above,'mom20':mom20,'score':score}
    spy=one(spy_map); qqq=one(qqq_map)
    score=max(0,min(100, spy['score']*0.45 + qqq['score']*0.55))
    label='RISK_ON' if score>=60 else ('NEUTRAL' if score>=45 else 'RISK_OFF')
    return {'regime_score':round(score,2),'regime_label':label,'spy_above50':int(spy['above50']),'qqq_above50':int(qqq['above50']),'spy_mom20':round(spy['mom20'],2),'qqq_mom20':round(qqq['mom20'],2)}

def features(rows,i, ticker, bench_maps):
    closes=[r['close'] for r in rows]; vols=[r['volume'] for r in rows]
    c=closes[i]
    m20=ma(closes,20,i); m50=ma(closes,50,i); v5=ma(vols,5,i); v20=ma(vols,20,i)
    prev20=max(closes[max(0,i-20):i]) if i>0 else c
    prev5=closes[i-5] if i>=5 else closes[0]
    prev10=closes[i-10] if i>=10 else closes[0]
    prev20close=closes[i-20] if i>=20 else closes[0]
    mom5=pct(c,prev5); mom10=pct(c,prev10); mom20=pct(c,prev20close)
    rv=vols[i]/v20 if v20 and v20>0 else 1
    vol_accel=(v5/v20) if v5 and v20 and v20>0 else 1
    dollar_volume=c*vols[i]
    bench=SECTOR_BENCH.get(ticker.upper(),'QQQ')
    bm=bench_maps.get(bench,{})
    bench_mom20=bench_return(bm, rows[i]['date'], 20)
    rs20=mom20-bench_mom20
    above50= bool(m50 and c>m50)
    breakout= c>=prev20*1.01 if prev20 else False
    pullback_reclaim= bool(m20 and m50 and c>m20 and m20>m50 and i>2 and closes[i-1]<m20)
    return {'close':c,'m20':m20,'m50':m50,'rv':rv,'vol_accel':vol_accel,'dollar_volume':dollar_volume,'mom5':mom5,'mom10':mom10,'mom20':mom20,'bench':bench,'bench_mom20':bench_mom20,'rs20':rs20,'above50':above50,'breakout':breakout,'pullback_reclaim':pullback_reclaim}

def signals(ticker, rows, i, bench_maps, reg):
    f=features(rows,i,ticker,bench_maps)
    out=[]
    if i<60: return out
    risk_ok=reg['regime_score']>=45
    rs_ok=f['rs20']>3
    strong_rs=f['rs20']>8
    volume_ok=f['rv']>1.25 and f['vol_accel']>1.05
    if f['above50'] and f['mom10']>8 and f['rv']>1.25:
        out.append(('momentum_continuation_legacy', f))
    if f['above50'] and f['mom10']>8 and volume_ok and rs_ok and risk_ok:
        out.append(('momentum_rs_continuation', f))
    if f['breakout'] and f['rv']>1.5 and f['mom5']>3 and rs_ok:
        out.append(('breakout_continuation', f))
    if i>1:
        gap=pct(rows[i]['open'], rows[i-1]['close']) if rows[i-1]['close'] else 0
        intraday=pct(rows[i]['close'], rows[i]['open']) if rows[i]['open'] else 0
        if gap>5 and intraday>-2 and f['rv']>1.3 and reg['regime_score']>=40:
            out.append(('gap_and_go', f))
    if f['pullback_reclaim'] and f['rv']>1.0 and f['rs20']>-2:
        out.append(('pullback_reclaim', f))
    if f['rv']>2.5 and f['mom5']>12 and f['vol_accel']>1.4:
        out.append(('squeeze_ignition', f))
    if f['rv']>1.8 and f['vol_accel']>1.3 and f['dollar_volume']>5_000_000 and f['mom5']>4:
        out.append(('volume_expansion_followthrough', f))
    if strong_rs and f['above50'] and f['mom20']>8 and f['rv']>1.0:
        out.append(('relative_strength_leader', f))
    return out

def catalyst_score(ticker):
    themes=THEMES.get(ticker.upper(),[])
    score=0
    for t in themes:
        for word,val in CATALYST_WORDS.items():
            if word in t: score+=val
    return min(100, score), '|'.join(themes) if themes else 'none'

def bucket(score):
    if score>=65: return 'ELITE'
    if score>=50: return 'GOOD'
    if score>=35: return 'USABLE'
    return 'LOW'

def main():
    try:
        import yfinance  # dependency gate
    except Exception as e:
        print('[SEE] FATAL: yfinance is not installed in the active Python environment:', e)
        print('[SEE] Run ./install.sh, then ./run_backtest.sh again.')
        sys.exit(2)
    tickers=[x.strip().upper() for x in (sys.argv[1] if len(sys.argv)>1 else 'BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA').split(',') if x.strip()]
    period=sys.argv[2] if len(sys.argv)>2 else '2y'
    holds=[1,3,5,10,20]
    print('[SEE] Download benchmarks SPY/QQQ')
    spy_rows=download_prices('SPY',period); qqq_rows=download_prices('QQQ',period)
    bench_maps={}
    for name, rows in [('SPY',spy_rows),('QQQ',qqq_rows)]:
        bench_maps[name]={'_rows':rows,'_idx':{r['date']:i for i,r in enumerate(rows)}}
    trades=[]; regime_rows=[]
    for ticker in tickers:
        print(f'[SEE] Download {ticker} {period}')
        rows=download_prices(ticker,period)
        if len(rows)<80: continue
        cscore,themes=catalyst_score(ticker)
        tcount=0
        for i in range(60,len(rows)-max(holds)-1):
            reg=regime_for_date(rows[i]['date'], bench_maps['SPY'], bench_maps['QQQ'])
            if ticker==tickers[0] and i%20==0:
                regime_rows.append({'date':rows[i]['date'], **reg})
            for setup,f in signals(ticker,rows,i,bench_maps,reg):
                for h in holds:
                    r=ret(rows,i,h)
                    if r is None: continue
                    trades.append({'ticker':ticker,'date':rows[i]['date'],'setup':setup,'hold':f'{h}d','return_pct':round(r,4),'win':1 if r>0 else 0,'rv':round(f['rv'],3),'vol_accel':round(f['vol_accel'],3),'dollar_volume':round(f['dollar_volume'],0),'mom5':round(f['mom5'],3),'mom10':round(f['mom10'],3),'mom20':round(f['mom20'],3),'bench':f['bench'],'bench_mom20':round(f['bench_mom20'],3),'rs20':round(f['rs20'],3),'regime_score':reg['regime_score'],'regime_label':reg['regime_label'],'catalyst_score':cscore,'themes':themes})
                    tcount+=1
        print(f'[SEE] {ticker}: {tcount} trades')
    groups={}
    for tr in trades:
        key=(tr['ticker'],tr['setup'],tr['hold'])
        groups.setdefault(key,[]).append(tr)
    summary=[]
    for (ticker,setup,hold),trs in groups.items():
        n=len(trs); wins=sum(t['win'] for t in trs); avg=sum(t['return_pct'] for t in trs)/n
        winrate=wins/n*100
        cscore=trs[0]['catalyst_score']; themes=trs[0]['themes']
        avg_rs=sum(t['rs20'] for t in trs)/n
        avg_rv=sum(t['rv'] for t in trs)/n
        avg_regime=sum(t['regime_score'] for t in trs)/n
        risk_off_share=sum(1 for t in trs if t['regime_label']=='RISK_OFF')/n*100
        fake=1 if n<15 else 0
        confidence=min(100, n*2.0)
        rs_bonus=max(-10,min(16,avg_rs*0.9))
        vol_bonus=max(0,min(12,(avg_rv-1)*7))
        regime_bonus=(avg_regime-50)*0.18
        evidence=avg*2.0 + (winrate-50)*0.8 + min(n,50)*0.45 + cscore*0.08 + rs_bonus + vol_bonus + regime_bonus
        if fake: evidence-=25
        if risk_off_share>45: evidence-=8
        good=1 if n>=20 and winrate>=55 and avg>2 and evidence>=40 and risk_off_share<55 else 0
        elite=1 if n>=30 and winrate>=60 and avg>4 and evidence>=55 and avg_rs>0 and risk_off_share<45 else 0
        reason=[]
        if n<15: reason.append('tiny_sample_penalty')
        if setup=='momentum_continuation_legacy': reason.append('legacy_momentum_core')
        if setup in ('momentum_rs_continuation','relative_strength_leader'): reason.append('relative_strength_confirmed')
        if setup=='volume_expansion_followthrough': reason.append('volume_expansion')
        if cscore>=30: reason.append('theme_catalyst_boost')
        if avg>8: reason.append('high_expectancy')
        if avg_regime>=60: reason.append('risk_on_regime')
        if risk_off_share>45: reason.append('risk_off_penalty')
        summary.append({'ticker':ticker,'setup':setup,'hold':hold,'trades':n,'winrate':round(winrate,2),'avg_return_pct':round(avg,2),'expectancy_pct':round(avg,2),'evidence_score':round(evidence,2),'confidence':round(confidence,1),'avg_rs20':round(avg_rs,2),'avg_rv':round(avg_rv,2),'avg_regime_score':round(avg_regime,2),'risk_off_share':round(risk_off_share,2),'catalyst_score':cscore,'themes':themes,'fake_alpha_warning':fake,'good_candidate':good,'elite':elite,'tier':bucket(evidence),'rank_reason':', '.join(reason)})
    summary.sort(key=lambda x:(x['elite'],x['good_candidate'],x['evidence_score'],x['trades']), reverse=True)
    def write_csv(path, rows):
        if not rows: return
        with open(path,'w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    write_csv(EXPORTS/f'see_trades_{VERSION}.csv', trades)
    write_csv(EXPORTS/f'see_summary_{VERSION}.csv', summary)
    write_csv(EXPORTS/f'see_elite_{VERSION}.csv', [r for r in summary if r['elite']])
    write_csv(EXPORTS/f'see_usable_{VERSION}.csv', [r for r in summary if r['fake_alpha_warning']==0 and r['tier'] in ('USABLE','GOOD','ELITE')])
    def aggregate(field):
        agg={}
        for r in summary:
            k=r[field]; agg.setdefault(k,{'name':k,'rows':0,'trades':0,'good':0,'elite':0,'avg_evidence':0,'avg_expectancy':0,'avg_rs20':0,'avg_regime':0})
            a=agg[k]; a['rows']+=1; a['trades']+=int(r['trades']); a['good']+=int(r['good_candidate']); a['elite']+=int(r['elite']); a['avg_evidence']+=float(r['evidence_score']); a['avg_expectancy']+=float(r['expectancy_pct']); a['avg_rs20']+=float(r['avg_rs20']); a['avg_regime']+=float(r['avg_regime_score'])
        out=[]
        for a in agg.values():
            n=a['rows'];
            for k in ['avg_evidence','avg_expectancy','avg_rs20','avg_regime']:
                a[k]=round(a[k]/n,2)
            out.append(a)
        out.sort(key=lambda x:(x['elite'],x['good'],x['avg_evidence']), reverse=True)
        return out
    by_ticker=aggregate('ticker'); by_setup=aggregate('setup')
    write_csv(EXPORTS/f'see_by_ticker_{VERSION}.csv', by_ticker)
    write_csv(EXPORTS/f'see_by_setup_{VERSION}.csv', by_setup)
    write_csv(EXPORTS/f'see_engine_diagnostics_{VERSION}.csv', by_setup)
    write_csv(EXPORTS/f'see_regime_{VERSION}.csv', regime_rows)
    rs_rows=sorted([r for r in summary if r['trades']>=15], key=lambda x:x['avg_rs20'], reverse=True)[:100]
    write_csv(EXPORTS/f'see_relative_strength_{VERSION}.csv', rs_rows)
    state={'version':VERSION,'updated_at':datetime.now(timezone.utc).isoformat(),'summary_rows':len(summary),'trades':len(trades),'elite':sum(int(r['elite']) for r in summary),'good':sum(int(r['good_candidate']) for r in summary),'tickers':len(tickers),'top':summary[:30],'by_setup':by_setup,'by_ticker':by_ticker,'regime':regime_rows[-20:],'relative_strength':rs_rows[:30]}
    (DATA/'state.json').write_text(json.dumps(state,indent=2))
    with zipfile.ZipFile(EXPORTS/'all.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in EXPORTS.glob(f'*_{VERSION}.csv'):
            z.write(p,p.name)
    print(f'[SEE] Done. trades={len(trades)} summary_rows={len(summary)} elite={state["elite"]} good={state["good"]}')
if __name__=='__main__': main()
