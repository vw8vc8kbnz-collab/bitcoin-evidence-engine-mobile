# Stock Evidence Engine v1.2.1

Verified rebuild of v1.2.0 with the same working v1.1.0 deployment discipline.

## Added/verified
- Fixed version labels to v1.2.1.
- Root-only deploy structure: `server.py`, `engine.py`, `install.sh`, `run_backtest.sh`.
- No FastAPI/uvicorn dashboard runtime.
- Dashboard starts with `/usr/bin/python3 /home/ubuntu/stock_evidence_latest/server.py`.
- Backtests always run through `./venv/bin/python`.
- Includes a local `selftest.sh` for deployment/package sanity checks.

## Research additions from v1.2.x
- Relative Strength Engine vs SPY/QQQ.
- Volume Expansion Engine.
- Market Regime Filter.
- Extra exports: relative strength and regime CSVs inside `/exports/all.zip`.
