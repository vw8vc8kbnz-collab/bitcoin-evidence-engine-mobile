#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "[SEE selftest] cwd=$(pwd)"
for f in server.py engine.py install.sh run_backtest.sh requirements.txt VERSION; do
  test -f "$f" || { echo "[SEE selftest] missing $f"; exit 2; }
done
python3 -m py_compile server.py engine.py
grep -q "stock_evidence_latest/server.py" install.sh || { echo "[SEE selftest] install.sh service path not fixed baseline"; exit 2; }
grep -q "./venv/bin/python engine.py" run_backtest.sh || { echo "[SEE selftest] run_backtest does not use venv"; exit 2; }
echo "[SEE selftest] OK"
