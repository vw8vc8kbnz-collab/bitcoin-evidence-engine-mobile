# Stock Evidence Engine v1.2.1

Relative Strength + Volume Expansion + Regime Filter release.

- One dashboard runtime: `server.py`
- Port: `8798`
- Export ZIP: `/exports/all.zip`
- New exports: `see_relative_strength_v1.2.1.csv`, `see_regime_v1.2.1.csv`
- Backtest uses fixed `venv/bin/python` and fails loudly if dependencies are missing.

Run:
```bash
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN" "2y"
```
