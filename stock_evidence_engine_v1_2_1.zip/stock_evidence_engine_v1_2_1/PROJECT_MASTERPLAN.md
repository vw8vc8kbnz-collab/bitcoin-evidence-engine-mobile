# SEE v1.2.1 Masterplan

Goal: improve signal quality by adding measurable confirmation layers.

New in v1.2.1:
- Relative Strength Engine: compares candidates vs QQQ/SPY 20d momentum.
- Volume Expansion Engine: relative volume, volume acceleration, dollar volume confirmation.
- Regime Filter: SPY/QQQ trend regime and risk-off penalty.
- Dashboard tabs: Relative Strength and Regime.
- Exports for relative strength and regime audit.
