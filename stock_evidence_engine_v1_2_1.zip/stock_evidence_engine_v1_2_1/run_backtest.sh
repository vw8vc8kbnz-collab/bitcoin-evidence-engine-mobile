#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

TICKERS="${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN}"
PERIOD="${2:-2y}"

if [ ! -x "./venv/bin/python" ]; then
  echo "[SEE] venv missing; run ./install.sh first"
  exit 2
fi

./venv/bin/python - <<'PY'
import importlib.util, sys
if importlib.util.find_spec("yfinance") is None:
    print("[SEE] yfinance missing in venv; run ./install.sh first")
    sys.exit(2)
print("[SEE] yfinance dependency OK")
PY

./venv/bin/python engine.py "$TICKERS" "$PERIOD"
