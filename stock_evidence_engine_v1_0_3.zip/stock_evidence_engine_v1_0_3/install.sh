#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/home/ubuntu/stock_evidence_latest"
cd "$APP_DIR"
python3 -m venv venv
venv/bin/python -m pip install --upgrade pip
venv/bin/python -m pip install -r requirements.txt
mkdir -p data logs exports
cat >/etc/systemd/system/stock-evidence-dashboard.service <<SERVICE
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/python3 $APP_DIR/server.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable stock-evidence-dashboard.service
systemctl restart stock-evidence-dashboard.service
