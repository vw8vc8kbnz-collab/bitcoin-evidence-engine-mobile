# Stock Evidence Engine v1.0.3 Masterplan

Backtest-first stock alpha lab. v1.0.3 fixes deployment by using exactly one runtime and one systemd service path. It also improves ranking by penalizing tiny samples and showing confidence tiers.

Next: add news/catalyst research, ticker detail pages, export ZIP/TXT, ntfy after validated setups only.
