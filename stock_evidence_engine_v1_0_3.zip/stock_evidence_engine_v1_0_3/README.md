# Stock Evidence Engine v1.0.3

Clean VPS build. One runtime: `server.py` on port 8798 via stdlib HTTP server. No FastAPI/uvicorn service dependency.

Run:

```bash
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA" "2y"
```

Open: `http://SERVER_IP:8798`
