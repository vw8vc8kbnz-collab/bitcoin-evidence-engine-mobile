from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime
from html import escape
import json
from pathlib import Path
import sqlite3

PORT = 8798
DB = Path('data/see_results.sqlite')
VERSION='1.0.3'

def query():
    if not DB.exists():
        return [], {'rows':0,'trades':0,'avg':0,'positive':0,'usable':0}
    with sqlite3.connect(DB) as con:
        con.row_factory = sqlite3.Row
        rows = [dict(r) for r in con.execute('select * from summary order by usable desc, evidence_score desc, trades desc limit 80')]
        total_trades = con.execute('select count(*) c from trades').fetchone()['c']
    avg = sum(float(r.get('avg_return') or 0) for r in rows)/len(rows) if rows else 0
    positive = sum(1 for r in rows if float(r.get('avg_return') or 0) > 0)
    usable = sum(1 for r in rows if int(r.get('trades') or 0) >= 15)
    return rows, {'rows':len(rows),'trades':total_trades,'avg':avg,'positive':positive,'usable':usable}

CSS = """
body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#f3f6fb;color:#101827;margin:0;padding:18px 18px 80px}.hero{background:linear-gradient(135deg,#0d315b,#176da7);color:white;border-radius:28px;padding:28px 24px;margin:18px 0 24px;box-shadow:0 20px 50px rgba(13,49,91,.22)}.kicker{letter-spacing:.22em;color:#f8c954;font-weight:900;font-size:13px}.hero h1{font-size:42px;line-height:.95;margin:20px 0 12px}.hero p{font-size:21px;line-height:1.25;margin:0}.pill{display:inline-block;background:#ffd15a;color:#111827;border-radius:20px;padding:14px 22px;margin-top:22px;font-weight:900}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.metric{background:white;border-radius:24px;padding:24px 20px;box-shadow:0 12px 32px rgba(15,23,42,.07)}.metric .big{font-size:43px;font-weight:950;letter-spacing:-.04em}.metric small{color:#667085;font-size:18px;font-weight:800}.section{font-size:30px;margin:28px 0 14px}.tablewrap{overflow:auto;border-radius:20px;background:white;box-shadow:0 12px 32px rgba(15,23,42,.07)}table{border-collapse:collapse;width:100%;min-width:820px}th{background:#111827;color:white;text-align:left;padding:16px 14px;font-size:16px}td{padding:15px 14px;border-bottom:1px solid #e8edf5;font-size:16px}.ticker{font-weight:950}.badge{border-radius:999px;padding:6px 10px;font-weight:900;font-size:12px}.ok{background:#dcfce7;color:#166534}.weak{background:#fef3c7;color:#92400e}.low{background:#fee2e2;color:#991b1b}.footer{color:#667085;margin-top:20px;font-size:13px}@media(min-width:760px){body{max-width:900px;margin:auto}.hero h1{font-size:56px}.metric .big{font-size:54px}}
"""

def render():
    rows, m = query()
    body_rows = ''
    for r in rows:
        conf = str(r.get('confidence','LOW'))
        cls = 'ok' if conf == 'STRONG' else 'weak' if conf in ('GOOD','WEAK') else 'low'
        body_rows += f"<tr><td class='ticker'>{escape(str(r.get('ticker','')))}</td><td>{escape(str(r.get('setup','')))}</td><td>{int(r.get('hold_days') or 0)}d</td><td>{int(r.get('trades') or 0)}</td><td>{float(r.get('winrate') or 0)*100:.1f}%</td><td>{float(r.get('avg_return') or 0):.2f}%</td><td>{float(r.get('evidence_score') or 0):.1f}</td><td><span class='badge {cls}'>{escape(conf)}</span></td></tr>"
    if not body_rows:
        body_rows = "<tr><td colspan='8'>Nog geen resultaten. Run: ./run_backtest.sh \"BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA\" \"2y\"</td></tr>"
    return f"""<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>Stock Evidence Engine</title><style>{CSS}</style></head><body><div class='hero'><div class='kicker'>BACKTEST-FIRST STOCK ALPHA LAB</div><h1>Stock Evidence Engine</h1><p>Research vóór live signals — clean stdlib dashboard, vaste service, geen uvicorn/module gedoe.</p><div class='pill'>v{VERSION} · poort 8798</div></div><div class='grid'><div class='metric'><div class='big'>{m['rows']}</div><small>summary rows</small></div><div class='metric'><div class='big'>{m['trades']}</div><small>historical trades</small></div><div class='metric'><div class='big'>{m['avg']:.2f}%</div><small>avg expectancy</small></div><div class='metric'><div class='big'>{m['usable']}</div><small>usable samples ≥15</small></div></div><h2 class='section'>Beste evidence-resultaten</h2><div class='tablewrap'><table><thead><tr><th>Ticker</th><th>Setup</th><th>Hold</th><th>Trades</th><th>Winrate</th><th>Avg</th><th>Evidence</th><th>Confidence</th></tr></thead><tbody>{body_rows}</tbody></table></div><div class='footer'>Server time: {datetime.utcnow().isoformat()}Z · tiny-sample resultaten worden lager gerankt.</div></body></html>"""

class Handler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers()
    def do_GET(self):
        if self.path.startswith('/health'):
            data=json.dumps({'ok':True,'version':VERSION}).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        data=render().encode('utf-8'); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)

if __name__ == '__main__':
    HTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
