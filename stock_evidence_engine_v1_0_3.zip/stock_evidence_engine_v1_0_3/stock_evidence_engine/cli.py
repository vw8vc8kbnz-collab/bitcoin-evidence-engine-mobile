from __future__ import annotations
import sys
import pandas as pd
from .data.yahoo_client import download_history
from .engines.backtester import backtest_ticker, summarize
from .storage.db import write_tables


def main():
    tickers = (sys.argv[1] if len(sys.argv)>1 else 'BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA').split(',')
    period = sys.argv[2] if len(sys.argv)>2 else '2y'
    all_trades = []
    for t in [x.strip().upper() for x in tickers if x.strip()]:
        print(f'[SEE] Download {t} {period}', flush=True)
        df = download_history(t, period)
        tr = backtest_ticker(df)
        print(f'[SEE] {t}: {len(tr)} trades', flush=True)
        if not tr.empty:
            all_trades.append(tr)
    trades = pd.concat(all_trades, ignore_index=True) if all_trades else pd.DataFrame()
    summary = summarize(trades) if not trades.empty else pd.DataFrame()
    write_tables(trades, summary)
    print(f'[SEE] Done. trades={len(trades)} summary_rows={len(summary)}')

if __name__ == '__main__':
    main()
