from __future__ import annotations
import pandas as pd


def setup_signals(df: pd.DataFrame) -> list[dict]:
    rows = []
    if df.empty or len(df) < 60:
        return rows
    d = df.copy().reset_index(drop=True)
    for i in range(60, len(d)-1):
        r = d.iloc[i]
        prev = d.iloc[i-1]
        date = str(r['date'])[:10]
        ticker = r['ticker']
        if pd.notna(r.get('relvol')) and r['relvol'] >= 2.5 and r['close'] > r['ma20']:
            rows.append({'ticker': ticker, 'date': date, 'setup':'volume_breakout', 'entry': float(r['close'])})
        if pd.notna(r.get('ma50')) and pd.notna(prev.get('ma50')) and prev['close'] <= prev['ma50'] and r['close'] > r['ma50'] and r.get('relvol',0) >= 1.5:
            rows.append({'ticker': ticker, 'date': date, 'setup':'ma50_reclaim_volume', 'entry': float(r['close'])})
        if pd.notna(r.get('rsi14')) and pd.notna(prev.get('rsi14')) and prev['rsi14'] < 35 and r['rsi14'] >= 35 and r['close'] > prev['close']:
            rows.append({'ticker': ticker, 'date': date, 'setup':'rsi_recovery', 'entry': float(r['close'])})
        if pd.notna(r.get('ma20')) and pd.notna(r.get('ma50')) and r['close'] > r['ma20'] > r['ma50'] and r.get('relvol',0) >= 1.2 and r.get('ret_1d',0) > 0.02:
            rows.append({'ticker': ticker, 'date': date, 'setup':'momentum_continuation', 'entry': float(r['close'])})
    return rows
