from __future__ import annotations
import math
import pandas as pd
from .features import add_features
from .setups import setup_signals

HOLDS = [1,3,5,10,20]
FEE_SLIPPAGE = 0.004


def backtest_ticker(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    d = add_features(df).reset_index(drop=True)
    sigs = setup_signals(d)
    trades = []
    for sig in sigs:
        idxs = d.index[d['date'].astype(str).str[:10] == sig['date']].tolist()
        if not idxs:
            continue
        i = idxs[0]
        for hold in HOLDS:
            exit_i = i + hold
            if exit_i >= len(d):
                continue
            exit_price = float(d.iloc[exit_i]['close'])
            ret = (exit_price / sig['entry'] - 1.0) - FEE_SLIPPAGE
            trades.append({**sig, 'hold_days': hold, 'exit_date': str(d.iloc[exit_i]['date'])[:10], 'exit': exit_price, 'return_pct': ret*100, 'win': ret > 0})
    return pd.DataFrame(trades)


def summarize(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame()
    g = trades.groupby(['ticker','setup','hold_days']).agg(
        trades=('return_pct','count'),
        winrate=('win','mean'),
        avg_return=('return_pct','mean'),
        median_return=('return_pct','median'),
        best_return=('return_pct','max'),
        worst_return=('return_pct','min'),
    ).reset_index()
    # conservative confidence: sample size + expectancy + winrate, penalize tiny samples
    g['sample_score'] = (g['trades'].clip(0,50) / 50.0) * 100
    g['expectancy_score'] = (50 + g['avg_return'] * 5).clip(0,100)
    g['winrate_score'] = (g['winrate'] * 100).clip(0,100)
    g['evidence_score'] = (0.45*g['expectancy_score'] + 0.35*g['winrate_score'] + 0.20*g['sample_score']).round(1)
    g['confidence'] = pd.cut(g['trades'], bins=[-1,4,14,29,9999], labels=['LOW','WEAK','GOOD','STRONG'])
    g['usable'] = g['trades'] >= 15
    g = g.sort_values(['usable','evidence_score','trades'], ascending=[False,False,False])
    return g
