from __future__ import annotations
import pandas as pd


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()
    close = out['close']
    out['ret_1d'] = close.pct_change()
    out['ma20'] = close.rolling(20).mean()
    out['ma50'] = close.rolling(50).mean()
    out['ma200'] = close.rolling(200).mean()
    out['vol20'] = out['volume'].rolling(20).mean()
    out['relvol'] = out['volume'] / out['vol20']
    delta = close.diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, pd.NA)
    out['rsi14'] = 100 - (100 / (1 + rs))
    out['high20'] = close.rolling(20).max()
    out['low20'] = close.rolling(20).min()
    return out
