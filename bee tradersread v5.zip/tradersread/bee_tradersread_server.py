#!/usr/bin/env python3
"""
BEE Trader's Read — multi-timeframe chart-analyse.

Standalone webserver voor de VPS (eigen poort). Leest de chart zoals een
ervaren trader: per timeframe (1d / 4h / 1h) kijkt hij naar trendstructuur,
VWAP, RSI, voortschrijdende gemiddelden, belangrijke niveaus, volume en
break-of-structure. Geeft per timeframe een uitspraak in trader-taal, plus een
samenvattend oordeel — zoals analyses op X/Telegram.

GEEN verzonnen prijspercentage (dat signaal bestaat niet betrouwbaar). WEL een
onderbouwd trader-oordeel: bullish/bearish/neutraal opzet, met de condities en
niveaus die ertoe doen. Waar een gevalideerde engine vuurt, de echte winrate.

Start: python bee_tradersread_server.py
Open:  http://<vps-ip>:8200/?key=<token>
"""
import json, os, http.server, socketserver
from urllib.parse import urlparse, parse_qs
import urllib.request
import pandas as pd, numpy as np

PORT = int(os.environ.get("TRADERSREAD_PORT", "8200"))
ACCESS_KEY = os.environ.get("TRADERSREAD_KEY", "bee-change-me")
CSV_PATH = os.environ.get("TRADERSREAD_CSV",
    "/home/ubuntu/bitcoin-engine-deploy/current/data/BTC_alle_lagen_gecombineerd.csv")
HTML_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bee_tradersread.html")

_DF = None
def load_data():
    global _DF
    if _DF is not None: return _DF
    path = CSV_PATH
    if not os.path.exists(path) and os.path.exists(path + ".gz"): path += ".gz"
    df = pd.read_csv(path)
    df["dt"] = pd.to_datetime(df["dt"], utc=True, errors="coerce")
    df = df.sort_values("dt").reset_index(drop=True)
    _DF = df
    return df

def fetch_live_candles(tf):
    """De SERVER haalt de candles op (de VPS heeft geen browser-blokkades).
       Coinbase primair, Kraken backup. Coinbase staat alleen vaste granularities
       toe (60,300,900,3600,21600,86400) — 4h (14400) bestaat NIET, dus voor 4H
       halen we 1h op en bouwen we 4h-candles."""
    headers = {"User-Agent": "Mozilla/5.0 (BEE TradersRead)"}

    def coinbase(gran):
        url = f"https://api.exchange.coinbase.com/products/BTC-USD/candles?granularity={gran}"
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=8) as r:
            raw = json.loads(r.read().decode())
        data = [{"time": k[0], "low": k[1], "high": k[2], "open": k[3], "close": k[4]} for k in raw]
        data.sort(key=lambda x: x["time"])
        return data

    def aggregate(candles, factor):
        """Bundel N candles tot grotere (bv. 4x 1h -> 4h)."""
        out = []
        for i in range(0, len(candles) - factor + 1, factor):
            chunk = candles[i:i+factor]
            out.append({"time": chunk[0]["time"], "open": chunk[0]["open"],
                        "high": max(c["high"] for c in chunk),
                        "low": min(c["low"] for c in chunk),
                        "close": chunk[-1]["close"]})
        return out

    # Coinbase pad
    try:
        if tf == "1H":
            data = coinbase(3600)
        elif tf == "1D":
            data = coinbase(86400)
        elif tf == "4H":
            hourly = coinbase(3600)          # 1h candles
            data = aggregate(hourly, 4)       # bouw 4h
        else:
            data = coinbase(3600)
        if data:
            return {"source": "Coinbase", "candles": data, "price": data[-1]["close"]}
    except Exception:
        pass

    # Kraken backup (heeft wel echte 4h = interval 240)
    try:
        krint = {"1H": 60, "4H": 240, "1D": 1440}.get(tf, 60)
        url = f"https://api.kraken.com/0/public/OHLC?pair=XBTUSD&interval={krint}"
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=8) as r:
            j = json.loads(r.read().decode())
        key = [k for k in j["result"] if k != "last"][0]
        data = [{"time": int(k[0]), "open": float(k[1]), "high": float(k[2]),
                 "low": float(k[3]), "close": float(k[4])} for k in j["result"][key]]
        data.sort(key=lambda x: x["time"])
        if data:
            return {"source": "Kraken", "candles": data, "price": data[-1]["close"]}
    except Exception:
        pass
    return {"source": None, "candles": [], "price": None}


def _col(df, *names):
    for n in names:
        if n in df.columns: return n
    return None

def _rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0).rolling(period).mean()
    loss = (-delta.clip(upper=0)).rolling(period).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def resample_ohlc(hourly, rule):
    """Maak hogere timeframe candles uit hourly data."""
    h = hourly.set_index("dt")
    close = _col(hourly, "close", "close_raw")
    o = h[_col(hourly,"open")].resample(rule).first()
    hi = h[_col(hourly,"high")].resample(rule).max()
    lo = h[_col(hourly,"low")].resample(rule).min()
    cl = h[close].resample(rule).last()
    vol = h["volume"].resample(rule).sum()
    out = pd.DataFrame({"open":o,"high":hi,"low":lo,"close":cl,"volume":vol}).dropna()
    return out.reset_index()

def analyze_timeframe(candles, tf_label, lookback):
    """Analyseer één timeframe als een trader. candles: DataFrame met OHLCV, dt."""
    c = candles.tail(max(lookback, 220)).reset_index(drop=True)
    close = c["close"]
    price = float(close.iloc[-1])

    # --- Trend via MA's ---
    ma50 = close.rolling(50).mean().iloc[-1] if len(close) >= 50 else np.nan
    ma200 = close.rolling(200).mean().iloc[-1] if len(close) >= 200 else np.nan
    above50 = bool(price > ma50) if ma50 == ma50 else None
    above200 = bool(price > ma200) if ma200 == ma200 else None

    # --- Structuur: hogere highs/lows of lager? (swing-detectie) ---
    window = c.tail(lookback).reset_index(drop=True)
    highs = window["high"]; lows = window["low"]
    mid = len(window) // 2
    recent_high = highs.iloc[mid:].max(); prev_high = highs.iloc[:mid].max()
    recent_low = lows.iloc[mid:].min(); prev_low = lows.iloc[:mid].min()
    hh = recent_high > prev_high       # higher high
    hl = recent_low > prev_low         # higher low
    lh = recent_high < prev_high
    ll = recent_low < prev_low
    if hh and hl: structure = "opwaarts (higher highs & higher lows)"
    elif lh and ll: structure = "neerwaarts (lower highs & lower lows)"
    else: structure = "zijwaarts / onduidelijk"

    # --- Break of Structure: brak de prijs net de vorige swing? ---
    bos = None
    prior_swing_high = highs.iloc[:-1].max()
    prior_swing_low = lows.iloc[:-1].min()
    if price > prior_swing_high * 0.999:
        bos = "bullish BOS — prijs breekt boven vorige swing high"
    elif price < prior_swing_low * 1.001:
        bos = "bearish BOS — prijs breekt onder vorige swing low"

    # --- VWAP over de lookback (volume-gewogen) ---
    tp = (c["high"] + c["low"] + c["close"]) / 3
    vwap = (tp * c["volume"]).tail(lookback).sum() / c["volume"].tail(lookback).sum()
    dist_vwap = (price / vwap - 1) * 100

    # --- RSI ---
    rsi = _rsi(close).iloc[-1]

    # --- Niveaus: dichtstbijzijnde weerstand boven & steun onder ---
    resistance = float(highs[highs > price].min()) if (highs > price).any() else float(recent_high)
    support = float(lows[lows < price].max()) if (lows < price).any() else float(recent_low)

    # --- Volume: is de laatste beweging bevestigd? ---
    vol_now = c["volume"].iloc[-1]; vol_avg = c["volume"].tail(lookback).mean()
    vol_conf = vol_now > vol_avg * 1.2

    # --- Trader-oordeel per timeframe ---
    bull_points = 0; bear_points = 0; notes = []
    if above200: bull_points += 1; notes.append("boven MA200 (lange trend op)")
    elif above200 is False: bear_points += 1; notes.append("onder MA200 (lange trend neer)")
    if above50: bull_points += 1
    elif above50 is False: bear_points += 1
    if hh and hl: bull_points += 2; notes.append("opwaartse structuur")
    elif lh and ll: bear_points += 2; notes.append("neerwaartse structuur")
    if dist_vwap > 0: bull_points += 1; notes.append(f"boven VWAP (+{dist_vwap:.1f}%)")
    else: bear_points += 1; notes.append(f"onder VWAP ({dist_vwap:.1f}%)")
    if rsi == rsi:
        if rsi > 70: bear_points += 1; notes.append(f"RSI {rsi:.0f} overbought")
        elif rsi < 30: bull_points += 1; notes.append(f"RSI {rsi:.0f} oversold")
    if bos and "bullish" in bos: bull_points += 1
    if bos and "bearish" in bos: bear_points += 1

    if bull_points - bear_points >= 2: bias = "BULLISH"
    elif bear_points - bull_points >= 2: bias = "BEARISH"
    else: bias = "NEUTRAAL"

    return {
        "tf": tf_label, "price": round(price, 2), "bias": bias,
        "structure": structure, "bos": bos,
        "dist_vwap_pct": round(float(dist_vwap), 2), "vwap": round(float(vwap), 2),
        "rsi": None if rsi != rsi else round(float(rsi), 1),
        "above_ma50": above50, "above_ma200": above200,
        "support": round(support, 2), "resistance": round(resistance, 2),
        "volume_confirms": bool(vol_conf),
        "bull_points": bull_points, "bear_points": bear_points,
        "notes": notes,
    }

def build_read():
    df = load_data()
    close = _col(df, "close", "close_raw")
    # normaliseer kolomnaam voor resample
    if "close" not in df.columns and "close_raw" in df.columns:
        df = df.rename(columns={"close_raw": "close"})

    hourly = df.copy()
    daily = resample_ohlc(hourly, "1D")
    h4 = resample_ohlc(hourly, "4h")
    h1 = hourly[["dt","open","high","low","close","volume"]].copy()

    reads = [
        analyze_timeframe(daily, "1D", 30),
        analyze_timeframe(h4, "4H", 42),
        analyze_timeframe(h1, "1H", 48),
    ]

    # LIVE prijs ophalen (server-side, geen browser-blokkade)
    live = fetch_live_candles("1H")
    live_price = live.get("price")

    bias_score = sum({"BULLISH":1,"NEUTRAAL":0,"BEARISH":-1}[r["bias"]] for r in reads)
    aligned = len(set(r["bias"] for r in reads)) == 1
    if bias_score >= 2: overall = "BULLISH"
    elif bias_score <= -2: overall = "BEARISH"
    else: overall = "GEMENGD"

    htf, mtf, ltf = reads
    summary = _summarize(htf, mtf, ltf, overall, aligned)
    action = _action_plan(htf, mtf, ltf, overall, live_price)

    last = df.iloc[-1]
    fg = _col(df,"fear_greed"); fnd = _col(df,"funding_rate"); prm = _col(df,"coinbase_premium_pct")
    engine_hits = []
    fgv = None if pd.isna(last[fg]) else last[fg]
    fndv = None if pd.isna(last[fnd]) else last[fnd]
    prmv = None if pd.isna(last[prm]) else last[prm]
    if fgv is not None and fndv is not None and fgv < 30 and fndv < 0:
        engine_hits.append({"name":"Cycle Reversal","win":67,"horizon":"7d"})
    if prmv is not None and prmv > 0.1:
        engine_hits.append({"name":"Coinbase Premium","win":66,"horizon":"7d"})

    return {
        "now": {"price": round(float(live_price),2) if live_price else round(float(df["close"].iloc[-1]),2),
                "live": live_price is not None,
                "source": live.get("source"),
                "dt": str(last["dt"]),
                "fear_greed": None if fgv is None else int(fgv)},
        "timeframes": reads,
        "overall": overall, "aligned": bool(aligned),
        "summary": summary,
        "action": action,
        "engine_hits": engine_hits,
    }

def _action_plan(htf, mtf, ltf, overall, live_price):
    """Concreet trader-actieplan: wachten waarop, entry-zone, invalidatie."""
    px = live_price
    steps = []
    # bepaal sleutel-niveaus uit de hogere timeframes
    key_sup = htf["support"]; key_res = htf["resistance"]
    vwap_d = htf["vwap"]

    if overall == "BULLISH":
        if px and px > key_res:
            steps.append(f"Prijs ({px:,.0f}) brak al boven weerstand {key_res:,.0f} — bevestiging is er. "
                         "Wacht op een terugtest van dat niveau als steun voor een gunstigere entry.")
        else:
            steps.append(f"Beste aanpak: NIET nu kopen, maar wachten op een terugtest naar steun "
                         f"({key_sup:,.0f}) of de daily VWAP ({vwap_d:,.0f}). Daar is de risk/reward beter.")
        steps.append(f"Long-idee faalt (invalidatie) onder {ltf['support']:,.0f} op de 1H — daaronder klopt de opzet niet meer.")
        steps.append(f"Doel/weerstand om in de gaten te houden: {key_res:,.0f}.")
    elif overall == "BEARISH":
        steps.append(f"Geen long-conviction nu. Wacht tot de 4H-structuur draait (een higher high boven {mtf['resistance']:,.0f}) "
                     "voordat je longs overweegt.")
        if px:
            steps.append(f"Bounces richting weerstand ({key_res:,.0f}) of VWAP ({vwap_d:,.0f}) zijn zwak zolang de daily neerwaarts is.")
        steps.append(f"Pas als de prijs boven {key_res:,.0f} sluit en daar blijft, verandert het beeld.")
    else:
        steps.append("Gemengd beeld — dit is een geen-trade-zone. De timeframes spreken elkaar tegen.")
        steps.append(f"Wacht op uitlijning: ofwel een 1H-breuk boven {ltf['resistance']:,.0f} (bullish), "
                     f"ofwel onder {ltf['support']:,.0f} (bearish). Tot dan: geduld.")
        if htf["bias"] == "BULLISH":
            steps.append(f"De hogere timeframe (daily) is wel bullish, dus de kans leunt naar boven — "
                         f"een terugtest naar {htf['support']:,.0f} kan een kans worden als de 1H bevestigt.")
    return {"steps": steps}

def build_read_OLD():
    pass

def _old_unused():
    df = None

def _summarize(htf, mtf, ltf, overall, aligned):
    """Schrijf een trader-samenvatting zoals op X/Telegram."""
    parts = []
    parts.append(f"Daily: {htf['bias'].lower()}, {htf['structure']}, "
                 f"{'boven' if htf['dist_vwap_pct']>0 else 'onder'} VWAP, RSI {htf['rsi']}.")
    parts.append(f"4H: {mtf['bias'].lower()}, {mtf['structure']}"
                 + (f", {mtf['bos']}" if mtf['bos'] else "") + ".")
    parts.append(f"1H: {ltf['bias'].lower()}"
                 + (f", {ltf['bos']}" if ltf['bos'] else "") + ".")
    if aligned and overall == "BULLISH":
        verdict = ("Alle timeframes lijnen bullish op. Sterkste opzet: longs bij een "
                   f"terugtest naar steun ({htf['support']:,.0f}) of de VWAP. Idee faalt onder "
                   f"{ltf['support']:,.0f}.")
    elif aligned and overall == "BEARISH":
        verdict = ("Alle timeframes neerwaarts. Bounces naar weerstand "
                   f"({htf['resistance']:,.0f}) zijn zwak tot de structuur draait. "
                   "Geen long-conviction hier.")
    elif overall == "BULLISH":
        verdict = (f"Overwegend bullish, maar niet alle timeframes eens — de lagere "
                   f"timeframe loopt achter. Wacht op 1H-bevestiging boven "
                   f"{ltf['resistance']:,.0f} voor een long.")
    elif overall == "BEARISH":
        verdict = ("Overwegend bearish met een hogere-timeframe tegenwind. "
                   "Voorzichtig met longs tot de structuur op 4H draait.")
    else:
        verdict = ("Gemengd beeld — timeframes spreken elkaar tegen. Dit is een "
                   "geen-trade-zone; wacht tot de timeframes uitlijnen.")
    return {"lines": parts, "verdict": verdict}


class Handler(http.server.BaseHTTPRequestHandler):
    def _auth(self, qs): return qs.get("key",[""])[0] == ACCESS_KEY
    def do_GET(self):
        p = urlparse(self.path); qs = parse_qs(p.query)
        if p.path in ("/", "/index.html"):
            if not self._auth(qs):
                self.send_response(401); self.send_header("Content-Type","text/html"); self.end_headers()
                self.wfile.write(b"<h2>Toegang geweigerd</h2><p>Voeg ?key=TOKEN toe.</p>"); return
            try:
                with open(HTML_PATH,"rb") as f: body=f.read()
                self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8")
                self.end_headers(); self.wfile.write(body)
            except FileNotFoundError:
                self.send_response(500); self.end_headers(); self.wfile.write(b"html mist")
            return
        if p.path == "/api/candles":
            if not self._auth(qs):
                self.send_response(401); self.end_headers(); return
            try:
                tf = qs.get("tf", ["4H"])[0]
                body = json.dumps(fetch_live_candles(tf)).encode()
                self.send_response(200); self.send_header("Content-Type","application/json")
                self.send_header("Cache-Control","no-store")
                self.end_headers(); self.wfile.write(body)
            except Exception as e:
                self.send_response(500); self.send_header("Content-Type","application/json")
                self.end_headers(); self.wfile.write(json.dumps({"error":str(e)}).encode())
            return
        if p.path == "/api/read":
            if not self._auth(qs):
                self.send_response(401); self.end_headers(); return
            try:
                body = json.dumps(build_read()).encode()
                self.send_response(200); self.send_header("Content-Type","application/json")
                self.end_headers(); self.wfile.write(body)
            except Exception as e:
                import traceback; traceback.print_exc()
                self.send_response(500); self.send_header("Content-Type","application/json")
                self.end_headers(); self.wfile.write(json.dumps({"error":str(e)}).encode())
            return
        self.send_response(404); self.end_headers()
    def log_message(self,*a): pass

if __name__ == "__main__":
    print(f"Loading data from {CSV_PATH} ...")
    try: print(f"Loaded {len(load_data())} rows.")
    except Exception as e: print(f"WAARSCHUWING: {e}")
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
        print(f"Trader's Read op poort {PORT}.")
        httpd.serve_forever()
