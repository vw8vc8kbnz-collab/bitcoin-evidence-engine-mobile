# HANDOVER — Configurator Studio v1.1

## Definitieve richting

v1.1 is de Reliable Configurator Core, gebaseerd op het oorspronkelijke plan + Claude audit + fixes-file.

## Niet-onderhandelbare regels

1. AI/output mag nooit zelf facts bevestigen.
2. Confirmed facts vereisen user/admin/measured/import verification.
3. Maten/prijsinput mogen nooit op AI-schatting gebaseerd zijn.
4. Gate decisions zijn boolean/per critical field, niet score-based.
5. Model moet configureerbaar/segmenteerbaar zijn voordat builder/publish doorgaat.
6. Pricing Engine is de enige bron van prijs.
7. Rule Engine mag prijzen alleen activeren/deactiveren via pricing rules.
8. Runtime configs zijn immutable snapshots.
9. Elke schema/object is workspace/project scoped.
10. Customer UI verbergt interne provider- en architectuurdetails.

## v1.1 bevat

- Static premium UI.
- Builder Draft modal met click-to-action model.
- Context menu voor no-code acties.
- Simulatie van configureerbaar versus niet-configureerbaar model.
- Engine schemas in `engine/schemas`.
- Engine core functions in `engine/core`.
- Builder core in `engine/builder-core`.
- Job/ledger core in `engine/job-core`.
- Mock adapters in `engine/provider-adapters`.
- Smoke tests in `engine/tests/engine-smoke-test.js`.

## Testen

Run lokaal of op server in uitgepakte map:

```bash
node engine/tests/engine-smoke-test.js
```

of:

```bash
npm run test:engine
```

## Scope bewust niet in v1.1

- Geen echte externe provider calls.
- Geen echte foto-naar-3D generatie.
- Geen automatische match score als waarheid.
- Geen manual formula engine.
- Geen volledige Shopify app.
