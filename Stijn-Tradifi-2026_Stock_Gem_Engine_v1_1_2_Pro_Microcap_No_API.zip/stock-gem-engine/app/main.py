import os, json, time, threading, sqlite3, re
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

import requests
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

ROOT = Path('/home/ubuntu/stock-gem-engine') if Path('/home/ubuntu/stock-gem-engine').exists() else Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'; LOGS = ROOT / 'logs'
DATA.mkdir(parents=True, exist_ok=True); LOGS.mkdir(parents=True, exist_ok=True)
load_dotenv(ROOT / '.env')

APP_VERSION = '1.1.2-pro-microcap-dashboard-no-api'
PORT = int(os.getenv('APP_PORT','8791'))
NTFY_TOPIC = os.getenv('NTFY_TOPIC','Stijn-Tradifi-2026')
SCAN_INTERVAL_MINUTES = int(os.getenv('SCAN_INTERVAL_MINUTES','60'))
AUTO_SCAN_ENABLED = os.getenv('AUTO_SCAN_ENABLED','true').lower() == 'true'
DB = DATA / 'stock_gems.sqlite3'

AI_ENABLED = os.getenv('AI_ENABLED','false').lower() == 'true'
AI_PROVIDER = os.getenv('AI_PROVIDER','none').lower()
AI_FALLBACK_PROVIDER = os.getenv('AI_FALLBACK_PROVIDER','none').lower()
AI_MAX_PER_SCAN = int(os.getenv('AI_MAX_PER_SCAN','0'))
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY','').strip()
OPENAI_MODEL = os.getenv('OPENAI_MODEL','gpt-4.1-mini')
OPENAI_BASE_URL = os.getenv('OPENAI_BASE_URL','https://api.openai.com/v1').rstrip('/')
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY','').strip()
DEEPSEEK_MODEL = os.getenv('DEEPSEEK_MODEL','deepseek-reasoner')
DEEPSEEK_BASE_URL = os.getenv('DEEPSEEK_BASE_URL','https://api.deepseek.com').rstrip('/')

app = FastAPI(title='Stijn-Tradifi-2026 Stock Gem Engine', version=APP_VERSION)
state = {'running': False, 'last_scan': None, 'last_alerts': 0, 'last_ai_used': 0, 'error': None}

# ----------------------- basic infra -----------------------
def log(msg: str):
    try:
        LOGS.mkdir(parents=True, exist_ok=True)
        with open(LOGS / 'app.log', 'a', encoding='utf-8') as f:
            f.write(f"{datetime.now(timezone.utc).isoformat()} {msg}\n")
    except Exception:
        pass

def _ensure_columns(con: sqlite3.Connection):
    existing = {r[1] for r in con.execute('PRAGMA table_info(gems)').fetchall()}
    add = {
        'hidden_score':'REAL', 'accumulation_score':'REAL', 'narrative_score':'REAL',
        'dilution_risk_score':'REAL', 'conviction_score':'REAL',
        'conviction_label':'TEXT', 'scam_risk_label':'TEXT', 'ai_source':'TEXT',
        'ai_verdict':'TEXT', 'ai_confidence':'REAL', 'timeline_json':'TEXT',
        'ai_json':'TEXT', 'next_level_json':'TEXT'
    }
    for col, typ in add.items():
        if col not in existing:
            try: con.execute(f'ALTER TABLE gems ADD COLUMN {col} {typ}')
            except Exception as e: log(f'migration_column_error {col} {e}')

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute('''CREATE TABLE IF NOT EXISTS gems (
      ticker TEXT PRIMARY KEY, name TEXT, sector TEXT, country TEXT, exchange TEXT,
      mcap_usd REAL, mcap_source TEXT, mcap_confidence TEXT,
      gem_score REAL, early_signal REAL, hype_risk REAL, risk_score REAL,
      hidden_score REAL, accumulation_score REAL, narrative_score REAL,
      dilution_risk_score REAL, conviction_score REAL,
      conviction_label TEXT, scam_risk_label TEXT, ai_source TEXT,
      ai_verdict TEXT, ai_confidence REAL,
      company_short TEXT, why_attractive TEXT, risk_plain TEXT, catalyst_plain TEXT,
      broker_json TEXT, news_json TEXT, timeline_json TEXT, ai_json TEXT, next_level_json TEXT,
      first_seen TEXT, last_seen TEXT, alerted INTEGER DEFAULT 0
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS scan_runs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, count INTEGER, alerts INTEGER, note TEXT, ai_used INTEGER DEFAULT 0
    )''')
    _ensure_columns(con)
    return con

# ----------------------- universe / signals -----------------------
UNIVERSE: List[Dict[str, Any]] = [
 {'ticker':'DPRO','name':'Draganfly','sector':'Drones / Defense Tech','country':'Canada/US','exchange':'NASDAQ/CSE','mcap':187_000_000,'news':['Defense drone integration deals','Autonomous counter-UAS platform mentions','Slowly rising defense-drone narrative'],'price_30d':18,'volume_trend':1.35,'mentions':'low','dilution':'medium','reverse_splits':1,'offerings_24m':2},
 {'ticker':'PRZO','name':'ParaZero Technologies','sector':'Drone safety / Defense','country':'Israel/US','exchange':'NASDAQ','mcap':38_000_000,'news':['DefendAir net pod integration deal','Autonomous counter-UAS platform','Small contract/news cadence increasing'],'price_30d':-3,'volume_trend':1.65,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'QBTS','name':'D-Wave Quantum','sector':'Quantum computing','country':'Canada/US','exchange':'NYSE','mcap':1_900_000_000,'news':['Quantum adoption narrative','Enterprise optimization pilots'],'price_30d':42,'volume_trend':2.4,'mentions':'high','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'RGTI','name':'Rigetti Computing','sector':'Quantum computing','country':'US','exchange':'NASDAQ','mcap':2_100_000_000,'news':['Quantum hardware roadmap','Government research funding'],'price_30d':35,'volume_trend':2.1,'mentions':'high','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'KULR','name':'KULR Technology','sector':'Battery safety / Energy storage','country':'US','exchange':'NYSE American','mcap':410_000_000,'news':['Battery safety contracts','Defense/space thermal management','Revenue narrative improving'],'price_30d':21,'volume_trend':1.8,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'OPTT','name':'Ocean Power Technologies','sector':'Marine energy / Defense','country':'US','exchange':'NYSE American','mcap':34_000_000,'news':['Maritime surveillance buoys','Defense ocean monitoring','Tiny cap with defense/maritime optionality'],'price_30d':5,'volume_trend':1.25,'mentions':'low','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'ONDS','name':'Ondas Holdings','sector':'Autonomous drones / Networks','country':'US','exchange':'NASDAQ','mcap':92_000_000,'news':['Autonomous drone platform','Industrial private wireless','Multi-unit drone opportunity'],'price_30d':11,'volume_trend':1.45,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'LIDR','name':'AEye','sector':'LiDAR / Autonomy','country':'US','exchange':'NASDAQ','mcap':45_000_000,'news':['Automotive lidar pipeline','Industrial sensing applications'],'price_30d':-8,'volume_trend':1.1,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':3},
 {'ticker':'MVIS','name':'MicroVision','sector':'LiDAR / Automotive sensors','country':'US','exchange':'NASDAQ','mcap':260_000_000,'news':['ADAS sensor narrative','Strategic alternatives discussion'],'price_30d':14,'volume_trend':1.4,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'ASTI','name':'Ascent Solar Technologies','sector':'Thin-film solar / Space','country':'US','exchange':'NASDAQ','mcap':55_000_000,'news':['Lightweight solar modules','Aerospace/space application potential','Solar-space narrative still early'],'price_30d':9,'volume_trend':1.3,'mentions':'low','dilution':'high','reverse_splits':3,'offerings_24m':5},
 {'ticker':'BBAI','name':'BigBear.ai','sector':'AI / Defense analytics','country':'US','exchange':'NYSE','mcap':1_200_000_000,'news':['AI defense analytics','Government contract narrative'],'price_30d':28,'volume_trend':1.9,'mentions':'high','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'SOUN','name':'SoundHound AI','sector':'Voice AI','country':'US','exchange':'NASDAQ','mcap':3_100_000_000,'news':['Enterprise voice AI adoption','Automotive assistant traction'],'price_30d':39,'volume_trend':2.2,'mentions':'high','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'REKR','name':'Rekor Systems','sector':'AI infrastructure / Public safety','country':'US','exchange':'NASDAQ','mcap':180_000_000,'news':['Roadway intelligence platform','Public sector AI analytics','AI infrastructure laggard vs bigger AI names'],'price_30d':6,'volume_trend':1.28,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'KSCP','name':'Knightscope','sector':'Security robotics','country':'US','exchange':'NASDAQ','mcap':30_000_000,'news':['Autonomous security robots','Recurring security contracts','Robotics narrative but execution risk high'],'price_30d':-12,'volume_trend':0.95,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':4},
 {'ticker':'AISP','name':'Airship AI','sector':'AI video analytics','country':'US','exchange':'NASDAQ','mcap':140_000_000,'news':['Edge AI surveillance','Government/enterprise analytics','AI video analytics narrative early'],'price_30d':16,'volume_trend':1.55,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'GEVO','name':'Gevo','sector':'Sustainable aviation fuel','country':'US','exchange':'NASDAQ','mcap':420_000_000,'news':['SAF plant financing','Airline offtake agreements'],'price_30d':-2,'volume_trend':1.05,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'UUUU','name':'Energy Fuels','sector':'Uranium / Rare earths','country':'US/Canada','exchange':'NYSE American/TSX','mcap':1_050_000_000,'news':['Uranium cycle strength','Rare earth processing'],'price_30d':13,'volume_trend':1.3,'mentions':'medium','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'UEC','name':'Uranium Energy','sector':'Uranium','country':'US/Canada','exchange':'NYSE American','mcap':2_600_000_000,'news':['Uranium restart optionality','US nuclear fuel narrative'],'price_30d':15,'volume_trend':1.35,'mentions':'medium','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'HYSR','name':'SunHydrogen','sector':'Hydrogen research','country':'US','exchange':'OTC','mcap':65_000_000,'news':['Green hydrogen prototype','Research milestone watch'],'price_30d':4,'volume_trend':1.15,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':4},
 {'ticker':'CYBN','name':'Cybin','sector':'Biotech / Neuropsychiatry','country':'Canada/US','exchange':'NYSE American/NEO','mcap':370_000_000,'news':['Clinical-stage neuropsychiatry pipeline','Trial catalyst watch'],'price_30d':7,'volume_trend':1.25,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ATOS','name':'Atossa Therapeutics','sector':'Biotech / Oncology','country':'US','exchange':'NASDAQ','mcap':150_000_000,'news':['Breast cancer therapy trials','Clinical catalyst watch'],'price_30d':3,'volume_trend':1.1,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'TNYA','name':'Tenaya Therapeutics','sector':'Biotech / Gene therapy','country':'US','exchange':'NASDAQ','mcap':220_000_000,'news':['Cardiac gene therapy pipeline','Clinical readout watch'],'price_30d':-6,'volume_trend':1.05,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'EOSE','name':'Eos Energy Enterprises','sector':'Grid storage','country':'US','exchange':'NASDAQ','mcap':1_400_000_000,'news':['Long-duration storage demand','US manufacturing support'],'price_30d':26,'volume_trend':1.75,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'ABAT','name':'American Battery Technology','sector':'Battery recycling / Lithium','country':'US','exchange':'NASDAQ','mcap':120_000_000,'news':['Battery recycling ramp','Lithium resource development','Circular battery supply chain narrative'],'price_30d':10,'volume_trend':1.32,'mentions':'low','dilution':'medium','reverse_splits':1,'offerings_24m':2},
]


# Extra global nano/microcap universe: Canada/CSE/TSXV, UK AIM/LSE, Australia ASX, Europe/Euronext.
# These are not recommendations. They exist to force the scanner outside US/NASDAQ and surface lower-mcap research candidates.
UNIVERSE.extend([
 {'ticker':'FLT','name':'Volatus Aerospace','sector':'Drones / Defense services','country':'Canada','exchange':'TSXV','yahoo':['FLT.V','FLT.TO'],'mcap':42_000_000,'news':['Drone services and defense/security demand','Canadian listed smallcap drone exposure','Potential contracts can move a small valuation fast'],'price_30d':4,'volume_trend':1.22,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'NILI','name':'Surge Battery Metals','sector':'Lithium exploration','country':'Canada','exchange':'TSXV/OTC','yahoo':['NILI.V','NILIF'],'mcap':86_000_000,'news':['Lithium resource development','Battery supply chain narrative','Exploration/resource update optionality'],'price_30d':-2,'volume_trend':1.08,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'GRID','name':'Tantalus Systems','sector':'Grid intelligence / Utilities software','country':'Canada','exchange':'TSX','yahoo':['GRID.TO'],'mcap':58_000_000,'news':['Smart grid modernization','Utility software adoption','Tiny Canadian grid-tech candidate'],'price_30d':3,'volume_trend':1.16,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'QNC','name':'Quantum eMotion','sector':'Quantum cybersecurity','country':'Canada','exchange':'TSXV/OTC','yahoo':['QNC.V','QNCCF'],'mcap':30_000_000,'news':['Quantum cybersecurity narrative','Low coverage Canadian quantum exposure','Potential IP/cybersecurity catalyst'],'price_30d':6,'volume_trend':1.18,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'TAU','name':'Thesis Gold','sector':'Gold exploration','country':'Canada','exchange':'TSXV/OTC','yahoo':['TAU.V','THSGF'],'mcap':88_000_000,'news':['Resource expansion drilling','Gold cycle optionality','Explorer re-rating possible on strong drill results'],'price_30d':1,'volume_trend':1.06,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ARCM','name':'Arc Minerals','sector':'Copper exploration','country':'UK/Zambia','exchange':'AIM','yahoo':['ARCM.L'],'mcap':30_000_000,'news':['Copper exploration optionality','Major-partner/resource catalyst watch','Very low UK AIM coverage'],'price_30d':-4,'volume_trend':1.05,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'KOD','name':'Kodal Minerals','sector':'Lithium / Mining development','country':'UK/Mali','exchange':'AIM','yahoo':['KOD.L'],'mcap':120_000_000,'news':['Lithium development project','Project financing/development milestones','AIM battery-materials exposure'],'price_30d':8,'volume_trend':1.2,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ATM','name':'Andrada Mining','sector':'Tin / Lithium / Tantalum','country':'UK/Namibia','exchange':'AIM','yahoo':['ATM.L'],'mcap':70_000_000,'news':['Critical minerals narrative','Tin/lithium/tantalum optionality','Production ramp and resource update watch'],'price_30d':2,'volume_trend':1.12,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'GGP','name':'Greatland Gold','sector':'Gold / Copper development','country':'UK/Australia','exchange':'AIM','yahoo':['GGP.L'],'mcap':410_000_000,'news':['Gold/copper project development','Resource and development milestones','UK retail attention moderate but not US-pumped'],'price_30d':6,'volume_trend':1.18,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'LKE','name':'Lake Resources','sector':'Lithium development','country':'Australia/Argentina','exchange':'ASX/OTC','yahoo':['LKE.AX','LLKKF'],'mcap':85_000_000,'news':['Direct lithium extraction narrative','Project financing/offtake catalyst watch','ASX lithium smallcap turnaround candidate'],'price_30d':-5,'volume_trend':1.1,'mentions':'medium','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'ASN','name':'Anson Resources','sector':'Lithium / Brine development','country':'Australia/US','exchange':'ASX/OTC','yahoo':['ASN.AX','ANSNF'],'mcap':95_000_000,'news':['US lithium brine project','Battery minerals optionality','Permitting/resource catalyst watch'],'price_30d':3,'volume_trend':1.14,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'IXR','name':'Ionic Rare Earths','sector':'Rare earths / Recycling','country':'Australia/UK/Uganda','exchange':'ASX','yahoo':['IXR.AX'],'mcap':62_000_000,'news':['Rare earth supply chain narrative','Magnet recycling optionality','Western critical minerals theme'],'price_30d':2,'volume_trend':1.12,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'4DS','name':'4DS Memory','sector':'Semiconductor memory','country':'Australia','exchange':'ASX','yahoo':['4DS.AX'],'mcap':52_000_000,'news':['Next-gen memory R&D','Semiconductor optionality','High-risk IP milestone candidate'],'price_30d':7,'volume_trend':1.24,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'ALM','name':'Alma Gold','sector':'Gold exploration','country':'Europe/Canada','exchange':'CSE','yahoo':['ALMA.CN'],'mcap':12_000_000,'news':['Very low mcap gold explorer','Resource/drill-result optionality','Microcap exploration risk very high'],'price_30d':0,'volume_trend':0.95,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'MGA','name':'Mega Uranium','sector':'Uranium holdings / Exploration','country':'Canada/Australia','exchange':'TSX','yahoo':['MGA.TO'],'mcap':150_000_000,'news':['Uranium cycle exposure','Asset/holding revaluation potential','Not NASDAQ, lower coverage uranium angle'],'price_30d':5,'volume_trend':1.14,'mentions':'low','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'POND','name':'Pond Technologies','sector':'Carbon capture / Algae biotech','country':'Canada','exchange':'TSXV','yahoo':['POND.V'],'mcap':9_000_000,'news':['Carbon capture / algae platform','Very low valuation optionality','Needs funding and commercial validation'],'price_30d':-7,'volume_trend':1.02,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':4},
])



# v1.1.0 expanded low-market-cap research universe.
# No-API safe mode cannot literally verify every listed stock worldwide without a paid data feed,
# but this expands the scan toward nano/microcaps outside only-NASDAQ and adds company websites for DD.
UNIVERSE.extend([
 {'ticker':'POND','name':'Pond Technologies','sector':'Carbon capture / Algae biotech','country':'Canada','exchange':'TSXV','yahoo':['POND.V'],'website':'https://pondtech.com','mcap':9_000_000,'news':['Carbon capture / algae platform','Very low valuation optionality','Needs funding and commercial validation'],'price_30d':-7,'volume_trend':1.02,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':4},
 {'ticker':'HYSR','name':'SunHydrogen','sector':'Hydrogen research','country':'US','exchange':'OTC','website':'https://www.sunhydrogen.com','mcap':65_000_000,'news':['Green hydrogen prototype','Research milestone watch','Hydrogen narrative remains cyclical'],'price_30d':4,'volume_trend':1.15,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':4},
 {'ticker':'QNC','name':'Quantum eMotion','sector':'Quantum cybersecurity','country':'Canada','exchange':'TSXV/OTC','yahoo':['QNC.V','QNCCF'],'website':'https://www.quantumemotion.com','mcap':30_000_000,'news':['Quantum cybersecurity narrative','Low coverage Canadian quantum exposure','Potential IP/cybersecurity catalyst'],'price_30d':6,'volume_trend':1.18,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'4DS','name':'4DS Memory','sector':'Semiconductor memory','country':'Australia','exchange':'ASX','yahoo':['4DS.AX'],'website':'https://www.4dsmemory.com','mcap':52_000_000,'news':['Next-gen memory R&D','Semiconductor optionality','High-risk IP milestone candidate'],'price_30d':7,'volume_trend':1.24,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'ARCM','name':'Arc Minerals','sector':'Copper exploration','country':'UK/Zambia','exchange':'AIM','yahoo':['ARCM.L'],'website':'https://www.arcminerals.com','mcap':30_000_000,'news':['Copper exploration optionality','Major-partner/resource catalyst watch','Very low UK AIM coverage'],'price_30d':-4,'volume_trend':1.05,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ALMA','name':'Alma Gold','sector':'Gold exploration','country':'Canada','exchange':'CSE','yahoo':['ALMA.CN'],'website':'https://www.almagoldinc.com','mcap':12_000_000,'news':['Very low mcap gold explorer','Resource/drill-result optionality','Microcap exploration risk very high'],'price_30d':0,'volume_trend':0.95,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'OPTT','name':'Ocean Power Technologies','sector':'Marine energy / Defense','country':'US','exchange':'NYSE American','website':'https://oceanpowertechnologies.com','mcap':34_000_000,'news':['Maritime surveillance buoys','Defense ocean monitoring','Tiny cap with defense/maritime optionality'],'price_30d':5,'volume_trend':1.25,'mentions':'low','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'KSCP','name':'Knightscope','sector':'Security robotics','country':'US','exchange':'NASDAQ','website':'https://www.knightscope.com','mcap':30_000_000,'news':['Autonomous security robots','Recurring security contracts','Robotics narrative but execution risk high'],'price_30d':-12,'volume_trend':0.95,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':4},
 {'ticker':'LIDR','name':'AEye','sector':'LiDAR / Autonomy','country':'US','exchange':'NASDAQ','website':'https://www.aeye.ai','mcap':45_000_000,'news':['Automotive lidar pipeline','Industrial sensing applications'],'price_30d':-8,'volume_trend':1.1,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':3},
 {'ticker':'PRZO','name':'ParaZero Technologies','sector':'Drone safety / Defense','country':'Israel/US','exchange':'NASDAQ','website':'https://parazero.com','mcap':38_000_000,'news':['DefendAir net pod integration deal','Autonomous counter-UAS platform','Small contract/news cadence increasing'],'price_30d':-3,'volume_trend':1.65,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'ASTI','name':'Ascent Solar Technologies','sector':'Thin-film solar / Space','country':'US','exchange':'NASDAQ','website':'https://www.ascentsolar.com','mcap':55_000_000,'news':['Lightweight solar modules','Aerospace/space application potential','Solar-space narrative still early'],'price_30d':9,'volume_trend':1.3,'mentions':'low','dilution':'high','reverse_splits':3,'offerings_24m':5},
 {'ticker':'FLT','name':'Volatus Aerospace','sector':'Drones / Defense services','country':'Canada','exchange':'TSXV','yahoo':['FLT.V','FLT.TO'],'website':'https://volatusaerospace.com','mcap':42_000_000,'news':['Drone services and defense/security demand','Canadian listed smallcap drone exposure','Potential contracts can move a small valuation fast'],'price_30d':4,'volume_trend':1.22,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'IXR','name':'Ionic Rare Earths','sector':'Rare earths / Recycling','country':'Australia/UK/Uganda','exchange':'ASX','yahoo':['IXR.AX'],'website':'https://ionicre.com.au','mcap':62_000_000,'news':['Rare earth supply chain narrative','Magnet recycling optionality','Western critical minerals theme'],'price_30d':2,'volume_trend':1.12,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'GRID','name':'Tantalus Systems','sector':'Grid intelligence / Utilities software','country':'Canada','exchange':'TSX','yahoo':['GRID.TO'],'website':'https://www.tantalus.com','mcap':58_000_000,'news':['Smart grid modernization','Utility software adoption','Tiny Canadian grid-tech candidate'],'price_30d':3,'volume_trend':1.16,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'ASN','name':'Anson Resources','sector':'Lithium / Brine development','country':'Australia/US','exchange':'ASX/OTC','yahoo':['ASN.AX','ANSNF'],'website':'https://www.ansonresources.com','mcap':95_000_000,'news':['US lithium brine project','Battery minerals optionality','Permitting/resource catalyst watch'],'price_30d':3,'volume_trend':1.14,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'LKE','name':'Lake Resources','sector':'Lithium development','country':'Australia/Argentina','exchange':'ASX/OTC','yahoo':['LKE.AX','LLKKF'],'website':'https://lakeresources.com.au','mcap':85_000_000,'news':['Direct lithium extraction narrative','Project financing/offtake catalyst watch','ASX lithium smallcap turnaround candidate'],'price_30d':-5,'volume_trend':1.1,'mentions':'medium','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'NILI','name':'Surge Battery Metals','sector':'Lithium exploration','country':'Canada','exchange':'TSXV/OTC','yahoo':['NILI.V','NILIF'],'website':'https://surgebatterymetals.com','mcap':86_000_000,'news':['Lithium resource development','Battery supply chain narrative','Exploration/resource update optionality'],'price_30d':-2,'volume_trend':1.08,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'TAU','name':'Thesis Gold','sector':'Gold exploration','country':'Canada','exchange':'TSXV/OTC','yahoo':['TAU.V','THSGF'],'website':'https://thesisgold.com','mcap':88_000_000,'news':['Resource expansion drilling','Gold cycle optionality','Explorer re-rating possible on strong drill results'],'price_30d':1,'volume_trend':1.06,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ATM','name':'Andrada Mining','sector':'Tin / Lithium / Tantalum','country':'UK/Namibia','exchange':'AIM','yahoo':['ATM.L'],'website':'https://andradamining.com','mcap':70_000_000,'news':['Critical minerals narrative','Tin/lithium/tantalum optionality','Production ramp and resource update watch'],'price_30d':2,'volume_trend':1.12,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ARU','name':'Arafura Rare Earths','sector':'Rare earths','country':'Australia','exchange':'ASX','yahoo':['ARU.AX'],'website':'https://www.arultd.com','mcap':190_000_000,'news':['Rare earth supply chain narrative','Project financing and offtake milestones','Western critical minerals theme'],'price_30d':5,'volume_trend':1.12,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'RNU','name':'Renascor Resources','sector':'Graphite / Battery materials','country':'Australia','exchange':'ASX','yahoo':['RNU.AX'],'website':'https://renascor.com.au','mcap':155_000_000,'news':['Graphite supply chain narrative','Battery anode material optionality','Project financing catalyst watch'],'price_30d':1,'volume_trend':1.07,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'VUL','name':'Vulcan Energy Resources','sector':'Lithium / Geothermal','country':'Australia/Germany','exchange':'ASX','yahoo':['VUL.AX'],'website':'https://v-er.eu','mcap':620_000_000,'news':['Low-carbon lithium/geothermal narrative','EU battery supply chain','Project execution milestones'],'price_30d':4,'volume_trend':1.12,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'ROO','name':'Roots Sustainable Agricultural Technologies','sector':'AgriTech','country':'Israel/Australia','exchange':'ASX','yahoo':['ROO.AX'],'website':'https://www.rootsag.com','mcap':8_000_000,'news':['Agritech microcap optionality','Water/soil technology theme','Needs commercial traction proof'],'price_30d':-3,'volume_trend':0.9,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'CPH','name':'Creso Pharma / CPH group','sector':'Biotech / Wellness','country':'Australia','exchange':'ASX','yahoo':['CPH.AX'],'website':'https://www.cphgroup.com.au','mcap':18_000_000,'news':['Small biotech/wellness optionality','Corporate restructure watch','High-risk microcap with funding risk'],'price_30d':2,'volume_trend':1.02,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':4},
 {'ticker':'EGR','name':'EcoGraf','sector':'Graphite / Battery materials','country':'Australia/Tanzania','exchange':'ASX','yahoo':['EGR.AX'],'website':'https://www.ecograf.com.au','mcap':72_000_000,'news':['Battery graphite narrative','Tanzania project optionality','Downstream processing catalyst watch'],'price_30d':3,'volume_trend':1.08,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'EMH','name':'European Metals Holdings','sector':'Lithium development','country':'UK/Czech Republic','exchange':'AIM/ASX','yahoo':['EMH.L','EMH.AX'],'website':'https://www.europeanmet.com','mcap':38_000_000,'news':['EU lithium project','Strategic battery supply chain relevance','Project financing/permitting catalyst'],'price_30d':-4,'volume_trend':1.04,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'PRE','name':'Pensana','sector':'Rare earths','country':'UK/Angola','exchange':'LSE','yahoo':['PRE.L'],'website':'https://pensana.co.uk','mcap':55_000_000,'news':['Rare earth processing narrative','Supply chain independence theme','Financing and construction catalyst watch'],'price_30d':6,'volume_trend':1.16,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'TGR','name':'Tirupati Graphite','sector':'Graphite','country':'UK/Madagascar','exchange':'LSE','yahoo':['TGR.L'],'website':'https://www.tirupatigraphite.co.uk','mcap':20_000_000,'news':['Graphite production ramp','Battery material optionality','Needs balance sheet validation'],'price_30d':-6,'volume_trend':0.98,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'SAE','name':'SIMEC Atlantis Energy','sector':'Tidal energy / Storage','country':'UK','exchange':'AIM','yahoo':['SAE.L'],'website':'https://saerenewables.com','mcap':18_000_000,'news':['Tidal power optionality','Energy storage/development catalyst','Very high funding/execution risk'],'price_30d':4,'volume_trend':1.12,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':4},
 {'ticker':'HE1','name':'Helium One Global','sector':'Helium exploration','country':'UK/Tanzania','exchange':'AIM','yahoo':['HE1.L'],'website':'https://www.helium-one.com','mcap':75_000_000,'news':['Helium exploration narrative','Drilling/resource catalyst','High volatility AIM smallcap'],'price_30d':12,'volume_trend':1.5,'mentions':'medium','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'BHL','name':'Bradda Head Lithium','sector':'Lithium exploration','country':'UK/US','exchange':'AIM/OTC','yahoo':['BHL.L','BHLIF'],'website':'https://www.braddaheadltd.com','mcap':11_000_000,'news':['US lithium exploration','Tiny valuation optionality','Exploration/dilution risk high'],'price_30d':-1,'volume_trend':1.02,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'CYAN','name':'CyanConnode','sector':'Smart metering / IoT','country':'UK/India','exchange':'AIM','yahoo':['CYAN.L'],'website':'https://cyanconnode.com','mcap':32_000_000,'news':['Smart metering rollouts','India utility deployment theme','Contract-to-revenue conversion watch'],'price_30d':5,'volume_trend':1.17,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'ENET','name':'Ethernity Networks','sector':'Networking / Edge infrastructure','country':'Israel/UK','exchange':'AIM','yahoo':['ENET.L'],'website':'https://ethernitynet.com','mcap':7_000_000,'news':['Edge networking turnaround candidate','Contract/order timing can move microcap','Very high balance-sheet risk'],'price_30d':9,'volume_trend':1.28,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':5},
 {'ticker':'AIML','name':'AI/ML Innovations','sector':'AI healthcare / Digital health','country':'Canada','exchange':'CSE','yahoo':['AIML.CN'],'website':'https://www.aiml-innovations.com','mcap':10_000_000,'news':['AI healthcare narrative','Tiny Canadian AI exposure','Needs real revenue proof'],'price_30d':3,'volume_trend':1.11,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'DME','name':'Desert Mountain Energy','sector':'Helium / Industrial gases','country':'Canada/US','exchange':'TSXV/OTC','yahoo':['DME.V','DMEHF'],'website':'https://desertmountainenergy.com','mcap':28_000_000,'news':['Helium production optionality','Industrial gas supply narrative','Execution/cash-flow validation needed'],'price_30d':-2,'volume_trend':1.05,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'HPQ','name':'HPQ Silicon','sector':'Silicon / Battery materials','country':'Canada','exchange':'TSXV/OTC','yahoo':['HPQ.V','HPQFF'],'website':'https://hpqsilicon.com','mcap':52_000_000,'news':['Silicon battery material narrative','Clean-tech process optionality','Commercial validation catalyst'],'price_30d':1,'volume_trend':1.06,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'NGEN','name':'NervGen Pharma','sector':'Biotech / Regenerative medicine','country':'Canada','exchange':'TSXV/OTC','yahoo':['NGEN.V','NGENF'],'website':'https://nervgen.com','mcap':160_000_000,'news':['Clinical-stage regenerative medicine','Trial milestone optionality','Biotech binary risk'],'price_30d':2,'volume_trend':1.09,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'PYR','name':'PyroGenesis Canada','sector':'Plasma / Industrial tech','country':'Canada','exchange':'TSX/NASDAQ','yahoo':['PYR.TO','PYR'],'website':'https://www.pyrogenesis.com','mcap':80_000_000,'news':['Plasma process technology','Defense/industrial customer optionality','Revenue conversion must be proven'],'price_30d':7,'volume_trend':1.23,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'ESE','name':'ESE Entertainment','sector':'Gaming / Esports services','country':'Canada/Europe','exchange':'TSXV/OTC','yahoo':['ESE.V','ENTEF'],'website':'https://esegaming.com','mcap':12_000_000,'news':['Esports/gaming services microcap','Potential contract cadence','Needs profitability proof'],'price_30d':1,'volume_trend':1.0,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'SERN','name':'Sernova','sector':'Biotech / Cell therapy','country':'Canada','exchange':'TSX/OTC','yahoo':['SVA.TO','SEOVF'],'website':'https://www.sernova.com','mcap':140_000_000,'news':['Cell pouch therapy platform','Clinical milestone optionality','Funding and clinical execution risk'],'price_30d':-3,'volume_trend':1.08,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'MDCX','name':'Medicus Pharma','sector':'Biotech / Dermatology','country':'Canada/US','exchange':'TSXV/NASDAQ','yahoo':['MDCX','MDCX.V'],'website':'https://medicuspharma.com','mcap':45_000_000,'news':['Clinical dermatology asset','Smallcap biotech milestone potential','Binary clinical/funding risk'],'price_30d':4,'volume_trend':1.12,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
])


# v1.1.1 expanded nano/microcap research universe.
# Research candidates only; not recommendations. Curated mcaps are low-confidence fallbacks; live Yahoo overrides where available.
UNIVERSE.extend([
 {'ticker':'WKEY','name':'WISeKey International','sector':'Cybersecurity / IoT / Semiconductors','country':'Switzerland/US','exchange':'NASDAQ/SIX','yahoo':['WKEY','WIHN.SW'],'website':'https://www.wisekey.com','mcap':18_000_000,'news':['Cybersecurity and IoT identity narrative','Semiconductor/security optionality','Tiny valuation can rerate on credible contracts'],'price_30d':-4,'volume_trend':1.12,'mentions':'low','dilution':'medium','reverse_splits':2,'offerings_24m':2},
 {'ticker':'MRIN','name':'Marin Software','sector':'Adtech / AI marketing software','country':'US','exchange':'NASDAQ','website':'https://www.marinsoftware.com','mcap':12_000_000,'news':['AI marketing software narrative','Ad automation tools','Low market cap software optionality'],'price_30d':-9,'volume_trend':1.05,'mentions':'low','dilution':'high','reverse_splits':2,'offerings_24m':3},
 {'ticker':'WINT','name':'Windtree Therapeutics','sector':'Biotech / Cardiopulmonary','country':'US','exchange':'NASDAQ','website':'https://www.windtreetx.com','mcap':9_000_000,'news':['Clinical-stage biotech catalyst watch','Very low valuation vs pipeline optionality','High financing risk must be checked'],'price_30d':-11,'volume_trend':1.22,'mentions':'low','dilution':'high','reverse_splits':3,'offerings_24m':5},
 {'ticker':'PALI','name':'Palisade Bio','sector':'Biotech / Gastrointestinal','country':'US','exchange':'NASDAQ','website':'https://www.palisadebio.com','mcap':10_000_000,'news':['Biotech pipeline catalyst optionality','Small float / tiny market cap profile','Needs cash runway and trial data verification'],'price_30d':-7,'volume_trend':1.18,'mentions':'low','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'SINT','name':'SINTX Technologies','sector':'Advanced materials / Medical ceramics','country':'US','exchange':'NASDAQ','website':'https://sintx.com','mcap':8_000_000,'news':['Advanced ceramics and defense/medical applications','Tiny market cap materials optionality','Commercial traction must be verified'],'price_30d':-15,'volume_trend':1.15,'mentions':'low','dilution':'high','reverse_splits':4,'offerings_24m':5},
 {'ticker':'IMNN','name':'Imunon','sector':'Biotech / Oncology immunotherapy','country':'US','exchange':'NASDAQ','website':'https://www.imunon.com','mcap':14_000_000,'news':['Clinical oncology catalyst watch','Immunotherapy narrative','Smallcap biotech asymmetric setup if data improves'],'price_30d':2,'volume_trend':1.09,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':3},
 {'ticker':'INM','name':'InMed Pharmaceuticals','sector':'Biotech / Cannabinoid medicines','country':'Canada/US','exchange':'NASDAQ','website':'https://www.inmedpharma.com','mcap':6_000_000,'news':['Rare cannabinoid pharmaceutical platform','Tiny valuation vs pipeline optionality','High cash/dilution risk'],'price_30d':-18,'volume_trend':1.04,'mentions':'low','dilution':'high','reverse_splits':3,'offerings_24m':5},
 {'ticker':'GNPX','name':'Genprex','sector':'Biotech / Gene therapy oncology','country':'US','exchange':'NASDAQ','website':'https://www.genprex.com','mcap':11_000_000,'news':['Gene therapy oncology platform','Clinical catalyst watch','Very speculative biotech optionality'],'price_30d':-6,'volume_trend':1.14,'mentions':'low','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'SNGX','name':'Soligenix','sector':'Biotech / Rare disease','country':'US','exchange':'NASDAQ','website':'https://www.soligenix.com','mcap':7_000_000,'news':['Rare disease and public-health pipeline','Regulatory/catalyst optionality','Needs financing and trial verification'],'price_30d':1,'volume_trend':1.11,'mentions':'low','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'JAGX','name':'Jaguar Health','sector':'Biotech / GI therapeutics','country':'US','exchange':'NASDAQ','website':'https://jaguar.health','mcap':13_000_000,'news':['GI therapy commercialization watch','Ultra-small cap with catalyst optionality','Significant dilution history risk'],'price_30d':-12,'volume_trend':1.26,'mentions':'medium','dilution':'high','reverse_splits':4,'offerings_24m':6},
 {'ticker':'BCLI','name':'BrainStorm Cell Therapeutics','sector':'Biotech / Neurodegenerative disease','country':'US/Israel','exchange':'NASDAQ','website':'https://brainstorm-cell.com','mcap':16_000_000,'news':['Neurodegenerative disease therapy watch','Regulatory path uncertainty','Tiny biotech optionality with high binary risk'],'price_30d':-5,'volume_trend':1.10,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':3},
 {'ticker':'MULN','name':'Mullen Automotive','sector':'EV / Commercial vehicles','country':'US','exchange':'NASDAQ','website':'https://www.mullenusa.com','mcap':18_000_000,'news':['EV/commercial vehicle narrative','Possible high attention on small valuation','Heavy dilution/reverse split risk must dominate score'],'price_30d':-20,'volume_trend':1.40,'mentions':'high','dilution':'high','reverse_splits':5,'offerings_24m':8},
 {'ticker':'CEI','name':'Camber Energy','sector':'Energy / Power systems','country':'US','exchange':'NYSE American','website':'https://www.camber.energy','mcap':17_000_000,'news':['Energy infrastructure optionality','Very speculative turnaround watch','High governance/dilution risk check needed'],'price_30d':-10,'volume_trend':1.18,'mentions':'medium','dilution':'high','reverse_splits':2,'offerings_24m':5},
 {'ticker':'IMPP','name':'Imperial Petroleum','sector':'Shipping / Tankers','country':'Greece/US','exchange':'NASDAQ','website':'https://www.imperialpetro.com','mcap':19_000_000,'news':['Shipping rate cycle optionality','Very small valuation vs fleet narrative','Share issuance and governance risk check needed'],'price_30d':3,'volume_trend':1.12,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':4},
 {'ticker':'TOPS','name':'TOP Ships','sector':'Shipping / Tankers','country':'Greece/US','exchange':'NASDAQ','website':'https://www.topships.org','mcap':8_000_000,'news':['Tanker cycle optionality','Nano-cap shipping speculation','Very high dilution/reverse-split history risk'],'price_30d':-4,'volume_trend':1.08,'mentions':'medium','dilution':'high','reverse_splits':6,'offerings_24m':6},
 {'ticker':'GLBS','name':'Globus Maritime','sector':'Shipping / Dry bulk','country':'Greece/US','exchange':'NASDAQ','website':'https://www.globusmaritime.gr','mcap':30_000_000,'news':['Dry bulk cycle optionality','Tiny listed shipping exposure','Governance and dilution must be checked'],'price_30d':2,'volume_trend':1.04,'mentions':'low','dilution':'medium','reverse_splits':2,'offerings_24m':2},
 {'ticker':'CERO','name':'CERo Therapeutics','sector':'Biotech / Cell therapy','country':'US','exchange':'NASDAQ','website':'https://www.cero.bio','mcap':12_000_000,'news':['Cell therapy platform optionality','Clinical-stage catalyst watch','High financing/binary risk profile'],'price_30d':-14,'volume_trend':1.20,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':3},
 {'ticker':'RNAZ','name':'TransCode Therapeutics','sector':'Biotech / RNA oncology','country':'US','exchange':'NASDAQ','website':'https://www.transcodetherapeutics.com','mcap':9_000_000,'news':['RNA oncology platform','Clinical catalyst optionality','Very high financing risk'],'price_30d':-8,'volume_trend':1.19,'mentions':'low','dilution':'high','reverse_splits':3,'offerings_24m':5},
 {'ticker':'VERB','name':'Verb Technology','sector':'Social commerce / livestream software','country':'US','exchange':'NASDAQ','website':'https://www.verb.tech','mcap':14_000_000,'news':['Livestream commerce narrative','Software turnaround optionality','Execution and dilution risk high'],'price_30d':4,'volume_trend':1.30,'mentions':'medium','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'MOB','name':'Mobilicom','sector':'Cybersecurity / Drone communications','country':'Israel/US','exchange':'NASDAQ','website':'https://mobilicom.com','mcap':22_000_000,'news':['Drone/cybersecure communications','Defense-drone narrative exposure','Smallcap with contract-driven rerating potential'],'price_30d':7,'volume_trend':1.28,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'AUID','name':'authID','sector':'Identity verification / Cybersecurity','country':'US','exchange':'NASDAQ','website':'https://www.authid.ai','mcap':45_000_000,'news':['Identity verification / fraud prevention','AI identity narrative','Needs revenue acceleration proof'],'price_30d':6,'volume_trend':1.16,'mentions':'low','dilution':'medium','reverse_splits':1,'offerings_24m':2},
 {'ticker':'BMTX','name':'BM Technologies','sector':'Fintech / Banking-as-a-service','country':'US','exchange':'NYSE American','website':'https://www.bmtx.com','mcap':38_000_000,'news':['Fintech turnaround watch','Banking-as-a-service optionality','Regulatory and execution risk'],'price_30d':1,'volume_trend':1.03,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'VLCN','name':'Volcon','sector':'EV / Powersports','country':'US','exchange':'NASDAQ','website':'https://www.volcon.com','mcap':5_000_000,'news':['Electric powersports turnaround speculation','Very low valuation','Severe dilution/reverse-split risk dominates'],'price_30d':-22,'volume_trend':1.25,'mentions':'medium','dilution':'high','reverse_splits':5,'offerings_24m':7},
 {'ticker':'KAVL','name':'Kaival Brands','sector':'Consumer products / Distribution','country':'US','exchange':'NASDAQ','website':'https://www.kaivalbrands.com','mcap':17_000_000,'news':['Distribution turnaround watch','Low valuation consumer product optionality','Regulatory/market concentration risk'],'price_30d':-3,'volume_trend':1.07,'mentions':'low','dilution':'medium','reverse_splits':1,'offerings_24m':2},
 {'ticker':'CNSP','name':'CNS Pharmaceuticals','sector':'Biotech / Oncology','country':'US','exchange':'NASDAQ','website':'https://www.cnspharma.com','mcap':4_000_000,'news':['Oncology trial catalyst watch','Ultra-nano-cap biotech optionality','Extreme financing/binary risk'],'price_30d':-15,'volume_trend':1.09,'mentions':'low','dilution':'high','reverse_splits':4,'offerings_24m':6},
 {'ticker':'NUWE','name':'Nuwellis','sector':'Medical devices / Fluid management','country':'US','exchange':'NASDAQ','website':'https://www.nuwellis.com','mcap':6_000_000,'news':['Medical device adoption watch','Hospital sales execution optionality','High financing/reverse split risk'],'price_30d':-10,'volume_trend':1.05,'mentions':'low','dilution':'high','reverse_splits':4,'offerings_24m':5},
 {'ticker':'TIVC','name':'Tivic Health','sector':'Medical devices / Bioelectronic medicine','country':'US','exchange':'NASDAQ','website':'https://tivichealth.com','mcap':7_000_000,'news':['Bioelectronic medicine narrative','Device commercialization watch','Very small cap with high execution risk'],'price_30d':-6,'volume_trend':1.12,'mentions':'low','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'EDBL','name':'Edible Garden','sector':'Food / Controlled environment agriculture','country':'US','exchange':'NASDAQ','website':'https://ediblegardenag.com','mcap':6_000_000,'news':['Controlled environment agriculture','Retail distribution watch','Thin margins and dilution risk high'],'price_30d':-13,'volume_trend':1.08,'mentions':'low','dilution':'high','reverse_splits':3,'offerings_24m':5},
 {'ticker':'MTEK','name':'Maris-Tech','sector':'Defense video / Edge AI','country':'Israel/US','exchange':'NASDAQ','website':'https://www.maris-tech.com','mcap':18_000_000,'news':['Defense video and edge AI narrative','Small Israeli defense-tech exposure','Contract cadence can rerate a tiny base'],'price_30d':8,'volume_trend':1.21,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'CISO','name':'CISO Global','sector':'Cybersecurity services','country':'US','exchange':'NASDAQ','website':'https://www.ciso.inc','mcap':16_000_000,'news':['Cybersecurity services turnaround','AI/security narrative','Balance sheet and dilution must be checked'],'price_30d':-9,'volume_trend':1.10,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':3},
 {'ticker':'DSS','name':'DSS Inc.','sector':'Holding company / Packaging / Healthcare','country':'US','exchange':'NYSE American','website':'https://www.dssworld.com','mcap':9_000_000,'news':['Microcap holding-company optionality','Asset-value rerating watch','Complex structure requires extra DD'],'price_30d':-5,'volume_trend':1.04,'mentions':'low','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'IZEA','name':'IZEA Worldwide','sector':'Creator economy / Marketing software','country':'US','exchange':'NASDAQ','website':'https://izea.com','mcap':36_000_000,'news':['Creator economy software','AI content/marketing workflow angle','Profitability and revenue growth check'],'price_30d':2,'volume_trend':1.09,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'FATH','name':'Fathom Digital Manufacturing','sector':'Advanced manufacturing / 3D printing','country':'US','exchange':'NYSE','website':'https://fathommfg.com','mcap':18_000_000,'news':['Advanced manufacturing / 3D printing narrative','Reshoring and industrial demand optionality','Debt/liquidity risk must be checked'],'price_30d':-2,'volume_trend':1.06,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'VLD','name':'Velo3D','sector':'3D printing / Aerospace manufacturing','country':'US','exchange':'NYSE','website':'https://velo3d.com','mcap':25_000_000,'news':['Aerospace additive manufacturing','Turnaround optionality','Cash runway and debt risk high'],'price_30d':-12,'volume_trend':1.17,'mentions':'medium','dilution':'high','reverse_splits':1,'offerings_24m':4},
 {'ticker':'NEXI','name':'NexImmune','sector':'Biotech / Immunotherapy','country':'US','exchange':'OTC','website':'https://www.neximmune.com','mcap':5_000_000,'news':['Immunotherapy platform optionality','OTC/illiquid turnaround watch','Very high distress/liquidity risk'],'price_30d':-20,'volume_trend':0.9,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':4},
 {'ticker':'POND','name':'Pond Technologies','sector':'Carbon capture / Algae biotech','country':'Canada','exchange':'TSXV','yahoo':['POND.V'],'website':'https://pondtech.com','mcap':8_000_000,'news':['Carbon utilization and algae platform','Low valuation climate-tech optionality','Commercial scale proof needed'],'price_30d':2,'volume_trend':1.05,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'XTM','name':'XTM Inc.','sector':'Fintech / Earned wage access','country':'Canada','exchange':'CSE/OTC','yahoo':['PAID.CN'],'website':'https://www.xtminc.com','mcap':7_000_000,'news':['Fintech/payments optionality','Tiny Canadian fintech turnaround','Needs revenue and financing verification'],'price_30d':-4,'volume_trend':1.04,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'NEXE','name':'NEXE Innovations','sector':'Sustainable packaging','country':'Canada','exchange':'TSXV/OTC','yahoo':['NEXE.V','NEXNF'],'website':'https://nexeinnovations.com','mcap':18_000_000,'news':['Compostable packaging narrative','Commercial production ramp watch','Smallcap ESG/materials optionality'],'price_30d':1,'volume_trend':1.07,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'RDN','name':'Raiden Resources','sector':'Lithium / Gold exploration','country':'Australia','exchange':'ASX','yahoo':['RDN.AX'],'website':'https://raidenresources.com.au','mcap':16_000_000,'news':['Lithium/gold exploration optionality','Drill result catalyst watch','Very speculative explorer risk'],'price_30d':5,'volume_trend':1.18,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'FAB','name':'Fusion Antibodies','sector':'Biotech tools / Antibodies','country':'UK','exchange':'AIM','yahoo':['FAB.L'],'website':'https://www.fusionantibodies.com','mcap':9_000_000,'news':['Biotech services turnaround','Antibody discovery services','Revenue recovery and financing check'],'price_30d':1,'volume_trend':1.05,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'SAE','name':'SIMEC Atlantis Energy','sector':'Tidal energy / Renewables','country':'UK','exchange':'AIM','yahoo':['SAE.L'],'website':'https://saerenewables.com','mcap':18_000_000,'news':['Tidal power and storage optionality','Renewables infrastructure narrative','Debt/project financing risk check'],'price_30d':3,'volume_trend':1.07,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'EQTEC','name':'EQTEC','sector':'Waste-to-energy / Cleantech','country':'Ireland/UK','exchange':'AIM','yahoo':['EQT.L'],'website':'https://eqtec.com','mcap':10_000_000,'news':['Waste-to-energy gasification narrative','Cleantech microcap optionality','Project execution and financing risk'],'price_30d':-2,'volume_trend':1.03,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':3},
 {'ticker':'N4P','name':'N4 Pharma','sector':'Biotech / Drug delivery','country':'UK','exchange':'AIM','yahoo':['N4P.L'],'website':'https://www.n4pharma.com','mcap':5_000_000,'news':['Drug delivery platform optionality','Tiny biotech research catalyst','Financing and data risk high'],'price_30d':-1,'volume_trend':1.04,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'BSFA','name':'BSF Enterprise','sector':'Biotech / Cellular agriculture','country':'UK','exchange':'LSE','yahoo':['BSFA.L'],'website':'https://bsfenterprise.com','mcap':7_000_000,'news':['Cellular agriculture / biotech narrative','Very early-stage optionality','Commercial proof required'],'price_30d':2,'volume_trend':1.05,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ALK','name':'Alkemy Capital Investments','sector':'Lithium refining / Battery materials','country':'UK','exchange':'LSE','yahoo':['ALK.L'],'website':'https://alkemycapital.co.uk','mcap':18_000_000,'news':['UK lithium refining narrative','Battery supply chain project optionality','Project financing and permitting risk'],'price_30d':4,'volume_trend':1.09,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'MLGO','name':'MicroAlgo','sector':'Algorithms / AI software','country':'China/US','exchange':'NASDAQ','website':'https://www.microalgor.com','mcap':14_000_000,'news':['AI algorithm narrative','Ultra-small cap China ADR speculation','High governance/hype risk check'],'price_30d':-18,'volume_trend':1.60,'mentions':'medium','dilution':'high','reverse_splits':1,'offerings_24m':4},
 {'ticker':'HOLO','name':'MicroCloud Hologram','sector':'Hologram / AI software','country':'China/US','exchange':'NASDAQ','website':'https://www.mcholo.com','mcap':18_000_000,'news':['Hologram/AI software narrative','High volatility microcap','Hype and governance risk high'],'price_30d':-25,'volume_trend':1.75,'mentions':'high','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'DUOT','name':'Duos Technologies','sector':'Rail AI / Machine vision','country':'US','exchange':'NASDAQ','website':'https://www.duostech.com','mcap':35_000_000,'news':['Rail inspection AI and machine vision','Infrastructure automation narrative','Revenue growth and contract cadence watch'],'price_30d':7,'volume_trend':1.20,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'AITX','name':'Artificial Intelligence Technology Solutions','sector':'Security robotics / AI','country':'US','exchange':'OTC','website':'https://aitx.ai','mcap':22_000_000,'news':['Security robotics narrative','Recurring order announcements watch','OTC dilution and share count risk'],'price_30d':5,'volume_trend':1.24,'mentions':'medium','dilution':'high','reverse_splits':0,'offerings_24m':5},
])

# Deduplicate by ticker: keep the most recent enriched definition.
_dedup = {}
for _it in UNIVERSE:
    _dedup[_it['ticker'].upper()] = _it
UNIVERSE = list(_dedup.values())

MCAP_CACHE: Dict[str, Any] = {}
BROKER_CACHE: Dict[str, Any] = {}

# ----------------------- helpers -----------------------
def _safe_num(v):
    try:
        if v is None: return None
        x = float(v)
        return x if x > 0 else None
    except Exception:
        return None

def fmt_mcap(m):
    if not m: return 'Onbekend'
    if m >= 1_000_000_000: return f"${m/1_000_000_000:.2f}B"
    return f"${m/1_000_000:.1f}M"

def classify_mcap(m):
    if not m: return 'onbekend'
    if m < 50_000_000: return 'nano/microcap'
    if m < 300_000_000: return 'microcap'
    if m < 2_000_000_000: return 'smallcap'
    return 'groter dan echte microcap'

def clamp(x, lo=0, hi=100): return max(lo, min(hi, float(x)))

def yahoo_market_cap(ticker: str):
    if os.getenv('MCAP_LIVE_ENABLED','true').lower() != 'true': return None
    t = ticker.upper().strip(); cached = MCAP_CACHE.get(t)
    if cached and time.time() - cached.get('ts',0) < 15*60: return cached.get('value')
    try:
        r = requests.get('https://query1.finance.yahoo.com/v7/finance/quote', params={'symbols':t}, headers={'User-Agent':'Mozilla/5.0 StockGemEngine/1.0'}, timeout=8)
        if r.status_code != 200:
            log(f'mcap_yahoo_http ticker={t} status={r.status_code}'); return None
        data = r.json().get('quoteResponse',{}).get('result',[])
        if not data: return None
        row = data[0]
        mcap = _safe_num(row.get('marketCap'))
        price = _safe_num(row.get('regularMarketPrice'))
        shares = _safe_num(row.get('sharesOutstanding') or row.get('impliedSharesOutstanding'))
        if mcap is None and price and shares: mcap = price * shares
        if mcap and mcap > 500_000:
            MCAP_CACHE[t] = {'ts': time.time(), 'value': mcap}
            return mcap
    except Exception as e:
        log(f'mcap_yahoo_error ticker={t} err={str(e)[:150]}')
    return None

def live_market_cap(item):
    curated = _safe_num(item.get('mcap'))
    live = None
    yahoo_symbols = item.get('yahoo') or [item['ticker']]
    if isinstance(yahoo_symbols, str): yahoo_symbols = [yahoo_symbols]
    for ysym in yahoo_symbols:
        live = yahoo_market_cap(ysym)
        if live: break
    if live:
        if curated and (live > curated*1.8 or live < curated*0.55): log(f'mcap_override ticker={item["ticker"]} curated={curated:.0f} live={live:.0f}')
        return float(live), 'yahoo_live_marketcap', 'high'
    if curated: return float(curated), 'curated_fallback_no_live', 'low'
    return None, 'missing', 'low'

# ----------------------- broker checks -----------------------
def ibkr_check(ticker, exchange):
    url = os.getenv('IBKR_GATEWAY_URL','').rstrip('/')
    if not url: return {'status':'not_configured','label':'IBKR API nog niet gekoppeld','route':None,'detail':'Zodra Client Portal Gateway draait, vult de tool dit live.'}
    try:
        verify = os.getenv('IBKR_VERIFY_SSL','false').lower() == 'true'
        r = requests.get(f"{url}/iserver/secdef/search", params={'symbol':ticker}, timeout=6, verify=verify)
        if r.status_code == 200:
            rows = r.json() if isinstance(r.json(), list) else []
            for row in rows:
                if str(row.get('symbol','')).upper() == ticker.upper():
                    return {'status':'verified','label':'IBKR verified','route':f"{ticker} / conid {row.get('conid','?')}", 'detail':row.get('companyName') or row.get('description') or 'gevonden via IBKR'}
            return {'status':'not_found','label':'Niet gevonden op IBKR','route':None,'detail':'Geen exacte ticker-match.'}
        return {'status':'api_error','label':'IBKR API fout','route':None,'detail':f'HTTP {r.status_code}'}
    except Exception as e: return {'status':'api_error','label':'IBKR niet bereikbaar','route':None,'detail':str(e)[:120]}

def saxo_check(ticker, exchange):
    token = os.getenv('SAXO_ACCESS_TOKEN','')
    base = os.getenv('SAXO_BASE_URL','https://gateway.saxobank.com/sim/openapi').rstrip('/')
    if not token: return {'status':'not_configured','label':'Saxo API nog niet gekoppeld','route':None,'detail':'Vul SAXO_ACCESS_TOKEN in na OpenAPI setup.'}
    try:
        r = requests.get(f"{base}/ref/v1/instruments", params={'Keywords':ticker,'AssetTypes':'Stock','$top':10}, headers={'Authorization':f'Bearer {token}'}, timeout=8)
        if r.status_code == 200:
            for row in r.json().get('Data', []):
                sym = str(row.get('Symbol','')).upper()
                if sym == ticker.upper() or ticker.upper() in sym:
                    exch = row.get('ExchangeId') or row.get('Exchange') or ''
                    return {'status':'verified','label':'Saxo verified','route':f"{sym}:{exch}" if exch else sym, 'detail':row.get('Description') or 'gevonden via Saxo'}
            return {'status':'not_found','label':'Niet gevonden op Saxo','route':None,'detail':'Geen exacte ticker-match.'}
        return {'status':'api_error','label':'Saxo API fout','route':None,'detail':f'HTTP {r.status_code}'}
    except Exception as e: return {'status':'api_error','label':'Saxo niet bereikbaar','route':None,'detail':str(e)[:120]}

def broker_availability(ticker, exchange):
    key = ticker+'|'+exchange; now = time.time(); cached = BROKER_CACHE.get(key)
    if cached and now - cached['ts'] < 900: return cached['data']
    data = {
        'ibkr': ibkr_check(ticker, exchange),
        'saxo': saxo_check(ticker, exchange),
        'degiro': {'status':'unsupported','label':'Geen officiële DEGIRO API','route':None,'detail':'Niet als exact koopbaar tonen zonder officiële API.'},
        'trading212': {'status':'planned','label':'Trading 212 later','route':None,'detail':'Later via officiële instrument list/API.'}
    }
    BROKER_CACHE[key] = {'ts':now,'data':data}; return data

# ----------------------- alpha engines -----------------------
def sector_heat(item):
    s = (item['sector'] + ' ' + ' '.join(item.get('news',[]))).lower()
    heat = 45
    for kw, pts in [('defense',20),('drone',18),('ai',18),('quantum',18),('uranium',14),('battery',13),('space',16),('robot',16),('clinical',12),('biotech',10),('lithium',11),('grid storage',12)]:
        if kw in s: heat += pts
    return clamp(heat,0,100)

def hype_score(item, mcap):
    mentions = item.get('mentions','low')
    mention_pts = {'low':5,'medium':22,'high':45}.get(mentions,15)
    price_pts = max(0, min(35, item.get('price_30d',0) * 0.8))
    bigcap_pts = 12 if mcap and mcap > 1_000_000_000 else 0
    return clamp(mention_pts + price_pts + bigcap_pts,0,100)

def accumulation_score(item):
    vt = float(item.get('volume_trend',1.0)); p = float(item.get('price_30d',0))
    score = 42 + (vt-1.0)*38
    if -10 <= p <= 18: score += 18
    if p > 35: score -= 22
    if item.get('mentions') == 'low': score += 10
    return clamp(score)

def dilution_risk_score(item):
    base = {'low':18,'medium':48,'high':78}.get(item.get('dilution','medium'),48)
    base += int(item.get('reverse_splits',0))*8 + int(item.get('offerings_24m',0))*5
    return clamp(base)

def scam_label(dilution, hype, mcap):
    if dilution >= 82 and (mcap or 0) < 100_000_000: return 'HIGH - dilution/penny-stock risk'
    if dilution >= 65 or hype >= 70: return 'MEDIUM/HIGH - streng controleren'
    if dilution >= 45: return 'MEDIUM - financing controleren'
    return 'LOW/MED - geen obvious red flag in scan'

def catalyst_timeline(item):
    news = item.get('news',[])
    return [
        {'when':'6m-3m geleden','event':'Sector/narrative begint te bewegen', 'why':'De tool ziet dit als achtergrondwind, nog geen koopreden op zichzelf.'},
        {'when':'1m geleden','event':news[0] if news else 'Eerste signaal zichtbaar', 'why':'Eerste materiaal signaal om verder te onderzoeken.'},
        {'when':'Nu','event':news[1] if len(news)>1 else 'Gem score wordt opnieuw berekend', 'why':'Combinatie van lage mcap, narrative en hype-filter wordt gemeten.'},
        {'when':'Volgende check','event':'Filings, cash runway, broker availability en echte contractwaarde controleren', 'why':'Hiermee scheid je echte gems van PR/pump rommel.'},
    ]

def score_item(item):
    mcap, src, conf = live_market_cap(item)
    cap_factor = 0.45 if not mcap else clamp((650_000_000 - min(mcap,650_000_000)) / 650_000_000 * 100) / 100
    # Global edge: non-US/non-NASDAQ low-coverage names get a small discovery boost so the list is not NASDAQ-only.
    global_boost = 8 if ('NASDAQ' not in item.get('exchange','').upper() and item.get('mentions') == 'low') else 0
    nano_boost = 10 if (mcap and mcap < 75_000_000 and 'NASDAQ' not in item.get('exchange','').upper()) else 0
    narrative = sector_heat(item)
    accum = accumulation_score(item)
    hype = hype_score(item, mcap)
    dilution = dilution_risk_score(item)
    early = clamp(0.42*narrative + 0.38*accum + 20*cap_factor + global_boost + nano_boost)
    hidden = clamp(0.40*early + 0.35*(100-hype) + 0.25*(100-dilution))
    risk = clamp(0.55*dilution + 0.30*hype + (15 if (mcap and mcap < 75_000_000) else 5))
    gem = clamp(0.48*hidden + 0.35*early + 0.17*(100-risk))
    conviction = clamp(0.40*gem + 0.30*hidden + 0.20*accum + 0.10*(100-hype) - max(0,dilution-70)*0.25) / 10
    if conviction >= 8.5: clabel='Extreme asymmetric candidate'
    elif conviction >= 7.4: clabel='High conviction watchlist'
    elif conviction >= 6.2: clabel='Medium conviction'
    else: clabel='Low / too early'
    return {
        'mcap':mcap, 'mcap_source':src, 'mcap_confidence':conf,
        'gem_score':round(gem,1), 'early_signal':round(early,1), 'hype_risk':round(hype,1), 'risk_score':round(risk,1),
        'hidden_score':round(hidden,1), 'accumulation_score':round(accum,1), 'narrative_score':round(narrative,1),
        'dilution_risk_score':round(dilution,1), 'conviction_score':round(conviction,1),
        'conviction_label':clabel, 'scam_risk_label':scam_label(dilution,hype,mcap)
    }

# ----------------------- AI analyst -----------------------
def _ai_provider_config(provider: str):
    provider = (provider or '').lower()
    if provider == 'openai': return {'provider':'openai','key':OPENAI_API_KEY,'base':OPENAI_BASE_URL,'model':OPENAI_MODEL,'missing':'openai_not_configured'}
    if provider == 'deepseek': return {'provider':'deepseek','key':DEEPSEEK_API_KEY,'base':DEEPSEEK_BASE_URL,'model':DEEPSEEK_MODEL,'missing':'deepseek_not_configured'}
    return {'provider':provider or 'none','key':'','base':'','model':'','missing':'ai_provider_unknown'}

def _parse_ai_json(content: str):
    content = (content or '').strip()
    if content.startswith('```'):
        content = content.strip('`').strip()
        if content.lower().startswith('json'): content = content[4:].strip()
    start = content.find('{'); end = content.rfind('}')
    if start >= 0 and end > start: content = content[start:end+1]
    return json.loads(content)

def _call_ai_provider(provider: str, prompt: str, ticker: str):
    cfg = _ai_provider_config(provider)
    if not cfg['key']: return None, cfg['missing']
    payload = {
        'model': cfg['model'],
        'messages': [
            {'role':'system','content':'Je bent een strenge smallcap hedge-fund analyst. Geen koopadvies. Antwoord uitsluitend als geldige JSON in makkelijke Nederlandse taal.'},
            {'role':'user','content':prompt}
        ],
        'temperature': 0.15,
        'max_tokens': 1400
    }
    r = requests.post(f"{cfg['base']}/chat/completions", headers={'Authorization':f"Bearer {cfg['key']}", 'Content-Type':'application/json'}, json=payload, timeout=55)
    if r.status_code != 200:
        log(f'ai_http_error provider={cfg["provider"]} ticker={ticker} status={r.status_code} body={r.text[:220]}')
        return None, f'{cfg["provider"]}_http_{r.status_code}'
    return _parse_ai_json(r.json()['choices'][0]['message']['content']), f'{cfg["provider"]}_{cfg["model"]}'

def ai_investor_analysis(item, scores, timeline):
    if not AI_ENABLED: return None, 'ai_disabled'
    prompt = f'''
Analyseer dit aandeel alsof je Stijn helpt hidden gems te vinden VOOR de hype/pump.
Geen koopadvies. Wees streng. Gebruik makkelijke taal. Hallucineer geen feiten; als iets onzeker is, zeg dat het gecontroleerd moet worden.

Ticker: {item['ticker']}
Naam: {item['name']}
Sector: {item['sector']}
Land/beurs: {item['country']} / {item['exchange']}
Website: {item.get('website','')}
Market cap: {fmt_mcap(scores['mcap'])}, bron {scores['mcap_source']}, confidence {scores['mcap_confidence']}
Signals: price_30d={item.get('price_30d')}%, volume_trend={item.get('volume_trend')}x, social_mentions={item.get('mentions')}, dilution={item.get('dilution')}, reverse_splits={item.get('reverse_splits')}, offerings_24m={item.get('offerings_24m')}
Scores: Gem {scores['gem_score']}/100, Hidden {scores['hidden_score']}/100, Accumulation {scores['accumulation_score']}/100, Narrative {scores['narrative_score']}/100, Hype Risk {scores['hype_risk']}/100, Dilution Risk {scores['dilution_risk_score']}/100, Conviction {scores['conviction_score']}/10
Nieuws/signalen: {'; '.join(item.get('news', []))}
Timeline: {json.dumps(timeline, ensure_ascii=False)}

Geef JSON met exact deze keys:
company_plain: 2 zinnen wat het bedrijf doet.
hidden_gem_thesis: waarom dit vóór hype interessant kan zijn.
bull_case: concrete bull-case, inclusief welke katalysator rerating kan geven.
bear_case: concrete bear-case, vooral dilution, cash runway, liquiditeit, reverse split, offering/pump risk.
scam_dilution_check: duidelijke rode vlaggen/checklist.
catalyst_map: lijst met 3-5 concrete katalysatoren of bewijsstukken die Stijn moet volgen.
what_to_verify_next: lijst met 5 concrete checks vóór hij geld riskeert.
verdict: Strong Gem Candidate, High-Risk Watchlist, Too Early, Avoid.
confidence: getal 0-100 voor betrouwbaarheid van deze analyse op basis van data.
plain_reason: 1 korte zin waarom aantrekkelijk óf waarom oppassen.
'''
    last = 'ai_not_configured'; tried=[]
    for provider in [AI_PROVIDER, AI_FALLBACK_PROVIDER]:
        if not provider or provider == 'none' or provider in tried: continue
        tried.append(provider)
        try:
            data, source = _call_ai_provider(provider, prompt, item['ticker'])
            if data: return data, source
            last = source
        except Exception as e:
            last = f'{provider}_error'; log(f'ai_error provider={provider} ticker={item.get("ticker")} err={str(e)[:180]}')
    return None, last

def fallback_analysis(item, scores, timeline):
    return {
      'company_plain': f"{item['name']} ({item['ticker']}) is een {classify_mcap(scores['mcap'])} binnen {item['sector']}. Website: {item.get('website','nog niet bekend')}. De tool ziet dit als vroeg research-aandeel: interessant om te onderzoeken, niet automatisch koopwaardig.",
      'hidden_gem_thesis': f"De combinatie van {fmt_mcap(scores['mcap'])} market cap, Hidden Score {scores['hidden_score']}/100 en Hype Risk {scores['hype_risk']}/100 suggereert dat het aandeel mogelijk nog vóór brede hype zit.",
      'bull_case': 'Bull case: als de genoemde katalysatoren echte omzet/contractwaarde opleveren, kan de markt het aandeel opnieuw waarderen.',
      'bear_case': 'Bear case: microcaps kunnen verwateren, lage liquiditeit hebben of vooral PR maken zonder harde omzet. Controleer filings en cash runway.',
      'scam_dilution_check': f"Dilution risk {scores['dilution_risk_score']}/100; reverse splits {item.get('reverse_splits')}; offerings 24m {item.get('offerings_24m')}.",
      'catalyst_map': item.get('news', [])[:5],
      'what_to_verify_next': ['Laatste 10-Q/10-K cash runway', 'Aantal shares outstanding', 'Recente offerings/S-3/ATM', 'Echte contractwaarde', 'Gemiddeld volume/liquiditeit'],
      'verdict': 'High-Risk Watchlist' if scores['dilution_risk_score'] > 65 else ('Strong Gem Candidate' if scores['conviction_score'] >= 7.5 else 'Too Early'),
      'confidence': 55,
      'plain_reason': 'Interessant als vroege watchlist, maar eerst filings en dilution controleren.'
    }

def build_texts(ai, scores, source):
    company = ai.get('company_plain','')
    why = f"{ai.get('hidden_gem_thesis','')}\n\nBull case: {ai.get('bull_case','')}"
    catalyst = 'Catalyst map: ' + '; '.join(ai.get('catalyst_map',[]) if isinstance(ai.get('catalyst_map'), list) else [str(ai.get('catalyst_map',''))])
    verify = ai.get('what_to_verify_next', [])
    if isinstance(verify, list): catalyst += '\n\nVolgende checks: ' + '; '.join(verify)
    risk = f"Bear case: {ai.get('bear_case','')}\n\nScam/dilution check: {ai.get('scam_dilution_check','')}\n\nVerdict: {ai.get('verdict','Watchlist')} · AI confidence {ai.get('confidence',0)} · Bron: {source}. Geen koopadvies."
    return company, why, catalyst, risk

# ----------------------- scan runtime -----------------------
def send_ntfy(gem):
    try:
        title = f"🚨 New Gem: {gem['ticker']} · {gem['conviction_score']:.1f}/10"
        msg = f"{gem['ticker']} · {gem['name']}\nMCap: {fmt_mcap(gem['mcap_usd'])}\nConviction: {gem['conviction_label']}\nVerdict: {gem.get('ai_verdict') or 'Watchlist'}\nWaarom: {gem['why_attractive'][:260]}\nhttp://51.195.102.180:8791"
        requests.post(f'https://ntfy.sh/{NTFY_TOPIC}', data=msg.encode('utf-8'), headers={'Title':title, 'Priority':'default'}, timeout=5)
        return True
    except Exception as e: log(f'ntfy_error {e}'); return False

def run_scan(manual=False):
    if state['running']: return {'ok':False,'message':'scan draait al'}
    state['running'] = True; state['error'] = None
    alerts = 0; count = 0; ai_used = 0
    try:
        con = db(); now = datetime.now(timezone.utc).isoformat()
        # v1.1.1: remove obsolete old-only rows so the expanded microcap universe becomes visible after scan.
        current_tickers = [it['ticker'].upper() for it in UNIVERSE]
        if current_tickers:
            placeholders = ','.join(['?']*len(current_tickers))
            con.execute(f'DELETE FROM gems WHERE UPPER(ticker) NOT IN ({placeholders})', current_tickers)
        scored = []
        for item in UNIVERSE:
            scores = score_item(item)
            scored.append((item, scores))
        scored.sort(key=lambda x: (x[1]['conviction_score'], x[1]['gem_score']), reverse=True)
        ai_budget = AI_MAX_PER_SCAN
        for item, scores in scored:
            timeline = catalyst_timeline(item)
            use_ai = False  # v1.0.1 safe mode: no paid AI/API calls
            if use_ai:
                ai, ai_source = ai_investor_analysis(item, scores, timeline)
                if ai: ai_used += 1; ai_budget -= 1
                else: ai, ai_source = fallback_analysis(item, scores, timeline), ai_source
            else:
                ai, ai_source = fallback_analysis(item, scores, timeline), 'rule_engine_not_ai_priority'
            company, why, catalyst, risk_txt = build_texts(ai, scores, ai_source)
            brokers = broker_availability(item['ticker'], item['exchange'])
            existing = con.execute('SELECT alerted FROM gems WHERE ticker=?',(item['ticker'],)).fetchone()
            should_alert = (not existing or existing['alerted']==0) and scores['conviction_score'] >= 7.6 and scores['hype_risk'] <= 55 and scores['dilution_risk_score'] < 85
            if should_alert: alerts += 1
            next_level = {
                'hidden_gem': scores['hidden_score'], 'accumulation': scores['accumulation_score'], 'narrative': scores['narrative_score'],
                'dilution': scores['dilution_risk_score'], 'price_30d': item.get('price_30d'), 'volume_trend': item.get('volume_trend'),
                'mentions': item.get('mentions'), 'reverse_splits': item.get('reverse_splits'), 'offerings_24m': item.get('offerings_24m'),
                'plain_reason': ai.get('plain_reason',''), 'website': item.get('website',''), 'mcap_bucket': ('<20M' if (scores['mcap'] or 0) < 20_000_000 else '<50M' if (scores['mcap'] or 0) < 50_000_000 else '<100M' if (scores['mcap'] or 0) < 100_000_000 else '<300M' if (scores['mcap'] or 0) < 300_000_000 else '300M+')
            }
            con.execute('''INSERT INTO gems(
              ticker,name,sector,country,exchange,mcap_usd,mcap_source,mcap_confidence,gem_score,early_signal,hype_risk,risk_score,
              hidden_score,accumulation_score,narrative_score,dilution_risk_score,conviction_score,conviction_label,scam_risk_label,ai_source,ai_verdict,ai_confidence,
              company_short,why_attractive,risk_plain,catalyst_plain,broker_json,news_json,timeline_json,ai_json,next_level_json,first_seen,last_seen,alerted)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(ticker) DO UPDATE SET
              name=excluded.name,sector=excluded.sector,country=excluded.country,exchange=excluded.exchange,mcap_usd=excluded.mcap_usd,mcap_source=excluded.mcap_source,mcap_confidence=excluded.mcap_confidence,
              gem_score=excluded.gem_score,early_signal=excluded.early_signal,hype_risk=excluded.hype_risk,risk_score=excluded.risk_score,hidden_score=excluded.hidden_score,accumulation_score=excluded.accumulation_score,narrative_score=excluded.narrative_score,dilution_risk_score=excluded.dilution_risk_score,conviction_score=excluded.conviction_score,conviction_label=excluded.conviction_label,scam_risk_label=excluded.scam_risk_label,ai_source=excluded.ai_source,ai_verdict=excluded.ai_verdict,ai_confidence=excluded.ai_confidence,company_short=excluded.company_short,why_attractive=excluded.why_attractive,risk_plain=excluded.risk_plain,catalyst_plain=excluded.catalyst_plain,broker_json=excluded.broker_json,news_json=excluded.news_json,timeline_json=excluded.timeline_json,ai_json=excluded.ai_json,next_level_json=excluded.next_level_json,last_seen=excluded.last_seen,alerted=CASE WHEN gems.alerted=1 THEN 1 ELSE excluded.alerted END''',
              (item['ticker'],item['name'],item['sector'],item['country'],item['exchange'],scores['mcap'],scores['mcap_source'],scores['mcap_confidence'],scores['gem_score'],scores['early_signal'],scores['hype_risk'],scores['risk_score'],scores['hidden_score'],scores['accumulation_score'],scores['narrative_score'],scores['dilution_risk_score'],scores['conviction_score'],scores['conviction_label'],scores['scam_risk_label'],ai_source,ai.get('verdict'),_safe_num(ai.get('confidence')),company,why,risk_txt,catalyst,json.dumps(brokers,ensure_ascii=False),json.dumps(item.get('news',[]),ensure_ascii=False),json.dumps(timeline,ensure_ascii=False),json.dumps(ai,ensure_ascii=False),json.dumps(next_level,ensure_ascii=False),now,now,1 if should_alert else 0))
            count += 1
        con.execute('INSERT INTO scan_runs(ts,count,alerts,note,ai_used) VALUES(?,?,?,?,?)',(now,count,alerts,'manual' if manual else 'auto',ai_used))
        con.commit(); con.close()
        state.update({'last_scan':now,'last_alerts':alerts,'last_ai_used':ai_used})
        if alerts:
            con = db()
            for row in con.execute('SELECT * FROM gems WHERE alerted=1 ORDER BY conviction_score DESC LIMIT 3').fetchall(): send_ntfy(dict(row))
            con.close()
        log(f'scan_complete count={count} alerts={alerts} ai_used={ai_used} manual={manual}')
        return {'ok':True,'count':count,'alerts':alerts,'ai_used':ai_used}
    except Exception as e:
        state['error'] = str(e); log(f'scan_error {e}'); return {'ok':False,'error':str(e)}
    finally:
        state['running'] = False

def scheduler_loop():
    log(f'scheduler_started enabled={AUTO_SCAN_ENABLED} interval={SCAN_INTERVAL_MINUTES}')
    while True:
        try:
            if AUTO_SCAN_ENABLED:
                con = db(); n = con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; con.close()
                if n < max(1, int(len(UNIVERSE)*0.8)): run_scan(False)
                time.sleep(SCAN_INTERVAL_MINUTES*60); run_scan(False)
            else: time.sleep(60)
        except Exception as e: log(f'scheduler_error {e}'); time.sleep(60)

@app.on_event('startup')
def startup(): threading.Thread(target=scheduler_loop, daemon=True).start()

# ----------------------- API -----------------------
@app.get('/api/ai/test')
def api_ai_test():
    cfg = _ai_provider_config(AI_PROVIDER)
    if not AI_ENABLED: return {'ok':False,'provider':AI_PROVIDER,'message':'AI_ENABLED=false'}
    if not cfg.get('key'): return {'ok':False,'provider':AI_PROVIDER,'message':cfg.get('missing')}
    try:
        data, source = _call_ai_provider(AI_PROVIDER, 'Antwoord uitsluitend als JSON: {"ok": true, "message": "AI koppeling werkt"}', 'TEST')
        return {'ok':True,'provider':AI_PROVIDER,'source':source,'response':data}
    except Exception as e: return {'ok':False,'provider':AI_PROVIDER,'message':str(e)[:220]}

@app.get('/api/status')
def api_status():
    con = db(); n = con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; con.close()
    return {'version':APP_VERSION,'gems':n,'ntfy_topic':NTFY_TOPIC,'scan_interval_minutes':SCAN_INTERVAL_MINUTES,'auto_scan':AUTO_SCAN_ENABLED,'ai_enabled':AI_ENABLED,'ai_provider':AI_PROVIDER,'ai_fallback_provider':AI_FALLBACK_PROVIDER,'openai_configured':bool(OPENAI_API_KEY),'deepseek_configured':bool(DEEPSEEK_API_KEY),'ai_configured':bool(OPENAI_API_KEY or DEEPSEEK_API_KEY),'ai_model':OPENAI_MODEL if AI_PROVIDER=='openai' else DEEPSEEK_MODEL,'universe_size':len(UNIVERSE),**state}

@app.get('/api/gems')
def api_gems():
    con = db(); rows = [dict(r) for r in con.execute('SELECT * FROM gems ORDER BY conviction_score DESC, gem_score DESC').fetchall()]; con.close()
    for r in rows:
        for key, default in [('broker_json',{}),('news_json',[]),('timeline_json',[]),('ai_json',{}),('next_level_json',{})]:
            val = r.pop(key, None)
            r[key.replace('_json','')] = json.loads(val or json.dumps(default))
    return rows

@app.post('/api/scan')
def api_scan(): return run_scan(manual=True)

@app.get('/', response_class=HTMLResponse)
def index(): return HTML

HTML = r'''<!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Stijn-Tradifi-2026</title><style>
:root{--bg:#07111f;--bg2:#0b1729;--card:#101b2e;--card2:#0d1627;--ink:#f8fafc;--muted:#9aa7bd;--line:rgba(255,255,255,.10);--gold:#f4c76b;--green:#3ee28f;--red:#ff5d6c;--orange:#ffb454;--blue:#7cb7ff;--purple:#bd8cff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 20% 0%,#172641 0,#07111f 38%,#050a13 100%);color:var(--ink);font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif}.top{position:sticky;top:0;z-index:20;background:rgba(7,17,31,.82);backdrop-filter:blur(22px);border-bottom:1px solid var(--line)}.wrap{max-width:1280px;margin:0 auto;padding:14px 12px 50px}.hero{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center}.eyebrow{font-size:11px;text-transform:uppercase;letter-spacing:.2em;font-weight:1000;color:var(--gold)}h1{margin:2px 0;font-size:clamp(28px,5vw,48px);letter-spacing:-.07em;line-height:.95}.sub{color:var(--muted);font-size:14px;line-height:1.35}.actions{display:flex;gap:8px}button{background:linear-gradient(135deg,#f5c66e,#ffdd94);color:#111827;border:0;border-radius:14px;padding:12px 14px;font-weight:1000;font-size:14px}.ghost{background:rgba(255,255,255,.07);color:var(--ink);border:1px solid var(--line)}.dash{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:12px 0}.stat{background:linear-gradient(180deg,rgba(255,255,255,.08),rgba(255,255,255,.035));border:1px solid var(--line);border-radius:18px;padding:12px;min-height:74px}.stat b{font-size:22px;letter-spacing:-.04em}.stat .sub{font-size:12px}.toolbar{display:flex;gap:8px;overflow:auto;padding:8px 0 14px;align-items:center}.chip{white-space:nowrap;background:rgba(255,255,255,.07);border:1px solid var(--line);border-radius:999px;padding:9px 11px;color:var(--muted);font-weight:900;font-size:12px}.sectorselect{background:rgba(255,255,255,.07);border:1px solid var(--line);border-radius:999px;padding:9px 11px;color:var(--ink);font-weight:900;font-size:12px;max-width:190px}.chip.active{color:#111827;background:var(--gold)}.panel{background:linear-gradient(180deg,rgba(255,255,255,.08),rgba(255,255,255,.035));border:1px solid var(--line);border-radius:22px;padding:14px;margin:12px 0}.panel h2{font-size:19px;margin:0 0 3px;letter-spacing:-.03em}.list{display:grid;gap:11px}.gem{background:linear-gradient(180deg,rgba(16,27,46,.96),rgba(10,18,32,.96));border:1px solid var(--line);border-radius:24px;overflow:hidden;box-shadow:0 22px 45px rgba(0,0,0,.25)}.summary{display:grid;grid-template-columns:72px 1fr 82px;gap:10px;align-items:center;padding:13px}.rank{height:54px;width:54px;border-radius:18px;background:rgba(244,199,107,.12);border:1px solid rgba(244,199,107,.28);display:grid;place-items:center;color:var(--gold);font-size:20px;font-weight:1000}.ticker{font-size:30px;font-weight:1000;letter-spacing:-.08em;line-height:.9}.name{color:var(--muted);font-size:12.5px;line-height:1.25;margin-top:3px}.sector{font-weight:1000;font-size:13px;margin-top:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.mcap{font-size:16px;font-weight:1000;color:#fff;margin-top:5px}.scoreBox{text-align:right}.score{font-size:34px;font-weight:1000;color:var(--gold);letter-spacing:-.06em;line-height:.9}.scoreBox small{font-size:11px;color:var(--muted)}.quick{display:grid;grid-template-columns:repeat(5,1fr);gap:7px;padding:0 13px 13px}.q{background:rgba(255,255,255,.055);border:1px solid var(--line);border-radius:14px;padding:8px}.q label{display:flex;justify-content:space-between;color:var(--muted);font-size:10.5px;font-weight:900}.bar{height:6px;border-radius:99px;background:rgba(255,255,255,.10);overflow:hidden;margin-top:6px}.fill{height:100%;background:linear-gradient(90deg,#6aa8ff,var(--gold));border-radius:99px}.badfill{background:linear-gradient(90deg,var(--green),var(--orange),var(--red))}.reason{display:grid;grid-template-columns:1.1fr .9fr;gap:10px;padding:0 13px 13px}.mini{background:rgba(255,255,255,.045);border:1px solid var(--line);border-radius:16px;padding:11px}.mini h3{font-size:13px;margin:0 0 6px;color:#fff}.mini p{margin:0;color:#c9d3e5;font-size:12.8px;line-height:1.45;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}.badtext{color:#ffd0d4!important}.tags{display:flex;gap:7px;flex-wrap:wrap;padding:0 13px 13px}.pill{font-size:10.5px;font-weight:1000;letter-spacing:.08em;text-transform:uppercase;border:1px solid var(--line);border-radius:999px;padding:6px 8px;color:var(--muted);background:rgba(255,255,255,.045)}.ok{color:var(--green)}.warn{color:var(--orange)}.bad{color:var(--red)}details{border-top:1px solid var(--line);padding:0 13px 13px}summary{cursor:pointer;color:var(--gold);font-weight:1000;padding:12px 0}.detailGrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.brokerline,.time{border-left:3px solid rgba(244,199,107,.55);padding:7px 0 7px 10px;color:#d5def0;font-size:12.6px}.brokerline b,.time b{display:block;color:#fff}.muted{color:var(--muted)}small{color:var(--muted);display:block;line-height:1.3}.empty{padding:24px;text-align:center;color:var(--muted)}@media(max-width:760px){.wrap{padding:11px 8px 38px}.hero{grid-template-columns:1fr}.dash{grid-template-columns:repeat(2,1fr)}.summary{grid-template-columns:48px 1fr 68px}.rank{height:42px;width:42px;border-radius:14px;font-size:15px}.ticker{font-size:25px}.quick{grid-template-columns:repeat(3,1fr)}.reason,.detailGrid{grid-template-columns:1fr}.score{font-size:29px}.sub{font-size:13px}.top .wrap{padding-bottom:10px}}

.probar{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0 0}.microNote{font-size:11px;color:var(--muted);line-height:1.25}.gem{border-radius:18px}.summary{padding:10px}.quick{grid-template-columns:repeat(5,1fr);padding:0 10px 10px}.reason{padding:0 10px 10px}.ticker{font-size:27px}.mcap{font-size:14px}.mini p{-webkit-line-clamp:3}.stat{min-height:64px;border-radius:15px}.panel{border-radius:18px}.toolbar{position:sticky;top:112px;z-index:10;background:rgba(7,17,31,.72);backdrop-filter:blur(18px);border-bottom:1px solid var(--line)}@media(max-width:760px){.dash{grid-template-columns:repeat(3,1fr)}.stat b{font-size:20px}.reason{display:none}.quick{grid-template-columns:repeat(5,1fr);gap:5px}.q{padding:6px}.q label{font-size:9px}.bar{height:5px}.summary{grid-template-columns:38px 1fr 64px}.rank{height:34px;width:34px;font-size:13px}.ticker{font-size:24px}.name{font-size:11px}.sector{font-size:12px}.mcap{font-size:12px}.pill{font-size:9px;padding:5px 6px}.score{font-size:25px}.gem{border-radius:16px}.top .wrap{padding-bottom:8px}.hero{gap:8px}button{padding:10px 12px;border-radius:12px}.sub{font-size:12px}.toolbar{top:0}.mini p{-webkit-line-clamp:unset}}
</style></head><body><div class="top"><div class="wrap"><div class="hero"><div><div class="eyebrow">No-API safe mode · pro microcap terminal</div><h1>Stijn-Tradifi-2026</h1><div class="sub">Pro microcap dashboard: directe buckets onder $20M / $50M / $100M, sectorfilter, website-link, compacte bedrijfs-DD en no-API safe mode.</div></div><div class="actions"><button onclick="scan()">Nieuwe scan</button><button class="ghost" onclick="load()">Vernieuwen</button></div></div></div></div><main class="wrap"><div class="dash"><div class="stat"><b id="count">0</b><div class="sub">Gems</div></div><div class="stat"><b id="last">...</b><div class="sub">Laatste scan</div></div><div class="stat"><b id="interval">...</b><div class="sub">Auto</div></div><div class="stat"><b id="topic">...</b><div class="sub">ntfy</div></div><div class="stat"><b id="coverage">Global</b><div class="sub">Universe</div></div><div class="stat"><b id="sub20">...</b><div class="sub">onder $20M</div></div></div><div class="toolbar"><span class="chip active" onclick="setFilter('all',this)">Alle</span><span class="chip" onclick="setFilter('cap20',this)">Top 10 &lt;$20M</span><span class="chip" onclick="setFilter('cap50',this)">Top 10 &lt;$50M</span><span class="chip" onclick="setFilter('cap100',this)">Top 10 &lt;$100M</span><span class="chip" onclick="setFilter('xus',this)">Buiten US/Nasdaq</span><span class="chip" onclick="setFilter('lowhype',this)">Lage hype</span><span class="chip" onclick="setFilter('safe',this)">Lagere dilution</span><select id="sectorSelect" class="sectorselect" onchange="setSector(this.value)"><option value="all">Alle sectoren</option></select></div><div class="panel"><h2>Top Gems Ranking</h2><div class="sub" id="status">Laden...</div></div><div class="list" id="list"></div></main><script>
let ALL=[], FILTER='all', SECTOR='all';
function money(v){if(!v)return 'Onbekend'; if(v>=1e9)return '$'+(v/1e9).toFixed(2)+'B'; return '$'+(v/1e6).toFixed(1)+'M'}
function pct(v){return Math.max(0,Math.min(100,Number(v)||0))}
function line(label,val,bad=false){let v=pct(val);return `<div class="q"><label><span>${label}</span><b>${v.toFixed(0)}</b></label><div class="bar"><div class="fill ${bad?'badfill':''}" style="width:${v}%"></div></div></div>`}
function brokerStatus(b){let cls='muted'; if(b?.status==='verified')cls='ok'; else if(['api_error','not_found'].includes(b?.status))cls='bad'; else if(['not_configured','planned','unsupported'].includes(b?.status))cls='warn'; return `<span class="${cls}">${b?.label||'onbekend'}${b?.route?' · '+b.route:''}</span><small>${b?.detail||''}</small>`}
function short(txt,n=260){txt=txt||''; return txt.length>n?txt.slice(0,n)+'…':txt}
function setFilter(f,el){FILTER=f; document.querySelectorAll('.chip').forEach(c=>c.classList.remove('active')); el.classList.add('active'); render(ALL)}
function setSector(v){SECTOR=v; render(ALL)}
function sectorRoot(g){return String(g.sector||'').split('/')[0].trim()}
function fillSectors(gems){let sel=document.getElementById('sectorSelect'); let old=sel.value||'all'; let sectors=[...new Set(gems.map(sectorRoot).filter(Boolean))].sort(); sel.innerHTML='<option value="all">Alle sectoren</option>'+sectors.map(x=>`<option value="${x}">${x}</option>`).join(''); sel.value=sectors.includes(old)?old:'all'}
function capVal(g){return Number(g.mcap_usd||g.mcap||0)||0}
function applyFilter(g){if(SECTOR!=='all' && sectorRoot(g)!==SECTOR)return false; let m=capVal(g); let b=(g.next_level&&g.next_level.mcap_bucket)||''; if(FILTER==='cap20')return (m>0 && m<20000000)||b==='<20M'; if(FILTER==='cap50')return (m>0 && m<50000000)||b==='<20M'||b==='<50M'; if(FILTER==='cap100')return (m>0 && m<100000000)||['<20M','<50M','<100M'].includes(b); if(FILTER==='lowhype')return (g.hype_risk||99)<=35; if(FILTER==='safe')return (g.dilution_risk_score||99)<=65; if(FILTER==='xus')return !String(g.exchange||'').match(/NASDAQ|NYSE/); return true}
async function load(){let s=await fetch('/api/status').then(r=>r.json()); count.textContent=s.gems; topic.textContent=s.ntfy_topic; interval.textContent=s.scan_interval_minutes+'m'; last.textContent=s.last_scan?new Date(s.last_scan).toLocaleTimeString():'geen'; coverage.textContent=s.universe_size||'Global'; status.textContent=(s.running?'Scan draait…':'running: nee')+' · alerts '+(s.last_alerts||0)+' · universe '+(s.universe_size||'?')+' · versie '+s.version+' · no API kosten'; ALL=await fetch('/api/gems').then(r=>r.json()); let c20=ALL.filter(g=>capVal(g)>0&&capVal(g)<20000000).length; sub20.textContent=c20; fillSectors(ALL); render(ALL)}
async function scan(){status.textContent='Scan draait… globale universe + rule-based alpha engine.'; await fetch('/api/scan',{method:'POST'}); await load()}
function render(gems){let data=gems.filter(applyFilter); if(['cap20','cap50','cap100'].includes(FILTER)) data=data.slice(0,10); let root=document.getElementById('list'); if(!data.length){root.innerHTML='<div class="panel empty">Nog geen resultaten in deze bucket. Klik Nieuwe scan; v1.1.2 vult de <$20M-bucket met ultra/nano-cap research candidates als de scan klaar is.</div>';return} root.innerHTML=data.map((g,i)=>{let n=g.next_level||{}, broker=g.broker||{}, tl=g.timeline||[];let xus=!String(g.exchange||'').match(/NASDAQ|NYSE/);return `<div class="gem"><div class="summary"><div class="rank">#${i+1}</div><div><div class="ticker">${g.ticker}</div><div class="name">${g.name} · ${g.country} · ${g.exchange}</div><div class="sector">${g.sector}</div><div class="mcap">${money(g.mcap_usd)} <span class="pill">${n.mcap_bucket||''}</span> <span class="pill">${g.mcap_confidence||'low'} · ${g.mcap_source||'source'}</span></div></div><div class="scoreBox"><div class="score">${Number(g.conviction_score||0).toFixed(1)}</div><small>conviction</small><small>gem ${Number(g.gem_score||0).toFixed(0)}</small></div></div><div class="quick">${line('Hidden',g.hidden_score)}${line('Accum.',g.accumulation_score)}${line('Narrative',g.narrative_score)}${line('Hype',g.hype_risk,true)}${line('Dilution',g.dilution_risk_score,true)}</div><div class="reason"><div class="mini"><h3>Waarom aantrekkelijk?</h3><p>${short((n.plain_reason||'')+' '+(g.why_attractive||''),360)}</p></div><div class="mini"><h3>Belangrijkste risico</h3><p class="badtext">${short(g.risk_plain||'',330)}</p></div></div><div class="tags"><span class="pill">${g.conviction_label||'Watchlist'}</span><span class="pill ${xus?'ok':'warn'}">${xus?'Buiten US/Nasdaq':'US route'}</span><span class="pill">${g.ai_source||'rule engine'}</span><span class="pill">mcap ${money(g.mcap_usd)}</span>${n.website?`<a class="pill ok" href="${n.website}" target="_blank" rel="noopener">Website</a>`:''}</div><details><summary>Open volledige analyse, timeline en brokerroute</summary><div class="detailGrid"><div class="mini"><h3>Wat doet dit bedrijf?</h3><p>${g.company_short||''}</p>${n.website?`<p><b>Website:</b> <a href="${n.website}" target="_blank" rel="noopener">${n.website}</a></p>`:''}<h3>Catalyst map</h3><p>${g.catalyst_plain||''}</p></div><div class="mini"><h3>Timeline</h3>${tl.map(t=>`<div class="time"><b>${t.when}</b>${t.event}<small>${t.why}</small></div>`).join('')}<h3 style="margin-top:12px">Brokerroute</h3><div class="brokerline"><b>IBKR</b>${brokerStatus(broker.ibkr)}</div><div class="brokerline"><b>Saxo</b>${brokerStatus(broker.saxo)}</div><div class="brokerline"><b>DEGIRO</b>${brokerStatus(broker.degiro)}</div><div class="brokerline"><b>T212</b>${brokerStatus(broker.trading212)}</div></div></div></details></div>`}).join('')}
load(); setInterval(load,30000)
</script></body></html>'''
