#!/usr/bin/env bash
set -euo pipefail

# Bitcoin Evidence Engine - definitieve VPS updater v10.16.12
# Doel: nieuwe ZIP in GitHub -> cd ~/bitcoin-engine-deploy && bash update.sh -> klaar.
# Belangrijk: data blijft persistent in ~/bitcoin_evidence_data en wordt nooit verwijderd.

REPO_URL="${REPO_URL:-https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git}"
BASE_DIR="${BASE_DIR:-$HOME/bitcoin-engine-deploy}"
REPO_DIR="$BASE_DIR/github_latest"
RELEASES_DIR="$BASE_DIR/releases"
CURRENT_LINK="$BASE_DIR/current"
LOGS_DIR="$BASE_DIR/logs"
DATA_DIR="${BEE_DATA_DIR:-$HOME/bitcoin_evidence_data}"
PORT="${PORT:-8787}"
APP_URL="http://51.195.102.180:${PORT}"

msg(){ echo "[BEE update] $*"; }

install_system_tools(){
  msg "Systeemtools controleren/installeren..."
  sudo apt-get update
  sudo apt-get install -y git unzip curl procps rsync build-essential golang-go python3.12 python3.12-venv python3.12-dev
}

choose_python(){
  # FORCEER Python 3.12. Python 3.14 veroorzaakt wheel/dependency-ellende
  # zoals duckdb/pandas/pydantic-core install-fouten.
  if command -v python3.12 >/dev/null 2>&1; then echo "python3.12"; return 0; fi
  if command -v python3.11 >/dev/null 2>&1; then echo "python3.11"; return 0; fi
  return 1
}

prepare_dirs(){
  mkdir -p "$BASE_DIR" "$RELEASES_DIR" "$LOGS_DIR" "$DATA_DIR"
  cd "$BASE_DIR"
}

stop_server(){
  msg "Oude server stoppen..."
  pkill -f "uvicorn app.main:app" >/dev/null 2>&1 || true
  sleep 1
}

clone_repo(){
  rm -rf "$REPO_DIR"
  msg "GitHub repo vers ophalen..."
  git clone "$REPO_URL" "$REPO_DIR"
}

find_latest_zip(){
  # Gebruik versie-sortering, niet mtime. Bij git clone kunnen mtimes gelijk zijn.
  find "$REPO_DIR" -maxdepth 3 -type f \( -iname 'bitcoin_evidence_engine*.zip' -o -iname 'engine*.zip' \) | sort -V | tail -1
}

unpack_release(){
  local zip_file="$1"
  local stamp name tmp app_dir dest
  stamp="$(date +%Y%m%d_%H%M%S)"
  name="$(basename "$zip_file" .zip)"
  tmp="$BASE_DIR/.update_extract_$stamp"
  dest="$RELEASES_DIR/${stamp}_${name}"
  rm -rf "$tmp" "$dest"
  mkdir -p "$tmp"
  msg "Nieuwste ZIP: $(basename "$zip_file")"
  unzip -q "$zip_file" -d "$tmp"
  app_dir=""
  while IFS= read -r mainfile; do
    candidate="$(dirname "$(dirname "$mainfile")")"
    if [ -f "$candidate/requirements.txt" ] && [ -f "$candidate/app/main.py" ]; then
      app_dir="$candidate"
      break
    fi
  done < <(find "$tmp" -type f -path '*/app/main.py' | sort)
  if [ -z "$app_dir" ]; then
    echo "❌ Geen geldige app-root gevonden in ZIP. Verwacht requirements.txt + app/main.py"
    find "$tmp" -maxdepth 4 -type f | head -120
    exit 1
  fi
  mv "$app_dir" "$dest"
  rm -rf "$tmp"
  ln -sfn "$dest" "$CURRENT_LINK"
  echo "$dest"
}

patch_requirements(){
  msg "Requirements VPS-proof maken..."
  # Oude pins uit eerdere builds nooit meer laten blokkeren.
  sed -i 's/^duckdb==1\.1\.3/duckdb>=1.4.2,<1.7/g' requirements.txt || true
  sed -i 's/^duckdb>=1\.4\.2$/duckdb>=1.4.2,<1.7/g' requirements.txt || true
  sed -i 's/^pandas==2\.2\.3/pandas>=2.2.3,<3.1/g' requirements.txt || true
  sed -i 's/^numpy==2\.1\.3/numpy>=2.1.3,<3.0/g' requirements.txt || true
  sed -i 's/^pydantic==2\.10\.3/pydantic>=2.10.3,<3.0/g' requirements.txt || true
}

make_venv(){
  local pybin="$1"
  msg "Virtualenv volledig opnieuw maken met $($pybin --version)..."
  rm -rf .venv
  "$pybin" -m venv .venv
  . .venv/bin/activate
  python -m pip install --upgrade 'pip<26' wheel setuptools
  msg "Dependencies installeren met binary wheels..."
  python -m pip install --only-binary=:all: -r requirements.txt
}

build_native(){
  if [ -f build_native_core_linux.sh ]; then
    msg "Go native Time Machine core bouwen/controleren..."
    bash build_native_core_linux.sh
  else
    msg "WAARSCHUWING: build_native_core_linux.sh ontbreekt. Bestaande native binary wordt gebruikt."
  fi
  if [ ! -x native_core/bin/bee_native_core ]; then
    chmod +x native_core/bin/bee_native_core 2>/dev/null || true
  fi
  if [ ! -x native_core/bin/bee_native_core ]; then
    echo "❌ Native core ontbreekt of is niet uitvoerbaar: native_core/bin/bee_native_core"
    exit 1
  fi
}

start_server(){
  mkdir -p logs "$DATA_DIR"
  export BEE_DATA_DIR="$DATA_DIR"
  export BEE_CLOUD_MODE="1"
  export BEE_PUBLIC_BASE_URL="$APP_URL"
  msg "Server starten op poort $PORT met persistente data-map: $DATA_DIR"
  nohup .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port "$PORT" --proxy-headers > "$LOGS_DIR/server.log" 2>&1 &
  local ok=0
  for i in $(seq 1 35); do
    if curl -fsS "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then ok=1; break; fi
    sleep 1
  done
  if [ "$ok" = "1" ]; then
    echo ""
    echo "✅ UPDATE KLAAR"
    echo "Open: $APP_URL"
    echo "Data blijft bewaard in: $DATA_DIR"
    echo "Log: $LOGS_DIR/server.log"
    echo "Voortaan: cd $BASE_DIR && bash update.sh"
  else
    echo ""
    echo "❌ Server startte niet goed. Laatste logregels:"
    tail -120 "$LOGS_DIR/server.log" || true
    exit 1
  fi
}

main(){
  deactivate >/dev/null 2>&1 || true
  prepare_dirs
  echo "=============================================="
  echo "Bitcoin Evidence Engine VPS updater v10.16.12"
  echo "Repo: $REPO_URL"
  echo "Base: $BASE_DIR"
  echo "Data: $DATA_DIR"
  echo "=============================================="
  stop_server
  install_system_tools
  PY_BIN="$(choose_python || true)"
  if [ -z "${PY_BIN:-}" ]; then
    echo "❌ Geen Python 3.12/3.11 gevonden. Installeer python3.12-venv en probeer opnieuw."
    exit 1
  fi
  clone_repo
  ZIP_FILE="$(find_latest_zip)"
  if [ -z "${ZIP_FILE:-}" ] || [ ! -f "$ZIP_FILE" ]; then
    echo "❌ Geen ZIP gevonden in GitHub repo. Zet bitcoin_evidence_engine*.zip in de root."
    exit 1
  fi
  DEST="$(unpack_release "$ZIP_FILE")"
  cd "$CURRENT_LINK"
  # Zorg dat de volgende update altijd deze updater gebruikt.
  if [ -f update.sh ]; then cp -f update.sh "$BASE_DIR/update.sh"; chmod +x "$BASE_DIR/update.sh"; fi
  patch_requirements
  make_venv "$PY_BIN"
  build_native
  start_server
}

main "$@"
