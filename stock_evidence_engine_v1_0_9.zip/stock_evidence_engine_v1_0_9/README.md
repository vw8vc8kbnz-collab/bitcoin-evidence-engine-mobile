# Stock Evidence Engine v1.0.9

Engine Diagnostics + Catalyst Scoring release.

- One runtime: `server.py`
- Port: `8798`
- Export ZIP: `/exports/all.zip`
- New export: `see_engine_diagnostics_v1.0.9.csv`

Run:
```bash
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN" "2y"
```
