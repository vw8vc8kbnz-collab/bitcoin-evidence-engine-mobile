# SEE v1.0.9 Masterplan

Focus: diagnose why legacy momentum works and add a first measurable catalyst proxy.

New in v1.0.9:
- Engine diagnostics by setup
- Catalyst/theme proxy score
- Extra export CSV for diagnostics
- Dashboard tabs: Overview, Elite, Diagnostics, Tickers
- Same stable server.py deployment baseline
