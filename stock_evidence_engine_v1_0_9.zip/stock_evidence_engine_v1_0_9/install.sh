#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/home/ubuntu/stock_evidence_latest"
SERVICE="/etc/systemd/system/stock-evidence-dashboard.service"
cd "$APP_DIR"
mkdir -p data exports logs
cat > "$SERVICE" <<EOF
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/python3 $APP_DIR/server.py --host 0.0.0.0 --port 8798
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable stock-evidence-dashboard.service
systemctl restart stock-evidence-dashboard.service
