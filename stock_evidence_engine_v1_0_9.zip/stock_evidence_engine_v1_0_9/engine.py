#!/usr/bin/env python3
import csv, json, math, os, sys, zipfile
from datetime import datetime
from pathlib import Path

VERSION='v1.0.9'
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; EXPORTS=ROOT/'exports'
DATA.mkdir(exist_ok=True); EXPORTS.mkdir(exist_ok=True)

THEMES={
 'BB':['ai','robotics','cybersecurity','automotive software','qnx'],
 'PLTR':['ai','defense','government','data platform'],
 'IONQ':['quantum','compute','next-gen'],
 'SOUN':['ai','voice ai','automotive ai'],
 'AI':['enterprise ai','ai software'],
 'BBAI':['ai','defense','analytics'],
 'RKLB':['space','defense','launch'],
 'SMR':['nuclear','energy'],
 'ACHR':['evtol','aviation','mobility'],
 'JOBY':['evtol','aviation','mobility'],
 'HOOD':['fintech','retail trading'],
 'COIN':['crypto','bitcoin'],
 'MARA':['crypto','bitcoin mining'],
 'RIOT':['crypto','bitcoin mining'],
 'AMD':['ai chips','semiconductor','datacenter'],
 'NVDA':['ai chips','semiconductor','datacenter'],
 'TSLA':['ev','robotics','ai'],
 'RIVN':['ev','automotive'],
 'LCID':['ev','automotive'],
 'UPST':['ai lending','fintech']
}

CATALYST_WORDS={
 'ai':18,'robotics':16,'quantum':16,'defense':14,'space':12,'crypto':10,'bitcoin':10,'semiconductor':12,'datacenter':10,'nuclear':10,'evtol':10,'contract':12,'partnership':10,'guidance':12,'earnings':8
}

def safe_float(x, default=0.0):
    try:
        if x is None or (isinstance(x,float) and math.isnan(x)): return default
        return float(x)
    except Exception: return default

def download_prices(ticker, period):
    try:
        import yfinance as yf
        df=yf.download(ticker, period=period, interval='1d', auto_adjust=True, progress=False)
        if df is None or df.empty: return []
        if hasattr(df.columns,'levels'):
            df.columns=[c[0] if isinstance(c, tuple) else c for c in df.columns]
        rows=[]
        for idx,r in df.iterrows():
            rows.append({'date':str(idx.date()), 'open':safe_float(r.get('Open')), 'high':safe_float(r.get('High')), 'low':safe_float(r.get('Low')), 'close':safe_float(r.get('Close')), 'volume':safe_float(r.get('Volume'))})
        return rows
    except Exception as e:
        print(f'[SEE] WARN {ticker}: yfinance failed: {e}')
        return []

def ma(vals,n,i):
    if i+1<n: return None
    return sum(vals[i-n+1:i+1])/n

def ret(rows,i,h):
    if i+h>=len(rows): return None
    a=rows[i]['close']; b=rows[i+h]['close']
    if not a: return None
    return (b/a-1)*100

def features(rows,i):
    closes=[r['close'] for r in rows]; vols=[r['volume'] for r in rows]
    c=closes[i]
    m20=ma(closes,20,i); m50=ma(closes,50,i); v20=ma(vols,20,i)
    prev20=max(closes[max(0,i-20):i]) if i>0 else c
    prev5=closes[i-5] if i>=5 else closes[0]
    prev10=closes[i-10] if i>=10 else closes[0]
    mom5=(c/prev5-1)*100 if prev5 else 0
    mom10=(c/prev10-1)*100 if prev10 else 0
    rv=vols[i]/v20 if v20 and v20>0 else 1
    above50= bool(m50 and c>m50)
    breakout= c>=prev20*1.01 if prev20 else False
    pullback_reclaim= bool(m20 and m50 and c>m20 and m20>m50 and i>2 and closes[i-1]<m20)
    return {'close':c,'m20':m20,'m50':m50,'rv':rv,'mom5':mom5,'mom10':mom10,'above50':above50,'breakout':breakout,'pullback_reclaim':pullback_reclaim}

def signals(ticker, rows, i):
    f=features(rows,i)
    out=[]
    if i<60: return out
    if f['above50'] and f['mom10']>8 and f['rv']>1.25:
        out.append(('momentum_continuation_legacy', f))
    if f['breakout'] and f['rv']>1.5 and f['mom5']>3:
        out.append(('breakout_continuation', f))
    if i>1:
        gap=(rows[i]['open']/rows[i-1]['close']-1)*100 if rows[i-1]['close'] else 0
        intraday=(rows[i]['close']/rows[i]['open']-1)*100 if rows[i]['open'] else 0
        if gap>5 and intraday>-2 and f['rv']>1.3:
            out.append(('gap_and_go', f))
    if f['pullback_reclaim'] and f['rv']>1.0:
        out.append(('pullback_reclaim', f))
    if f['rv']>2.5 and f['mom5']>12:
        out.append(('squeeze_ignition', f))
    return out

def catalyst_score(ticker):
    themes=THEMES.get(ticker.upper(),[])
    score=0
    for t in themes:
        for word,val in CATALYST_WORDS.items():
            if word in t: score+=val
    return min(100, score), '|'.join(themes) if themes else 'none'

def bucket(score):
    if score>=65: return 'ELITE'
    if score>=50: return 'GOOD'
    if score>=35: return 'USABLE'
    return 'LOW'

def main():
    tickers=[x.strip().upper() for x in (sys.argv[1] if len(sys.argv)>1 else 'BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA').split(',') if x.strip()]
    period=sys.argv[2] if len(sys.argv)>2 else '2y'
    holds=[1,3,5,10,20]
    trades=[]; diagnostics=[]
    for ticker in tickers:
        print(f'[SEE] Download {ticker} {period}')
        rows=download_prices(ticker,period)
        if len(rows)<80: continue
        cscore,themes=catalyst_score(ticker)
        tcount=0
        for i in range(60,len(rows)-max(holds)-1):
            for setup,f in signals(ticker,rows,i):
                for h in holds:
                    r=ret(rows,i,h)
                    if r is None: continue
                    trades.append({'ticker':ticker,'date':rows[i]['date'],'setup':setup,'hold':f'{h}d','return_pct':round(r,4),'win':1 if r>0 else 0,'rv':round(f['rv'],3),'mom5':round(f['mom5'],3),'mom10':round(f['mom10'],3),'catalyst_score':cscore,'themes':themes})
                    tcount+=1
        print(f'[SEE] {ticker}: {tcount} trades')
    # summary
    groups={}
    for tr in trades:
        key=(tr['ticker'],tr['setup'],tr['hold'])
        groups.setdefault(key,[]).append(tr)
    summary=[]
    for (ticker,setup,hold),trs in groups.items():
        n=len(trs); wins=sum(t['win'] for t in trs); avg=sum(t['return_pct'] for t in trs)/n
        winrate=wins/n*100
        cscore=trs[0]['catalyst_score']; themes=trs[0]['themes']
        fake=1 if n<15 else 0
        confidence=min(100, n*2.0)
        evidence=avg*2.0 + (winrate-50)*0.8 + min(n,50)*0.45 + cscore*0.08
        if fake: evidence-=25
        good=1 if n>=20 and winrate>=55 and avg>2 and evidence>=40 else 0
        elite=1 if n>=30 and winrate>=60 and avg>4 and evidence>=55 else 0
        reason=[]
        if n<15: reason.append('tiny_sample_penalty')
        if setup=='momentum_continuation_legacy': reason.append('legacy_momentum_core')
        if cscore>=30: reason.append('theme_catalyst_boost')
        if avg>8: reason.append('high_expectancy')
        summary.append({'ticker':ticker,'setup':setup,'hold':hold,'trades':n,'winrate':round(winrate,2),'avg_return_pct':round(avg,2),'expectancy_pct':round(avg,2),'evidence_score':round(evidence,2),'confidence':round(confidence,1),'catalyst_score':cscore,'themes':themes,'fake_alpha_warning':fake,'good_candidate':good,'elite':elite,'tier':bucket(evidence),'rank_reason':', '.join(reason)})
    summary.sort(key=lambda x:(x['elite'],x['good_candidate'],x['evidence_score'],x['trades']), reverse=True)
    def write_csv(path, rows):
        if not rows: return
        with open(path,'w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    write_csv(EXPORTS/f'see_trades_{VERSION}.csv', trades)
    write_csv(EXPORTS/f'see_summary_{VERSION}.csv', summary)
    write_csv(EXPORTS/f'see_elite_{VERSION}.csv', [r for r in summary if r['elite']])
    write_csv(EXPORTS/f'see_usable_{VERSION}.csv', [r for r in summary if r['fake_alpha_warning']==0 and r['tier'] in ('USABLE','GOOD','ELITE')])
    # by ticker/setup diagnostics
    def aggregate(field):
        agg={}
        for r in summary:
            k=r[field]; agg.setdefault(k,{'name':k,'rows':0,'trades':0,'good':0,'elite':0,'avg_evidence':0,'avg_expectancy':0})
            a=agg[k]; a['rows']+=1; a['trades']+=int(r['trades']); a['good']+=int(r['good_candidate']); a['elite']+=int(r['elite']); a['avg_evidence']+=float(r['evidence_score']); a['avg_expectancy']+=float(r['expectancy_pct'])
        out=[]
        for a in agg.values():
            n=a['rows']; a['avg_evidence']=round(a['avg_evidence']/n,2); a['avg_expectancy']=round(a['avg_expectancy']/n,2); out.append(a)
        out.sort(key=lambda x:(x['elite'],x['good'],x['avg_evidence']), reverse=True)
        return out
    by_ticker=aggregate('ticker'); by_setup=aggregate('setup')
    write_csv(EXPORTS/f'see_by_ticker_{VERSION}.csv', by_ticker)
    write_csv(EXPORTS/f'see_by_setup_{VERSION}.csv', by_setup)
    # engine diagnostics with signal contribution
    diagnostics=by_setup
    write_csv(EXPORTS/f'see_engine_diagnostics_{VERSION}.csv', diagnostics)
    state={'version':VERSION,'updated_at':datetime.utcnow().isoformat()+'Z','summary_rows':len(summary),'trades':len(trades),'elite':sum(int(r['elite']) for r in summary),'good':sum(int(r['good_candidate']) for r in summary),'tickers':len(tickers),'top':summary[:25],'by_setup':by_setup,'by_ticker':by_ticker}
    (DATA/'state.json').write_text(json.dumps(state,indent=2))
    with zipfile.ZipFile(EXPORTS/'all.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in EXPORTS.glob(f'*_{VERSION}.csv'):
            z.write(p,p.name)
    print(f'[SEE] Done. trades={len(trades)} summary_rows={len(summary)} elite={state["elite"]} good={state["good"]}')
if __name__=='__main__': main()
