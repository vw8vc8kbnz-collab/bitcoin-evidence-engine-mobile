"use client";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { OutletBatch } from "@/lib/types";

type BatchWithCounts = OutletBatch & { counts?: { photos: number; groups: number; ready: number; review: number; processing: number } };
const TYPES = ["retouren", "b-stock", "showroom", "restpartij", "faillissement", "overig"] as const;

export function OutletBatchCreator() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [f, setF] = useState({ reference: "", supplier: "", partyType: "retouren", warehouseLocation: "", estimatedProducts: "", notes: "" });
  async function create() {
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/outlet-batches", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...f, estimatedProducts: Number(f.estimatedProducts) || undefined }) });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.batch?.id) router.push(`/partner/outlet/${j.batch.id}`);
    else setErr(j.error || "Partij aanmaken mislukt");
  }
  return <section className="outletCreateCard">
    <span className="eyebrow">OUTLET INVENTORY CRM</span>
    <h1>Nieuwe outletpartij</h1>
    <p>Maak eerst een partij met referentie. Daarna upload je alle foto’s en groepeert Outrun ze veilig per product.</p>
    <div className="outletFormGrid">
      <label>Referentie<input value={f.reference} onChange={e => setF({ ...f, reference: e.target.value })} placeholder="bv. MM-RET-2026-0712" /></label>
      <label>Leverancier<input value={f.supplier} onChange={e => setF({ ...f, supplier: e.target.value })} placeholder="optioneel" /></label>
      <label>Type partij<select value={f.partyType} onChange={e => setF({ ...f, partyType: e.target.value })}>{TYPES.map(t => <option key={t} value={t}>{t}</option>)}</select></label>
      <label>Magazijnlocatie<input value={f.warehouseLocation} onChange={e => setF({ ...f, warehouseLocation: e.target.value })} placeholder="bv. Pallet A17" /></label>
      <label>Geschat aantal<input type="number" value={f.estimatedProducts} onChange={e => setF({ ...f, estimatedProducts: e.target.value })} placeholder="bv. 80" /></label>
      <label className="wide">Opmerking<input value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} placeholder="bv. retourpartij, labels vaak aanwezig" /></label>
    </div>
    {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
    <button className="btn pri" onClick={create} disabled={busy}>{busy ? "Aanmaken…" : "Start uploadstudio"}</button>
  </section>;
}

export function OutletBatchOverview({ batches }: { batches: BatchWithCounts[] }) {
  return <div className="outletBatchList">
    {batches.map(b => <a className="outletBatchCard" href={`/partner/outlet/${b.id}`} key={b.id}>
      <span><b>{b.reference}</b><small>{b.partyType} · {b.supplier || "geen leverancier"}</small></span>
      <em>{b.counts?.groups || b.groups.length} producten</em>
      <div className="outletBatchBars"><i style={{ width: `${Math.min(100, ((b.counts?.ready || 0) / Math.max(1, b.groups.length)) * 100)}%` }} /></div>
      <small>{b.counts?.photos || b.photos.length} foto’s · {b.counts?.review || 0} controle · {b.status}</small>
    </a>)}
  </div>;
}

export function OutletBatchStudio({ initialBatch }: { initialBatch: OutletBatch }) {
  const router = useRouter();
  const [batch, setBatch] = useState(initialBatch);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [selected, setSelected] = useState<string | null>(batch.groups[0]?.id || null);
  const selectedGroup = batch.groups.find(g => g.id === selected) || batch.groups[0];
  const photosById = useMemo(() => new Map(batch.photos.map(p => [p.id, p])), [batch.photos]);
  const ready = batch.groups.filter(g => g.status === "ready_for_ai" || g.status === "ready_to_publish").length;
  const review = batch.groups.filter(g => g.status === "needs_review" || g.status === "draft" || g.status === "error").length;
  async function refresh() {
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}`, { cache: "no-store" });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.batch) setBatch(j.batch);
    router.refresh();
  }
  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true); setErr("");
    const fd = new FormData();
    Array.from(files).forEach(f => fd.append("photos", f));
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}/photos`, { method: "POST", body: fd });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.batch) { setBatch(j.batch); setSelected(j.batch.groups[0]?.id || null); }
    else setErr(j.error || "Upload mislukt");
  }
  async function patchGroup(groupId: string, patch: any) {
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}/groups/${groupId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch) });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.batch) setBatch(j.batch); else setErr(j.error || "Opslaan mislukt");
  }
  async function queue() {
    setBusy(true); setErr("");
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}/queue`, { method: "POST" });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.batch) setBatch(j.batch); else setErr(j.error || "Queue starten mislukt");
  }
  const groupPhotos = selectedGroup ? selectedGroup.photoIds.map(id => photosById.get(id)).filter(Boolean) as OutletBatch["photos"] : [];
  return <section className="outletStudio">
    <div className="outletHero">
      <span className="eyebrow">UPLOAD BATCH</span>
      <h1>{batch.reference}</h1>
      <p>{batch.partyType} · {batch.supplier || "leverancier onbekend"} · {batch.warehouseLocation || "geen magazijnlocatie"}</p>
      <div className="outletStats"><span><b>{batch.photos.length}</b><small>foto’s</small></span><span><b>{batch.groups.length}</b><small>producten</small></span><span><b>{review}</b><small>controle</small></span><span><b>{ready}</b><small>klaar</small></span></div>
    </div>
    <label className="outletDrop">{busy ? "Uploaden…" : "Sleep/selecteer foto’s van deze outletpartij"}<input type="file" accept="image/*" multiple hidden onChange={e => upload(e.target.files)} /><small>AI groepeert per product, maar publiceert nooit automatisch. Label/typeplaatjes blijven standaard privé.</small></label>
    {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
    <div className="outletWorkspace">
      <aside className="outletGroups">
        <div className="dsec"><h2>Productgroepen</h2><span>AI VOORSTEL</span></div>
        {batch.groups.length === 0 && <p className="note">Nog geen foto’s. Upload eerst een partij.</p>}
        {batch.groups.map(g => <button key={g.id} onClick={() => setSelected(g.id)} className={selectedGroup?.id === g.id ? "on" : ""}>
          <b>{g.title || g.reference}</b><small>{g.photoIds.length}/5 foto’s · {g.aiConfidence}/100</small><em>{g.status === "needs_review" ? "controle" : g.status.replaceAll("_", " ")}</em>
        </button>)}
      </aside>
      <div className="outletReviewPanel">
        {!selectedGroup ? <p className="note">Selecteer een productgroep.</p> : <>
          <div className="outletReviewTop"><span><b>{selectedGroup.reference}</b><small>{selectedGroup.status}</small></span><button className="btn ghost" onClick={() => patchGroup(selectedGroup.id, { status: selectedGroup.status === "ready_for_ai" ? "needs_review" : "ready_for_ai" })}>{selectedGroup.status === "ready_for_ai" ? "Terug naar controle" : "Groep klopt"}</button></div>
          <div className="outletPhotoWall">
            {groupPhotos.map(p => <article key={p.id} className={!p.publicAllowed ? "private" : ""}>
              {/* eslint-disable-next-line @next/next/no-img-element */}<img src={p.url} alt="" />
              <span>{p.role}{!p.publicAllowed ? " · privé" : ""}</span>
              <button onClick={() => patchGroup(selectedGroup.id, { mainPhotoId: p.id })}>{selectedGroup.mainPhotoId === p.id ? "Hoofdfoto" : "Maak hoofd"}</button>
            </article>)}
          </div>
          <div className="outletGroupEdit">
            <label>Productreferentie<input defaultValue={selectedGroup.reference} onBlur={e => patchGroup(selectedGroup.id, { reference: e.currentTarget.value })} /></label>
            <label>Werktitel<input defaultValue={selectedGroup.title || ""} placeholder="optioneel vóór AI" onBlur={e => patchGroup(selectedGroup.id, { title: e.currentTarget.value })} /></label>
          </div>
          {selectedGroup.missingPhotos?.length ? <p className="note">Let op: {selectedGroup.missingPhotos.join(" · ")}</p> : null}
        </>}
      </div>
    </div>
    <div className="outletQueueBar"><button className="btn pri" onClick={queue} disabled={busy || batch.groups.length === 0}>Zet gecontroleerde groepen in AI queue</button><button className="btn ghost" onClick={refresh}>Ververs status</button><span>{batch.jobs.filter(j => j.status === "waiting").length} wachtend · {batch.jobs.filter(j => j.status === "error").length} fout</span></div>
  </section>;
}
