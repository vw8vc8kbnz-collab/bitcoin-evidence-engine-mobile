# Outrun IQ v8.6.1

AI-commerceplatform voor outlet/voorraaddeals. Deze versie bouwt verder op v8.5.10 en voegt de eerste echte zakelijke onboarding- en inventory reviewlaag toe.

Belangrijkste routes:
- `/partner/storefront` — partner onboarding, storeprofiel, levering/retour en payout-preview.
- `/partner/voorraad` — inventory-statusflow met review-checklist.
- `/partner/nieuw` — bestaande AI-upload, prijsadvies en listing writer.

Deploypad op VPS: `/var/www/outrun-iq-v5`.


## v8.6.1 Outlet Inventory CRM
Gebruik `/partner/outlet` om een outletpartij/batch aan te maken, foto’s te uploaden, productgroepen veilig te controleren en gecontroleerde groepen in de AI queue te zetten.
