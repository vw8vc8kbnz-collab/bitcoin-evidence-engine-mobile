# v8.6.1 — Outlet Inventory CRM

- Nieuwe partnerroute `/partner/outlet` voor outlet-/retour-/restpartij batches.
- Batchreferentiesysteem met leverancier, partijtype, magazijnlocatie, geschat aantal producten en opmerkingen.
- Uploadstudio voor veel foto’s binnen één partij met server-safe limieten.
- Foto’s worden gekoppeld aan batch, productgroep, rol, public/private status en duplicate-hash.
- AI-groepering is bewust semi-automatisch: Outrun stelt groepen voor, partner bevestigt.
- Label/typeplaatje/barcode-foto’s blijven standaard privé en worden niet automatisch buyer-facing.
- Productgroepen krijgen interne referenties per batch, status, confidence, hoofdfoto en controleflag.
- Compacte processing queue met waiting/running/done/error basis en retry-metadata voorbereid.
- Partnerhub stuurt voortaan naar “Nieuwe outletpartij” als aanbevolen flow, losse productflow blijft beschikbaar.
- Bestaande v8.6.0 onboarding, storefront, inventory-statusflow en review-checklist blijven behouden.

# Changelog

## v8.6.0 — Partner Onboarding & Inventory Flow
- Partnerprofiel uitgebreid met bedrijfsnaam, KvK, BTW-nummer, contactpersoon, zakelijke e-mail/telefoon, leveringsopties, standaard verzendkosten, payout/bankstatus en Stripe Connect-previewstatus.
- Storefront-editor omgebouwd tot echte partner onboarding-flow met logo, banner, bedrijfsprofiel, afhaaladres, klantenservice en retourvoorwaarden.
- Nieuwe inventory-statusflow toegevoegd: draft, ai_processing, needs_review, ready_to_publish, published, reserved, sold en archived. Legacy active/paused blijft backwards-compatible.
- Nieuwe listings krijgen automatisch een review-checklist: titel, prijs, categorie, foto, modelbevestiging, prijsbevestiging, beschrijving en SEO.
- Voorraadscherm toont live/review/verkocht en checklist-score per product.
- Buyer-facing zichtbaarheid accepteert published én legacy active, zodat bestaande voorraad niet verdwijnt.
- Finance blijft veilig: payout/Stripe Connect zijn statusvelden; geen live geldverplaatsing.

## v8.5.10 — Product Resolver Depth & Clean Titles
- Basis voor productresolver met modelkeuzes, schonere titels en buyer-facing cleanup.
