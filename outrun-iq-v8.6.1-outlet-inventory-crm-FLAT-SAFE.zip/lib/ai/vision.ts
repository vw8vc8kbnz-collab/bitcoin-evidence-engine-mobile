/** Vision-taakroute van de AI Model Abstraction Layer.
 *
 * Belangrijk: vision wordt bewust NIET meer stil naar DeepSeek-text teruggezet.
 * Zet expliciet VISION_API_KEY + VISION_MODEL op een multimodaal model
 * (bijv. OpenAI gpt-4o-mini of een EU multimodaal model). Zonder die env-vars
 * blijft vision uit en vult de partner de velden handmatig in.
 */

export type VisionFields = {
  title: string;
  brand: string;
  model: string;
  category: "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
  color: string;
  condition: string;
  conditionScore: number;     // 1-10
  conditionReason: string;    // korte verdedigbare motivatie
  defect: string;             // leeg = geen zichtbaar gebrek
  defects: string[];          // per-foto schade/gebrek observaties
  accessories: string[];
  energyLabel: string;
  newPriceEstimate: number;   // geschatte adviesprijs in hele euro's, 0 = onbekend
  sellingPoints: string[];
  modelCandidates: string[];
  articleNumber: string;
  serialMasked: string;
  ocrText: string;
  confidence: number;
  needsExtraPhotos: string[];
  photoRoles: { index: number; role: "hero" | "angle" | "condition" | "accessories" | "label" | "serial" | "packaging" | "irrelevant"; buyerFacing: boolean; reason?: string }[];
  uncertainty: boolean;
  source: string;
};

const CATS = ["witgoed", "meubels", "keukens", "tuin", "overig"] as const;

function num(x: unknown): number {
  if (typeof x === "number" && isFinite(x)) return Math.round(x);
  if (typeof x === "string") {
    const v = parseFloat(x.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", "."));
    if (isFinite(v)) return Math.round(v);
  }
  return 0;
}
function str(x: unknown, max = 160): string { return String(x ?? "").slice(0, max).trim(); }
function arr(x: unknown, maxItems = 5, maxLen = 90): string[] {
  return Array.isArray(x) ? x.map(v => str(v, maxLen)).filter(Boolean).slice(0, maxItems) : [];
}
function roles(x: unknown, maxPhotos = 5): VisionFields["photoRoles"] {
  if (!Array.isArray(x)) return [];
  const allowed = new Set(["hero", "angle", "condition", "accessories", "label", "serial", "packaging", "irrelevant"]);
  return x.map((v, i) => {
    const o = (v && typeof v === "object") ? v as Record<string, unknown> : {};
    const idx = Math.min(maxPhotos, Math.max(1, num(o.index) || (i + 1)));
    const role = allowed.has(String(o.role)) ? String(o.role) as VisionFields["photoRoles"][number]["role"] : "angle";
    const buyerFacing = typeof o.buyerFacing === "boolean" ? o.buyerFacing : !["label", "serial", "irrelevant"].includes(role);
    return { index: idx, role, buyerFacing, reason: str(o.reason, 80) || undefined };
  }).filter(x => x.index >= 1 && x.index <= maxPhotos).slice(0, maxPhotos);
}



const MOTOR_HALLUCINATION_MODELS = [
  "yamaha xv 535 virago", "xv 535 virago", "xv535 virago", "yamaha virago",
  "honda shadow", "suzuki intruder", "kawasaki vulcan"
];
function lc(v: string) { return v.toLowerCase().replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim(); }
function hasAny(hay: string, needles: string[]) { const x = lc(hay); return needles.some(n => x.includes(lc(n))); }
function normalizeVehicleIdentity(out: VisionFields): VisionFields {
  const hay = `${out.title} ${out.brand} ${out.model} ${out.condition} ${out.conditionReason} ${out.sellingPoints.join(" ")} ${out.modelCandidates.join(" ")} ${out.ocrText}`;
  const isMotor = hasAny(hay, ["motor", "motorfiets", "cruiser", "touring", "harley", "road king", "softail", "saddlebags", "koffers", "v twin", "v-twin"]);
  if (!isMotor) return out;

  const hallucinatedJapaneseCruiser = hasAny(`${out.title} ${out.brand} ${out.model}`, MOTOR_HALLUCINATION_MODELS)
    && !hasAny(out.ocrText, ["yamaha", "virago", "xv535", "xv 535"]);

  const harleySignals = hasAny(hay, ["harley", "harley-davidson", "road king", "softail", "heritage", "touring", "grote v-twin", "v-twin", "hard bags", "zijkoffers", "floorboards", "treeplanken", "whitewall", "klassieke cruiser"]);

  if (hallucinatedJapaneseCruiser || (harleySignals && out.brand.toLowerCase() !== "harley-davidson")) {
    const candidates = Array.from(new Set([
      "Harley-Davidson Road King / Road King Classic",
      "Harley-Davidson Heritage Softail Classic",
      "Harley-Davidson Softail Deluxe",
      ...out.modelCandidates.filter(x => !hasAny(x, MOTOR_HALLUCINATION_MODELS)),
    ])).slice(0, 4);
    return {
      ...out,
      title: "Harley-Davidson cruiser/touring motor",
      brand: "Harley-Davidson",
      model: "Cruiser / touring (model bevestigen)",
      category: "overig",
      confidence: Math.min(86, Math.max(out.confidence || 0, 78)),
      uncertainty: true,
      modelCandidates: candidates,
      needsExtraPhotos: Array.from(new Set([
        "foto van tanklogo of embleem",
        "foto van dashboard/typeplaatje",
        "foto van kentekenbewijs of modelcode",
        ...out.needsExtraPhotos,
      ])).slice(0, 4),
      conditionReason: out.conditionReason || "De motor lijkt goed onderhouden; merk/model blijft een AI-suggestie tot logo of typeplaatje zichtbaar is.",
      sellingPoints: Array.from(new Set(["Harley-Davidson-stijl cruiser/touring", "zijkoffers zichtbaar", ...out.sellingPoints])).slice(0, 3),
    };
  }

  // Algemene motorfiets-regel: geen hard model automatisch vastzetten bij lage zekerheid.
  if (out.confidence < 88 && !out.ocrText && out.model && !out.uncertainty) {
    return {
      ...out,
      model: `${out.model} (bevestigen)`,
      uncertainty: true,
      needsExtraPhotos: out.needsExtraPhotos.length ? out.needsExtraPhotos : ["foto van merklogo", "foto van typeplaatje of kentekenbewijs"],
    };
  }
  return out;
}


const GENERIC_HEADPHONE_TERMS = ["koptelefoon", "headset", "hoofdtelefoon", "draadloze koptelefoon", "wireless headphone", "noise cancelling", "anc"];
const SONY_HEADPHONE_MODELS = [
  "Sony WH-1000XM5",
  "Sony WH-1000XM4",
  "Sony WH-1000XM3",
  "Sony ULT Wear",
  "Sony WH-CH720N"
];
function normalizeAudioIdentity(out: VisionFields): VisionFields {
  const hay = `${out.title} ${out.brand} ${out.model} ${out.condition} ${out.conditionReason} ${out.sellingPoints.join(" ")} ${out.modelCandidates.join(" ")} ${out.ocrText}`;
  const isHeadphone = hasAny(hay, GENERIC_HEADPHONE_TERMS) || hasAny(hay, ["oorschelp", "hoofdband", "sony wh", "wh-1000", "1000xm"]);
  if (!isHeadphone) return out;

  const isSony = hasAny(hay, ["sony", "wh-1000", "1000xm", "ult wear", "ch720"]);
  if (!isSony) return out;

  const exactSony = SONY_HEADPHONE_MODELS.find(m => hasAny(hay, [m, m.replace("Sony ", ""), m.replace("Sony WH-", "WH-")]));
  if (exactSony && out.confidence >= 90) {
    return {
      ...out,
      brand: "Sony",
      model: exactSony.replace(/^Sony\s+/, ""),
      title: exactSony.includes("Sony ") ? `${exactSony} ${out.color || "Zwart"}`.trim().slice(0, 70) : `Sony ${exactSony}`,
      category: "overig",
      uncertainty: false,
      modelCandidates: [],
      needsExtraPhotos: out.needsExtraPhotos.filter(x => !hasAny(x, ["model", "typeplaatje"])),
    };
  }

  const genericSonyTitle = hasAny(`${out.title} ${out.model}`, ["sony draadloze koptelefoon", "sony koptelefoon", "sony hoofdtelefoon", "sony headset"]);
  const lacksSpecificModel = !hasAny(`${out.title} ${out.model}`, ["wh-1000xm", "ult wear", "wh-ch", "xm5", "xm4", "xm3"]);
  if (genericSonyTitle || lacksSpecificModel || out.confidence < 92) {
    const candidates = Array.from(new Set([
      "Sony WH-1000XM5",
      "Sony WH-1000XM4",
      "Sony WH-1000XM3",
      ...out.modelCandidates.filter(x => !hasAny(x, ["algemene", "koptelefoon", "headset"])),
    ])).slice(0, 4);
    return {
      ...out,
      title: "Sony WH-1000X-serie koptelefoon",
      brand: "Sony",
      model: "WH-1000X-serie (model bevestigen)",
      category: "overig",
      confidence: Math.min(88, Math.max(out.confidence || 0, 82)),
      uncertainty: true,
      modelCandidates: candidates,
      needsExtraPhotos: Array.from(new Set([
        "foto van de binnenkant/typecode",
        "foto van doos of modelsticker",
        "close-up van knop/arm met modeltekst",
        ...out.needsExtraPhotos,
      ])).slice(0, 4),
      conditionReason: out.conditionReason || "Sony over-ear koptelefoon herkend; exact WH-model moet nog bevestigd worden.",
      sellingPoints: Array.from(new Set(["Sony over-ear koptelefoon", "waarschijnlijk WH-1000X-serie", ...out.sellingPoints])).slice(0, 3),
    };
  }
  return out;
}

const THRUSTMASTER_WHEEL_MODELS = [
  "Thrustmaster T300 RS GT",
  "Thrustmaster T300 RS",
  "Thrustmaster T-GT II",
  "Thrustmaster T248",
  "Thrustmaster TX Racing Wheel"
];
function normalizeGamingWheelIdentity(out: VisionFields): VisionFields {
  const hay = `${out.title} ${out.brand} ${out.model} ${out.condition} ${out.conditionReason} ${out.sellingPoints.join(" ")} ${out.modelCandidates.join(" ")} ${out.ocrText}`;
  const isWheel = hasAny(hay, ["thrustmaster", "racing wheel", "racestuur", "stuurwiel", "pedalen", "playstation", "official licensed product", "t300", "t248", "t-gt"]);
  if (!isWheel) return out;
  const candidates = Array.from(new Set([
    ...out.modelCandidates.filter(Boolean),
    ...THRUSTMASTER_WHEEL_MODELS,
  ])).slice(0, 6);
  const exact = candidates.find(c => hasAny(hay, [c, c.replace("Thrustmaster ", "")])) || "Thrustmaster T300 RS GT";
  return {
    ...out,
    title: exact,
    brand: "Thrustmaster",
    model: exact.replace(/^Thrustmaster\s+/, ""),
    category: "overig",
    confidence: Math.min(90, Math.max(out.confidence || 0, 78)),
    uncertainty: true,
    modelCandidates: candidates,
    needsExtraPhotos: Array.from(new Set(["foto van typeplaatje of doos", "close-up van stuurbase/modeltekst", ...out.needsExtraPhotos])).slice(0, 4),
    sellingPoints: Array.from(new Set(["racing wheel met pedalen", "geschikt voor racegames", ...out.sellingPoints])).slice(0, 3),
  };
}

function normalizeApplianceIdentity(out: VisionFields): VisionFields {
  const hay = `${out.title} ${out.brand} ${out.model} ${out.category} ${out.condition} ${out.conditionReason} ${out.sellingPoints.join(" ")} ${out.modelCandidates.join(" ")} ${out.ocrText}`;
  const brand = hasAny(hay, ["samsung"]) ? "Samsung" : hasAny(hay, ["bosch"]) ? "Bosch" : hasAny(hay, ["miele"]) ? "Miele" : hasAny(hay, ["siemens"]) ? "Siemens" : hasAny(hay, ["lg"]) ? "LG" : out.brand;
  const isWasher = hasAny(hay, ["wasmachine", "washer", "eco bubble", "ecobubble", "addwash", "ww", "quickdrive", "bespoke ai", "trommel"]);
  const isFridge = hasAny(hay, ["koelkast", "vriesvak", "koel vries", "koel-vries", "fridge", "freezer", "no frost", "rb", "bespoke"]);
  const isDryer = hasAny(hay, ["droger", "warmtepompdroger", "dryer", "dv90", "heat pump"]);
  if (!brand || (!isWasher && !isFridge && !isDryer)) return out;
  let generic = `${brand} witgoed`;
  let candidates: string[] = [];
  if (isWasher) { generic = `${brand} wasmachine`; candidates = [`${brand} EcoBubble wasmachine`, `${brand} Bespoke AI wasmachine`, `${brand} AddWash wasmachine`, `${brand} QuickDrive wasmachine`, `${brand} wasmachine 8-9 kg`]; }
  if (isFridge) { generic = `${brand} koel-vriescombinatie`; candidates = [`${brand} koel-vriescombinatie No Frost`, `${brand} Bespoke koel-vriescombinatie`, `${brand} koelkast met vriesvak`, `${brand} RB-serie koel-vriescombinatie`]; }
  if (isDryer) { generic = `${brand} warmtepompdroger`; candidates = [`${brand} DV90 warmtepompdroger`, `${brand} Bespoke warmtepompdroger`, `${brand} warmtepompdroger 9 kg`]; }
  const hasSpecific = hasAny(`${out.title} ${out.model} ${out.modelCandidates.join(" ")}`, ["ecobubble", "addwash", "quickdrive", "bespoke", "no frost", "dv90", "ww90", "rb3", "rb5"]);
  if (hasSpecific && out.confidence >= 88) return out;
  return {
    ...out,
    title: generic,
    brand,
    model: generic.replace(`${brand} `, ""),
    category: "witgoed",
    confidence: Math.min(86, Math.max(out.confidence || 0, 70)),
    uncertainty: true,
    modelCandidates: Array.from(new Set([...out.modelCandidates, ...candidates])).slice(0, 6),
    needsExtraPhotos: Array.from(new Set(["foto van typeplaatje/modelsticker", "foto van energielabel", "foto van display/bedieningspaneel", ...out.needsExtraPhotos])).slice(0, 4),
  };
}

function cleanModelConfirmText(out: VisionFields): VisionFields {
  const clean = (v: string) => String(v || "").replace(/\s*\((?:model\s*)?bevestigen\)\s*/gi, " ").replace(/\s{2,}/g, " ").trim();
  return { ...out, title: clean(out.title), model: clean(out.model), brand: clean(out.brand), modelCandidates: out.modelCandidates.map(clean).filter(Boolean) };
}

export function isVisionConfigured() {
  return Boolean(process.env.VISION_API_KEY && process.env.VISION_MODEL);
}

export async function analyzeProductPhotos(dataUrls: string[]): Promise<VisionFields | null> {
  const key = process.env.VISION_API_KEY;
  const model = process.env.VISION_MODEL;
  if (!key || !model) {
    console.error("[ai-vision] uitgeschakeld: VISION_API_KEY en VISION_MODEL zijn verplicht voor beeldherkenning.");
    return null;
  }
  const api = process.env.VISION_BASE_URL || "https://api.openai.com/v1/chat/completions";
  const images = dataUrls.filter(Boolean).slice(0, 5);
  if (!images.length) return null;

  const sys = `Je bent de productherkenning van Outrun IQ, een Nederlandse outlet-marketplace. Je krijgt maximaal 5 foto's van hetzelfde product. Foto 1 is meestal de hoofdproductfoto; latere foto's kunnen zijkant, verpakking, label, serienummer, artikelnummer of schade tonen. Beoordeel merk, model, conditie en gebreken op basis van ALLE foto's. Antwoord UITSLUITEND met geldige JSON, exact deze sleutels:
{"title":"","brand":"","model":"","category":"","color":"","condition":"","conditionScore":0,"conditionReason":"","defect":"","defects":[],"accessories":[],"energyLabel":"","newPriceEstimate":0,"sellingPoints":[],"modelCandidates":[],"articleNumber":"","serialMasked":"","ocrText":"","confidence":0,"needsExtraPhotos":[],"photoRoles":[],"uncertainty":false}
Regels: title = korte Nederlandse producttitel incl. merk en model/kandidaat indien zichtbaar of sterk aannemelijk, max 80 tekens. Wees NIET generiek als er meer herkenbaar is: schrijf niet alleen "motorfiets", "stoel" of "koptelefoon" als merk/model/type te herkennen of sterk waarschijnlijk is. Voor consumentenelektronica moet je modelseries herkennen en bij twijfel opties geven: een Sony over-ear noise-cancelling koptelefoon moet bij twijfel niet alleen "Sony koptelefoon" worden, maar minimaal "Sony WH-1000X-serie (model bevestigen)" met modelCandidates zoals "Sony WH-1000XM5", "Sony WH-1000XM4" en "Sony WH-1000XM3"; vraag extra foto van typecode/doos als exact model onzeker is. Voor iPhones/MacBooks/Dyson/JBL/Sonos/Jura/Bosch/Miele/Samsung/LG/Siemens idem: merk + serie + 3-6 modelkandidaten in plaats van generieke titel. Voor witgoed mag je nooit alleen "Samsung" of alleen "koelkast/wasmachine" teruggeven: geef minimaal "Samsung wasmachine", "Samsung koel-vriescombinatie" of vergelijkbaar plus modelCandidates zoals EcoBubble, Bespoke AI, AddWash, QuickDrive, No Frost of RB-serie wanneer relevant. Voor gaming/racing producten: herken merk en serie; Thrustmaster stuur met PlayStation badge/pedalen moet opties geven zoals T300 RS GT, T300 RS, T-GT II, T248 of TX afhankelijk van zichtbare kenmerken. Voor voertuigen/motoren moet je extra scherp zijn: kijk naar tankbadge, emblemen, spatborden, motorblok, V-twin-layout, zijkoffers, zadel, floorboards/treeplanken, velgen, whitewalls, dashboard en touring/cruiser-lijnen. Een grote klassieke cruiser/touring motor met zijkoffers en Harley-achtige V-twin mag niet lichtvaardig als Yamaha Virago/Honda Shadow/Suzuki Intruder worden ingevuld. Als Harley-Davidson waarschijnlijker is, geef brand="Harley-Davidson" en model="Cruiser / touring (model bevestigen)" met modelCandidates zoals Road King, Heritage Softail Classic of Softail Deluxe. Bij brede cruiser/touring-motoren met grote V-twin, zijkoffers, treeplanken/floorboards, klassiek spatbord en lage touringlijn moet Harley-Davidson expliciet als eerste kandidaat komen, óók als het logo niet scherp zichtbaar is. Alleen een exact model vastzetten bij zichtbare badge/OCR of zeer hoge zekerheid. Vul nooit Yamaha XV 535 Virago, Honda Shadow, Suzuki Intruder of Kawasaki Vulcan in zonder zichtbaar logo/typeplaatje/OCR; toon die hooguit als lage kandidaat. Anders: brand waarschijnlijk, modelCandidates, confidence lager dan 90 en needsExtraPhotos zoals "foto van tanklogo", "dashboard/typeplaatje" of "kentekenbewijs/modelcode". brand/model alleen als zichtbaar of sterk waarschijnlijk; onzekerheid = true wanneer model niet hard genoeg is. category = precies één uit: witgoed, meubels, keukens, tuin, overig. condition = korte NL conditietekst van wat je ziet. conditionScore 1-10; onzeker = 7. conditionReason = verdedigbare motivatie in één zin. defect = belangrijkste zichtbaar gebrek of leeg. defects = max 5 bullets met per foto wat opvalt, bijv. "foto 3: kras rechts". accessories = zichtbare accessoires/verpakking. energyLabel = energielabel indien zichtbaar. articleNumber = artikelnummer/SKU/EAN/modelcode indien zichtbaar via OCR. serialMasked = serienummer alleen gemaskeerd, bijv. "****1234". ocrText = korte relevante OCR-samenvatting, geen volledige lange tekst. confidence = 0-100 voor merk/model/titel. photoRoles = array met per foto {index, role, buyerFacing, reason}; role één van hero, angle, condition, accessories, label, serial, packaging, irrelevant. Label/serial/barcodefoto's zijn normaal buyerFacing=false: gebruik intern voor AI/OCR, niet in de openbare galerij tenzij ze essentieel zijn. newPriceEstimate = realistische Nederlandse nieuwprijs in hele euro's, 0 = onbekend. sellingPoints = 2-3 korte verkoopargumenten. Verzin geen typenummers, labels of schade die je niet ziet.`;

  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 30_000);
  try {
    const content: any[] = [
      { type: "text", text: `Analyseer deze ${images.length} foto('s) als één product. Gebruik alle foto's, inclusief label-, artikelnummer-, schade- en detailfoto's. Bepaal ook welke foto's openbaar naar buyers mogen en welke intern moeten blijven. Als merk/model niet 90%+ zeker is: geef een waarschijnlijke hoofdkandidaat, modelCandidates en uncertainty=true; verzin geen exact model.` },
      ...images.flatMap((url, idx) => ([
        { type: "text", text: `Foto ${idx + 1}` },
        { type: "image_url", image_url: { url } },
      ])),
    ];
    const res = await fetch(api, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        temperature: 0.1,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content },
        ],
      }),
    });
    if (!res.ok) {
      console.error("[ai-vision] provider weigerde:", res.status, (await res.text().catch(() => "")).slice(0, 400));
      return null;
    }
    const data = await res.json();
    const raw = String(data?.choices?.[0]?.message?.content ?? "");
    const p = JSON.parse(raw.replace(/```json|```/g, "").trim());
    const cat = CATS.includes(p.category) ? p.category : "overig";
    const score = Math.min(10, Math.max(1, num(p.conditionScore) || 7));
    const defects = arr(p.defects, 5, 100);
    const out: VisionFields = {
      title: str(p.title, 70),
      brand: str(p.brand, 40),
      model: str(p.model, 50),
      category: cat,
      color: str(p.color, 30),
      condition: str(p.condition, 140),
      conditionScore: score,
      conditionReason: str(p.conditionReason, 180),
      defect: str(p.defect, 120) || defects[0] || "",
      defects,
      accessories: arr(p.accessories, 5, 60),
      energyLabel: str(p.energyLabel, 20),
      newPriceEstimate: Math.max(0, num(p.newPriceEstimate)),
      sellingPoints: arr(p.sellingPoints, 3, 70),
      modelCandidates: arr(p.modelCandidates, 6, 80),
      articleNumber: str(p.articleNumber, 60),
      serialMasked: str(p.serialMasked, 30),
      ocrText: str(p.ocrText, 220),
      confidence: Math.min(100, Math.max(0, num(p.confidence) || (p.uncertainty ? 55 : 75))),
      needsExtraPhotos: arr(p.needsExtraPhotos, 4, 80),
      photoRoles: roles(p.photoRoles, images.length),
      uncertainty: Boolean(p.uncertainty),
      source: String(data?.model ?? model),
    };
    const normalized = cleanModelConfirmText(normalizeApplianceIdentity(normalizeGamingWheelIdentity(normalizeAudioIdentity(normalizeVehicleIdentity(out)))));
    return normalized.title ? normalized : null;
  } catch (e) {
    console.error("[ai-vision] fout:", e);
    return null;
  } finally { clearTimeout(t); }
}

export async function analyzeProductPhoto(dataUrl: string): Promise<VisionFields | null> {
  return analyzeProductPhotos([dataUrl]);
}
