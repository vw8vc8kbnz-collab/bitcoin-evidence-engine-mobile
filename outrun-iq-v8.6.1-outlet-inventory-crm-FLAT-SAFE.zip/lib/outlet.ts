import crypto from "crypto";
import { mutate, read } from "./store";
import type { OutletBatch, OutletPartyType, OutletPhotoRole, ProcessingJob } from "./types";

const MAX_BATCH_PHOTOS = 300;
const MAX_GROUP_PHOTOS = 5;
const DAILY_PHOTO_LIMIT = 500;

function id(prefix: string) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
function day() { return new Date().toISOString().slice(0, 10); }
function safeRef(v: string) { return String(v || "").trim().replace(/\s+/g, " ").slice(0, 60); }
function autoRef(sellerSlug: string) { return `OUT-${day().replaceAll("-", "")}-${sellerSlug.slice(0, 4).toUpperCase()}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`; }
function photoRole(filename: string): OutletPhotoRole {
  const n = filename.toLowerCase();
  if (/type|label|serial|serie|barcode|ean|sticker|plaat/.test(n)) return "label";
  if (/schade|damage|kras|deuk|defect/.test(n)) return "damage";
  if (/doos|box|pack|verpakking/.test(n)) return "packaging";
  if (/acc|remote|adapter|kabel|access/.test(n)) return "accessory";
  if (/detail|side|zijde|achter|back/.test(n)) return "detail";
  return "unknown";
}
function groupKey(filename: string, index: number) {
  const base = filename.toLowerCase().replace(/\.[a-z0-9]+$/, "").replace(/(img|dsc|photo|foto|image)[-_ ]?/g, "");
  const m = base.match(/([a-z0-9]+)[-_ ](?:0?[1-5]|front|back|label|detail|schade|damage)$/i);
  if (m?.[1] && m[1].length >= 3) return m[1];
  return `auto-${Math.floor(index / MAX_GROUP_PHOTOS) + 1}`;
}
function batchCounts(b: OutletBatch) {
  return {
    photos: b.photos.length,
    groups: b.groups.length,
    ready: b.groups.filter(g => g.status === "ready_to_publish").length,
    review: b.groups.filter(g => g.status === "needs_review" || g.status === "draft" || g.status === "error").length,
    processing: b.groups.filter(g => g.status === "ai_processing").length,
  };
}

export async function listOutletBatches(sellerSlug: string) {
  const db = await read();
  const batches = (db.outletBatches || []).filter(b => b.sellerSlug === sellerSlug).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  return batches.map(b => ({ ...b, counts: batchCounts(b) }));
}
export async function getOutletBatch(sellerSlug: string, batchId: string) {
  const db = await read();
  return (db.outletBatches || []).find(b => b.sellerSlug === sellerSlug && b.id === batchId) || null;
}
export async function createOutletBatch(sellerSlug: string, input: { reference?: string; supplier?: string; partyType?: OutletPartyType; warehouseLocation?: string; estimatedProducts?: number; notes?: string; }) {
  return mutate(db => {
    db.outletBatches ??= [];
    const now = new Date().toISOString();
    const rec: OutletBatch = {
      id: id("batch"), sellerSlug,
      reference: safeRef(input.reference || "") || autoRef(sellerSlug),
      supplier: safeRef(input.supplier || "") || undefined,
      partyType: input.partyType || "retouren",
      warehouseLocation: safeRef(input.warehouseLocation || "") || undefined,
      estimatedProducts: Math.max(0, Math.min(10000, Math.round(Number(input.estimatedProducts) || 0))) || undefined,
      notes: String(input.notes || "").trim().slice(0, 500) || undefined,
      status: "draft", photos: [], groups: [], jobs: [], createdAt: now, updatedAt: now,
    };
    db.outletBatches.push(rec);
    return rec;
  });
}
export async function addPhotosToBatch(sellerSlug: string, batchId: string, files: { url: string; filename: string; buffer: Buffer }[]) {
  return mutate(db => {
    db.outletBatches ??= [];
    const b = db.outletBatches.find(x => x.sellerSlug === sellerSlug && x.id === batchId);
    if (!b) throw new Error("Batch niet gevonden");
    const todayUploaded = db.outletBatches.filter(x => x.sellerSlug === sellerSlug && x.createdAt.slice(0, 10) === day()).reduce((sum, x) => sum + x.photos.length, 0);
    if (todayUploaded + files.length > DAILY_PHOTO_LIMIT) throw new Error(`Daglimiet bereikt (${DAILY_PHOTO_LIMIT} foto's)`);
    if (b.photos.length + files.length > MAX_BATCH_PHOTOS) throw new Error(`Maximaal ${MAX_BATCH_PHOTOS} foto's per outletpartij`);
    const now = new Date().toISOString();
    const existingHashes = new Set(b.photos.map(p => p.hash).filter(Boolean));
    const added = [] as OutletBatch["photos"];
    files.forEach((f, i) => {
      const hash = crypto.createHash("sha256").update(f.buffer).digest("hex");
      if (existingHashes.has(hash)) return;
      const role = photoRole(f.filename);
      const key = groupKey(f.filename, b.photos.length + i);
      const groupId = `grp_${key.replace(/[^a-z0-9-]/g, "").slice(0, 28) || Math.ceil((b.photos.length + i + 1) / MAX_GROUP_PHOTOS)}`;
      const p = { id: id("photo"), url: f.url, filename: f.filename.slice(0, 90), hash, suggestedGroupId: groupId, confirmedGroupId: groupId, role, publicAllowed: role !== "label", confidence: groupId.startsWith("grp_auto") ? 55 : 72, needsReview: role === "label" || groupId.startsWith("grp_auto"), createdAt: now };
      b.photos.push(p); added.push(p); existingHashes.add(hash);
    });
    const groupMap = new Map(b.groups.map(g => [g.id, g]));
    for (const p of added) {
      const gid = p.confirmedGroupId || p.suggestedGroupId || `grp_auto-${b.groups.length + 1}`;
      let g = groupMap.get(gid);
      if (!g) {
        const nr = b.groups.length + 1;
        g = { id: gid, batchId: b.id, reference: `${b.reference}-${String(nr).padStart(3, "0")}`, status: "needs_review", photoIds: [], aiConfidence: p.confidence, aiNotes: [], missingPhotos: [], updatedAt: now };
        b.groups.push(g); groupMap.set(gid, g);
      }
      if (g.photoIds.length < MAX_GROUP_PHOTOS) g.photoIds.push(p.id);
      else {
        const splitId = `${gid}-${Math.ceil((g.photoIds.length + 1) / MAX_GROUP_PHOTOS)}`;
        let s = groupMap.get(splitId);
        if (!s) { s = { id: splitId, batchId: b.id, reference: `${b.reference}-${String(b.groups.length + 1).padStart(3, "0")}`, status: "needs_review", photoIds: [], aiConfidence: 45, aiNotes: ["Automatisch gesplitst: meer dan 5 foto's."], missingPhotos: [], updatedAt: now }; b.groups.push(s); groupMap.set(splitId, s); }
        s.photoIds.push(p.id); p.confirmedGroupId = splitId;
      }
    }
    for (const g of b.groups) {
      const ps = b.photos.filter(p => g.photoIds.includes(p.id));
      g.mainPhotoId ||= ps.find(p => p.publicAllowed)?.id || ps[0]?.id;
      g.status = ps.length === 0 ? "draft" : ps.some(p => p.needsReview) ? "needs_review" : "ready_for_ai";
      g.aiConfidence = Math.round(ps.reduce((sum, p) => sum + p.confidence, 0) / Math.max(1, ps.length));
      g.missingPhotos = g.aiConfidence < 65 ? ["Controleer of alle foto's bij hetzelfde product horen"] : [];
      g.updatedAt = now;
    }
    b.status = "review"; b.updatedAt = now;
    const job: ProcessingJob = { id: id("job"), batchId: b.id, sellerSlug, type: "photo_grouping", status: "done", attempts: 1, maxAttempts: 2, createdAt: now, startedAt: now, finishedAt: now };
    b.jobs.push(job); db.processingJobs ??= []; db.processingJobs.push(job);
    return { batch: b, added: added.length, skippedDuplicates: files.length - added.length };
  });
}
export async function updateOutletBatch(sellerSlug: string, batchId: string, patch: any) {
  return mutate(db => {
    const b = (db.outletBatches || []).find(x => x.sellerSlug === sellerSlug && x.id === batchId);
    if (!b) throw new Error("Batch niet gevonden");
    if (patch.reference !== undefined) b.reference = safeRef(patch.reference) || b.reference;
    if (patch.supplier !== undefined) b.supplier = safeRef(patch.supplier) || undefined;
    if (patch.warehouseLocation !== undefined) b.warehouseLocation = safeRef(patch.warehouseLocation) || undefined;
    if (["retouren", "b-stock", "showroom", "restpartij", "faillissement", "overig"].includes(patch.partyType)) b.partyType = patch.partyType;
    if (patch.notes !== undefined) b.notes = String(patch.notes || "").slice(0, 500) || undefined;
    b.updatedAt = new Date().toISOString();
    return b;
  });
}
export async function patchGroup(sellerSlug: string, batchId: string, groupId: string, patch: any) {
  return mutate(db => {
    const b = (db.outletBatches || []).find(x => x.sellerSlug === sellerSlug && x.id === batchId);
    const g = b?.groups.find(x => x.id === groupId);
    if (!b || !g) throw new Error("Groep niet gevonden");
    if (patch.reference !== undefined) g.reference = safeRef(patch.reference) || g.reference;
    if (patch.title !== undefined) g.title = safeRef(patch.title) || undefined;
    if (patch.status === "ready_for_ai" || patch.status === "needs_review") g.status = patch.status;
    if (patch.mainPhotoId && g.photoIds.includes(patch.mainPhotoId)) g.mainPhotoId = patch.mainPhotoId;
    if (Array.isArray(patch.publicPhotoIds)) {
      const set = new Set(patch.publicPhotoIds.map(String));
      for (const p of b.photos) if (g.photoIds.includes(p.id)) p.publicAllowed = set.has(p.id) && p.role !== "label";
    }
    g.updatedAt = b.updatedAt = new Date().toISOString();
    return { batch: b, group: g };
  });
}
export async function enqueueBatchAi(sellerSlug: string, batchId: string) {
  return mutate(db => {
    const b = (db.outletBatches || []).find(x => x.sellerSlug === sellerSlug && x.id === batchId);
    if (!b) throw new Error("Batch niet gevonden");
    const now = new Date().toISOString();
    const jobs: ProcessingJob[] = [];
    for (const g of b.groups) {
      if (!["ready_for_ai", "needs_review"].includes(g.status)) continue;
      const ps = b.photos.filter(p => g.photoIds.includes(p.id));
      if (!ps.length) continue;
      g.status = ps.some(p => p.needsReview) ? "needs_review" : "ai_processing";
      const job: ProcessingJob = { id: id("job"), batchId: b.id, groupId: g.id, sellerSlug, type: "listing_ai", status: g.status === "ai_processing" ? "waiting" : "error", attempts: 0, maxAttempts: 2, error: g.status === "needs_review" ? "Menselijke controle nodig vóór AI-verwerking" : undefined, createdAt: now };
      b.jobs.push(job); jobs.push(job); db.processingJobs ??= []; db.processingJobs.push(job);
    }
    b.status = jobs.some(j => j.status === "waiting") ? "ready_to_process" : "review";
    b.updatedAt = now;
    return { batch: b, jobs };
  });
}
