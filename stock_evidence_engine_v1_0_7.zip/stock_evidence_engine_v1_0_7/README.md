# Stock Evidence Engine v1.0.7

Werkende baseline op poort 8798 met één stdlib `server.py` dashboard.

Nieuw in v1.0.7:
- Elite en Usable tabs
- Harder fake-alpha filter
- `good_candidate`, `elite`, `rank_reason` in summary
- Betere conservative ranking
- Geen FastAPI/uvicorn dashboard runtime

Deploy volgens vaste flow: ZIP naar `/home/ubuntu`, uitpakken naar `/home/ubuntu/stock_evidence_latest`, `./install.sh`, `./run_backtest.sh`, service check.


## v1.0.7
- Added one-click `/exports/all.zip` audit export.
- ZIP contains summary, trades, elite, usable, by_ticker and by_setup CSV files.
- Keeps stable server.py runtime on port 8798.
