# SEE v1.0.7 Masterplan

V1.0.7 maakt de research-ranking strenger. Tiny samples worden niet meer prominent als alpha behandeld.

Criteria:
- usable: trades >= 15 en geen fake-alpha warning
- good_candidate: trades >= 20, winrate >= 55%, avg_return > 2%, evidence_score >= 40
- elite: trades >= 30, winrate >= 60%, avg_return > 4%, evidence_score >= 55

Vaste deployment baseline blijft v1.0.3/1.0.5 stijl: stdlib server.py op poort 8798.

Volgende stap: live news/catalyst research-laag pas toevoegen nadat research-signalen betrouwbaar zijn.


## v1.0.7
- Added one-click `/exports/all.zip` audit export.
- ZIP contains summary, trades, elite, usable, by_ticker and by_setup CSV files.
- Keeps stable server.py runtime on port 8798.
