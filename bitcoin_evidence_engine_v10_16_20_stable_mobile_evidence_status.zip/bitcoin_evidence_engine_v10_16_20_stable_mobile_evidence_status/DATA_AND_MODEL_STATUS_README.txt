Bitcoin Evidence Engine v10.16.20 - Data & Model Status

Belangrijkste architectuurregel:
Forecast en Time Machine moeten dezelfde state-vector gebruiken. Als een dataset in Forecast wordt gebruikt, moet die dataset ook historisch beschikbaar zijn voor Time Machine. Anders heeft historische vergelijking geen betrouwbare waarde.

Deze versie focust op stabiliteit en zichtbaarheid:
- De iPhone UI gebruikt nu een snelle status-heartbeat (/api/mobile/status-fast) zodat de app niet rood/fout blijft tijdens externe backfill of Random1000.
- De normale /api/mobile/summary is lichter gemaakt en doet geen zware dashboard-readiness calls meer.
- De Data-tab toont nu welke evidence datasets werkelijk gevuld zijn: candles, Binance futures funding/OI/long-short/taker, orderbook, Fear & Greed, Coinbase/Kraken premium en CoinMetrics/MVRV.
- Elke Time Machine export-ZIP bevat nu evidence_data_status.json/csv plus EVIDENCE_DATA_README.txt zodat audits exact zien welke data echt aanwezig was.

Statuslabels:
- active = 1000+ historische rijen beschikbaar
- partial = enkele/recente rijen beschikbaar
- missing = geen echte historische data

Let op:
Modellen mogen alleen zwaar meewegen als de bijbehorende data echt historisch gevuld is. Als een datasource partial/missing is, moet het model laag of proxy-gewicht krijgen.

Na update testen:
1. Open Home: prijs en Historical Memory moeten binnen enkele seconden zichtbaar zijn.
2. Data-tab: controleer Evidence Data en Feature Coverage.
3. Machine: Reset TM.
4. Random1000 draaien.
5. Download ZIP.
6. In de ZIP controleren: random_items.csv, time_machine_tests_batch.csv, time_machine_feature_snapshots_batch.csv, time_machine_signal_scores_all.csv, evidence_data_status.csv.
