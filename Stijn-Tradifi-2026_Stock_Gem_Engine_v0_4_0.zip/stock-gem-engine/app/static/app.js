let ITEMS=[];
async function j(url,opt){const r=await fetch(url,opt);return await r.json()}
function fmtCap(x){if(!x)return 'onbekend'; if(x>=1e12)return '$'+(x/1e12).toFixed(2)+'T'; if(x>=1e9)return '$'+(x/1e9).toFixed(2)+'B'; return '$'+(x/1e6).toFixed(1)+'M'}
function bar(name,val,type=''){val=Number(val||0);return `<div class="bar ${type}"><label><span>${name}</span><b>${val.toFixed?val.toFixed(1):val}</b></label><div class="track"><div class="fill" style="width:${Math.max(0,Math.min(100,val))}%"></div></div></div>`}
function cls(v){v=v||''; if(v.includes('avoid')||v.includes('hot'))return 'bad'; if(v.includes('Watch'))return 'watch'; if(v.includes('Strong'))return 'strong'; return ''}
function brokerBlock(b){b=b||{};const br=b.brokers||{};const row=(name)=>{const x=br[name]||{status:'NOT_VERIFIED',label:'Niet exact geverifieerd',route:''};const ok=x.status==='VERIFIED';return `<div class="broker-row ${ok?'verified':'notverified'}"><b>${name}</b><span>${ok?'✅ ':''}${x.label||'Niet exact geverifieerd'}${x.route?`<em>${x.route}</em>`:''}</span></div>`};return `<div class="broker"><div class="broker-title">Exacte brokerroute Nederland</div>${row('Interactive Brokers')}${row('Saxo')}${row('DEGIRO')}${row('Trading 212')}<small>${b.note||'Alleen VERIFIED is exact. Niet-geverifieerd wordt niet als koopplek geteld.'}<br>${b.coverage_note||''}</small></div>`}
function card(x){let source=(x.market_cap_source||'unknown').replaceAll('_',' ');let conf=x.market_cap_confidence||'';return `<article class="card"><div class="top"><div><div class="ticker">${x.symbol}</div><div class="name">${x.name}</div><div class="meta">${x.market} · ${x.exchange||''}</div></div><div class="score">${x.gem_score}</div></div><div class="sector">${x.sector}</div><div class="mcap"><b>${x.mcap_label||fmtCap(x.market_cap)}</b><span>${source}${conf?' · '+conf:''}</span></div><span class="verdict ${cls(x.verdict)}">${x.verdict}</span><div class="bars">${bar('Early Signal',x.early_signal,'early')}${bar('Hype Risk',x.hype_risk,'hype')}${bar('Risk Score',x.risk_score,'risk')}</div><p class="explain">${x.explanation}</p>${brokerBlock(x.broker_info)}<div class="news"><b>Nieuws</b><br>${(x.news||[]).slice(0,3).map(n=>'• '+(n.title||'')).join('<br>')||'Nog geen nieuws gevonden via gratis bron.'}</div></article>`}
function render(){const query=(q.value||'').toLowerCase();const vf=verdictFilter.value;let arr=ITEMS.filter(x=>!query||[x.symbol,x.name,x.sector,x.market,x.exchange].join(' ').toLowerCase().includes(query)); if(vf){arr=arr.filter(x=>(x.verdict||'').includes(vf));} cards.innerHTML=arr.map(card).join('')||'<div class="loading">Geen resultaten. Draai een scan.</div>'}
async function load(){const s=await j('/api/status');version.textContent=s.version.replace('0.4.0-','0.4.0 ').replace('0.3.1-','0.3.1 ').replace('0.3.0-','0.3.0 ');topic.textContent='ntfy: '+s.ntfy_topic;daemon.textContent=(s.auto_scan_enabled?'elk '+s.scan_interval_minutes+' min':'uit');const ls=s.last_scan||{};scaninfo.textContent=`Laatste scan: ${ls.last_finished||'nog geen'} · running: ${ls.running?'ja':'nee'} · alerts: ${ls.last_new_alerts||0} · live mcap: ${ls.live_mcap_count||0} · estimate mcap: ${ls.fallback_mcap_count||0}`;const g=await j('/api/gems');ITEMS=g.items||[];count.textContent=ITEMS.length;render()}
async function scan(){
  loading.classList.remove('hidden');
  loading.textContent='Scan draait... bestaande lijst blijft zichtbaar, resultaten worden direct ververst zodra klaar.';
  const r=await j('/api/scan',{method:'POST'});
  loading.classList.add('hidden');
  if(r.running){alert('Er draait al een scan. De bestaande lijst blijft zichtbaar.'); return;}
  if(r.items){ITEMS=r.items; count.textContent=ITEMS.length; render();}
  await load();
}
async function testNtfy(){await j('/api/test-ntfy',{method:'POST'});alert('Testmelding verzonden naar ntfy.')}
load();setInterval(load,30000);
