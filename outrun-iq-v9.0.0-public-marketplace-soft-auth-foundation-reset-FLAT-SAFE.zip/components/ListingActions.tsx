"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { eur } from "@/lib/types";

export function ListingActions({ id, status, price, newPrice }:{
  id: string; status: string; price: number; newPrice: number;
}) {
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);
  const [p, setP] = useState(String(price));
  const [confirmDel, setConfirmDel] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();

  async function call(method: "PATCH" | "DELETE", body?: object) {
    setBusy(true); setErr("");
    const r = await fetch(`/api/partner/listings/${id}`, {
      method, headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setEditing(false); setConfirmDel(false); router.refresh(); }
    else setErr(j.error || "Actie mislukt");
  }

  const btn: React.CSSProperties = {
    fontFamily: "var(--mono)", fontSize: 9.5, fontWeight: 600, letterSpacing: .8,
    background: "none", border: "1px solid #2A3540", borderRadius: 9, padding: "7px 11px",
    color: "#8B96A0", cursor: "pointer",
  };

  return (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", margin: "8px 16px 14px", maxWidth: 760 }}>
      {!editing ? (
        <>
          {status !== "sold" && (
            <button style={btn} disabled={busy} onClick={() => call("PATCH", { action: (status === "published" || status === "active") ? "pause" : "activate" })}>
              {(status === "published" || status === "active") ? "ARCHIVEER" : "PUBLICEER"}
            </button>
          )}
          <button style={btn} disabled={busy} onClick={() => { setEditing(true); setP(String(price)); }}>PRIJS {eur(price)}</button>
          {!confirmDel
            ? <button style={btn} disabled={busy} onClick={() => setConfirmDel(true)}>VERWIJDER</button>
            : <button style={{ ...btn, color: "var(--amber)", borderColor: "var(--amber-deep)" }} disabled={busy} onClick={() => call("DELETE")}>ZEKER? TIK NOGMAALS</button>}
        </>
      ) : (
        <>
          <input
            type="number" min={1} max={newPrice - 1} value={p} onChange={e => setP(e.target.value)}
            style={{ ...btn, width: 96, color: "#fff", cursor: "text" }} autoFocus
          />
          <button style={{ ...btn, color: "#4CBE8B", borderColor: "#2E9E6B" }} disabled={busy || !(Number(p) > 0)} onClick={() => call("PATCH", { action: "price", price: Number(p) })}>OPSLAAN</button>
          <button style={btn} onClick={() => setEditing(false)}>ANNULEER</button>
        </>
      )}
      {err && <span style={{ fontSize: 10.5, color: "var(--amber)" }}>{err}</span>}
    </div>
  );
}
