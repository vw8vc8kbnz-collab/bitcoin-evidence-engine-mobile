"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { eur } from "@/lib/types";
import type { PriceAdvice } from "@/lib/ai";

type Cat = "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
type PhotoRole = { index: number; role: string; buyerFacing: boolean; reason?: string };
type VisionDetails = { conditionReason?: string; defects?: string[]; accessories?: string[]; energyLabel?: string; sellingPoints?: string[]; photosAnalyzed?: number; source?: string; model?: string; seriesCandidates?: string[]; modelCandidates?: string[]; articleNumber?: string; serialMasked?: string; ocrText?: string; confidence?: number; uncertainty?: boolean; needsExtraPhotos?: string[]; photoRoles?: PhotoRole[]; };
type IdentityChoice = { label: string; brand?: string; model?: string; kind: "ai" | "candidate" | "manual" | "unknown" };
type ListingCopy = { title: string; shortDescription: string; description: string; longDescription: string; seoTitle: string; metaDescription: string; searchKeywords: string[]; altTexts: string[]; bullets: string[]; sourceMode: string; confidence: number; warnings?: string[] };
const CATS: { v: Cat; label: string }[] = [
  { v: "witgoed", label: "Witgoed" }, { v: "meubels", label: "Meubels" },
  { v: "keukens", label: "Keukens" }, { v: "tuin", label: "Tuin" }, { v: "overig", label: "Overig" },
];

const inputStyle: React.CSSProperties = {
  border: 0, background: "none", font: "inherit", width: "100%", outline: "none", color: "#fff",
};

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="dli" style={{ cursor: "default" }}>
      <b style={{ flex: "none", width: 108, fontSize: 11 }}>{label}</b>
      <span style={{ flex: 1 }}>{children}</span>
    </div>
  );
}

function basisLabel(basis?: string) {
  if (basis === "live_market") return "live marktscan";
  if (basis === "market_anchor") return "marktanker";
  if (basis === "new_price") return "prijsanker";
  return "voorzichtige fallback";
}
function confidenceClass(n?: number) {
  const v = Number(n || 0);
  return v >= 72 ? "done" : v >= 50 ? "warn" : "bad";
}

function stripConfirmMarkers(v: string) {
  return String(v || "")
    .replace(/\s*\((?:model\s*)?bevestigen\)\s*/gi, " ")
    .replace(/\s*\/\s*touring\s*$/i, "")
    .replace(/\s{2,}/g, " ")
    .trim();
}
function cleanListingTitle(title: string, brand?: string, model?: string) {
  const cleanTitle = stripConfirmMarkers(title);
  const cleanModel = stripConfirmMarkers(model || "");
  const cleanBrand = stripConfirmMarkers(brand || "");
  if (cleanBrand && cleanModel && !cleanModel.toLowerCase().startsWith(cleanBrand.toLowerCase())) return `${cleanBrand} ${cleanModel}`.trim();
  return (cleanTitle || [cleanBrand, cleanModel].filter(Boolean).join(" ")).trim();
}

function exactModelOptionsFor(label: string): string[] {
  const s = stripConfirmMarkers(label).toLowerCase();
  if (s.includes("samsung") && (s.includes("ecobubble") || s.includes("eco bubble"))) return [
    "Samsung EcoBubble WW90T534AAW", "Samsung EcoBubble WW80TA049AE", "Samsung EcoBubble WW90CGC04AAE", "Samsung EcoBubble WW90T554AAW", "Samsung EcoBubble WW11BB704AGB"
  ];
  if (s.includes("samsung") && s.includes("addwash")) return [
    "Samsung AddWash WW90T554AAW", "Samsung AddWash WW80T554AAW", "Samsung AddWash WW90K6400QW"
  ];
  if (s.includes("samsung") && s.includes("quickdrive")) return [
    "Samsung QuickDrive WW90T986ASH", "Samsung QuickDrive WW8800M", "Samsung QuickDrive WW10M86INOA"
  ];
  if (s.includes("bosch") && s.includes("serie 6")) return ["Bosch WGG244F9NL", "Bosch WGG244Z5NL", "Bosch WUU28T20NL", "Bosch WAU28S70NL"];
  if (s.includes("bosch") && s.includes("serie 4")) return ["Bosch WAN28275NL", "Bosch WAN28075NL", "Bosch WAN2827FNL"];
  if (s.includes("miele") && s.includes("w1")) return ["Miele WCA 030 WCS", "Miele WCD 030 WCS", "Miele WSG 363 WCS", "Miele WSI 863 WCS"];
  if (s.includes("sony") && s.includes("wh-1000x")) return ["Sony WH-1000XM5", "Sony WH-1000XM4", "Sony WH-1000XM3"];
  if (s.includes("jbl") && s.includes("live")) return ["JBL Live 770NC", "JBL Live 660NC", "JBL Live 670NC"];
  if (s.includes("jbl") && s.includes("tune")) return ["JBL Tune 770NC", "JBL Tune 760NC", "JBL Tune 720BT"];
  if (s.includes("bose") && s.includes("quietcomfort")) return ["Bose QuietComfort Ultra Headphones", "Bose QuietComfort 45", "Bose QuietComfort 35 II"];
  if (s.includes("sennheiser") && s.includes("momentum")) return ["Sennheiser Momentum 4 Wireless", "Sennheiser Momentum 3 Wireless"];
  return [];
}
function isGenericIdentity(label: string) {
  const s = stripConfirmMarkers(label).toLowerCase();
  return !s || ["koptelefoon", "wasmachine", "bank", "stoel", "product", "onbekend product"].includes(s);
}

function choiceParts(label: string, fallbackBrand?: string) {
  const clean = stripConfirmMarkers(label);
  const knownBrands = ["Sony", "Samsung", "Thrustmaster", "Harley-Davidson", "Apple", "Bosch", "Miele", "Dyson", "JBL", "Bose", "Sennheiser", "Sonos", "Jura", "Lenovo", "Tefal", "LG", "AEG", "Siemens", "Philips"];
  const brand = knownBrands.find(b => clean.toLowerCase().startsWith(b.toLowerCase() + " ")) || fallbackBrand || "";
  const model = brand && clean.toLowerCase().startsWith(brand.toLowerCase() + " ") ? clean.slice(brand.length).trim() : clean;
  return { label: clean, brand, model };
}

export function NewListingFlow() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  // stap 1
  const [photos, setPhotos] = useState<string[]>([]);
  const [vision, setVision] = useState<"idle" | "busy" | "done" | "failed">("idle");
  const [visionNote, setVisionNote] = useState("");
  const [visionDetails, setVisionDetails] = useState<VisionDetails | null>(null);
  const [identityConfirmed, setIdentityConfirmed] = useState(false);
  const [identityChoices, setIdentityChoices] = useState<IdentityChoice[]>([]);
  const [seriesStep, setSeriesStep] = useState<{ label: string; options: string[] } | null>(null);
  // stap 2
  const [f, setF] = useState({
    title: "", brand: "", partnerRef: "", category: "witgoed" as Cat, condition: "", conditionScore: 8,
    defect: "", newPrice: "", stock: "1", delivery: "Bezorging in overleg", deliveryPrice: "0",
  });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setF({ ...f, [k]: e.target.value });
  // stap 3
  const [advice, setAdvice] = useState<PriceAdvice | null>(null);
  const [copyBusy, setCopyBusy] = useState(false);
  const [listingCopy, setListingCopy] = useState<ListingCopy | null>(null);
  const [copyVariant, setCopyVariant] = useState<"short" | "normal" | "long">("normal");
  const [choice, setChoice] = useState<"fast" | "outlet" | "premium">("outlet");
  const [ownPrice, setOwnPrice] = useState("");

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true); setErr("");
    const fd = new FormData();
    Array.from(files).slice(0, Math.max(0, 5 - photos.length)).forEach(x => fd.append("photos", x));
    const r = await fetch("/api/partner/upload", { method: "POST", body: fd });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) {
      const next = [...photos, ...j.urls].slice(0, 5);
      setPhotos(next);
      if (vision === "idle" && next[0]) recognize(next);
    } else setErr(j.error || "Upload mislukt");
  }

  /** AI vult velden vooraf in — nooit over eigen invoer heen. */
  async function recognize(photoUrls: string[]) {
    const batch = photoUrls.slice(0, 5);
    if (!batch.length) return;
    setVision("busy"); setVisionNote(""); setVisionDetails(null); setIdentityConfirmed(false); setIdentityChoices([]); setSeriesStep(null);
    const r = await fetch("/api/partner/vision", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ photoUrls: batch }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { setVision("failed"); setVisionNote(j.error || "AI-herkenning mislukt — vul de velden zelf in."); return; }
    const detailDefects = Array.isArray(j.defects) ? j.defects.filter(Boolean).slice(0, 5) : [];
    const conditionParts = [j.condition, j.conditionReason].filter(Boolean).join(" · ");
    setF(prev => ({
      ...prev,
      title: prev.title || cleanListingTitle(j.title || "", j.brand || "", j.model || ""),
      brand: prev.brand || stripConfirmMarkers(j.brand || ""),
      category: (prev.title || prev.brand) ? prev.category : (j.category ?? prev.category),
      condition: prev.condition || conditionParts || "",
      conditionScore: prev.condition ? prev.conditionScore : (j.conditionScore ?? prev.conditionScore),
      defect: prev.defect || j.defect || detailDefects[0] || "",
      newPrice: prev.newPrice || (j.newPriceEstimate > 0 ? String(j.newPriceEstimate) : ""),
    }));
    const seriesCandidates = Array.isArray(j.seriesCandidates) ? j.seriesCandidates.filter(Boolean).slice(0, 6) : [];
    const modelCandidates = Array.isArray(j.modelCandidates) ? j.modelCandidates.filter(Boolean).slice(0, 8) : [];
    const confidence = Number(j.confidence) || 0;
    const uncertain = Boolean(j.uncertainty) || confidence < 90 || modelCandidates.length > 0;
    setVisionDetails({
      conditionReason: j.conditionReason,
      defects: detailDefects,
      accessories: Array.isArray(j.accessories) ? j.accessories.filter(Boolean).slice(0, 5) : [],
      energyLabel: j.energyLabel || "",
      sellingPoints: Array.isArray(j.sellingPoints) ? j.sellingPoints.filter(Boolean).slice(0, 3) : [],
      photosAnalyzed: j.photosAnalyzed,
      source: j.source,
      model: j.model || "",
      seriesCandidates,
      modelCandidates,
      articleNumber: j.articleNumber || "",
      serialMasked: j.serialMasked || "",
      ocrText: j.ocrText || "",
      confidence,
      uncertainty: uncertain,
      needsExtraPhotos: Array.isArray(j.needsExtraPhotos) ? j.needsExtraPhotos.filter(Boolean).slice(0, 4) : [],
      photoRoles: Array.isArray(j.photoRoles) ? j.photoRoles.slice(0, 5) : [],
    });
    const baseLabel = cleanListingTitle(j.title || "", j.brand || "", j.model || "") || (j.brand ? `${j.brand} product` : "Onbekend product");
    const choices: IdentityChoice[] = [];
    if (baseLabel && !isGenericIdentity(baseLabel)) { const p = choiceParts(baseLabel, j.brand || ""); choices.push({ label: p.label, brand: p.brand, model: p.model, kind: "ai" }); }
    seriesCandidates.forEach((m: string) => {
      const p = choiceParts(String(m).trim(), j.brand || "");
      const label = p.label;
      if (label && !choices.some(c => c.label.toLowerCase() === label.toLowerCase())) {
        choices.push({ label, brand: p.brand, model: p.model, kind: "candidate" });
      }
    });
    modelCandidates.forEach((m: string) => {
      const p = choiceParts(String(m).trim(), j.brand || "");
      const label = p.label;
      if (label && !choices.some(c => c.label.toLowerCase() === label.toLowerCase())) {
        choices.push({ label, brand: p.brand, model: p.model, kind: "candidate" });
      }
    });
    choices.push({ label: "Merk/model onzeker — ik vul het zelf in", kind: "manual" });
    setIdentityChoices(choices.slice(0, 9));
    setIdentityConfirmed(!uncertain);
    setVision("done");
    setVisionNote(`AI heeft ${j.photosAnalyzed || batch.length} foto${(j.photosAnalyzed || batch.length) === 1 ? "" : "'s"} beoordeeld en stap 2 ingevuld${j.newPriceEstimate > 0 ? " (nieuwprijs is een schatting)" : ""}. Controleer alles.`);
  }

  function confirmIdentity(choice: IdentityChoice) {
    const exactOptions = exactModelOptionsFor(choice.label);
    if (choice.kind !== "manual" && exactOptions.length && !exactOptions.some(x => x.toLowerCase() === choice.label.toLowerCase())) {
      const brand = stripConfirmMarkers(choice.brand || f.brand);
      const title = cleanListingTitle(choice.label, brand, choice.model || choice.label);
      setF(prev => ({ ...prev, brand: brand || prev.brand, title: title || prev.title }));
      setSeriesStep({ label: choice.label, options: exactOptions });
      setIdentityConfirmed(false);
      setVisionDetails(prev => prev ? { ...prev, model: stripConfirmMarkers(choice.model || choice.label), uncertainty: true, modelCandidates: exactOptions } : prev);
      return;
    }
    if (choice.kind === "manual") {
      setF(prev => ({ ...prev, title: stripConfirmMarkers(prev.title), brand: stripConfirmMarkers(prev.brand) }));
      setSeriesStep(null);
      setIdentityConfirmed(true);
      return;
    }
    const brand = stripConfirmMarkers(choice.brand || f.brand);
    const model = stripConfirmMarkers(choice.model || choice.label || "");
    const title = cleanListingTitle(choice.label, brand, model);
    setF(prev => ({ ...prev, brand: brand || prev.brand, title: title || stripConfirmMarkers(prev.title) }));
    setSeriesStep(null);
    setIdentityConfirmed(true);
    setVisionDetails(prev => prev ? { ...prev, model: model || stripConfirmMarkers(prev.model || ""), uncertainty: false } : prev);
  }

  const step2ok = Boolean(f.title);

  async function runAi() {
    setBusy(true); setErr(""); setAdvice(null); setStep(3);
    const r = await fetch("/api/partner/pricing", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: f.title, brand: f.brand, category: f.category, condition: f.condition,
        conditionScore: Number(f.conditionScore), newPrice: Number(f.newPrice),
        stock: Number(f.stock), photosCount: photos.length, defect: f.defect || undefined,
        visionSummary: visionDetails ? [visionDetails.conditionReason, ...(visionDetails.defects || []), ...(visionDetails.sellingPoints || [])].filter(Boolean).join(" · ") : undefined,
        conditionReason: visionDetails?.conditionReason,
        defects: visionDetails?.defects, accessories: visionDetails?.accessories, energyLabel: visionDetails?.energyLabel,
        model: visionDetails?.model, articleNumber: visionDetails?.articleNumber, identityConfirmed,
        marketScanRequested: !f.newPrice || Number(f.newPrice) < 1 || (f.brand.toLowerCase().includes("harley") || f.title.toLowerCase().includes("motor")),
      }),
    });
    const j = await r.json().catch(() => null);
    setBusy(false);
    if (r.ok && j?.outlet) {
      if ((!f.newPrice || Number(f.newPrice) <= Number(j.outlet))) {
        const ref = Number(j.referenceNewPrice || 0) > Number(j.outlet) ? Number(j.referenceNewPrice) : Math.round(Number(j.premium || j.outlet) * 1.35);
        if (ref > Number(j.outlet)) setF(prev => ({ ...prev, newPrice: String(Math.round(ref)) }));
      }
      setAdvice(j);
      runListingWriter(j);
    }
    else { setErr(j?.error || "Prijsadvies mislukt"); setStep(2); }
  }

  async function runListingWriter(nextAdvice: PriceAdvice) {
    setCopyBusy(true); setListingCopy(null);
    const pickedPrice = nextAdvice.outlet;
    const r = await fetch("/api/partner/listing-writer", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: f.title, brand: f.brand, category: f.category, condition: f.condition,
        conditionScore: Number(f.conditionScore), newPrice: Number(f.newPrice), price: pickedPrice,
        stock: Number(f.stock), photosCount: photos.length, defect: f.defect || undefined,
        model: visionDetails?.model, articleNumber: visionDetails?.articleNumber, identityConfirmed,
        conditionReason: visionDetails?.conditionReason, defects: visionDetails?.defects,
        accessories: visionDetails?.accessories, energyLabel: visionDetails?.energyLabel,
        visionSummary: visionDetails ? [visionDetails.conditionReason, ...(visionDetails.defects || []), ...(visionDetails.sellingPoints || [])].filter(Boolean).join(" · ") : undefined,
        market: { marketLow: nextAdvice.marketLow, marketHigh: nextAdvice.marketHigh, marketAverage: nextAdvice.marketAverage, confidence: nextAdvice.marketConfidence || nextAdvice.confidence, pricingBasis: nextAdvice.pricingBasis, reasoning: nextAdvice.reasoning },
      }),
    });
    const j = await r.json().catch(() => null);
    setCopyBusy(false);
    if (r.ok && j?.description) {
      setListingCopy(j);
      setF(prev => ({ ...prev, title: prev.title || j.title || prev.title }));
    }
  }

  async function publish() {
    if (!advice) return;
    const price = ownPrice ? Math.round(Number(ownPrice)) : advice[choice];
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/listings", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...f, title: cleanListingTitle(f.title, f.brand, visionDetails?.model), brand: stripConfirmMarkers(f.brand), conditionScore: Number(f.conditionScore), newPrice: Number(f.newPrice),
        stock: Number(f.stock), deliveryPrice: Number(f.deliveryPrice),
        perUnit: Number(f.stock) > 1, photos: safePublicPhotos, internalPhotos,
        visionMetadata: visionDetails ? {
          model: visionDetails.model,
          seriesCandidates: visionDetails.seriesCandidates,
          modelCandidates: visionDetails.modelCandidates,
          articleNumber: visionDetails.articleNumber,
          serialMasked: visionDetails.serialMasked,
          ocrText: visionDetails.ocrText,
          confidence: visionDetails.confidence,
          uncertainty: visionDetails.uncertainty,
          needsExtraPhotos: visionDetails.needsExtraPhotos,
          photoRoles: visionDetails.photoRoles,
          identityConfirmed,
        } : undefined,
        listingCopy: listingCopy ? {
          title: listingCopy.title,
          shortDescription: listingCopy.shortDescription,
          description: copyVariant === "short" ? listingCopy.shortDescription : copyVariant === "long" ? listingCopy.longDescription : listingCopy.description,
          longDescription: listingCopy.longDescription,
          bullets: listingCopy.bullets,
          sourceMode: listingCopy.sourceMode,
          confidence: listingCopy.confidence,
          warnings: listingCopy.warnings,
        } : undefined,
        seo: listingCopy ? { title: listingCopy.seoTitle, metaDescription: listingCopy.metaDescription, keywords: listingCopy.searchKeywords, altTexts: listingCopy.altTexts } : undefined,
        price, fast: advice.fast, premium: advice.premium,
        expectedDays: choice === "fast" ? advice.expectedDaysFast : choice === "premium" ? advice.expectedDaysPremium : advice.expectedDaysOutlet,
        confidence: advice.confidence, comps: advice.comps, aiSource: advice.source,
      }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.id) { router.push("/partner/voorraad"); router.refresh(); }
    else setErr(j.error || "Publiceren mislukt");
  }

  const chosen = advice ? (ownPrice ? Math.round(Number(ownPrice)) : advice[choice]) : 0;
  const buyerPhotoIndexes = new Set((visionDetails?.photoRoles || []).filter(r => r.buyerFacing !== false).map(r => r.index - 1));
  const hasRoleAdvice = (visionDetails?.photoRoles || []).length > 0;
  const publicPhotos = hasRoleAdvice ? photos.filter((_, i) => buyerPhotoIndexes.has(i)).slice(0, 5) : photos.slice(0, 5);
  const safePublicPhotos = publicPhotos.length ? publicPhotos : photos.slice(0, Math.min(1, photos.length));
  const internalPhotos = photos.filter(u => !safePublicPhotos.includes(u));

  return (
    <>
      <div className="dots">{[1, 2, 3, 4].map(i => <i key={i} className={step >= i ? "on" : ""} />)}</div>

      {step === 1 && (
        <>
          <div className="upl">
            <div className="thumbs">
              {photos.map(u => (
                <span key={u} className="imw dk">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={u} alt="" />
                </span>
              ))}
              {photos.length < 5 && (
                <label className="add" style={{ cursor: "pointer" }}>+
                  <input type="file" accept="image/*" multiple hidden onChange={e => upload(e.target.files)} />
                </label>
              )}
            </div>
            <p>{photos.length === 0 ? "Max 5 foto's: voorkant · zijkant · detail/schade · accessoires · label/artikelnummer" : `${photos.length}/5 foto's — AI kiest zelf wat openbaar wordt en wat intern blijft`}</p>
          </div>
          {vision === "busy" && (
            <div className="scan"><div className="r">AI herkent je product <span>analyseren…</span></div></div>
          )}
          {vision === "done" && (
            <div className="scan"><div className="r">AI-herkenning <span className="done">{visionDetails?.photosAnalyzed || photos.length} foto's geanalyseerd</span></div></div>
          )}
          {vision === "failed" && visionNote && (
            <p className="note" style={{ color: "var(--amber)" }}>{visionNote}{" "}
              {photos[0] && <button className="alink" style={{ color: "var(--petrol-glow)" }} onClick={() => recognize(photos)}>Herken opnieuw →</button>}
            </p>
          )}
          <p className="note">Foto's mogen ook later; zonder foto toont de app een nette illustratie.</p>
          <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={() => setStep(2)} disabled={busy}>
            {busy ? "Uploaden…" : vision === "busy" ? "AI herkent je product…" : "Verder — productgegevens"}</button></div>
        </>
      )}

      {step === 2 && (
        <>
          {vision === "done" && visionNote && (
            <p className="note" style={{ margin: "0 4px 10px", color: "var(--petrol-glow)" }}>✦ {visionNote}</p>
          )}
          {visionDetails && (
            <div className="aiIdentityCard">
              <div className="aiIdTop">
                <span>AI-herkenning</span>
                <b className={identityConfirmed ? "ok" : "warn"}>{identityConfirmed ? "bevestigd" : `${visionDetails.confidence || 0}/100`}</b>
              </div>
              <h3>{f.title || "Product herkend"}</h3>
              <p>{identityConfirmed ? "Merk/model staan klaar. Controleer alleen nog prijs, staat en levering." : "Meerdere modellen lijken op elkaar. Kies de juiste optie — één tik is genoeg."}</p>
              {!identityConfirmed && seriesStep ? (
                <div className="resolverStep">
                  <b>Serie gekozen: {seriesStep.label}</b>
                  <p>Kies nu het exacte modelnummer. Staat het er niet tussen? Gebruik “exact model onbekend” en voeg later een typeplaatje toe.</p>
                  <div className="aiChoiceGrid">
                    {seriesStep.options.map((m, i) => <button key={`${m}-${i}`} type="button" onClick={() => confirmIdentity({ label: m, kind: "candidate" })}><span>Modelnummer optie</span>{m}</button>)}
                    <button type="button" onClick={() => { setSeriesStep(null); setIdentityConfirmed(true); setVisionDetails(prev => prev ? { ...prev, uncertainty: true, needsExtraPhotos: Array.from(new Set([...(prev.needsExtraPhotos || []), "foto van typeplaatje/modelsticker"])).slice(0,4) } : prev); }}><span>Veilig</span>Exact model onbekend</button>
                  </div>
                </div>
              ) : !identityConfirmed && identityChoices.length > 0 ? (
                <div className="aiChoiceGrid">
                  {identityChoices.map((c, i) => <button key={`${c.label}-${i}`} type="button" onClick={() => confirmIdentity(c)}><span>{i === 0 ? "Meest waarschijnlijk" : c.kind === "manual" ? "Anders" : exactModelOptionsFor(c.label).length ? "Serie/familie" : "Ook mogelijk"}</span>{c.label}</button>)}
                </div>
              ) : null}
              <div className="aiMiniFacts">
                {visionDetails.conditionReason && <span><b>Staat</b>{visionDetails.conditionReason}</span>}
                {visionDetails.articleNumber && <span><b>Intern</b>{visionDetails.articleNumber}</span>}
                {visionDetails.needsExtraPhotos?.length && !identityConfirmed ? <span><b>Zekerder met</b>{visionDetails.needsExtraPhotos.slice(0, 2).join(" · ")}</span> : null}
              </div>
            </div>
          )}
          <div className="dgroup">
            <Field label="Titel"><input style={inputStyle} value={f.title} onChange={set("title")} placeholder="Bosch Serie 6 wasmachine 9kg" /></Field>
            <Field label="Merk"><input style={inputStyle} value={f.brand} onChange={set("brand")} placeholder="Bosch" /></Field>
            <Field label="Ref / SKU"><input style={inputStyle} value={f.partnerRef} onChange={set("partnerRef")} placeholder="optioneel — bv. MAG-A12-0433" /></Field>
            <Field label="Categorie">
              <select style={{ ...inputStyle, appearance: "none" }} value={f.category} onChange={set("category")}>
                {CATS.map(c => <option key={c.v} value={c.v} style={{ color: "#000" }}>{c.label}</option>)}
              </select>
            </Field>
            <Field label="Conditie"><input style={inputStyle} value={f.condition} onChange={set("condition")} placeholder="Retour, ongebruikt · doos beschadigd" /></Field>
            <Field label="Score /10"><input style={inputStyle} type="number" min={1} max={10} value={f.conditionScore} onChange={set("conditionScore")} /></Field>
            <Field label="Gebrek"><input style={inputStyle} value={f.defect} onChange={set("defect")} placeholder="optioneel — bv. kras zijkant, foto 3" /></Field>
            <Field label="Prijsanker €"><input style={inputStyle} type="number" min={0} value={f.newPrice} onChange={set("newPrice")} placeholder="optioneel — AI zoekt marktprijs" /></Field>
            <Field label="Voorraad"><input style={inputStyle} type="number" min={1} value={f.stock} onChange={set("stock")} /></Field>
            <Field label="Levering"><input style={inputStyle} value={f.delivery} onChange={set("delivery")} /></Field>
            <Field label="Bezorgkosten €"><input style={inputStyle} type="number" min={0} value={f.deliveryPrice} onChange={set("deliveryPrice")} /></Field>
          </div>
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
          <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={runAi} disabled={!step2ok || busy}>
            {!identityConfirmed && visionDetails?.uncertainty ? "Prijsanalyse starten" : "Start AI-prijsanalyse"}</button></div>
        </>
      )}

      {step === 3 && (
        <>
          <div className="scan">
            <div className="r">Productherkenning <span className={advice ? "done" : ""}>{advice ? (f.brand || f.title.split(" ")[0]) : "analyseren…"}</span></div>
            <div className="r">Conditieweging <span className={advice ? "done" : ""}>{advice ? `${f.conditionScore}/10` : "…"}</span></div>
            <div className="r">Marktprijs <span className={advice ? "done" : ""}>{advice ? (advice.marketAverage ? `± ${eur(advice.marketAverage)}` : (advice.comps > 0 ? `${advice.comps} signalen` : "modelkennis")) : "…"}</span></div>
            <div className="r">Confidence <span className={advice ? "done" : ""}>{advice ? `${advice.confidence}/100` : "…"}</span></div>
          </div>
          {advice && (
            <>
              {advice.priceWarning ? <p className="note" style={{ color: "var(--amber)" }}>⚠ {advice.priceWarning}</p> : null}
              <div className="marketCard">
                <div className="marketHead">
                  <span>AI prijsbewijs</span>
                  <b className={confidenceClass(advice.marketConfidence || advice.confidence)}>{basisLabel(advice.pricingBasis)} · {advice.marketConfidence || advice.confidence}/100</b>
                </div>
                <div className="marketNumbers">
                  <span><small>2e hands markt</small><b>{advice.marketLow && advice.marketHigh ? `${eur(advice.marketLow)}–${eur(advice.marketHigh)}` : (advice.marketAverage ? `± ${eur(advice.marketAverage)}` : "onbekend")}</b></span>
                  <span><small>Advies</small><b>{eur(advice.outlet)}</b></span>
                </div>
                <p>{advice.reasoning} <em>{advice.source === "deepseek" ? "AI pricing" : "veilig model"}</em></p>
                {advice.marketSignals?.length ? (
                  <div className="marketSignals">
                    {advice.marketSignals.slice(0, 3).map((m, i) => (
                      <span key={`${m.label}-${i}`}>
                        <b>{m.label}</b>
                        <small>{eur(m.low)}–{eur(m.high)} · {m.confidence}/100</small>
                      </span>
                    ))}
                  </div>
                ) : null}
              </div>
              <div className="copyCard">
                <div className="copyHead"><span>AI beschrijving & Google-tekst</span><b className={listingCopy ? "done" : copyBusy ? "warn" : "bad"}>{listingCopy ? `${listingCopy.confidence}/100` : copyBusy ? "schrijven…" : "fallback"}</b></div>
                {copyBusy && <p>AI schrijft nu een originele productbeschrijving met natuurlijke zoekwoorden. Fabrikantsteksten worden niet letterlijk gekopieerd.</p>}
                {listingCopy && <>
                  <h3>{listingCopy.title}</h3>
                  <div className="copyTabs">
                    <button type="button" className={copyVariant === "short" ? "on" : ""} onClick={() => setCopyVariant("short")}>Kort</button>
                    <button type="button" className={copyVariant === "normal" ? "on" : ""} onClick={() => setCopyVariant("normal")}>Normaal</button>
                    <button type="button" className={copyVariant === "long" ? "on" : ""} onClick={() => setCopyVariant("long")}>Uitgebreid</button>
                  </div>
                  <p>{copyVariant === "short" ? listingCopy.shortDescription : copyVariant === "long" ? listingCopy.longDescription : listingCopy.description}</p>
                  <div className="copyBullets">{listingCopy.bullets.slice(0,4).map((b,i)=><span key={`${b}-${i}`}>{b}</span>)}</div>
                  <small>SEO: {listingCopy.searchKeywords.slice(0,6).join(" · ")}</small>
                  {listingCopy.warnings?.length ? <em>{listingCopy.warnings[0]}</em> : null}
                </>}
              </div>
              <div className="dsec"><h2>Kies je strategie</h2></div>
              <div className="pk3">
                {(["fast", "outlet", "premium"] as const).map(k => (
                  <button key={k} className={`pk${choice === k && !ownPrice ? " on" : ""}`} onClick={() => { setChoice(k); setOwnPrice(""); }}>
                    <label>{k.toUpperCase()}</label><b>{eur(advice[k])}</b>
                    <span>± {k === "fast" ? advice.expectedDaysFast : k === "premium" ? advice.expectedDaysPremium : advice.expectedDaysOutlet} dagen</span>
                  </button>
                ))}
              </div>
              <div className="slabel" style={{ color: "#5F6873" }}>OF ZELF</div>
              <div className="dgroup"><Field label="Eigen prijs €"><input style={inputStyle} type="number" min={1} value={ownPrice} onChange={e => setOwnPrice(e.target.value)} placeholder={String(advice.outlet)} /></Field></div>
              <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={() => setStep(4)} disabled={!chosen || chosen <= 0 || (Number(f.newPrice) > 0 && chosen >= Number(f.newPrice))}>
                Verder — controleren</button></div>
            </>
          )}
          {!advice && !err && <p className="note">De AI analyseert je product…</p>}
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
        </>
      )}

      {step === 4 && advice && (
        <>
          <div className="scan">
            <div className="r">{f.title} <span className="done">{eur(chosen)}{Number(f.stock) > 1 ? "/st" : ""}</span></div>
            <div className="r">Nieuwprijs <span className="done">{eur(Number(f.newPrice))}</span></div>
            <div className="r">Voorraad <span className="done">{f.stock} stuks</span></div>
            <div className="r">Levering <span className="done">{f.delivery} · {eur(Number(f.deliveryPrice))}</span></div>
            <div className="r">Openbare foto's <span className="done">{safePublicPhotos.length}/5</span></div>
            {internalPhotos.length ? <div className="r">Interne AI/OCR-foto's <span className="done">{internalPhotos.length} niet in galerij</span></div> : null}
          </div>
          <p className="note">Kopers zien het prijsbewijs (fast → outlet → nieuwprijs) bij je listing. Eerlijkheid verkoopt.</p>
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
          <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={publish} disabled={busy}>
            {busy ? "Publiceren…" : `Publiceer listing — ${eur(chosen)}`}</button></div>
        </>
      )}
    </>
  );
}
