import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/beheer", "/admin", "/partner"] }],
    sitemap: "https://outruniq.nl/sitemap.xml",
  };
}
