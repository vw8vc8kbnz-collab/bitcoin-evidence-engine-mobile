import Link from "next/link";
import { notFound } from "next/navigation";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { eur } from "@/lib/types";

export const dynamic = "force-dynamic";

const fmt = (iso?: string) => iso ? new Date(iso).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "—";

export default async function PartnerInzage({ params, searchParams }:{
  params: Promise<{ slug: string }>; searchParams: Promise<{ pin?: string }>;
}) {
  const { slug } = await params;
  const { pin } = await searchParams;
  const me = await getUser();
  const viaPin = !!process.env.ADMIN_PIN && pin === process.env.ADMIN_PIN;
  if (me?.role !== "admin" && !viaPin) notFound();
  const db = await read();
  const s = db.sellers.find(x => x.slug === slug);
  const owner = db.users.find(u => u.partnerSlug === slug);
  if (!s || !owner) notFound();
  const listings = db.listings.filter(l => l.sellerSlug === slug);
  const orders = db.orders.filter(o => o.sellerSlug === slug).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const bids = db.bids.filter(b => b.sellerSlug === slug).sort((a, b) => b.at.localeCompare(a.at));
  const reviews = db.reviews.filter(r => r.sellerSlug === slug);
  const netto = orders.filter(o => o.status === "paid_out").reduce((x, o) => x + o.sellerNet, 0);

  return (
    <div className="app dark">
      <main className="page adm">
        <div className="hd" style={{ display: "flex" }}>
          <Link href="/beheer" className="back" style={{ color: "#8B96A0" }}>
            <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Beheer
          </Link>
          <span className="sp" /><span className="mini" style={{ color: "#5F6873" }}>INZAGE · {slug.toUpperCase()}</span>
        </div>
        <h1 className="h1big">{s.name}</h1>
        <p className="note" style={{ color: "#8B96A0" }}>
          {owner.partnerProfile?.companyName} · KvK {owner.partnerProfile?.kvk} · {s.city} · {owner.email}
          {" · "}voorwaarden akkoord: {fmt(owner.partnerProfile?.termsAcceptedAt)} · escrow {s.trusted ? "7" : "14"} dgn
          {" · "}service: {s.support?.email ?? "⚠ ONTBREEKT"}{s.support?.phone ? ` / ${s.support.phone}` : ""}
          {s.address ? ` · afhaal: ${s.address.street}, ${s.address.postcode} ${s.address.city}` : " · ⚠ geen afhaaladres"}
        </p>
        <div className="admgrid" style={{ marginTop: 14 }}>
          <div className="admstat"><span className="k">LIVE</span><b>{listings.filter(l => l.status === "published" || l.status === "active").length}</b><span className="sub">{listings.length} totaal</span></div>
          <div className="admstat"><span className="k">ORDERS</span><b>{orders.length}</b></div>
          <div className="admstat"><span className="k">NETTO UITBETAALD</span><b>{eur(netto)}</b><span className="sub">test</span></div>
          <div className="admstat"><span className="k">BIEDINGEN</span><b>{bids.length}</b></div>
        </div>

        <div className="dsec" style={{ marginTop: 24 }}><h2>Listings</h2><span>{listings.length}</span></div>
        {listings.map(l => (
          <div key={l.id} className="orow">
            <span><b>{l.title}{l.partnerRef ? ` · ${l.partnerRef}` : ""}</b>
              <span>{l.status.toUpperCase()} · {eur(l.price)} (nieuw {eur(l.newPrice)}) · voorraad {l.stock} · {l.views} views{l.priceLog?.length ? ` · ${l.priceLog.length}× geherprijsd` : ""}</span></span>
            <Link href={`/listing/${l.id}`} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>BEKIJK →</Link>
          </div>
        ))}

        <div className="dsec" style={{ marginTop: 24 }}><h2>Orders — meekijken</h2><span>{orders.length}</span></div>
        {orders.map(o => {
          const buyer = db.users.find(u => u.id === o.buyerId);
          const lastMsg = o.messages?.[o.messages.length - 1];
          return (
            <div key={o.id} className="orow" style={{ alignItems: "flex-start" }}>
              <span style={{ flex: 1 }}>
                <b>{o.itemTitle} · {eur(o.totalPaid)} · {o.status.replaceAll("_", " ").toUpperCase()}</b>
                <span>{o.id} · koper: {buyer?.name ?? "?"} ({buyer?.email ?? "?"}) · {o.deliveryChoice}{o.deliveryAddress ? ` → ${o.deliveryAddress.postcode} ${o.deliveryAddress.city}` : ""}{o.pickupCode ? ` · code ${o.pickupCode}` : ""}</span>
                <span style={{ display: "block", marginTop: 4, fontSize: 10.5, color: "#5F6873", fontFamily: "var(--mono)" }}>
                  {o.events.slice(-3).map(e => `${fmt(e.at)} ${e.status}${e.note ? ` (${e.note.slice(0, 40)})` : ""}`).join("  →  ")}
                </span>
                {o.dispute && <span style={{ display: "block", marginTop: 3, fontSize: 11, color: "var(--amber)" }}>⚠ Dispute: {o.dispute.category} — "{o.dispute.text.slice(0, 80)}"</span>}
                {o.returnRequest && <span style={{ display: "block", marginTop: 3, fontSize: 11, color: "var(--amber)" }}>↩ Retour {o.returnRequest.status}: "{o.returnRequest.reason.slice(0, 80)}"</span>}
                {lastMsg && <span style={{ display: "block", marginTop: 3, fontSize: 11, color: "#8B96A0" }}>💬 laatste ({lastMsg.from}): "{lastMsg.text.slice(0, 70)}" · {fmt(lastMsg.at)}</span>}
              </span>
            </div>
          );
        })}

        {reviews.length > 0 && (
          <>
            <div className="dsec" style={{ marginTop: 24 }}><h2>Reviews</h2><span>{reviews.length}</span></div>
            {reviews.map(r => (
              <div key={r.id} className="orow">
                <span><b>{"★".repeat(r.rating)} · {r.buyerName}{r.text ? ` — "${r.text.slice(0, 80)}"` : ""}</b>
                  <span>{fmt(r.at)} · {r.orderId}{r.reply ? ` · reactie: "${r.reply.text.slice(0, 50)}"` : ""}</span></span>
              </div>
            ))}
          </>
        )}
        {bids.length > 0 && (
          <>
            <div className="dsec" style={{ marginTop: 24 }}><h2>Biedingen</h2><span>{bids.length}</span></div>
            {bids.slice(0, 12).map(b => {
              const l = db.listings.find(x => x.id === b.listingId);
              return (
                <div key={b.id} className="orow">
                  <span><b>€{b.amount} op {l?.title ?? b.listingId} · {b.status.toUpperCase()}</b>
                    <span>{fmt(b.at)}{b.counterAmount ? ` · tegenbod €${b.counterAmount}` : ""}{b.message ? ` · "${b.message.slice(0, 50)}"` : ""}</span></span>
                </div>
              );
            })}
          </>
        )}
      </main>
    </div>
  );
}
