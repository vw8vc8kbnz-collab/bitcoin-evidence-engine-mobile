import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { AdminApprove } from "@/components/AdminApprove";
import { AdminResolve } from "@/components/AdminResolve";
import { AdminReturn } from "@/components/AdminReturn";
import { AdminTrust } from "@/components/AdminTrust";
import { AdminFlowControls } from "@/components/AdminFlowControls";
import { aiProviderMatrix } from "@/lib/ai/brain";
import { getFinanceAuditReport, sweepOrders, RELEASE_DAYS, RELEASE_DAYS_NEW, getLearningReport, getCommerceBrainReport } from "@/lib/data";
import { flushTraffic, liveNow } from "@/lib/traffic";
import { Mark } from "@/components/icons";
import { eur } from "@/lib/types";
import { financeSafetyMode, getPaymentProviderStatus } from "@/lib/payments";

export const dynamic = "force-dynamic";

const day = (offset: number) => new Date(Date.now() - offset * 864e5).toISOString().slice(0, 10);

export default async function Beheer({ searchParams }:{ searchParams: Promise<{ pin?: string }> }) {
  const { pin } = await searchParams;
  const me = await getUser();
  const viaPin = !!process.env.ADMIN_PIN && pin === process.env.ADMIN_PIN;
  if (me?.role !== "admin" && !viaPin) {
    return (
      <div className="app dark"><main className="page narrow">
        <h1 className="h1big" style={{ marginTop: 26 }}>Beheer</h1>
        <p className="note">Log in met het beheerdersaccount (ADMIN_EMAIL in .env) of open /beheer?pin=ADMIN_PIN.</p>
      </main></div>
    );
  }
  await sweepOrders();
  await flushTraffic();
  const db = await read();
  const paymentStatus = getPaymentProviderStatus();
  const financeSafety = financeSafetyMode();
  const financeAudit = await getFinanceAuditReport();
  const learning = await getLearningReport();
  const commerceBrain = await getCommerceBrainReport();

  // ---- kerncijfers ----
  const consumers = db.users.filter(u => u.role === "consument");
  const pending = db.users.filter(u => u.role === "partner" && u.partnerProfile?.status === "pending");
  const partners = db.users.filter(u => u.role === "partner" && u.partnerProfile?.status === "approved");
  const live = db.listings.filter(l => l.status === "published" || l.status === "active");
  const openStatuses = ["paid", "confirmed", "delivery_planned", "delivered"];
  const openOrders = db.orders.filter(o => openStatuses.includes(o.status));
  const escrowVast = openOrders.reduce((s, o) => s + o.totalPaid, 0);
  const paidOut = db.orders.filter(o => o.status === "paid_out");
  const gmv = db.orders.filter(o => o.status !== "cancelled").reduce((s, o) => s + o.totalPaid, 0);
  const commissie = paidOut.reduce((s, o) => s + o.commission, 0);
  const disputes = db.orders.filter(o => o.status === "disputed");
  const escReturns = db.orders.filter(o => o.returnRequest?.status === "escalated");
  const openBids = db.bids.filter(b => ["open", "countered"].includes(b.status));
  const t0 = db.traffic[day(0)] ?? { views: 0, visitors: 0 };
  const t7 = Array.from({ length: 7 }, (_, i) => db.traffic[day(i)] ?? { views: 0, visitors: 0 })
    .reduce((a, b) => ({ views: a.views + b.views, visitors: a.visitors + b.visitors }), { views: 0, visitors: 0 });

  const stats: { k: string; v: string; sub?: string; hot?: boolean }[] = [
    { k: "LIVE NU", v: String(liveNow()), sub: "bezoekers < 5 min", hot: liveNow() > 0 },
    { k: "VANDAAG", v: String(t0.visitors), sub: `${t0.views} weergaven` },
    { k: "7 DAGEN", v: String(t7.visitors), sub: `${t7.views} weergaven` },
    { k: "CONSUMENTEN", v: String(consumers.length) },
    { k: "PARTNERS", v: String(partners.length), sub: pending.length ? `+${pending.length} in aanvraag` : undefined, hot: pending.length > 0 },
    { k: "LIVE LISTINGS", v: String(live.length), sub: `${db.listings.length} totaal` },
    { k: "OPEN ORDERS", v: String(openOrders.length), sub: `${db.orders.length} totaal` },
    { k: "IN ESCROW", v: eur(escrowVast), sub: `termijn ${RELEASE_DAYS}/${RELEASE_DAYS_NEW} dgn` },
    { k: "GMV (TEST)", v: eur(gmv) },
    { k: "COMMISSIE", v: eur(commissie), sub: "gerealiseerd (test)" },
    { k: "BIEDINGEN", v: String(openBids.length), sub: "open/tegenbod" },
    { k: "ISSUES", v: String(disputes.length + escReturns.length), sub: `${disputes.length} dispute · ${escReturns.length} retour`, hot: disputes.length + escReturns.length > 0 },
  ];

  const recent = [...db.orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 8);
  const auditRecent = [...(db.auditLog ?? [])].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 10);
  const auditSuffix = viaPin && me?.role !== "admin" ? `?pin=${pin}` : "";
  const auditCsv = `/api/admin/audit/export${auditSuffix}${auditSuffix ? "&" : "?"}format=csv`;
  const auditJsonl = `/api/admin/audit/export${auditSuffix}${auditSuffix ? "&" : "?"}format=jsonl`;
  const flowJsonl = `/api/admin/flow/export${auditSuffix}${auditSuffix ? "&" : "?"}format=jsonl`;
  const flowReplay = `/api/admin/flow/export${auditSuffix}${auditSuffix ? "&" : "?"}format=html`;

  const emailCounts = db.users.reduce<Record<string, number>>((acc, u) => {
    acc[u.email] = (acc[u.email] ?? 0) + 1;
    return acc;
  }, {});
  const adminMail = (process.env.ADMIN_EMAIL ?? "").trim().toLowerCase();
  const roleIssues = db.users.flatMap(u => {
    const issues: string[] = [];
    const sellerExists = !!u.partnerSlug && db.sellers.some(s => s.slug === u.partnerSlug);
    if (adminMail && u.email === adminMail && (u.role === "partner" || !!u.partnerProfile)) issues.push("ADMIN_EMAIL OP ZAKELIJK/PARTNERACCOUNT");
    if (u.role === "admin" && u.partnerProfile) issues.push("ADMIN MET PARTNERPROFILE");
    if (u.role === "admin" && u.partnerSlug) issues.push("ADMIN MET PARTNERSLUG");
    if ((emailCounts[u.email] ?? 0) > 1) issues.push("DUBBEL EMAILADRES");
    if (u.role === "consument" && u.partnerProfile) issues.push("KOPER MET PARTNERPROFILE");
    if (u.role === "consument" && u.partnerSlug) issues.push("KOPER MET PARTNERSLUG");
    if (u.role === "partner" && !u.partnerProfile) issues.push("PARTNER ZONDER PROFIEL");
    if (u.partnerProfile?.status === "approved" && u.role !== "partner") issues.push("GOEDGEKEURD MAAR ROLE NIET PARTNER");
    if (u.role === "partner" && u.partnerProfile?.status === "approved" && !u.partnerSlug) issues.push("GOEDGEKEURD ZONDER SLUG");
    if (u.role === "partner" && u.partnerProfile?.status === "approved" && !sellerExists) issues.push("GOEDGEKEURD ZONDER SELLER-RECORD");
    if (u.role !== "partner" && u.role !== "admin" && db.listings.some(l => l.sellerSlug === u.partnerSlug)) issues.push("NIET-PARTNER MET LISTINGS");
    return issues.length ? [{ user: u, issues, sellerExists }] : [];
  });

  return (
    <div className="app dark">
      <main className="page adm">
        <div className="hd" style={{ display: "flex" }}>
          <span className="lock" style={{ color: "#fff" }}><Mark glow />BEHEER · OUTRUN <b>IQ</b></span>
          <span className="sp" />
          <span className="mini" style={{ color: "#5F6873" }}>{new Date().toLocaleDateString("nl-NL", { weekday: "long", day: "numeric", month: "long" })}</span>
        </div>

        <h1 className="h1big">Missiecontrole</h1>
        <div className="admgrid">
          {stats.map(s => (
            <div key={s.k} className={`admstat${s.hot ? " hot" : ""}`}>
              <span className="k">{s.k}</span>
              <b>{s.v}</b>
              {s.sub && <span className="sub">{s.sub}</span>}
            </div>
          ))}
        </div>

        {pending.length > 0 && (
          <>
            <div className="dsec" style={{ marginTop: 26 }}><h2>Partneraanvragen</h2><span>{pending.length} NIEUW</span></div>
            {pending.map(u => (
              <AdminApprove key={u.id} userId={u.id} label={`${u.partnerProfile!.companyName} · KvK ${u.partnerProfile!.kvk} · ${u.partnerProfile!.city} · ${u.email}`} />
            ))}
          </>
        )}
        {disputes.length > 0 && (
          <>
            <div className="dsec" style={{ marginTop: 22 }}><h2>Disputes</h2><span>{disputes.length} OPEN</span></div>
            {disputes.map(o => (
              <AdminResolve key={o.id} orderId={o.id}
                label={`${o.id} · ${o.itemTitle} · ${o.dispute?.category ?? ""} — "${(o.dispute?.text ?? "").slice(0, 90)}" · koper betaalde €${o.totalPaid}`} />
            ))}
          </>
        )}
        {escReturns.length > 0 && (
          <>
            <div className="dsec" style={{ marginTop: 22 }}><h2>Geëscaleerde retouren</h2><span>{escReturns.length}</span></div>
            {escReturns.map(o => (
              <AdminReturn key={o.id} orderId={o.id}
                label={`${o.id} · ${o.itemTitle} — "${o.returnRequest!.reason.slice(0, 90)}" · partner reageerde niet binnen de termijn`} />
            ))}
          </>
        )}

        <div className="dsec" style={{ marginTop: 26 }}><h2>Partners</h2><span>{partners.length}</span></div>
        {partners.length === 0 && <p className="note">Nog geen goedgekeurde partners.</p>}
        {partners.map(u => {
          const sl = db.sellers.find(x => x.slug === u.partnerSlug);
          const pl = db.listings.filter(l => l.sellerSlug === u.partnerSlug);
          const po = db.orders.filter(o => o.sellerSlug === u.partnerSlug);
          const issues = po.filter(o => o.status === "disputed" || ["requested", "escalated"].includes(o.returnRequest?.status ?? "")).length;
          return (
            <div key={u.id} className="orow" style={{ flexWrap: "wrap", gap: 8 }}>
              <span><b>{u.partnerProfile!.companyName}{issues > 0 ? ` · ⚠ ${issues}` : ""}</b>
                <span>{pl.filter(l => l.status === "published" || l.status === "active").length} LIVE · {po.length} ORDERS · ESCROW {sl?.trusted ? "7" : "14"} DGN · {u.email}</span></span>
              {sl && <AdminTrust slug={sl.slug} trusted={sl.trusted} />}
              <Link href={`/beheer/partner/${u.partnerSlug}${viaPin && me?.role !== "admin" ? `?pin=${pin}` : ""}`} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>INZAGE →</Link>
            </div>
          );
        })}

        <div className="dsec" style={{ marginTop: 26 }}><h2>Role audit</h2><span>{roleIssues.length ? `${roleIssues.length} CHECK` : "SCHOON"}</span></div>
        {roleIssues.length === 0 ? (
          <div className="orow"><span><b>Geen open deuren gevonden</b><span>Geen dubbele emails, geen koperaccounts met partnerrechten en geen missende seller-records.</span></span></div>
        ) : roleIssues.map(({ user: u, issues }) => (
          <div key={u.id} className="orow" style={{ borderColor: "rgba(241,166,50,.45)" }}>
            <span><b>{u.email}</b>
              <span>{u.name} · role={u.role} · partnerStatus={u.partnerProfile?.status ?? "—"} · slug={u.partnerSlug ?? "—"} · {issues.join(" · ")}</span></span>
          </div>
        ))}

        <div className="dsec" style={{ marginTop: 26 }}><h2>Finance safety</h2><span>{financeAudit.ok ? financeSafety.label : `${financeAudit.issues.length} CHECKS`}</span></div>
        <div className="orow" style={{ borderColor: financeAudit.ok ? "rgba(53,169,172,.35)" : "rgba(239,68,68,.55)", gap: 10, flexWrap: "wrap" }}>
          <span><b>{paymentStatus.label} · {financeSafety.label}</b><span>{financeSafety.message}</span></span>
          <Link href={`/api/admin/payments/status${viaPin && me?.role !== "admin" ? `?pin=${pin}` : ""}`} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>PAYMENT STATUS JSON →</Link>
        </div>
        <div className="orow" style={{ gap: 10, flexWrap: "wrap" }}>
          <span><b>Ledger integrity</b><span>{financeAudit.ok ? "Hash-chain, reserves en balances schoon." : financeAudit.issues.slice(0, 4).join(" · ")}</span></span>
          <span className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: financeAudit.ok ? "var(--petrol-glow)" : "#ef4444" }}>{financeAudit.totals.ledgerEntries} LEDGER · {financeAudit.totals.activeCampaigns} ACTIVE CAMPAIGNS</span>
        </div>



        <div className="dsec" style={{ marginTop: 26 }}><h2>AI Learning Foundation</h2><span>{learning.totals.productKeys} PRODUCT KEYS · CAPPED</span></div>
        <div className="admgrid">
          <div className="admstat"><span className="k">GELEERDE LISTINGS</span><b>{learning.totals.listingsLearned}</b><span className="sub">compacte snapshots</span></div>
          <div className="admstat"><span className="k">INTERACTIES</span><b>{learning.totals.views + learning.totals.saves + learning.totals.bids}</b><span className="sub">views/saves/bids geaggregeerd</span></div>
          <div className="admstat"><span className="k">ORDERS</span><b>{learning.totals.orders}</b><span className="sub">verkoopdata voor prijs-AI</span></div>
          <div className="admstat"><span className="k">DATA CAPS</span><b>{learning.caps.products}</b><span className="sub">producten · {learning.caps.daily} dagen</span></div>
        </div>
        <div className="orow" style={{ gap: 10, flexWrap: "wrap" }}>
          <span><b>Server-safe learning</b><span>Outrun bewaart alleen aggregaten: geen ruwe klikstream, geen foto-kopieën, geen grote payloads. Oude/zwakke productkeys worden automatisch weggesnoeid.</span></span>
          <Link href={`/api/admin/learning${viaPin && me?.role !== "admin" ? `?pin=${pin}` : ""}`} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>LEARNING JSON →</Link>
        </div>
        {learning.topProducts.slice(0, 6).map(p => (
          <div key={p.key} className="orow">
            <span><b>{p.brand || "Onbekend merk"}{p.model ? ` · ${p.model}` : ""}</b>
              <span>{p.category} · lijstprijs gem. {eur(p.avgListPrice)} · verkocht gem. {p.avgSoldPrice ? eur(p.avgSoldPrice) : "—"} · {p.totalViews} views · {p.totalSaves} saves · {p.totalBids} bids · {p.totalOrders} orders</span></span>
          </div>
        ))}


        <div className="dsec" style={{ marginTop: 26 }}><h2>AI Commerce Brain</h2><span>{commerceBrain.processed} EVENTS · QUEUE {commerceBrain.queue.length}/{commerceBrain.caps.queue}</span></div>
        <div className="admgrid">
          <div className="admstat"><span className="k">SEO READY</span><b>{commerceBrain.seoReady}</b><span className="sub">live productpagina's</span></div>
          <div className="admstat"><span className="k">MERK + MODEL</span><b>{commerceBrain.withBrandModel}</b><span className="sub">sterkere AI ranking</span></div>
          <div className="admstat"><span className="k">STRUCTURED DATA</span><b>{commerceBrain.seo.structuredDataReady}</b><span className="sub">Google/AI zichtbaar</span></div>
          <div className="admstat"><span className="k">DROPPED</span><b>{commerceBrain.dropped}</b><span className="sub">cap bescherming VPS</span></div>
        </div>
        <div className="orow" style={{ gap: 10, flexWrap: "wrap" }}>
          <span><b>Server-safe AI event queue</b><span>Events worden kort gebufferd en direct samengevat tot learning/SEO-status. Geen ruwe clickstream, geen foto's, geen zware payloads.</span></span>
          <Link href={`/api/admin/commerce-brain${viaPin && me?.role !== "admin" ? `?pin=${pin}` : ""}`} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>COMMERCE BRAIN JSON →</Link>
        </div>
        {commerceBrain.advice.slice(0, 5).map(a => (
          <div key={a.id} className="orow">
            <span><b>{a.title}</b><span>AI Commerce Score {a.score}/100 · {a.tips.join(" · ")}</span></span>
          </div>
        ))}

        <div className="dsec" style={{ marginTop: 26 }}><h2>Flow Recorder</h2><span>{(db.flowEvents ?? []).length} EVENTS · MASKED</span></div>
        <AdminFlowControls jsonlHref={flowJsonl} replayHref={flowReplay} />

        <div className="dsec" style={{ marginTop: 26 }}><h2>Outrun AI Brain</h2><span>{(db.aiDecisions ?? []).length} DECISIONS</span></div>
        <div className="orow" style={{ gap: 10, flexWrap: "wrap" }}>
          <span><b>AI Router</b><span>OpenAI voor taal/UX · DeepSeek voor analyse/ranking · Rules Engine als stabiele fallback</span></span>
          <Link href="/api/admin/ai/config" className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>CONFIG JSON →</Link>
          <Link href="/api/admin/ai/decisions" className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>DECISIONS JSON →</Link>
        </div>
        {aiProviderMatrix().slice(0, 4).map(row => (
          <div key={row.task} className="orow">
            <span><b>{row.task}</b><span>{row.plan.map(p => `${p.provider}:${p.available ? "aan" : "uit"}`).join(" · ")}</span></span>
          </div>
        ))}

        <div className="dsec" style={{ marginTop: 26 }}><h2>Audit log</h2><span>{auditRecent.length} RECENT</span></div>
        <div className="orow" style={{ gap: 10, flexWrap: "wrap" }}>
          <span><b>Download beheerlog</b><span>JSONL voor technische audit · CSV voor Excel/boekhouding</span></span>
          <Link href={auditJsonl} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>JSONL ↓</Link>
          <Link href={auditCsv} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>CSV ↓</Link>
        </div>
        {auditRecent.map(a => (
          <div key={a.id} className="orow">
            <span><b>{a.action} · {a.entityId ?? a.entity}</b>
              <span>{new Date(a.at).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} · {a.actorType.toUpperCase()} · {a.actorLabel ?? a.actorId ?? "systeem"} · {a.summary}</span></span>
          </div>
        ))}

        <div className="dsec" style={{ marginTop: 26 }}><h2>Laatste orders</h2><span>{recent.length}</span></div>
        {recent.map(o => (
          <div key={o.id} className="orow">
            <span><b>{o.itemTitle} · {eur(o.totalPaid)}</b>
              <span>{o.id} · {o.status.replaceAll("_", " ").toUpperCase()} · {o.sellerSlug.toUpperCase()} · {new Date(o.createdAt).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span></span>
          </div>
        ))}
      </main>
    </div>
  );
}
