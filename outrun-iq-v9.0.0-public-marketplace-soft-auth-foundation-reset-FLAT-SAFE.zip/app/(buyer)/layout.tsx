import { redirect } from "next/navigation";
import { BuyerDock, TopNav } from "@/components/Dock";
import { SplashIntro } from "@/components/SplashIntro";
import { getUser, isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function BuyerLayout({
  children, modal,
}: { children: React.ReactNode; modal: React.ReactNode }) {
  const user = await getUser();
  // Admin blijft in beheer. Partners mogen vanaf v9.0 ook gewoon de publieke shop bekijken.
  if (isAdmin(user)) redirect("/beheer");
  return (
    <div className="app">
      <SplashIntro />
      <TopNav isLoggedIn={!!user} isPartner={user?.role === "partner"} />
      {children}
      {modal}
      <BuyerDock />
    </div>
  );
}
