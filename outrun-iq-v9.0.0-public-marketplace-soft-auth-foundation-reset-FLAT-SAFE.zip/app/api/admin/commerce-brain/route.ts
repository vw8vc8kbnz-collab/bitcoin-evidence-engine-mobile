import { NextRequest, NextResponse } from "next/server";
import { getUser } from "@/lib/auth";
import { getCommerceBrainReport } from "@/lib/data";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const u = await getUser();
  const pin = req.nextUrl.searchParams.get("pin") || "";
  const viaPin = !!process.env.ADMIN_PIN && pin === process.env.ADMIN_PIN;
  if (u?.role !== "admin" && !viaPin) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  return NextResponse.json(await getCommerceBrainReport());
}
