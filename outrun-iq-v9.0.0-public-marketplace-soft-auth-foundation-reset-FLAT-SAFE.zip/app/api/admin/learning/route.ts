import { NextRequest, NextResponse } from "next/server";
import { getUser } from "@/lib/auth";
import { getLearningReport } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const me = await getUser();
  const pin = req.nextUrl.searchParams.get("pin") || "";
  const viaPin = !!process.env.ADMIN_PIN && pin === process.env.ADMIN_PIN;
  if (me?.role !== "admin" && !viaPin) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const report = await getLearningReport();
  return NextResponse.json(report);
}
