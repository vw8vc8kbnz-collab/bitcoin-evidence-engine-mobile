import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner, rateLimit } from "@/lib/auth";
import { getListingCopy } from "@/lib/ai/listingWriter";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  if (!rateLimit(`ai-listing-copy:${u?.id ?? "anon"}`, 45, 60 * 60_000)) {
    return NextResponse.json({ error: "AI-limiet bereikt. Probeer het straks opnieuw." }, { status: 429 });
  }
  const b = await req.json().catch(() => null);
  if (!b?.title || !b?.category) return NextResponse.json({ error: "title en category zijn verplicht" }, { status: 400 });
  const copy = await getListingCopy({
    title: String(b.title).slice(0, 120),
    brand: b.brand ? String(b.brand).slice(0, 60) : undefined,
    category: String(b.category).slice(0, 40),
    condition: String(b.condition ?? "").slice(0, 220),
    conditionScore: Math.min(10, Math.max(1, Number(b.conditionScore) || 7)),
    newPrice: Number(b.newPrice) || 0,
    price: Number(b.price) || 0,
    stock: Number(b.stock) || 1,
    photosCount: Number(b.photosCount) || 0,
    defect: b.defect ? String(b.defect).slice(0, 140) : undefined,
    model: b.model ? String(b.model).slice(0, 80) : undefined,
    articleNumber: b.articleNumber ? String(b.articleNumber).slice(0, 80) : undefined,
    identityConfirmed: Boolean(b.identityConfirmed),
    conditionReason: b.conditionReason ? String(b.conditionReason).slice(0, 220) : undefined,
    defects: Array.isArray(b.defects) ? b.defects.map((x: unknown) => String(x).slice(0, 120)).slice(0, 5) : undefined,
    accessories: Array.isArray(b.accessories) ? b.accessories.map((x: unknown) => String(x).slice(0, 80)).slice(0, 5) : undefined,
    energyLabel: b.energyLabel ? String(b.energyLabel).slice(0, 30) : undefined,
    visionSummary: b.visionSummary ? String(b.visionSummary).slice(0, 500) : undefined,
    market: b.market && typeof b.market === "object" ? b.market : undefined,
  });
  return NextResponse.json(copy);
}
