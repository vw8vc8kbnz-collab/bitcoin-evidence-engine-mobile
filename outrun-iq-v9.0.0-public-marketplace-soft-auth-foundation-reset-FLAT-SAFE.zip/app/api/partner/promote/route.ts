import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { createPromotionCampaign, getPromotionCampaigns, setPromotionCampaignStatus } from "@/lib/data";
import { read } from "@/lib/store";
import { generatePromotionCreatives } from "@/lib/ai/brain";
import type { Listing, PromotionCampaign } from "@/lib/types";
export const runtime = "nodejs";

const cats = new Set(["witgoed", "meubels", "keukens", "tuin", "overig"]);
const objectives = new Set(["views", "chats", "sell_faster", "brand"]);

export async function GET() {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen partners" }, { status: 403 });
  return NextResponse.json({ campaigns: await getPromotionCampaigns(u.partnerSlug) });
}

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen partners" }, { status: 403 });
  const b = await req.json().catch(() => null);
  if (b?.aiAutoExecute === true || b?.source === "ai_auto") return NextResponse.json({ error: "AI mag adviseren maar niet zelfstandig geld reserveren of campagnes starten." }, { status: 403 });
  const action = String(b?.action ?? "create");
  if (action === "status") {
    const status = String(b?.status ?? "paused") as PromotionCampaign["status"];
    if (!["active", "paused", "ended", "stopped"].includes(status)) return NextResponse.json({ error: "Ongeldige status" }, { status: 400 });
    return NextResponse.json(await setPromotionCampaignStatus(u.partnerSlug, String(b?.id ?? ""), status, String(b?.reason ?? "")));
  }
  const kind = String(b?.kind ?? "seller") as PromotionCampaign["kind"];
  if (!["listing", "seller", "category"].includes(kind)) return NextResponse.json({ error: "Ongeldig campagnetype" }, { status: 400 });
  const objective = String(b?.objective ?? "views") as PromotionCampaign["objective"];
  if (!objectives.has(objective)) return NextResponse.json({ error: "Ongeldig doel" }, { status: 400 });
  const category = cats.has(String(b?.category ?? "")) ? String(b.category) as Listing["category"] : undefined;
  const listingIds: string[] = Array.isArray(b?.listingIds)
    ? Array.from(new Set<string>(b.listingIds.map((x: unknown) => String(x)).filter(Boolean))).slice(0, 20)
    : (b?.listingId ? [String(b.listingId)] : []);
  const db = await read();
  const seller = db.sellers.find(s => s.slug === u.partnerSlug);
  const campaignName = String(b?.name ?? "Outrun Promote").trim() || "Outrun Promote";
  const campaignListings = db.listings.filter(l => l.sellerSlug === u.partnerSlug && (l.status === "published" || l.status === "active") && (
    kind === "seller" ||
    (kind === "listing" && listingIds.includes(l.id)) ||
    (kind === "category" && l.category === category)
  )).slice(0, 8);
  const creative = await generatePromotionCreatives({ seller, listings: campaignListings, objective, name: campaignName, kind });
  const result = await createPromotionCampaign({
    sellerSlug: u.partnerSlug,
    kind,
    listingId: listingIds[0],
    listingIds,
    category,
    name: campaignName,
    objective,
    budgetDaily: Number(b?.budgetDaily) || 5,
    days: Number(b?.days) || 7,
    creativeVariants: creative.variants,
    selectedVariantId: creative.variants[0]?.id,
    requestId: typeof b?.requestId === "string" ? b.requestId.slice(0, 80) : undefined,
    initiatedBy: "partner",
  });
  const status = "error" in result ? 400 : 200;
  return NextResponse.json(result, { status });
}
