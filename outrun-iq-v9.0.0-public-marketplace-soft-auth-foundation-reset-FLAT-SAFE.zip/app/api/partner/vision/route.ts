import { NextResponse, type NextRequest } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import { getUser, isApprovedPartner, rateLimit } from "@/lib/auth";
import { analyzeProductPhotos, isVisionConfigured } from "@/lib/ai/vision";
import { UPLOAD_DIR, LEGACY_UPLOAD_DIR } from "@/lib/store";
export const runtime = "nodejs";

const MIME: Record<string, string> = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".heic": "image/heic" };

async function readUploadAsDataUrl(photoUrl: unknown): Promise<string | null> {
  const raw = String(photoUrl ?? "");
  const name = path.basename(raw);       // padtraversal onmogelijk
  const ext = path.extname(name).toLowerCase();
  if (!raw.startsWith("/uploads/") || !MIME[ext]) return null;
  for (const dir of [UPLOAD_DIR, LEGACY_UPLOAD_DIR]) {
    try {
      const buf = await fs.readFile(path.join(dir, name));
      return `data:${MIME[ext]};base64,${buf.toString("base64")}`;
    } catch { /* volgende */ }
  }
  return null;
}

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  if (!rateLimit(`ai-vision:${u?.id ?? "anon"}`, 30, 60 * 60_000)) {
    return NextResponse.json({ error: "AI-limiet bereikt. Probeer het straks opnieuw." }, { status: 429 });
  }
  if (!isVisionConfigured()) {
    return NextResponse.json({ error: "AI-fotoherkenning staat nog uit. Zet VISION_API_KEY en VISION_MODEL op een multimodaal model." }, { status: 503 });
  }

  const body = await req.json().catch(() => ({}));
  const photoUrls = Array.isArray(body.photoUrls) ? body.photoUrls : [body.photoUrl];
  const dataUrls = (await Promise.all(photoUrls.slice(0, 5).map(readUploadAsDataUrl))).filter(Boolean) as string[];
  if (!dataUrls.length) return NextResponse.json({ error: "Geen geldige foto's gevonden" }, { status: 400 });

  const fields = await analyzeProductPhotos(dataUrls);
  if (!fields) {
    return NextResponse.json({ error: "AI-herkenning niet beschikbaar of provider ondersteunt geen beelden — zie serverlog" }, { status: 502 });
  }
  return NextResponse.json({ ...fields, photosAnalyzed: dataUrls.length });
}
