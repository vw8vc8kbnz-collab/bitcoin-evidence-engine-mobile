import { NextResponse } from "next/server";
import { getActiveListings, publicListings } from "@/lib/data";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const listings = await getActiveListings();
  return NextResponse.json({ listings: publicListings(listings) });
}
