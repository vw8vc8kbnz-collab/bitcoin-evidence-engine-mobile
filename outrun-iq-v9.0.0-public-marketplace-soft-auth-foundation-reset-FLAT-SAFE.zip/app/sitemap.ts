import type { MetadataRoute } from "next";
import { getActiveListings } from "@/lib/data";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = "https://outruniq.nl";
  const listings = await getActiveListings();
  return [
    { url: `${base}/`, lastModified: new Date(), changeFrequency: "daily", priority: 1 },
    { url: `${base}/categorieen`, lastModified: new Date(), changeFrequency: "daily", priority: 0.8 },
    ...listings.slice(0, 2000).map((l) => ({
      url: `${base}/listing/${l.id}`,
      lastModified: new Date(l.createdAt),
      changeFrequency: "daily" as const,
      priority: 0.7,
    })),
  ];
}
