import Link from "next/link";
import { NewListingFlow } from "@/components/NewListingFlow";

export default function Nieuw() {
  return (
    <main className="page narrow partnerNewClean" style={{ paddingBottom: 170 }}>
      <header className="hd">
        <Link href="/partner" className="back" style={{ color: "#fff" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Terug
        </Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>NIEUW PRODUCT</span>
      </header>
      <section className="cleanPartnerHero">
        <span className="eyebrow">PRODUCT PER 1</span>
        <h1 className="h1big">Voeg één outletproduct toe</h1>
        <p>De werkbank en bulk-groepering zijn verwijderd. Je voegt nu bewust één product tegelijk toe, met maximaal 5 foto’s, AI-hulp voor herkenning, prijsadvies en listingtekst.</p>
      </section>
      <NewListingFlow />
    </main>
  );
}
