# Outrun IQ v9.0.0

Public Marketplace & Soft Authentication Foundation Reset.

Belangrijkste richting: Outrun start niet meer met een loginmuur. Bezoekers kunnen producten, stores, zoeken en AI Vinder bekijken zonder account. Login is pas nodig bij duidelijke intentie: kopen, bewaren, chat/orders, account en partnerfuncties.

Deploypad: `/var/www/outrun-iq-v5`.
