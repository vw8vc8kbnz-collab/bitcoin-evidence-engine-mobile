# Changelog

## v9.0.0 — Public Marketplace & Soft Authentication Foundation Reset

- `/` is nu public-first: bezoekers kunnen snuffelen zonder account.
- Login is verschoven naar intent-momenten: bewaren, kopen, orders, account en partnerfuncties.
- `/welkom` is nu alleen auth en niet langer de primaire entree.
- Partneraccounts mogen de publieke shop bekijken; kopen blijft alleen voor persoonlijke kopersaccounts.
- Test Mode veiliger gemaakt: admin-testprofiel is standaard geblokkeerd en verschijnt alleen met aparte admin-test env flags.
- Publieke listings worden via een buyer-facing projectie geretourneerd; interne OCR, serienummers, partnerRef, internalPhotos en reviewChecklist worden niet meer via de publieke listings-API gestuurd.
- Publieke homepage krijgt een marketplace-hero met zoekbalk, AI Vinder en partner-CTA.
- Bulk/foto-werkbank blijft buiten de hoofdflow; partnerflow blijft single-product-first.
