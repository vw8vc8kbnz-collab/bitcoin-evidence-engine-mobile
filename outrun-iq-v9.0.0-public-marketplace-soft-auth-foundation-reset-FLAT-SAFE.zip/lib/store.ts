import { promises as fs } from "fs";
import path from "path";
import type { DB } from "./types";

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

const EMPTY: DB = { users: [], sessions: [], codes: [], saved: [], notifications: [], sellers: [], listings: [], outletBatches: [], processingJobs: [], orders: [], bids: [], pushSubs: [], reviews: [], auditLog: [], flowEvents: [], aiDecisions: [], promotionCampaigns: [], walletLedger: [], traffic: {}, counters: { order: 0 } };

type G = typeof globalThis & { __oiqDb?: DB; __oiqLock?: Promise<void> };
const g = globalThis as G;

async function load(): Promise<DB> {
  if (g.__oiqDb) return g.__oiqDb;
  try {
    const raw = await fs.readFile(DB_FILE, "utf8");
    g.__oiqDb = { ...EMPTY, ...JSON.parse(raw) };
  } catch {
    g.__oiqDb = structuredClone(EMPTY);
  }
  return g.__oiqDb!;
}

async function persist(db: DB) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const tmp = DB_FILE + ".tmp";
  await fs.writeFile(tmp, JSON.stringify(db, null, 2), "utf8");
  await fs.rename(tmp, DB_FILE); // atomisch
}

/** Serialiseert alle schrijfacties (single-process; pm2 draait 1 instance). */
export async function mutate<T>(fn: (db: DB) => T | Promise<T>): Promise<T> {
  const prev = g.__oiqLock ?? Promise.resolve();
  let release!: () => void;
  g.__oiqLock = new Promise<void>(r => (release = r));
  await prev;
  try {
    const db = await load();
    const out = await fn(db);
    await persist(db);
    return out;
  } finally {
    release();
  }
}

export async function read(): Promise<DB> {
  return structuredClone(await load());
}

export const UPLOAD_DIR = path.join(DATA_DIR, "uploads");                    // runtime-uploads (update- en buildproof)
export const LEGACY_UPLOAD_DIR = path.join(process.cwd(), "public", "uploads"); // oude locatie, alleen-lezen fallback
