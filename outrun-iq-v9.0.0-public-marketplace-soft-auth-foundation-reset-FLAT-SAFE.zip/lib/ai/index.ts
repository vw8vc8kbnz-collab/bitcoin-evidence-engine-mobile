/**
 * AI Model Abstraction Layer (Masterplan V1.1 Amendment 3).
 * Provider = vervangbaar component. Routing per taaktype; nu: reasoning (pricing).
 * ENV: AI_PROVIDER=deepseek|heuristiek (default: deepseek als key aanwezig), DEEPSEEK_API_KEY.
 */
import { deepseekPricing } from "./deepseek";
import { heuristicPricing } from "./heuristic";
import { getMarketSignals, selectMarketAnchor } from "./market";

export type PricingInput = {
  title: string; brand?: string; category: string;
  condition: string; conditionScore: number;   // 1–10
  newPrice: number;                            // nieuwprijs/prijsanker, mag 0 zijn als marktscan nodig is
  stock: number; photosCount: number; defect?: string;
  model?: string; articleNumber?: string; identityConfirmed?: boolean; marketScanRequested?: boolean;
  visionSummary?: string; conditionReason?: string; defects?: string[]; accessories?: string[]; energyLabel?: string;
  marketSignals?: { label: string; source: string; low: number; high: number; average: number; confidence: number; notes: string }[];
};

export type PriceAdvice = {
  fast: number; outlet: number; premium: number;
  expectedDaysFast: number; expectedDaysOutlet: number; expectedDaysPremium: number;
  confidence: number;          // 0–100
  comps: number;               // 0 = geen echte marktscan gedaan
  reasoning: string;           // 1 zin NL, tonen aan seller
  source: "deepseek" | "heuristiek";
  marketAverage?: number;
  marketLow?: number;
  marketHigh?: number;
  referenceNewPrice?: number;
  marketConfidence?: number;
  pricingBasis?: "live_market" | "market_anchor" | "new_price" | "fallback";
  marketSignals?: { label: string; source: string; low: number; high: number; average: number; confidence: number; notes: string }[];
  priceWarning?: string;
};

export async function getPriceAdvice(input: PricingInput): Promise<PriceAdvice> {
  const marketSignals = await getMarketSignals(input);
  const anchor = selectMarketAnchor(marketSignals);
  const enriched: PricingInput = { ...input, marketSignals };
  if (anchor && (!input.newPrice || input.newPrice < anchor.average * 0.45 || input.marketScanRequested)) {
    enriched.newPrice = Math.max(input.newPrice || 0, Math.round(anchor.high * 1.18));
    enriched.visionSummary = [input.visionSummary, `Marktanker: ${anchor.label}, gemiddeld €${anchor.average}, range €${anchor.low}-€${anchor.high}, ${anchor.notes}`].filter(Boolean).join(" · ");
  }

  const provider = process.env.AI_PROVIDER
    ?? (process.env.DEEPSEEK_API_KEY ? "deepseek" : "heuristiek");
  let out: PriceAdvice | null = null;
  if (provider === "deepseek" && process.env.DEEPSEEK_API_KEY) {
    try { out = await deepseekPricing(enriched); }
    catch (e) { console.error("[ai] deepseek faalde, val terug op heuristiek:", e); }
  }
  if (!out) out = heuristicPricing(enriched);

  if (anchor) {
    out.marketSignals = marketSignals;
    out.marketAverage = out.marketAverage || anchor.average;
    out.marketLow = out.marketLow || anchor.low;
    out.marketHigh = out.marketHigh || anchor.high;
    out.marketConfidence = Math.max(out.marketConfidence || 0, anchor.confidence);
    out.pricingBasis = anchor.source === "webhook" ? "live_market" : "market_anchor";
    if (input.newPrice && input.newPrice < anchor.average * 0.45) {
      out.priceWarning = `Prijsanker €${input.newPrice} lijkt te laag voor ${anchor.label}; marktanker gebruikt.`;
    }
  } else {
    out.pricingBasis = input.newPrice ? "new_price" : "fallback";
    out.marketSignals = [];
    if (!input.newPrice) out.priceWarning = "Geen marktanker gevonden; vraag bouwjaar/modelcode/extra foto voor beter advies.";
  }
  return out;
}
