import type { PricingInput } from "./index";

export type MarketSignal = {
  label: string;
  source: "modelkennis" | "catalogus" | "webhook" | "fallback";
  low: number;
  high: number;
  average: number;
  confidence: number;
  notes: string;
};

function norm(s: string | undefined) { return String(s || "").toLowerCase(); }
function round(v: number, step = 50) { return Math.max(step, Math.round(v / step) * step); }
function includesAny(s: string, terms: string[]) { return terms.some(t => s.includes(t)); }

function vehicleModelKey(i: PricingInput) {
  const s = norm(`${i.title} ${i.brand ?? ""} ${i.model ?? ""} ${i.visionSummary ?? ""}`);
  if (includesAny(s, ["road king", "flhr", "flhrc"])) return "harley-road-king";
  if (includesAny(s, ["heritage", "softail classic", "flstc"])) return "harley-heritage-softail";
  if (includesAny(s, ["softail deluxe", "flstn", "deluxe"])) return "harley-softail-deluxe";
  if (includesAny(s, ["harley", "harley-davidson", "cruiser", "touring"])) return "harley-cruiser-unknown";
  if (includesAny(s, ["yamaha vmax", "vmax"])) return "yamaha-vmax";
  if (includesAny(s, ["motor", "motorfiets", "cruiser", "touring"])) return "motor-unknown";
  return "";
}

export function localMarketSignals(i: PricingInput): MarketSignal[] {
  const key = vehicleModelKey(i);
  const cond = Math.min(10, Math.max(1, Number(i.conditionScore) || 7));
  const conditionFactor = 0.86 + cond * 0.025;

  if (key === "harley-road-king") {
    const avg = round(14250 * conditionFactor, 100);
    return [{ label: "Harley-Davidson Road King / Classic", source: "catalogus", low: round(avg * .78, 100), high: round(avg * 1.22, 100), average: avg, confidence: 76, notes: "Modelkandidaat met realistische Nederlandse tweedehandsrange; bouwjaar/km ontbreken." }];
  }
  if (key === "harley-heritage-softail") {
    const avg = round(13250 * conditionFactor, 100);
    return [{ label: "Harley-Davidson Heritage Softail Classic", source: "catalogus", low: round(avg * .78, 100), high: round(avg * 1.22, 100), average: avg, confidence: 73, notes: "Heritage/Softail-kandidaat; bevestig model, bouwjaar en km voor scherper advies." }];
  }
  if (key === "harley-softail-deluxe") {
    const avg = round(14750 * conditionFactor, 100);
    return [{ label: "Harley-Davidson Softail Deluxe", source: "catalogus", low: round(avg * .78, 100), high: round(avg * 1.22, 100), average: avg, confidence: 72, notes: "Softail Deluxe-kandidaat; prijs blijft breed zonder bouwjaar/km." }];
  }
  if (key === "harley-cruiser-unknown") {
    const avg = round(13500 * conditionFactor, 100);
    return [{ label: "Harley-Davidson cruiser/touring", source: "catalogus", low: round(avg * .65, 100), high: round(avg * 1.35, 100), average: avg, confidence: 64, notes: "Harley-merk waarschijnlijk; specifiek model onzeker. Vraag tanklogo/typeplaatje/dashboard." }];
  }
  if (key === "yamaha-vmax") {
    const avg = round(7500 * conditionFactor, 100);
    return [{ label: "Yamaha VMAX", source: "catalogus", low: round(avg * .72, 100), high: round(avg * 1.25, 100), average: avg, confidence: 66, notes: "VMAX-kandidaat; controleer bouwjaar/uitvoering." }];
  }
  if (key === "motor-unknown") {
    const avg = round(5200 * conditionFactor, 100);
    return [{ label: "Motorfiets / cruiser onbekend", source: "fallback", low: round(avg * .55, 100), high: round(avg * 1.55, 100), average: avg, confidence: 38, notes: "Te weinig identiteit voor exact prijsadvies; extra foto's of kenteken/modelcode nodig." }];
  }

  // Algemeen: prijsanker omzetten naar verkooprange, maar alleen als het anker geloofwaardig is.
  if (i.newPrice && i.newPrice > 0) {
    const avg = round(i.newPrice * (0.54 + (cond - 5) * 0.045), 5);
    return [{ label: "Prijsanker + conditie", source: "modelkennis", low: round(avg * .88, 5), high: round(avg * 1.14, 5), average: avg, confidence: 46 + cond * 2, notes: "Geen externe marktbron; gebruikt prijsanker, staat en outletlogica." }];
  }
  return [];
}

export async function externalMarketSignals(i: PricingInput): Promise<MarketSignal[]> {
  const endpoint = process.env.MARKET_SCAN_ENDPOINT;
  if (!endpoint) return [];
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 12_000);
  try {
    const res = await fetch(endpoint, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", ...(process.env.MARKET_SCAN_KEY ? { Authorization: `Bearer ${process.env.MARKET_SCAN_KEY}` } : {}) },
      body: JSON.stringify({ title: i.title, brand: i.brand, model: i.model, category: i.category, condition: i.condition, articleNumber: i.articleNumber }),
    });
    if (!res.ok) return [];
    const j = await res.json().catch(() => null);
    const raw = Array.isArray(j?.signals) ? j.signals : [];
    return raw.map((x: any) => ({
      label: String(x.label || x.title || "Marktsignaal").slice(0, 80),
      source: "webhook" as const,
      low: Number(x.low) || 0,
      high: Number(x.high) || 0,
      average: Number(x.average) || Number(x.price) || 0,
      confidence: Math.max(0, Math.min(100, Number(x.confidence) || 55)),
      notes: String(x.notes || x.reason || "Extern prijsanker").slice(0, 160),
    })).filter((x: MarketSignal) => x.average > 0);
  } catch { return []; }
  finally { clearTimeout(t); }
}

export async function getMarketSignals(i: PricingInput): Promise<MarketSignal[]> {
  const external = await externalMarketSignals(i);
  const local = localMarketSignals(i);
  return [...external, ...local].slice(0, 5);
}

export function selectMarketAnchor(signals: MarketSignal[]) {
  if (!signals.length) return null;
  const sorted = [...signals].sort((a, b) => b.confidence - a.confidence || b.average - a.average);
  return sorted[0];
}
