import type { PricingInput, PriceAdvice } from "./index";

export type ListingCopyInput = PricingInput & {
  price?: number;
  photos?: string[];
  identityConfirmed?: boolean;
  market?: Pick<PriceAdvice, "marketLow" | "marketHigh" | "marketAverage" | "confidence" | "pricingBasis" | "reasoning">;
};

export type ListingCopy = {
  title: string;
  shortDescription: string;
  description: string;
  longDescription: string;
  seoTitle: string;
  metaDescription: string;
  searchKeywords: string[];
  altTexts: string[];
  bullets: string[];
  sourceMode: "known_product_paraphrase" | "vision_generated" | "safe_fallback";
  confidence: number;
  warnings?: string[];
};

const clean = (s: unknown, max = 500) => String(s ?? "").replace(/\s+/g, " ").trim().slice(0, max);
const uniq = (arr: string[]) => Array.from(new Set(arr.map(x => clean(x, 42)).filter(Boolean))).slice(0, 14);

function baseKeywords(input: ListingCopyInput) {
  const title = clean(input.title, 100);
  const brand = clean(input.brand, 50);
  const model = clean(input.model, 80);
  const cat = clean(input.category, 40);
  const words = [brand, model, title, cat, "tweedehands", "outlet", "gecontroleerd", "bezorgen", "Nederland"];
  if (/harley|motor|cruiser|touring/i.test([brand, model, title, cat].join(" "))) {
    words.push("Harley-Davidson", "Harley", "cruiser", "touring motor", "tweedehands motor", "motor kopen");
  }
  return uniq(words);
}

function makeTitle(input: ListingCopyInput) {
  const brand = clean(input.brand, 45);
  const model = clean(input.model, 70);
  let title = clean(input.title, 90);
  if (brand && model && !title.toLowerCase().includes(brand.toLowerCase())) title = `${brand} ${model}`;
  if (!title && brand) title = [brand, model].filter(Boolean).join(" ");
  const extras: string[] = [];
  if (input.conditionScore >= 8) extras.push("nette staat");
  if (input.defect) extras.push("met aandachtspunt");
  if (input.accessories?.length) extras.push("incl. accessoires");
  return [title || "Gecontroleerd outletproduct", ...extras].filter(Boolean).join(" – ").slice(0, 90);
}

export function heuristicListingCopy(input: ListingCopyInput): ListingCopy {
  const title = makeTitle(input);
  const brandModel = [input.brand, input.model].map(x => clean(x, 80)).filter(Boolean).join(" ") || title;
  const condition = clean(input.conditionReason || input.condition, 180) || `conditiescore ${input.conditionScore || 7}/10`;
  const defects = (input.defects || []).map(x => clean(x, 90)).filter(Boolean).slice(0, 3);
  const accessories = (input.accessories || []).map(x => clean(x, 70)).filter(Boolean).slice(0, 4);
  const kws = baseKeywords(input);
  const market = input.market?.marketLow && input.market?.marketHigh ? `De AI-prijscheck vergelijkt dit aanbod met een marktbandbreedte rond €${input.market.marketLow}–€${input.market.marketHigh}.` : "De prijs is gecontroleerd met Outrun IQ op basis van producttype, conditie en beschikbare marktankers.";
  const productLine = input.identityConfirmed || input.model
    ? `${brandModel} is een herkenbaar product binnen de categorie ${input.category}.`
    : `Dit product is door Outrun IQ beoordeeld op basis van de foto's, categorie en conditie.`;
  const bulletBase = [
    `${brandModel}`,
    `Conditie: ${condition}`,
    defects.length ? `Aandachtspunt: ${defects.join(", ")}` : "Gecontroleerde outletdeal",
    accessories.length ? `Meegeleverd: ${accessories.join(", ")}` : "Levering in overleg",
  ];
  const shortDescription = `${productLine} ${condition}. ${market}`.slice(0, 360);
  const description = [
    `${title} is een gecontroleerde outletdeal via Outrun IQ.`,
    productLine,
    `De staat is beoordeeld als ${condition}.`,
    defects.length ? `Bekende aandachtspunten: ${defects.join(", ")}.` : "Er zijn geen grote zichtbare aandachtspunten vastgelegd in de AI-samenvatting.",
    accessories.length ? `Meegeleverd/zichtbaar: ${accessories.join(", ")}.` : "Controleer de foto's voor exacte uitvoering en meegeleverde onderdelen.",
    market,
    `Interessant voor kopers die zoeken naar ${kws.slice(0, 5).join(", ")}.`,
  ].join(" ");
  const longDescription = `${description} Deze tekst is origineel geschreven voor deze listing en combineert fotoanalyse, conditie-informatie en prijscontext. Vraag de partner bij twijfel om extra details zoals modelcode, bouwjaar, serienummer of accessoires.`;
  const metaDescription = `${title}. Gecontroleerde outletdeal met AI-prijscheck, conditie ${input.conditionScore || 7}/10 en veilige aankoop via Outrun IQ.`.slice(0, 155);
  return {
    title,
    shortDescription,
    description: description.slice(0, 900),
    longDescription: longDescription.slice(0, 1600),
    seoTitle: `${title} kopen | Outrun IQ`.slice(0, 68),
    metaDescription,
    searchKeywords: kws,
    altTexts: [
      `${title} hoofdfoto`,
      `${brandModel} detailfoto`,
      `${title} conditie en accessoires`,
      `${brandModel} tweedehands outletdeal`,
      `${title} productlabel of extra detail`,
    ].slice(0, Math.max(1, Math.min(5, input.photosCount || 5))),
    bullets: uniq(bulletBase).slice(0, 5),
    sourceMode: input.model || input.identityConfirmed ? "known_product_paraphrase" : "vision_generated",
    confidence: Math.max(50, Math.min(94, Math.round((input.market?.confidence || 60) * 0.45 + (input.conditionScore || 7) * 4 + (input.identityConfirmed ? 18 : 0)))),
    warnings: input.identityConfirmed ? [] : ["Merk/model niet volledig bevestigd; tekst bewust voorzichtig gehouden."],
  };
}

export async function deepseekListingCopy(input: ListingCopyInput): Promise<ListingCopy> {
  if (!process.env.DEEPSEEK_API_KEY) return heuristicListingCopy(input);
  const prompt = `Schrijf originele Nederlandse productlisting-copy voor Outrun IQ. BELANGRIJK: kopieer geen fabrikant/webshoptekst letterlijk. Als merk/model bekend is, gebruik algemene productkennis en parafraseer volledig. Als onbekend: schrijf op basis van foto/conditie. SEO natuurlijk verwerken, geen keyword stuffing. Output strikt JSON met: title, shortDescription, description, longDescription, seoTitle, metaDescription, searchKeywords array, altTexts array, bullets array, sourceMode, confidence, warnings array. Input: ${JSON.stringify(input).slice(0, 3500)}`;
  const res = await fetch("https://api.deepseek.com/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}` },
    body: JSON.stringify({
      model: process.env.DEEPSEEK_MODEL || "deepseek-chat",
      temperature: 0.35,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    }),
  });
  if (!res.ok) throw new Error(`DeepSeek listing copy HTTP ${res.status}`);
  const j = await res.json();
  const raw = j?.choices?.[0]?.message?.content;
  const parsed = JSON.parse(raw || "{}");
  const fallback = heuristicListingCopy(input);
  return {
    title: clean(parsed.title, 90) || fallback.title,
    shortDescription: clean(parsed.shortDescription, 360) || fallback.shortDescription,
    description: clean(parsed.description, 1000) || fallback.description,
    longDescription: clean(parsed.longDescription, 1800) || fallback.longDescription,
    seoTitle: clean(parsed.seoTitle, 68) || fallback.seoTitle,
    metaDescription: clean(parsed.metaDescription, 155) || fallback.metaDescription,
    searchKeywords: uniq(Array.isArray(parsed.searchKeywords) ? parsed.searchKeywords : fallback.searchKeywords),
    altTexts: (Array.isArray(parsed.altTexts) ? parsed.altTexts : fallback.altTexts).map((x: unknown) => clean(x, 120)).filter(Boolean).slice(0, 5),
    bullets: (Array.isArray(parsed.bullets) ? parsed.bullets : fallback.bullets).map((x: unknown) => clean(x, 120)).filter(Boolean).slice(0, 5),
    sourceMode: parsed.sourceMode === "known_product_paraphrase" || parsed.sourceMode === "vision_generated" ? parsed.sourceMode : fallback.sourceMode,
    confidence: Math.max(0, Math.min(100, Math.round(Number(parsed.confidence) || fallback.confidence))),
    warnings: Array.isArray(parsed.warnings) ? parsed.warnings.map((x: unknown) => clean(x, 120)).filter(Boolean).slice(0, 3) : fallback.warnings,
  };
}

export async function getListingCopy(input: ListingCopyInput): Promise<ListingCopy> {
  if ((process.env.AI_PROVIDER ?? "deepseek") === "deepseek" && process.env.DEEPSEEK_API_KEY) {
    try { return await deepseekListingCopy(input); } catch (e) { console.error("[ai] listing writer fallback:", e); }
  }
  return heuristicListingCopy(input);
}
