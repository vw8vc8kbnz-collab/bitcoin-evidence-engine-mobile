/** Vision-taakroute van de AI Model Abstraction Layer.
 *
 * Belangrijk: vision wordt bewust NIET meer stil naar DeepSeek-text teruggezet.
 * Zet expliciet VISION_API_KEY + VISION_MODEL op een multimodaal model
 * (bijv. OpenAI gpt-4o-mini of een EU multimodaal model). Zonder die env-vars
 * blijft vision uit en vult de partner de velden handmatig in.
 */

import { brandHintBlock, applyBrandHints } from "./brand-hints";

export type VisionFields = {
  title: string;
  brand: string;
  model: string;
  category: "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
  color: string;
  condition: string;
  conditionScore: number;     // 1-10
  conditionReason: string;    // korte verdedigbare motivatie
  defect: string;             // leeg = geen zichtbaar gebrek
  defects: string[];          // per-foto schade/gebrek observaties
  accessories: string[];
  energyLabel: string;
  newPriceEstimate: number;   // geschatte adviesprijs in hele euro's, 0 = onbekend
  sellingPoints: string[];
  seriesCandidates: string[];
  modelCandidates: string[];
  articleNumber: string;
  serialMasked: string;
  ocrText: string;
  confidence: number;
  needsExtraPhotos: string[];
  photoRoles: { index: number; role: "hero" | "angle" | "condition" | "accessories" | "label" | "serial" | "packaging" | "irrelevant"; buyerFacing: boolean; reason?: string }[];
  uncertainty: boolean;
  source: string;
};

const CATS = ["witgoed", "meubels", "keukens", "tuin", "overig"] as const;

function num(x: unknown): number {
  if (typeof x === "number" && isFinite(x)) return Math.round(x);
  if (typeof x === "string") {
    const v = parseFloat(x.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", "."));
    if (isFinite(v)) return Math.round(v);
  }
  return 0;
}
function str(x: unknown, max = 160): string { return String(x ?? "").slice(0, max).trim(); }
function arr(x: unknown, maxItems = 5, maxLen = 90): string[] {
  return Array.isArray(x) ? x.map(v => str(v, maxLen)).filter(Boolean).slice(0, maxItems) : [];
}
function roles(x: unknown, maxPhotos = 5): VisionFields["photoRoles"] {
  if (!Array.isArray(x)) return [];
  const allowed = new Set(["hero", "angle", "condition", "accessories", "label", "serial", "packaging", "irrelevant"]);
  return x.map((v, i) => {
    const o = (v && typeof v === "object") ? v as Record<string, unknown> : {};
    const idx = Math.min(maxPhotos, Math.max(1, num(o.index) || (i + 1)));
    const role = allowed.has(String(o.role)) ? String(o.role) as VisionFields["photoRoles"][number]["role"] : "angle";
    const buyerFacing = typeof o.buyerFacing === "boolean" ? o.buyerFacing : !["label", "serial", "irrelevant"].includes(role);
    return { index: idx, role, buyerFacing, reason: str(o.reason, 80) || undefined };
  }).filter(x => x.index >= 1 && x.index <= maxPhotos).slice(0, maxPhotos);
}



// (merkspecifieke normalisatie verplaatst naar lib/ai/brand-hints.ts — data i.p.v. code)

export function isVisionConfigured() {
  return Boolean(process.env.VISION_API_KEY && process.env.VISION_MODEL);
}

export async function analyzeProductPhotos(dataUrls: string[]): Promise<VisionFields | null> {
  const key = process.env.VISION_API_KEY;
  const model = process.env.VISION_MODEL;
  if (!key || !model) {
    console.error("[ai-vision] uitgeschakeld: VISION_API_KEY en VISION_MODEL zijn verplicht voor beeldherkenning.");
    return null;
  }
  const api = process.env.VISION_BASE_URL || "https://api.openai.com/v1/chat/completions";
  const images = dataUrls.filter(Boolean).slice(0, 5);
  if (!images.length) return null;

  const sys = `Je bent de productherkenning van Outrun IQ, een Nederlandse outlet-marketplace. Je krijgt maximaal 5 foto's van hetzelfde product. Foto 1 is meestal de hoofdfoto; latere foto's tonen zijkant, verpakking, label, serienummer of schade. Beoordeel merk, model, conditie en gebreken op basis van ALLE foto's.

Antwoord UITSLUITEND met geldige JSON, exact deze sleutels:
{"title":"","brand":"","model":"","category":"","color":"","condition":"","conditionScore":0,"conditionReason":"","defect":"","defects":[],"accessories":[],"energyLabel":"","newPriceEstimate":0,"sellingPoints":[],"brandCandidates":[],"seriesCandidates":[],"modelCandidates":[],"articleNumber":"","serialMasked":"","ocrText":"","confidence":0,"needsExtraPhotos":[],"photoRoles":[],"uncertainty":false}

Kernregels:
- title: korte NL producttitel, max 80 tekens. Als merk zichtbaar is, benoem merk + waarschijnlijke serie. Verzin NOOIT een exact model zonder zichtbaar bewijs (badge, typeplaatje, OCR, doos).
- Herkenningsladder verplicht: eerst productsoort, dan merk, dan serie/familie, dan exact modelnummer.
- brand alleen invullen als logo/merknaam zichtbaar is of OCR/label dat zeer sterk ondersteunt. Is het alleen een generieke koptelefoon/wasmachine? Laat brand leeg of gebruik “onbekend”, zet uncertainty=true en vraag extra foto.
- model alleen invullen als exact model zichtbaar/sterk onderbouwd is. Anders: serie in title/model en exacte opties in modelCandidates.
- brandCandidates: 2-5 mogelijke merken alleen als het echt twijfel tussen merken is. seriesCandidates: 2-6 mogelijke productfamilies/series. modelCandidates: 3-8 exacte modelcodes of modelnamen passend bij gekozen/waarschijnlijke serie.
- Kritische anti-hallucinatie: Sony WH-1000XM5 mag alleen bij duidelijke Sony/WH/XM5 aanwijzingen; Samsung EcoBubble alleen bij Samsung/EcoBubble/WW-code aanwijzingen. Geen merk-fallback op basis van productsoort.
- category: precies één uit witgoed, meubels, keukens, tuin, overig.
- conditionScore 1-10 (onzeker=7); conditionReason = verdedigbare motivatie in één zin.
- defects: max 5 bullets, per foto wat opvalt ("foto 3: kras rechts"). defect = belangrijkste gebrek of leeg.
- energyLabel, articleNumber (SKU/EAN/modelcode via OCR), serialMasked ("****1234"), ocrText (korte samenvatting) alleen indien zichtbaar.
- photoRoles: per foto {index, role, buyerFacing, reason}; role uit hero/angle/condition/accessories/label/serial/packaging/irrelevant. Label- en serienummerfoto's zijn normaal buyerFacing=false (intern voor OCR, niet in de publieke galerij).
- newPriceEstimate: realistische NL nieuwprijs in hele euro's (0 = onbekend). sellingPoints: 2-3 korte verkoopargumenten.
Verzin geen typenummers, labels of schade die je niet ziet.

${brandHintBlock()}`;

  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 30_000);
  try {
    const content: any[] = [
      { type: "text", text: `Analyseer deze ${images.length} foto('s) als één product. Gebruik alle foto's, inclusief label-, artikelnummer-, schade- en detailfoto's. Bepaal ook welke foto's openbaar naar buyers mogen en welke intern moeten blijven. Als merk/model niet 90%+ zeker is: geef productsoort + mogelijke brandCandidates/seriesCandidates/modelCandidates en uncertainty=true; verzin geen exact model. Geen Sony/Samsung/Bosch als fallback zonder zichtbaar merk.` },
      ...images.flatMap((url, idx) => ([
        { type: "text", text: `Foto ${idx + 1}` },
        { type: "image_url", image_url: { url } },
      ])),
    ];
    const res = await fetch(api, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        temperature: 0.1,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content },
        ],
      }),
    });
    if (!res.ok) {
      console.error("[ai-vision] provider weigerde:", res.status, (await res.text().catch(() => "")).slice(0, 400));
      return null;
    }
    const data = await res.json();
    const raw = String(data?.choices?.[0]?.message?.content ?? "");
    const p = JSON.parse(raw.replace(/```json|```/g, "").trim());
    const cat = CATS.includes(p.category) ? p.category : "overig";
    const score = Math.min(10, Math.max(1, num(p.conditionScore) || 7));
    const defects = arr(p.defects, 5, 100);
    const out: VisionFields = {
      title: str(p.title, 70),
      brand: str(p.brand, 40),
      model: str(p.model, 50),
      category: cat,
      color: str(p.color, 30),
      condition: str(p.condition, 140),
      conditionScore: score,
      conditionReason: str(p.conditionReason, 180),
      defect: str(p.defect, 120) || defects[0] || "",
      defects,
      accessories: arr(p.accessories, 5, 60),
      energyLabel: str(p.energyLabel, 20),
      newPriceEstimate: Math.max(0, num(p.newPriceEstimate)),
      sellingPoints: arr(p.sellingPoints, 3, 70),
      seriesCandidates: arr(p.seriesCandidates, 6, 80),
      modelCandidates: arr(p.modelCandidates, 8, 90),
      articleNumber: str(p.articleNumber, 60),
      serialMasked: str(p.serialMasked, 30),
      ocrText: str(p.ocrText, 220),
      confidence: Math.min(100, Math.max(0, num(p.confidence) || (p.uncertainty ? 55 : 75))),
      needsExtraPhotos: arr(p.needsExtraPhotos, 4, 80),
      photoRoles: roles(p.photoRoles, images.length),
      uncertainty: Boolean(p.uncertainty),
      source: String(data?.model ?? model),
    };
    const normalized = applyBrandHints(out);
    return normalized.title ? normalized : null;
  } catch (e) {
    console.error("[ai-vision] fout:", e);
    return null;
  } finally { clearTimeout(t); }
}

export async function analyzeProductPhoto(dataUrl: string): Promise<VisionFields | null> {
  return analyzeProductPhotos([dataUrl]);
}
