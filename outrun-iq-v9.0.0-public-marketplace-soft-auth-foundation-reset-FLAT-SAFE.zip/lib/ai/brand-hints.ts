/** Merk- en serie-hints als DATA, niet als harde herkenning.
 *
 * v8.8.4 Product Resolver 2.0:
 * - Geen merk mag ooit als default/fallback worden ingevuld op basis van een generiek producttype.
 * - Hints mogen alleen helpen NADAT merk/serie zichtbaar of OCR-matig aannemelijk is.
 * - Exacte modelnummers zijn kandidaat-opties voor partnerbevestiging, geen buyer-facing zekerheid.
 */

export type BrandHint = {
  match: string[];
  fallbackType: string;
  seriesCandidates: string[];
  modelCandidates: string[];
  needPhoto?: string;
};

export const BRAND_HINTS: BrandHint[] = [
  {
    match: ["sony", "wh-1000", "wh1000", "xm5", "xm4", "xm3"],
    fallbackType: "Sony noise-cancelling koptelefoon",
    seriesCandidates: ["Sony WH-1000X-serie", "Sony ULT-serie", "Sony WH-CH-serie"],
    modelCandidates: ["Sony WH-1000XM5", "Sony WH-1000XM4", "Sony WH-1000XM3", "Sony ULT Wear", "Sony WH-CH720N"],
    needPhoto: "foto van de typecode op de beugel, oorschelp of doos"
  },
  {
    match: ["bose", "quietcomfort", "qc45", "qc 45", "qc35", "700 headphones"],
    fallbackType: "Bose noise-cancelling koptelefoon",
    seriesCandidates: ["Bose QuietComfort", "Bose Noise Cancelling Headphones"],
    modelCandidates: ["Bose QuietComfort Ultra Headphones", "Bose QuietComfort 45", "Bose QuietComfort 35 II", "Bose Noise Cancelling Headphones 700"],
    needPhoto: "foto van logo en modeltekst aan binnenzijde/oorschelp"
  },
  {
    match: ["jbl", "tour one", "live 770", "live 660", "tune 760", "tune 770"],
    fallbackType: "JBL koptelefoon",
    seriesCandidates: ["JBL Tour", "JBL Live", "JBL Tune"],
    modelCandidates: ["JBL Tour One M2", "JBL Live 770NC", "JBL Live 660NC", "JBL Tune 770NC", "JBL Tune 760NC"],
    needPhoto: "foto van modeltekst op doos of binnenzijde van de hoofdband"
  },
  {
    match: ["sennheiser", "momentum", "accentum", "hd 450"],
    fallbackType: "Sennheiser koptelefoon",
    seriesCandidates: ["Sennheiser Momentum", "Sennheiser Accentum", "Sennheiser HD"],
    modelCandidates: ["Sennheiser Momentum 4 Wireless", "Sennheiser Accentum Plus", "Sennheiser Accentum Wireless", "Sennheiser HD 450BT"],
    needPhoto: "foto van modeltekst op doos, case of binnenzijde"
  },
  {
    match: ["samsung wasmachine", "samsung wasautomaat", "ecobubble", "eco bubble", "addwash", "quickdrive", "bespoke", "ww90", "ww80", "ww11", "ww12"],
    fallbackType: "Samsung wasmachine",
    seriesCandidates: ["Samsung EcoBubble", "Samsung AddWash", "Samsung QuickDrive", "Samsung Bespoke AI"],
    modelCandidates: ["Samsung EcoBubble WW90T534AAW", "Samsung EcoBubble WW80TA049AE", "Samsung EcoBubble WW90CGC04AAE", "Samsung AddWash WW90T554AAW", "Samsung QuickDrive WW90T986ASH", "Samsung Bespoke AI WW11BB944AGB"],
    needPhoto: "foto van de modelcodesticker in de deuropening"
  },
  {
    match: ["bosch wasmachine", "bosch serie 4", "bosch serie 6", "bosch serie 8", "wan", "wat", "wav", "wgg"],
    fallbackType: "Bosch wasmachine",
    seriesCandidates: ["Bosch Serie 4", "Bosch Serie 6", "Bosch Serie 8"],
    modelCandidates: ["Bosch WAN28275NL", "Bosch WGG244F9NL", "Bosch WGG244Z5NL", "Bosch WAX32M40NL", "Bosch WAV28K0SNL"],
    needPhoto: "foto van het typeplaatje aan de binnenzijde van de deur"
  },
  {
    match: ["miele wasmachine", "miele w1", "powerwash", "twindos", "wca", "wcd", "wsg"],
    fallbackType: "Miele wasmachine",
    seriesCandidates: ["Miele W1", "Miele W1 PowerWash", "Miele W1 TwinDos"],
    modelCandidates: ["Miele WCA 030 WCS", "Miele WCD 030 WCS", "Miele WSG 363 WCS", "Miele WSI 863 WCS", "Miele WWG 760 WPS"],
    needPhoto: "foto van het Miele typeplaatje in de deuropening"
  },
  {
    match: ["samsung koelkast", "koel-vries", "no frost", "bespoke", "rb34", "rb38", "rb36", "family hub"],
    fallbackType: "Samsung koel-vriescombinatie",
    seriesCandidates: ["Samsung Bespoke", "Samsung No Frost RB-serie", "Samsung Family Hub"],
    modelCandidates: ["Samsung RB34C600ESA", "Samsung RB38C7B6AS9", "Samsung RB38A7B6AS9", "Samsung Bespoke RB38C7B6AB1", "Samsung Family Hub RS6HA8891SL"],
    needPhoto: "foto van het typeplaatje binnenin de koelkast"
  },
  {
    match: ["thrustmaster", "racestuur", "sim racing", "playstation stuur", "t300", "t248", "t-gt"],
    fallbackType: "Thrustmaster racestuur",
    seriesCandidates: ["Thrustmaster T300", "Thrustmaster T248", "Thrustmaster T-GT", "Thrustmaster TX"],
    modelCandidates: ["Thrustmaster T300 RS GT", "Thrustmaster T300 RS", "Thrustmaster T-GT II", "Thrustmaster T248", "Thrustmaster TX"],
    needPhoto: "foto van het typeplaatje onderop de basis"
  },
  {
    match: ["harley", "harley-davidson", "softail", "road king", "heritage", "deluxe", "v-twin"],
    fallbackType: "Harley-Davidson cruiser/touring motor",
    seriesCandidates: ["Harley-Davidson Touring", "Harley-Davidson Softail", "Harley-Davidson Heritage"],
    modelCandidates: ["Harley-Davidson Road King", "Harley-Davidson Heritage Softail Classic", "Harley-Davidson Softail Deluxe", "Harley-Davidson Fat Boy", "Harley-Davidson Street Bob"],
    needPhoto: "foto van tanklogo, dashboard en typeplaatje op het frame"
  },
  {
    match: ["dyson", "v15", "v12", "v11", "v10", "v8", "detect", "absolute"],
    fallbackType: "Dyson steelstofzuiger",
    seriesCandidates: ["Dyson V-serie", "Dyson Detect", "Dyson Absolute"],
    modelCandidates: ["Dyson V15 Detect Absolute", "Dyson V12 Detect Slim", "Dyson V11 Absolute", "Dyson Cyclone V10", "Dyson V8 Absolute"],
    needPhoto: "foto van de modelnaam op de motorunit"
  },
  {
    match: ["jura", "ena", "e8", "s8", "z10", "impressa"],
    fallbackType: "Jura volautomaat espressomachine",
    seriesCandidates: ["Jura E-serie", "Jura ENA", "Jura S-serie", "Jura Z-serie"],
    modelCandidates: ["Jura E8", "Jura ENA 8", "Jura S8", "Jura Z10", "Jura E6"],
    needPhoto: "foto van het typeplaatje aan de achterzijde"
  },
];

export function brandHintBlock(): string {
  const table = BRAND_HINTS.map((h) => ({
    herkenAlleenBijDezeTekst: h.match,
    type: h.fallbackType,
    series: h.seriesCandidates,
    modellen: h.modelCandidates,
    extraFoto: h.needPhoto ?? "",
  }));
  return (
    `Product-resolver hints. Gebruik deze lijst alleen als merk/serie zichtbaar is in logo, badge, OCR, doos of zeer duidelijke producttekst. ` +
    `Gebruik NOOIT Sony, Samsung, Bosch enz. als fallback voor een generieke koptelefoon/wasmachine zonder zichtbaar merk. ` +
    `Bij twijfel: laat brand/model leeg of generiek, zet uncertainty=true en vraag extra foto. Hints: ` +
    JSON.stringify(table)
  );
}

export function applyBrandHints<T extends {
  title: string; brand: string; model: string; modelCandidates: string[];
  needsExtraPhotos: string[]; uncertainty: boolean; confidence: number;
  seriesCandidates?: string[];
}>(out: T): T {
  const hay = `${out.title} ${out.brand} ${out.model}`.toLowerCase();
  const haveBrandOrCode = Boolean(out.brand.trim()) || /\b[a-z]{1,4}\d{2,}[a-z0-9-]*\b/i.test(hay);

  for (const h of BRAND_HINTS) {
    if (!h.match.some((m) => hay.includes(m))) continue;
    // Kritisch: geen merk injecteren op basis van alleen generieke productsoort.
    if (!haveBrandOrCode && !h.match.some((m) => m.includes("-") || /\d/.test(m))) continue;

    const generic = out.title.trim().split(/\s+/).length <= 2 || !out.model;
    if (generic && !out.title) out.title = h.fallbackType;

    out.seriesCandidates = Array.from(new Set([...(out.seriesCandidates ?? []), ...h.seriesCandidates])).slice(0, 6);
    const have = new Set(out.modelCandidates.map((c) => c.toLowerCase()));
    for (const c of h.modelCandidates) if (!have.has(c.toLowerCase())) out.modelCandidates.push(c);
    out.modelCandidates = out.modelCandidates.slice(0, 8);

    if (generic || out.modelCandidates.length) {
      out.uncertainty = true;
      if (out.confidence > 88) out.confidence = 82;
      if (h.needPhoto && !out.needsExtraPhotos.includes(h.needPhoto)) {
        out.needsExtraPhotos = [...out.needsExtraPhotos, h.needPhoto].slice(0, 4);
      }
    }
    break;
  }
  return out;
}
