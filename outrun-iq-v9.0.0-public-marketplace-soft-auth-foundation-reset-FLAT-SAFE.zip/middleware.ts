import { NextResponse, type NextRequest } from "next/server";

// v9.0.0 Foundation Reset:
// Outrun is public-first. Visitors can browse, search, view stores/listings and use AI Finder.
// Login is only required at intent moments: buying, saving, chat/order, account, partner and admin.
const PUBLIC_PREFIXES = [
  "/",
  "/welkom",
  "/zoeken",
  "/listing",
  "/store",
  "/vinder",
  "/word-partner",
  "/juridisch",
  "/offline",
  "/api/auth/",
  "/api/beacon",
  "/api/listings",
  "/api/vinder",
  "/manifest.webmanifest",
  "/sw.js",
  "/icons/",
  "/brand/",
  "/uploads/",
];

const AUTH_PREFIXES = [
  "/account",
  "/bewaard",
  "/meldingen",
  "/checkout",
  "/order",
  "/partner",
  "/api/me",
  "/api/orders",
  "/api/bids",
  "/api/partner",
  "/api/push",
];

function matches(pathname: string, prefixes: string[]) {
  return prefixes.some(p => pathname === p || (p !== "/" && pathname.startsWith(p)));
}

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const hasSession = !!req.cookies.get("oiq_sessie")?.value;

  // Admin blijft hard afgeschermd; eigen pagina/API doet extra PIN/role checks.
  if (pathname.startsWith("/beheer") || pathname.startsWith("/api/admin")) {
    if (!hasSession) {
      if (pathname.startsWith("/api/")) return NextResponse.json({ error: "Log in" }, { status: 401 });
      const url = req.nextUrl.clone();
      url.pathname = "/welkom";
      url.searchParams.set("next", pathname);
      return NextResponse.redirect(url);
    }
    return NextResponse.next();
  }

  if (matches(pathname, AUTH_PREFIXES) && !hasSession) {
    if (pathname.startsWith("/api/")) return NextResponse.json({ error: "Log in" }, { status: 401 });
    const url = req.nextUrl.clone();
    url.pathname = "/welkom";
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  if (matches(pathname, PUBLIC_PREFIXES)) return NextResponse.next();
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
