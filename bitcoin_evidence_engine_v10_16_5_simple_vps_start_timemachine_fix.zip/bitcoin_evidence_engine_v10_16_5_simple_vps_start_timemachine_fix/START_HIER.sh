#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Stap 1/1: Bitcoin Evidence Engine simpel starten/herstarten..."
bash restart_vps.sh
