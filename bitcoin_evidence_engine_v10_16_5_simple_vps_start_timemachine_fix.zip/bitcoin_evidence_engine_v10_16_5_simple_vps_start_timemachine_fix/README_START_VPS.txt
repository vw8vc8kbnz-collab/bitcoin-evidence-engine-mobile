Bitcoin Evidence Engine v10.16.5 - simpele VPS start

Dit is de versie die twee dingen oplost:
1. Time Machine native-core mismatch: Linux bouwt nu de Go native core, niet meer de oude C++ core met verkeerde tm_random argument-volgorde.
2. Startproblemen op VPS: start_vps.sh gebruikt nu altijd .venv/bin/python en niet meer de globale python3 zonder uvicorn.

Gebruik op de VPS:

cd ~/bitcoin-engine-deploy/bitcoin_evidence_engine_v10_16_5_simple_vps_start_timemachine_fix
bash START_HIER.sh

Als je handmatig wilt:

bash install_vps.sh
bash restart_vps.sh

Status checken:

bash CHECK_STATUS.sh

Logs:

cat server.log

Stoppen:

bash stop_vps.sh

Open daarna:
http://51.195.102.180:8787

Test in de app:
- Home online
- Data Health 70.000+ candles
- Machine > Random100
- Machine > Random1000
- Geen stoul foutmelding meer
