from __future__ import annotations
import httpx
from app.core.config import settings

class CoinbaseProvider:
    source = 'coinbase'
    base_url = 'https://api.exchange.coinbase.com'

    async def fetch_btc_usd_ticker(self) -> dict:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds, headers={'User-Agent':'BitcoinEvidenceEngine/8.4'}) as client:
            r = await client.get(f'{self.base_url}/products/BTC-USD/ticker')
            r.raise_for_status()
            x = r.json()
        return {'price': float(x.get('price') or 0), 'volume': float(x.get('volume') or 0), 'trade_id': x.get('trade_id')}
