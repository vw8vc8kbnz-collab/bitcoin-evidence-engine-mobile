from __future__ import annotations
import httpx
from app.core.config import settings

class KrakenProvider:
    source = "kraken"
    base_url = "https://api.kraken.com"

    async def fetch_btc_usd_ticker(self) -> dict:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            r = await client.get(f"{self.base_url}/0/public/Ticker", params={"pair": "XBTUSD"})
            r.raise_for_status()
            data = r.json()["result"]
        key = next(iter(data.keys()))
        x = data[key]
        return {"price": float(x["c"][0]), "volume": float(x["v"][1])}
