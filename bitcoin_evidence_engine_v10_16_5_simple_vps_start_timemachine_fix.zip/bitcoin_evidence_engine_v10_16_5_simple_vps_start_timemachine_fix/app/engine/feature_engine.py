from __future__ import annotations
import json
import numpy as np
import pandas as pd
from app.db.database import db
from app.engine.indicators import rsi, safe_pct_change

HALVINGS_MS = [
    1354116278000,
    1468082773000,
    1589225023000,
    1713571767000,
]
CYCLE_DAYS = 1458

class FeatureEngine:
    """Builds the normalized evidence timeline.

    V5 turns raw market/futures/sentiment/on-chain points into a single hourly
    feature table. Every model reads from this table so future data sources can
    be added without touching the dashboard or forecast storage.
    """
    interval = "1h"

    def rebuild(self) -> int:
        df = db.df("""
            SELECT open_time AS timestamp_ms, open, close, high, low, volume
            FROM raw_candles
            WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h'
            ORDER BY open_time DESC
            LIMIT 12000
        """)
        if df.empty:
            return 0
        df = df.sort_values("timestamp_ms").reset_index(drop=True)  # V6.9: keep live forecast fast; deep history remains in raw_candles
        df["return_1"] = safe_pct_change(df["close"], 1)
        df["return_4"] = safe_pct_change(df["close"], 4)
        df["return_24"] = safe_pct_change(df["close"], 24)
        df["ma_20"] = df["close"].rolling(20).mean()
        df["ma_50"] = df["close"].rolling(50).mean()
        df["ma_200"] = df["close"].rolling(200).mean()
        df["rsi_14"] = rsi(df["close"], 14)
        df["volatility_24"] = df["return_1"].rolling(24).std()
        vol_ma = df["volume"].rolling(24).mean()
        vol_std = df["volume"].rolling(168).std()
        df["volume_ratio_24"] = df["volume"] / vol_ma
        df["volume_zscore"] = (df["volume"] - vol_ma) / vol_std
        df["range_pct"] = (df["high"] - df["low"]) / df["close"] * 100
        df["candle_body_pct"] = (df["close"] - df.get("open", df["close"])) / df["close"] * 100
        df["ath"] = df["close"].cummax()
        df["drawdown_from_ath"] = (df["close"] / df["ath"] - 1) * 100

        df = self._merge_metric(df, 'alternative_me', 'fear_greed', 'fear_greed', tolerance_ms=7*86400000)
        for metric, col, tol, source in [
            ('funding_rate', 'funding_rate', 10*3600000, 'binance_futures'),
            ('open_interest_value', 'open_interest_value', 4*3600000, 'binance_futures'),
            ('long_short_ratio', 'long_short_ratio', 4*3600000, 'binance_futures'),
            ('taker_buy_sell_ratio', 'taker_buy_sell_ratio', 4*3600000, 'binance_futures'),
            ('taker_delta_ratio', 'taker_delta_ratio', 4*3600000, 'binance_futures'),
            ('futures_basis_premium_pct', 'futures_basis_premium_pct', 4*3600000, 'binance_futures'),
            ('top_position_long_short_ratio', 'top_position_long_short_ratio', 4*3600000, 'binance_futures'),
            ('top_account_long_short_ratio', 'top_account_long_short_ratio', 4*3600000, 'binance_futures'),
            ('cross_exchange_spread_pct', 'cross_exchange_spread_pct', 2*3600000, 'spot_composite'),
            ('spot_premium_kraken_pct', 'spot_premium_kraken_pct', 2*3600000, 'spot_composite'),
            ('spot_premium_coinbase_pct', 'spot_premium_coinbase_pct', 2*3600000, 'spot_composite'),
            # V6: one composite signal built from Binance, Coinbase, Kraken, OKX and Bybit.
            # The dashboard/model sees one orderbook layer; raw metadata preserves exchange detail.
            ('orderbook_imbalance', 'orderbook_imbalance', 6*3600000, 'composite_orderbook'),
            ('orderbook_spread', 'orderbook_spread', 6*3600000, 'composite_orderbook'),
        ]:
            df = self._merge_metric(df, source, metric, col, tolerance_ms=tol)

        # Coin Metrics daily fields, forward-filled only within 45 days so old data
        # doesn't silently pretend to be current.
        for metric, col in [
            ('CapMrktCurUSD', 'market_cap_usd'),
            ('CapRealUSD', 'realized_cap_usd'),
            ('CapMVRVCur', 'coinmetrics_mvrv'),
        ]:
            df = self._merge_metric(df, 'coinmetrics_community', metric, col, tolerance_ms=45*86400000)

        if 'coinmetrics_mvrv' not in df or df['coinmetrics_mvrv'].isna().all():
            if 'market_cap_usd' in df and 'realized_cap_usd' in df:
                df['coinmetrics_mvrv'] = df['market_cap_usd'] / df['realized_cap_usd']

        df['open_interest_change_24h'] = safe_pct_change(df.get('open_interest_value', pd.Series(index=df.index, dtype=float)), 24)

        rows=[]
        for _, r in df.iterrows():
            ts = int(r.timestamp_ms)
            last_halving = max([h for h in HALVINGS_MS if h <= ts], default=HALVINGS_MS[0])
            days_since = (ts - last_halving) / 86400000
            cycle_progress = min(max(days_since / CYCLE_DAYS, 0), 1)
            regime = self._classify_regime(r, cycle_progress)
            completeness = self._data_completeness(r)
            state = {
                "close": _val(r.close),
                "rsi_14": _val(r.rsi_14),
                "ma50_distance": _safe((r.close / r.ma_50 - 1) * 100),
                "ma200_distance": _safe((r.close / r.ma_200 - 1) * 100),
                "volatility_24": _val(r.volatility_24),
                "volume_zscore": _val(r.volume_zscore),
                "volume_ratio_24": _val(r.volume_ratio_24),
                "range_pct": _val(r.range_pct),
                "candle_body_pct": _val(r.candle_body_pct),
                "drawdown_from_ath": _val(r.drawdown_from_ath),
                "days_since_halving": days_since,
                "cycle_progress": cycle_progress,
                "fear_greed": _val(getattr(r, 'fear_greed', None)),
                "funding_rate": _val(getattr(r, 'funding_rate', None)),
                "open_interest_value": _val(getattr(r, 'open_interest_value', None)),
                "open_interest_change_24h": _val(getattr(r, 'open_interest_change_24h', None)),
                "long_short_ratio": _val(getattr(r, 'long_short_ratio', None)),
                "taker_buy_sell_ratio": _val(getattr(r, 'taker_buy_sell_ratio', None)),
                "orderbook_imbalance": _val(getattr(r, 'orderbook_imbalance', None)),
                "orderbook_spread": _val(getattr(r, 'orderbook_spread', None)),
                "taker_delta_ratio": _val(getattr(r, 'taker_delta_ratio', None)),
                "futures_basis_premium_pct": _val(getattr(r, 'futures_basis_premium_pct', None)),
                "top_position_long_short_ratio": _val(getattr(r, 'top_position_long_short_ratio', None)),
                "top_account_long_short_ratio": _val(getattr(r, 'top_account_long_short_ratio', None)),
                "cross_exchange_spread_pct": _val(getattr(r, 'cross_exchange_spread_pct', None)),
                "spot_premium_kraken_pct": _val(getattr(r, 'spot_premium_kraken_pct', None)),
                "spot_premium_coinbase_pct": _val(getattr(r, 'spot_premium_coinbase_pct', None)),
                "coinmetrics_mvrv": _val(getattr(r, 'coinmetrics_mvrv', None)),
                "regime": regime,
                "data_completeness": completeness,
            }
            rows.append((
                self.interval, ts, _val(r.close), _val(r.return_1), _val(r.return_4), _val(r.return_24),
                _val(r.ma_20), _val(r.ma_50), _val(r.ma_200), _val(r.rsi_14), _val(r.volatility_24),
                _val(r.volume_zscore), _val(r.volume_ratio_24), _val(r.range_pct), _val(r.candle_body_pct),
                _val(r.drawdown_from_ath), days_since, cycle_progress, _val(getattr(r, 'fear_greed', None)),
                _val(getattr(r, 'funding_rate', None)), _val(getattr(r, 'open_interest_value', None)),
                _val(getattr(r, 'open_interest_change_24h', None)), _val(getattr(r, 'long_short_ratio', None)),
                _val(getattr(r, 'taker_buy_sell_ratio', None)), _val(getattr(r, 'orderbook_imbalance', None)),
                _val(getattr(r, 'orderbook_spread', None)), _val(getattr(r, 'taker_delta_ratio', None)),
                _val(getattr(r, 'futures_basis_premium_pct', None)), _val(getattr(r, 'top_position_long_short_ratio', None)),
                _val(getattr(r, 'top_account_long_short_ratio', None)), _val(getattr(r, 'cross_exchange_spread_pct', None)),
                _val(getattr(r, 'spot_premium_kraken_pct', None)), _val(getattr(r, 'spot_premium_coinbase_pct', None)),
                _val(getattr(r, 'coinmetrics_mvrv', None)), _val(getattr(r, 'realized_cap_usd', None)), _val(getattr(r, 'market_cap_usd', None)),
                regime, completeness, json.dumps(state)
            ))
        # DuckDB on Windows can be very slow with executemany into JSON columns.
        # V6.9 inserts through a registered DataFrame instead; this keeps Forecast fast.
        import pandas as _pd
        cols = [
            "interval", "timestamp_ms", "close", "return_1", "return_4", "return_24",
            "ma_20", "ma_50", "ma_200", "rsi_14", "volatility_24", "volume_zscore",
            "volume_ratio_24", "range_pct", "candle_body_pct", "drawdown_from_ath",
            "days_since_halving", "cycle_progress", "fear_greed", "funding_rate",
            "open_interest_value", "open_interest_change_24h", "long_short_ratio",
            "taker_buy_sell_ratio", "orderbook_imbalance", "orderbook_spread",
            "taker_delta_ratio", "futures_basis_premium_pct", "top_position_long_short_ratio",
            "top_account_long_short_ratio", "cross_exchange_spread_pct", "spot_premium_kraken_pct",
            "spot_premium_coinbase_pct", "coinmetrics_mvrv", "realized_cap_usd", "market_cap_usd", "regime",
            "data_completeness", "state_json"
        ]
        frame = _pd.DataFrame(rows, columns=cols)
        db.upsert_features_frame(frame)
        return len(rows)

    def _merge_metric(self, df: pd.DataFrame, source: str, metric: str, col: str, tolerance_ms: int) -> pd.DataFrame:
        m = db.df("""
            SELECT timestamp_ms, value AS metric_value
            FROM raw_metric_points
            WHERE source=? AND metric=?
            ORDER BY timestamp_ms
        """, [source, metric])
        if m.empty:
            df[col] = np.nan if col not in df else df[col]
            return df
        merged = pd.merge_asof(
            df.sort_values('timestamp_ms'),
            m.sort_values('timestamp_ms'),
            on='timestamp_ms',
            direction='backward',
            tolerance=tolerance_ms,
        )
        df[col] = merged['metric_value'].values
        return df

    def _classify_regime(self, r, cycle_progress: float) -> str:
        close, ma50, ma200 = _val(r.close), _val(r.ma_50), _val(r.ma_200)
        dd = _val(r.drawdown_from_ath) or 0
        rsi_v = _val(r.rsi_14) or 50
        if close and ma50 and ma200 and close > ma50 > ma200 and dd > -20:
            return 'bull_trend'
        if close and ma50 and ma200 and close < ma50 < ma200 and dd < -35:
            return 'bear_trend'
        if dd < -55:
            return 'capitulation'
        if cycle_progress < 0.18 and close and ma200 and close > ma200:
            return 'post_halving_accumulation'
        if rsi_v > 72 and dd > -10 and cycle_progress > 0.45:
            return 'euphoria_risk'
        return 'transition'

    def _data_completeness(self, r) -> float:
        cols = ['rsi_14','ma_50','ma_200','volatility_24','volume_zscore','range_pct','fear_greed','funding_rate','open_interest_value','long_short_ratio','taker_buy_sell_ratio','orderbook_imbalance','taker_delta_ratio','futures_basis_premium_pct','top_position_long_short_ratio','cross_exchange_spread_pct','coinmetrics_mvrv']
        present = sum(1 for c in cols if _val(getattr(r, c, None)) is not None)
        return round(present / len(cols) * 100, 1)

def _val(x):
    try:
        if pd.isna(x) or x is None: return None
        if np.isinf(x): return None
        return float(x)
    except Exception:
        return None

def _safe(x):
    return _val(x)
