from __future__ import annotations

"""V10.14.5 Data Foundation orchestration.

This service is deliberately small and boring.  It owns the data-readiness flow
so the rest of the app can scale without every route deciding for itself which
providers are critical, important or optional.

Design rules:
- Critical data must become visible quickly: Binance 1h candles + ticker.
- Forecasts may only be created after minimum local candle requirements pass.
- Optional providers are never allowed to block dashboard/chart/Time Machine.
- Every phase writes sync_state so the UI and exported logs show where we are.
"""

import asyncio
from dataclasses import dataclass
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl, write_json
from app.core.logger import log
from app.core.time_utils import utc_now
from app.db.database import db
from app.services.audit_service import AuditService
from app.services.forecast_service import ForecastService
from app.services.health_service import HealthService
from app.services.sync_service import SyncService
from app.engine.feature_engine import FeatureEngine
from app.services.historical_memory_service import HistoricalMemoryService


@dataclass(frozen=True)
class MinimumDataPolicy:
    min_candles_for_forecast: int = 260
    ideal_candles_for_features: int = 1000
    max_latest_candle_age_hours: float = 6.0


class DataFoundationService:
    """Clean scalable data pipeline for V10.4+.

    The public methods are intended for routes/background tasks:
    - bootstrap_visible_data(): fast critical data only.
    - run_forecast_pipeline(): critical data + readiness + forecast.
    - sync_important_background(): capped evidence layers, non-blocking.
    - readiness(): single source of truth for whether data is usable.
    """

    policy = MinimumDataPolicy()

    def __init__(self) -> None:
        self.sync = SyncService()
        self.health = HealthService()

    def _state(self, key: str, value: str) -> None:
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", [key, value, utc_now()])

    def _event(self, event: str, **extra: Any) -> None:
        append_jsonl("data_foundation_audit.jsonl", {"event": event, **extra})

    def readiness(self) -> dict:
        row = db.fetchone(
            """
            SELECT COUNT(*), MIN(open_time), MAX(open_time)
            FROM raw_candles
            WHERE source='binance' AND symbol=? AND interval='1h'
            """,
            [settings.symbol],
        )
        count = int(row[0] or 0) if row else 0
        min_ts = int(row[1]) if row and row[1] is not None else None
        max_ts = int(row[2]) if row and row[2] is not None else None
        latest_candle = db.fetchone(
            """
            SELECT close, open_time, close_time
            FROM raw_candles
            WHERE source='binance' AND symbol=? AND interval='1h'
            ORDER BY open_time DESC LIMIT 1
            """,
            [settings.symbol],
        )
        last_close = float(latest_candle[0]) if latest_candle and latest_candle[0] is not None else None
        now_ms = int(utc_now().timestamp() * 1000)
        age_h = ((now_ms - max_ts) / 3600000.0) if max_ts else None
        ticker = db.fetchone(
            """
            SELECT value, timestamp_ms FROM raw_metric_points
            WHERE source='binance_ticker' AND metric='btc_last_price'
            ORDER BY timestamp_ms DESC LIMIT 1
            """
        )
        feature_row = db.fetchone("SELECT COUNT(*), MAX(timestamp_ms) FROM features WHERE interval='1h'")
        feature_count = int(feature_row[0] or 0) if feature_row else 0
        ready = bool(
            count >= self.policy.min_candles_for_forecast
            and last_close is not None
            and (age_h is None or age_h <= self.policy.max_latest_candle_age_hours)
        )
        missing = []
        if count < self.policy.min_candles_for_forecast:
            missing.append(f"candles {count}/{self.policy.min_candles_for_forecast}")
        if last_close is None:
            missing.append("latest candle price")
        if age_h is not None and age_h > self.policy.max_latest_candle_age_hours:
            missing.append(f"latest candle too old ({age_h:.1f}h)")
        return {
            "ready_for_forecast": ready,
            "candle_count": count,
            "min_candle_ts": min_ts,
            "max_candle_ts": max_ts,
            "latest_candle_age_hours": age_h,
            "latest_candle_close": last_close,
            "ticker_price": float(ticker[0]) if ticker and ticker[0] is not None else None,
            "ticker_ts": int(ticker[1]) if ticker and ticker[1] is not None else None,
            "feature_count": feature_count,
            "feature_max_ts": int(feature_row[1]) if feature_row and feature_row[1] is not None else None,
            "missing": missing,
            "historical_memory": HistoricalMemoryService().history_status(),
            "adaptive_weights": self._adaptive_weight_status(),
            "policy": {
                "min_candles_for_forecast": self.policy.min_candles_for_forecast,
                "ideal_candles_for_features": self.policy.ideal_candles_for_features,
                "max_latest_candle_age_hours": self.policy.max_latest_candle_age_hours,
            },
        }


    def data_integrity(self, record_state: bool = True) -> dict:
        """Fast integrity snapshot used by dashboard/status.

        This catches the dangerous class of bugs where the latest ticker and the
        latest stored candle disagree heavily, or where the latest candle is old.
        It is deliberately read-only except for sync_state, so it can be called
        often without disturbing sync.
        """
        ready = self.readiness()
        candle = ready.get("latest_candle_close")
        ticker = ready.get("ticker_price")
        price_delta_pct = None
        if candle and ticker:
            price_delta_pct = abs((float(candle) / float(ticker) - 1.0) * 100.0)
        now_ms = int(utc_now().timestamp() * 1000)
        ticker_age_h = ((now_ms - int(ready["ticker_ts"])) / 3600000.0) if ready.get("ticker_ts") else None
        status = "ok"
        warnings = []
        if ready.get("latest_candle_age_hours") is not None and ready["latest_candle_age_hours"] > self.policy.max_latest_candle_age_hours:
            status = "warning"
            warnings.append(f"latest candle age {ready['latest_candle_age_hours']:.1f}h")
        if ticker_age_h is not None and ticker_age_h > 2.0:
            status = "warning"
            warnings.append(f"ticker age {ticker_age_h:.1f}h")
        if price_delta_pct is not None and price_delta_pct > 5.0:
            status = "warning"
            warnings.append(f"ticker/candle delta {price_delta_pct:.2f}%")
        if record_state:
            if status == "warning":
                self._state("data_integrity", "warning: " + "; ".join(warnings))
            else:
                self._state("data_integrity", "ok")
        return {
            "status": status,
            "warnings": warnings,
            "latest_candle_close": candle,
            "latest_candle_ts": ready.get("max_candle_ts"),
            "latest_candle_age_hours": ready.get("latest_candle_age_hours"),
            "ticker_price": ticker,
            "ticker_ts": ready.get("ticker_ts"),
            "ticker_age_hours": ticker_age_h,
            "price_delta_pct": price_delta_pct,
            "ready_for_forecast": ready.get("ready_for_forecast"),
            "candle_count": ready.get("candle_count"),
        }

    def _adaptive_weight_status(self) -> dict:
        try:
            row = db.fetchone("SELECT COUNT(*), AVG(weight), MAX(sample), MAX(updated_at) FROM adaptive_feature_weights")
            out = {"dimensions": int(row[0] or 0) if row else 0, "avg_weight": float(row[1] or 0) if row and row[1] is not None else None, "max_sample": int(row[2] or 0) if row and row[2] is not None else 0, "updated_at": row[3] if row and row[3] is not None else None}
            try:
                import json
                from pathlib import Path
                path = settings.base_dir / 'logs' / 'adaptive_feature_weights.json'
                if path.exists():
                    payload = json.loads(path.read_text(encoding='utf-8'))
                    out.update({"active": bool(payload.get('active')), "rows_used": int(payload.get('rows_used') or 0), "active_dimensions": payload.get('active_dimensions') or [], "message": payload.get('message')})
            except Exception:
                pass
            return out
        except Exception:
            return {"dimensions": 0, "active": False}

    async def bootstrap_visible_data(self) -> dict:
        """Fast first phase: make price/chart possible. No heavy providers."""
        self._state("data_pipeline", "phase_1_visible_data")
        self._state("sync_phase", "phase_1_visible_data")
        self._event("phase_start", phase="visible_data")
        result = await self.sync.sync_minimal_live()
        # V10.14.3: the State Vector Engine may not start with feature_count=0.
        # Build the OHLC-derived feature warehouse immediately after candles are
        # available. This is a background/startup phase, not a Time Machine click.
        feature_rows = 0
        try:
            feature_rows = FeatureEngine().rebuild()
            self._event("features_rebuilt_after_visible_data_v10143", rows=feature_rows)
        except Exception as exc:
            self._event("features_rebuild_visible_failed_v10143", error=str(exc))
        ready = self.readiness()
        integrity = self.data_integrity()
        ready["feature_rebuild_rows"] = feature_rows
        self._state("data_readiness", "ready" if ready["ready_for_forecast"] else "not_ready: " + ", ".join(ready["missing"]))
        self._event("phase_done", phase="visible_data", ready=ready)
        write_json("last_data_readiness.json", ready)
        return {"phase": "visible_data", "sync": result, "readiness": ready, "integrity": integrity}

    async def run_forecast_pipeline(self, source: str = "manual") -> dict:
        """Critical data -> readiness gate -> audit -> forecast.

        This is the only flow that Sync + Forecast and startup auto-sync should
        use. That makes future scaling simple: add phases here, not scattered in
        JS/routes/main.
        """
        self._state("manual_sync_status" if source == "manual" else "startup_sync_status", "running")
        self._state("data_pipeline", f"{source}:critical")
        self._event("pipeline_start", source=source)

        visible = await self.bootstrap_visible_data()
        ready = visible["readiness"]
        if not ready["ready_for_forecast"]:
            reason = "Minimum data ontbreekt: " + ", ".join(ready["missing"])
            self._state("data_pipeline", f"{source}:not_ready")
            self._state("manual_sync_status" if source == "manual" else "startup_sync_status", "not_ready")
            self._event("pipeline_not_ready", source=source, reason=reason, ready=ready)
            return {"created": False, "reason": reason, "sync": visible["sync"], "readiness": ready}

        self._state("sync_phase", "phase_2_audit_and_forecast")
        self._state("data_pipeline", f"{source}:forecast")
        AuditService().audit_due_predictions()
        created = ForecastService().create_run()
        ready_after = self.readiness()
        self._state("manual_sync_status" if source == "manual" else "startup_sync_status", "completed")
        self._state("sync_phase", "idle")
        self._state("data_pipeline", f"{source}:completed")
        try:
            HistoricalMemoryService().adaptive_weights()
        except Exception as exc:
            self._event("adaptive_weights_refresh_failed", error=str(exc))
        self._event("pipeline_done", source=source, created=created, ready=ready_after)
        return {"created": bool(created.get("created")), "run_id": created.get("run_id"), "reason": created.get("reason"), "forecast": created, "sync": visible["sync"], "readiness": ready_after}


    async def delayed_background_evidence(self, delay_seconds: float = 75.0) -> dict:
        """Start optional evidence after the UI has been idle for a while.

        This exists so startup can stay responsive.  The expensive futures/feature
        rebuild phase is useful, but it must not steal the DuckDB lock while the
        user is opening Time Machine or dragging the chart.
        """
        await asyncio.sleep(max(5.0, float(delay_seconds)))
        return await self.sync_important_background()

    async def sync_important_background(self) -> dict:
        """Phase 3: important-but-noncritical evidence with hard caps.

        This is safe to start after the first forecast. It improves data
        completeness over time but cannot make the dashboard empty.
        """
        self._state("sync_phase", "phase_3_important_evidence")
        self._state("data_pipeline", "background:important_evidence")
        self._event("phase_start", phase="important_evidence")
        tasks = [
            self.sync._safe_call("coingecko", self.sync.sync_coingecko_price_metric(), 5.0, True),
            self.sync._safe_call("alternative_me", self.sync.sync_fear_greed(), 3.0, True),
            self.sync._safe_call("binance_futures", self.sync.sync_binance_futures_layer(), 8.0, True),
        ]
        raw = await asyncio.gather(*tasks)
        results = [self.sync._log_result(r) for r in raw]
        rebuilt = 0
        try:
            rebuilt = FeatureEngine().rebuild()
            self._event("features_rebuilt_after_background", rows=rebuilt)
        except Exception as exc:
            log.warning("Background feature rebuild failed: %s", exc)
        integrity = self.data_integrity()
        self._state("sync_phase", "idle")
        self._state("data_pipeline", "background:idle")
        self._event("phase_done", phase="important_evidence", results=results)
        return {"phase": "important_evidence", "results": results, "features_rebuilt": rebuilt, "readiness": self.readiness(), "integrity": integrity}


    async def sync_historical_memory_background(self) -> dict:
        self._state("sync_phase", "phase_4_historical_memory")
        self._state("data_pipeline", "background:historical_memory")
        self._event("phase_start", phase="historical_memory_daemon")
        result = await HistoricalMemoryService().ensure_eight_year_history_daemon()
        self._state("sync_phase", "idle")
        self._state("data_pipeline", "background:idle")
        self._event("phase_done", phase="historical_memory_daemon", result=result)
        return result
