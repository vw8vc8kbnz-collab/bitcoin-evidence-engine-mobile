from __future__ import annotations
from datetime import datetime, timezone
import json
import asyncio
from app.db.database import db
from app.core.config import settings
from app.core.time_utils import utc_now, interval_ms
from app.providers.binance import BinanceProvider
from app.providers.fear_greed import FearGreedProvider
from app.providers.coingecko import CoinGeckoProvider
from app.providers.coinmetrics import CoinMetricsProvider
from app.providers.binance_futures import BinanceFuturesProvider
from app.providers.composite_orderbook import CompositeOrderBookProvider
from app.services.health_service import HealthService
from app.core.logger import log
from app.core.debug import append_jsonl, write_json

class SyncService:
    def __init__(self):
        self.health = HealthService()
        self.binance = BinanceProvider()
        self.fear_greed = FearGreedProvider()
        self.coingecko = CoinGeckoProvider()
        self.coinmetrics = CoinMetricsProvider()
        self.futures = BinanceFuturesProvider()
        self.composite_orderbook = CompositeOrderBookProvider()
        try:
            from app.providers.coinbase import CoinbaseProvider
            self.coinbase = CoinbaseProvider()
        except Exception:
            self.coinbase = None

    def _log_result(self, result: dict) -> dict:
        source = result.get("source", "unknown")
        status = result.get("status", "?")
        rows = result.get("rows", 0)
        detail = {k:v for k,v in result.items() if k not in ("source","status","rows","error")}
        if status == "ok":
            log.info("SYNC OK source=%s rows=%s detail=%s", source, rows, detail)
        else:
            log.warning("SYNC %s source=%s rows=%s error=%s detail=%s", status.upper(), source, rows, result.get("error"), detail)
        append_jsonl('sync_audit.jsonl', {"event":"sync_result", "source":source, "status":status, "rows":rows, "error":result.get("error"), "detail":detail})
        try:
            write_json('last_data_health_snapshot.json', {"providers": self.health.list()})
        except Exception:
            pass
        return result


    async def sync_minimal_live(self) -> dict:
        """Ultra-safe startup sync for the visible dashboard.

        This path intentionally fetches only the minimum data needed to make the
        app useful immediately: recent Binance 1h candles, Binance ticker, and a
        small optional spot consensus. It does not call futures/orderbook/flow
        providers, because those optional layers can be slow or blocked and must
        never keep the UI empty. Manual Sync + Forecast can still run the broader
        sync later.
        """
        log.info("Minimal live sync phase: candles_and_ticker_only")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'minimal_live_candles', utc_now()])
        results = []
        # Run critical calls sequentially so we know exactly where a failure happens.
        r = await self._safe_call('binance_recent', self.sync_binance_candles(), 10.0, False)
        results.append(self._log_result(r))
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'minimal_live_ticker', utc_now()])
        for name, coro, timeout in [
            ('binance_ticker', self.sync_binance_ticker(), 5.0),
            ('kraken_ticker', self.sync_kraken_ticker_metric(), 4.0),
            ('coinbase_ticker', self.sync_coinbase_ticker_metric(), 4.0),
        ]:
            r = await self._safe_call(name, coro, timeout, True)
            results.append(self._log_result(r))
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'minimal_live_spot_composite', utc_now()])
        r = await self._safe_call('spot_composite', self.sync_spot_composite_metrics(), 4.0, True)
        results.append(self._log_result(r))
        # Mark heavy layers as deferred, not failed.
        for src in ['coingecko','alternative_me','binance_futures','binance_orderbook','composite_orderbook','binance_spot_flow','binance_futures_flow']:
            self.health.skipped(src, 'deferred during startup minimal sync for fast visible data', {})
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'minimal_live_done', utc_now()])
        write_json('last_minimal_live_sync_results.json', {"mode": "minimal_live", "results": results})
        return {"results": results, "mode": "minimal_live"}

    async def sync_all(self) -> dict:
        # V6.4 priority order: first make the dashboard useful NOW, then continue
        # the heavy historical Time Machine backfill. This prevents the app from
        # looking empty while old 2017 data is still downloading.
        log.info("Sync phase: recent_market_data")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'recent_market_data', utc_now()])
        results=[]
        results.append(self._log_result(await self.sync_binance_candles()))
        results.append(self._log_result(await self.sync_binance_ticker()))
        results.append(self._log_result(await self.sync_kraken_ticker_metric()))
        results.append(self._log_result(await self.sync_coinbase_ticker_metric()))
        results.append(self._log_result(await self.sync_spot_composite_metrics()))
        results.append(self._log_result(await self.sync_fear_greed()))
        results.append(self._log_result(await self.sync_coingecko_price_metric()))

        log.info("Sync phase: orderflow_futures_onchain")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'orderflow_futures_onchain', utc_now()])
        results.append(self._log_result(await self.sync_composite_orderbooks()))
        results.append(self._log_result(await self.sync_binance_orderbook_snapshot()))
        results.append(self._log_result(await self.sync_binance_futures_layer()))
        results.append(self._log_result(await self.sync_binance_spot_tradeflow()))
        results.append(self._log_result(await self.sync_binance_futures_tradeflow()))
        results.append(self._log_result(await self.sync_coinmetrics_metrics()))

        log.info("Sync phase: historical_backfill")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'historical_backfill', utc_now()])
        results.append(self._log_result(await self.sync_binance_deep_history()))
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'idle', utc_now()])
        log.info("Sync phase: idle")
        return {"results": results}

    async def _safe_call(self, name: str, coro, timeout: float = 5.0, optional: bool = False):
        try:
            return await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError:
            msg = f"{'optional/' if optional else ''}provider timed out after {timeout}s"
            if optional:
                self.health.skipped(name, msg, {})
                return {"source": name, "status": "skipped", "rows": 0, "warning": "timeout"}
            self.health.error(name, TimeoutError(msg))
            return {"source": name, "status": "error", "rows": 0, "error": msg}
        except Exception as exc:
            if optional:
                self.health.skipped(name, f"optional provider unavailable: {exc}", {})
                return {"source": name, "status": "skipped", "rows": 0, "warning": str(exc)}
            self.health.error(name, exc)
            return {"source": name, "status": "error", "rows": 0, "error": str(exc)}

    async def sync_startup_fast(self) -> dict:
        """V10.2 startup path: only critical sources, no slow optional orderbook/flow.

        Goal: the app must fill the dashboard quickly and reliably. Optional
        providers are allowed to be skipped/deferred instead of making the first
        screen look frozen or empty. Manual Sync + Forecast can still collect
        more evidence.
        """
        log.info("Startup stability sync phase: critical_market_data")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'startup_critical_market', utc_now()])
        tasks = [
            self._safe_call('binance_recent', self.sync_binance_candles(), 7.0, False),
            self._safe_call('kraken_ticker', self.sync_kraken_ticker_metric(), 4.0, True),
            self._safe_call('coinbase_ticker', self.sync_coinbase_ticker_metric(), 4.0, True),
            self._safe_call('coingecko', self.sync_coingecko_price_metric(), 5.0, True),
            self._safe_call('binance_futures', self.sync_binance_futures_layer(), 8.0, True),
        ]
        raw_results = await asyncio.gather(*tasks)
        raw_results.append(await self._safe_call('spot_composite', self.sync_spot_composite_metrics(), 3.0, True))
        # Mark intentionally deferred sources so Data Health is honest, but not alarming.
        for src in ['alternative_me','binance_ticker','binance_orderbook','composite_orderbook','binance_spot_flow','binance_futures_flow']:
            self.health.skipped(src, 'deferred during startup for stable app launch', {})
            raw_results.append({"source": src, "status": "skipped", "rows": 0, "warning": "deferred_startup"})
        results=[self._log_result(r) for r in raw_results]
        write_json('last_fast_sync_results.json', {"mode": "startup_fast", "results": results})
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'idle', utc_now()])
        return {"results": results}

    async def sync_forecast_fast(self) -> dict:
        """V10.2 manual fast path.

        Critical data is fetched first and optional slow providers are capped hard.
        This keeps Sync + Forecast reliable: a slow orderbook/flow provider must
        never leave the dashboard empty or block forecast creation.
        """
        log.info("Fast sync phase: critical_then_optional_capped")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'critical_market_data', utc_now()])

        critical = [
            self._safe_call('binance_recent', self.sync_binance_candles(), 7.0, False),
            self._safe_call('binance_ticker', self.sync_binance_ticker(), 3.0, True),
            self._safe_call('kraken_ticker', self.sync_kraken_ticker_metric(), 4.0, True),
            self._safe_call('coinbase_ticker', self.sync_coinbase_ticker_metric(), 4.0, True),
            self._safe_call('coingecko', self.sync_coingecko_price_metric(), 5.0, True),
            self._safe_call('binance_futures', self.sync_binance_futures_layer(), 8.0, True),
        ]
        raw_results = await asyncio.gather(*critical)
        raw_results.append(await self._safe_call('spot_composite', self.sync_spot_composite_metrics(), 3.0, True))

        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'optional_evidence_capped', utc_now()])
        optional = [
            self._safe_call('alternative_me', self.sync_fear_greed(), 2.5, True),
            self._safe_call('binance_orderbook', self.sync_binance_orderbook_snapshot(), 2.5, True),
            self._safe_call('composite_orderbook', self.sync_composite_orderbooks(), 3.5, True),
            self._safe_call('binance_spot_flow', self.sync_binance_spot_tradeflow(), 2.5, True),
            self._safe_call('binance_futures_flow', self.sync_binance_futures_tradeflow(), 2.5, True),
        ]
        raw_results.extend(await asyncio.gather(*optional))
        results=[self._log_result(r) for r in raw_results]
        write_json('last_fast_sync_results.json', {"mode": "manual_fast", "results": results})
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'idle', utc_now()])
        return {"results": results}


    async def _store_flow_snapshot(self, source: str, flow: dict) -> dict:
        ts = int(flow.get('timestamp_ms') or int(utc_now().timestamp()*1000))
        rows = [
            (source, 'buy_notional_recent', ts, float(flow.get('buy_notional') or 0), json.dumps({'trade_count': flow.get('trade_count')}), utc_now()),
            (source, 'sell_notional_recent', ts, float(flow.get('sell_notional') or 0), json.dumps({'trade_count': flow.get('trade_count')}), utc_now()),
            (source, 'trade_delta_ratio_recent', ts, float(flow.get('delta_ratio') or 0), json.dumps({'method': 'aggTrades buyer-maker proxy'}), utc_now()),
            (source, 'buy_sell_ratio_recent', ts, float(flow.get('buy_sell_ratio') or 0), json.dumps({'method': 'aggTrades buyer-maker proxy'}), utc_now()),
            (source, 'large_buy_notional_recent', ts, float(flow.get('large_buy_notional') or 0), json.dumps({'threshold': 'spot 250k / futures 500k'}), utc_now()),
            (source, 'large_sell_notional_recent', ts, float(flow.get('large_sell_notional') or 0), json.dumps({'threshold': 'spot 250k / futures 500k'}), utc_now()),
            (source, 'large_trade_imbalance_recent', ts, float(flow.get('large_trade_imbalance') or 0), json.dumps({'method': 'large aggTrade imbalance'}), utc_now()),
            (source, 'largest_trade_notional_recent', ts, float(flow.get('largest_trade_notional') or 0), json.dumps({}), utc_now()),
        ]
        db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
        self.health.success(source, len(rows), {'delta_ratio': flow.get('delta_ratio'), 'large_imbalance': flow.get('large_trade_imbalance'), 'trade_count': flow.get('trade_count')})
        return {"source": source, "status": "ok", "rows": len(rows), "delta_ratio": flow.get('delta_ratio'), "large_imbalance": flow.get('large_trade_imbalance')}

    async def sync_binance_spot_tradeflow(self) -> dict:
        source = 'binance_spot_flow'
        try:
            flow = await self.binance.fetch_recent_agg_trade_flow(settings.symbol, limit=1000)
            return await self._store_flow_snapshot(source, flow)
        except Exception as e:
            self.health.skipped(source, f"optional spot flow unavailable: {e}", {})
            return {"source": source, "status": "skipped", "rows": 0, "warning": str(e)}

    async def sync_binance_futures_tradeflow(self) -> dict:
        source = 'binance_futures_flow'
        try:
            flow = await self.futures.fetch_recent_agg_trade_flow(settings.futures_symbol, limit=1000)
            return await self._store_flow_snapshot(source, flow)
        except Exception as e:
            self.health.skipped(source, f"optional futures flow unavailable: {e}", {})
            return {"source": source, "status": "skipped", "rows": 0, "warning": str(e)}

    async def sync_kraken_ticker_metric(self) -> dict:
        source='kraken_ticker'
        try:
            from app.providers.kraken import KrakenProvider
            x = await KrakenProvider().fetch_btc_usd_ticker()
            ts = int(utc_now().timestamp()*1000)
            rows=[
                (source, 'btc_last_price', ts, float(x.get('price') or 0), json.dumps({'pair':'XBTUSD','volume':x.get('volume')}), utc_now()),
                (source, 'btc_24h_volume', ts, float(x.get('volume') or 0), json.dumps({'pair':'XBTUSD'}), utc_now()),
            ]
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'price': x.get('price')})
            return {"source":source,"status":"ok","rows":len(rows),"price":x.get('price')}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_coinbase_ticker_metric(self) -> dict:
        source='coinbase_ticker'
        try:
            from app.providers.coinbase import CoinbaseProvider
            x = await CoinbaseProvider().fetch_btc_usd_ticker()
            ts = int(utc_now().timestamp()*1000)
            rows=[
                (source, 'btc_last_price', ts, float(x.get('price') or 0), json.dumps({'pair':'BTC-USD','volume':x.get('volume'), 'trade_id':x.get('trade_id')}), utc_now()),
                (source, 'btc_24h_volume', ts, float(x.get('volume') or 0), json.dumps({'pair':'BTC-USD'}), utc_now()),
            ]
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'price': x.get('price')})
            return {"source":source,"status":"ok","rows":len(rows),"price":x.get('price')}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}



    async def sync_spot_composite_metrics(self) -> dict:
        """Composite spot consensus from Binance, Kraken and Coinbase.

        This does not show separate exchange forecasts to the user; it stores a
        single data-quality/evidence layer: cross-exchange spread and spot
        premiums. A wide spread means lower confidence; Kraken/Coinbase premium
        versus Binance can indicate real spot demand or local liquidity stress.
        """
        source = 'spot_composite'
        try:
            now = utc_now()
            ts = int(now.timestamp()*1000)
            def latest(src):
                r = db.fetchone("""
                    SELECT value FROM raw_metric_points
                    WHERE source=? AND metric='btc_last_price'
                    ORDER BY timestamp_ms DESC LIMIT 1
                """, [src])
                return float(r[0]) if r and r[0] is not None else None
            b = latest('binance_ticker')
            k = latest('kraken_ticker')
            c = latest('coinbase_ticker')
            prices = [x for x in (b,k,c) if x and x > 0]
            if len(prices) < 2:
                self.health.skipped(source, 'need at least two spot sources', {'binance': b, 'kraken': k, 'coinbase': c})
                return {"source": source, "status": "skipped", "rows": 0, "warning": "need at least two spot sources"}
            mid = sum(prices) / len(prices)
            spread_pct = ((max(prices) - min(prices)) / mid) * 100 if mid else 0.0
            kraken_premium = ((k / b - 1) * 100) if b and k else None
            coinbase_premium = ((c / b - 1) * 100) if b and c else None
            rows = [
                (source, 'spot_consensus_price', ts, mid, json.dumps({'binance': b, 'kraken': k, 'coinbase': c}), now),
                (source, 'cross_exchange_spread_pct', ts, spread_pct, json.dumps({'prices': prices}), now),
            ]
            if kraken_premium is not None:
                rows.append((source, 'spot_premium_kraken_pct', ts, kraken_premium, json.dumps({'vs':'binance'}), now))
            if coinbase_premium is not None:
                rows.append((source, 'spot_premium_coinbase_pct', ts, coinbase_premium, json.dumps({'vs':'binance'}), now))
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'spread_pct': spread_pct, 'sources': len(prices)})
            return {"source": source, "status": "ok", "rows": len(rows), "spread_pct": spread_pct, "sources": len(prices)}
        except Exception as e:
            self.health.error(source, e)
            return {"source": source, "status": "error", "error": str(e)}

    async def sync_binance_ticker(self) -> dict:
        """Fast live ticker used by the top BTC price card.

        Candles/history can be delayed during deep backfill. This metric gives
        the dashboard a current price as soon as the API responds.
        """
        source='binance_ticker'
        try:
            x = await self.binance.fetch_ticker(settings.symbol)
            ts = int(utc_now().timestamp()*1000)
            rows = [
                (source, 'btc_last_price', ts, float(x.get('price') or 0), json.dumps({'symbol':settings.symbol, 'change_pct': x.get('change_pct'), 'volume': x.get('volume')}), utc_now()),
                (source, 'btc_24h_change_pct', ts, float(x.get('change_pct') or 0), json.dumps({'symbol':settings.symbol}), utc_now()),
                (source, 'btc_24h_volume', ts, float(x.get('volume') or 0), json.dumps({'symbol':settings.symbol}), utc_now()),
            ]
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'price': x.get('price'), 'change_pct': x.get('change_pct')})
            return {"source":source,"status":"ok","rows":len(rows),"price":x.get('price')}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_binance_deep_history(self) -> dict:
        """Backfill older hourly BTC candles backwards from the earliest stored candle.

        V10.15.1 Auto Historical Memory hardening:
        - Uses longer timeouts for 1000-candle historical chunks than for live UI calls.
        - Retries transient Binance/network failures per chunk instead of ending the daemon pass.
        - Records exact start/end window and local min/max so stalls are visible in Data Health/logs.
        - Keeps paging backwards from MIN(open_time), because the recent/live sync owns the newest candles.
        """
        source='binance_history_1h'
        try:
            first = db.fetchone("SELECT MIN(open_time) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
            total = 0
            chunks = 0
            now=utc_now()
            end_ms = int(first[0]) - 1 if first and first[0] else int(utc_now().timestamp()*1000)
            requested_start_end = end_ms
            last_error = None
            while chunks < int(settings.backfill_max_chunks_per_sync) and end_ms > int(settings.historical_start_ms):
                rows = None
                for attempt in range(1, int(settings.binance_backfill_retries) + 1):
                    try:
                        rows = await self.binance.fetch_klines(
                            settings.symbol,
                            '1h',
                            None,
                            int(settings.backfill_chunk_limit),
                            end_ms=end_ms,
                            timeout_seconds=float(settings.binance_backfill_timeout_seconds),
                        )
                        last_error = None
                        break
                    except Exception as exc:
                        last_error = str(exc)
                        append_jsonl('sync_audit.jsonl', {
                            'event': 'binance_history_retry_v10150',
                            'attempt': attempt,
                            'max_attempts': int(settings.binance_backfill_retries),
                            'end_ms': end_ms,
                            'error': last_error,
                        })
                        if attempt < int(settings.binance_backfill_retries):
                            await asyncio.sleep(float(settings.binance_backfill_retry_pause_seconds) * attempt)
                if rows is None:
                    raise RuntimeError(f"Binance historical backfill failed after retries at end_ms={end_ms}: {last_error}")

                # Binance can return a partly older-than-target chunk near the start.
                # Keep only the configured 8Y window but still consider this a normal terminal condition.
                rows = sorted([r for r in rows if int(r['open_time']) >= int(settings.historical_start_ms)], key=lambda r: int(r['open_time']))
                if not rows:
                    break
                payload=[(r['source'],r['symbol'],r['interval'],r['open_time'],r['close_time'],r['open'],r['high'],r['low'],r['close'],r['volume'],r['quote_volume'],r['trades'],now) for r in rows]
                db.executemany("""
                    INSERT OR REPLACE INTO raw_candles VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, payload)
                total += len(payload)
                chunks += 1
                oldest = min(int(r['open_time']) for r in rows)
                newest = max(int(r['open_time']) for r in rows)
                append_jsonl('sync_audit.jsonl', {
                    'event': 'binance_history_chunk_v10150',
                    'rows': len(payload),
                    'oldest': oldest,
                    'newest': newest,
                    'next_end_ms': oldest - 1,
                })
                new_end = oldest - 1
                if new_end >= end_ms:
                    break
                end_ms = new_end
                if len(rows) < int(settings.backfill_chunk_limit):
                    break
            rng = db.fetchone("SELECT MIN(open_time), MAX(open_time), COUNT(*) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
            detail = {
                "symbol": settings.symbol,
                "interval":"1h",
                "chunks": chunks,
                "stored_rows": int(rng[2] or 0) if rng else 0,
                "min_open_time": int(rng[0]) if rng and rng[0] is not None else None,
                "max_open_time": int(rng[1]) if rng and rng[1] is not None else None,
                "requested_start_end_ms": requested_start_end,
                "next_end_ms": end_ms,
            }
            self.health.success(source, total, detail)
            return {"source":source,"status":"ok","rows":total,"chunks":chunks, **detail}
        except Exception as e:
            self.health.error(source, e)
            append_jsonl('sync_audit.jsonl', {'event':'binance_history_error_v10150', 'error':str(e)})
            return {"source":source,"status":"error","rows":0,"chunks":0,"error":str(e)}

    async def sync_binance_candles(self) -> dict:
        """Always fetch the most recent candles.

        Deep backfill can take multiple app starts to fill 2017→now. If this
        function continued from the current MAX(open_time), the dashboard could
        show an old historical candle until the full backfill completed. For the
        live dashboard/forecast we always insert the latest public Binance window.
        The historical backfill remains responsible for filling older gaps.
        """
        source='binance_recent'
        try:
            rows = await self.binance.fetch_klines(settings.symbol, '1h', None, settings.bootstrap_candles_limit)
            now=utc_now()
            payload=[(r['source'],r['symbol'],r['interval'],r['open_time'],r['close_time'],r['open'],r['high'],r['low'],r['close'],r['volume'],r['quote_volume'],r['trades'],now) for r in rows]
            if payload:
                db.executemany("""
                    INSERT OR REPLACE INTO raw_candles VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, payload)
            self.health.success(source, len(payload), {"symbol": settings.symbol, "interval":"1h"})
            return {"source":source,"status":"ok","rows":len(payload)}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_fear_greed(self) -> dict:
        source='alternative_me'
        try:
            x = await self.fear_greed.fetch_latest()
            if not x:
                self.health.success(source, 0, {"empty": True})
                return {"source":source,"status":"empty","rows":0}
            db.execute("""
                INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)
            """, [source, 'fear_greed', x['timestamp_ms'], x['value'], json.dumps({"classification": x.get('classification')}), utc_now()])
            self.health.success(source, 1, {"classification": x.get('classification')})
            return {"source":source,"status":"ok","rows":1}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_coingecko_price_metric(self) -> dict:
        source='coingecko'
        try:
            rows = await self.coingecko.fetch_market_chart(days=30)
            payload=[(source, 'btc_price_usd', r['timestamp_ms'], r['value'], json.dumps({}), utc_now()) for r in rows]
            if payload:
                db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
            self.health.success(source, len(payload), {"metric":"btc_price_usd"})
            return {"source":source,"status":"ok","rows":len(payload)}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}




    async def sync_composite_orderbooks(self) -> dict:
        source='composite_orderbook'
        try:
            x = await self.composite_orderbook.fetch_all()
            if x.get('status') != 'ok':
                raise RuntimeError('; '.join([e.get('exchange','?')+': '+e.get('error','') for e in x.get('errors', [])]) or 'no orderbook sources returned')
            ts = int(utc_now().timestamp()*1000)
            rows = [
                (source, 'orderbook_imbalance', ts, float(x.get('composite_imbalance') or 0.5), json.dumps(x), utc_now()),
                (source, 'orderbook_spread', ts, float(x.get('composite_spread') or 0), json.dumps({'exchange_count':x.get('exchange_count')}), utc_now()),
                (source, 'orderbook_exchange_count', ts, float(x.get('exchange_count') or 0), json.dumps({'errors':x.get('errors', [])}), utc_now()),
                (source, 'orderbook_bid_notional_1pct', ts, float(x.get('bid_notional_1pct') or 0), json.dumps({'unit':'USD notional'}), utc_now()),
                (source, 'orderbook_ask_notional_1pct', ts, float(x.get('ask_notional_1pct') or 0), json.dumps({'unit':'USD notional'}), utc_now()),
            ]
            for key, band in (x.get('bands') or {}).items():
                clean = key.replace('.', '_')
                rows.append((source, f'orderbook_imbalance_{clean}', ts, float(band.get('imbalance') or 0.5), json.dumps(band), utc_now()))
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'exchange_count': x.get('exchange_count'), 'warnings': x.get('errors', [])[:3], 'imbalance': x.get('composite_imbalance')})
            return {"source":source,"status":"ok","rows":len(rows),"exchange_count":x.get('exchange_count'),"warnings":x.get('errors', [])[:3]}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_binance_orderbook_snapshot(self) -> dict:
        source='binance_orderbook'
        try:
            x = await self.binance.fetch_orderbook(settings.symbol, limit=500)
            ts = int(utc_now().timestamp()*1000)
            rows = [
                ('binance', 'orderbook_imbalance', ts, float(x.get('imbalance') or 0.5), json.dumps({'limit':500}), utc_now()),
                ('binance', 'orderbook_spread', ts, float(x.get('spread') or 0), json.dumps({'bid_notional':x.get('bid_notional'), 'ask_notional':x.get('ask_notional')}), utc_now()),
            ]
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'imbalance': x.get('imbalance'), 'spread': x.get('spread')})
            return {"source":source,"status":"ok","rows":len(rows)}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_binance_futures_layer(self) -> dict:
        source='binance_futures'
        total = 0
        detail = {}
        errors = []
        def store_rows(name: str, rows: list[dict]):
            nonlocal total
            payload=[(source, r['metric'], int(r['timestamp_ms']), float(r['value']), json.dumps({'feed': name}), utc_now()) for r in (rows or []) if r.get('value') is not None]
            if payload:
                db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
            total += len(payload)
            detail[name] = len(payload)

        async def call(name, coro):
            try:
                rows = await coro
                return name, rows, None
            except Exception as e:
                return name, [], str(e)

        try:
            last_funding = db.fetchone("SELECT MAX(timestamp_ms) FROM raw_metric_points WHERE source=? AND metric='funding_rate'", [source])
            start_ms = int(last_funding[0]) + 1 if last_funding and last_funding[0] else None
            import asyncio
            tasks = [
                call('funding_rate', self.futures.fetch_funding_rate(settings.futures_symbol, start_ms=start_ms, limit=1000)),
                call('open_interest', self.futures.fetch_open_interest_hist(settings.futures_symbol, period='1h', limit=500)),
                call('long_short', self.futures.fetch_global_long_short_ratio(settings.futures_symbol, period='1h', limit=500)),
                call('taker_ratio', self.futures.fetch_taker_long_short_ratio(settings.futures_symbol, period='1h', limit=500)),
                call('premium_index', self.futures.fetch_premium_index(settings.futures_symbol)),
                call('current_open_interest', self.futures.fetch_open_interest_current(settings.futures_symbol)),
                call('top_position_ratio', self.futures.fetch_top_long_short_position_ratio(settings.futures_symbol, period='1h', limit=500)),
                call('top_account_ratio', self.futures.fetch_top_long_short_account_ratio(settings.futures_symbol, period='1h', limit=500)),
            ]
            for name, rows, err in await asyncio.gather(*tasks):
                if err:
                    errors.append(f'{name}: {err}')
                    detail[name] = 0
                else:
                    store_rows(name, rows)
            detail['liquidations_recent'] = 'skipped_optional'
        except Exception as e:
            errors.append(f'futures_layer: {e}')

        if total > 0:
            self.health.success(source, total, {**detail, 'warnings': errors[:6]})
            return {"source":source,"status":"ok","rows":total,"detail":detail,"warnings":errors[:6]}
        err = '; '.join(errors) if errors else 'no futures rows'
        self.health.skipped(source, f"optional futures layer unavailable: {err}", detail)
        return {"source":source,"status":"skipped","rows":0,"warning":err,"detail":detail}

    async def sync_coinmetrics_metrics(self) -> dict:
        source='coinmetrics_community'
        metrics=['PriceUSD','CapMrktCurUSD','CapRealUSD','CapMVRVCur']
        try:
            rows = await self.coinmetrics.fetch_asset_metrics(metrics, days=365)
            payload=[(source, r['metric'], r['timestamp_ms'], r['value'], json.dumps({}), utc_now()) for r in rows]
            if payload:
                db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
            self.health.success(source, len(payload), {"metrics": metrics})
            return {"source":source,"status":"ok","rows":len(payload)}
        except Exception as e:
            # Current free/community access can be blocked depending on network/API policy.
            # Keep this explicit but non-fatal: the engine continues using price,
            # sentiment, orderbook and futures data. A paid/on-chain API key layer
            # can be added later without changing the feature engine.
            self.health.skipped(source, f"optional on-chain endpoint unavailable: {e}", {"metrics": metrics})
            return {"source":source,"status":"skipped","rows":0,"warning":str(e)}
