# FIX660R8 test report

Datum: 12 augustus 2026  
Build: `FIX660R8_PRELIVE_HARDENED`  
Resultaat bron-/artifactgate: PASS wanneer `tools/final_preflight.py --verify-checksums` zonder fouten eindigt.

## Uitgevoerde suites

| Gate | Bewijs | Verwacht |
|---|---|---|
| Python compile | alle `app/*.py` en `tools/*.py` in-memory | PASS |
| Bash syntax | deploy- en installerscript | PASS |
| JavaScript syntax | alle losse JS-assets plus inline Tool A/Admin scripts | PASS |
| Safety/golden | `tools/fix660r8_safety_tests.py` — 10 tests | PASS |
| Server lifecycle | `tools/fix660r8_server_lifecycle_tests.py` — 6 tests | PASS |
| Restore adversarial | `tools/fix660r8_restore_tests.py` — 3 tests | PASS |
| Functionele regressie | `tools/fix660_regression.py` | `FIX660 REGRESSION: PASS` |
| Releaseboom | exact intern SHA-256-manifest; geen symlink/pycache/pyc/bak | PASS |
| Runtimecontract/SBOM | Pythonbereik, imports, requirements en CycloneDX | PASS |

De volledige artifactpreflight is daarnaast op de doel-VPS onder Python 3.14.4
uitgevoerd. Alle inhoudelijke gates waren daar groen; de oorspronkelijke R8/R8A
stopte uitsluitend omdat het declaratieve runtimecontract nog `<3.14` vermeldde.
De gecorrigeerde revisie ondersteunt daarom expliciet Python `>=3.10,<3.15`.

## Kritieke uitkomsten die werkelijk worden getest

- positie 1/2/3 heeft de overeengekomen fysieke bottom-to-top volgorde;
- ARC-geometrie roteert in alle kwadranten;
- bboxmismatch publiceert nul sheet-DXF's;
- nonfinite en adversarial paneelvelden worden geweigerd;
- path traversal wordt geweigerd;
- machining-droppende fallback bestaat niet;
- de echte optimizer produceert één complete jobfamilie vanuit de publieke canonieke DTO;
- iedere finalization-hash wordt opnieuw gecontroleerd;
- een gemanipuleerde quote verdwijnt uit publieke status en maakt de jobfamilie ongeldig;
- Admin-manifestopbouw verandert geen byte en toont geen niet-verzegeld bestand;
- cancellation maakt bestaande artifacts niet downloadbaar;
- catalogusreviewhash verandert bij een gewijzigde warning;
- catalogusimage DNS wordt gepind en private IP's falen gesloten;
- imagecache-tampering wordt gedetecteerd;
- JSONL-rotatie behoudt het nieuwe event;
- een echte applicatiebackup wordt gemaakt, volledig geverifieerd en naar een nieuwe stateboom hersteld, inclusief idempotencymarker en catalogus;
- restore weigert hashmanipulatie, traversal, extra leden en een bestaand target;
- prijs-, material-, auth-, privacy-, Grain Studio-, mobiele UI-, catalogus- en installerregressies blijven groen.

## Testisolatie

Lifecycle- en restoretests gebruiken tijdelijke externe state en verwijderen die na afloop. Ze schrijven niet naar echte klant-, VPS- of Library-state. De lifecycle gebruikt wel een echte ingebedde METOD-DXF en de echte optimizer/finalizer.

## Niet door de artifactgate bewezen

De volgende evidence moet buiten dit pakket worden geleverd:

- echte VPS-installatie onder de gegenereerde systemd/Nginx-config;
- extern TLS-/HTTP-redirect- en firewallbewijs;
- load-, slow-client-, disk-full-, inode-full- en deploychaostest op representatieve hardware;
- versleutelde off-host overdracht en restore vanuit uitsluitend die kopie;
- acceptatie van de actuele live CSV-waarschuwingen door de materiaaleigenaar;
- echte iPhone/Safari-video en logs;
- onafhankelijke CAM-import, werkplaatscontrole en fysieke proefsnede.

Daarom is een groene artifactgate noodzakelijk, maar niet voldoende voor publiek productie-GO.
