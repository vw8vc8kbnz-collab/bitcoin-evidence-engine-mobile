import os, json, time, threading, sqlite3, math
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
import requests
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse

ROOT = Path('/home/ubuntu/stock-gem-engine') if Path('/home/ubuntu/stock-gem-engine').exists() else Path(__file__).resolve().parents[1]
DATA = ROOT/'data'; LOGS = ROOT/'logs'
DATA.mkdir(parents=True, exist_ok=True); LOGS.mkdir(parents=True, exist_ok=True)
load_dotenv(ROOT/'.env')
APP_VERSION = '1.3.0-real-data-audit-terminal-no-api'
PORT=int(os.getenv('APP_PORT','8791'))
NTFY_TOPIC=os.getenv('NTFY_TOPIC','Stijn-Tradifi-2026')
AUTO_SCAN_ENABLED=os.getenv('AUTO_SCAN_ENABLED','true').lower()=='true'
SCAN_INTERVAL_MINUTES=int(os.getenv('SCAN_INTERVAL_MINUTES','60'))
MCAP_LIVE_ENABLED=os.getenv('MCAP_LIVE_ENABLED','true').lower()=='true'
DB=DATA/'stock_gems.sqlite3'
app=FastAPI(title='Stijn-Tradifi-2026',version=APP_VERSION)
state={'running':False,'last_scan':None,'last_alerts':0,'last_error':None,'audit':{}}

SEED_UNIVERSE=[
# US/NASDAQ/NYSE micro/nano candidates
('PRZO','ParaZero Technologies','Drone safety / Defense','Israel/US','NASDAQ','https://parazero.com',38e6),('OPTT','Ocean Power Technologies','Marine energy / Defense','US','NYSE American','https://oceanpowertechnologies.com',34e6),('ASTI','Ascent Solar Technologies','Thin-film solar / Space','US','NASDAQ','https://ascentsolar.com',55e6),('KSCP','Knightscope','Security robotics','US','NASDAQ','https://www.knightscope.com',30e6),('MTEK','Maris-Tech','Defense video / Edge AI','Israel/US','NASDAQ','https://www.maris-tech.com',18e6),('CISO','CISO Global','Cybersecurity services','US','NASDAQ','https://www.ciso.inc',16e6),('DSS','DSS Inc.','Holding company / Packaging / Healthcare','US','NYSE American','https://www.dssworld.com',9e6),('MLGO','MicroAlgo','Algorithms / AI software','China/US','NASDAQ','https://www.microalgor.com',14e6),('HOLO','MicroCloud Hologram','Hologram / AI software','China/US','NASDAQ','https://www.mcholo.com',18e6),('WISA','WiSA Technologies','Wireless audio / Consumer tech','US','NASDAQ','https://www.wisatechnologies.com',8e6),('NUWE','Nuwellis','Medical devices','US','NASDAQ','https://www.nuwellis.com',6e6),('TIVC','Tivic Health','Medical devices / Bioelectronic medicine','US','NASDAQ','https://tivichealth.com',7e6),('EDBL','Edible Garden','Food / Controlled environment agriculture','US','NASDAQ','https://ediblegardenag.com',6e6),('FATH','Fathom Digital Manufacturing','Advanced manufacturing / 3D printing','US','NYSE','https://fathommfg.com',18e6),('DUOT','Duos Technologies','Rail AI / Machine vision','US','NASDAQ','https://www.duostech.com',35e6),('REKR','Rekor Systems','AI infrastructure / Public safety','US','NASDAQ','https://www.rekor.ai',180e6),('LIDR','AEye','LiDAR / Autonomy','US','NASDAQ','https://www.aeye.ai',45e6),('ONDS','Ondas Holdings','Autonomous drones / Networks','US','NASDAQ','https://www.ondas.com',92e6),('KULR','KULR Technology','Battery safety / Energy storage','US','NYSE American','https://www.kulrtechnology.com',410e6),('DPRO','Draganfly','Drones / Defense Tech','Canada/US','NASDAQ/CSE','https://draganfly.com',187e6),
# OTC / sub 20 research routes
('AITX','Artificial Intelligence Technology Solutions','Security robotics / AI','US','OTC','https://aitx.ai',22e6),('NEXI','NexImmune','Biotech / Immunotherapy','US','OTC','https://www.neximmune.com',5e6),('HYSR','SunHydrogen','Hydrogen research','US','OTC','https://www.sunhydrogen.com',75e6),
# Canada suffixes where Yahoo can query
('POND.V','Pond Technologies','Carbon capture / Algae biotech','Canada','TSXV','https://pondtech.com',8e6),('NEXE.V','NEXE Innovations','Sustainable packaging','Canada','TSXV','https://nexeinnovations.com',18e6),('PAID.CN','XTM Inc.','Fintech / Earned wage access','Canada','CSE','https://www.xtminc.com',7e6),('FLT.V','Volatus Aerospace','Drones / Aviation services','Canada','TSXV','https://volatusaerospace.com',25e6),('PNG.V','Kraken Robotics','Marine robotics / Defense','Canada','TSXV','https://krakenrobotics.com',290e6),
# UK / LSE/AIM suffixes
('FAB.L','Fusion Antibodies','Biotech tools / Antibodies','UK','AIM','https://www.fusionantibodies.com',9e6),('SAE.L','SIMEC Atlantis Energy','Tidal energy / Renewables','UK','AIM','https://saerenewables.com',18e6),('EQT.L','EQTEC','Waste-to-energy / Cleantech','Ireland/UK','AIM','https://eqtec.com',10e6),('N4P.L','N4 Pharma','Biotech / Drug delivery','UK','AIM','https://www.n4pharma.com',5e6),('BSFA.L','BSF Enterprise','Biotech / Cellular agriculture','UK','LSE','https://bsfenterprise.com',7e6),('ALK.L','Alkemy Capital Investments','Lithium refining / Battery materials','UK','LSE','https://alkemycapital.co.uk',18e6),('IKA.L','Ilika','Solid-state batteries','UK','AIM','https://www.ilika.com',45e6),('CPX.L','CAP-XX','Supercapacitors / Energy storage','Australia/UK','AIM','https://www.cap-xx.com',8e6),
# ASX / AU
('RDN.AX','Raiden Resources','Lithium / Gold exploration','Australia','ASX','https://raidenresources.com.au',16e6),('LRS.AX','Latin Resources','Lithium exploration','Australia','ASX','https://www.latinresources.com.au',190e6),('VUL.AX','Vulcan Energy','Lithium / Geothermal','Australia/Germany','ASX','https://v-er.eu',620e6),('IXR.AX','Ionic Rare Earths','Rare earths','Australia','ASX','https://ionicre.com.au',75e6),('EMH.AX','European Metals','Lithium / Battery metals','Australia/Europe','ASX','https://www.europeanmet.com',55e6),
# Europe suffixes
('ALNOV.PA','Novacyt','Diagnostics / Biotech','France/UK','Euronext Growth','https://novacyt.com',45e6),('ALERS.PA','Eurobio Scientific','Diagnostics','France','Euronext Growth','https://www.eurobio-scientific.com',160e6),
]
# A few extra real-ish ticker candidates; live Yahoo will decide whether they exist.
EXPLORATION_SYMBOLS=['AULT','BFRG','BTTR','CETX','CNEY','CRKN','CYCN','DATS','ELAB','GCTK','GNS','HUBC','INTZ','IVDA','JFBR','JTAI','LIPO','MOB','MULN','NCNA','NVOS','ONFO','PBM','PEGY','PIXY','POLA','RELI','RNAZ','SINT','SISI','SMX','SOBR','SONN','SPRC','TANH','TNON','TRNR','VLCN','VRAX','WINT','XCUR','ZCAR']


def log(msg):
    try:
        with open(LOGS/'app.log','a',encoding='utf-8') as f: f.write(datetime.now(timezone.utc).isoformat()+" "+msg+"\n")
    except Exception: pass

def db():
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    con.execute('''CREATE TABLE IF NOT EXISTS gems(ticker TEXT PRIMARY KEY,name TEXT,sector TEXT,country TEXT,exchange TEXT,website TEXT,mcap_usd REAL,mcap_source TEXT,mcap_confidence TEXT,gem_score REAL,hidden_score REAL,accumulation_score REAL,narrative_score REAL,hype_risk REAL,dilution_risk_score REAL,conviction_score REAL,conviction_label TEXT,company_plain TEXT,why_attractive TEXT,risk_plain TEXT,catalyst_plain TEXT,last_price REAL,volume INTEGER,first_seen TEXT,last_seen TEXT,alerted INTEGER DEFAULT 0)''')
    con.execute('''CREATE TABLE IF NOT EXISTS scan_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,ts TEXT,count INTEGER,under20 INTEGER,under50 INTEGER,under100 INTEGER,live_ok INTEGER,live_fail INTEGER,note TEXT)''')
    # lightweight migrations
    cols={r[1] for r in con.execute('PRAGMA table_info(gems)').fetchall()}
    for col,typ in {'website':'TEXT','last_price':'REAL','volume':'INTEGER'}.items():
        if col not in cols:
            try: con.execute(f'ALTER TABLE gems ADD COLUMN {col} {typ}')
            except Exception: pass
    return con

def fmt_mcap(x):
    if not x: return 'Onbekend'
    if x>=1e9: return f'${x/1e9:.2f}B'
    return f'${x/1e6:.1f}M'

def chunked(lst,n):
    for i in range(0,len(lst),n): yield lst[i:i+n]

def yahoo_quote(symbols:List[str])->Dict[str,Dict[str,Any]]:
    out={}
    if not MCAP_LIVE_ENABLED or not symbols: return out
    headers={'User-Agent':'Mozilla/5.0 StockGemEngine/1.3'}
    for ch in chunked(symbols,40):
        try:
            r=requests.get('https://query1.finance.yahoo.com/v7/finance/quote',params={'symbols':','.join(ch)},headers=headers,timeout=8)
            if r.status_code!=200:
                log(f'yahoo_quote_http status={r.status_code} symbols={ch[:3]}'); continue
            for row in r.json().get('quoteResponse',{}).get('result',[]):
                sym=str(row.get('symbol','')).upper()
                out[sym]=row
        except Exception as e: log('yahoo_quote_error '+str(e)[:160])
    return out

def yahoo_search(q:str)->List[Dict[str,Any]]:
    try:
        r=requests.get('https://query1.finance.yahoo.com/v1/finance/search',params={'q':q,'quotesCount':12,'newsCount':0},headers={'User-Agent':'Mozilla/5.0'},timeout=8)
        rows=[]
        for x in r.json().get('quotes',[]):
            if x.get('quoteType') in ('EQUITY','ETF'):
                rows.append({'symbol':x.get('symbol'), 'name':x.get('shortname') or x.get('longname') or '', 'exchange':x.get('exchDisp') or x.get('exchange') or '', 'type':x.get('quoteType')})
        return rows
    except Exception as e:
        log('yahoo_search_error '+str(e)[:160]); return []

def cap_from_row(row):
    def f(v):
        try: return float(v) if v not in (None,'') and float(v)>0 else None
        except Exception: return None
    m=f(row.get('marketCap'))
    p=f(row.get('regularMarketPrice') or row.get('postMarketPrice'))
    sh=f(row.get('sharesOutstanding') or row.get('impliedSharesOutstanding'))
    if not m and p and sh: m=p*sh
    return m,p,row.get('regularMarketVolume') or row.get('averageDailyVolume3Month')

def narrative_score(sector):
    s=sector.lower(); score=35
    for kw,pts in [('defense',24),('drone',20),('ai',20),('robot',18),('battery',15),('lithium',14),('rare earth',14),('biotech',13),('hydrogen',12),('space',16),('cyber',15),('energy',10)]:
        if kw in s: score+=pts
    return min(100,score)

def score(seed,row=None):
    sym,name,sector,country,exchange,website,curated=seed
    live_m,price,vol=(None,None,None)
    if row: live_m,price,vol=cap_from_row(row)
    m=live_m or curated
    src='yahoo_live' if live_m else 'curated_fallback'
    conf='high' if live_m else 'low'
    cap_component=max(0,min(100,(150_000_000-min(m or 150_000_000,150_000_000))/150_000_000*100))
    nar=narrative_score(sector)
    accum=48
    hype=8 if m and m<100_000_000 else 18
    dilution=55 if m and m<20_000_000 else 45
    hidden=round(0.45*cap_component+0.35*nar+0.20*(100-hype),1)
    gem=round(0.45*hidden+0.35*nar+0.20*(100-dilution),1)
    conv=round(max(0,min(10,(gem*0.65+hidden*0.35-dilution*0.15)/10)),1)
    cl='Ultra/nano-cap DD candidate' if m and m<20_000_000 else ('Microcap watchlist' if m and m<100_000_000 else 'Smallcap/too large for nano bucket')
    plain=f'{name} is actief in {sector}. Dit is een research-kandidaat; controleer altijd filings, kaspositie, omzet, dilution en echte brokerbaarheid voordat je iets doet.'
    why=f'Aantrekkelijk omdat de market cap {fmt_mcap(m)} is, de sector/narrative relevant kan worden en de hype-score laag blijft. De tool zoekt hier vooral naar vóór-de-hype asymmetrie.'
    risk=f'Risico: microcaps kunnen illiquide zijn en vaak extra aandelen uitgeven. Market cap bron: {src} ({conf}). Bij fallback altijd zelf controleren.'
    cat='Katalysator om te checken: nieuw contract, partnership, klinische data, financiering, overheids/defense order, productlaunch of sector-nieuws.'
    return dict(ticker=sym.upper(),name=name,sector=sector,country=country,exchange=exchange,website=website,mcap_usd=m,mcap_source=src,mcap_confidence=conf,gem_score=gem,hidden_score=hidden,accumulation_score=accum,narrative_score=nar,hype_risk=hype,dilution_risk_score=dilution,conviction_score=conv,conviction_label=cl,company_plain=plain,why_attractive=why,risk_plain=risk,catalyst_plain=cat,last_price=price,volume=vol)

def seed_list():
    seeds=list(SEED_UNIVERSE)
    for s in EXPLORATION_SYMBOLS:
        seeds.append((s,s,'Unclassified microcap candidate','US','NASDAQ/NYSE/OTC','',None))
    # de-dupe preserving first
    seen=set(); out=[]
    for x in seeds:
        if x[0].upper() not in seen:
            out.append(x); seen.add(x[0].upper())
    return out

def run_scan(manual=False):
    if state['running']: return {'running':True,'message':'scan already running'}
    state['running']=True; state['last_error']=None
    try:
        seeds=seed_list(); symbols=[x[0] for x in seeds]
        rows=yahoo_quote(symbols)
        results=[]; live_ok=live_fail=0
        for seed in seeds:
            row=rows.get(seed[0].upper())
            item=score(seed,row)
            if item['mcap_source']=='yahoo_live': live_ok+=1
            else: live_fail+=1
            # keep only real micro/smallcap candidates, no billion-dollar names
            if item['mcap_usd'] and item['mcap_usd']<=300_000_000:
                results.append(item)
        results.sort(key=lambda x:(x['mcap_usd'] or 9e9, -x['gem_score']))
        con=db(); now=datetime.now(timezone.utc).isoformat(); alerts=0
        con.execute('DELETE FROM gems')  # v1.3 audit fix: replace stale 24-row DB entirely
        for g in results:
            con.execute('''INSERT OR REPLACE INTO gems(ticker,name,sector,country,exchange,website,mcap_usd,mcap_source,mcap_confidence,gem_score,hidden_score,accumulation_score,narrative_score,hype_risk,dilution_risk_score,conviction_score,conviction_label,company_plain,why_attractive,risk_plain,catalyst_plain,last_price,volume,first_seen,last_seen,alerted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (g['ticker'],g['name'],g['sector'],g['country'],g['exchange'],g['website'],g['mcap_usd'],g['mcap_source'],g['mcap_confidence'],g['gem_score'],g['hidden_score'],g['accumulation_score'],g['narrative_score'],g['hype_risk'],g['dilution_risk_score'],g['conviction_score'],g['conviction_label'],g['company_plain'],g['why_attractive'],g['risk_plain'],g['catalyst_plain'],g['last_price'],g['volume'],now,now,0))
        u20=sum(1 for g in results if g['mcap_usd'] and g['mcap_usd']<20e6); u50=sum(1 for g in results if g['mcap_usd'] and g['mcap_usd']<50e6); u100=sum(1 for g in results if g['mcap_usd'] and g['mcap_usd']<100e6)
        con.execute('INSERT INTO scan_runs(ts,count,under20,under50,under100,live_ok,live_fail,note) VALUES(?,?,?,?,?,?,?,?)',(now,len(results),u20,u50,u100,live_ok,live_fail,'replace-stale-db'))
        con.commit(); con.close()
        state.update({'last_scan':now,'last_alerts':alerts,'audit':{'universe':len(seeds),'stored':len(results),'under20':u20,'under50':u50,'under100':u100,'live_ok':live_ok,'live_fail':live_fail}})
        log(f'scan_complete stored={len(results)} under20={u20} under50={u50} live_ok={live_ok} live_fail={live_fail}')
        return {'ok':True,**state['audit']}
    except Exception as e:
        state['last_error']=str(e); log('scan_error '+str(e)); return {'ok':False,'error':str(e)}
    finally:
        state['running']=False

@app.on_event('startup')
def startup():
    db().close(); log(f'started version={APP_VERSION}')
    def loop():
        log(f'scheduler_started enabled={AUTO_SCAN_ENABLED} interval={SCAN_INTERVAL_MINUTES}')
        # immediate repair scan if DB stale or empty
        try:
            con=db(); c=con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; con.close()
            if c<40: run_scan(False)
        except Exception: pass
        while True:
            time.sleep(max(60,SCAN_INTERVAL_MINUTES*60))
            if AUTO_SCAN_ENABLED: run_scan(False)
    threading.Thread(target=loop,daemon=True).start()

@app.get('/api/status')
def api_status():
    con=db(); count=con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; u20=con.execute('SELECT COUNT(*) c FROM gems WHERE mcap_usd<20000000').fetchone()['c']; u50=con.execute('SELECT COUNT(*) c FROM gems WHERE mcap_usd<50000000').fetchone()['c']; con.close()
    return {'version':APP_VERSION,'running':state['running'],'last_scan':state['last_scan'],'gems':count,'under20':u20,'under50':u50,'audit':state['audit'],'error':state['last_error'],'ntfy':NTFY_TOPIC,'auto_minutes':SCAN_INTERVAL_MINUTES}

@app.post('/api/scan')
def api_scan(): return run_scan(True)

@app.post('/api/admin/reset_scan')
def reset_scan():
    con=db(); con.execute('DELETE FROM gems'); con.commit(); con.close(); return run_scan(True)

@app.get('/api/gems')
def api_gems(bucket:str='all',sector:str='all',limit:int=250):
    where=[]; args=[]
    if bucket=='20': where.append('mcap_usd<20000000')
    if bucket=='50': where.append('mcap_usd<50000000')
    if bucket=='100': where.append('mcap_usd<100000000')
    if sector!='all': where.append('lower(sector) LIKE ?'); args.append('%'+sector.lower()+'%')
    sql='SELECT * FROM gems '+(('WHERE '+' AND '.join(where)) if where else '')+' ORDER BY mcap_usd ASC, gem_score DESC LIMIT ?'; args.append(limit)
    con=db(); rows=[dict(r) for r in con.execute(sql,args).fetchall()]; con.close(); return rows

@app.get('/api/audit/microcaps')
def audit():
    con=db();
    d={k:con.execute(q).fetchone()['c'] for k,q in {'all':'SELECT COUNT(*) c FROM gems','under20':'SELECT COUNT(*) c FROM gems WHERE mcap_usd<20000000','under50':'SELECT COUNT(*) c FROM gems WHERE mcap_usd<50000000','under100':'SELECT COUNT(*) c FROM gems WHERE mcap_usd<100000000','live':'SELECT COUNT(*) c FROM gems WHERE mcap_source="yahoo_live"','fallback':'SELECT COUNT(*) c FROM gems WHERE mcap_source!="yahoo_live"'}.items()}
    d['sample_under20']=[dict(r) for r in con.execute('SELECT ticker,name,mcap_usd,mcap_source FROM gems WHERE mcap_usd<20000000 ORDER BY mcap_usd LIMIT 20').fetchall()]
    con.close(); return d

@app.get('/api/search')
def search(q:str):
    q=q.strip();
    if not q: return []
    con=db(); local=[dict(r) for r in con.execute('SELECT * FROM gems WHERE ticker LIKE ? OR name LIKE ? OR sector LIKE ? ORDER BY mcap_usd ASC LIMIT 15',(f'%{q.upper()}%',f'%{q}%',f'%{q}%')).fetchall()]; con.close()
    found=yahoo_search(q)
    syms=[x['symbol'] for x in found if x.get('symbol')]
    quotes=yahoo_quote(syms)
    enriched=[]
    for x in found:
        row=quotes.get(str(x.get('symbol','')).upper(),{})
        m,p,v=cap_from_row(row) if row else (None,None,None)
        enriched.append({**x,'mcap_usd':m,'mcap_fmt':fmt_mcap(m),'price':p})
    return {'local':local,'yahoo':enriched}

HTML = r'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Stijn-Tradifi-2026</title><style>
:root{--bg:#08101b;--panel:#0f1a2b;--panel2:#142338;--line:#24344d;--txt:#f4f7fb;--mut:#91a0b7;--gold:#ffd376;--green:#66e39a;--red:#ff6e7a;--blue:#8ab4ff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 25% 0,#14243b 0,#08101b 42%,#050913 100%);font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;color:var(--txt)}.wrap{max-width:1180px;margin:auto;padding:18px}.top{position:sticky;top:0;z-index:20;background:linear-gradient(180deg,rgba(8,16,27,.98),rgba(8,16,27,.88));backdrop-filter:blur(14px);border-bottom:1px solid var(--line);padding:16px 18px}.brand{display:flex;justify-content:space-between;gap:14px;align-items:end}.kicker{letter-spacing:.28em;color:var(--gold);font-weight:900;font-size:12px}.brand h1{margin:4px 0 0;font-size:34px;line-height:1}.sub{color:var(--mut);font-size:15px;margin-top:6px}.bar{display:grid;grid-template-columns:1fr auto auto;gap:10px;margin-top:14px}.search{width:100%;border:1px solid var(--line);background:#0b1423;color:var(--txt);border-radius:18px;padding:14px 16px;font-size:16px;font-weight:700}.btn{border:1px solid #354762;background:#152238;color:var(--txt);border-radius:18px;padding:12px 16px;font-weight:900;font-size:15px}.primary{background:linear-gradient(135deg,#ffe39a,#ffbd4e);color:#111827;border:0}.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:16px 0}.stat{background:linear-gradient(180deg,#152238,#0c1625);border:1px solid var(--line);border-radius:20px;padding:14px}.stat b{font-size:26px}.stat span{display:block;color:var(--mut);font-weight:700}.filters{display:flex;gap:8px;overflow:auto;padding-bottom:7px}.pill{white-space:nowrap;border:1px solid var(--line);background:#111b2d;color:var(--mut);border-radius:999px;padding:10px 13px;font-weight:900}.pill.on{background:var(--gold);color:#111827;border:0}.layout{display:grid;grid-template-columns:1fr 350px;gap:14px}.panel{background:linear-gradient(180deg,#101b2d,#0b1423);border:1px solid var(--line);border-radius:22px;overflow:hidden}.panel h2{margin:0;padding:14px 16px;border-bottom:1px solid var(--line);font-size:18px}.row{display:grid;grid-template-columns:56px 1fr 96px;gap:10px;padding:13px 14px;border-bottom:1px solid rgba(255,255,255,.06);align-items:center}.rank{width:42px;height:42px;border-radius:14px;background:#1b2740;color:var(--gold);display:grid;place-items:center;font-weight:900;border:1px solid #43536d}.sym{font-size:26px;font-weight:1000;letter-spacing:-.04em}.meta{color:var(--mut);font-weight:700;font-size:13px}.sector{font-weight:900;margin-top:4px}.chips{display:flex;gap:5px;flex-wrap:wrap;margin-top:8px}.chip{font-size:10px;letter-spacing:.12em;text-transform:uppercase;border:1px solid #31435f;border-radius:999px;padding:5px 7px;color:#b8c4d9;font-weight:900}.mcap{color:var(--green)}.score{text-align:right}.score b{font-size:30px;color:var(--gold)}.score span{display:block;color:var(--mut);font-size:12px;font-weight:800}.micro{font-size:12px;color:var(--mut);line-height:1.45;margin-top:7px}.details{display:none;grid-column:2/4;background:#0b1423;border:1px solid var(--line);border-radius:16px;padding:12px;margin-top:6px}.details.open{display:block}.details h3{margin:0 0 5px;font-size:14px;color:var(--gold)}.details p{margin:0 0 10px;color:#cbd5e1}.side{position:sticky;top:160px;align-self:start}.auditline{display:flex;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,.08);padding:10px 12px;color:#cbd5e1}.result{padding:10px 12px;border-bottom:1px solid rgba(255,255,255,.06)}.link{color:var(--blue);font-weight:900;text-decoration:none}@media(max-width:850px){.wrap{padding:0}.top{padding:16px}.brand h1{font-size:32px}.bar{grid-template-columns:1fr 1fr}.search{grid-column:1/3}.stats{grid-template-columns:repeat(2,1fr);padding:0 14px}.layout{display:block;padding:0 14px}.side{position:static;margin-top:14px}.row{grid-template-columns:46px 1fr 78px}.sym{font-size:24px}.score b{font-size:26px}.details{grid-column:1/4}.panel{border-radius:18px}.filters{padding:0 14px 8px}.hero{padding:0 14px}}</style></head><body><div class=top><div class=brand><div><div class=kicker>REAL DATA AUDIT · MICROCAP TERMINAL · NO API COSTS</div><h1>Stijn-Tradifi-2026</h1><div class=sub>Compact dashboard: echte audit, sub-$20M buckets, live Yahoo mcap waar beschikbaar en Google-achtige zoekbalk.</div></div></div><div class=bar><input id=q class=search placeholder="Zoek ticker, bedrijf of sector… bv. ASTI, lithium, ASX"><button class="btn primary" onclick="scan()">Nieuwe scan</button><button class=btn onclick="loadAll()">Vernieuwen</button></div></div><div class=wrap><div class=hero><div class=stats><div class=stat><b id=gems>…</b><span>Gems</span></div><div class=stat><b id=u20>…</b><span>onder $20M</span></div><div class=stat><b id=u50>…</b><span>onder $50M</span></div><div class=stat><b id=live>…</b><span>live mcap</span></div><div class=stat><b id=last>…</b><span>laatste scan</span></div></div><div class=filters><button class="pill on" data-b="all">Alle</button><button class=pill data-b="20">Top <$20M</button><button class=pill data-b="50">Top <$50M</button><button class=pill data-b="100">Top <$100M</button><button class=pill data-sector="defense">Defense</button><button class=pill data-sector="biotech">Biotech</button><button class=pill data-sector="lithium">Lithium</button><button class=pill data-sector="ai">AI</button></div></div><div class=layout><main class=panel><h2>Top Gems Ranking</h2><div id=list><div style="padding:20px;color:#91a0b7">Laden…</div></div></main><aside class="panel side"><h2>Data-audit & zoeken</h2><div id=audit></div><div id=searchResults></div></aside></div></div><script>
let bucket='all', sector='all';
function fmtM(x){if(!x)return'Onbekend'; if(x>=1e9)return '$'+(x/1e9).toFixed(2)+'B'; return '$'+(x/1e6).toFixed(1)+'M'}
async function status(){let s=await (await fetch('/api/status?_='+Date.now())).json(); gems.textContent=s.gems; u20.textContent=s.under20; u50.textContent=s.under50; live.textContent=(s.audit&&s.audit.live_ok)||0; last.textContent=s.last_scan?new Date(s.last_scan).toLocaleTimeString():'geen'; audit.innerHTML=['version '+s.version,'universe '+((s.audit&&s.audit.universe)||'?'),'stored '+s.gems,'under20 '+s.under20,'under50 '+s.under50,'error '+(s.error||'geen')].map(x=>'<div class=auditline><span>'+x.split(' ')[0]+'</span><b>'+x.substring(x.indexOf(' ')+1)+'</b></div>').join('')}
function card(x,i){let w=x.website?`<a class=link href="${x.website}" target=_blank>website</a>`:'geen website';return `<div class=row onclick="this.querySelector('.details').classList.toggle('open')"><div class=rank>#${i+1}</div><div><div class=sym>${x.ticker}</div><div class=meta>${x.name} · ${x.country} · ${x.exchange}</div><div class=sector>${x.sector}</div><div class=chips><span class="chip mcap">${fmtM(x.mcap_usd)}</span><span class=chip>${x.mcap_source}</span><span class=chip>${x.mcap_confidence}</span><span class=chip>${x.conviction_label||''}</span></div><div class=micro>${x.company_plain||''}</div></div><div class=score><b>${Number(x.conviction_score||0).toFixed(1)}</b><span>conviction</span><span>gem ${Number(x.gem_score||0).toFixed(0)}</span></div><div class=details><h3>Waarom aantrekkelijk?</h3><p>${x.why_attractive||''}</p><h3>Risico</h3><p>${x.risk_plain||''}</p><h3>Katalysator</h3><p>${x.catalyst_plain||''}</p><h3>DD</h3><p>${w} · prijs ${x.last_price||'n/b'} · volume ${x.volume||'n/b'}</p></div></div>`}
async function gemsLoad(){list.innerHTML='<div style="padding:20px;color:#91a0b7">Laden…</div>';let rows=await (await fetch(`/api/gems?bucket=${bucket}&sector=${sector}&limit=250&_=${Date.now()}`)).json();list.innerHTML=rows.length?rows.map(card).join(''):'<div style="padding:24px;color:#91a0b7">Geen resultaten. Run Nieuwe scan of kies Alle.</div>'}
async function loadAll(){await status(); await gemsLoad()}
async function scan(){list.innerHTML='<div style="padding:24px;color:#ffd376;font-weight:900">Scan draait… stale DB wordt vervangen.</div>';await fetch('/api/scan',{method:'POST'}); await loadAll()}
document.querySelectorAll('.pill').forEach(p=>p.onclick=()=>{document.querySelectorAll('.pill').forEach(x=>x.classList.remove('on'));p.classList.add('on');bucket=p.dataset.b||bucket;sector=p.dataset.sector||'all';gemsLoad()})
let timer; q.oninput=()=>{clearTimeout(timer);timer=setTimeout(search,500)}; async function search(){let v=q.value.trim();if(!v){searchResults.innerHTML='';return}let r=await (await fetch('/api/search?q='+encodeURIComponent(v))).json();let html='<h2>Zoekresultaten</h2>';(r.local||[]).slice(0,5).forEach(x=>html+=`<div class=result><b>${x.ticker}</b> ${x.name}<br><span class=meta>${fmtM(x.mcap_usd)} · lokaal</span></div>`);(r.yahoo||[]).slice(0,8).forEach(x=>html+=`<div class=result><b>${x.symbol}</b> ${x.name}<br><span class=meta>${x.mcap_fmt} · ${x.exchange}</span></div>`);searchResults.innerHTML=html}
loadAll(); setInterval(loadAll,30000);
</script></body></html>'''

@app.get('/')
def home(): return HTMLResponse(HTML)
