# Outrun IQ v1.0 no-fastapi

Deze build gebruikt alleen Python standaardbibliotheek. Geen FastAPI/install nodig.

Run:

```bash
HOST=0.0.0.0 PORT=8795 python3 server.py
```

Health:

```bash
curl -s http://127.0.0.1:8795/api/health
```
