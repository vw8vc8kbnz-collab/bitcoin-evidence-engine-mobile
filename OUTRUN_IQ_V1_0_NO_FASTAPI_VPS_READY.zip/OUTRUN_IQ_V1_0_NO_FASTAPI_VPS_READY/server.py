#!/usr/bin/env python3
import os
import json
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

APP_NAME = "Outrun IQ"
VERSION = "v1.0-no-fastapi"
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8795"))
ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC), **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":
            data = {"ok": True, "app": APP_NAME, "version": VERSION, "port": PORT}
            body = json.dumps(data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if path in ("", "/"):
            self.path = "/index.html"
        return super().do_GET()

if __name__ == "__main__":
    if not STATIC.exists():
        raise SystemExit(f"Static folder not found: {STATIC}")
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"{APP_NAME} {VERSION} running on http://{HOST}:{PORT}", flush=True)
    httpd.serve_forever()
