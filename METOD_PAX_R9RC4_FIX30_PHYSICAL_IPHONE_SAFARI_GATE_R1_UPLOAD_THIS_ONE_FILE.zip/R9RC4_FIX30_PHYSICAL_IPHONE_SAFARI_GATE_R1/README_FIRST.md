# METOD/PAX FIX30 — fysieke iPhone-Safari-gate R1

Dit pakket verzamelt serverbewijs rond één handmatig gefilmde acceptatierun in
echte Safari op een fysieke iPhone. Het wijzigt Tool A, de releasepointer,
configuratie en live state niet. Alleen normale healthrequests en de door de
tester bewust uitgevoerde klantflow bereiken de stagingapplicatie.

De gate bestaat uit twee bewijshelften:

1. de collector bewijst exact FIX30, gezonde service, onveranderde release,
   Safari-verkeer, noodzakelijke HTTP-routes en afwezigheid van achtergebleven
   optimizerprocessen;
2. de schermopname bewijst touchbediening, visuele materiaal-/paneelkoppeling,
   Nerf-preview, echte voortgangspercentages, volledige checkout en reset.

De servercapture kan daarom zelfstandig alleen
`PENDING_PHYSICAL_MEDIA_REVIEW` bereiken. De definitieve fysieke gate wordt pas
PASS nadat de video samen met de server-evidence is beoordeeld.

## Gebruik

1. Voer `operations/START_FIX30_PHYSICAL_IPHONE_SAFARI_GATE.sh` uit.
2. Open de getoonde `OPEN=`-URL in echte Safari en film de volledige checklist.
3. Voer na de test vanuit Termius de getoonde `FINISH=`-regel uit.
4. Upload de schermopname en de gemaakte server-evidence-ZIP samen.

Gebruik uitsluitend de synthetische gegevens uit
`docs/PHYSICAL_IPHONE_SAFARI_CHECKLIST_NL.md`.

## Exacte FIX30-binding

- release: `R9RC4_FIX30_MOBILE_MATERIAL_CHECKOUT_GRAIN_DISCOVERY`;
- FIX30-manifest SHA-256:
  `038df64bb4f7f2aee3bf4fbf19fe9d2136246d8957e658a33522360cd6543550`;
- eerder afgeronde R4-browseroraclecommit:
  `1855dce5bf2ee112e88b84a6af303f6d39b0289e`.
