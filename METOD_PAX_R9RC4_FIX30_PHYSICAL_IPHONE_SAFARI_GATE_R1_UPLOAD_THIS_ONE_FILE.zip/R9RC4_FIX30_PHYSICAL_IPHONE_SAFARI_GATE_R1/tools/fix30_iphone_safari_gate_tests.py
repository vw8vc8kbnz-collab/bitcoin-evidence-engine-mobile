#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import os
import stat
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TOOL_PATH = ROOT / "tools" / "fix30_iphone_safari_gate.py"
SPEC = importlib.util.spec_from_file_location("fix30_iphone_safari_gate", TOOL_PATH)
assert SPEC and SPEC.loader
TOOL = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = TOOL
SPEC.loader.exec_module(TOOL)


class Fix30IphoneSafariGateTests(unittest.TestCase):
    def test_exact_https_origin_is_required(self) -> None:
        self.assertEqual(
            TOOL.strict_https_origin("https://preview.example.invalid/\n"),
            "https://preview.example.invalid/",
        )
        for invalid in (
            "http://preview.example.invalid/",
            "https://preview.example.invalid/path",
            "https://preview.example.invalid/?token=secret",
            "https://user:password@preview.example.invalid/",
        ):
            with self.assertRaises(TOOL.GateError):
                TOOL.strict_https_origin(invalid)

    def test_dynamic_routes_are_normalized_without_query_values(self) -> None:
        self.assertEqual(
            TOOL.normalize_route("/api/jobs/opaque-secret/status?ts=123"),
            "/api/jobs/{jobId}/status",
        )
        self.assertEqual(
            TOOL.normalize_route("/api/materials/image/decor_123/catalog?v=secret"),
            "/api/materials/image/{materialId}/{variant}",
        )
        self.assertEqual(TOOL.normalize_route("/?fix30=iphone-r1"), "/")

    def test_log_summary_detects_real_iphone_safari_and_excludes_crios(self) -> None:
        raw = (
            '203.0.113.1 - - [date] "GET /?fix30=iphone-r1 HTTP/1.1" 200 12 "-" '
            '"Mozilla/5.0 (iPhone) Version/26.0 Mobile/15E148 Safari/604.1"\n'
            '203.0.113.1 - - [date] "GET /api/jobs/secret/status?ts=1 HTTP/1.1" 200 12 "-" '
            '"Mozilla/5.0 (iPhone) CriOS/151 Mobile/15E148 Safari/604.1"\n'
        ).encode()
        result = TOOL.summarize_http_log(raw)
        self.assertEqual(result["iphoneSafariRequestCount"], 1)
        self.assertEqual(result["http5xxCount"], 0)
        self.assertIn(
            {"method": "GET", "path": "/api/jobs/{jobId}/status", "status": 200, "count": 1},
            result["routes"],
        )
        self.assertNotIn("secret", json.dumps(result))
        self.assertNotIn("203.0.113.1", json.dumps(result))

    def test_required_routes_are_fail_closed(self) -> None:
        contract = {
            "requiredPublicRoutes": [
                {"method": "POST", "path": "/api/jobs", "acceptedStatuses": [202], "minimum": 1},
                {"method": "POST", "path": "/api/submit_config", "acceptedStatuses": [200], "minimum": 1},
            ]
        }
        routes = [{"method": "POST", "path": "/api/jobs", "status": 202, "count": 1}]
        checks = TOOL.required_route_checks(contract, routes)
        self.assertEqual([item["status"] for item in checks], ["PASS", "FAIL"])

    def test_manifest_verification_binds_exact_fileset_and_bytes(self) -> None:
        with tempfile.TemporaryDirectory(prefix="fix30-iphone-manifest-") as raw:
            root = Path(raw)
            (root / "a.txt").write_text("A\n", encoding="utf-8")
            digest = TOOL.sha256_file(root / "a.txt")
            (root / "SHA256SUMS.txt").write_text(f"{digest}  a.txt\n", encoding="utf-8")
            result = TOOL.verify_manifested_tree(root, "SHA256SUMS.txt")
            self.assertEqual(result["fileCount"], 1)
            (root / "extra.txt").write_text("extra\n", encoding="utf-8")
            with self.assertRaises(TOOL.GateError):
                TOOL.verify_manifested_tree(root, "SHA256SUMS.txt")

    def test_manifest_rejects_traversal_duplicates_and_symlinks(self) -> None:
        with tempfile.TemporaryDirectory(prefix="fix30-iphone-manifest-") as raw:
            root = Path(raw)
            manifest = root / "SHA256SUMS.txt"
            manifest.write_text(f"{'0' * 64}  ../escape\n", encoding="utf-8")
            with self.assertRaises(TOOL.GateError):
                TOOL.parse_checksum_manifest(manifest)
            manifest.write_text(f"{'0' * 64}  a\n{'1' * 64}  a\n", encoding="utf-8")
            with self.assertRaises(TOOL.GateError):
                TOOL.parse_checksum_manifest(manifest)
            target = root / "target"
            target.write_text("x", encoding="utf-8")
            (root / "link").symlink_to(target)
            with self.assertRaises(TOOL.GateError):
                TOOL.regular_files(root, {"SHA256SUMS.txt"})

    def test_manifest_rejects_a_symlinked_tree_root(self) -> None:
        with tempfile.TemporaryDirectory(prefix="fix30-iphone-root-") as raw:
            parent = Path(raw)
            root = parent / "tree"
            root.mkdir()
            (root / "proof.txt").write_text("proof\n", encoding="utf-8")
            digest = TOOL.sha256_file(root / "proof.txt")
            (root / "SHA256SUMS.txt").write_text(f"{digest}  proof.txt\n", encoding="utf-8")
            alias = parent / "alias"
            alias.symlink_to(root, target_is_directory=True)
            with self.assertRaises(TOOL.GateError):
                TOOL.verify_manifested_tree(alias, "SHA256SUMS.txt")

    def test_atomic_json_is_private_and_strict(self) -> None:
        with tempfile.TemporaryDirectory(prefix="fix30-iphone-json-") as raw:
            path = Path(raw) / "result.json"
            TOOL.atomic_json(path, {"ok": True, "value": 1.5})
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
            self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["ok"], True)
            with self.assertRaises(ValueError):
                TOOL.atomic_json(path, {"bad": float("nan")})

    def test_evidence_verifier_detects_tampering(self) -> None:
        with tempfile.TemporaryDirectory(prefix="fix30-iphone-evidence-") as raw:
            evidence = Path(raw)
            files = {
                "FIX30_IPHONE_R1_START.json": {"status": "PASS"},
                "FIX30_IPHONE_R1_END.json": {"status": "PASS"},
                "FIX30_IPHONE_R1_ROUTE_SUMMARY.json": {"status": "PASS"},
                "FIX30_IPHONE_R1_SERVER_ACCEPTANCE.json": {
                    "gateId": TOOL.GATE_ID,
                    "candidateManifestSha256": TOOL.EXPECTED_MANIFEST_SHA256,
                    "status": "PASS",
                },
                "FIX30_PHYSICAL_IPHONE_SAFARI_GATE_CONTRACT.json": {"contractId": TOOL.GATE_ID},
            }
            for name, value in files.items():
                TOOL.atomic_json(evidence / name, value)
            TOOL.atomic_text(evidence / "PHYSICAL_IPHONE_SAFARI_CHECKLIST_NL.md", "# checklist\n")
            TOOL.evidence_manifest(evidence)
            self.assertEqual(TOOL.verify_evidence(evidence)["serverCaptureStatus"], "PASS")
            (evidence / "FIX30_IPHONE_R1_END.json").write_text("{}\n", encoding="utf-8")
            with self.assertRaises(TOOL.GateError):
                TOOL.verify_evidence(evidence)

    def test_evidence_zip_contains_only_regular_evidence_files(self) -> None:
        with tempfile.TemporaryDirectory(prefix="fix30-iphone-zip-") as raw:
            root = Path(raw)
            evidence = root / "evidence"
            evidence.mkdir()
            TOOL.atomic_text(evidence / "proof.txt", "proof\n")
            output = root / "evidence.zip"
            TOOL.write_evidence_zip(evidence, output)
            self.assertEqual(stat.S_IMODE(output.stat().st_mode), 0o600)
            with zipfile.ZipFile(output) as archive:
                self.assertEqual(archive.namelist(), ["evidence/proof.txt"])
                self.assertEqual(archive.read("evidence/proof.txt"), b"proof\n")

    def test_collector_does_not_read_credentials_or_request_bodies(self) -> None:
        source = TOOL_PATH.read_text(encoding="utf-8")
        self.assertNotIn("admin_credentials", source)
        self.assertNotIn("metod-pax.env", source)
        self.assertNotIn("shell=True", source)
        self.assertNotIn('"tail", "-c"', source)
        self.assertNotIn("Authorization", source)
        self.assertIn('"iflag=skip_bytes,count_bytes"', source)
        self.assertIn("MAX_LOG_DELTA_BYTES", source)
        self.assertIn('"requestBodiesCollected": False', source)
        self.assertIn('"rawLogsPersisted": False', source)

    def test_contract_matches_collector_identity_and_bounds(self) -> None:
        contract = json.loads(
            (ROOT / "contracts/FIX30_PHYSICAL_IPHONE_SAFARI_GATE_CONTRACT.json").read_text(encoding="utf-8")
        )
        self.assertEqual(contract["contractId"], TOOL.GATE_ID)
        self.assertEqual(contract["frozenCandidate"]["manifestSha256"], TOOL.EXPECTED_MANIFEST_SHA256)
        self.assertEqual(contract["frozenCandidate"]["browserOracleCommit"], TOOL.EXPECTED_BROWSER_ORACLE_COMMIT)
        self.assertEqual(contract["runtime"]["maximumCaptureSeconds"], TOOL.MAX_CAPTURE_SECONDS)
        self.assertEqual(contract["runtime"]["maximumLogDeltaBytes"], TOOL.MAX_LOG_DELTA_BYTES)
        self.assertEqual(len(contract["requiredPublicRoutes"]), 5)

    def test_server_capture_cannot_claim_final_physical_gate(self) -> None:
        source = TOOL_PATH.read_text(encoding="utf-8")
        self.assertIn('"screenRecordingReviewStatus": "PENDING"', source)
        self.assertIn('"physicalIphoneSafariGate": "PENDING_PHYSICAL_MEDIA_REVIEW"', source)
        self.assertNotIn('"physicalIphoneSafariGate": "PASS"', source)


if __name__ == "__main__":
    unittest.main()
