#!/usr/bin/env python3
"""Fail-closed server evidence around one physical iPhone Safari run.

The collector never reads request bodies, credentials or application state
records. Raw logs are reduced in memory to route/status counts and hashes; only
those privacy-safe summaries are written to evidence.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Iterable


GATE_ID = "R9RC4_FIX30_PHYSICAL_IPHONE_SAFARI_GATE_R1"
EXPECTED_MANIFEST_SHA256 = "038df64bb4f7f2aee3bf4fbf19fe9d2136246d8957e658a33522360cd6543550"
EXPECTED_BROWSER_ORACLE_COMMIT = "1855dce5bf2ee112e88b84a6af303f6d39b0289e"
CURRENT_LINK = Path("/opt/adzaagt/metod-pax-current")
RELEASE_ROOT = Path("/opt/adzaagt/metod-pax-releases")
STATE_ROOT = Path("/var/lib/metod-pax")
PREVIEW_URL_FILE = Path("/etc/adzaagt/metod-pax/preview-url")
SERVICE = "metod-pax.service"
HEALTH_BASE = "http://127.0.0.1:8790"
ACTIVE_FILE_NAME = "METOD_FIX30_IPHONE_R1_ACTIVE.txt"
AUDIT_PREFIX = "metod-fix30-iphone-audit."
MAX_CAPTURE_SECONDS = 7200
MAX_LOG_DELTA_BYTES = 64 * 1024 * 1024
NGINX_LOG_CANDIDATES = (
    Path("/var/log/nginx/metod-pax-access.log"),
    Path("/var/log/nginx/access.log"),
)


class GateError(RuntimeError):
    """A bounded fail-closed contract violation."""


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_bytes(path: Path, value: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, raw_tmp = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    tmp = Path(raw_tmp)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "wb") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
        os.chmod(path, mode)
    finally:
        if tmp.exists():
            tmp.unlink()


def atomic_text(path: Path, value: str, mode: int = 0o600) -> None:
    atomic_bytes(path, value.encode("utf-8"), mode)


def atomic_json(path: Path, value: Any) -> None:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    atomic_text(path, encoded + "\n")


def run(command: list[str], *, privileged: bool = False, binary: bool = False) -> str | bytes:
    argv = (["sudo", "-n"] if privileged else []) + command
    result = subprocess.run(
        argv,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=not binary,
        timeout=120,
    )
    if result.returncode != 0:
        stderr = result.stderr.decode("utf-8", "replace") if binary else result.stderr
        detail = " ".join(str(stderr or "").split())[:400]
        raise GateError(f"command failed ({result.returncode}): {command[0]}: {detail}")
    return result.stdout


def require_commands(names: Iterable[str]) -> None:
    missing = [name for name in names if shutil.which(name) is None]
    if missing:
        raise GateError(f"required command(s) missing: {', '.join(missing)}")


def normalized_relative(raw: str) -> str:
    candidate = raw[2:] if raw.startswith("./") else raw
    path = PurePosixPath(candidate)
    if not candidate or path.is_absolute() or ".." in path.parts or "\\" in candidate:
        raise GateError(f"unsafe manifest path: {raw!r}")
    normalized = path.as_posix()
    if normalized in {"", "."}:
        raise GateError("empty manifest path")
    return normalized


def parse_checksum_manifest(path: Path) -> dict[str, str]:
    if path.is_symlink() or not path.is_file():
        raise GateError(f"manifest is not a regular file: {path}")
    entries: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            raise GateError("manifest contains an invalid line")
        relative = normalized_relative(match.group(2))
        if relative in entries:
            raise GateError(f"manifest contains duplicate path: {relative}")
        entries[relative] = match.group(1)
    if not entries:
        raise GateError("manifest is empty")
    return entries


def regular_files(root: Path, excluded: set[str]) -> list[str]:
    files: list[str] = []
    for path in root.rglob("*"):
        relative = path.relative_to(root).as_posix()
        if path.is_symlink():
            raise GateError(f"symbolic link is forbidden: {relative}")
        if path.is_file() and relative not in excluded:
            files.append(relative)
        elif not path.is_file() and not path.is_dir():
            raise GateError(f"special filesystem object is forbidden: {relative}")
    return sorted(files)


def verify_manifested_tree(root: Path, manifest_name: str, expected_manifest_sha256: str | None = None) -> dict[str, Any]:
    if root.is_symlink():
        raise GateError(f"tree root is a symbolic link: {root}")
    resolved = root.resolve(strict=True)
    if not resolved.is_dir():
        raise GateError(f"tree is not a regular directory: {resolved}")
    manifest = resolved / manifest_name
    manifest_sha = sha256_file(manifest)
    if expected_manifest_sha256 and manifest_sha != expected_manifest_sha256:
        raise GateError(f"unexpected manifest SHA-256: {manifest_sha}")
    entries = parse_checksum_manifest(manifest)
    actual = regular_files(resolved, {manifest_name})
    expected = sorted(entries)
    if actual != expected:
        missing = sorted(set(expected) - set(actual))
        extra = sorted(set(actual) - set(expected))
        raise GateError(f"manifest fileset mismatch; missing={missing}; extra={extra}")
    tree_digest = hashlib.sha256()
    for relative in expected:
        path = resolved / relative
        actual_sha = sha256_file(path)
        if actual_sha != entries[relative]:
            raise GateError(f"file checksum mismatch: {relative}")
        tree_digest.update(relative.encode("utf-8"))
        tree_digest.update(b"\0")
        tree_digest.update(actual_sha.encode("ascii"))
        tree_digest.update(b"\n")
    return {
        "fileCount": len(expected),
        "manifestSha256": manifest_sha,
        "verifiedTreeSha256": tree_digest.hexdigest(),
    }


def verify_package(package_root: Path) -> dict[str, Any]:
    result = verify_manifested_tree(package_root, "PACKAGE_MANIFEST_SHA256.txt")
    contract = json.loads((package_root / "contracts/FIX30_PHYSICAL_IPHONE_SAFARI_GATE_CONTRACT.json").read_text(encoding="utf-8"))
    if contract.get("contractId") != GATE_ID:
        raise GateError("unexpected package contract")
    frozen = contract.get("frozenCandidate", {})
    if frozen.get("manifestSha256") != EXPECTED_MANIFEST_SHA256:
        raise GateError("package contract does not bind exact FIX30")
    if frozen.get("browserOracleCommit") != EXPECTED_BROWSER_ORACLE_COMMIT:
        raise GateError("package contract does not bind the completed browser oracle")
    return result


def safe_home() -> Path:
    candidate = Path.home()
    if candidate.is_symlink():
        raise GateError("user home cannot be a symbolic link")
    home = candidate.resolve(strict=True)
    if not home.is_dir():
        raise GateError("invalid user home")
    return home


def safe_audit_root(raw: str | Path, home: Path) -> Path:
    candidate = Path(raw)
    if candidate.is_symlink():
        raise GateError("audit root cannot be a symbolic link")
    root = candidate.resolve(strict=True)
    if root.parent != home or not root.name.startswith(AUDIT_PREFIX):
        raise GateError(f"audit root falls outside the fixed home prefix: {root}")
    if not root.is_dir():
        raise GateError("invalid audit root")
    return root


def strict_https_origin(raw: str) -> str:
    text = raw.strip()
    parsed = urllib.parse.urlsplit(text)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
    ):
        raise GateError("preview URL is not an exact HTTPS origin")
    port = f":{parsed.port}" if parsed.port else ""
    return f"https://{parsed.hostname}{port}/"


def read_privileged_text(path: Path) -> str:
    return str(run(["cat", str(path)], privileged=True)).strip()


def service_snapshot() -> dict[str, Any]:
    properties = [
        "ActiveState",
        "SubState",
        "MainPID",
        "NRestarts",
        "ExecMainStartTimestampMonotonic",
        "ControlGroup",
    ]
    output = str(run(["systemctl", "show", SERVICE, "--no-pager", *[f"--property={item}" for item in properties]]))
    values: dict[str, str] = {}
    for line in output.splitlines():
        key, separator, value = line.partition("=")
        if separator:
            values[key] = value
    if any(key not in values for key in properties):
        raise GateError("systemd snapshot is incomplete")
    if values["ActiveState"] != "active" or values["SubState"] != "running":
        raise GateError("metod-pax service is not active/running")
    main_pid = int(values["MainPID"])
    if main_pid <= 1:
        raise GateError("invalid service MainPID")
    return {
        "activeState": values["ActiveState"],
        "subState": values["SubState"],
        "mainPid": main_pid,
        "nRestarts": int(values["NRestarts"]),
        "execMainStartTimestampMonotonic": int(values["ExecMainStartTimestampMonotonic"]),
        "controlGroup": values["ControlGroup"],
    }


def cgroup_snapshot(service: dict[str, Any]) -> dict[str, Any]:
    control_group = str(service["controlGroup"])
    if not control_group.startswith("/") or ".." in PurePosixPath(control_group).parts:
        raise GateError("invalid service control group")
    procs_path = Path("/sys/fs/cgroup") / control_group.lstrip("/") / "cgroup.procs"
    raw = read_privileged_text(procs_path)
    pids = sorted({int(value) for value in raw.split()})
    main_pid = int(service["mainPid"])
    return {
        "processCount": len(pids),
        "onlyMainPid": pids == [main_pid],
        "mainPidPresent": main_pid in pids,
    }


def health_snapshot(route: str) -> dict[str, Any]:
    url = HEALTH_BASE + route
    request = urllib.request.Request(url, headers={"User-Agent": "FIX30-iPhone-R1-server-evidence/1"})
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            body = response.read(8192)
            status = int(response.status)
            headers = response.headers
    except Exception as exc:
        raise GateError(f"health request failed for {route}: {type(exc).__name__}") from exc
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise GateError(f"health response is not strict JSON for {route}") from exc
    if status != 200 or payload.get("ok") is not True:
        raise GateError(f"health response is not OK for {route}")
    return {
        "route": route,
        "httpStatus": status,
        "ok": True,
        "build": str(payload.get("build", "")),
        "bodySha256": sha256_bytes(body),
        "contentType": str(headers.get("Content-Type", "")),
        "environment": str(headers.get("X-METOD-Environment", "")),
    }


def direct_entry_count(path: Path) -> int:
    output = run(
        ["find", str(path), "-mindepth", "1", "-maxdepth", "1", "-printf", "."],
        privileged=True,
        binary=True,
    )
    return len(bytes(output))


def state_counts() -> dict[str, int]:
    return {
        "jobsEntries": direct_entry_count(STATE_ROOT / "jobs"),
        "requestsEntries": direct_entry_count(STATE_ROOT / "requests"),
        "draftEntries": direct_entry_count(STATE_ROOT / "drafts"),
    }


def release_snapshot() -> dict[str, Any]:
    current = CURRENT_LINK.resolve(strict=True)
    try:
        current.relative_to(RELEASE_ROOT.resolve(strict=True))
    except ValueError as exc:
        raise GateError("current release falls outside the immutable release root") from exc
    verification = verify_manifested_tree(current, "SHA256SUMS.txt", EXPECTED_MANIFEST_SHA256)
    metadata = current.stat()
    mode = stat.S_IMODE(metadata.st_mode)
    if metadata.st_uid != 0 or metadata.st_gid != 0 or mode & 0o222:
        raise GateError("current release is not root-owned and read-only")
    return {
        "currentRelease": str(current),
        "currentReleaseName": current.name,
        "ownerUid": metadata.st_uid,
        "ownerGid": metadata.st_gid,
        "mode": format(mode, "04o"),
        **verification,
    }


def runtime_snapshot() -> dict[str, Any]:
    service = service_snapshot()
    return {
        "capturedAtUtc": utc_now(),
        "release": release_snapshot(),
        "service": service,
        "serviceCgroup": cgroup_snapshot(service),
        "health": {
            "live": health_snapshot("/health/live"),
            "ready": health_snapshot("/health/ready"),
        },
        "stateCounts": state_counts(),
    }


def privileged_stat(path: Path) -> dict[str, Any]:
    output = str(run(["stat", "-Lc", "%i|%s|%f", str(path)], privileged=True)).strip()
    inode, size, raw_mode = output.split("|", 2)
    if not stat.S_ISREG(int(raw_mode, 16)):
        raise GateError(f"log is not a regular file: {path}")
    return {"path": str(path), "inode": int(inode), "size": int(size)}


def nginx_log_cursor() -> dict[str, Any]:
    for path in NGINX_LOG_CANDIDATES:
        result = subprocess.run(["sudo", "-n", "test", "-f", str(path)], check=False)
        if result.returncode == 0:
            return privileged_stat(path)
    raise GateError("no supported Nginx access log exists")


def normalize_route(raw_target: str) -> str:
    try:
        path = urllib.parse.urlsplit(raw_target).path
        path = urllib.parse.unquote(path)
    except (ValueError, UnicodeError):
        return "<invalid-route>"
    replacements = (
        (r"^/api/jobs/[^/]+/status$", "/api/jobs/{jobId}/status"),
        (r"^/api/jobs/[^/]+/download/[^/]+$", "/api/jobs/{jobId}/download/{filename}"),
        (r"^/api/materials/image/[^/]+/[^/]+$", "/api/materials/image/{materialId}/{variant}"),
    )
    for pattern, replacement in replacements:
        if re.fullmatch(pattern, path):
            return replacement
    return path or "/"


def summarize_http_log(raw: bytes) -> dict[str, Any]:
    text = raw.decode("utf-8", "replace")
    route_counter: Counter[tuple[str, str, int]] = Counter()
    iphone_safari = 0
    parsed_lines = 0
    for line in text.splitlines():
        match = re.search(r'"(GET|POST|PUT|PATCH|DELETE|OPTIONS|HEAD)\s+(\S+)\s+HTTP/[0-9.]+"\s+(\d{3})', line)
        if not match:
            continue
        parsed_lines += 1
        method, target, raw_status = match.groups()
        route_counter[(method, normalize_route(target), int(raw_status))] += 1
        lowered = line.lower()
        if (
            "iphone" in lowered
            and "mobile/" in lowered
            and "safari/" in lowered
            and not any(marker in lowered for marker in ("crios/", "fxios/", "edgios/", "opios/"))
        ):
            iphone_safari += 1
    routes = [
        {"method": method, "path": path, "status": status, "count": count}
        for (method, path, status), count in sorted(route_counter.items())
    ]
    return {
        "rawBytes": len(raw),
        "rawSha256": sha256_bytes(raw),
        "lineCount": len(text.splitlines()),
        "parsedRequestLineCount": parsed_lines,
        "iphoneSafariRequestCount": iphone_safari,
        "http4xxCount": sum(item["count"] for item in routes if 400 <= item["status"] < 500),
        "http5xxCount": sum(item["count"] for item in routes if item["status"] >= 500),
        "routes": routes,
    }


def read_nginx_delta(cursor: dict[str, Any]) -> tuple[dict[str, Any], bool]:
    path = Path(str(cursor["path"]))
    current = privileged_stat(path)
    stable = current["inode"] == int(cursor["inode"]) and current["size"] >= int(cursor["size"])
    if not stable:
        return {
            "startCursor": cursor,
            "endCursor": current,
            "cursorStable": False,
            "rawBytes": 0,
            "rawSha256": sha256_bytes(b""),
            "lineCount": 0,
            "parsedRequestLineCount": 0,
            "iphoneSafariRequestCount": 0,
            "http4xxCount": 0,
            "http5xxCount": 0,
            "routes": [],
        }, False
    byte_count = current["size"] - int(cursor["size"])
    if byte_count > MAX_LOG_DELTA_BYTES:
        raise GateError("Nginx log delta exceeds the bounded maximum")
    raw = bytes(run(
        [
            "dd",
            f"if={path}",
            "iflag=skip_bytes,count_bytes",
            f"skip={int(cursor['size'])}",
            f"count={byte_count}",
            "status=none",
        ],
        privileged=True,
        binary=True,
    ))
    if len(raw) != byte_count:
        raise GateError("Nginx log changed while its bounded delta was read")
    summary = summarize_http_log(raw)
    summary.update({"startCursor": cursor, "endCursor": current, "cursorStable": True})
    return summary, True


def journal_summary(start_epoch: int, end_epoch: int) -> dict[str, Any]:
    raw = bytes(run(
        [
            "journalctl",
            "-u",
            SERVICE,
            "--since",
            f"@{start_epoch}",
            "--until",
            f"@{end_epoch}",
            "--no-pager",
            "-o",
            "cat",
        ],
        privileged=True,
        binary=True,
    ))
    if len(raw) > MAX_LOG_DELTA_BYTES:
        raise GateError("service journal delta exceeds the bounded maximum")
    return summarize_http_log(raw)


def route_occurrences(routes: list[dict[str, Any]], method: str, path: str, accepted: list[int]) -> int:
    return sum(
        int(item["count"])
        for item in routes
        if item["method"] == method and item["path"] == path and int(item["status"]) in accepted
    )


def required_route_checks(contract: dict[str, Any], routes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    for item in contract["requiredPublicRoutes"]:
        actual = route_occurrences(routes, item["method"], item["path"], item["acceptedStatuses"])
        minimum = int(item["minimum"])
        checks.append({
            "id": f"route:{item['method']} {item['path']}",
            "status": "PASS" if actual >= minimum else "FAIL",
            "actual": actual,
            "minimum": minimum,
            "acceptedStatuses": item["acceptedStatuses"],
        })
    return checks


def boolean_check(identifier: str, passed: bool, actual: Any, expected: Any) -> dict[str, Any]:
    return {
        "id": identifier,
        "status": "PASS" if passed else "FAIL",
        "actual": actual,
        "expected": expected,
    }


def evidence_manifest(evidence: Path) -> None:
    manifest = evidence / "SHA256SUMS.txt"
    files = regular_files(evidence, {"SHA256SUMS.txt"})
    lines = [f"{sha256_file(evidence / relative)}  {relative}" for relative in files]
    atomic_text(manifest, "\n".join(lines) + "\n")


def verify_evidence(evidence: Path) -> dict[str, Any]:
    verification = verify_manifested_tree(evidence, "SHA256SUMS.txt")
    required = {
        "FIX30_IPHONE_R1_START.json",
        "FIX30_IPHONE_R1_END.json",
        "FIX30_IPHONE_R1_ROUTE_SUMMARY.json",
        "FIX30_IPHONE_R1_SERVER_ACCEPTANCE.json",
        "FIX30_PHYSICAL_IPHONE_SAFARI_GATE_CONTRACT.json",
        "PHYSICAL_IPHONE_SAFARI_CHECKLIST_NL.md",
    }
    actual = set(regular_files(evidence, {"SHA256SUMS.txt"}))
    if actual != required:
        raise GateError(f"unexpected evidence fileset: {sorted(actual)}")
    acceptance = json.loads((evidence / "FIX30_IPHONE_R1_SERVER_ACCEPTANCE.json").read_text(encoding="utf-8"))
    if acceptance.get("gateId") != GATE_ID:
        raise GateError("unexpected evidence gate identity")
    if acceptance.get("candidateManifestSha256") != EXPECTED_MANIFEST_SHA256:
        raise GateError("evidence does not bind exact FIX30")
    return {**verification, "serverCaptureStatus": acceptance.get("status")}


def write_evidence_zip(evidence: Path, output: Path) -> None:
    fd, raw_tmp = tempfile.mkstemp(prefix=f".{output.name}.", dir=str(output.parent))
    os.close(fd)
    tmp = Path(raw_tmp)
    try:
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(evidence.rglob("*")):
                if not path.is_file() or path.is_symlink():
                    continue
                relative = PurePosixPath("evidence") / PurePosixPath(path.relative_to(evidence).as_posix())
                info = zipfile.ZipInfo(relative.as_posix(), date_time=time.localtime(path.stat().st_mtime)[:6])
                info.create_system = 3
                info.external_attr = 0o100600 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                with path.open("rb") as source:
                    archive.writestr(info, source.read())
        os.chmod(tmp, 0o600)
        os.replace(tmp, output)
    finally:
        if tmp.exists():
            tmp.unlink()


def start(package_root: Path) -> int:
    require_commands(("sudo", "systemctl", "find", "stat", "dd", "journalctl"))
    package_verification = verify_package(package_root)
    run(["true"], privileged=True)
    home = safe_home()
    active_file = home / ACTIVE_FILE_NAME
    if active_file.exists():
        existing = active_file.read_text(encoding="utf-8").strip()
        raise GateError(f"an iPhone capture is already active: {existing}")

    audit_root = Path(tempfile.mkdtemp(prefix=AUDIT_PREFIX, dir=str(home)))
    os.chmod(audit_root, 0o700)
    collector = audit_root / "collector"
    shutil.copytree(package_root, collector)
    for path in collector.rglob("*"):
        if path.is_file():
            os.chmod(path, 0o700 if path.suffix == ".sh" else 0o600)
        elif path.is_dir():
            os.chmod(path, 0o700)
    verify_package(collector)

    started_epoch = int(time.time())
    preview_origin = strict_https_origin(read_privileged_text(PREVIEW_URL_FILE))
    snapshot = runtime_snapshot()
    if snapshot["serviceCgroup"]["onlyMainPid"] is not True:
        raise GateError("service is not quiescent before the physical test")
    cursor = nginx_log_cursor()
    start_record = {
        "schemaVersion": 1,
        "gateId": GATE_ID,
        "phase": "START",
        "status": "PASS",
        "startedAtUtc": utc_now(),
        "startedEpoch": started_epoch,
        "previewOrigin": preview_origin,
        "package": package_verification,
        "runtime": snapshot,
        "nginxAccessCursor": cursor,
        "privacy": {
            "rawRequestBodiesCollected": False,
            "credentialsRead": False,
            "rawLogsPersisted": False,
        },
    }
    evidence = audit_root / "evidence"
    evidence.mkdir(mode=0o700)
    atomic_json(evidence / "FIX30_IPHONE_R1_START.json", start_record)
    atomic_text(active_file, str(audit_root) + "\n")
    cache_token = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    open_url = f"{preview_origin}?fix30=iphone-r1-{cache_token}"
    finish_command = f'AUDIT="$(cat "$HOME/{ACTIVE_FILE_NAME}")" && bash "$AUDIT/collector/operations/FINISH_FIX30_PHYSICAL_IPHONE_SAFARI_GATE.sh"'
    print("FIX30_IPHONE_SAFARI_R1_START=PASS")
    print(f"AUDIT_ROOT={audit_root}")
    print(f"OPEN={open_url}")
    print(f"FINISH={finish_command}")
    print("PHYSICAL_GATE=PENDING_IPHONE_RUN_AND_MEDIA_REVIEW")
    return 0


def finish() -> int:
    require_commands(("sudo", "systemctl", "find", "stat", "dd", "journalctl"))
    run(["true"], privileged=True)
    home = safe_home()
    active_file = home / ACTIVE_FILE_NAME
    if active_file.is_symlink() or not active_file.is_file():
        raise GateError("no active iPhone capture exists")
    audit_root = safe_audit_root(active_file.read_text(encoding="utf-8").strip(), home)
    evidence = audit_root / "evidence"
    collector = audit_root / "collector"
    package_verification = verify_package(collector)
    start_path = evidence / "FIX30_IPHONE_R1_START.json"
    start_record = json.loads(start_path.read_text(encoding="utf-8"))
    if start_record.get("gateId") != GATE_ID or start_record.get("status") != "PASS":
        raise GateError("invalid start record")
    start_epoch = int(start_record["startedEpoch"])
    end_epoch = int(time.time())
    duration = end_epoch - start_epoch
    if duration < 1 or duration > MAX_CAPTURE_SECONDS:
        raise GateError(f"capture duration is outside 1..{MAX_CAPTURE_SECONDS} seconds")

    end_runtime = runtime_snapshot()
    nginx_summary, cursor_stable = read_nginx_delta(start_record["nginxAccessCursor"])
    journal = journal_summary(start_epoch, end_epoch)
    contract_path = collector / "contracts/FIX30_PHYSICAL_IPHONE_SAFARI_GATE_CONTRACT.json"
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    start_runtime = start_record["runtime"]

    checks = [
        boolean_check(
            "exact-release-path-unchanged",
            start_runtime["release"]["currentRelease"] == end_runtime["release"]["currentRelease"],
            end_runtime["release"]["currentRelease"],
            start_runtime["release"]["currentRelease"],
        ),
        boolean_check(
            "exact-fix30-manifest-before-after",
            start_runtime["release"]["manifestSha256"] == end_runtime["release"]["manifestSha256"] == EXPECTED_MANIFEST_SHA256,
            end_runtime["release"]["manifestSha256"],
            EXPECTED_MANIFEST_SHA256,
        ),
        boolean_check(
            "release-tree-byte-unchanged",
            start_runtime["release"]["verifiedTreeSha256"] == end_runtime["release"]["verifiedTreeSha256"],
            end_runtime["release"]["verifiedTreeSha256"],
            start_runtime["release"]["verifiedTreeSha256"],
        ),
        boolean_check(
            "service-remained-active",
            end_runtime["service"]["activeState"] == "active" and end_runtime["service"]["subState"] == "running",
            [end_runtime["service"]["activeState"], end_runtime["service"]["subState"]],
            ["active", "running"],
        ),
        boolean_check(
            "service-not-restarted",
            start_runtime["service"]["mainPid"] == end_runtime["service"]["mainPid"]
            and start_runtime["service"]["nRestarts"] == end_runtime["service"]["nRestarts"]
            and start_runtime["service"]["execMainStartTimestampMonotonic"] == end_runtime["service"]["execMainStartTimestampMonotonic"],
            {
                "mainPid": end_runtime["service"]["mainPid"],
                "nRestarts": end_runtime["service"]["nRestarts"],
                "started": end_runtime["service"]["execMainStartTimestampMonotonic"],
            },
            {
                "mainPid": start_runtime["service"]["mainPid"],
                "nRestarts": start_runtime["service"]["nRestarts"],
                "started": start_runtime["service"]["execMainStartTimestampMonotonic"],
            },
        ),
        boolean_check(
            "health-live-ready-after",
            end_runtime["health"]["live"]["ok"] is True and end_runtime["health"]["ready"]["ok"] is True,
            [end_runtime["health"]["live"]["ok"], end_runtime["health"]["ready"]["ok"]],
            [True, True],
        ),
        boolean_check("nginx-log-cursor-stable", cursor_stable, cursor_stable, True),
        boolean_check(
            "physical-iphone-safari-observed",
            nginx_summary["iphoneSafariRequestCount"] >= 1,
            nginx_summary["iphoneSafariRequestCount"],
            ">=1",
        ),
        boolean_check(
            "no-server-http-5xx",
            nginx_summary["http5xxCount"] == 0 and journal["http5xxCount"] == 0,
            {"nginx": nginx_summary["http5xxCount"], "service": journal["http5xxCount"]},
            {"nginx": 0, "service": 0},
        ),
        boolean_check(
            "only-service-main-pid-remains",
            end_runtime["serviceCgroup"]["onlyMainPid"] is True,
            end_runtime["serviceCgroup"],
            {"onlyMainPid": True},
        ),
    ]
    checks.extend(required_route_checks(contract, nginx_summary["routes"]))
    server_status = "PASS" if all(item["status"] == "PASS" for item in checks) else "FAIL"

    route_summary = {
        "schemaVersion": 1,
        "gateId": GATE_ID,
        "captureStartedAtUtc": start_record["startedAtUtc"],
        "captureFinishedAtUtc": utc_now(),
        "captureDurationSeconds": duration,
        "nginx": nginx_summary,
        "serviceJournal": journal,
        "privacy": {
            "rawLogsPersisted": False,
            "requestBodiesCollected": False,
            "clientIpAddressesPersisted": False,
            "rawCapabilitiesPersisted": False,
        },
    }
    end_record = {
        "schemaVersion": 1,
        "gateId": GATE_ID,
        "phase": "END",
        "status": "PASS",
        "finishedAtUtc": utc_now(),
        "finishedEpoch": end_epoch,
        "runtime": end_runtime,
        "collectorPackage": package_verification,
    }
    acceptance = {
        "schemaVersion": 1,
        "gateId": GATE_ID,
        "status": server_status,
        "candidateManifestSha256": EXPECTED_MANIFEST_SHA256,
        "browserOracleCommit": EXPECTED_BROWSER_ORACLE_COMMIT,
        "checks": checks,
        "failedCheckIds": [item["id"] for item in checks if item["status"] != "PASS"],
        "screenRecordingReviewStatus": "PENDING",
        "physicalIphoneSafariGate": "PENDING_PHYSICAL_MEDIA_REVIEW",
        "productionGo": False,
    }
    atomic_json(evidence / "FIX30_IPHONE_R1_END.json", end_record)
    atomic_json(evidence / "FIX30_IPHONE_R1_ROUTE_SUMMARY.json", route_summary)
    atomic_json(evidence / "FIX30_IPHONE_R1_SERVER_ACCEPTANCE.json", acceptance)
    shutil.copyfile(contract_path, evidence / contract_path.name)
    shutil.copyfile(
        collector / "docs/PHYSICAL_IPHONE_SAFARI_CHECKLIST_NL.md",
        evidence / "PHYSICAL_IPHONE_SAFARI_CHECKLIST_NL.md",
    )
    for path in evidence.iterdir():
        if path.is_file():
            os.chmod(path, 0o600)
    evidence_manifest(evidence)
    verification = verify_evidence(evidence)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = home / f"FIX30_PHYSICAL_IPHONE_SAFARI_R1_SERVER_EVIDENCE_{timestamp}.zip"
    if output.exists():
        raise GateError(f"refusing to overwrite existing evidence archive: {output}")
    write_evidence_zip(evidence, output)
    archive_sha = sha256_file(output)
    active_file.unlink()
    print(f"FIX30_IPHONE_SAFARI_R1_SERVER_CAPTURE={server_status}")
    print(f"EVIDENCE_FILESET={verification['fileCount']}")
    print(f"UPLOAD={output}")
    print(f"EVIDENCE_SHA256={archive_sha}")
    print("PHYSICAL_GATE=PENDING_SCREEN_RECORDING_REVIEW")
    return 0 if server_status == "PASS" else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    verify_package_parser = subparsers.add_parser("verify-package")
    verify_package_parser.add_argument("--package-root", type=Path, required=True)
    start_parser = subparsers.add_parser("start")
    start_parser.add_argument("--package-root", type=Path, required=True)
    verify_parser = subparsers.add_parser("verify-evidence")
    verify_parser.add_argument("--evidence", type=Path, required=True)
    subparsers.add_parser("finish")
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    if arguments.command == "verify-package":
        result = verify_package(arguments.package_root)
        print(f"FIX30_IPHONE_R1_PACKAGE=PASS FILES={result['fileCount']}")
        return 0
    if arguments.command == "start":
        return start(arguments.package_root.resolve(strict=True))
    if arguments.command == "finish":
        return finish()
    if arguments.command == "verify-evidence":
        result = verify_evidence(arguments.evidence.resolve(strict=True))
        print(f"FIX30_IPHONE_R1_EVIDENCE=PASS FILES={result['fileCount']} SERVER={result['serverCaptureStatus']}")
        return 0
    raise GateError("unknown command")


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (GateError, json.JSONDecodeError, OSError, ValueError) as exc:
        print(f"FIX30 IPHONE SAFARI R1 FOUT: {exc}", file=sys.stderr)
        raise SystemExit(1)
