# Fysieke iPhone-Safari-checklist

## Voorbereiding

- Gebruik de echte Safari-app in portretstand, niet Chrome of een homescreen-PWA.
- Sluit oude Tool A-tabs.
- Start de iOS-schermopname voordat je de door `START` getoonde URL opent.
- Laat adresbalk, eerste paginalading en alle vijf stappen in één opname zien.
- Gebruik uitsluitend onderstaande synthetische klantgegevens.

## Uit te voeren route

1. Open de unieke `OPEN=`-URL en kies een nieuwe configuratie.
2. Selecteer twee duidelijk verschillende materialen.
3. Open `Jouw materialen`, activeer verwijderen en bevestig met de rode knop.
4. Bewijs dat het materiaal werkelijk weg is en voeg het daarna opnieuw toe.
5. Voeg minimaal twee standaardpanelen van meer dan één soort toe.
6. Voeg minimaal één `Overig paneel` toe en koppel dit aan het tweede materiaal.
7. Open de mobiele paneellijst en film dat beide materialen met hun eigen
   standaard-/overige panelen herkenbaar en correct gegroepeerd zijn.
8. Maak een nerfgroep met twee panelen.
9. Open `Nerf-preview`, sluit hem, wijzig de paneelvolgorde met de mobiele
   bediening en open de preview opnieuw.
10. Pas de nerfgroep toe en ga naar `Gegevens`.
11. Vul exact deze synthetische waarden in:

    - Voornaam: `FIX30`
    - Achternaam: `iPhone`
    - Bedrijf: `Adzaagt acceptatietest`
    - E-mail: `fix30-iphone@example.invalid`
    - Telefoon: `0612345678`
    - Factuuradres: `Bewijsstraat`
    - Huisnummer: `42-A`
    - Postcode: `1234 AB`
    - Plaats: `Utrecht`
    - Land: `Nederland`

12. Ga naar het overzicht en film klant-, materiaal- en paneelgegevens.
13. Start optimaliseren. Film minimaal drie verschillende oplopende percentages,
    waaronder de uiteindelijke `100%`, zonder hangende overlay.
14. Film in checkout dat persoonlijk, contact, adres, beide materialen, alle
    standaardpanelen, het overige paneel, controles en positieve prijs aanwezig
    zijn.
15. Verzend de synthetische aanvraag en film de bedankpagina.
16. Start een nieuwe configuratie en bewijs dat oude klantgegevens verdwenen zijn.
17. Herlaad Safari eenmaal en bewijs dat Tool A bruikbaar terugkomt.
18. Stop pas daarna de schermopname en voer de `FINISH=`-regel uit.

## Handmatige PASS-criteria

- Geen inerte knop, onverwachte foutmelding, horizontale layoutbreuk of blokkade.
- Verwijderen en opnieuw toevoegen van materiaal werkt met touch.
- Twee materialen en hun paneeleigenaarschap zijn op mobiel ondubbelzinnig.
- Standaardpanelen en overige panelen zijn volledig aanwezig.
- Nerf-preview is vindbaar, opent, sluit en rendert na herschikken opnieuw.
- De optimalisatie-overlay toont monotone echte voortgang tot 100%.
- Checkout bevat alle synthetische klant-, materiaal- en paneelgegevens.
- De serverprijs is positief en de aanvraag eindigt op de bedankpagina.
- Nieuwe configuratie wist de oude klantgegevens uit de zichtbare UI.
