#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

SCRIPT_PATH="$(readlink -f "$0")"
PACKAGE_ROOT="$(cd "$(dirname "$SCRIPT_PATH")/.." && pwd -P)"
/usr/bin/python3 -I -S -B "$PACKAGE_ROOT/tools/fix30_iphone_safari_gate.py" \
  verify-package --package-root "$PACKAGE_ROOT"
exec /usr/bin/python3 -I -S -B "$PACKAGE_ROOT/tools/fix30_iphone_safari_gate.py" \
  start --package-root "$PACKAGE_ROOT"
