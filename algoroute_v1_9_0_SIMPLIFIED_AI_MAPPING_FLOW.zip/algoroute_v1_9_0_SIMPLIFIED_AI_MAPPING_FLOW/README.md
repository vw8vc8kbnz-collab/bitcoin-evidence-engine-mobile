# AlgoRoute v1.9.0 — Simplified AI Mapping Flow

- Nieuwe simpele Planning flow: Import → Controlecentrum → Routes klaar.
- Smart Mapping voelt meer AI: semantische hints, waardenherkenning, conflict-resolutie en alleen twijfelgevallen tonen.
- Import probeert nu automatisch PDOK/BAG geocoding voordat de gebruiker optimaliseert.
- Controlecentrum toont bruikbare status: mapping, GPS/adressen en route-readiness.
- Queue blijft intern bestaan, maar voelt minder als debug-scherm.
