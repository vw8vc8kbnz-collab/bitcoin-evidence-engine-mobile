# Technische overdracht — METOD/PAX Tool A FIX655

## 1. Doel
FIX655 is een gerichte vervolgcorrectie op FIX654 na live acceptatie. Het uitgangspunt is dat de productie-outputfinalisatie van FIX654 wordt behouden, terwijl twee resterende problemen worden opgelost:

1. **Overview kon nog leeg/wit openen** door meerdere concurrerende legacy render/open-paden.
2. **`Aanvraag voorbereiden…` kon lang op ~1% blijven** doordat de browser grote embedded DXF's herhaaldelijk parseerde/transformeerde en identieke tekst per PartId naar `/api/jobs` stuurde.

De nesting-engine zelf is niet gewijzigd.

## 2. Belangrijkste auditbevindingen uit FIX654

### 2.1 Wat FIX654 werkelijk had aangepast
In `server_py.py` waren aanwezig:
- `_finalize_subjob_outputs`
- `DXF_Zaagplaten`
- `DXF_Onderdelen`
- `_generate_stickertool_json`
- `finalization.json`
- recovery van subjob/output-links richting Admin.

Dit sluit aan op de live observatie dat na lang wachten opnieuw een DXF-plaatindeling aan de Admin-job hing.

### 2.2 Waarom Overview desondanks wit kon blijven
`toolA.html` bevatte tegelijk meerdere routes, onder andere:
- `openOverview()`
- een tweede `openOverview()` in een later blok
- `openOverviewHard()`
- meerdere click/capture-bindings
- `renderOverview()`
- `renderOverviewSafe()`
- `renderOverviewSimple()`

FIX654 probeerde fallback-rendering toe te voegen, maar maakte die niet tot de enige eigenaar van het renderpad. Bovendien zette die functie `window.__TOOLA_OVERVIEW_RENDER_OK = true` uiteindelijk onvoorwaardelijk, waardoor de marker geen betrouwbare bewijswaarde had.

### 2.3 Waarom de voorbereiding nog lang kon duren
Voor iedere METOD-cartregel gebeurde in de oude route in essentie opnieuw:
1. embedded DXF ophalen/lezen;
2. tekst in code/value-pairs parsen;
3. layers classificeren/relayeren;
4. spiegelen/verlenging uitvoeren;
5. terug naar DXF-tekst serialiseren;
6. volledige tekst onder die PartId in JSON opnemen.

Bij identieke fronten werd dezelfde geometrie dus vaak herhaald.

## 3. FIX655 Overview-controller
Nieuw bestand:

`app/toolA_overview_fix655.js`

Buildmarker:

`FIX655_OVERVIEW_SINGLE_CONTROLLER`

### 3.1 Eigenaarschap
Na laden worden de publieke APIs expliciet toegewezen:
- `window.__FIX655_RENDER_OVERVIEW__`
- `window.renderOverviewSafe`
- `window.openOverviewOverlay`
- `window.closeOverviewOverlay`

De oude lokale `renderOverviewSafe()` in `toolA.html` bevat daarnaast een vroege delegatie naar `window.__FIX655_RENDER_OVERVIEW__`.

### 3.2 Eventstrategie
Een document-level **capture** listener behandelt:
- `#overviewBtn`
- `#wizardOverviewBtn`
- `#priceBarBtnOverview`
- `#overviewCloseBtn`
- `#overviewBackBtn`
- `#overviewNextBtn`
- FIX655 material tabs
- FIX655 delete controls

Hierdoor kan een oude target-level handler niet eerst een concurrerende renderroute uitvoeren.

### 3.3 Mutation recovery
De overlay wordt geobserveerd. Als een legacy/programmatic route hem alsnog zichtbaar maakt, volgt een nieuwe renderpass via `requestAnimationFrame`.

### 3.4 Privacy
Materiaallabels gebruiken alleen klantveilige naamvelden:
- `publicName`
- `displayName`
- `productName`
- `decorName`

Geen fallback naar material key/article/code.

## 4. Client-side DXF voorbereiding
In `toolA.html`:

- `_DXF_TEXT_CACHE`
- `_DXF_TEXT_PROMISE_CACHE`
- `_DXF_CLASSIFIED_PAIR_CACHE`
- `_DXF_TRANSFORMED_TEXT_CACHE`
- `getClassifiedDxfPairs()`
- `prewarmDxfSourcesForItems()`

### 4.1 Cache keys
De uiteindelijke geometriecache gebruikt:

`[sourceName, hinge, extTop, extBot]`

Materiaal hoeft daar niet in omdat die velden de CNC-geometrie niet wijzigen.

### 4.2 Prewarm
Alle unieke `sourceName` waarden in de order worden vooraf voorbereid met maximaal vier workers. Hierdoor worden tientallen identieke fronten niet tientallen keren opnieuw geparsed.

## 5. Compact DXF payload
Schema:

`FIX655_DXF_REF_V1`

Client verstuurt:

```json
{
  "dxfBlobs": {
    "g0001": "<DXF tekst>"
  },
  "dxfPartRefs": {
    "part_a": "g0001",
    "part_b": "g0001"
  }
}
```

Dus iedere unieke getransformeerde DXF slechts eenmaal.

Serverfunctie:

`_expand_dxf_payload(payload)`

Deze ondersteunt tevens de oude `dxfParts`-vorm.

Validatie:
- PartId regex `[A-Za-z0-9_-]+`, maximaal 80 chars;
- blob-id begrensd/gevalideerd;
- lege geometrie verboden;
- referentie naar onbekende blob verboden;
- blob byte-limit via `PUBLIC_DXF_BLOB_MAX_BYTES` (deploy: 2 MB).

## 6. Server subjob I/O
Masterjob blijft alle `PartId.dxf` bestanden krijgen.

Voor elke material subjob:
1. `panels.csv` wordt op MaterialCode gefilterd;
2. alleen de daarin voorkomende PartIds worden bepaald;
3. alleen die DXF-bestanden worden gekoppeld;
4. `os.link()` wordt geprobeerd;
5. bij falen volgt normale `_write_file()`.

Dit verandert het Tool B contract niet, maar voorkomt het herhaald schrijven van irrelevante ordergeometrie naar iedere material subjob.

## 7. Outputfinalisatie
FIX654 blijft de basis:
- optimizer draait per materiaal;
- daarna `_finalize_subjob_outputs()`;
- finalization moet COMPLETE zijn;
- Admin kan DXF_Zaagplaten / DXF_Onderdelen / StickerTool terugvinden.

FIX655 mag deze keten niet vervangen door een nieuwe optimizer.

## 8. Library first paint
`decor_library.js` build:

`FIX655_LIBRARY_RUNTIME_FAST_FIRST_PAINT`

Parameters:
- `INITIAL_VISIBLE = 16`
- `CHUNK_SIZE = 24`
- `EAGER_IMAGE_COUNT = 8`

De eerste acht afbeeldingen krijgen eager/high priority. De rest blijft lazy.

Pillow is optioneel. Op de huidige VPS was Pillow tijdens FIX654 niet beschikbaar; de app moet daarom correct blijven werken met lokale `catalog.img` fallback.

## 9. Belangrijke ongewijzigde contracten
Niet wijzigen zonder expliciete nieuwe scope:
- CSV-only active catalog.
- Alleen 18/19/20 mm.
- Directe CSV verkoopprijs incl. BTW als materiaalprijs.
- Geen algemene materiaalfactor.
- Overige Admin-kosten blijven instelbaar.
- Artikelnummer nooit publiek; opaque `decor_...` IDs.
- FIX644/FIX645 keyboardgedrag Stap 2.
- Verticale mobiele grain-flow / FIX650 preview fix.

## 10. Performance benchmark
Met de echte embedded `Metod deur 60x80.dxf`:
- bron: 106,281 bytes;
- 100 identieke fronten legacy transport: 12,426,514 bytes JSON;
- compact: 126,228 bytes JSON;
- reductie: 98.98%, circa 98.4×.

Dit meet het client→server DXF-transport. Het is geen garantie voor de rekentijd van Tool B zelf.

## 11. Gevalideerde serverregressie
Een lokale 2-materiaal test met één gedeelde echte DXF-blob gaf:
- 2 subjobs;
- subjob A alleen `p001.dxf`;
- subjob B alleen `p002.dxf`;
- beide finalization `COMPLETE`;
- beide `DXF_Zaagplaten` aanwezig;
- beide `stickertool.json` aanwezig;
- circa 1.54 s voor deze kleine testomgeving.

## 12. Deploy
Releasebestand:

`METOD_PAX_FIX655_OVERVIEW_PERFORMANCE_FIX.zip`

Deployscript:

`DEPLOY_FIX655.sh`

De one-shot installer moet live runtimegegevens behouden:
- jobs
- requests
- queue
- archive
- backups
- drafts
- system/catalog import history/public ID registry
- decor_media
- material_library.json
- pricing_active + pricing history/audit
- live embedded DXF library/manifest

## 13. Live acceptatie
Lokale tests kunnen de VPS/browser niet vervangen. Controleer na deploy:
1. Overview met echte panelen.
2. Tijd die de overlay in DXF/panel-prep doorbrengt.
3. Volledige job tot prijsresultaat.
4. Admin DXF_Zaagplaten.
5. Admin DXF_Onderdelen.
6. StickerTool.
7. Meerdere materialen in één order.
8. Eerste library paint.
