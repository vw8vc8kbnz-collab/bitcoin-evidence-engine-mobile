import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

DATA_PATH = Path(os.environ.get("ALGOROUTE_DATA", "/app/data/algoroute_store.json"))

app = FastAPI(title="AlgoRoute API", version="0.7.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class VehicleIn(BaseModel):
    code: str = Field(min_length=1)
    license_plate: str = Field(min_length=4)
    brand: str = ""
    model: str = ""
    vehicle_type: str = ""
    status: str = "available"
    maintenance_until: Optional[str] = None
    max_weight_kg: int = 0
    euro_pallets: int = 0
    roll_containers: int = 0
    notes: str = ""

class TransportUnitIn(BaseModel):
    name: str = Field(min_length=1)
    length_mm: int = 0
    width_mm: int = 0
    height_mm: int = 0
    max_weight_kg: int = 0
    active: bool = True


def default_store() -> dict[str, Any]:
    return {"vehicles": [], "transport_units": []}


def read_store() -> dict[str, Any]:
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not DATA_PATH.exists():
        write_store(default_store())
    try:
        return json.loads(DATA_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        broken = DATA_PATH.with_suffix(".broken.json")
        DATA_PATH.rename(broken)
        store = default_store()
        write_store(store)
        return store


def write_store(store: dict[str, Any]) -> None:
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = DATA_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(DATA_PATH)


def norm_plate(value: str) -> str:
    return value.strip().upper().replace(" ", "").replace("-", "")

@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": "0.7.0", "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/bootstrap")
def bootstrap():
    store = read_store()
    return {
        "vehicles": store.get("vehicles", []),
        "transport_units": store.get("transport_units", []),
        "stats": calc_stats(store),
    }

@app.get("/api/vehicles")
def list_vehicles():
    return read_store().get("vehicles", [])

@app.post("/api/vehicles")
def create_vehicle(payload: VehicleIn):
    store = read_store()
    vehicles = store.setdefault("vehicles", [])
    plate = norm_plate(payload.license_plate)
    if any(norm_plate(v.get("license_plate", "")) == plate for v in vehicles):
        raise HTTPException(409, detail="Kenteken bestaat al")
    vehicle = payload.model_dump()
    vehicle["id"] = "veh_" + uuid.uuid4().hex[:10]
    vehicles.append(vehicle)
    write_store(store)
    return vehicle

@app.put("/api/vehicles/{vehicle_id}")
def update_vehicle(vehicle_id: str, payload: VehicleIn):
    store = read_store()
    vehicles = store.setdefault("vehicles", [])
    idx = next((i for i, v in enumerate(vehicles) if v.get("id") == vehicle_id), None)
    if idx is None:
        raise HTTPException(404, detail="Voertuig niet gevonden")
    plate = norm_plate(payload.license_plate)
    if any(v.get("id") != vehicle_id and norm_plate(v.get("license_plate", "")) == plate for v in vehicles):
        raise HTTPException(409, detail="Kenteken bestaat al")
    updated = payload.model_dump()
    updated["id"] = vehicle_id
    vehicles[idx] = updated
    write_store(store)
    return updated

@app.delete("/api/vehicles/{vehicle_id}")
def delete_vehicle(vehicle_id: str):
    store = read_store()
    vehicles = store.setdefault("vehicles", [])
    before = len(vehicles)
    store["vehicles"] = [v for v in vehicles if v.get("id") != vehicle_id]
    if len(store["vehicles"]) == before:
        raise HTTPException(404, detail="Voertuig niet gevonden")
    write_store(store)
    return {"ok": True}

@app.get("/api/transport-units")
def list_units():
    return read_store().get("transport_units", [])

@app.post("/api/transport-units")
def create_unit(payload: TransportUnitIn):
    store = read_store()
    units = store.setdefault("transport_units", [])
    unit = payload.model_dump()
    unit["id"] = "tu_" + uuid.uuid4().hex[:10]
    units.append(unit)
    write_store(store)
    return unit

@app.put("/api/transport-units/{unit_id}")
def update_unit(unit_id: str, payload: TransportUnitIn):
    store = read_store()
    units = store.setdefault("transport_units", [])
    idx = next((i for i, u in enumerate(units) if u.get("id") == unit_id), None)
    if idx is None:
        raise HTTPException(404, detail="Transport unit niet gevonden")
    unit = payload.model_dump()
    unit["id"] = unit_id
    units[idx] = unit
    write_store(store)
    return unit

@app.delete("/api/transport-units/{unit_id}")
def delete_unit(unit_id: str):
    store = read_store()
    units = store.setdefault("transport_units", [])
    before = len(units)
    store["transport_units"] = [u for u in units if u.get("id") != unit_id]
    if len(store["transport_units"]) == before:
        raise HTTPException(404, detail="Transport unit niet gevonden")
    write_store(store)
    return {"ok": True}


def calc_stats(store: dict[str, Any]) -> dict[str, Any]:
    vehicles = store.get("vehicles", [])
    available = sum(1 for v in vehicles if v.get("status") == "available")
    maintenance = sum(1 for v in vehicles if v.get("status") == "maintenance")
    unavailable = sum(1 for v in vehicles if v.get("status") == "unavailable")
    return {
        "vehicles_total": len(vehicles),
        "vehicles_available": available,
        "vehicles_maintenance": maintenance,
        "vehicles_unavailable": unavailable,
        "euro_pallet_capacity": sum(int(v.get("euro_pallets") or 0) for v in vehicles if v.get("status") == "available"),
        "roll_container_capacity": sum(int(v.get("roll_containers") or 0) for v in vehicles if v.get("status") == "available"),
    }
