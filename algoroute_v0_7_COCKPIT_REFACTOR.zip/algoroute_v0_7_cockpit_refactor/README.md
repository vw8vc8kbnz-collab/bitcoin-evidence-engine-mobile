# AlgoRoute v0.7 — Cockpit Refactor Foundation

Deze build refactort de cockpit-layout richting verkoopbare SaaS-basis:

- witte marketing/intro-kolom verwijderd uit de app
- compacte professionele sidebar
- nieuwe topbar met search/quick action/user
- grote Live Nederland Cockpit als centrale hero
- KPI-row bovenin
- rechter operationele stack met overzicht, prestaties en alerts
- ondergrid met planning, import en wagenpark
- eigen Live Kaart pagina
- bestaande Wagenpark + Transport Units API blijft werken
- iPhone blijft desktop-canvas met horizontaal scrollen

Nog bewust niet inbegrepen: echte MapLibre/OSM kaartdata, echte routing solver, CSV Smart Field Picker.
