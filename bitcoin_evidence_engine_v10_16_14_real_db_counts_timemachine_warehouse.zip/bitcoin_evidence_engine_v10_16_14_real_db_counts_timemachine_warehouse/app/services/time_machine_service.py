from __future__ import annotations
import math
import uuid
import json
import time
import threading
import httpx
import numpy as np
import pandas as pd
from datetime import datetime, timezone
from app.db.database import db
from app.core.config import settings
from app.core.time_utils import horizon_delta, to_ms, HORIZON_SECONDS, interval_ms
from app.engine.twin_finder import HistoricalTwinFinder
from app.engine.risk_rules import invalidation_price as calc_invalidation_price
from app.engine.model_arena import ModelArena
from app.engine.meta_judge import MetaJudge
from app.core.debug import append_jsonl, write_json
from app.core.logger import log
from app.core.runtime_locks import tm_priority_event
from app.services.evidence_attribution_service import EvidenceAttributionService
from app.services.time_machine_learning_service import TimeMachineLearningService
from app.services.time_machine_export_service import TimeMachineExportService
from app.services.native_core_service import NativeCoreService, NativeCoreRequiredError
from app.services.historical_memory_service import HistoricalMemoryService

TIMEFRAME_HOURS = {
    "1h": 1,
    "4h": 4,
    "8h": 8,
    "24h": 24,
    "1d": 24,
    "7d": 24 * 7,
    "1w": 24 * 7,
    "30d": 24 * 30,
    "1m": 24 * 30,
}
BINANCE_INTERVAL = {"1h":"1h", "4h":"4h", "8h":"8h", "24h":"1d", "1d":"1d", "7d":"1w", "1w":"1w", "30d":"1M", "1m":"1M"}

# V10.11.1: Random 100/1000 is a two-phase workflow.
# Phase 1 (native C++ compute) must return to the UI immediately.
# Phase 2 (DuckDB persistence + Evidence Warehouse enrichment) runs in the
# background so the browser never waits minutes and times out.
_RANDOM_BATCH_JOBS: dict[str, dict] = {}
_RANDOM_BATCH_LOCK = threading.RLock()

# V10.14.5: small process-local candle cache for instant resolve while
# historical backfill is writing. It is filled from chart responses.
_RESOLVE_CACHE: dict[int, dict] = {}
_RESOLVE_CACHE_LOCK = threading.RLock()

def _cache_resolve_points(points) -> None:
    try:
        with _RESOLVE_CACHE_LOCK:
            for p in points or []:
                ts = int(p.get("timestamp_ms") or p.get("open_time") or 0)
                if ts:
                    _RESOLVE_CACHE[ts] = {
                        "timestamp_ms": ts,
                        "open": float(p.get("open") or p.get("close") or 0),
                        "high": float(p.get("high") or p.get("close") or 0),
                        "low": float(p.get("low") or p.get("close") or 0),
                        "close": float(p.get("close") or 0),
                        "volume": float(p.get("volume") or 0),
                    }
            if len(_RESOLVE_CACHE) > 8000:
                # keep recent-ish keys but avoid unbounded growth
                for k in sorted(_RESOLVE_CACHE)[:len(_RESOLVE_CACHE)-8000]:
                    _RESOLVE_CACHE.pop(k, None)
    except Exception:
        pass

def _resolve_from_cache(ts: int) -> dict | None:
    try:
        with _RESOLVE_CACHE_LOCK:
            if not _RESOLVE_CACHE:
                return None
            best = min(_RESOLVE_CACHE.keys(), key=lambda k: abs(k-int(ts)))
            if abs(best-int(ts)) <= 6 * 3600000:
                row = dict(_RESOLVE_CACHE[best])
                row["ok"] = True
                row["timestamp_ms"] = int(best)
                row["iso"] = datetime.fromtimestamp(best/1000, tz=timezone.utc).isoformat()
                row["distance_ms"] = abs(best-int(ts))
                row["cache_hit"] = True
                return row
    except Exception:
        return None
    return None

def _set_random_job(batch_id: str, **updates) -> None:
    with _RANDOM_BATCH_LOCK:
        job = _RANDOM_BATCH_JOBS.setdefault(batch_id, {"batch_id": batch_id})
        job.update(updates)
        job["updated_at"] = datetime.now(timezone.utc).isoformat()

def _get_random_job(batch_id: str | None = None) -> dict:
    with _RANDOM_BATCH_LOCK:
        if batch_id:
            return dict(_RANDOM_BATCH_JOBS.get(batch_id) or {"batch_id": batch_id, "status": "unknown"})
        if not _RANDOM_BATCH_JOBS:
            return {"status": "none"}
        latest = max(_RANDOM_BATCH_JOBS.values(), key=lambda j: j.get("started_at", ""))
        return dict(latest)

class TimeMachineService:
    """Backtest engine with a hard data cutoff.

    V4 upgrades:
    - Chart can be requested on multiple display timeframes.
    - Clicks are always resolved to an exact 1h candle.
    - Backend returns the full visible time range metadata so the frontend can
      zoom/pan without breaking the no-future-leak rule.
    """
    def __init__(self):
        self.judge = MetaJudge()
        self._run_context_cache = {}
        self._truth_window_cache = set()
        self._feature_tuple_cache = {}

    def chart_points(self, timeframe: str = "1h", limit: int = 5000, start_ms: int | None = None, end_ms: int | None = None) -> dict:
        """Chart feed, V10.4 cache-first.

        Previous builds tried a live Binance fetch before reading local DuckDB.
        That made the chart look broken when the browser aborted the request or a
        provider was slow. V10.4 reads local candles first (fast/stable), and only
        uses a small live fetch when the local cache is empty. The live fetch also
        writes 1h candles back to DuckDB, so the next chart/Time Machine request is
        cache-first again.
        """
        timeframe = timeframe if timeframe in TIMEFRAME_HOURS else "1h"
        limit = max(50, min(int(limit), 20000))
        now_ms = int(datetime.now(timezone.utc).timestamp()*1000)
        full_min = settings.historical_start_ms
        full_max = now_ms

        def db_range() -> tuple[int, int, int]:
            r = db.fetchone("""
                SELECT MIN(open_time), MAX(open_time), COUNT(*)
                FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h'
            """, [settings.symbol])
            if not r or r[0] is None or r[1] is None:
                return full_min, full_max, 0
            return int(r[0]), int(r[1]), int(r[2] or 0)

        def local_points() -> dict | None:
            params = [settings.symbol]
            where = "source='binance' AND symbol=? AND interval='1h'"
            if start_ms:
                where += " AND open_time>=?"
                params.append(int(start_ms))
            if end_ms:
                where += " AND open_time<=?"
                params.append(int(end_ms))
            df = db.df(f"""
                SELECT open_time AS timestamp_ms, open, high, low, close, volume
                FROM raw_candles
                WHERE {where}
                ORDER BY open_time ASC
            """, params)
            if df.empty:
                return None
            # Drop corrupt/null rows before sending to native core. The canvas must
            # never receive hidden NaN/null candles, because that creates random
            # visual gaps and broken y-scales.
            for col in ("open", "high", "low", "close"):
                df[col] = pd.to_numeric(df[col], errors="coerce")
            df = df.dropna(subset=["timestamp_ms", "open", "high", "low", "close"])
            df = df[(df["high"] > 0) & (df["low"] > 0) & (df["close"] > 0)]
            if df.empty:
                return None
            raw_count = len(df)
            bucket_hours = TIMEFRAME_HOURS[timeframe]
            native_chart = NativeCoreService().chart_ohlc(
                df.rename(columns={"timestamp_ms": "open_time"}),
                bucket_hours=bucket_hours,
                limit=limit,
            )
            real_min, real_max, stored_rows = db_range()
            pts = native_chart.get("points") or []
            _cache_resolve_points(pts)
            return {
                "points": pts,
                "count": int(native_chart.get("count") or len(pts)),
                "raw_count": raw_count,
                "stored_rows": stored_rows,
                "timeframe": timeframe,
                "min_ts": real_min,
                "max_ts": real_max,
                "range_start_ms": int(start_ms) if start_ms else (int(df["timestamp_ms"].min()) if not df.empty else None),
                "range_end_ms": int(end_ms) if end_ms else (int(df["timestamp_ms"].max()) if not df.empty else None),
                "live_fetch": False,
                "source": "native_cpp_chart_required",
                "native_required": True,
                "native_elapsed_ms": native_chart.get("native_bridge_elapsed_ms"),
            }

        cached = local_points()

        # V10.10: if the visible range is not sufficiently present locally,
        # hydrate the exact 1H range first. This fixes the apparent random chart
        # gaps and makes 1M/3M/6M/1Y ranges behave like an exchange chart.
        try:
            if start_ms and end_ms:
                expected_1h = max(1, int((int(end_ms) - int(start_ms)) // 3600000) + 1)
                have = int(cached.get("raw_count", 0)) if cached else 0
                hydrate_limit = min(12000, max(1000, expected_1h + 24))
                if have < max(80, int(expected_1h * 0.88)) and expected_1h <= 12000:
                    append_jsonl('chart_audit.jsonl', {"event":"hydrate_visible_1h_range", "timeframe":timeframe, "have":have, "expected_1h":expected_1h, "start_ms":start_ms, "end_ms":end_ms})
                    self._fetch_display_candles('1h', limit=hydrate_limit, start_ms=start_ms, end_ms=end_ms)
                    cached = local_points()
        except Exception as exc:
            append_jsonl('chart_audit.jsonl', {"event":"chart_visible_hydrate_failed", "timeframe":timeframe, "start_ms":start_ms, "end_ms":end_ms, "error":str(exc)})

        if cached and cached.get("count", 0) > 0:
            return cached

        # Last resort: hydrate a compact recent 1H window, then native aggregation.
        try:
            pts = self._fetch_display_candles('1h', limit=min(max(limit, 1000), 5000), start_ms=start_ms, end_ms=end_ms)
            if pts:
                cached_after = local_points()
                if cached_after and cached_after.get("count", 0) > 0:
                    cached_after["live_fetch"] = True
                    cached_after["source"] = "live_1h_hydrated_native_cache"
                    return cached_after
        except Exception as exc:
            append_jsonl('chart_audit.jsonl', {"event":"chart_fetch_failed", "timeframe":timeframe, "start_ms":start_ms, "end_ms":end_ms, "error":str(exc)})

        cached = local_points()
        if cached:
            return cached
        real_min, real_max, stored_rows = db_range()
        return {"points": [], "count": 0, "raw_count": 0, "stored_rows": stored_rows, "timeframe": timeframe, "min_ts": real_min, "max_ts": real_max, "live_fetch": False, "source": "empty"}

    def _fetch_display_candles(self, timeframe: str, limit: int = 1000, start_ms: int | None = None, end_ms: int | None = None) -> list[dict]:
        interval = BINANCE_INTERVAL.get(timeframe, '1h')
        max_rows = max(200, min(int(limit), 12000))
        all_raw = []
        with httpx.Client(timeout=max(settings.request_timeout_seconds, 12.0)) as client:
            # If a visible range is requested, paginate forward through the range.
            # V10.10 raises the chunk cap so 6M/1Y chart ranges can be hydrated
            # fully once, after which native C++ aggregation is cache-fast.
            if start_ms is not None and end_ms is not None:
                cur = int(start_ms)
                chunks = 0
                while cur <= int(end_ms) and len(all_raw) < max_rows and chunks < 14:
                    params = {"symbol": settings.symbol, "interval": interval, "limit": min(1000, max_rows-len(all_raw)), "startTime": cur, "endTime": int(end_ms)}
                    r = client.get('https://api.binance.com/api/v3/klines', params=params)
                    r.raise_for_status()
                    raw = r.json()
                    if not raw:
                        break
                    all_raw.extend(raw)
                    nxt = int(raw[-1][0]) + interval_ms(interval)
                    if nxt <= cur:
                        break
                    cur = nxt
                    chunks += 1
            else:
                params = {"symbol": settings.symbol, "interval": interval, "limit": min(max_rows, 1000)}
                if start_ms is not None:
                    params['startTime'] = int(start_ms)
                if end_ms is not None:
                    params['endTime'] = int(end_ms)
                r = client.get('https://api.binance.com/api/v3/klines', params=params)
                r.raise_for_status()
                all_raw = r.json()
        # De-duplicate while preserving order.
        seen=set(); raw=[]
        for x in all_raw:
            ts=int(x[0])
            if ts in seen: continue
            seen.add(ts); raw.append(x)
        pts = [{"timestamp_ms": int(x[0]), "open": float(x[1]), "high": float(x[2]), "low": float(x[3]), "close": float(x[4]), "volume": float(x[5])} for x in raw]
        if interval == '1h' and pts:
            now = datetime.now(timezone.utc)
            payload=[('binance', settings.symbol, '1h', p['timestamp_ms'], p['timestamp_ms']+3600000-1, p['open'], p['high'], p['low'], p['close'], p['volume'], None, None, now) for p in pts]
            db.executemany("INSERT OR REPLACE INTO raw_candles VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", payload)
        append_jsonl('chart_audit.jsonl', {"event":"display_fetch", "timeframe":timeframe, "interval":interval, "rows":len(pts), "start_ms":start_ms, "end_ms":end_ms})
        return pts

    def _ensure_1h_window(self, start_ms: int, end_ms: int) -> None:
        """Fetch enough 1H candles around a clicked point for Time Machine truth.

        This keeps Time Machine useful even before the full 2017→now local
        backfill has completed. It fetches at most a few chunks, so clicks stay
        responsive.
        """
        now_ms = int(datetime.now(timezone.utc).timestamp()*1000)
        start_ms = max(settings.historical_start_ms, int(start_ms))
        end_ms = min(int(end_ms), now_ms)
        if end_ms <= start_ms:
            return
        have = db.fetchone("SELECT COUNT(*) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' AND open_time>=? AND open_time<=?", [settings.symbol, start_ms, end_ms])
        expected = max(1, int((end_ms-start_ms)//3600000))
        if have and int(have[0] or 0) >= expected * 0.88:
            return
        cur = start_ms
        chunks = 0
        while cur <= end_ms and chunks < 4:
            self._fetch_display_candles('1h', limit=1000, start_ms=cur, end_ms=end_ms)
            cur += 1000*3600000
            chunks += 1

    def resolve_click(self, timestamp_ms: int) -> dict:
        """Resolve a chart click to the exact nearest-known 1H candle.

        V8.8 fix:
        The chart may be drawn from live display candles in 4H/1D/1W mode. Those
        display candles were not always present in local 1H storage yet, so a
        click could resolve to an older local candle and place the pink line far
        away from the mouse. We now first hydrate a small 1H window around the
        clicked point, then choose the nearest 1H candle around the click.
        """
        ts = int(timestamp_ms)
        # V9.1: first resolve from local candles so chart clicks feel instant.
        # Only hydrate from Binance when the clicked range is not present locally.
        row = db.fetchone("""
            SELECT open_time, open, high, low, close, volume,
                   ABS(open_time - ?) AS distance_ms
            FROM raw_candles
            WHERE source='binance' AND symbol=? AND interval='1h'
              AND open_time BETWEEN ? AND ?
            ORDER BY distance_ms ASC LIMIT 1
        """, [ts, settings.symbol, ts - 2*3600000, ts + 2*3600000])
        if not row:
            # V10.8: resolve must be instant and must never perform network
            # hydration. The chart click path was timing out because resolve could
            # wait behind network/DB work. Use wider local lookup only; if the
            # range is not cached, the UI can ask the user to Sync/Full history.
            row = db.fetchone("""
                SELECT open_time, open, high, low, close, volume,
                       ABS(open_time - ?) AS distance_ms
                FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h'
                  AND open_time BETWEEN ? AND ?
                ORDER BY distance_ms ASC LIMIT 1
            """, [ts, settings.symbol, ts - 12*3600000, ts + 12*3600000])
        if not row:
            row = db.fetchone("""
                SELECT open_time, open, high, low, close, volume,
                       ABS(open_time - ?) AS distance_ms
                FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h' AND open_time<=?
                ORDER BY open_time DESC LIMIT 1
            """, [ts, settings.symbol, ts])
        if not row:
            tm_priority_event.clear()
            return {"ok": False, "reason": "Geen 1h candle rond dit punt beschikbaar"}
        resolved_ms = int(row[0])
        append_jsonl('time_machine_audit.jsonl', {"event":"resolve_click", "requested_ms":ts, "resolved_ms":resolved_ms, "distance_ms":int(row[6] or 0)})
        try:
            _cache_resolve_points([{"timestamp_ms": resolved_ms, "open": row[1], "high": row[2], "low": row[3], "close": row[4], "volume": row[5]}])
        finally:
            tm_priority_event.clear()
        return {
            "ok": True,
            "timestamp_ms": resolved_ms,
            "iso": datetime.fromtimestamp(resolved_ms/1000, tz=timezone.utc).isoformat(),
            "open": float(row[1]),
            "high": float(row[2]),
            "low": float(row[3]),
            "close": float(row[4]),
            "volume": float(row[5]),
            "distance_ms": int(row[6] or 0),
        }

    def run(self, timestamp_ms: int, reveal: bool = True, persist: bool = True, source: str = "manual", batch_id: str | None = None, hydrate_context: bool = True) -> dict:
        tm_priority_event.set()
        # V9.0: resolve first and do not prefetch the entire 90d truth window before
        # the UI can respond. Truth candles are filled per horizon in _actual_info_after.
        started_perf = time.perf_counter()
        resolved = self.resolve_click(timestamp_ms)
        if not resolved.get("ok"):
            tm_priority_event.clear()
            return resolved
        cutoff_ms, start_price = int(resolved["timestamp_ms"]), float(resolved["close"])
        cutoff_dt = datetime.fromtimestamp(cutoff_ms/1000, tz=timezone.utc)

        # V10.11: single-click Time Machine now runs through the native core as well.
        # The previous Python path rebuilt deep twins per horizon and typically took
        # 4-7 seconds. Native single-click keeps the V9.8 rich output shape, but moves
        # the candle-array/twin/target sequencing work out of Python. No heavy Python
        # fallback: if native fails, return a clear error instead of silently getting slow.
        try:
            context_start = int(settings.historical_start_ms)  # V10.14: always search full 8Y historical memory, not last ~6M.
            context_end = min(int(datetime.now(timezone.utc).timestamp()*1000), cutoff_ms + int(HORIZON_SECONDS['90d']*1000))
            have = db.fetchone("""
                SELECT COUNT(*) FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h'
                  AND open_time>=? AND open_time<=?
            """, [settings.symbol, context_start, context_end])
            have_n = int(have[0] or 0) if have else 0
            if have_n < 1100:
                # One targeted hydrate if the user clicks a region that was not loaded yet.
                self._fetch_display_candles('1h', limit=12000, start_ms=max(settings.historical_start_ms, cutoff_ms - 5200*3600000), end_ms=context_end)
            df_native = db.df("""
                SELECT open_time, open, high, low, close, volume
                FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h'
                  AND open_time>=? AND open_time<=?
                ORDER BY open_time ASC
            """, [settings.symbol, context_start, context_end])
            native = NativeCoreService().tm_single(df_native, cutoff_ms)
            items = native.get('items') or []
            batch_id = batch_id or str(uuid.uuid4())
            source_native = source + '_native_cpp_single'
            # V10.11.2 Instant Time Machine:
            # Return the native result immediately. Persistence, attribution and
            # Evidence Warehouse enrichment can take seconds, so those run in a
            # background thread and must never block the click response.
            if persist and reveal and items:
                def _background_single_import(batch_id_: str, source_: str, cutoff_ms_: int, cutoff_iso_: str, items_copy: list[dict]) -> None:
                    t_bg = time.perf_counter()
                    try:
                        self._persist_test_items(batch_id=batch_id_, source=source_, cutoff_iso=cutoff_iso_, items=items_copy)
                        EvidenceAttributionService().record_time_machine_items(batch_id=batch_id_, cutoff_ms=cutoff_ms_, items=items_copy)
                        learning = TimeMachineLearningService()
                        feature_by_cutoff = learning.feature_snapshots_for_cutoffs([cutoff_ms_])
                        learning.record_items(batch_id=batch_id_, source=source_, items=items_copy, feature_by_cutoff=feature_by_cutoff)
                        try:
                            from app.services.historical_memory_service import HistoricalMemoryService
                            HistoricalMemoryService().adaptive_weights()
                        except Exception as exc:
                            append_jsonl('time_machine_audit.jsonl', {"event":"adaptive_rebuild_after_single_failed_v10143", "batch_id":batch_id_, "error":str(exc)})
                        append_jsonl('time_machine_audit.jsonl', {
                            "event":"single_async_import_complete", "batch_id":batch_id_,
                            "items":len(items_copy), "elapsed_ms":int((time.perf_counter()-t_bg)*1000)
                        })
                    except Exception as exc:
                        log.exception("Single Time Machine background import failed: %s", exc)
                        append_jsonl('time_machine_audit.jsonl', {"event":"single_async_import_failed", "batch_id":batch_id_, "error":str(exc)})
                threading.Thread(
                    target=_background_single_import,
                    args=(batch_id, source_native, cutoff_ms, cutoff_dt.isoformat(), list(items)),
                    daemon=True,
                    name=f"tm-single-import-{batch_id[:8]}"
                ).start()
            selected_native = native.get('selected_candle') or resolved
            selected_native.setdefault('timestamp_ms', cutoff_ms)
            selected_native.setdefault('iso', cutoff_dt.isoformat())
            out = {"ok": True, "batch_id": batch_id, "cutoff_ms": int(native.get('cutoff_ms') or cutoff_ms), "cutoff_iso": cutoff_dt.isoformat(), "start_price": float(native.get('start_price') or start_price), "selected_candle": selected_native, "items": items, "native": True, "native_mode": native.get('mode'), "native_elapsed_ms": native.get('native_bridge_elapsed_ms'), "core_elapsed_ms": native.get('elapsed_ms')}
            elapsed_ms = int((time.perf_counter() - started_perf) * 1000)
            append_jsonl('time_machine_audit.jsonl', {"event":"time_machine_native_single_run", "source":source, "cutoff_ms":cutoff_ms, "elapsed_ms":elapsed_ms, "native_elapsed_ms":native.get('native_bridge_elapsed_ms'), "core_elapsed_ms":native.get('elapsed_ms'), "items":len(items)})
            write_json('last_time_machine_run.json', out)
            return out
        except Exception as exc:
            append_jsonl('time_machine_audit.jsonl', {"event":"time_machine_native_single_error", "source":source, "cutoff_ms":cutoff_ms, "error":str(exc)})
            return {"ok": False, "reason": "C++ native Time Machine click faalde: " + str(exc), "native_required": True, "native_status": NativeCoreService().status()}

        # V9.2: never hydrate the full 90d truth window before returning.
        # That was the reason the first Time Machine click could take 30-40s.
        # The click now resolves instantly and uses only locally cached candles for truth.
        # Missing far-future truth is shown as unavailable instead of blocking the UI.
        append_jsonl('time_machine_audit.jsonl', {"event":"fast_click_path", "cutoff_ms":cutoff_ms, "truth_prefetch":"disabled"})
        items=[]
        batch_id = batch_id or str(uuid.uuid4())
        # V9.6: build enough local 1H context once per clicked hour before
        # running the model arena. Without this, Time Machine often only had
        # a tiny 12-25 candle window and predictions fell back to 50/50.
        if hydrate_context:
            self._hydrate_analysis_context(cutoff_ms)
        arena = ModelArena()
        latest = self._feature_tuple_at(cutoff_ms)
        feature_snapshot = TimeMachineLearningService().feature_tuple_to_dict(latest)
        futx = arena.latest_futures_snapshot(cutoff_ms)
        for horizon in settings.horizons:
            models = self._run_models_at(horizon, cutoff_ms, start_price, latest=latest, futx=futx, arena=arena)
            combined = self.judge.combine(models, start_price)
            due_dt = cutoff_dt + horizon_delta(horizon)
            row = {
                "horizon": horizon,
                "cutoff_ms": cutoff_ms,
                "due_at_ms": to_ms(due_dt),
                "start_price": start_price,
                **combined,
                "status": "simulated",
                # Stability defaults: every item has these keys even when truth is missing
                # or a neutral/edge-case model path occurs. This prevents Time Machine
                # from crashing on undefined invalidation fields.
                "invalidation_price": None,
                "invalidation_distance_pct": None,
                "target_touched": False,
                "target_reached": False,
                "invalidated": False,
                "invalidation_gap_pct": None,
                "target_gap_pct": None,
                "feature_snapshot": feature_snapshot,
            }
            if reveal:
                target_price = float(combined.get("expected_price") or start_price)
                expected_move = float(combined.get("expected_move_pct") or 0)
                target_distance_pct = abs((target_price / start_price - 1) * 100) if start_price else abs(expected_move)
                invalidation_price_value, invalidation_distance_pct = calc_invalidation_price(start_price, expected_move, horizon, target_distance_pct)
                row["invalidation_price"] = invalidation_price_value
                row["invalidation_distance_pct"] = invalidation_distance_pct
                actual_info = self._actual_info_after(cutoff_ms, horizon, target_price, invalidation_price_value, expected_move)
                if actual_info is not None:
                    actual = float(actual_info["close"])
                    actual_high = float(actual_info["high"])
                    actual_low = float(actual_info["low"])
                    actual_move = (actual/start_price - 1) * 100
                    expected_dir = 1 if expected_move >= 0 else -1
                    actual_dir = 1 if actual_move >= 0 else -1
                    direction_correct = expected_dir == actual_dir
                    price_error = actual_move - expected_move
                    abs_error = abs(price_error)

                    # V9.3: sequence-aware target check. WIN only if target is
                    # touched before invalidation. Invalidation is now wider and
                    # horizon-specific, so normal wick noise does not kill every run.
                    target_touched = bool(actual_info.get("target_touched"))
                    invalidated = bool(actual_info.get("invalidated"))
                    target_reached = bool(actual_info.get("target_reached"))
                    closest_price = float(actual_info.get("target_closest") or (actual_high if expected_move >= 0 else actual_low))
                    invalidation_closest = float(actual_info.get("invalidation_closest") or (actual_low if expected_move >= 0 else actual_high))
                    inv_price_value = invalidation_price_value
                    target_gap_pct = ((closest_price / target_price) - 1) * 100 if target_price else None
                    invalidation_gap_pct = ((invalidation_closest / inv_price_value) - 1) * 100 if inv_price_value else None
                    close_gap_pct = ((actual / target_price) - 1) * 100 if target_price else None
                    target_gap_abs = abs(float(target_gap_pct or 0))
                    # V9.8: Three-level scoring. A target missed by a few dollars should
                    # not be counted as a hard fail. WIN remains strict; PARTIAL is a
                    # near-hit without invalidation; FAIL is invalidation or far miss.
                    partial_threshold_pct = {
                        "1h": 0.18, "4h": 0.28, "8h": 0.38, "24h": 0.55,
                        "7d": 0.90, "30d": 1.60, "90d": 2.40,
                    }.get(horizon, 0.75)
                    partial_reached = bool((not target_reached) and (not invalidated) and target_gap_abs <= partial_threshold_pct)
                    target_score = 100.0 if target_reached else max(0, 100 - target_gap_abs*18)
                    magnitude_score = max(0, 100 - abs_error*4)
                    if target_reached:
                        total_score = 100.0
                        outcome_label, outcome_class, outcome_explain, outcome_tier = "WIN", "strong-hit", "doelprijs eerst geraakt; invalidatie niet eerder geraakt", "win"
                    elif invalidated:
                        total_score = 0.0
                        outcome_label, outcome_class, outcome_explain, outcome_tier = "FAIL invalidatie", "miss", "invalidatie werd eerder geraakt dan de doelprijs", "fail"
                    elif partial_reached:
                        total_score = max(55.0, min(88.0, target_score))
                        outcome_label, outcome_class, outcome_explain, outcome_tier = "PARTIAL", "near", f"doel bijna geraakt: binnen {partial_threshold_pct:.2f}% zonder invalidatie", "partial"
                    elif target_touched:
                        total_score = 35.0
                        outcome_label, outcome_class, outcome_explain, outcome_tier = "doel geraakt na invalidatie", "near", "doelprijs werd geraakt, maar pas nadat invalidatie al geraakt was", "partial"
                    elif direction_correct:
                        total_score = min(target_score, 35.0)
                        outcome_label, outcome_class, outcome_explain, outcome_tier = "FAIL doel niet gehaald", "near", "richting klopte, maar doelprijs niet geraakt", "fail"
                    else:
                        total_score = 0.0
                        outcome_label, outcome_class, outcome_explain, outcome_tier = "FAIL doel niet gehaald", "miss", "doelprijs niet geraakt", "fail"
                    row.update({
                        "actual_price": actual,
                        "actual_high": actual_high,
                        "actual_low": actual_low,
                        "actual_move_pct": actual_move,
                        "direction_correct": direction_correct,
                        "target_touched": target_touched,
                        "target_reached": target_reached,
                        "partial_reached": partial_reached,
                        "outcome_tier": outcome_tier,
                        "partial_threshold_pct": partial_threshold_pct,
                        "invalidation_price": inv_price_value,
                        "invalidated": invalidated,
                        "invalidation_gap_pct": invalidation_gap_pct,
                        "target_gap_pct": target_gap_pct,
                        "close_gap_pct": close_gap_pct,
                        "price_error_pct": price_error,
                        "magnitude_score": magnitude_score,
                        "target_score": target_score,
                        "total_score": total_score,
                        "outcome_label": outcome_label,
                        "outcome_class": outcome_class,
                        "outcome_explain": outcome_explain,
                        "status": "revealed"
                    })
                else:
                    row.update({"status": "future_not_available"})
            items.append(row)
        if persist and reveal:
            self._persist_test_items(batch_id=batch_id, source=source, cutoff_iso=cutoff_dt.isoformat(), items=items)
            EvidenceAttributionService().record_time_machine_items(batch_id=batch_id, cutoff_ms=cutoff_ms, items=items)
            TimeMachineLearningService().record_items(batch_id=batch_id, source=source, items=items, feature_by_cutoff={cutoff_ms: feature_snapshot})
        out = {"ok": True, "batch_id": batch_id, "cutoff_ms": cutoff_ms, "cutoff_iso": cutoff_dt.isoformat(), "start_price": start_price, "selected_candle": resolved, "items": items}
        elapsed_ms = int((time.perf_counter() - started_perf) * 1000)
        append_jsonl('time_machine_audit.jsonl', {"event":"time_machine_run", "source":source, "cutoff_ms":cutoff_ms, "start_price":start_price, "elapsed_ms":elapsed_ms, "items":[{k:i.get(k) for k in ('horizon','bullish_probability','expected_price','expected_move_pct','invalidation_price','actual_price','actual_high','actual_low','target_reached','invalidated','target_gap_pct')} for i in items]})
        write_json('last_time_machine_run.json', out)
        tm_priority_event.clear()
        return out

    def random_tests(self, count: int = 100) -> dict:
        tm_priority_event.set()
        """Fast Monte-Carlo style Time Machine audit.

        V10.0: the old Random 100/1000 called the full manual Time Machine
        engine once per random point. That is accurate but far too slow: one
        click can need several seconds, so 1000 points felt endless. This batch
        path keeps the same WIN/PARTIAL/FAIL semantics, but computes the random
        sample directly from local 1H candles with a lightweight historical-twin
        similarity model. It is meant for fast statistical auditing, not for the
        detailed single-click explanation card.
        """
        t0 = time.perf_counter()
        count = max(1, min(int(count), 1000))
        max_steps = int(HORIZON_SECONDS['90d'] / 3600)
        df = db.df("""
            SELECT open_time, open, high, low, close, volume
            FROM raw_candles
            WHERE source='binance' AND symbol=? AND interval='1h'
            ORDER BY open_time ASC
        """, [settings.symbol])
        if df.empty or len(df) < max_steps + 500:
            # V10.10: Random 100/1000 must be usable after startup. Minimal
            # sync only inserts 1000 candles, but the native random core needs
            # enough future truth for 90d horizons. Hydrate a recent ~7 month
            # 1H window once, then rerun the native core.
            now_ms = int(datetime.now(timezone.utc).timestamp()*1000)
            start_hist = max(settings.historical_start_ms, now_ms - 5200*3600000)
            append_jsonl('time_machine_audit.jsonl', {"event":"random_native_history_hydrate_start", "existing_rows":0 if df.empty else int(len(df)), "start_ms":start_hist, "end_ms":now_ms})
            self._fetch_display_candles('1h', limit=5400, start_ms=start_hist, end_ms=now_ms)
            df = db.df("""
                SELECT open_time, open, high, low, close, volume
                FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h'
                ORDER BY open_time ASC
            """, [settings.symbol])
        if df.empty or len(df) < max_steps + 500:
            tm_priority_event.clear()
            return {"ok": False, "reason": f"Niet genoeg lokale 1H historie voor C++ Random backtest ({0 if df.empty else len(df)} candles, minimaal {max_steps+500}). V10.14 historical memory vult nu op de achtergrond richting 8 jaar.", "summary": {}, "count": 0, "native_required": True, "historical_memory": HistoricalMemoryService().history_status()}

        # V10.9+: C++ native core is mandatory for Random 100/1000.
        # No Python fallback, so performance problems are visible instead of hidden.
        native = NativeCoreService().tm_random(df, count=count)
        batch_id = str(uuid.uuid4())
        items = native.get("items") or []
        if not native.get("ok") or not items:
            tm_priority_event.clear()
            return {"ok": False, "reason": "C++ native core gaf geen random-resultaten terug.", "summary": {}, "count": 0, "native_status": NativeCoreService().status()}

        summary = self._summaries_from_items(items)
        source = f"native_cpp_required_random_{count}"
        export_info = {}
        try:
            export_info = TimeMachineExportService().write_random_batch(
                batch_id=batch_id, count=count, native=native, items=list(items), summary=summary, source=source
            )
        except Exception as exc:
            append_jsonl('time_machine_export_audit.jsonl', {"event":"tm_random_export_failed_v101610", "batch_id":batch_id, "error":str(exc)})
        started_at = datetime.now(timezone.utc).isoformat()
        persisted_rows = 0
        # V10.16.14: persist random outcomes BEFORE returning to the UI.
        # Earlier builds returned immediately and relied on a daemon thread. If
        # the thread crashed, the UI/export showed 7000 rows but DuckDB stayed at
        # time_machine_tests=0. Inserts are small (700/7000 rows), so make the
        # warehouse write deterministic and only run enrichment in the background.
        try:
            _set_random_job(batch_id, status="persisting", phase="time_machine_tests", progress_pct=35)
            self._persist_test_items(batch_id=batch_id, source=source, cutoff_iso="batch", items=list(items))
            persisted_rows = int(db.fetchone("SELECT COUNT(*) FROM time_machine_tests WHERE batch_id=?", [batch_id])[0] or 0)
            append_jsonl('time_machine_audit.jsonl', {"event":"random_sync_persist_complete_v101613", "batch_id":batch_id, "rows":persisted_rows})
        except Exception as exc:
            tm_priority_event.clear()
            log.exception("Random batch immediate persist failed: %s", exc)
            append_jsonl('time_machine_audit.jsonl', {"event":"random_sync_persist_failed_v101613", "batch_id":batch_id, "error":str(exc)})
            return {"ok": False, "reason": "Random-resultaten berekend, maar wegschrijven naar time_machine_tests faalde: " + str(exc), "batch_id": batch_id, "summary": summary, "native_status": NativeCoreService().status()}

        _set_random_job(
            batch_id, status="persisted_learning_running", phase="learning_enrichment",
            count=int(native.get("count") or count), native_items=len(items), persisted_rows=persisted_rows,
            learning_done=False, started_at=started_at, native_elapsed_ms=native.get("elapsed_ms"),
            native_bridge_elapsed_ms=native.get("native_bridge_elapsed_ms"), summary=summary,
        )

        def _background_import(batch_id: str, source: str, items_copy: list[dict]) -> None:
            t_bg = time.perf_counter()
            try:
                # Tests are already persisted synchronously above. Only enrich.
                _set_random_job(batch_id, status="attribution", phase="evidence_attribution", progress_pct=55)
                EvidenceAttributionService().record_time_machine_items(batch_id=batch_id, cutoff_ms=0, items=items_copy)
                _set_random_job(batch_id, status="learning_enrichment", phase="feature_snapshots", progress_pct=72)
                learning = TimeMachineLearningService()
                cutoffs = [int(i.get('cutoff_ms') or 0) for i in items_copy if i.get('cutoff_ms')]
                feature_by_cutoff = learning.feature_snapshots_for_cutoffs(cutoffs)
                _set_random_job(batch_id, status="learning_write", phase="signal_scores", progress_pct=86, feature_matches=len(feature_by_cutoff))
                learning.record_items(batch_id=batch_id, source=source, items=items_copy, feature_by_cutoff=feature_by_cutoff)
                try:
                    from app.services.historical_memory_service import HistoricalMemoryService
                    HistoricalMemoryService().adaptive_weights()
                except Exception as exc:
                    append_jsonl('time_machine_audit.jsonl', {"event":"adaptive_rebuild_after_random_failed_v101613", "batch_id":batch_id, "error":str(exc)})
                elapsed_bg = int((time.perf_counter() - t_bg) * 1000)
                _set_random_job(batch_id, status="completed", phase="done", progress_pct=100, learning_done=True, background_elapsed_ms=elapsed_bg, completed_at=datetime.now(timezone.utc).isoformat())
                append_jsonl('time_machine_audit.jsonl', {"event":"random_async_learning_complete_v101613", "batch_id":batch_id, "items":len(items_copy), "persisted_rows":persisted_rows, "elapsed_ms":elapsed_bg})
            except Exception as exc:
                log.exception("Random batch background learning failed: %s", exc)
                _set_random_job(batch_id, status="persisted_learning_error", phase="learning_failed", error=str(exc), completed_at=datetime.now(timezone.utc).isoformat())
                append_jsonl('time_machine_audit.jsonl', {"event":"random_async_learning_failed_v101613", "batch_id":batch_id, "error":str(exc)})

        th = threading.Thread(target=_background_import, args=(batch_id, source, list(items)), daemon=True, name=f"tm-random-learning-{batch_id[:8]}")
        th.start()

        out = dict(native)
        out["batch_id"] = batch_id
        out["mode"] = "native_sync_persist_async_learning"
        out["summary"] = summary
        out["items_logged"] = persisted_rows
        out["import_status"] = "background_started"
        out["export"] = export_info
        out["download_url"] = export_info.get("download_url") if isinstance(export_info, dict) else None
        out["native_status"] = NativeCoreService().status()
        out.pop("items", None)
        elapsed_ms = int((time.perf_counter()-t0)*1000)
        out["elapsed_ms"] = elapsed_ms
        append_jsonl('time_machine_audit.jsonl', {"event":"random_native_async_return", "batch_id":batch_id, "count":out.get("count"), "native_items":len(items), "elapsed_ms":elapsed_ms, "native_elapsed_ms":native.get("elapsed_ms")})
        return out

        # Legacy Python random path removed in V10.9. Kept below unreachable only
        # until the next cleanup pass to avoid risky large-file surgery.
        # Numeric arrays for fast slicing.
        ts_arr = df.open_time.astype('int64').to_numpy()
        open_arr = df.open.astype(float).to_numpy()
        high_arr = df.high.astype(float).to_numpy()
        low_arr = df.low.astype(float).to_numpy()
        close_arr = df.close.astype(float).to_numpy()
        vol_arr = df.volume.astype(float).to_numpy()
        n = len(df)

        # Historical state vectors from raw candles. These are intentionally
        # cheap and available for every hour: short/medium momentum, volatility,
        # drawdown and volume pressure.
        close_s = pd.Series(close_arr)
        ret4 = close_s.pct_change(4).fillna(0).to_numpy() * 100
        ret24 = close_s.pct_change(24).fillna(0).to_numpy() * 100
        ret168 = close_s.pct_change(168).fillna(0).to_numpy() * 100
        vol24 = close_s.pct_change().rolling(24).std().fillna(0).to_numpy() * 100
        roll_high = close_s.rolling(24*90, min_periods=24).max().ffill().fillna(close_s).to_numpy()
        dd = (close_arr / np.maximum(roll_high, 1e-9) - 1) * 100
        vol_ratio = pd.Series(vol_arr).rolling(24, min_periods=2).mean().fillna(0).to_numpy() / np.maximum(pd.Series(vol_arr).rolling(168, min_periods=3).mean().fillna(1).to_numpy(), 1e-9)
        vectors = np.column_stack([ret4, ret24, ret168, vol24, dd, np.nan_to_num(vol_ratio)])
        vectors = np.nan_to_num(vectors, nan=0.0, posinf=0.0, neginf=0.0)

        # Random sample only where a 90d truth window exists and enough prior
        # history exists for fair similarity comparisons.
        eligible = np.arange(24*120, n - max_steps - 2)
        if len(eligible) <= 0:
            return {"ok": False, "reason": "Geen geschikte historische punten met volledige 90d toekomst beschikbaar.", "summary": {}, "count": 0}
        rng = np.random.default_rng(int(time.time()*1000) % (2**32-1))
        replace = len(eligible) < count
        sample_idx = rng.choice(eligible, size=count if replace else min(count, len(eligible)), replace=replace)

        summaries = {h: {"total":0, "correct":0, "partial":0, "avg_score":0.0, "avg_error":0.0} for h in settings.horizons}
        batch_id = str(uuid.uuid4())
        all_items = []
        feature_by_cutoff = {}
        examples = []
        partial_thresholds = {"1h": 0.18, "4h": 0.28, "8h": 0.38, "24h": 0.55, "7d": 0.90, "30d": 1.60, "90d": 2.40}

        for idx_i, idx in enumerate(sample_idx.tolist(), start=1):
            start_price = float(close_arr[idx])
            cutoff_ms = int(ts_arr[idx])
            cutoff_iso = datetime.fromtimestamp(cutoff_ms/1000, tz=timezone.utc).isoformat()
            feature_snapshot = self._fast_batch_feature_snapshot(idx, ts_arr, close_arr, high_arr, low_arr, open_arr, vol_arr, ret4, ret24, ret168, vol24, dd, vol_ratio)
            feature_by_cutoff[cutoff_ms] = feature_snapshot
            cur_vec = vectors[idx]
            batch_items = []

            # Use up to the last 5000 hours before the clicked point, but require
            # candidate forward result to also be before the clicked point. That
            # keeps the no-future-leak principle intact.
            hist_start = max(24*30, idx - 5000)
            hist_all = np.arange(hist_start, idx)
            if len(hist_all) < 300:
                continue
            hist_vecs_all = vectors[hist_all]
            med = np.nanmedian(hist_vecs_all, axis=0)
            std = np.nanstd(hist_vecs_all, axis=0)
            std[std == 0] = 1.0
            dists_all = np.linalg.norm((hist_vecs_all - cur_vec) / std, axis=1)

            for horizon in settings.horizons:
                steps = int(HORIZON_SECONDS[horizon] / 3600)
                # Historical candidates must have their future move known before cutoff.
                valid_mask = hist_all + steps < idx
                cand_idx = hist_all[valid_mask]
                cand_dists = dists_all[valid_mask]
                if len(cand_idx) < 80:
                    prob = 0.5
                    expected_move_pct = 0.0
                    evidence = int(len(cand_idx))
                else:
                    take = min(180, len(cand_idx))
                    top_local = np.argpartition(cand_dists, take-1)[:take]
                    chosen = cand_idx[top_local]
                    moves = (close_arr[chosen + steps] / np.maximum(close_arr[chosen], 1e-9) - 1) * 100
                    prob = float((moves > 0).mean())
                    # Median is robust; add a light directional nudge from current
                    # short-term momentum so targets are not always tiny.
                    expected_move_pct = float(np.median(moves) + 0.12*ret24[idx] + 0.035*ret168[idx])
                    evidence = int(len(moves))

                target_price = float(start_price * (1 + expected_move_pct/100.0))
                target_distance_pct = abs((target_price/start_price - 1) * 100) if start_price else abs(expected_move_pct)
                inv_price, inv_dist = calc_invalidation_price(start_price, expected_move_pct, horizon, target_distance_pct)
                inv_price = float(inv_price or start_price)
                due_i = min(n-1, idx + steps)
                win = False
                invalidated = False
                target_touched = False
                first_event = None

                # First-touch check. This is the same rule the UI explains:
                # target first = WIN, invalidation first = FAIL.
                direction_up = expected_move_pct >= 0
                for j in range(idx+1, due_i+1):
                    if direction_up:
                        t_hit = high_arr[j] >= target_price
                        i_hit = low_arr[j] <= inv_price
                    else:
                        t_hit = low_arr[j] <= target_price
                        i_hit = high_arr[j] >= inv_price
                    if t_hit or i_hit:
                        if t_hit and i_hit:
                            # Same candle ambiguity: approximate using open distance.
                            open_j = open_arr[j]
                            if abs(open_j-target_price) <= abs(open_j-inv_price):
                                first_event = 'target'
                            else:
                                first_event = 'invalid'
                        else:
                            first_event = 'target' if t_hit else 'invalid'
                        break
                target_touched = bool((high_arr[idx+1:due_i+1].max() >= target_price) if direction_up else (low_arr[idx+1:due_i+1].min() <= target_price)) if due_i > idx else False
                invalidated_any = bool((low_arr[idx+1:due_i+1].min() <= inv_price) if direction_up else (high_arr[idx+1:due_i+1].max() >= inv_price)) if due_i > idx else False
                win = first_event == 'target'
                invalidated = first_event == 'invalid'
                actual_price = float(close_arr[due_i])
                actual_high = float(np.max(high_arr[idx+1:due_i+1])) if due_i > idx else actual_price
                actual_low = float(np.min(low_arr[idx+1:due_i+1])) if due_i > idx else actual_price
                actual_move_pct = (actual_price/start_price - 1) * 100
                direction_correct = (actual_move_pct >= 0) == (expected_move_pct >= 0)
                closest = actual_high if direction_up else actual_low
                target_gap_pct = ((closest/target_price)-1)*100 if target_price else 0.0
                abs_gap = abs(float(target_gap_pct))
                partial_threshold = partial_thresholds.get(horizon, 0.75)
                partial = bool((not win) and (not invalidated) and abs_gap <= partial_threshold)
                if win:
                    score = 100.0; tier = 'win'
                elif partial:
                    score = max(55.0, min(88.0, 100 - abs_gap*18)); tier = 'partial'
                else:
                    score = 0.0 if invalidated else max(0.0, min(35.0, 100 - abs_gap*18)); tier = 'fail'
                price_error_pct = actual_move_pct - expected_move_pct

                item = {
                    "horizon": horizon, "cutoff_ms": cutoff_ms, "due_at_ms": int(ts_arr[due_i]), "start_price": start_price,
                    "bullish_probability": max(0.01, min(0.99, prob)), "bearish_probability": 1-max(0.01, min(0.99, prob)),
                    "expected_move_pct": expected_move_pct, "expected_price": target_price,
                    "confidence": min(94.0, 30.0 + evidence/5.0 + abs(prob-0.5)*90.0),
                    "evidence_count": evidence, "actual_price": actual_price, "actual_high": actual_high, "actual_low": actual_low,
                    "actual_move_pct": actual_move_pct, "direction_correct": bool(direction_correct),
                    "target_touched": bool(target_touched), "target_reached": bool(win), "partial_reached": bool(partial),
                    "outcome_tier": tier, "invalidation_price": inv_price, "invalidated": bool(invalidated),
                    "invalidation_gap_pct": 0.0, "target_gap_pct": float(target_gap_pct), "price_error_pct": float(price_error_pct),
                    "total_score": float(score), "contributions": [{"model_id":"M_FAST_TWIN", "name":"Fast Historical Twin Batch", "weight":1, "evidence_count":evidence}],
                    "feature_snapshot": feature_snapshot,
                    "cutoff_iso": cutoff_iso,
                }
                batch_items.append(item)
                s = summaries[horizon]
                s["total"] += 1
                if win: s["correct"] += 1
                elif partial: s["partial"] += 1
                s["avg_score"] += score
                s["avg_error"] += abs(float(target_gap_pct))

            if batch_items:
                # V10.1: collect all random results in memory and persist once after
                # the loop. Persisting seven rows per sample caused the UI to look
                # endless on Random 100/1000.
                all_items.extend(batch_items)
                if len(examples) < 20:
                    examples.append({"cutoff_ms": cutoff_ms, "start_price": start_price})
            if idx_i % 25 == 0:
                append_jsonl('time_machine_audit.jsonl', {"event":"random_fast_progress", "batch_id":batch_id, "done":idx_i, "count":int(len(sample_idx)), "items_buffered":len(all_items)})

        if all_items:
            # One bulk persistence pass for the full Monte Carlo batch. Use a
            # synthetic cutoff label because every item has its own cutoff_ms.
            self._persist_test_items(batch_id=batch_id, source=f"random_fast_{count}", cutoff_iso="batch", items=all_items)
            EvidenceAttributionService().record_time_machine_items(batch_id=batch_id, cutoff_ms=0, items=all_items)
            TimeMachineLearningService().record_items(batch_id=batch_id, source=f"random_fast_{count}", items=all_items, feature_by_cutoff=feature_by_cutoff)

        for h,s in summaries.items():
            if s["total"]:
                s["hitrate"] = s["correct"] / s["total"]
                s["hitrate_with_partial"] = (s["correct"] + s["partial"]) / s["total"]
                s["avg_score"] = s["avg_score"] / s["total"]
                s["avg_error"] = s["avg_error"] / s["total"]
            else:
                s["hitrate"] = None
                s["hitrate_with_partial"] = None
        elapsed_ms = int((time.perf_counter()-t0)*1000)
        append_jsonl('time_machine_audit.jsonl', {"event":"random_fast_complete", "batch_id":batch_id, "count":len(examples), "elapsed_ms":elapsed_ms, "summary":summaries})
        return {"ok": True, "mode":"fast_batch", "batch_id": batch_id, "count": len(examples), "elapsed_ms": elapsed_ms, "summary": summaries, "examples": examples, "cumulative": self.stats()}

    def _fast_batch_feature_snapshot(self, idx: int, ts_arr, close_arr, high_arr, low_arr, open_arr, vol_arr, ret4, ret24, ret168, vol24, dd, vol_ratio) -> dict:
        """Compact feature context for Random 100/1000 without DB lookups.

        This is intentionally cheap because it runs once per sampled cutoff. It
        gives the learning warehouse enough context to discover which regimes,
        trend states, volatility/volume states and momentum states work best.
        """
        close = float(close_arr[idx])
        def ma(period: int):
            if idx + 1 < period:
                return None
            return float(np.mean(close_arr[idx-period+1:idx+1]))
        ma50 = ma(50)
        ma200 = ma(200)
        rsi = None
        if idx >= 15:
            diffs = np.diff(close_arr[idx-14:idx+1])
            gains = np.maximum(diffs, 0.0)
            losses = np.abs(np.minimum(diffs, 0.0))
            avg_gain = float(np.mean(gains)) if len(gains) else 0.0
            avg_loss = float(np.mean(losses)) if len(losses) else 0.0
            rsi = 100.0 if avg_loss == 0 and avg_gain > 0 else (50.0 if avg_loss == 0 else 100 - (100 / (1 + avg_gain / avg_loss)))
        range_pct = float(((high_arr[idx] - low_arr[idx]) / close) * 100) if close else 0.0
        body_pct = float(((close_arr[idx] - open_arr[idx]) / close) * 100) if close else 0.0
        vz = None
        if idx >= 168:
            window = vol_arr[idx-167:idx+1].astype(float)
            std = float(np.std(window))
            vz = float((vol_arr[idx] - np.mean(window)) / std) if std else None
        # same coarse regime naming as the manual fallback feature builder
        regime = 'transition'
        ddraw = float(dd[idx])
        if close and ma50 and ma200 and close > ma50 > ma200 and ddraw > -20:
            regime = 'bull_trend'
        elif close and ma50 and ma200 and close < ma50 < ma200 and ddraw < -35:
            regime = 'bear_trend'
        elif ddraw < -55:
            regime = 'capitulation'
        elif rsi is not None and rsi > 72 and ddraw > -10:
            regime = 'euphoria_risk'
        return {
            "rsi_14": rsi, "return_4": float(ret4[idx]), "return_24": float(ret24[idx]),
            "return_168": float(ret168[idx]), "ma_50": ma50, "ma_200": ma200, "close": close,
            "volatility_24": float(vol24[idx]), "volume_zscore": vz, "volume_ratio_24": float(vol_ratio[idx]),
            "range_pct": range_pct, "candle_body_pct": body_pct, "drawdown_from_ath": ddraw,
            "cycle_progress": None, "regime": regime, "data_completeness": 50.0,
            "source": "random_fast_local_candles",
        }

    def stats(self) -> dict:
        rows = db.df("""
            SELECT horizon,
                   COUNT(*) AS total,
                   SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS correct,
                   SUM(CASE WHEN (NOT target_reached) AND total_score >= 55 THEN 1 ELSE 0 END) AS partial,
                   SUM(CASE WHEN target_reached OR total_score >= 55 THEN 0 ELSE 1 END) AS wrong,
                   AVG(CASE WHEN target_reached THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(CASE WHEN target_reached OR total_score >= 55 THEN 1.0 ELSE 0.0 END) AS hitrate_with_partial,
                   AVG(total_score) AS avg_score,
                   AVG(ABS((actual_price/NULLIF(expected_price,0)-1)*100)) AS avg_abs_error,
                   MAX(created_at) AS last_test_at
            FROM time_machine_tests
            GROUP BY horizon
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """).to_dict('records')
        total_row = db.fetchone("""
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS correct,
                   SUM(CASE WHEN (NOT target_reached) AND total_score >= 55 THEN 1 ELSE 0 END) AS partial,
                   AVG(CASE WHEN target_reached THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(CASE WHEN target_reached OR total_score >= 55 THEN 1.0 ELSE 0.0 END) AS hitrate_with_partial
            FROM time_machine_tests
        """)
        return {
            "rows": rows,
            "total": int(total_row[0] or 0) if total_row else 0,
            "correct": int(total_row[1] or 0) if total_row else 0,
            "partial": int(total_row[2] or 0) if total_row else 0,
            "hitrate": float(total_row[3]) if total_row and total_row[3] is not None else None,
            "hitrate_with_partial": float(total_row[4]) if total_row and len(total_row) > 4 and total_row[4] is not None else None,
        }

    def random_batch_status(self, batch_id: str | None = None) -> dict:
        """Return latest/selected async Random batch import status."""
        job = _get_random_job(batch_id)
        if job.get("status") in ("completed", "persisting", "attribution", "learning_enrichment", "learning_write"):
            try:
                job["cumulative"] = self.stats()
            except Exception:
                pass
        return job

    def _summaries_from_items(self, items: list[dict]) -> dict:
        summaries = {h: {"total":0, "correct":0, "partial":0, "avg_score":0.0, "avg_error":0.0} for h in settings.horizons}
        for item in items or []:
            h = str(item.get("horizon") or "unknown")
            if h not in summaries:
                summaries[h] = {"total":0, "correct":0, "partial":0, "avg_score":0.0, "avg_error":0.0}
            s = summaries[h]
            s["total"] += 1
            if item.get("target_reached"):
                s["correct"] += 1
            elif item.get("partial_reached") or str(item.get("outcome_tier") or "").lower() == "partial":
                s["partial"] += 1
            try:
                s["avg_score"] += float(item.get("total_score") or 0.0)
            except Exception:
                pass
            try:
                s["avg_error"] += abs(float(item.get("target_gap_pct") or 0.0))
            except Exception:
                pass
        for s in summaries.values():
            if s["total"]:
                s["hitrate"] = s["correct"] / s["total"]
                s["hitrate_with_partial"] = (s["correct"] + s["partial"]) / s["total"]
                s["avg_score"] = s["avg_score"] / s["total"]
                s["avg_error"] = s["avg_error"] / s["total"]
            else:
                s["hitrate"] = None
                s["hitrate_with_partial"] = None
        return summaries

    def _persist_test_items(self, batch_id: str, source: str, cutoff_iso: str, items: list[dict]) -> None:
        """Persist Time Machine items efficiently.

        V10.1: uses DuckDB executemany in one DB call instead of one INSERT per
        horizon/sample. This makes Random 100/1000 feel like a real batch audit
        instead of an endless UI wait.
        """
        now = datetime.now(timezone.utc)
        columns = [
            "test_item_id", "batch_id", "source", "created_at", "cutoff_ms", "cutoff_iso", "horizon", "start_price",
            "bullish_probability", "bearish_probability", "expected_move_pct", "expected_price", "confidence",
            "actual_price", "actual_high", "actual_low", "actual_move_pct", "direction_correct", "target_touched",
            "target_reached", "invalidation_price", "invalidated", "invalidation_gap_pct", "target_gap_pct",
            "price_error_pct", "total_score", "model_contributions_json", "partial_reached", "outcome_tier"
        ]
        rows = []
        for item in items:
            if item.get("status") == "future_not_available":
                continue
            if item.get("direction_correct") is None or item.get("actual_price") is None:
                continue
            rows.append([
                str(uuid.uuid4()), batch_id, source, now, int(item.get("cutoff_ms")), cutoff_iso if cutoff_iso != "batch" else datetime.fromtimestamp(int(item.get("cutoff_ms"))/1000, tz=timezone.utc).isoformat(), item.get("horizon"),
                float(item.get("start_price") or 0), float(item.get("bullish_probability") or 0),
                float(item.get("bearish_probability") or 0), float(item.get("expected_move_pct") or 0),
                float(item.get("expected_price") or 0), float(item.get("confidence") or 0),
                float(item.get("actual_price") or 0), float(item.get("actual_high") or item.get("actual_price") or 0),
                float(item.get("actual_low") or item.get("actual_price") or 0), float(item.get("actual_move_pct") or 0),
                bool(item.get("direction_correct")), bool(item.get("target_touched")), bool(item.get("target_reached")),
                float(item.get("invalidation_price") or 0), bool(item.get("invalidated")),
                float(item.get("invalidation_gap_pct") or 0), float(item.get("target_gap_pct") or 0),
                float(item.get("price_error_pct") or 0), float(item.get("total_score") or 0), json.dumps(item.get("contributions") or [], default=str),
                bool(item.get("partial_reached")), item.get("outcome_tier") or ("win" if item.get("target_reached") else "partial" if item.get("partial_reached") else "fail")
            ])
        if not rows:
            return
        placeholders = ", ".join(["?"] * len(columns))
        db.executemany(f"""
            INSERT OR REPLACE INTO time_machine_tests ({', '.join(columns)})
            VALUES ({placeholders})
        """, rows)
        append_jsonl('time_machine_audit.jsonl', {"event":"persist_test_items_bulk", "batch_id":batch_id, "source":source, "rows":len(rows)})


    def _hydrate_analysis_context(self, cutoff_ms: int) -> None:
        """Ensure the Time Machine has enough 1H history before a clicked point.

        The chart can be drawn from Binance display candles (4H/1D/1W/1M), while
        the forecast engine needs local 1H candles for indicators and historical
        twins. If the local DB only has a tiny window around the click, the model
        collapses to 50/50. Hydrate a practical lookback once per selected hour.
        """
        key = (int(cutoff_ms)//3600000, 'analysis_context')
        if key in self._truth_window_cache:
            return
        lookback_hours = 720  # V10.5.2: about 30 days; keeps clicked Time Machine runs responsive
        start_ms = max(settings.historical_start_ms, int(cutoff_ms) - lookback_hours*3600000)
        end_ms = int(cutoff_ms)
        try:
            have = db.fetchone("""
                SELECT COUNT(*) FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h'
                  AND open_time>=? AND open_time<=?
            """, [settings.symbol, start_ms, end_ms])
            have_n = int(have[0] or 0) if have else 0
            if have_n < min(240, lookback_hours * 0.35):
                t0 = time.perf_counter()
                self._fetch_display_candles('1h', limit=900, start_ms=start_ms, end_ms=end_ms)
                append_jsonl('time_machine_audit.jsonl', {"event":"analysis_context_hydrated", "cutoff_ms":int(cutoff_ms), "had_rows":have_n, "lookback_hours":lookback_hours, "elapsed_ms":int((time.perf_counter()-t0)*1000)})
            else:
                append_jsonl('time_machine_audit.jsonl', {"event":"analysis_context_cached", "cutoff_ms":int(cutoff_ms), "rows":have_n})
        except Exception as exc:
            append_jsonl('time_machine_audit.jsonl', {"event":"analysis_context_hydrate_failed", "cutoff_ms":int(cutoff_ms), "error":str(exc)})
        self._truth_window_cache.add(key)

    def _feature_tuple_at(self, cutoff_ms: int):
        """Cached rich feature tuple for a Time Machine cutoff.

        V9.2: the previous version rebuilt the same fallback feature snapshot once
        per horizon, so one click logged fallback_feature_built seven times. This
        method builds/loads it once and reuses it across all horizons.
        """
        key = int(cutoff_ms)
        if key in self._feature_tuple_cache:
            return self._feature_tuple_cache[key]
        latest = db.fetchone("""
            SELECT rsi_14, return_4, return_24, ma_50, ma_200, close, volatility_24,
                   volume_zscore, volume_ratio_24, range_pct, candle_body_pct,
                   drawdown_from_ath, cycle_progress, fear_greed, funding_rate,
                   open_interest_value, open_interest_change_24h, long_short_ratio,
                   taker_buy_sell_ratio, orderbook_imbalance, taker_delta_ratio, futures_basis_premium_pct,
                   top_position_long_short_ratio, top_account_long_short_ratio, cross_exchange_spread_pct,
                   spot_premium_kraken_pct, spot_premium_coinbase_pct, coinmetrics_mvrv,
                   realized_cap_usd, market_cap_usd, regime, data_completeness
            FROM features WHERE interval='1h' AND timestamp_ms<=? ORDER BY timestamp_ms DESC LIMIT 1
        """, [key])
        if not latest:
            latest = self._fallback_feature_tuple(key)
        self._feature_tuple_cache[key] = latest
        if len(self._feature_tuple_cache) > 96:
            for k in list(self._feature_tuple_cache.keys())[:-96]:
                self._feature_tuple_cache.pop(k, None)
        return latest

    def _fallback_feature_tuple(self, cutoff_ms: int):
        """Build a light historical feature snapshot directly from raw 1H candles.

        V8.8: Time Machine often tests points outside the latest rebuilt feature
        window. Previously that meant only the Historical Twins model ran, often
        with evidence_count=0, so forecasts collapsed to exactly 50/50. This
        fallback gives Time Machine real historical price/volume/cycle/futures
        context at the clicked cutoff without needing a full feature rebuild.
        """
        df = db.df("""
            SELECT open_time, open, high, low, close, volume
            FROM raw_candles
            WHERE source='binance' AND symbol=? AND interval='1h' AND open_time<=?
            ORDER BY open_time DESC LIMIT 600
        """, [settings.symbol, int(cutoff_ms)])
        if df.empty or len(df) < 120:
            # V10.5.2: use a small targeted hydrate only. Large hydration made
            # single Time Machine clicks feel broken while the result actually
            # arrived much later.
            try:
                self._ensure_1h_window(int(cutoff_ms)-720*3600000, int(cutoff_ms))
            except Exception as exc:
                append_jsonl('time_machine_audit.jsonl', {"event":"fallback_small_hydrate_failed", "cutoff_ms":int(cutoff_ms), "error":str(exc)})
            df = db.df("""
                SELECT open_time, open, high, low, close, volume
                FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h' AND open_time<=?
                ORDER BY open_time DESC LIMIT 600
            """, [settings.symbol, int(cutoff_ms)])
        if df.empty or len(df) < 30:
            append_jsonl('time_machine_audit.jsonl', {"event":"fallback_feature_missing", "cutoff_ms":int(cutoff_ms), "rows":0 if df.empty else len(df)})
            return None
        df = df.sort_values('open_time').reset_index(drop=True)
        closes=[float(x) for x in df['close'].tolist()]
        highs=[float(x) for x in df['high'].tolist()]
        lows=[float(x) for x in df['low'].tolist()]
        opens=[float(x) for x in df['open'].tolist()]
        vols=[float(x or 0) for x in df['volume'].tolist()]
        close=closes[-1]
        def ret(n):
            return ((close / closes[-1-n]) - 1) * 100 if len(closes) > n and closes[-1-n] else 0.0
        def ma(n):
            return sum(closes[-n:]) / n if len(closes) >= n else None
        ret4=ret(4); ret24=ret(24)
        ma50=ma(50); ma200=ma(200)
        # Simple RSI(14)
        gains=[]; losses=[]
        for i in range(max(1, len(closes)-14), len(closes)):
            diff=closes[i]-closes[i-1]
            gains.append(max(diff,0)); losses.append(abs(min(diff,0)))
        avg_gain=sum(gains)/len(gains) if gains else 0
        avg_loss=sum(losses)/len(losses) if losses else 0
        rsi=100.0 if avg_loss==0 and avg_gain>0 else (50.0 if avg_loss==0 else 100 - (100/(1+(avg_gain/avg_loss))))
        returns=[]
        for i in range(max(1, len(closes)-24), len(closes)):
            if closes[i-1]: returns.append((closes[i]/closes[i-1]-1)*100)
        vol24=(sum((x-(sum(returns)/len(returns)))**2 for x in returns)/len(returns))**0.5 if returns else None
        v24=sum(vols[-24:])/min(24,len(vols)) if vols else None
        v168=vols[-168:] if len(vols)>=24 else vols
        vmean=sum(v168)/len(v168) if v168 else 0
        vstd=(sum((x-vmean)**2 for x in v168)/len(v168))**0.5 if v168 else 0
        vol_ratio=(vols[-1]/v24) if v24 else None
        vol_z=((vols[-1]-vmean)/vstd) if vstd else None
        range_pct=((highs[-1]-lows[-1])/close*100) if close else 0
        body_pct=((closes[-1]-opens[-1])/close*100) if close else 0
        ath=max(closes) if closes else close
        dd=(close/ath-1)*100 if ath else 0
        # Cycle progress using same halving constants as feature_engine.
        halvings=[1354116278000,1468082773000,1589225023000,1713571767000]
        last_halving=max([h for h in halvings if h<=int(cutoff_ms)], default=halvings[0])
        cycle=min(max(((int(cutoff_ms)-last_halving)/86400000)/1458,0),1)
        def metric(source, name):
            row=db.fetchone("""
                SELECT value FROM raw_metric_points
                WHERE source=? AND metric=? AND timestamp_ms<=?
                ORDER BY timestamp_ms DESC LIMIT 1
            """, [source, name, int(cutoff_ms)])
            return float(row[0]) if row and row[0] is not None else None
        fg=metric('alternative_me','fear_greed')
        funding=metric('binance_futures','funding_rate')
        oi=metric('binance_futures','open_interest_value') or metric('binance_futures','current_open_interest_contracts')
        oi_prev_row=db.fetchone("""
            SELECT value FROM raw_metric_points WHERE source='binance_futures' AND metric='open_interest_value' AND timestamp_ms<=?
            ORDER BY timestamp_ms DESC LIMIT 1
        """, [int(cutoff_ms)-24*3600000])
        oi_prev=float(oi_prev_row[0]) if oi_prev_row and oi_prev_row[0] is not None else None
        oi_chg=((oi/oi_prev-1)*100) if oi and oi_prev else None
        long_short=metric('binance_futures','long_short_ratio')
        taker_ratio=metric('binance_futures','taker_buy_sell_ratio')
        taker_delta=metric('binance_futures','taker_delta_ratio')
        basis=metric('binance_futures','futures_basis_premium_pct')
        top_position=metric('binance_futures','top_position_long_short_ratio')
        top_account=metric('binance_futures','top_account_long_short_ratio')
        cross_spread=metric('spot_composite','cross_exchange_spread_pct')
        kraken_premium=metric('spot_composite','spot_premium_kraken_pct')
        coinbase_premium=metric('spot_composite','spot_premium_coinbase_pct')
        ob_imb=metric('composite_orderbook','orderbook_imbalance')
        # Light regime classification
        regime='transition'
        if close and ma50 and ma200 and close > ma50 > ma200 and dd > -20: regime='bull_trend'
        elif close and ma50 and ma200 and close < ma50 < ma200 and dd < -35: regime='bear_trend'
        elif dd < -55: regime='capitulation'
        elif rsi > 72 and dd > -10 and cycle > 0.45: regime='euphoria_risk'
        completeness_items=[rsi,ma50,ma200,vol24,vol_z,range_pct,fg,funding,oi,long_short,taker_ratio,ob_imb,taker_delta,basis,top_position,cross_spread]
        completeness=round(sum(1 for x in completeness_items if x is not None)/len(completeness_items)*100,1)
        append_jsonl('time_machine_audit.jsonl', {"event":"fallback_feature_built", "cutoff_ms":int(cutoff_ms), "rows":len(df), "regime":regime, "completeness":completeness})
        return (rsi, ret4, ret24, ma50, ma200, close, vol24, vol_z, vol_ratio, range_pct, body_pct,
                dd, cycle, fg, funding, oi, oi_chg, long_short, taker_ratio, ob_imb, taker_delta, basis,
                top_position, top_account, cross_spread, kraken_premium, coinbase_premium, None,
                None, None, regime, completeness)


    def _raw_context(self, cutoff_ms: int) -> pd.DataFrame:
        """V9.1 deep raw context for Time Machine.

        This is the missing engine piece from V9.0: instead of rebuilding a tiny
        fallback per horizon, build one deep price-action warehouse for the
        selected cutoff and reuse it for every horizon. It uses only candles at
        or before the selected hour, so there is no future leak.
        """
        key = int(cutoff_ms)
        cached = self._run_context_cache.get(key)
        if cached is not None:
            return cached
        df = db.df("""
            SELECT open_time AS timestamp_ms, open, high, low, close, volume
            FROM raw_candles
            WHERE source='binance' AND symbol=? AND interval='1h' AND open_time<=?
            ORDER BY open_time DESC
            LIMIT 90000
        """, [settings.symbol, key])
        if df.empty or len(df) < 1500:
            self._hydrate_analysis_context(int(cutoff_ms))
            df = db.df("""
                SELECT open_time AS timestamp_ms, open, high, low, close, volume
                FROM raw_candles
                WHERE source='binance' AND symbol=? AND interval='1h' AND open_time<=?
                ORDER BY open_time DESC
                LIMIT 90000
            """, [settings.symbol, key])
        if df.empty:
            self._run_context_cache[key] = df
            return df
        # DuckDB LIMIT must keep the most recent history before the cutoff, then
        # we sort ASC for rolling features and positional forward-return lookup.
        df = df.sort_values('timestamp_ms').reset_index(drop=True)
        close = df['close'].astype(float)
        vol = df['volume'].astype(float)
        df['ret1'] = close.pct_change(1) * 100
        df['ret4'] = close.pct_change(4) * 100
        df['ret8'] = close.pct_change(8) * 100
        df['ret24'] = close.pct_change(24) * 100
        df['ret168'] = close.pct_change(168) * 100
        df['ret720'] = close.pct_change(720) * 100
        df['ma20dist'] = (close / close.rolling(20).mean() - 1) * 100
        df['ma50dist'] = (close / close.rolling(50).mean() - 1) * 100
        df['ma200dist'] = (close / close.rolling(200).mean() - 1) * 100
        df['vol24'] = df['ret1'].rolling(24).std()
        df['vol168'] = df['ret1'].rolling(168).std()
        df['range'] = (df['high'].astype(float) - df['low'].astype(float)) / close * 100
        df['body'] = (close - df['open'].astype(float)) / close * 100
        df['vol_ratio'] = vol / vol.rolling(24).mean()
        df['ath'] = close.cummax()
        df['dd'] = (close / df['ath'] - 1) * 100
        # cycle context from known halvings
        def cycle_progress(ts):
            last = max([h for h in [1354116278000,1468082773000,1589225023000,1713571767000] if h <= int(ts)], default=1354116278000)
            return max(0.0, min(1.0, ((int(ts)-last)/86400000)/1458))
        df['cycle'] = df['timestamp_ms'].map(cycle_progress)
        self._run_context_cache[key] = df
        # Avoid unbounded memory if the user clicks many points.
        if len(self._run_context_cache) > 4:
            for k in list(self._run_context_cache.keys())[:-4]:
                self._run_context_cache.pop(k, None)
        return df

    def _fallback_twin_raw(self, horizon: str, cutoff_ms: int, top_n: int = 260) -> dict:
        """Deep historical twin finder from raw candles.

        V9.1 upgrades:
        - Uses a reusable deep context instead of a small 600/9000-candle slice.
        - Compares against all available local history up to the selected cutoff.
        - Produces both probability and realistic target magnitude from actual
          historical forward returns for every horizon, not just long horizons.
        """
        steps = int(HORIZON_SECONDS[horizon] / 3600)
        df = self._raw_context(cutoff_ms)
        if df.empty or len(df) < max(320, steps + 260):
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0, "fallback": "deep_raw_insufficient"}
        cur = df.iloc[-1]
        # Candidate rows must have their forward outcome fully before cutoff.
        hist = df.iloc[240:-(steps+1)].dropna(subset=['ret4','ret24','ma50dist','ma200dist','vol24','range','dd','cycle']).copy()
        if hist.empty:
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0, "fallback": "deep_raw_empty"}
        # Horizon-aware fingerprints: short horizons emphasize short flow/volatility;
        # longer horizons emphasize trend, drawdown and cycle context.
        if horizon in ('1h','4h','8h'):
            keys = ['ret1','ret4','ret8','ret24','ma20dist','ma50dist','vol24','range','body','vol_ratio','dd']
        elif horizon in ('24h','7d'):
            keys = ['ret4','ret24','ret168','ma20dist','ma50dist','ma200dist','vol24','vol168','range','vol_ratio','dd','cycle']
        else:
            keys = ['ret24','ret168','ret720','ma50dist','ma200dist','vol168','dd','cycle','vol_ratio']
        keys = [k for k in keys if k in hist.columns]
        cur_vec = np.array([float(cur[k]) if pd.notna(cur.get(k)) else 0.0 for k in keys], dtype=float)
        mat = hist[keys].replace([np.inf,-np.inf], np.nan).fillna(0.0).to_numpy(dtype=float)
        med = np.nanmedian(mat, axis=0); std = np.nanstd(mat, axis=0); std[std==0] = 1.0
        hist['distance'] = np.linalg.norm((mat-cur_vec)/std, axis=1)
        hist = hist.sort_values('distance').head(top_n)
        closes = df['close'].astype(float).tolist()
        ts_to_pos = {int(ts): i for i, ts in enumerate(df.timestamp_ms)}
        moves=[]; matches=[]
        for _, r in hist.iterrows():
            i = ts_to_pos.get(int(r.timestamp_ms))
            if i is None or i + steps >= len(closes):
                continue
            mv = (float(closes[i+steps]) / float(r.close) - 1) * 100
            if not np.isfinite(mv):
                continue
            moves.append(mv)
            matches.append({"timestamp_ms": int(r.timestamp_ms), "close": float(r.close), "future_move_pct": float(mv), "distance": float(r.distance)})
        if not moves:
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0, "fallback": "deep_raw_no_moves"}
        arr = np.array(moves, dtype=float)
        bullish_prob = float((arr > 0).mean())
        if bullish_prob >= 0.5:
            conditional = arr[arr > 0]
            expected = float(np.median(conditional)) if len(conditional) else float(np.median(arr))
        else:
            conditional = arr[arr < 0]
            expected = float(np.median(conditional)) if len(conditional) else float(np.median(arr))
        return {
            "matches": matches[:60],
            "evidence_count": len(moves),
            "bullish_probability": bullish_prob,
            "expected_move_pct": expected,
            "median_all_move_pct": float(np.median(arr)),
            "avg_move_pct": float(np.mean(arr)),
            "p25_move_pct": float(np.percentile(arr, 25)),
            "p75_move_pct": float(np.percentile(arr, 75)),
            "worst_move_pct": float(np.min(arr)),
            "best_move_pct": float(np.max(arr)),
            "fallback": "deep_raw_price_action",
            "keys": keys,
        }

    def _run_models_at(self, horizon: str, cutoff_ms: int, start_price: float, latest=None, futx=None, arena=None) -> list[dict]:
        feature_twin = HistoricalTwinFinder().find_at(horizon, cutoff_ms=cutoff_ms)
        deep_twin = self._fallback_twin_raw(horizon, cutoff_ms)
        # V9.1: Time Machine should look deeply into the past. Feature twins are
        # useful when rich feature-state exists; deep raw twins usually have more
        # history and better target magnitude. Prefer the deeper one unless the
        # feature twin has clearly stronger evidence.
        if (deep_twin.get("evidence_count", 0) >= feature_twin.get("evidence_count", 0)) or feature_twin.get("evidence_count", 0) < 220:
            twin = deep_twin
        else:
            twin = feature_twin
        arena = arena or ModelArena()
        futx = futx if futx is not None else arena.latest_futures_snapshot(cutoff_ms)
        models = [arena._historical_twin_model(horizon, twin)]
        if latest:
            (rsi, ret4, ret24, ma50, ma200, close, vol24, vol_z, vol_ratio, range_pct, body_pct,
             dd, cycle, fg, funding, oi, oi_chg, long_short, taker_ratio, ob_imb, taker_delta, basis_premium,
             top_position_ratio, top_account_ratio, cross_spread, kraken_premium, coinbase_premium, mvrv,
             realized_cap, market_cap, regime, completeness) = latest
            models += [
                arena._momentum_model(horizon, ret4, ret24),
                arena._trend_model(horizon, close, ma50, ma200, regime),
                arena._rsi_model(horizon, rsi, regime),
                arena._cycle_model(horizon, cycle, dd),
                arena._sentiment_model(horizon, fg),
                arena._volatility_model(horizon, vol24),
                arena._volume_model(horizon, vol_z, vol_ratio, ret4, ret24),
                arena._range_expansion_model(horizon, range_pct, body_pct, ret4),
                arena._mean_reversion_model(horizon, rsi, dd, close, ma50),
                arena._funding_model(horizon, funding, long_short),
                arena._open_interest_model(horizon, oi_chg, funding),
                arena._orderbook_model(horizon, ob_imb, taker_ratio),
                arena._onchain_mvrv_model(horizon, mvrv, close, realized_cap, market_cap),
                arena._regime_model(horizon, regime, completeness),
                arena._drawdown_pressure_model(horizon, dd, regime),
                arena._ma_structure_model(horizon, close, ma50, ma200, dd),
                arena._risk_confluence_model(horizon, fg, funding, long_short, ob_imb, dd),
                arena._cycle_drawdown_confluence_model(horizon, cycle, dd, regime),
                arena._breakout_retest_model(horizon, ret24, range_pct, close, ma50),
                arena._futures_pressure_stack_model(horizon, funding, oi_chg, long_short, taker_ratio),
                arena._liquidity_imbalance_model(horizon, ob_imb, range_pct, ret4),
                arena._sentiment_exhaustion_model(horizon, fg, rsi, dd),
                arena._trend_exhaustion_model(horizon, close, ma50, ma200, rsi, dd),
                arena._basis_premium_model(horizon, futx.get('futures_basis_premium_pct'), futx.get('premium_last_funding_rate')),
                arena._top_trader_position_model(horizon, futx.get('top_position_long_short_ratio'), futx.get('top_account_long_short_ratio'), funding),
                arena._spot_futures_basis_model(horizon, close, futx.get('futures_mark_price'), futx.get('futures_index_price')),
                arena._cvd_delta_model(horizon, taker_delta, taker_ratio, ret4),
                arena._cross_exchange_spread_model(horizon, cross_spread, kraken_premium, coinbase_premium),
                arena._evidence_cluster_model(horizon, regime, completeness, funding, oi_chg, ob_imb, taker_delta, fg, dd),
            ]
            # V10.16.12: use the same extra alpha/flow specialist stack in historical
            # Time Machine as in live forecasts. Each model receives only values known
            # at cutoff_ms via latest_alpha_snapshot(cutoff_ms). Missing providers
            # produce low-weight neutral models, not fake evidence.
            alpha = arena.latest_alpha_snapshot(cutoff_ms)
            models += [
                arena._spot_aggression_model(horizon, alpha),
                arena._futures_aggression_model(horizon, alpha, funding),
                arena._large_trade_imbalance_model(horizon, alpha),
                arena._leverage_flow_agreement_model(horizon, alpha, funding, oi_chg, taker_delta),
                arena._multi_layer_alpha_stack_model(horizon, alpha, regime, completeness, funding, oi_chg, ob_imb, fg, dd),
            ]
        return models

    def _ensure_truth_window_once(self, start_ms: int, end_ms: int) -> None:
        # Bucket by selected hour and end hour so repeated horizon checks do not
        # run network requests over and over. One click = one truth hydration.
        key = (int(start_ms)//3600000, int(end_ms)//3600000)
        if key in self._truth_window_cache:
            return
        t0 = time.perf_counter()
        self._ensure_1h_window(start_ms, end_ms)
        self._truth_window_cache.add(key)
        if len(self._truth_window_cache) > 24:
            self._truth_window_cache = set(list(self._truth_window_cache)[-24:])
        append_jsonl('time_machine_audit.jsonl', {"event":"truth_window_hydrated_once", "start_ms":int(start_ms), "end_ms":int(end_ms), "elapsed_ms":int((time.perf_counter()-t0)*1000)})

    def _actual_info_after(self, cutoff_ms: int, horizon: str, target_price: float | None = None, invalidation_price: float | None = None, expected_move: float = 0.0) -> dict | None:
        target = cutoff_ms + HORIZON_SECONDS[horizon]*1000
        close_row = db.fetchone("""
            SELECT open_time, close FROM raw_candles
            WHERE source='binance' AND symbol=? AND interval='1h' AND open_time>=?
            ORDER BY open_time ASC LIMIT 1
        """, [settings.symbol, target])
        if not close_row:
            return None
        rows = db.df("""
            SELECT open_time, open, high, low, close FROM raw_candles
            WHERE source='binance' AND symbol=? AND interval='1h' AND open_time>? AND open_time<=?
            ORDER BY open_time ASC
        """, [settings.symbol, cutoff_ms, int(close_row[0])])
        if rows.empty:
            return {"due_open_time": int(close_row[0]), "close": float(close_row[1]), "high": float(close_row[1]), "low": float(close_row[1]),
                    "target_touched": False, "invalidated": False, "target_reached": False}
        high = float(rows['high'].max())
        low = float(rows['low'].min())
        target_touched = False
        invalidated = False
        target_first_ms = None
        invalid_first_ms = None
        target_closest = high if expected_move >= 0 else low
        invalidation_closest = low if expected_move >= 0 else high
        if target_price is not None and invalidation_price is not None:
            for _, r in rows.iterrows():
                h = float(r['high']); l = float(r['low']); ts = int(r['open_time'])
                if expected_move >= 0:
                    t_hit = h >= float(target_price)
                    i_hit = l <= float(invalidation_price)
                else:
                    t_hit = l <= float(target_price)
                    i_hit = h >= float(invalidation_price)
                if t_hit and target_first_ms is None:
                    target_first_ms = ts
                if i_hit and invalid_first_ms is None:
                    invalid_first_ms = ts
                if target_first_ms is not None or invalid_first_ms is not None:
                    # Keep scanning is unnecessary for first-touch sequencing.
                    if target_first_ms is not None and invalid_first_ms is not None:
                        break
            target_touched = target_first_ms is not None
            invalidated = invalid_first_ms is not None and (target_first_ms is None or invalid_first_ms <= target_first_ms)
        target_reached = bool(target_touched and not invalidated)
        return {
            "due_open_time": int(close_row[0]),
            "close": float(close_row[1]),
            "high": high,
            "low": low,
            "target_touched": bool(target_touched),
            "invalidated": bool(invalidated),
            "target_reached": bool(target_reached),
            "target_first_ms": target_first_ms,
            "invalid_first_ms": invalid_first_ms,
            "target_closest": float(target_closest),
            "invalidation_closest": float(invalidation_closest),
        }

