#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p native_core/bin logs
if command -v g++ >/dev/null 2>&1; then
  echo "Building Linux C++ native core with g++..."
  g++ -std=c++17 -O3 -DNDEBUG native_core/src/bee_native_core.cpp -o native_core/bin/bee_native_core
  chmod +x native_core/bin/bee_native_core
  echo "OK: native_core/bin/bee_native_core"
else
  echo "ERROR: g++ not found. Install build-essential/gcc-c++ or use the included Nix/Replit config." >&2
  exit 1
fi
