# HANDOVER — Configurator Studio v0.9

## Kern

v0.9 voegt de business/paywall laag toe bovenop v0.8 Exact Product AI.

## Vastgezet

- Free/Demo Sandbox mag nooit dure AI-provider-calls doen.
- Demo Sandbox bevat alleen pre-generated demo models.
- Eigen uploads/generatie/publicatie zitten achter een harde betaalmuur.
- Starter €39: 2 configurators, 5k views, eigen GLB upload, geen eigen Tripo/Rodin AI generation.
- Growth €129: 10 configurators, 50k views, 50 AI credits, Tripo/Rodin/Meshy via credits.
- Scale €349: veel/onbeperkt configurators, 250k views, 250 credits, priority, analytics.
- Klein Configurator Studio-logo blijft in alle normale abonnementen.
- Enterprise kan later full white-label krijgen.
- Shopify route: OAuth, App Bridge, Theme App Extensions/App Blocks, Shopify App Pricing, cart strategy.
- Checkout prijs moet Shopify-compatibel via variants/add-ons/functions/configuration ID; niet blind arbitrary price pushen.

## Backendmodules die hierna nodig zijn

1. Auth/workspaces/plans
2. Subscription state + entitlements
3. Credit ledger
4. AI job cost estimator
5. Exact Product Verification Engine
6. OpenAI Structured Outputs blueprint generator
7. Tripo/Rodin/Meshy provider adapters
8. Asset pipeline + CDN storage
9. Configurator compiler
10. Shopify app integration
