# Configurator Studio v0.9 — Paywall & Exact Product AI

v0.9 zet de businesslaag en harde AI-paywall in de prototype-app.

## Nieuw

- Demo Sandbox is standaard actief.
- Gratis sandbox kan alleen vooraf gegenereerde demo-modellen openen.
- Eigen productfoto’s of AI-generatie openen direct de paywall.
- Starter/Growth/Scale pricing zichtbaar.
- Klein Configurator Studio-logo/branding blijft in elk normaal plan.
- Starter is upload-ready-3D, geen eigen Tripo/Rodin generatie.
- Growth is hoofd-AI-plan met 50 credits.
- Scale heeft 250 credits en priority/analytics.
- Add-on credit economy voorbereid.
- Exact Product Check blijft verplicht voor betaalde productie.
- Provider credit estimate toegevoegd.
- Backend architecture preview toegevoegd:
  - OpenAI Product Architect
  - Tripo/Rodin/Meshy provider router
  - No-code configurator compiler
  - Shopify App Store route

## Richting

Geen conceptmodus. Geen gokken. Geen dure AI-calls zonder betaald plan + credits + voldoende productbewijs.
