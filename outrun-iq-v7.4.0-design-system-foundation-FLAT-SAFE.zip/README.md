# Outrun IQ v7.4.0 Design System Foundation

Flat root ZIP: `package.json` staat direct in de ZIP-root.

Deze versie bouwt verder op v7.3.11 en houdt de role-isolation/Flow Recorder hardening intact.

Belangrijk:
- `.env`, `data/`, `runtime_uploads/`, `public/uploads/`, `node_modules/` en `.next/` niet overschrijven bij deploy.
- Upload ZIP naar GitHub raw en gebruik de vaste veilige Termius 1-regel.
