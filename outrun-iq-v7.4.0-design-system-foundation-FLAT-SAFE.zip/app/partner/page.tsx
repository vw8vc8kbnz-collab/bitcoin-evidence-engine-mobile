import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { sweepOrders } from "@/lib/data";
import { getSellerStats, eur, unreadCount } from "@/lib/data";
import { Mark } from "@/components/icons";
import { Img } from "@/components/Img";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";

function sparkPath(daily: number[]): string {
  const max = Math.max(...daily, 1);
  const pts = daily.map((v, i) => [i * (280 / 29), 40 - (v / max) * 34] as const);
  return "M" + pts.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" L");
}

export default async function SellerDash() {
  await sweepOrders();
  const db = await read();
  const user = await getUser();
  const seller = db.sellers.find(x => x.slug === user?.partnerSlug);
  const unread = user ? await unreadCount(user.id) : 0;
  const stats = seller ? await getSellerStats(seller.slug) : null;
  const openOrders = (stats?.orders ?? []).filter(o => !["paid_out", "cancelled"].includes(o.status));

  return (
    <main className="page">
      <header className="hd">
        <Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />PARTNER <b>HUB</b></Link>
        <span className="sp" />
        <Link href="/meldingen" className="icbtn" aria-label="Meldingen">
          <svg viewBox="0 0 24 24"><path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5h-15S6 14 6 10z" /><path d="M10.5 19a1.8 1.8 0 003 0" /></svg>
          {unread > 0 && <span className="bub">{unread > 9 ? "9+" : unread}</span>}
        </Link>
        <Link href="/partner/storefront" className="icbtn" aria-label="Storefront en instellingen">
          <svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="3" /><path d="M4 10h16M10 10v10" /></svg>
        </Link>
        <Link href="/partner/orders" className="icbtn" aria-label="Orders">
          <svg viewBox="0 0 24 24"><path d="M5 4h14v16l-3-2-2 2-2-2-2 2-2-2-3 2z" /></svg>
        </Link>
      </header>

      {!seller && (
        <>
          <Empty
            title="Welkom in de Partner Hub"
            text="Je partneraccount is actief. Plaats je eerste listing — de AI doet het prijswerk."
          />
          <div className="foot"><Link href="/partner/nieuw" className="btn pri">+ Eerste listing plaatsen</Link></div>
        </>
      )}

      {seller && stats && (
        <>
          <section className="partnerHero"><div className="big"><label>UITBETAALD · LAATSTE 30 DAGEN</label>
            <b>{eur(stats.rev30)}</b></div>
          <svg className="spark" height="44" viewBox="0 0 280 44" preserveAspectRatio="none" aria-hidden>
            <path d={sparkPath(stats.daily)} fill="none" stroke="#35A9AC" strokeWidth="2" />
            <circle cx="280" cy={40 - (stats.daily[29] / Math.max(...stats.daily, 1)) * 34} r="3.4" fill="#E9A13B" />
          </svg></section>
          <div className="dkchips partnerMetricGrid">
            <span className="dkc"><label>LIVE LISTINGS</label><b>{stats.activeCount}</b></span>
            <span className="dkc"><label>SELL-THROUGH</label><b>{stats.sellThrough}%</b></span>
            <span className="dkc"><label>IN ESCROW</label><b>{eur(stats.inEscrowSum)}</b></span>
          </div>
          {(!seller.support?.email || !seller.logo) && (
            <Link href="/partner/storefront" className="act actionCard">
              <span className="n2">!</span>
              <span><b>Maak je storefront af</b><span>{!seller.support?.email ? "klantenservicegegevens verplicht vóór publiceren" : "voeg je logo toe — bouwt vertrouwen"}</span></span>
              <span className="go">OPEN →</span>
            </Link>
          )}
          {openOrders.length > 0 && (
            <Link href="/partner/orders" className="act actionCard">
              <span className="n2">{openOrders.length}</span>
              <span><b>{openOrders.length === 1 ? "Order wacht op actie" : "Orders wachten op actie"}</b><span>bevestig of plan de levering</span></span>
              <span className="go">OPEN →</span>
            </Link>
          )}
          <div className="dsec"><h2>Laatste orders</h2><span>{stats.orders.length} TOTAAL</span></div>
          {stats.orders.length === 0 && (
            <p className="note">Nog geen orders. Zodra een koper een testorder plaatst, verschijnt hij hier.</p>
          )}
          {[...stats.orders].reverse().slice(0, 4).map(o => {
            const l = db.listings.find(x => x.id === o.listingId);
            return (
              <div key={o.id} className="orow orderCard">
                <Img src={l?.photos[0]} fallback={l?.fallback ?? "tv"} dark />
                <span><b>{o.itemTitle}</b><span>{o.id} · {o.status.replaceAll("_", " ").toUpperCase()}</span></span>
                <span className="amt">{eur(o.sellerNet)}<i className={o.status === "paid_out" ? "esc" : "esc"} style={o.status === "paid_out" ? { color: "#4CBE8B" } : undefined}>{o.status === "paid_out" ? "UITBETAALD" : "IN ESCROW"}</i></span>
              </div>
            );
          })}
        </>
      )}
    </main>
  );
}
