# Outrun IQ v7.4.0 — Design System Foundation

Gebouwd op v7.3.11 Flow Recorder + Role Hardening.

## Nieuw / verbeterd
- Visuele foundation aangescherpt: spacing, radius, shadows, surfaces en premium app-gevoel.
- Buyer-home sterker gemaakt met duidelijke intro, trust strip, premium hero en consistentere deal cards.
- Accountpagina professioneler gemaakt met persoonlijke dashboard-hero en strakkere settings/cards.
- Partner Hub visueel opgewaardeerd: professionelere dashboard-hero, metric cards, actiekaarten en ordercards.
- Partner header heeft geen link meer naar koperaccount; gesloten werelden blijven intact.
- Shared UI foundation toegevoegd (`components/ui/*`) voor toekomstige schermen.
- Service worker cacheversie verhoogd naar v7.4.0.

## Bewust niet gedaan
- Geen datamodel- of paymentwijzigingen.
- Geen verwijdering van v7.3.11 role/flow hardening.
- Geen grote partner-flow herbouw; dit is foundation, geen volledige v7.6 Partner Portal redesign.

## Validatie
- `npx tsc --noEmit` succesvol.
- `next build` compile/type-check succesvol; de sandbox time-outte tijdens static page generation, niet tijdens compile/type-check.
