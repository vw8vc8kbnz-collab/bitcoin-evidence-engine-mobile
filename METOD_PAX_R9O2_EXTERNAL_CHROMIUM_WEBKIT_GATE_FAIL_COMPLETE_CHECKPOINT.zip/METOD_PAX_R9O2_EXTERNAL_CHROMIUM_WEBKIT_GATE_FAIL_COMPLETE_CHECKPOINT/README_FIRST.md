# METOD/PAX R9O2 — lees dit eerst

Dit is het volledige, zelfstandige checkpoint na de eerste externe uitvoering
met zowel echte Chromium als echte WebKit. Een nieuwe chat kan met alleen deze
ZIP direct verder zonder eerdere berichten of bijlagen.

## Waar we staan

- Checkpoint: `R9O2_EXTERNAL_CHROMIUM_WEBKIT_GATE_FAIL`.
- Checkpointcommit: `94c6de42270677ef63e8c3fb22f15b8c4f285159`.
- Tag: `r9o2-external-chromium-webkit-gate-fail-checkpoint`.
- Geteste runtimecommit: `d6f43a8918c2c7ed77d9d52d502917ee75c4b2c3`.
- Runtimeartifact: `runtime/METOD_PAX_R9O1_BROWSER_GATE_DEFECT_REMEDIATION_CANDIDATE.zip`.
- Runtime-SHA-256: `be3e941b4bdbbb2674d6a175e15b2a7530f25e371e6916b46fdea117bc0b1ec2`.
- Runtimemanifest-SHA-256: `57bb221c877eaa1081192df28bd3b61f91185968b9ed18302004bb12a61fae6f`.
- Immutable R8Z-baseline-SHA-256: `d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62`.
- Browsergate: 8/15 fixtures PASS, 7/15 FAIL, 100 assertions.
- Productiestatus: **NO_GO** en `releaseEligible=false`.

## Belangrijk onderscheid

R9O2 heeft de applicatieruntime niet gewijzigd. Het is een evidence-only
checkpoint dat het echte VPS-resultaat, de mislukte eerste invocatie, de geldige
tweede browserrun, de bevindingen en het R9O3-plan toevoegt. De runtime in deze
ZIP heet daarom terecht nog R9O1; herlabelen als R9O2-runtime zou misleidend zijn.

## Bewezen uitkomst

Het officiële Playwright 1.62.0 Noble-image draaide echte Chromium
151.0.7922.34 en WebKit 26.5. Beide konden starten. Acht kritieke fixtures
passeerden in alle vereiste profielen. Zeven faalden door een combinatie van
een werkelijk WebKit-iPhone Admin-overflowdefect, kandidaat-ResizeObserver-
diagnostiek en twee golden+kandidaat fixture-/timingproblemen. R8Z en kandidaat
bleven tijdens de run ongewijzigd.

## Eerst doen

1. Controleer `PACKAGE_MANIFEST_SHA256.txt`.
2. Lees `docs/01_COMPLETE_TECHNICAL_HANDOFF_R9O2.md`.
3. Lees het machineleesbare en menselijke R9O2-resultaat.
4. Verifieer `evidence/vps/SHA256SUMS.txt`.
5. Clone de Git-bundle en checkout de R9O2-tag.
6. Voer uitsluitend `R9O3_WEBKIT_FAILURE_REMEDIATION` uit.

Noem R9O2 nooit live, production-ready of browsergoedgekeurd. Zelfs na een
groene R9O3-rerun blijven echte iPhone/Safari, productie-VPS/edge, security,
load/chaos/restore, operations, CAM/bedrijf en formele signoff open.
