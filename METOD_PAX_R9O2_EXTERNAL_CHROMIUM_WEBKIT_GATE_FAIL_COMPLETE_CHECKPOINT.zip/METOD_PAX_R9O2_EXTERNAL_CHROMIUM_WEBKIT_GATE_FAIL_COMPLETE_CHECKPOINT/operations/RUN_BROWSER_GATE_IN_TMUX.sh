#!/usr/bin/env bash
set -Eeuo pipefail

IMAGE="mcr.microsoft.com/playwright:v1.62.0-noble"
IMAGE_DIGEST="sha256:baed2032d533817f3dbe6425de795788430ba345e819a1201337009ba17c9d07"
SESSION="metod-r9o3-browser-gate"

fail() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 2
}

run_inside_tmux() {
  local audit_root="$1"
  local report_id="$2"
  local repo="$audit_root/repo"
  local golden="$audit_root/golden/METOD_PAX_FIX660R8_PRELIVE_HARDENED"
  local evidence="$audit_root/evidence"
  local report="$repo/reports/${report_id}.json"
  local log="$evidence/${report_id}_EXECUTION.log"

  mkdir -p "$evidence"
  git -C "$repo" rev-parse HEAD > "$evidence/${report_id}_GIT_HEAD.txt"
  sha256sum "$repo/candidate/SHA256SUMS.txt" > "$evidence/${report_id}_CANDIDATE_MANIFEST_SHA256.txt"
  sha256sum "$golden/SHA256SUMS.txt" > "$evidence/${report_id}_GOLDEN_MANIFEST_SHA256.txt"
  sudo -n docker image inspect "$IMAGE" > "$evidence/${report_id}_DOCKER_IMAGE_INSPECT.json"

  set +e
  sudo -n docker run --rm --init --ipc=host --network none \
    -v "$audit_root:/audit" \
    -w /audit/repo \
    "$IMAGE" \
    bash -lc "git config --global --add safe.directory /audit/repo && python3 -B tools/r9a_browser_oracle_tests.py -q && python3 -B tools/r9a_browser_oracle.py --registry contracts/R9A_BROWSER_FIXTURES.json --golden-release /audit/golden/METOD_PAX_FIX660R8_PRELIVE_HARDENED --candidate candidate --engines chromium webkit --json-output reports/${report_id}.json --playwright-module /audit/repo/browser/node_modules/playwright --chromium-executable /ms-playwright/chromium-1234/chrome-linux64/chrome --webkit-executable /ms-playwright/webkit-2336/pw_run.sh --probe-timeout 60 --suite-timeout 1800" \
    2>&1 | tee "$log"
  local docker_exit="${PIPESTATUS[0]}"
  set -e

  printf 'R9_BROWSER_GATE_DOCKER_EXIT=%s\n' "$docker_exit" > "$evidence/${report_id}_EXIT.txt"
  if sudo -n test -f "$report"; then
    sudo -n cp "$report" "$evidence/${report_id}.json"
    sudo -n chown "$(id -u):$(id -g)" "$evidence/${report_id}.json"
    chmod 0600 "$evidence/${report_id}.json"
  fi

  (
    cd "$evidence"
    find . -maxdepth 1 -type f ! -name SHA256SUMS.txt -print0 \
      | sort -z \
      | xargs -0 sha256sum > SHA256SUMS.txt
  )
  python3 -m zipfile -c "$audit_root/${report_id}_EVIDENCE.zip" "$evidence"
  printf 'Browser gate finished with Docker exit %s.\n' "$docker_exit"
  exit "$docker_exit"
}

command_name="${1:-}"
audit_root="${2:-/home/ubuntu/metod-r9o3-audit}"
report_id="${3:-R9O3_BROWSER_GATE}"

[[ "$report_id" =~ ^[A-Z0-9_]+$ ]] || fail "report id must contain only A-Z, 0-9 and underscore"

case "$command_name" in
  --inside)
    run_inside_tmux "$audit_root" "$report_id"
    ;;
  start)
    command -v tmux >/dev/null || fail "tmux is missing; install it with: sudo apt install tmux -y"
    command -v docker >/dev/null || fail "docker is missing"
    [[ -d "$audit_root/repo/.git" ]] || fail "missing repository: $audit_root/repo"
    [[ -d "$audit_root/golden/METOD_PAX_FIX660R8_PRELIVE_HARDENED" ]] || fail "missing immutable R8Z golden"
    [[ -f "$audit_root/repo/browser/node_modules/playwright/index.js" ]] || fail "pinned Playwright module is not installed"
    sudo -v
    actual_digest="$(sudo docker image inspect "$IMAGE" --format '{{index .RepoDigests 0}}' 2>/dev/null || true)"
    [[ "$actual_digest" == "mcr.microsoft.com/playwright@${IMAGE_DIGEST}" ]] || fail "Docker image digest mismatch: $actual_digest"
    if tmux has-session -t "$SESSION" 2>/dev/null; then
      fail "tmux session already exists: $SESSION"
    fi
    script_path="$(realpath "$0")"
    tmux new-session -d -s "$SESSION" "bash '$script_path' --inside '$audit_root' '$report_id'"
    printf 'tmux session started: %s\n' "$SESSION"
    printf 'Termius may now disconnect safely.\n'
    printf 'Follow log: tail -f %s/evidence/%s_EXECUTION.log\n' "$audit_root" "$report_id"
    ;;
  status)
    if tmux has-session -t "$SESSION" 2>/dev/null; then
      printf 'RUNNING: %s\n' "$SESSION"
    else
      printf 'NOT RUNNING. Check %s/evidence/%s_EXIT.txt and the JSON report.\n' "$audit_root" "$report_id"
    fi
    ;;
  *)
    printf 'Usage: %s start|status [AUDIT_ROOT] [REPORT_ID]\n' "$0" >&2
    exit 2
    ;;
esac
