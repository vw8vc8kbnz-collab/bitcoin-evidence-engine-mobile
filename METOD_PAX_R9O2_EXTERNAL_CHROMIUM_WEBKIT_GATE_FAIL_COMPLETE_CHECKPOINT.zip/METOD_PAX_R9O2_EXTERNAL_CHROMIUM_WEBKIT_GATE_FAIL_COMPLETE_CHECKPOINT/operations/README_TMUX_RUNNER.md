# Veilige lange VPS-run met tmux

`RUN_BROWSER_GATE_IN_TMUX.sh` is een voorbereid hulpmiddel voor de volgende
R9O3-rerun. Het verandert de applicatie niet en is nog geen R9O3-resultaat.

## Voorwaarden

De auditroot bevat:

- `repo/` met de te testen checkpointcommit;
- `golden/METOD_PAX_FIX660R8_PRELIVE_HARDENED/`;
- `repo/browser/node_modules/playwright` van versie 1.62.0;
- het Dockerimage `mcr.microsoft.com/playwright:v1.62.0-noble`.

Installeer eenmalig tmux indien nodig:

```bash
sudo apt update && sudo apt install tmux -y
```

Start daarna bijvoorbeeld:

```bash
chmod +x RUN_BROWSER_GATE_IN_TMUX.sh
./RUN_BROWSER_GATE_IN_TMUX.sh start /home/ubuntu/metod-r9o3-audit R9O3_BROWSER_GATE
```

Termius mag dicht zodra `tmux session started` is gemeld. Status bekijken:

```bash
./RUN_BROWSER_GATE_IN_TMUX.sh status /home/ubuntu/metod-r9o3-audit R9O3_BROWSER_GATE
```

Log volgen:

```bash
tail -f /home/ubuntu/metod-r9o3-audit/evidence/R9O3_BROWSER_GATE_EXECUTION.log
```

Na voltooiing staan rapport, log, exitcode, image-inspect, provenance,
SHA256SUMS en een evidence-ZIP onder de auditroot. Een exitcode 0 is alleen een
geldige PASS wanneer het JSON-rapport zelf eveneens `status: PASS` vermeldt.
