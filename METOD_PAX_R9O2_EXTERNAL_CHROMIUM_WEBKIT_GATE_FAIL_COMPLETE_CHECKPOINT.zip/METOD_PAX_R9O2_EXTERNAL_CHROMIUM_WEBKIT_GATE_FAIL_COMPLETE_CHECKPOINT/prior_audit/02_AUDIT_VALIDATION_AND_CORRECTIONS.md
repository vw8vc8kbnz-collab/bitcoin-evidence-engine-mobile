# Validatie van de externe pre-live audit — R9J8

Beoordeeld document: `METOD_PAX_R9J8_EXTERNAL_PRELIVE_AUDIT_2026-08-24.md`  
Beoordeeld checkpoint: R9J8, commit `9e779bacd300fdf914b479cd3c78682f9e505d66`  
Reviewmethode: checksum-/Git-/broncontrole plus verse uitvoering van beschikbare gates  
Productcode gewijzigd: nee

---

## 1. Eindoordeel over de audit

De audit is inhoudelijk sterk, technisch concreet en in hoofdzaak correct. Het
NO-GO-besluit is zonder twijfel juist. Alle 18 bevindingen hebben een reële basis
in bron of ontbrekend bewijs. De audit overschrijft geen R8Z-/R9-claims en maakt
correct onderscheid tussen lokale first-party PASS en ontbrekende externe
evidence.

Er zijn drie belangrijke kwalificaties:

1. Het aangeleverde “externe auditpakket” bevat alleen één Markdownrapport. Er
   zijn geen ruwe scanneroutputs, pentestrequests, CVE-results, screenshots,
   ondertekende auditoridentiteit, opdrachtbrief, onafhankelijkheidsverklaring
   of cryptografische attestatie meegeleverd. Het rapport is dus een goede
   technische review, maar niet zelfstandig bewijs dat een formeel onafhankelijke
   externe auditor de audit heeft uitgevoerd.
2. Bevinding A07 onderschat de aantoonbaar onbereikbare code: er zijn vier
   volledige 410-legacybodies met samen circa 231 onbereikbare regels, niet alleen
   de genoemde uploadbody.
3. Een aantal bevindingen is een release-engineering-/governance-eis en geen
   direct productdefect. Dat verandert de NO-GO niet, maar voorkomt dat een
   volgende chat sterke actieve code onnodig herschrijft.

Er is geen bewijs gevonden dat de audit een actieve kritieke kwetsbaarheid heeft
gemist. Er is ook geen bewijs gevonden voor een direct exploiteerbare critical in
R9J8. “Kritiek” betekent hier terecht: blokkade voor publieke livegang.

---

## 2. Onafhankelijk opnieuw vastgestelde feiten

### 2.1 Integriteit en provenance

- Audit-ZIP SHA-256:
  `cea13c9abd816c9fbeb1adf21fa58f02fc575a4c892eeb29e5d6e80204b6cc8d`.
- Checkpoint-ZIP SHA-256:
  `6fd25430ebdac198e49adbfd1b656f7d357e1b662cf762d1e4bca7fed752f970`.
- Beide ZIPs: CRC PASS en veilige memberpaden.
- Checkpointmanifest: alle opgenomen bestanden PASS.
- Candidate-ZIP SHA-256:
  `aa3c53788d655626318471a9280b3daf7afe5680d2e37f968d596fa126cb8af4`.
- R8Z-ZIP SHA-256:
  `d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62`.
- Git-bundle: volledige historie, 73 commits, 65 tags.
- Final commit: `9e779bac...`.
- Tag wijst annotated naar de final commit.
- Candidate-ZIP en Git `candidate/`: exact gelijk.
- Git objectdatabase: `fsck --full` schoon.
- Alle commits en checkpointtag: unsigned.

### 2.2 Verse tests

- release identity: PASS;
- R9J8 cleanup: 7/7 PASS;
- lifecycle: 11/11 PASS;
- performance: 11/11 PASS;
- first-party supply chain: PASS;
- verse preflight vanuit schone extractie: PASS;
- server golden black-box: 12/12 fixtures, 47/47 assertions PASS;
- resetdifferential: 3/3 assertions PASS;
- HTTP smoke: 2/2 PASS;
- security/privacy: 7/7 PASS;
- restore: 3/3 PASS;
- browseroracle: exit 3 / NO_GO, 14/14 blocked, 0 assertions.

Een preflightrun na andere tests vond door die testuitvoering gemaakte cachefiles.
Dit is geen artifactdefect: een verse ZIP-extractie met
`PYTHONDONTWRITEBYTECODE=1` gaf preflight PASS en nul residual `.pyc/.pyo/.bak`.

---

## 3. Bevinding-voor-bevinding oordeel

### A01 — Release is canoniek zelf NO-GO

**Auditstatus:** bevestigd.  
**Direct bewijs:** `RELEASE_IDENTITY.json` zet `releaseEligible:false`, status
`PROVISIONAL_DEVELOPMENT_ONLY`, alle externe evidence op `DEFERRED_NO_GO` en
`productionGo:false`.

**Nuance:** de identitygate die PASS is, bewijst juist dat de kandidaat eerlijk
NO-GO gelabeld is. Het is geen release-PASS.

**Advies:** geen velden omzetten; pas een nieuwe releaseRevision minten nadat
bewijs werkelijk bestaat.

### A02 — Browsergate heeft 0 echte assertions

**Auditstatus:** bevestigd en opnieuw gereproduceerd.  
**Direct bewijs:** 14 fixtures, 0 passed, 0 failed, 14 blocked, 0 assertions,
geen engines passed. Verse run meldt ontbrekende echte Chromium- en
WebKit-binaries.

**Nuance:** “0 failures” betekent hier niet groen. Het betekent dat niets is
uitgevoerd. De gate faalt correct gesloten.

**Advies:** exact pinned Playwright installeren en beide engines echt uitvoeren;
daarnaast fysiek Safari/iOS-bewijs.

### A03 — Productie-, werkplaats- en operationeel bewijs ontbreekt

**Auditstatus:** bevestigd binnen pakketbereik.  
**Direct bewijs:** checklistvelden staan open; pakket bevat geen VPS/TLS/firewall,
off-host restore, monitoring, load/chaos, CAM of proefsnedebewijs.

**Nuance:** afwezigheid in dit pakket bewijst niet dat een organisatie buiten
dit pakket nooit iets heeft uitgevoerd. Voor deze artifacthash is het echter
niet gebonden en mag het dus niet meetellen.

### A04 — Backend is geen schone composition root

**Auditstatus:** bevestigd.  
**Direct bewijs:** 14.375 regels, 703.989 bytes, exact 374 AST-functies/methodes,
35 definities ≥80 regels. De genoemde hotspots en groottes kloppen.

**Nuance:** er zijn al echte modules en behavior-preserving extracties. De audit
zegt terecht niet dat alles moet worden herschreven; verdere extractie moet juist
klein en oracle-gedreven zijn.

### A05 — Frontend blijft legacy en netwerkownership is verdeeld

**Auditstatus:** bevestigd.  
**Direct bewijs:** script-06 = 9.563 regels / 435.812 bytes. Twaalf fetchlocaties:
twee in canonieke API-modules, negen in script-06 en één in early bootstrap.
`toolA.html` bevat 157 `style=`-attributen.

**Nuance:** `toolA.html` bevat geen inline `<script>`-/`<style>`elementen en is
sterk kleiner geworden. De shell-extractie is dus echt, maar niet af.

### A06 — Dormante verouderde Admin-authcode

**Auditstatus:** volledig bevestigd.  
**Direct bewijs:** direct-return door vooraf gezet FIX626-marker; daarna complete
password-only, bearer, sessionStorage en fetch-monkeypatchcode. Actieve login
gebruikt TOTP + HttpOnly cookie.

**Risicoklasse:** securityhygiëne/high, niet bewezen active exploit.

**Advies:** eerste kleine remediationpatch. Voeg negatieve tests toe voor:

- geen Adminbearer in Web Storage;
- geen password-only productie-login;
- één loginowner;
- geen globale fetch-monkeypatch voor Adminauth.

### A07 — Cleanup is niet compleet

**Auditstatus:** bevestigd, maar audit is onvolledig/te voorzichtig.  
**Direct bewijs uit AST:** vier methodes hebben een unconditional return als
eerste statement en daarna onbereikbare bodies:

| Methode | Onbereikbaar na return |
|---|---:|
| `_api_admin_materials_save_item` | circa 88 regels |
| `_api_admin_materials_delete_item` | circa 26 regels |
| `_api_admin_materials_upload` | circa 84 regels |
| `_api_admin_material_image_upload` | circa 33 regels |

Daarnaast:

- permanent `for jp in []:` in `api_admin_requests`;
- `_merge_raw_quotes` heeft repositorybreed alleen een definitie;
- mogelijke aanvullende één-occurrencefuncties vereisen dynamische controle.

**Correctie op audit:** de genoemde uploadbody is slechts één van vier bewezen
onbereikbare method bodies. Totaal circa 231 regels.

### A08 — XSS/SAST-bewijs te oppervlakkig

**Auditstatus:** bevestigd.  
**Direct bewijs:** 91 innerHTML-assignments, één insertAdjacentHTML. First-party
gate meldt nul findings maar bevat expliciet een evidenceLimit en inventariseert
sinks; hij bewijst geen taintflow.

**Nuance:** sterke CSP en afwezigheid van eval/new Function/document.write zijn
positief. Een sinkcount is niet automatisch een kwetsbaarheid.

### A09 — Geen meetbare coveragegate

**Auditstatus:** bevestigd.  
**Direct bewijs:** geen `.coveragerc`, coverageconfig, coverageartifact of
CI-threshold gevonden.

**Nuance:** er zijn veel outcome- en differentialtests. Coverage is aanvullend,
niet een vervanging voor golden outcome tests.

### A10 — CI/supply chain geen onafhankelijke attestatie

**Auditstatus:** bevestigd.  
**Direct bewijs:** workflow gebruikt pinned checkout en first-party gates en bouwt
een artifact. Ontbrekend: browseroracle, coverage, vendor SAST, volledige
historysecretscan, dependency/OS CVE, legal license, artifact upload/retentie en
signed provenance. 73 commits en tag zijn unsigned.

**Nuance:** de workflow is niet waardeloos; hij is alleen onvoldoende voor een
formele final release.

### A11 — Productieruntime niet volledig reproduceerbaar/inventariseerbaar

**Auditstatus:** bevestigd als release-engineeringbevinding.  
**Direct bewijs:** `/usr/bin/python3`, geen pinned patch/venv/container, optionele
Pillow-range, geen OS/Nginx/OpenSSL/libc inventory in de artifact-SBOM.

**Nuance:** productiepad heeft bewust nul verplichte third-party Pythonpackages
en kan zonder Pillow correct functioneren. Het risico betreft reproduceerbaarheid,
cachebytes/performance en totale runtime-CVEdekking, niet aangetoonde foutieve
prijs- of optimizerlogica.

### A12 — Custom env-directory doorbreekt rollbackconsistentie

**Auditstatus:** volledig bevestigd; concrete bug.  
**Direct bewijs:** `METOD_ENV_DIR`/`ENV_FILE` worden afgeleid, maar installerbackup
en rollback refereren ook hardcoded `/etc/adzaagt/metod-pax/metod-pax.env`.

**Advies:** middelgrote prioriteit, maar vóór deployment op custom paths. Test
faultinjectie vóór/na pointerwissel voor default én custom env.

### A13 — Monitoringoppervlak onvoldoende

**Auditstatus:** bevestigd.  
**Direct bewijs:** `_prometheus_metrics` heeft exact elf gauges en geen latency,
HTTP-errors, jobduration/failure, queue age, free inodes, backup-/restorefreshness
of maintenanceerrors. Endpoint vereist interactieve Adminsession.

**Nuance:** readiness controleert vrije bytes/inodes en andere dependencies, maar
is geen historisch monitoring- of alarmkanaal.

### A14 — Privacy/retentie organisatorisch niet afgerond

**Auditstatus:** bevestigd binnen pakketbereik.  
**Direct bewijs:** technische defaults/documentatie bestaan; geen ondertekende
legal basis, verwerkingsoverzicht, DSAR/deletion/breach runbooks of privacy notice
in het pakket.

**Nuance:** dit is grotendeels organisatiebewijs. Niet oplossen door alleen code
te herschrijven.

### A15 — Disaster recovery niet bewezen

**Auditstatus:** bevestigd.  
**Direct bewijs:** lokale backup/restore is sterk en opnieuw 3/3 PASS. De app
doet geen off-host encryptie/replicatie. Flags/proof kunnen fail-closed zijn,
maar bewijzen de provider, sleutelbewaring en clean-host restore niet.

### A16 — Build-/cache-identiteit verwarrend

**Auditstatus:** bevestigd.  
**Direct bewijs:** health toont compatibilitybuild FIX660R8 terwijl canonical
identity R9J8 is. `end_headers` voegt globaal no-store toe. Sommige routes sturen
ook immutable/private cacheheaders, waardoor dubbele/conflicterende headers
mogelijk zijn.

**Nuance:** dit is bewust gedaan om stale ZIP-assets te voorkomen. Het is veilig
maar operationeel onduidelijk en inefficiënt.

### A17 — Assets/licenties niet onafhankelijk afgetekend

**Auditstatus:** bevestigd als bewijsafwezigheid.  
**Direct bewijs:** policy erkent proprietary projectassets en geen zelfstandig
bewijs van rechten voor logo's, materiaalbeelden, DXF's en merknamen.

**Nuance:** juridische eigenaarssignoff, niet primair een softwarepatch.

### A18 — In-memory securitystate heeft operationele grenzen

**Auditstatus:** bevestigd.  
**Direct bewijs:** sessie-/rate-limitdicts en locks zijn process-local; systemd
start één appproces; restart wist state; Nginx heeft aanvullende edge limits.

**Nuance:** één proces is een geldig expliciet model. Het wordt een defect zodra
multiworker/horizontale scaling zonder gedeelde state wordt ingezet.

---

## 4. Wat de audit goed doet

- Zij promoveert geen lokale PASS naar productie-GO.
- Zij laat frozen optimizer/geometrie/pricing/panelcontracten met rust.
- Zij onderscheidt active security van bronhygiëne.
- Zij geeft per finding bewijs, actie en exitcriterium.
- Zij benoemt governance/operations expliciet naast code.
- Zij adviseert een nieuwe revisie in plaats van R9J8 cosmetisch te muteren.
- Zij kiest kleine behavior-preserving checkpoints, geen big-bang rewrite.

---

## 5. Wat aan de audit/evidence ontbreekt

Het audit-ZIP bevat slechts één Markdownbestand van ongeveer 28 KB. Voor een
formele externe auditoverdracht ontbreken:

1. auditororganisatie en individuele reviewer(s);
2. onafhankelijkheidsverklaring;
3. opdracht/scope/signoff;
4. gebruikte toolnamen/versies/configuraties;
5. ruwe SAST/DAST/CVE/secrets/licentieoutputs;
6. commandolog en timestamps per controle;
7. chain of custody van bron naar bevinding;
8. cryptografische handtekening of signed provenance;
9. reproduceerbare machineleesbare findingdatabase;
10. bewijs dat de audit-ZIP zelf aan de R9J8-checkpointidentiteit is gebonden.

Het rapport mag daarom worden genoemd:

> inhoudelijk geverifieerde pre-live technische auditreview

maar nog niet:

> formeel ondertekende onafhankelijke externe auditattestatie

zonder aanvullend bewijs.

---

## 6. Gecorrigeerd prioriteitenbeeld

### P0 — productie-GO blokkeren

- A01 release identity NO-GO;
- A02 browser 0 assertions;
- A03 VPS/operations/CAM ontbreekt;
- A10 onafhankelijke CI/attestatie ontbreekt;
- finale SAST/DAST/CVE/history-secret/licentie/privacy/off-host restore.

### P1 — eerstvolgende code-remediation

1. A06 dormant FIX626-authblok verwijderen.
2. A07 vier unreachable 410-bodies verwijderen.
3. A07 lege `for jp in []` verwijderen.
4. A07 `_merge_raw_quotes` afzonderlijk bewijzen/verwijderen.
5. A12 custom-env rollbackconsistentie herstellen.

### P1 — architectuur/assurance

- A04 servercomposition verder opsplitsen;
- A05 frontendnetwerkownership en script-06 opsplitsen;
- A08 sinks taint-reviewen;
- A09 coveragegate invoeren;
- A11 runtime pinnen/inventariseren;
- A13 monitoring/alerts;
- A16 identity/cachecontract.

### Organisatie-/infrastructuurgates

- A14 privacy/retentie;
- A15 off-host DR;
- A17 assets/licenties;
- A18 scalingmodel;
- CAM/proefsnede/productowner/operationssignoff.

---

## 7. Defensieve conclusie

Het auditbesluit **NO-GO voor publieke productie** moet worden gehandhaafd. De
audit is geen reden om optimizer-, geometrie-, pricing- of paneelalgoritmes te
wijzigen. De juiste technische reactie is:

1. R9J8 bevriezen als remediationbaseline;
2. auditbewijsindex maken;
3. securityverwarrende en bewezen onbereikbare code in kleine nieuwe revisions
   verwijderen;
4. dezelfde lokale orakels na iedere wijziging draaien;
5. browser-, coverage- en onafhankelijke securityevidence toevoegen;
6. pas daarna productie-identieke infrastructuur en werkplaatsacceptatie;
7. een nieuwe, schone, ondertekende final release minten.
