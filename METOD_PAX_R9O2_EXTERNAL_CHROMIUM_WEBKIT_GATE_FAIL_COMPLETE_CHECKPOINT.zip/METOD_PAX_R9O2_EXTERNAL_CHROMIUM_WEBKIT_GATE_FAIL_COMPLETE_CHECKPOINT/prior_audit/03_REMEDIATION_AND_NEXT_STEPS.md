# R9J8 — gecontroleerde herstelroute en volgende stappen

Deze route begint bij exact commit
`9e779bacd300fdf914b479cd3c78682f9e505d66`. R8Z blijft read-only golden.
Iedere stap krijgt een eigen commit, scopecontract, testbewijs en checkpoint. Er
wordt nooit tegelijk opgeschoond, gemodulariseerd en functioneel gewijzigd.

## Waar het project werkelijk staat

De geplande R9-lijn is inhoudelijk ver gevorderd tot R9J8:

- R9A: uitvoerbare R8Z↔R9-orakels en karakterisering;
- R9B: architectuurfundament en regels;
- R9C: pure identifiers, credentials, redaction, headers en pricingcontracten;
- R9D: requestrepository, submission, projectie en maintenancebarrière;
- R9E: jobstatus, admission, scheduler, supervisor, finalization en reconciliation;
- R9F: declaratieve routecatalogus en dispatch;
- R9G: frontend read models, ownership, jobpoller en submit/thank-you;
- R9H: componentextracties en semantische HTML-shell;
- R9I: gerichte legacy-read- en shadow-owner-cleanup;
- R9J1–J3: hermetisch artifact, supply-chainbasis en release-identiteit;
- R9J4–J5: notification projection/message-extractie;
- R9J6–J8: bewezen dode finalization-, label- en Admin-DXF-pijplijnen verwijderd.

Dat is aantoonbare vooruitgang, maar de oorspronkelijke eindarchitectuur is nog
niet bereikt. `server_py.py` is nog 14.375 regels, de frontendlegacybundel nog
9.563 regels en de browsergate heeft nul echte browserassertions. De juiste
omschrijving is daarom: **sterke lokale modulariseringscandidate, nog geen
audit- of productiecandidate**.

## Volgende reeks: eerst concrete herstelpunten

### R9K1 — Dormante FIX626 Admin-auth volledig verwijderen

Scope:

- verwijder alleen het codepad achter de reeds onvoorwaardelijk genomen return;
- behoud de actieve TOTP-, cookie-, origin- en roleflow byte-/gedragsequivalent;
- verwijder geen actieve securitycontrole;
- voeg negatieve bron- en browsertests toe voor password-only login,
  `sessionStorage`-bearers en globale auth-fetchmonkeypatches.

Exit-gate:

- actieve Adminlogin werkt uitsluitend via de huidige route;
- geen Admincredential of bearer in Web Storage;
- routecatalogus, security/privacy, HTTP-smoke, black-box en preflight PASS;
- browsergate blijft eerlijk NO_GO zolang binaries ontbreken.

### R9K2 — Vier bewezen onbereikbare 410-bodies verwijderen

Methodes:

- `_api_admin_materials_save_item`;
- `_api_admin_materials_delete_item`;
- `_api_admin_materials_upload`;
- `_api_admin_material_image_upload`.

Verwijder alleen statements na de eerste onvoorwaardelijke 410-return. Houd de
410-respons, methodehandtekening en routemetadata exact gelijk. Voeg AST-tests toe
die aantonen dat na de return geen body overblijft en HTTP-tests die de status en
payload met R9J8 vergelijken.

### R9K3 — Overige bewezen dead-code één voor één

Eerst het permanente `for jp in []:`-blok. Daarna `_merge_raw_quotes`, maar pas
nadat statische én dynamische referentiecontrole aantonen dat geen indirecte
consumer bestaat. Geen bulk-dead-code-tool op `server_py.py` loslaten.

### R9K4 — Custom environment rollback repareren

De installer accepteert een custom `METOD_ENV_DIR`, maar rollback verwijst naar
`/etc/adzaagt/metod-pax/metod-pax.env`. Maak één gevalideerde env-path-eigenaar en
gebruik die in install, backup en rollback. Test standaardpad, custom pad,
mislukking vóór/na symlinkwissel en herstel van de vorige release.

## Daarna: resterende technische modularisering

### R9L — Backend verkleinen zonder algoritmedrift

Aanbevolen volgorde:

1. actieve Adminpresentatie en actieve auth/sessioncode;
2. observability/metrics;
3. resterende request-/downloadprojecties;
4. statische-file- en HTTP-adapters;
5. resterende joblifecyclefacades.

Voor elke extractie:

- één eigenaar vóór en na de commit;
- importafhankelijkheid alleen richting contract → repository → service → HTTP;
- geen lock kopiëren; dezelfde lockeigenaar injecteren;
- geen stateformaat, route, statuscode of payload wijzigen;
- optimizer, geometry, pricing helper en panel contract niet aanraken;
- vooraf en achteraf de vier frozen behavior hashes controleren.

Doel blijft een dunne composition root, maar dit doel mag nooit worden gehaald
door een grote herschrijving.

### R9M — Frontendownership afronden

1. verplaats alle productiefetches naar `tool-a/api`;
2. haal action-/mutatieownership uit script-06, één flow per checkpoint;
3. verwijder de bijbehorende legacybody zodra de nieuwe owner bewezen is;
4. consolideer inline style-attributen componentgewijs;
5. behandel de submit/thank-you-keten als hoogste risico en als laatste.

Per fysieke tik moet precies één action en maximaal één passend netwerkrequest
worden waargenomen. Reset moet materialen, panelen, nerfgroepen, klant-PII,
capabilities, draft en pollers wissen, maar een al gecommitteerde Adminaanvraag
niet verwijderen.

## Assurancewerk dat niet mag worden overgeslagen

### Browserbewijs

- exact de lockfileversie installeren;
- echte Chromium én echte Playwright-WebKit uitvoeren;
- echte iPhone/Safari-proef apart vastleggen;
- alle 14 fixtures, golden én candidate, zonder skips;
- console/runtime errors, netwerkmethodes/-aantallen en DOM/state vergelijken;
- browserrapport binden aan commit, artifacthash, enginehash en contracts.

### Coverage en security

- coverage.py met fail-threshold: kritisch ≥95%, overige server ≥85%;
- JS coverage voor kritieke Tool A-acties;
- vendor SAST/taintanalyse naast de first-party sinkinventory;
- volledige Git-history secret scan;
- dependency-, OS-/runtime-CVE- en licentiescan;
- ondertekende artifactprovenance en identificeerbare reviewer.

### Productie-identieke infrastructuur

Dit kan later op een definitieve VPS, maar niet worden omzeild voor GO:

- TLS/certificaat/HSTS, firewall en originpolicy;
- één/twee/drie-klant loadtest en queue/admissionbewijs;
- optimizer cancel/timeout/crash/restart onder belasting;
- disk-, inode- en OOM-chaos;
- monitoring van latency, foutpercentages, queue age, jobduur, opslag, backup age;
- versleutelde off-host backup en echte restore;
- CAM/proefsnede en werkplaatssignoff;
- minimaal zeven dagen soak voor dezelfde finale artifacthash.

## Verplichte regressiematrix na ieder checkpoint

- release identity en manifest/checksums;
- R9J-specifieke unit-/scopetests;
- final preflight vanuit een schone extractie;
- HTTP-smoke;
- security/privacy;
- lifecycle, performance en restore als de scope server/deploy raakt;
- R8Z↔candidate server-black-box 12/12;
- resetdifferential;
- browseroracle; een ontbrekende engine blijft NO_GO en wordt nooit PASS;
- repository/source-tree onveranderd door testuitvoering;
- nul residual childprocessen en tijdelijke state.

## Beslisregels voor een nieuwe chat

- Geen productcode wijzigen tijdens een audit- of overdrachtsstap.
- Geen bestaand bewijs sterker formuleren dan het rapport.
- Geen nieuw checkpoint taggen bij een rode lokale gate.
- Geen R8Z-bewijs opnieuw claimen zonder dezelfde fixture opnieuw uit te voeren.
- Een ontbrekende browser/VPS is een expliciete deferred NO_GO, geen reden om
  technisch werk stil te leggen en ook geen reden om productie-GO te geven.
- Na iedere stap melden: commit, scope, gewijzigde bestanden, tests, resterende
  blockers en de eerstvolgende stap.

## Praktische eerstvolgende actie

Start **R9K1** vanaf de R9J8-tag. Verwijder uitsluitend de dormante FIX626-code,
voeg regressietests toe en draai de volledige lokale matrix. Mint pas daarna een
klein R9K1-checkpoint. R9K2 volgt in een afzonderlijke commit; combineer beide
niet, zodat een verschil exact kan worden teruggeleid.

