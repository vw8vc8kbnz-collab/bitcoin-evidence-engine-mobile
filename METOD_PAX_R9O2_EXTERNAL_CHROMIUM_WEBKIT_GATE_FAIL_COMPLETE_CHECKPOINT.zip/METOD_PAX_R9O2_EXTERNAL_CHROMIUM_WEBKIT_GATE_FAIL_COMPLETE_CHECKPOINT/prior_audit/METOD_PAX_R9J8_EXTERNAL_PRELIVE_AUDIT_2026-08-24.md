# Externe pre-live audit — METOD/PAX R9J8

**Auditdatum:** 24 augustus 2026  
**Beoordeelde versie:** R9J8 — `R9J8_DEAD_ADMIN_DXF_PIPELINE_CLEANUP`  
**Auditvorm:** onafhankelijke bron-, artifact-, architectuur-, security-, privacy-, supply-chain-, deployment- en operationele-readinessaudit  
**Besluit:** **NO-GO voor publieke productie**

## 1. Executive conclusion

R9J8 is een serieuze en bovengemiddeld goed beveiligde **auditkandidaat**, maar is nog geen schone liveversie. De artifactintegriteit, het fail-closed productieprofiel, de server-canonical pricing/catalogusketen, de verzegelde DXF-output en de backup-/restorecode zijn sterk. De volledige lokale preflight en de server-side golden/differential tests zijn groen.

De release is desondanks niet productie-eligible. De eigen canonieke release-identiteit verklaart:

- `releaseChannel: AUDIT_CANDIDATE`;
- `status: PROVISIONAL_DEVELOPMENT_ONLY`;
- `releaseEligible: false`;
- browser, VPS en onafhankelijke security-audit: `DEFERRED_NO_GO`;
- `productionGo: false`.

De zwaarste inhoudelijke tekortkomingen zijn:

1. geen enkele echte Chromium/WebKit-uitvoering van de verplichte browseroracle en geen iPhone/Safari-acceptatie;
2. geen productie-identiek VPS-, TLS-, firewall-, load-, chaos-, monitoring-, off-host-restore- of CAM/proefsnedebewijs;
3. geen meetbare coveragegate, onafhankelijke SAST/DAST, volledige Git-history secretscan, externe CVE-scan of juridische licentiecontrole;
4. een backend van 14.375 regels en een legacy frontendruntime van 9.563 regels, met aantoonbaar resterende dode en overlappende code;
5. dormant verouderde Admin-authenticatiecode met password-only/sessionStorage/bearerlogica achter een runtime early-return;
6. onvolledige reproduceerbaarheid en attestatie van de werkelijk gedeployde runtime;
7. onvoldoende operationele metrics en nog geen aantoonbare alarmering/herstelketen.

Er is in deze audit **geen bewezen direct exploiteerbare kritieke kwetsbaarheid** gevonden. De classificatie “kritiek” hieronder betekent dat het ontbreken van bewijs of governance een publieke livegang blokkeert. Het veiligheidsniveau van de actieve servercode is duidelijk beter dan de huidige bronstructuur en release-evidence doen vermoeden.

## 2. Scope en beperking

Beoordeeld zijn de aangeleverde R9J8-checkpoint-ZIP, het ingebedde canonieke candidate-artifact, de bijbehorende volledige Git-bundle, de R8Z-goldenreferentie, applicatiebron, tests, releasecontracten, SBOM, installer/deployscripts en operationele documentatie.

Deze audit omvatte geen toegang tot een echte VPS, DNS, TLS-edge, firewall, off-host backupprovider, monitoringplatform, fysieke iPhone, CAM/CNC of werkplaats. Die onderdelen zijn daarom niet “niet gevonden”, maar **niet bewezen** en blijven harde NO-GO-gates.

Er zijn geen bronwijzigingen uitgevoerd.

## 3. Artifact- en provenancebewijs

| Onderdeel | Vaststelling |
|---|---|
| Aangeleverde outer checkpoint-ZIP | SHA-256 `6fd25430ebdac198e49adbfd1b656f7d357e1b662cf762d1e4bca7fed752f970` |
| Canonieke inner candidate-ZIP | SHA-256 `aa3c53788d655626318471a9280b3daf7afe5680d2e37f968d596fa126cb8af4` |
| Candidate `SHA256SUMS.txt` | SHA-256 `fab153c1e0c02dc3e8c2eff1650f2880a0b4d65ae8dd7d088b9f2cca5532a068` |
| Git implementationcommit | `db44a2783ab9e7749a292bf1b51f2435e1060eae` |
| Git evidence/final commit | `9e779bacd300fdf914b479cd3c78682f9e505d66` |
| Tag | `r9j-dead-admin-dxf-pipeline-cleanup-checkpoint` |
| ZIP versus Git `candidate/` tree | exact gelijk; 355 bestanden aan beide zijden |
| ZIP-hygiëne | één root, geen duplicate members, traversal, absolute paden of symlinks |
| Git-objectdatabase | `git fsck --full` zonder objectfouten; alleen een technisch unborn lokale HEAD na bundle-fetch |
| Commit-/tagsignatuur | geen cryptografische handtekening; `git verify-commit` en `git verify-tag` melden “no signature found” |

De outer checkpoint-ZIP is niet het bestand dat rechtstreeks gedeployd moet worden. Het canonieke runtime-artifact is de inner `METOD_PAX_R9J8_DEAD_ADMIN_DXF_PIPELINE_CANDIDATE.zip`. Ook dat bestand is uitdrukkelijk een candidate, geen finale productieartifact.

## 4. Wat aantoonbaar sterk is

- De volledige verse `final_preflight.py --verify-checksums` eindigt PASS.
- R9J8-specifieke cleanup: 7/7 PASS.
- Server lifecycle: 11/11 PASS.
- Performance-/capaciteitsfixtures: 11/11 PASS.
- Server golden black-box: 12/12 fixtures en 47/47 assertions PASS.
- Resetdifferential: 3/3 assertions PASS.
- HTTP-smoke, security/privacy, restore en first-party supply-chaingates zijn lokaal groen.
- Python compile, alle shellscripts met `bash -n` en alle productie-JavaScriptbestanden met `node --check` zijn syntactisch groen.
- `dxf_nesting_optimizer.py`, `dxf_geometry.py`, `pricing_helpers.py` en `panel_contract.py` zijn bytegelijk aan de R8Z-goldenbaseline.
- Publieke materiaalidentiteit, prijs en btw worden server-canonical bepaald; clientquotes zijn niet leidend bij submit.
- Definitieve jobs en downloads worden gekoppeld aan verzegelde outputmanifesten en vaste root-resolutie.
- Cataloguspublicatie gebruikt preview/reviewhash, actor, signoff en rollback van library/signoff bij commitfouten.
- Catalogusafbeeldingen gebruiken HTTPS-hostallowlisting, publieke-IP-controle, DNS/IP-pinning, redirecthercontrole, byte-/pixelgrenzen en metadatareductie.
- Productie-Admin gebruikt individuele users, PBKDF2-SHA256/260.000, TOTP, HttpOnly/Secure/SameSite=Strict cookie, idle/absolute expiry en exact-origin controles.
- Productie draait non-root, zonder capabilities, met een streng systemd-sandboxprofiel en externe mutable state.
- Installer zet de edge eerst in maintenance, bewaart infrastructuurconfig, wisselt de immutable releasepointer atomisch en rolt vóór edge-reopen release/config terug zonder state terug te draaien.
- Backup en restore hebben manifesthashes, begrenzing, fsync/atomische publicatie en zip-slip/symlink/duplicate-padverdediging.

Dit is een goede basis. De resterende acties zijn geen reden om de sterke onderdelen te herschrijven. In het bijzonder moeten optimizer-, geometrie-, pricing- en paneelcontracten alleen onder de bestaande frozen-core wijzigingsprocedure worden aangeraakt.

## 5. Bevindingen

### R9J8-A01 — Release is canoniek zelf NO-GO

**Ernst:** kritiek / releaseblokkade  
**Bewijs:** `RELEASE_IDENTITY.json`, `RUNTIME_CONTRACT.json`, `SBOM.cdx.json` en het R9J8-checkpoint verklaren de versie provisional, niet release-eligible en zonder externe evidence.

**Vereiste actie:** maak pas na sluiting van alle P0/P1-gates een nieuwe finale revisie. Verander de identiteit niet cosmetisch in R9J8; bouw een nieuw artifact uit een schone checkout, met een production release channel, unieke runtimebuild en `releaseEligible: true` dat door echte bewijslinks wordt onderbouwd.

**Exitcriterium:** één canoniek identitydocument, artifactnaam, SBOM, healthbuild, Git-tag en change record verwijzen naar dezelfde finale revisie; geen `CANDIDATE`, `PROVISIONAL` of `DEFERRED_NO_GO` resteert.

### R9J8-A02 — Verplichte browsergate heeft 0 echte assertions uitgevoerd

**Ernst:** kritiek / releaseblokkade  
**Bewijs:** `R9J8_BROWSER_GATE_NO_GO.json` bevat 14/14 geblokkeerde fixtures, nul geslaagde fixtures en vereist Chromium plus WebKit. De pinned Playwrighttoolchain is beschreven maar niet uitgevoerd.

**Vereiste actie:** voer de volledige R8Z↔finale-candidate differential oracle uit met exact de gelockte Node/Playwrightversie en echte Chromium- en WebKit-binaries. Bewaar traces, screenshots, console/networklogs en machineleesbare resultaten als CI-artifacts. Voer daarnaast de mobiele gates uit op het gemelde iPhone/Safari-model en minstens één extra ondersteunde iOS-versie.

**Exitcriterium:** 14/14 fixtures in beide engines PASS, 100% van de kritieke Tool A-flows groen, nul skips/xfails/blockers en afgetekend fysiek iPhonebewijs.

### R9J8-A03 — Productie-, werkplaats- en operationeel bewijs ontbreekt

**Ernst:** kritiek / releaseblokkade  
**Bewijs:** geen echte VPS-/TLS-/firewallinspectie, productie-identieke load/chaostest, disk-/inode-faultinjectie, CAM-validatie, fysieke proefsnede, monitoringbewijs of off-host restorebewijs in het pakket. De eigen go-livechecklist laat deze vakken open.

**Vereiste actie:** voer alle gates uit hoofdstukken 2–7 van `GO_LIVE_GATES_FIX660R8.md` uit op productie-identieke infrastructuur. Koppel ieder resultaat aan datum, omgeving, artifacthash, uitvoerder en eigenaar.

**Exitcriterium:** productowner, CAM/werkplaats, materiaal/pricing, security/privacy en operations hebben ieder een naam, datum, besluit en bewijslink ingevuld; alle verplichte vakken zijn groen.

### R9J8-A04 — Backend is geen schone composition root

**Ernst:** hoog / clean-releaseblokkade  
**Bewijs:** `app/server_py.py` is 14.375 regels, 703.989 bytes, circa 374 functies en bevat routing, Admin HTML/CSS/JS, auth, catalogus, pricing, jobs, backup, logging en maintenance. Complexiteitshotspots zijn onder meer `_write_human_calculation_summary` (479 regels), `_api_status` (405), `_generate_stickertool_json` (300), `_create_job_from_payload` (513) en `validate_submit_payload` (297).

**Risico:** uitzonderlijk hoge regressiekans, reviewblinde vlekken, lastig ownership, moeilijk meetbare dekking en te grote security-impact per wijziging.

**Vereiste actie:** vervolg de behavior-preserving extractie totdat `server_py.py` uitsluitend compositie/startup bevat. Scheid minimaal Admin-presentatie, auth/session, HTTP-responses, catalogusservice, pricingservice, joborkestratie, retention/backup, metrics en routecontrollers. Behoud alle publieke contracten en goldenbytes tijdens iedere kleine checkpoint.

**Exitcriterium:** `server_py.py` maximaal 250 regels en zonder businesslogica; geen productiedefinitie groter dan 100 regels zonder expliciete auditor-waiver; kritieke complexiteit begrensd en automatisch bewaakt.

### R9J8-A05 — Frontend blijft grotendeels legacy en heeft verdeeld netwerkownership

**Ernst:** hoog / clean-releaseblokkade  
**Bewijs:** `script-06-legacy-application-runtime.js` telt 9.563 regels en circa 349 benoemde functies. Van twaalf `fetch`-locaties staan er slechts twee in de canonieke `tool-a/api/*` modules. Directe fetches blijven in de early catalog bootstrap en legacy runtime voor manifest, DXF, logging, catalogus, cancel en draft.

**Vereiste actie:** verplaats alle netwerk-I/O naar typed/contracted API-modules; laat componenten alleen commands/selectors gebruiken. Splits legacy runtime per ownershipgebied en verwijder compatibility bridges pas na differentialbewijs. Verplaats de 157 inline `style=` attributen naar stylesheets.

**Exitcriterium:** nul directe `fetch` buiten `tool-a/api`; nul globale businessstatepublicaties zonder gedocumenteerde adapter; legacy runtime verwijderd of teruggebracht tot een kleine expliciete bootstrap; nul inline style-attributen.

### R9J8-A06 — Dormante verouderde Admin-authcode is aanwezig

**Ernst:** hoog / security-hygiëneblokkade  
**Bewijs:** in `ADMIN_HTML` staat een volledige oude “FIX626”-IIFE die door `window.__ADZAAGT_ADMIN_AUTH_FIX626__` direct retourneert. Het onbereikbare blok implementeert password-only login, verwacht een bearer `token`, bewaart die in `sessionStorage` en monkey-patcht `window.fetch`. De actieve implementatie gebruikt terecht TOTP plus HttpOnly cookie.

**Risico:** securityverwarring, kans op onbedoelde reactivatie en fout-positieve/fout-negatieve audituitkomsten.

**Vereiste actie:** verwijder het volledige onbereikbare blok en voeg een test toe die bearer/sessionStorage Admin-auth en password-only productie-login expliciet verbiedt.

**Exitcriterium:** één Admin-authimplementatie; geen Admin-token in Web Storage; productie-login vereist wachtwoord én TOTP; logout/revoke/timeouts getest op de echte edge.

### R9J8-A07 — Cleanup is aantoonbaar nog niet compleet

**Ernst:** hoog voor clean release, middel voor directe runtimeveiligheid  
**Bewijs:** `_api_admin_materials_upload` retourneert direct HTTP 410 waarna circa 85 regels onbereikbare legacy uploadcode blijven staan. `_merge_raw_quotes` beslaat 82 regels en komt alleen bij de definitie voor. Daarnaast zijn meerdere één-occurrence serverhelpers en vijf benoemde JS-functies zeer waarschijnlijk ongebruikt. Ook `api_admin_requests` bevat een permanent lege legacylus (`for jp in []`).

**Vereiste actie:** verwijder eerst de bewezen onbereikbare blokken. Verifieer elke één-occurrence kandidaat met AST/callgraph, routecatalogus, dynamische attributen en volledige tests. Laat mogelijke dode functies in de frozen optimizer/geometrie staan of behandel ze in een afzonderlijk goedgekeurd frozen-coretraject.

**Exitcriterium:** nul code na onvoorwaardelijke return, nul permanent lege loops, nul ongewaived high-confidence dead definitions en een automatische dead-codegate die geen hardcoded functietellingen als enige bewijs gebruikt.

### R9J8-A08 — XSS/SAST-bewijs is te oppervlakkig

**Ernst:** hoog / security-assuranceblokkade  
**Bewijs:** productie-JS bevat 91 `innerHTML`-assignments en één `insertAdjacentHTML`. Er is geen `eval`, `new Function` of `document.write`, en CSP is sterk voor scripts, maar de first-party supply-chaingate telt sinks vooral tegen een verwachte inventaris; zij bewijst geen taintflow of correcte escaping.

**Vereiste actie:** laat alle sinks handmatig en met een onafhankelijke SAST/tainttool beoordelen. Vervang dynamische HTML waar mogelijk door `textContent`/DOM-constructie; centraliseer en test escaping/sanitizing. Voeg adversarial payloads toe voor klant-, materiaal-, bestands-, status- en foutvelden en voer een geauthenticeerde DAST uit.

**Exitcriterium:** iedere sink heeft een veilige bron/sanitizer of is verwijderd; onafhankelijke SAST en DAST hebben geen open high/critical findings; CSP-browsercontrole is groen.

### R9J8-A09 — Geen meetbare coveragegate

**Ernst:** hoog / releaseblokkade  
**Bewijs:** veel goede outcome-tests zijn aanwezig, maar geen coverageconfiguratie, coverageartifact of afdwingbare branch-/statementthreshold.

**Vereiste actie:** instrumenteer productie-Python en kritieke frontendmodules in hosted CI. Meet echte branch coverage, niet alleen statement coverage. Sluit gegenereerde fixtures uit maar niet de giant owners.

**Exitcriterium:** kritieke security/pricing/catalogus/job/finalisatiecode minimaal 95% branch coverage; overige productie-servercode minimaal 85% statement coverage; kritieke Tool A-flows 100% browser-oracledekking; thresholds blokkeren merges.

### R9J8-A10 — CI en supply chain leveren geen onafhankelijke release-attestatie

**Ernst:** hoog / releaseblokkade  
**Bewijs:** de workflow draait checkout, first-party regex/AST-gates, identitycheck en artifactbuild. Zij draait geen browseroracle, coverage, CodeQL/Semgrep, volledige historyscan met gitleaks/trufflehog, OSV/dependencyscan, licentiescanner, artifactretentie of provenanceattestatie. Alle 73 commits en de tag zijn unsigned. Een aanvullende eenvoudige historiescan vond geen private-key/AWS/GitHub/Slack-tokenpatronen, maar wel veel generieke test-/codehits en vervangt geen secretscanner.

**Vereiste actie:** bouw een protected hosted releaseworkflow met pinned actions, coverage, onafhankelijke SAST, history-secretscan, dependency/CVE-scan, licentiescan, browseroracle en artifact upload. Genereer CycloneDX/SPDX voor de werkelijke runtime en onderteken artifact/checksum/provenance met Sigstore of organisatie-PKI.

**Exitcriterium:** groene hosted run op de finale commit; immutable logs/artifacts; signed tag/commit of signed provenance; verifieerbare artifactattestatie die source commit, builder en SHA-256 bindt.

### R9J8-A11 — Werkelijke productieruntime is niet reproduceerbaar of volledig geïnventariseerd

**Ernst:** hoog  
**Bewijs:** de app start `/usr/bin/python3`, zonder vaste Python patchrelease of hermetische omgeving. Pillow is optioneel (`>=10,<13`) en gedrag/prestaties verschillen afhankelijk van wat globaal geïnstalleerd is. Nginx, OpenSSL, systemd, libc en OS-packages ontbreken in het artifact-SBOM.

**Vereiste actie:** kies één reproduceerbaar runtimeprofiel: bij voorkeur een digest-pinned container, anders een vast OS-image plus pinned Python patch en hash-locked venv. Maak Pillow verplicht en exact gepind of schakel de optionele import uit. Leg alle gedeployde componenten en versies vast en scan het resulterende image/host-SBOM.

**Exitcriterium:** dezelfde source levert byte-/digest-identieke runtime; onverwachte globale Pythonpackages beïnvloeden gedrag niet; complete runtime-SBOM en CVE-resultaat horen bij het change record.

### R9J8-A12 — Configureerbare env-directory doorbreekt rollbackconsistentie

**Ernst:** middel, hoog bij afwijkende deploypaden  
**Bewijs:** installer en deploy accepteren `METOD_ENV_DIR`, maar configbackup en rollback gebruiken deels hardcoded `/etc/adzaagt/metod-pax/metod-pax.env`. Bij een toegestane custom env-directory is de transactie dus niet volledig symmetrisch.

**Vereiste actie:** gebruik overal de afgeleide `$ENV_FILE`/`$ENV_DIR`; vermijd dubbele vaste paden. Voeg faultinjectietests toe vóór/na pointerwissel, met defaults én custom paden.

**Exitcriterium:** iedere geforceerde fout vóór edge-reopen herstelt exact pointer, env, systemd en Nginx; state blijft voorwaarts behouden; bewijs bevat voor/na hashes.

### R9J8-A13 — Monitoringoppervlak is onvoldoende voor live operations

**Ernst:** hoog / operationele releaseblokkade  
**Bewijs:** `/api/admin/metrics` geeft elf actuele gauges, maar geen HTTP-error-/latencycounters, jobduur/-fouten, queueleeftijd, inodevrijte, backupouderdom/-succes, restoreproofleeftijd of maintenancefouten. Het endpoint vereist een interactieve Adminsessie en er is geen service-to-service scrapecontract of monitoringdeploy. Readiness kan groen blijven terwijl periodieke backup/retention herhaald faalt.

**Vereiste actie:** voeg counters/histograms en freshness/errorgates toe; ontsluit metrics alleen intern via mTLS, Unix socket, loopback sidecar of aparte machinecredential. Configureer dashboards, SLO's, alerts, routing en een externe calculate→price→submit synthetic zonder echte klant-PII.

**Exitcriterium:** diskbytes/inodes, service, HTTP 4xx/5xx/latency, jobduur/fouten/timeouts, queue depth/age, backup age/success, restoreproof age, catalogus/pricing readiness en maintenancefouten worden gemonitord; testalerts bereiken de benoemde wachtdienst.

### R9J8-A14 — Privacy- en bewaarbeleid is technisch, niet organisatorisch afgerond

**Ernst:** hoog / compliance-releaseblokkade  
**Bewijs:** PII-vrije actieve index, redaction en technische retentie zijn sterk. Defaults zijn 90 dagen actief + 90 dagen archief voor terminale requests en maximaal 365 dagen voor open requests; backups kunnen langer bestaan. De documentatie vereist nog expliciete owneracceptatie. Geen bewijs van register van verwerkingen, verwerkersafspraken, privacyverklaring, inzage/verwijderprocedure of incident-/datalekproces is meegeleverd.

**Vereiste actie:** laat privacy/legal doel, grondslag, minimale velden, termijnen per state/log/backup/notification, ontvangers en rechtenprocedures vastleggen. Test dat een verwijder-/inzageverzoek alle actieve, archief-, log- en backupbeperkingen correct behandelt. Beperk ntfy-klantdetails tot expliciet goedgekeurde noodzaak.

**Exitcriterium:** getekende privacy-/retentiematrix, actuele privacyverklaring en uitvoerbaar DSAR/verwijder-/datalekrunbook; technische defaults sluiten daarop aan.

### R9J8-A15 — Backup is lokaal goed, maar disaster recovery is niet bewezen

**Ernst:** hoog / operationele releaseblokkade  
**Bewijs:** lokale ZIP-backups zijn mode 0600 en goed geverifieerd, maar worden door de applicatie niet versleuteld of off-host geplaatst. Productie vertrouwt op `OFFSITE_BACKUP_VERIFIED=1`, providertekst en restoreproof; het pakket bewijst de externe kopie, sleutelbewaring, immutability of een restore vanaf die kopie niet.

**Vereiste actie:** automatiseer versleutelde off-host replicatie met gescheiden sleutelbeheer, object lock/versioning en monitorbare RPO. Herstel naar een schone host uitsluitend vanaf de off-host kopie en voer functionele job/request/cataloguscontroles uit.

**Exitcriterium:** gedateerd bewijs bindt off-host objecthash aan `restore_test_proof.json`; RPO/RTO gehaald; sleutel- en ransomware-/providerverliesprocedure getest.

### R9J8-A16 — Build-/cache-identiteit is operationeel verwarrend

**Ernst:** middel  
**Bewijs:** publieke `/health/live` en `/health/ready` rapporteren alleen `FIX660R8_PRELIVE_HARDENED`, terwijl R9J8 de echte release is. Tool A bevat wel R9J8-meta. Alle responses, ook versioned statics, krijgen globaal `no-store`, wat stale assets voorkomt maar productiecache/performance benadeelt.

**Vereiste actie:** rapporteer afzonderlijk `releaseRevision`, `releaseBuild`, `compatibilityProtocol` en artifacthash in interne health/diagnostics. Gebruik content-hashed assets met `public,max-age=31536000,immutable`; houd HTML/API/private downloads op `no-store`.

**Exitcriterium:** operators kunnen backend én frontend ondubbelzinnig aan dezelfde artifacthash koppelen; geen gemengde assets in chaosdeploy; cacheheaders zijn route-/asset-specifiek getest.

### R9J8-A17 — Assets en licenties zijn niet onafhankelijk afgetekend

**Ernst:** middel / juridische releaseblokkade indien rechten ontbreken  
**Bewijs:** bronbeleid noemt projectassets proprietary maar erkent dat rechten op logo's, materiaalafbeeldingen, DXF's en merknamen niet zelfstandig zijn bewezen.

**Vereiste actie:** laat eigenaar/herkomst/licentie voor elk extern logo, beeld, materiaaldata, DXF en merkgebruik vastleggen; laat de werkelijke runtime-SBOM juridisch beoordelen.

**Exitcriterium:** getekend assetregister en geen onbekende of onverenigbare licenties.

### R9J8-A18 — In-memory securitystate heeft operationele grenzen

**Ernst:** middel  
**Bewijs:** Adminsessies en applicatieratelimits zijn proceslokaal. Een restart logt veilig iedereen uit, maar wist ook mislukte-loginstate; horizontale scaling zou inconsistente sessies/limits geven. Nginx voegt wel edge-ratelimits toe.

**Vereiste actie:** documenteer en enforce één applicatieproces zolang dit ontwerp geldt, of gebruik een gedeelde TTL-store voor sessies, revoke en abuse-limits. Voeg accountgebaseerde detectie/alerting toe zonder usernames/PII onveilig te loggen.

**Exitcriterium:** gekozen scalingmodel is expliciet; restart/multiworker tests bewijzen sessie- en rate-limitgedrag; brute-force alerts werken.

## 6. Exact remediatiepad naar een schone liveversie

### Fase 0 — Releasebasis bevriezen

1. Markeer R9J8 definitief als auditbaseline, niet als liveartifact.
2. Maak een nieuwe revisielijn voor remediation.
3. Behoud de vier R8Z-protected behaviorfiles byte-exact, tenzij een afzonderlijk change request met nieuwe goldenbaseline wordt goedgekeurd.
4. Maak één evidence-index met per gate: ID, eigenaar, omgeving, commit, artifacthash, datum, status en link.

### Fase 1 — Dode/securityverwarrende code verwijderen

1. Verwijder dormant FIX626 Admin-authblok.
2. Verwijder de onbereikbare body van `_api_admin_materials_upload` en de lege `for jp in []`-lus.
3. Verwijder `_merge_raw_quotes` en daarna alleen bewezen ongebruikte helpers, per klein checkpoint.
4. Voeg gates toe voor code na unconditional return, permanent lege iterables, dubbele authmodellen en Admin-tokens in Web Storage.
5. Draai na ieder checkpoint checksums, volledige preflight, 12/12 servergolden, reset- en browserdifferential.

### Fase 2 — Architectuur en frontendownership voltooien

1. Extraheer Admin HTML/CSS/JS uit `server_py.py`.
2. Extraheer auth/session, response/securityheaders, catalogus, pricing, jobs/finalisatie, backup/retention en metrics naar duidelijke modules/controllers.
3. Reduceer `server_py.py` tot een composition root van maximaal 250 regels.
4. Centraliseer alle Tool A-netwerkverkeer in `tool-a/api`.
5. Breek `script-06` op langs dezelfde domeingrenzen en verwijder globals/timers/bridges zodra browseroracles groen zijn.
6. Verwijder inline styles en maak CSP gereed om ook `style-src-attr 'unsafe-inline'` te schrappen.

### Fase 3 — Onafhankelijke security en kwaliteit

1. Hosted CI met branchcoverage en harde thresholds.
2. Onafhankelijke SAST/taintscan plus handmatige review van alle HTML-sinks.
3. Volledige Git-history secretscan.
4. Dependency-, OS-image- en CVE-scan van de echte runtime.
5. Geauthenticeerde DAST/pentest op staging, inclusief traversal, double encoding, cross-job tokenmatrix, CORS/CSRF, session/cookie/TOTP, SSRF, oversized/chunked requests, slow clients en export/downloads.
6. Privacy/legal en asset/licentiesignoff.

### Fase 4 — Reproduceerbare runtime en operations

1. Pin OS/runtime/Python/Pillow/Nginx/OpenSSL of bouw een digest-pinned image.
2. Herstel de custom-env rollbackbug en voer deployfaultinjectie uit.
3. Implementeer complete metrics, interne scrape-auth, dashboards, SLO's en alerts.
4. Repliceer backups encrypted/off-host; voer clean-host restore uit.
5. Run productie-identieke load/chaos/disk-full/inode-full/restart/cancel/timeouttests.
6. Test TLS, redirect, firewall, systemd-effective settings en logretentie op de echte VPS.

### Fase 5 — Product- en werkplaatsacceptatie

1. Voer alle 14 browserfixtures uit in Chromium en WebKit.
2. Voer de volledige mobiele checklist uit op twee iOS/Safari-combinaties.
3. Laat artikel, decor, dikte, plaatmaat, btw en prijs handmatig steekproeven.
4. Laat onafhankelijke CAM de golden outputs importeren.
5. Controleer ARC 0/90/180/270, asymmetrische nerf, labels/placements, Admin-DXF-namen en voer een fysieke proefsnede uit.
6. Leg eigenaar vast voor handmatige factuur/Odoo-opvolging en de twee-werkdagbelofte.

### Fase 6 — Finale release minten

1. Bouw uit een schone, protected commit in hosted CI.
2. Maak een minimale, hermetische production artifact en een apart evidencepakket.
3. Genereer complete SBOM, checksums en provenance.
4. Onderteken tag, artifact en attestatie.
5. Deploy eerst staging, daarna production onder change control.
6. Laat alle vijf rollen het uiteindelijke GO-besluit tekenen.

## 7. Harde finale GO-definitie

Publieke livegang mag uitsluitend plaatsvinden wanneer gelijktijdig waar is:

- nieuwe finale release-identiteit is consistent en production-eligible;
- artifact, manifest, commit/tag en provenance zijn cryptografisch verifieerbaar;
- alle lokale bestaande tests blijven groen;
- coverage voldoet aan 95% critical branch / 85% overige server statements;
- Chromium en WebKit: 14/14 fixtures PASS, nul skips;
- twee fysieke iOS/Safari-acceptaties PASS;
- onafhankelijke SAST, history-secretscan, CVE-scan en DAST hebben geen open critical/high;
- productie-VPS, TLS, firewall, systemd en Nginx zijn effectief geïnspecteerd;
- load/chaos/disk/inode/restart/cancel/timeout-SLO's zijn gehaald;
- encrypted off-host backup en clean restore zijn bewezen;
- monitoring, synthetic en alertescalatie zijn bewezen;
- catalogus/pricing-signoff en handmatige prijssteekproef zijn groen;
- CAM, labels/placements en fysieke proefsnede zijn afgetekend;
- privacy/retentie, licenties/assets en operationsrunbooks zijn goedgekeurd;
- productowner, CAM/werkplaats, materiaal/pricing, security/privacy en operations hebben ieder expliciet GO gegeven.

Als één punt ontbreekt, blijft het besluit **NO-GO**.

## 8. Eindbeoordeling

R9J8 laat zien dat de kern van de tool serieus is gehard en dat de makers regressies bewust proberen te voorkomen. De configurator, optimizer-, DXF-, pricing-, catalogus-, aanvraag- en Admin-keten zijn inhoudelijk duidelijk te begrijpen en grotendeels coherent. De release is echter nog halverwege twee doelen: behavior-preserving modularisering en aantoonbare productieacceptatie.

De snelste verantwoorde route is daarom niet R9J8 “live verklaren”, maar:

1. securityverwarrende/dode code eerst verwijderen;
2. browser, coverage en onafhankelijke security-evidence verplicht maken;
3. runtime en operations reproduceerbaar/bewezen maken;
4. daarna pas een nieuwe, ondertekende finale release minten.

**Definitief auditbesluit voor R9J8: NO-GO voor publieke productie; geschikt als gecontroleerde remediationbaseline.**
