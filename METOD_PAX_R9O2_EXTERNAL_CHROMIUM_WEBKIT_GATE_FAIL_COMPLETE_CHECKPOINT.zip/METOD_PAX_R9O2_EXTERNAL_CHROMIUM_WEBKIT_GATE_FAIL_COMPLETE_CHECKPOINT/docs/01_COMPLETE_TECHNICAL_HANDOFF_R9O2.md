# Complete technische overdracht — R9O2 extern browsergate-FAIL-checkpoint

## 1. Hervatpunt

R9O2 heeft de ongewijzigde R9O1-runtime extern getest. De runtime is niet
aangepast; dit checkpoint voegt uitsluitend authentiek VPS-bewijs,
classificatie en een begrensd vervolgplan toe.

- geteste runtimecommit: `d6f43a8918c2c7ed77d9d52d502917ee75c4b2c3`;
- geteste tag: `r9o1-browser-gate-defect-remediation-checkpoint`;
- runtime-ZIP: `METOD_PAX_R9O1_BROWSER_GATE_DEFECT_REMEDIATION_CANDIDATE.zip`;
- runtime-SHA-256: `be3e941b4bdbbb2674d6a175e15b2a7530f25e371e6916b46fdea117bc0b1ec2`;
- runtimemanifest: `57bb221c877eaa1081192df28bd3b61f91185968b9ed18302004bb12a61fae6f`;
- immutable R8Z-ZIP-SHA-256: `d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62`;
- R9O2-gatestatus: `FAIL`;
- releaseEligible: `false`;
- productie: `NO_GO`;
- volgende stap: `R9O3_WEBKIT_FAILURE_REMEDIATION`.

Gebruik altijd de complete outer checkpoint-ZIP. De inner runtime-ZIP is de
daadwerkelijke applicatiekandidaat. R8Z is alleen de immutable behavior-oracle.

## 2. Wat de tool is

METOD/PAX Tool A is de Adzaagt-webapplicatie voor het configureren en aanvragen
van maatwerk METOD- en PAX-fronten/panelen. De browserflow beheert onder meer:

- materiaalcatalogus en materiaalbatches;
- deur-, ladefront- en paneelconfiguratie;
- DXF-gedreven formaten en previewdata;
- doorlopende nerfgroepen en previews;
- klantgegevens, prijsjob, aanvraag en bedankflow;
- jobstatus, annulering, herstel na optimizerfouten;
- beveiligde Admin-login, sessie, aanvragen, downloads en DXF-presentatie.

De Pythonruntime bezit HTTP-routing, beveiligingsheaders, sessies, publieke en
Admin-API's, duurzame job/requeststate, admission/FIFO, processupervisie,
optimizeruitvoering, finalisatie en statische assets. De frontend is modulair
gesplitst. De publieke Tool A-shell en de Adminpresentatie hebben externe CSS en
JavaScript; de browsercontracten bewaken gedrag, beveiliging en layout.

## 3. Architectuur- en veiligheidsgrenzen

- R8Z is immutable en mag nooit worden gerepareerd of opnieuw verpakt.
- De kandidaat wordt differentieel tegen R8Z uitgevoerd, behalve expliciete
  candidate-conformancefixtures voor bewust herstelde beveiligings/privacy-
  eigenschappen.
- Optimizer, nesting, geometrie, prijs- en finalisatiealgoritmen vallen buiten
  deze browserremediatie tenzij bewijs een directe regressie aantoont.
- Interne artikelnummers blijven uit publieke API, DOM, fouten en downloads.
- Adminauth gebruikt HttpOnly-sessiecookies, origin-/CSRFbeleid en beschermde
  assetroutes; verwachte ongeauthenticeerde 404's mogen niet als lek worden
  'gerepareerd'.
- Mutable state wordt nooit met een code-rollback teruggedraaid.
- Geen checkpoint wordt live of production-ready genoemd zolang een harde gate
  rood, geblokkeerd of niet uitgevoerd is.

## 4. Exacte externe uitvoering

De VPS draaide Ubuntu 26.04 LTS, x86_64, 2 vCPU, 3,7 GiB RAM en 8 GiB swap. De
test gebruikte het officiële Playwright 1.62.0 Noble-image op vaste digest,
Node 24.18.0 en Python 3.12.3. De container had geen extern netwerk tijdens de
browserrun. Chromium 151.0.7922.34 en WebKit 26.5 startten als echte processen.

De eerste run stopte fail-closed op Git dubious ownership. De tweede run zette
alleen in de wegwerpcontainer `/audit/repo` als safe directory. De 13 unit-
tests voor het browserorakel passeerden in beide pogingen.

## 5. Gate-uitkomst

- 15 fixtures uitgevoerd;
- 100 vereiste contractasserties beoordeeld;
- 8 fixtures PASS in alle vereiste profielen;
- 7 fixtures FAIL;
- 0 geblokkeerde fixtures;
- geen totale engine-PASS;
- kandidaat en R8Z voor/na byte-ongewijzigd;
- totale status `FAIL`.

De acht volledig geslaagde fixtures bewijzen onder meer catalogus/winkelwagen,
mobiele bediening, mobiele nerfpreview, klantsnapshot, autoritatieve prijs,
iPhone-bedankflow, PII-reset en optimizercrashherstel in beide echte engines.

## 6. Open bevindingen

1. WebKit meldt embedded-DXF access-control-page-errors in zowel R8Z als
   kandidaat tijdens de wizardfixture. Dit vereist lifecycle-/orakelstabilisatie
   of een aangetoonde echte runtimefix; geen brede allowlist.
2. Vier desktopflows tonen kandidaatspecifieke WebKit ResizeObserver-loops.
3. De gecontroleerde actieve jobstatus wordt in WebKit niet waargenomen in
   R8Z noch kandidaat; de cancellationfixture mist deterministische synchronisatie.
4. Admin overflowt in WebKit-iPhone: 528 pixels binnen een 393-pixelviewport.
5. De eerste containerinvocatie miste een ephemeral Git-safe-directoryinstelling.

Lees voor exacte waarden `R9O2_EXTERNAL_CHROMIUM_WEBKIT_GATE_RESULT.json` en
het authentieke rapport onder `reports/r9o2_external_vps/`.

## 7. HTML-splitstatus

De professionele split blijft aanwezig: semantische Admin-HTML, externe
`admin.css`, `admin.js` en `dxf.js`, plus externe loginassets. De 404-meldingen
voor ongeauthenticeerde GET-verzoeken naar beschermde assets zijn verwacht en
bevestigen de authgrens. R9O2 toont echter dat de split nog een concrete
responsive WebKit-iPhone-layoutcorrectie en vermoedelijk een
ResizeObserver/layoutcorrectie nodig heeft voordat de browsergate groen kan.

## 8. Hervatten in een nieuwe chat

1. Verifieer `PACKAGE_MANIFEST_SHA256.txt` van de outer ZIP.
2. Lees `README_FIRST.md`, deze overdracht, het R9O2-resultaat en
   `R9O2_NEXT_STEP_R9O3.md`.
3. Verifieer de runtime- en R8Z-ZIP tegen hun sidecars.
4. Verifieer de VPS-evidence met `reports/r9o2_external_vps/SHA256SUMS.txt`.
5. Clone de meegeleverde Git-bundle en checkout de R9O2-checkpointtag.
6. Bevestig dat de runtime nog R9O1 is en dat R9O2 alleen bewijs toevoegde.
7. Start uitsluitend R9O3 volgens de vier failuregroepen.
8. Bouw na remediatie een nieuwe runtime; overschrijf of herlabel R9O1 niet.
9. Voer de volledige gate opnieuw uit in `tmux` op exact dezelfde image/digest.

## 9. Resterende live-gates na browserremediatie

Zelfs een volledig groene R9O3-browserrerun is niet automatisch productie-GO.
Daarna blijven ten minste echte iPhone/Safari, kandidaat-VPS met edge/TLS/
systemd/Nginx, onafhankelijke security/full-history secretscan, load/chaos/soak,
off-host restore, observability/operations, CAM/werkplaats/bedrijf en formele
release-signoff vereist.
