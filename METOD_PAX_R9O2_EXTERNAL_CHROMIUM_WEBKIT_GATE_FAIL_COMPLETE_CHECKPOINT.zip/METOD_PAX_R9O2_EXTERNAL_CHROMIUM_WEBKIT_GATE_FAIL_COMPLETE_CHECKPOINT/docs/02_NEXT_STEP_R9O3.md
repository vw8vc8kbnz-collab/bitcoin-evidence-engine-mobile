# Volgende exclusieve stap — R9O3 WebKit-failure-remediatie

## Doel

Herstel uitsluitend de vier door R9O2 bewezen failuregroepen en voer daarna
dezelfde verzegelde Chromium/WebKit-gate opnieuw uit. R9O3 mag geen algemene
featureontwikkeling, optimizerwijziging, prijswijziging of releaseclaim bevatten.

## Verplichte werkvolgorde

1. Reproduceer de WebKit-DXF-page-errors en bewijs per request status, origin,
   responsecompletion en moment van contextsluiting.
2. Stabiliseer de fixture bij succesvolle same-origin responses of herstel een
   echte runtime-requestfout. Voeg geen generieke WebKit/pageerror-allowlist toe.
3. Traceer de kandidaat-ResizeObserver naar zijn concrete owner. Voorkom
   synchrone layoutfeedback, dubbele observers en callbacks na teardown.
4. Bind cancellationobservatie aan de gecontroleerde optimizer-hold en wacht
   deterministisch op een aantoonbaar actieve status voordat annulering start.
5. Lokaliseer de 528-pixel Admin-overflowowner in het WebKit-iPhoneprofiel en
   herstel responsive `min-width`, grid/flex of overflow zonder de viewportgate
   te versoepelen.
6. Voeg gerichte negatieve regressietests toe voor iedere oorzaak.
7. Herhaal lokale preflight, standalone-artifactgate, identity, repository en
   supply-chaingate.
8. Bouw een nieuwe volledige runtimekandidaat en checkpoint-ZIP.
9. Voer de volledige 15-fixture/100-assertiongate opnieuw uit op exact hetzelfde
   Playwright-image en dezelfde twee browserrevisies.

## Rerunvereisten

- Dockerimage en digest blijven exact vastgezet;
- echte Chromium en WebKit, geen simulatie of vervanging;
- `--network none`, `--init` en `--ipc=host` blijven actief;
- Git `safe.directory` wordt alleen binnen de wegwerpcontainer gezet;
- lange uitvoering draait in `tmux` en schrijft afzonderlijke logs/exitcodes;
- kandidaat en R8Z moeten voor en na de run ongewijzigd zijn;
- PASS vereist 15/15 fixtures, 100/100 contractasserties, beide engines en geen
  geblokkeerde fixture.

## Verboden shortcuts

- geen brede filtering van `ResizeObserver`, page-errors of console-errors;
- geen verwijdering/verzwakking van `admin-layout-fits-viewport`;
- geen acceptatie van een WebKit-fout omdat Chromium passeert;
- geen wijziging van immutable R8Z;
- geen productie-GO op basis van alleen deze browserrerun.
