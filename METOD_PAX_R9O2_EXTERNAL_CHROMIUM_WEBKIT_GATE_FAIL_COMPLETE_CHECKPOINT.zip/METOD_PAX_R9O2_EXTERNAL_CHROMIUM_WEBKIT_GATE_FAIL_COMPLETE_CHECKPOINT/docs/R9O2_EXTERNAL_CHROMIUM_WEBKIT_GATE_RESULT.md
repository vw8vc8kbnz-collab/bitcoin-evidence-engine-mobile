# R9O2 — externe Chromium/WebKit-gate

## Uitkomst

De verzegelde R9O1-kandidaat is op een externe x86_64-VPS uitgevoerd met het
officiële Playwright-image `mcr.microsoft.com/playwright:v1.62.0-noble`,
vastgelegd op digest
`sha256:baed2032d533817f3dbe6425de795788430ba345e819a1201337009ba17c9d07`.
De echte Chromium- en WebKit-processen waren beide beschikbaar en launchable.

De inhoudelijke tweede uitvoering eindigde `FAIL`: 8 van 15 fixtures passeerden,
7 faalden, 100 contractasserties werden geëvalueerd en geen enkele browserengine
behaalde de totale gate. De kandidaat en immutable R8Z-bron bleven gedurende de
uitvoering byte-ongewijzigd. Productiestatus blijft daarom **NO_GO**.

## Bewijsbinding

- geteste commit: `d6f43a8918c2c7ed77d9d52d502917ee75c4b2c3`;
- kandidaatmanifest: `57bb221c877eaa1081192df28bd3b61f91185968b9ed18302004bb12a61fae6f`;
- R8Z-manifest: `c9f9198a83c9e1d40917f02fb1e5e45ff4bbfbab6bc6474815985cf3788d61db`;
- Playwright: `1.62.0`, Node `v24.18.0`;
- Chromium: `151.0.7922.34`, executable-SHA-256
  `0b20b130e7edd9dd51873be867761295fe0cfad490c2b9a64f95bd3cfc08fa71`;
- WebKit: `26.5`, executable-SHA-256
  `a85baad3d8c07173ac387a59b41500c382b21ed692afe0964d29aac247ccc63b`;
- bronmutatiecontrole: PASS voor R8Z en kandidaat.

## Geslaagde fixtures

De volgende acht fixtures passeerden in alle daarvoor vereiste echte engines
en profielen:

1. materiaalcatalogus en desktopwinkelwagen;
2. mobiele touch-verwijdering uit de materiaalwagen;
3. doorlopende-nerfpreview op iPhone-profielen;
4. klantgegevenssnapshot en invoerverversing;
5. jobaanmaak, polling en autoritatieve prijs;
6. definitieve aanvraag en bedankflow op iPhone-profielen;
7. nieuwe-configuratiereset en PII-verwijdering;
8. browserherstel na optimizercrash.

## Bevindingen

### 1. WebKit embedded-DXF access-control-diagnostiek

`wizard-keyboard-routing-refresh` faalde uitsluitend in WebKit desktop door 35
page-errors in immutable R8Z en 12 in de kandidaat voor same-origin
`/embedded_dxfs/...`-requests. Chromium passeerde. Omdat ook de immutable golden
faalt, is dit geen bewezen R9O1-regressie. De fixture- en requestlifecycle moet
wel deterministisch worden gemaakt; een brede allowlist is niet toegestaan.

### 2. Kandidaatspecifieke ResizeObserver-loop

Vier kandidaatflows produceren uitsluitend onder WebKit desktop telkens
`ResizeObserver loop completed with undelivered notifications`:

- paneelconfiguratie;
- desktop doorlopende-nerfpreview;
- desktop definitieve aanvraag/bedankflow;
- Admin-aanvraagprojectie/download.

R8Z produceert deze melding in dezelfde profielen niet. Dit blijft dus een
kandidaatspecifieke runtimebevinding totdat een gerichte oorzaakcorrectie of
nauw bewijs van een veilige engineconditie bestaat.

### 3. Niet-deterministische actieve status in WebKit

De cancellationfixture zag de gecontroleerde actieve verwerkingsstatus in
Chromium, maar niet in WebKit. Dit gebeurde identiek in R8Z en kandidaat. De
fixture moet aan het reeds aanwezige optimizer-hold-readinesssignaal worden
gebonden voordat de browserstatus wordt beoordeeld.

### 4. Werkelijk Admin-overflowdefect op WebKit iPhone

De kandidaat meet in `admin-presentation-session-assets` een
`bodyScrollWidth` van 528 pixels bij een viewport van 393 pixels. Chromium
iPhone en beide desktopprofielen passen wel. Dit is een echte kandidaat-
conformancefout; de responsive CSS-owner moet gericht worden gecorrigeerd.

### 5. Eerste infrastructuurpoging

De eerste uitvoering stopte vóór browseruitvoering doordat Git de als root
gemounte repository niet als veilige directory accepteerde. De tweede run
gebruikte uitsluitend in de wegwerpcontainer een `safe.directory`-uitzondering.
Beide exitcodes en logs blijven als bewijs bewaard.

## Geen bevinding

De zichtbare 404-consolemeldingen voor niet-geauthenticeerde GET-verzoeken naar
beschermde Admin-assets zijn onderdeel van het beveiligingscontract. De
registry accepteert deze statussen bewust, terwijl geauthenticeerde HEAD-
controles 200 moeten blijven. Deze meldingen veroorzaakten de gatefail niet.

## Besluit

R9O2 is een geldig extern **FAIL-checkpoint**, geen mislukte of waardeloze test.
Er is nu voor het eerst echt WebKit-bewijs. Er worden geen skips, engine-
vervangingen of handmatige PASS-claims toegestaan.

Volgende exclusieve stap: `R9O3_WEBKIT_FAILURE_REMEDIATION`.
