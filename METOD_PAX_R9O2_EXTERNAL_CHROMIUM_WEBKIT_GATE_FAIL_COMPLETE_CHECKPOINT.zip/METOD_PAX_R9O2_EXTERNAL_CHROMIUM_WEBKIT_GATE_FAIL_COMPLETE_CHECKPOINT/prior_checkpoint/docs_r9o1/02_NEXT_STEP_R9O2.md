# Volgende exclusieve stap — R9O2 WebKit-gate-uitvoering

## Doel

Voer dezelfde fail-closed browseroracle met de exact verzegelde R9O1-kandidaat
uit in echte Chromium én echte WebKit uit Playwright 1.62.0. Vereist: 15/15
fixtures, alle vier profielen, nul skips, nul xfails, nul bronmutatie.

## Schone audithost

Gebruik een geïsoleerde Ubuntu 24.04 x86_64-host met werkende apt-repositories.
Installeer Node 24 en voer in de herstelde repository uit:

```bash
npm --prefix browser ci
npx --prefix browser playwright install --with-deps chromium webkit
python3 -B tools/r9a_browser_oracle_tests.py -q
```

Gebruik vervolgens de paden die Playwright 1.62.0 zelf rapporteert. Vervang geen
engine door een systeem- of gesimuleerde browser. Voer uit:

```bash
python3 -B tools/r9a_browser_oracle.py \
  --registry contracts/R9A_BROWSER_FIXTURES.json \
  --golden-release /pad/naar/uitgepakte/METOD_PAX_FIX660R8_PRELIVE_HARDENED \
  --candidate candidate \
  --engines chromium webkit \
  --json-output reports/R9O2_BROWSER_GATE.json \
  --probe-timeout 60 \
  --suite-timeout 1800
```

## Acceptatie

- `status=PASS`.
- `enginesPassed` bevat exact `chromium` en `webkit`.
- `passedFixtureCount=15`, blocked/failed/skipped allemaal nul.
- Iedere vereiste assertion is PASS.
- `sourceMutationCheck.unchanged=true`.
- Rapport bindt R9O1-tag/commit, kandidaatmanifest, registry, runner, driver,
  normalisatie, Playwrightpackage en beide executablehashes.

Bij een runtimebevinding: stop, karakteriseer, herstel begrensd, bouw een nieuw
artifact en herhaal beide engines. Bij een host/dependencyprobleem: status NO_GO,
host herstellen en exact dezelfde R9O1-kandidaat opnieuw uitvoeren.

Na een volledige tweemotor-PASS volgen nog steeds fysieke iPhone/Safari, VPS,
security, operations, CAM/bedrijf en formele signoff; de browsergate alleen zet
geen productie-GO.
