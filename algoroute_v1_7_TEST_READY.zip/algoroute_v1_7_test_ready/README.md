# AlgoRoute v1.7 TEST READY

Deze build maakt de software testklaar:
- Wagenpark is geen lege placeholder meer: voertuigen toevoegen/verwijderen, capaciteit, status en EV-profielen.
- Chauffeurs is geen lege placeholder meer: chauffeurs toevoegen/verwijderen, beschikbaarheid, rijbewijs en voertuigkoppeling.
- Handmatige test-vloot knop zodat je direct kunt testen zonder automatische dummydata.
- Planning/Import/Mapping/Queue/Geocoding/Optimizer foundation blijven behouden.
- OSRM blijft via setup script te installeren omdat Nederland-data preprocessen zwaar is.

## Testflow
1. Open Wagenpark en klik Test-vloot laden of voeg eigen voertuigen toe.
2. Open Chauffeurs en controleer chauffeurs/voertuigkoppeling.
3. Upload de CSV testorders in Planning > Import.
4. Controleer Mapping.
5. Commit naar Queue.
6. Valideer adressen met PDOK/BAG.
7. Start OSRM setup op de VPS.
8. Optimaliseer routes.
