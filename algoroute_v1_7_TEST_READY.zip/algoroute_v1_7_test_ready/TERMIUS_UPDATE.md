Zie de update-regels in ChatGPT.
