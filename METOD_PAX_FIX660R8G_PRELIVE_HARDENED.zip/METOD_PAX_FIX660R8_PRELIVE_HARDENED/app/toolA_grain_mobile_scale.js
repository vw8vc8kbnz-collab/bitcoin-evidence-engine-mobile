(function(root){
  'use strict';
  if(root.__FIX660R8G_GRAIN_MOBILE__) return;
  root.__FIX660R8G_GRAIN_MOBILE__='FIX660R8G_IOS_DRAWER_PUBLISH_GATE';
  root.__TOOLA_GRAIN_PREVIEW_BUILD='FIX660R8G_IOS_DRAWER_PUBLISH_GATE';

  const MQ='(max-width:900px)';
  const q=id=>document.getElementById(id);
  const isMobile=()=>!!(root.matchMedia&&root.matchMedia(MQ).matches);
  const bridge=()=>root.ToolAGrainBridge||null;
  const state=()=>{const b=bridge();return b&&typeof b.state==='function'?b.state():(root.state||null);};
  const entry=ref=>{const b=bridge();return b&&typeof b.getEntry==='function'?b.getEntry(ref):null;};
  const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const n=(v,d=0)=>{const x=Number(v);return Number.isFinite(x)?x:d;};
  const qmm=v=>Math.round(n(v)*1000)/1000;
  const fmt=v=>{const x=n(v);return Math.abs(x-Math.round(x))<.01?String(Math.round(x)):x.toFixed(1).replace('.',',');};
  const widthMm=e=>qmm(e&&e.widthMm);
  const heightMm=e=>Math.max(1,n(e&&e.baseHeightMm)+Math.max(0,n(e&&e.extTop))+Math.max(0,n(e&&e.extBot)));
  const sameWidth=(a,b)=>{try{return root.ToolAGrainStudioMath?root.ToolAGrainStudioMath.sameWidthMm(a,b):Math.abs(n(a)-n(b))<=.001;}catch(_){return Math.abs(n(a)-n(b))<=.001;}};
  const materialKey=()=>{const b=bridge();try{return String(b&&typeof b.selectedMaterialKey==='function'?b.selectedMaterialKey():'');}catch(_){return '';}};
  const doorLabel=raw=>{const b=bridge();try{return b&&typeof b.doorDirectionLabel==='function'?b.doorDirectionLabel(raw):'';}catch(_){return '';}};
  const extLabel=raw=>{const b=bridge();try{return b&&typeof b.extensionLabel==='function'?b.extensionLabel(raw):'';}catch(_){return '';}};

  function ensureSelectedGroup(preferFilled=true){
    const s=state(); if(!s||!s.grain) return null;
    const mk=materialKey();
    const groups=(s.grain.groups||[]).filter(g=>!mk||String(g&&g.materialKey||'')===mk);
    if(!groups.length) return null;
    let g=groups.find(x=>String(x&&x.id||'')===String(s.grain.selectedGroupId||''))||null;
    if((!g || (preferFilled && !(g.items||[]).length)) && preferFilled) g=groups.find(x=>(x&&x.items||[]).length)||g;
    if(!g) g=groups[0]||null;
    if(g) s.grain.selectedGroupId=g.id;
    return g;
  }
  function groupWidth(g){
    let w=qmm(g&&g.widthMm);
    if(!w&&g&&(g.items||[]).length){const e=entry(g.items[0]);w=widthMm(e);if(w){g.widthMm=w;g.widthCm=w/10;}}
    return w;
  }
  function groupHeight(g){return (g&&g.items||[]).reduce((sum,ref)=>{const e=entry(ref);return sum+(e?heightMm(e):0);},0);}
  function groupSummary(g){const w=groupWidth(g),h=groupHeight(g),c=(g&&g.items||[]).length;return `${w?fmt(w)+' mm':'—'} · ${c} ${c===1?'paneel':'panelen'}${h?' · '+fmt(h)+' mm hoog':''}`;}

  function refreshAll(){
    const b=bridge(); if(!b) return;
    try{b.syncOrders&&b.syncOrders();}catch(_){}
    try{b.rebuildWidthOptions&&b.rebuildWidthOptions();}catch(_){}
    try{b.rebuildEligible&&b.rebuildEligible();}catch(_){}
    try{b.rebuildGroups&&b.rebuildGroups();}catch(_){}
    try{b.renderCart&&b.renderCart();}catch(_){}
    try{b.syncPanelDockChrome&&b.syncPanelDockChrome();}catch(_){}
    try{b.renderExtraPanels&&b.renderExtraPanels();}catch(_){}
    try{b.syncChecksFromSelect&&b.syncChecksFromSelect();}catch(_){}
    try{b.drawExtraPreview&&b.drawExtraPreview();}catch(_){}
    try{root.ToolAGrainStudioRenderer&&root.ToolAGrainStudioRenderer.schedule();}catch(_){}
    try{b.setMessage&&b.setMessage('');}catch(_){}
  }
  function targetGroup(){
    let g=ensureSelectedGroup(false); if(g) return g;
    const b=bridge(); try{b&&b.newGroup&&b.newGroup();}catch(_){}
    return ensureSelectedGroup(false);
  }
  function addOne(refs){
    const s=state(),b=bridge(),g=targetGroup(); if(!s||!b||!g) return;
    const e=(refs||[]).map(entry).find(x=>x&&!x.grainGroupId); if(!e) return;
    const w=widthMm(e),gw=groupWidth(g);
    if(!b.isGrainCapable||!b.isGrainCapable(e.raw)) return;
    if(gw&&!sameWidth(gw,w)){b.setMessage&&b.setMessage(`Alleen exact ${fmt(gw)} mm brede panelen kunnen in deze nerf-set.`);return;}
    if(!g.widthMm){g.widthMm=w;g.widthCm=w/10;}
    const ref=String(e.ref||''); if(!ref||g.items.map(String).includes(ref)) return;
    // Semantic production truth: BOTTOM -> TOP. Append = stack one level higher.
    g.items.push(ref); s.grain.selectedGroupId=g.id; refreshAll();
  }

  function displayGroups(entries){const b=bridge();try{return b&&b.groupDisplayEntries?b.groupDisplayEntries(entries):[];}catch(_){return [];}}

  function renderEligible(){
    if(!isMobile()) return false;
    const b=bridge(),host=q('grainEligible'),count=q('grainEligibleCount'),toggle=q('grainIncludeExtraToggle'),widthSel=q('grainWidthSel');
    if(!b||!host||!count) return false;
    host.innerHTML=''; const eligible=(b.getEligible&&b.getEligible())||[]; count.textContent=String(eligible.length); if(toggle)toggle.checked=!!(b.extrasEnabled&&b.extrasEnabled());
    if(!eligible.length){host.innerHTML='<div class="fix660CompactEmpty">Geen panelen beschikbaar voor doorlopende nerf.</div>';return true;}

    const active=ensureSelectedGroup(false),lockedW=groupWidth(active);
    const byW=new Map(); eligible.forEach(e=>{const w=widthMm(e);if(!(w>0))return;if(!byW.has(w))byW.set(w,[]);byW.get(w).push(e);});
    let widths=Array.from(byW.keys()).sort((a,c)=>a-c);
    const filter=widthSel&&widthSel.value!=='all'?n(widthSel.value):0;
    if(lockedW) widths=widths.filter(w=>sameWidth(w,lockedW)); else if(filter) widths=widths.filter(w=>sameWidth(w,filter));

    widths.forEach(w=>{
      const entries=byW.get(w)||[];
      const band=document.createElement('section');band.className='fix660CompactWidth';
      const free=entries.filter(e=>!e.grainGroupId).length;
      band.innerHTML=`<div class="fix660CompactWidthHead"><strong>${esc(fmt(w))} mm</strong><span>${free}/${entries.length} beschikbaar</span></div>`;
      const list=document.createElement('div');list.className='fix660CompactAvailableList';
      [{key:'cart'},{key:'extra'}].forEach(sec=>{
        const secEntries=entries.filter(e=>e.kind===sec.key);if(!secEntries.length)return;
        displayGroups(secEntries).sort((a,c)=>String(a?.rep?.label||'').localeCompare(String(c?.rep?.label||''))).forEach(group=>{
          const rep=group.rep,total=Math.max(1,group.items.length),freeItems=group.items.filter(x=>!x.grainGroupId);
          const row=document.createElement('div');row.className='fix660CompactAvailable'+(!freeItems.length?' is-disabled':'');
          const main=document.createElement('div');main.className='fix660CompactAvailableMain';
          main.innerHTML=`<strong>${esc(rep.label)}</strong><span>${esc(fmt(widthMm(rep)))} × ${esc(fmt(heightMm(rep)))} mm${esc(doorLabel(rep.raw))}${rep.kind==='extra'?' · overig':''}</span>`;
          const right=document.createElement('div');right.className='fix660CompactAvailableRight';
          const av=document.createElement('span');av.className='fix660CompactCount';av.textContent=`${freeItems.length}/${total}`;
          const plus=document.createElement('button');plus.type='button';plus.className='fix660CompactPlus';plus.setAttribute('aria-label',`Voeg ${rep.label} bovenop de nerf-set toe`);plus.textContent='+';plus.disabled=!freeItems.length;plus.addEventListener('click',()=>addOne(freeItems.map(x=>x.ref)));
          right.append(av,plus);row.append(main,right);list.appendChild(row);
        });
      });band.appendChild(list);host.appendChild(band);
    });
    return true;
  }

  function mini(e){const box=document.createElement('div');box.className='fix660PanelMiniBox';const shape=document.createElement('div');shape.className='fix660PanelMiniShape';const w=Math.max(1,widthMm(e)),h=Math.max(1,heightMm(e)),sc=Math.min(23/w,30/h);shape.style.width=Math.max(4,w*sc)+'px';shape.style.height=Math.max(3,h*sc)+'px';box.appendChild(shape);return box;}

  function bindTouchReorder(handle,item,body,g){
    let active=false,startY=0,moved=false;
    const finish=ev=>{if(!active)return;active=false;try{handle.releasePointerCapture(ev.pointerId);}catch(_){}item.classList.remove('is-dragging');document.body.classList.remove('fix660GrainReordering');if(moved){const visual=Array.from(body.querySelectorAll('.fix660GroupItem')).map(el=>String(el.dataset.ref||'')).filter(Boolean);g.items=visual.reverse();refreshAll();}moved=false;};
    handle.addEventListener('pointerdown',ev=>{if(ev.button!=null&&ev.button!==0)return;active=true;startY=ev.clientY;moved=false;try{handle.setPointerCapture(ev.pointerId);}catch(_){}item.classList.add('is-dragging');document.body.classList.add('fix660GrainReordering');ev.preventDefault();});
    handle.addEventListener('pointermove',ev=>{if(!active)return;if(Math.abs(ev.clientY-startY)>5)moved=true;let t=document.elementFromPoint(ev.clientX,ev.clientY);t=t&&t.closest&&t.closest('.fix660GroupItem');if(!t||t===item||t.parentElement!==body)return;const r=t.getBoundingClientRect();body.insertBefore(item,ev.clientY<r.top+r.height/2?t:t.nextSibling);});
    handle.addEventListener('pointerup',finish);handle.addEventListener('pointercancel',finish);
  }

  function renderGroups(){
    if(!isMobile()) return false;
    const s=state(),b=bridge(),host=q('grainGroups');if(!s||!b||!host)return false;host.innerHTML='';
    const mk=materialKey();const groups=(s.grain.groups||[]).filter(g=>!mk||String(g.materialKey||'')===mk);ensureSelectedGroup();
    if(!groups.length){host.innerHTML='<div class="fix660CompactEmpty">Tik op + bij een paneel; G01 wordt automatisch gemaakt.</div>';return true;}
    groups.forEach(g=>{
      const selected=String(s.grain.selectedGroupId||'')===String(g.id||'');
      const card=document.createElement('section');card.className='fix660CompactGroup'+(selected?' is-selected':'');card.dataset.groupId=String(g.id||'');
      const head=document.createElement('div');head.className='fix660CompactGroupHead';
      const choose=document.createElement('button');choose.type='button';choose.className='fix660CompactGroupChoose';choose.innerHTML=`<strong>${esc(g.id)}</strong><span>${esc(groupSummary(g))}</span>`;choose.addEventListener('click',()=>{s.grain.selectedGroupId=g.id;renderGroups();root.ToolAGrainStudioRenderer&&root.ToolAGrainStudioRenderer.schedule();});
      const trash=document.createElement('button');trash.type='button';trash.className='fix660CompactGroupDelete';trash.setAttribute('aria-label','Verwijder nerf-set');trash.textContent='×';trash.addEventListener('click',ev=>{ev.stopPropagation();s.grain.groups=s.grain.groups.filter(x=>x.id!==g.id);if(s.grain.selectedGroupId===g.id)s.grain.selectedGroupId=null;ensureSelectedGroup();refreshAll();});
      head.append(choose,trash);card.appendChild(head);
      const hint=document.createElement('div');hint.className='fix660CompactStackHint';hint.textContent='↑ hoger in de stapel · 1 = onderaan';card.appendChild(hint);
      const body=document.createElement('div');body.className='fix660CompactGroupBody';
      if(!(g.items||[]).length){body.innerHTML='<div class="fix660CompactEmpty">Voeg eerst het onderste paneel toe.</div>';}else{
        g.items.slice().reverse().forEach(ref=>{
          const semanticIndex=g.items.map(String).indexOf(String(ref)),pos=semanticIndex+1,e=entry(ref);if(!e)return;
          const item=document.createElement('div');item.className='fix660GroupItem'+(String(root.__fix660SelectedGrainRef||'')===String(ref)?' is-selected':'');item.dataset.ref=String(ref);
          const badge=document.createElement('span');badge.className='fix660OrderBadge';badge.textContent=String(pos);item.append(badge,mini(e));
          const main=document.createElement('button');main.type='button';main.className='fix660GroupItemMain';main.innerHTML=`<strong>${esc(e.label)}</strong><span>${esc(fmt(widthMm(e)))} × ${esc(fmt(heightMm(e)))} mm${esc(doorLabel(e.raw))}</span>`;main.addEventListener('click',()=>{root.__fix660SelectedGrainRef=String(ref);s.grain.selectedGroupId=g.id;renderGroups();root.ToolAGrainStudioRenderer&&root.ToolAGrainStudioRenderer.schedule();});item.appendChild(main);
          const drag=document.createElement('button');drag.type='button';drag.className='fix660DragHandle';drag.setAttribute('aria-label','Sleep om volgorde te wijzigen');drag.innerHTML='<i></i><i></i><i></i><i></i><i></i><i></i>';item.appendChild(drag);bindTouchReorder(drag,item,body,g);
          const rm=document.createElement('button');rm.type='button';rm.className='fix660RemoveBtn';rm.setAttribute('aria-label','Verwijder uit nerf-set');rm.textContent='×';rm.addEventListener('click',ev=>{ev.stopPropagation();b.removeFromGroup&&b.removeFromGroup(g.id,ref);});item.appendChild(rm);body.appendChild(item);
        });
      }
      card.appendChild(body);host.appendChild(card);
    });
    return true;
  }

  let drawer=null,handle=null,actions=null,dragging=false,startY=0,startOffset=0,pointerDragged=false,lastPointerToggleAt=0;
  const PEEK=30;
  const travel=()=>drawer?Math.max(0,drawer.getBoundingClientRect().height-PEEK):0;
  const expanded=()=>!!(drawer&&drawer.classList.contains('fix660DrawerOpen'));
  function setTransform(offset){if(drawer)drawer.style.setProperty('transform',`translateY(${Math.max(0,Math.min(travel(),offset))}px)`,'important');}
  function renderOpenPreview(){
    if(!expanded())return;ensureSelectedGroup();
    const host=q('grainPreview'),r=root.ToolAGrainStudioRenderer;if(!host||!r)return;
    try{if(typeof r.prepareHost==='function')r.prepareHost(host);}catch(_){}
    // Two animation frames guarantee that Safari has committed the fixed drawer and
    // explicit host size before we ask Canvas for its backing-store dimensions.
    root.requestAnimationFrame(()=>root.requestAnimationFrame(()=>{try{r.render(host);}catch(err){try{console.error('[GrainPreview]',err);}catch(_){}}}));
  }
  function setDrawer(open,instant=false){
    if(!drawer)return;drawer.classList.toggle('fix660DrawerOpen',!!open);drawer.classList.toggle('fix660DrawerClosed',!open);drawer.style.removeProperty('transform');drawer.setAttribute('aria-expanded',open?'true':'false');root.__fix660GrainDrawerOpen=!!open;
    if(handle)handle.setAttribute('aria-expanded',open?'true':'false');
    if(open){renderOpenPreview();if(!instant)setTimeout(renderOpenPreview,340);}
  }
  function buildActions(){if(actions||!isMobile())return;const modal=document.querySelector('#grainOverlay .modal');if(!modal)return;actions=document.createElement('div');actions.className='fix660MobileActions';const c=document.createElement('button');c.type='button';c.className='btn';c.textContent='Annuleren';c.onclick=()=>q('grainCancelBtn')&&q('grainCancelBtn').click();const a=document.createElement('button');a.type='button';a.className='btn btnPrimary';a.textContent='Toepassen';a.onclick=()=>q('grainApplyBtn')&&q('grainApplyBtn').click();actions.append(c,a);modal.appendChild(actions);}
  function initDrawer(forceClosed=false){
    if(!isMobile())return;drawer=document.querySelector('#grainOverlay .grainPreviewCard');if(!drawer)return;drawer.classList.add('fix660PreviewDrawer');handle=q('fix660DrawerHandle')||drawer.querySelector('.fix660DrawerHandle');
    const old=q('fix649PreviewToggle');if(old)old.hidden=true;const txt=handle&&handle.querySelector('.fix660DrawerHandleText');if(txt)txt.hidden=true;
    if(!drawer.dataset.fix660r8gTransitionBound){drawer.dataset.fix660r8gTransitionBound='1';drawer.addEventListener('transitionend',ev=>{if(ev.propertyName==='transform'&&expanded())renderOpenPreview();});}
    if(handle&&!handle.dataset.fix660r8gBound){
      handle.dataset.fix660r8gBound='1';
      // Keyboard/assistive click fallback. A real pointer tap is handled on pointerup,
      // because iOS Safari may suppress click after preventDefault on pointerdown.
      handle.addEventListener('click',ev=>{if(Date.now()-lastPointerToggleAt<700)return;ev.preventDefault();setDrawer(!expanded());});
      handle.addEventListener('pointerdown',ev=>{if(ev.button!=null&&ev.button!==0)return;dragging=true;pointerDragged=false;startY=ev.clientY;startOffset=expanded()?0:travel();drawer.classList.add('fix660DrawerDragging');try{handle.setPointerCapture(ev.pointerId);}catch(_){}ev.preventDefault();});
      handle.addEventListener('pointermove',ev=>{if(!dragging)return;const dy=ev.clientY-startY;if(Math.abs(dy)>5)pointerDragged=true;setTransform(startOffset+dy);});
      const finish=(ev,cancelled=false)=>{if(!dragging)return;dragging=false;drawer.classList.remove('fix660DrawerDragging');try{handle.releasePointerCapture(ev.pointerId);}catch(_){}const dy=Number(ev.clientY)-startY;if(cancelled){setDrawer(startOffset===0,true);return;}if(!pointerDragged&&Math.abs(dy)<=5){lastPointerToggleAt=Date.now();setDrawer(!expanded());return;}const current=Math.max(0,Math.min(travel(),startOffset+dy));setDrawer(current<travel()*.55,true);};
      handle.addEventListener('pointerup',ev=>finish(ev,false));handle.addEventListener('pointercancel',ev=>finish(ev,true));
    }
    buildActions();setDrawer(forceClosed?false:!!root.__fix660GrainDrawerOpen,true);
  }
  function teardown(){if(drawer){drawer.classList.remove('fix660PreviewDrawer','fix660DrawerOpen','fix660DrawerClosed','fix660DrawerDragging');drawer.style.removeProperty('transform');}const host=q('grainPreview');if(host){host.style.removeProperty('height');host.style.removeProperty('min-height');host.style.removeProperty('flex');}if(actions){actions.remove();actions=null;}drawer=null;handle=null;}
  function onOverlayOpen(){root.__fix660GrainDrawerOpen=false;ensureSelectedGroup();renderEligible();renderGroups();requestAnimationFrame(()=>initDrawer(true));}
  function viewportChanged(){if(isMobile()){renderEligible();renderGroups();initDrawer(false);}else teardown();}
  function focusRef(ref){root.__fix660SelectedGrainRef=String(ref||'');renderGroups();root.ToolAGrainStudioRenderer&&root.ToolAGrainStudioRenderer.schedule();setTimeout(()=>{try{const el=document.querySelector(`#grainGroups .fix660GroupItem[data-ref="${CSS.escape(String(ref||''))}"]`);el&&el.scrollIntoView({behavior:'smooth',block:'center'});}catch(_){}},20);}
  function start(){if(isMobile())initDrawer(true);try{const mq=root.matchMedia(MQ);(mq.addEventListener?mq.addEventListener('change',viewportChanged):mq.addListener(viewportChanged));}catch(_){} }

  root.ToolAGrainStudioMobile=Object.freeze({BUILD:'FIX660R8G_IOS_DRAWER_PUBLISH_GATE',isActive:isMobile,renderEligible,renderGroups,onOverlayOpen,focusRef,openPreview(){initDrawer(false);setDrawer(true);},closePreview(){setDrawer(false);},ensureSelectedGroup});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})(window);
