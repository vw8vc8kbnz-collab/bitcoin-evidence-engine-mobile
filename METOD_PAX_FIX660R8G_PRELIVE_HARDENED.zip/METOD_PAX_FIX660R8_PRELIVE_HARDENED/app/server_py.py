#!/usr/bin/env python3
# METOD Tool A + Tool B local server (py-only)
# Serves Tool A UI, Admin UI, and runs Tool B optimizer jobs.

from __future__ import annotations

# Build stamps are deliberately public module constants.  A leading double
# underscore is name-mangled when it is referenced from a class method (for
# example Handler.do_GET), which used to crash /health/live after the socket
# had already opened.
STICKERTOOL_V2_BUILD = 'FIX626_ADMIN_LOGIN_CLEAN_SESSION'
OUTPUT_PIPELINE_BUILD = 'FIX654_OUTPUT_PIPELINE_AUDIT'
PERFORMANCE_BUILD = 'FIX660_GRAIN_STUDIO'
SECURITY_BUILD = 'FIX660R8_PRELIVE_HARDENED'

import json
import csv
import math
import os
import re
import shutil
import stat
import subprocess
import sys
import threading
import traceback
import time
import uuid
import base64
import binascii
import io
import hmac
import hashlib
import secrets
import queue
import zipfile
import gzip
import ssl
import ipaddress
try:
    import fcntl as _fcntl  # type: ignore
except Exception:  # pragma: no cover - non-POSIX development fallback
    _fcntl = None
from datetime import datetime, timedelta, timezone
from dataclasses import replace
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote, quote
from urllib.request import Request, urlopen
from urllib.error import URLError
from typing import Optional, List, Dict, Any, Union

from server_helpers import (
    atomic_write_json as _helpers_atomic_write_json,
    atomic_write_text as _helpers_atomic_write_text,
    extract_request_token as _helpers_extract_request_token,
    read_json_body as _helpers_read_json_body,
    read_json_body_limited as _helpers_read_json_body_limited,
    require_same_origin_admin_write as _helpers_require_same_origin_admin_write,
    safe_job_file as _helpers_safe_job_file,
)
from pricing_helpers import (
    aggregate_materials_from_subjob_quotes as _pricing_aggregate_materials_from_subjob_quotes,
    parse_calculation_summary_totals as _pricing_parse_calculation_summary_totals,
)
from catalog_importer import (
    ALLOWED_THICKNESSES_MM as CATALOG_ALLOWED_THICKNESSES_MM,
    VAT_RATE as CATALOG_VAT_RATE,
    atomic_write_cached_image as _catalog_atomic_write_cached_image,
    catalog_diff as _catalog_diff,
    download_catalog_image as _catalog_download_image,
    parse_catalog_csv as _parse_catalog_csv,
    read_cached_image as _catalog_read_cached_image,
    classify_catalog_presentation as _catalog_classify_presentation,
)
from catalog_taxonomy import (
    PUBLIC_FAMILIES as CATALOG_PUBLIC_FAMILIES,
    SUBSTRATE_LABELS as CATALOG_SUBSTRATE_LABELS,
    apply_admin_override as _taxonomy_apply_admin_override,
    apply_admin_family_override as _taxonomy_apply_admin_family_override,
    clear_admin_family_override as _taxonomy_clear_admin_family_override,
    enrich_catalog_records as _taxonomy_enrich_records,
    load_registry as _taxonomy_load_registry,
    registry_with_records as _taxonomy_registry_with_records,
    save_registry as _taxonomy_save_registry,
    taxonomy_summary as _taxonomy_summary,
)
from dxf_geometry import entities_section as _strict_dxf_entities_section
from dxf_geometry import parse_pairs as _strict_dxf_parse_pairs
from dxf_geometry import split_entities as _strict_dxf_split_entities
from dxf_geometry import entity_type as _strict_dxf_entity_type
from dxf_geometry import entity_layer as _strict_dxf_entity_layer
from dxf_geometry import entities_bbox as _strict_dxf_entities_bbox
from dxf_geometry import entity_bbox as _strict_dxf_entity_bbox
from panel_contract import canonical_csv as _canonical_panels_csv
from panel_contract import parse_panels_csv as _parse_panels_csv_contract
from safety_contracts import (
    ContractError as SafetyContractError,
    append_jsonl_rotating,
    durable_copy_file,
    durable_create_json_exclusive,
    durable_write_bytes,
    durable_write_json,
    durable_write_text,
    ensure_finite_json,
    finite_number,
    fsync_directory,
    resolve_identifier_child,
    resolve_relative_file,
    sha256_file,
    strict_json_dumps,
    strict_json_load,
    strict_json_loads,
    tail_text_lines,
    validate_job_id,
    validate_public_material_id,
    validate_request_id,
)

ROOT = Path(__file__).resolve().parent
RELEASE_ROOT = ROOT.parent
_DEFAULT_STATE_ROOT = ROOT.parents[1] / 'metod-pax-state'
STATE_ROOT = Path(os.environ.get('METOD_STATE_ROOT') or _DEFAULT_STATE_ROOT).expanduser().resolve()
DXF_LIBRARY_ROOT = STATE_ROOT / 'embedded_dxfs'
DXF_MANIFEST_PATH = STATE_ROOT / 'embedded_dxfs_manifest.json'
PRICING_SEED_PATH = ROOT / 'pricing_v13mm.json'
MATERIAL_LIBRARY_SEED_PATH = ROOT / 'material_library.json'
BUILD_MARKER_FIX651 = 'FIX651_CSV_CATALOG_DIRECT_PRICING'
BUILD_MARKER_FIX652 = 'FIX652_CSV_ONLY_LIBRARY_RESET'
BUILD_MARKER_FIX653 = 'FIX653_LIBRARY_UX_CLASSIFICATION'
BASE_DIR = str(ROOT)
MATERIAL_LIBRARY_PATH = STATE_ROOT / 'material_library.json'
CATALOG_PUBLIC_ID_REGISTRY = STATE_ROOT / 'system' / 'catalog_public_ids.json'
CATALOG_TAXONOMY_REGISTRY = STATE_ROOT / 'system' / 'catalog_taxonomy_registry.json'
DECOR_MEDIA_ROOT = STATE_ROOT / 'decor_media'
_MATERIAL_LIBRARY_LOCK = threading.RLock()
_PRICING_CONFIG_LOCK = threading.RLock()
_CATALOG_IMAGE_SYNC_LOCK = threading.Lock()
_CATALOG_IMAGE_SYNC_ACTIVE: set[str] = set()
_PUBLIC_MATERIAL_ID_RE = re.compile(r'^decor_[a-f0-9]{20,40}$')
PUBLIC_MATERIAL_CATALOG_CACHE_PATH = STATE_ROOT / 'system' / 'public_material_catalog_v1.json'
PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH = STATE_ROOT / 'system' / 'public_material_catalog_v1.meta.json'
PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA = 2
PUBLIC_MATERIAL_CATALOG_CACHE_BUILD = 'FIX660R8F_CATALOG_IMAGES'
_PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK = threading.RLock()
_PUBLIC_MATERIALS_RESPONSE_CACHE: dict[str, Any] = {'mtimeNs': None, 'body': None, 'etag': None}


def _invalidate_public_materials_response_cache() -> None:
    with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
        _PUBLIC_MATERIALS_RESPONSE_CACHE['mtimeNs'] = None
        _PUBLIC_MATERIALS_RESPONSE_CACHE['body'] = None
        _PUBLIC_MATERIALS_RESPONSE_CACHE['etag'] = None


_DEFAULT_ADMIN_PASSWORDS = {"change-me", "changeme", "admin", "password", "123456", "SET_STRONG_PASSWORD"}
_ADMIN_PBKDF2_ITERATIONS = 260000
_DUMMY_ADMIN_PASSWORD_HASH = 'pbkdf2_sha256$260000$fix660r8-dummy-salt-2026$6dc4157cf635b6c54340f11ae04c9c83a14251e871ee18e4bc0b8c7190bc5aae'
_DUMMY_ADMIN_TOTP_SECRET = 'JBSWY3DPEHPK3PXP'
_RATE_LIMITS_LOCK = threading.Lock()
_RATE_LIMITS: dict[tuple[str, str], list[float]] = {}
_PUBLIC_JOB_CREATE_LOCK = threading.Lock()
_PUBLIC_JOB_CREATE_BY_IP: dict[str, int] = {}
_PUBLIC_JOB_CREATE_TOTAL = 0
_ADMIN_SESSIONS_LOCK = threading.Lock()
_ADMIN_SESSIONS: dict[str, dict[str, Any]] = {}
_ADMIN_SESSION_IDLE_SEC = int(os.environ.get('ADMIN_SESSION_IDLE_SEC', str(30 * 60)))
_ADMIN_SESSION_ABSOLUTE_SEC = int(os.environ.get('ADMIN_SESSION_ABSOLUTE_SEC', str(8 * 60 * 60)))

def _sanitize_filename(name: Any, max_len: int = 120) -> str:
    try:
        raw = str(name or '')
    except Exception:
        raw = ''
    raw = raw.replace('\\', '_').replace('/', '_')
    raw = re.sub(r'[^A-Za-z0-9.,_ -]+', '_', raw).strip(' ._')
    if not raw:
        return ''
    try:
        limit = max(1, int(max_len or 120))
    except Exception:
        limit = 120
    return raw[:limit]

def _direct_peer_ip(handler) -> str:
    try:
        return str((handler.client_address or ["?"])[0] or "?").strip()
    except Exception:
        return "?"

def _split_env_csv(name: str, default: str = "") -> list[str]:
    raw = str(os.environ.get(name, default) or "")
    return [x.strip() for x in raw.split(",") if x.strip()]

def _ip_matches(value: str, pattern: str) -> bool:
    try:
        ip = ipaddress.ip_address(str(value).strip())
        pat = str(pattern).strip()
        if "/" in pat:
            return ip in ipaddress.ip_network(pat, strict=False)
        return ip == ipaddress.ip_address(pat)
    except Exception:
        return str(value or "").strip() == str(pattern or "").strip()

def _is_trusted_proxy_peer(handler) -> bool:
    peer = _direct_peer_ip(handler)
    proxies = _split_env_csv("TRUSTED_PROXY_IPS", "127.0.0.1,::1")
    return any(_ip_matches(peer, p) for p in proxies)

def _extract_forwarded_client_ip(raw: str) -> str:
    """Accept one proxy-normalized client IP, never a client-supplied chain."""
    cand = str(raw or '').strip()
    if not cand or ',' in cand:
        return ''
    if cand.startswith('[') and ']' in cand:
        cand = cand[1:cand.index(']')]
    try:
        return str(ipaddress.ip_address(cand))
    except Exception:
        return ''

def _client_ip(handler) -> str:
    try:
        # Only trust forwarded headers from a configured reverse proxy.
        if _is_trusted_proxy_peer(handler):
            # The production Nginx contract overwrites X-Real-IP and X-Forwarded-For
            # with $remote_addr. Prefer X-Real-IP and reject comma-separated chains.
            real = _extract_forwarded_client_ip(handler.headers.get('X-Real-IP') or '')
            if real:
                return real
            real = _extract_forwarded_client_ip(handler.headers.get('X-Forwarded-For') or '')
            if real:
                return real
        return _direct_peer_ip(handler)
    except Exception:
        return _direct_peer_ip(handler) or "?"

def _is_loopback_value(value: str) -> bool:
    v = str(value or '').strip().lower()
    return v in {'127.0.0.1', '::1', 'localhost'}

def _is_loopback_client(handler) -> bool:
    return _is_loopback_value(_client_ip(handler))


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    """Thread-per-request development server with a strict global concurrency cap.

    Nginx remains the public edge, but the application must also fail closed when
    upstream limits are misconfigured or bypassed.
    """

    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 128

    def __init__(self, server_address, request_handler_class):
        self._request_slots = threading.BoundedSemaphore(max(1, min(256, _env_int('HTTP_MAX_CONCURRENT', 64))))
        super().__init__(server_address, request_handler_class)

    def process_request(self, request, client_address):
        if not self._request_slots.acquire(blocking=False):
            try:
                request.sendall(
                    b'HTTP/1.1 503 Service Unavailable\r\n'
                    b'Connection: close\r\nContent-Type: text/plain; charset=utf-8\r\n'
                    b'Content-Length: 21\r\n\r\nServer is at capacity'
                )
            except Exception:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._request_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._request_slots.release()

def _credentials_are_default(user: Optional[str], pw: Optional[str]) -> bool:
    try:
        return str(user or '').strip().lower() == 'admin' and str(pw or '').strip() in _DEFAULT_ADMIN_PASSWORDS
    except Exception:
        return False

def _rate_limit_allow(bucket: str, key: str, max_hits: int, window_sec: int) -> bool:
    now = time.time()
    kk = (str(bucket), str(key))
    with _RATE_LIMITS_LOCK:
        if len(_RATE_LIMITS) > 10_000:
            cutoff = now - max(60.0, float(window_sec))
            for stale_key, values in list(_RATE_LIMITS.items()):
                kept = [ts for ts in values[-max(10, int(max_hits) * 2):] if ts >= cutoff]
                if kept:
                    _RATE_LIMITS[stale_key] = kept
                else:
                    _RATE_LIMITS.pop(stale_key, None)
        arr = [ts for ts in _RATE_LIMITS.get(kk, []) if now - ts < float(window_sec)]
        if len(arr) >= int(max_hits):
            _RATE_LIMITS[kk] = arr
            return False
        arr.append(now)
        _RATE_LIMITS[kk] = arr
        return True


def _rate_limit_is_blocked(bucket: str, key: str, max_hits: int, window_sec: int) -> bool:
    now = time.time()
    kk = (str(bucket), str(key))
    with _RATE_LIMITS_LOCK:
        arr = [ts for ts in _RATE_LIMITS.get(kk, []) if now - ts < float(window_sec)]
        _RATE_LIMITS[kk] = arr
        return len(arr) >= int(max_hits)


def _rate_limit_record(bucket: str, key: str) -> None:
    now = time.time()
    kk = (str(bucket), str(key))
    with _RATE_LIMITS_LOCK:
        arr = _RATE_LIMITS.get(kk, [])[-999:]
        arr.append(now)
        _RATE_LIMITS[kk] = arr


def _rate_limit_clear(bucket: str, key: str) -> None:
    kk = (str(bucket), str(key))
    with _RATE_LIMITS_LOCK:
        _RATE_LIMITS.pop(kk, None)

def _env_int(name: str, default: int) -> int:
    try:
        raw = str(os.environ.get(name, '')).strip()
        return int(raw) if raw else int(default)
    except Exception:
        return int(default)


def _try_acquire_public_job_slot(ip: str) -> tuple[bool, str]:
    global _PUBLIC_JOB_CREATE_TOTAL
    ip = str(ip or '?')
    # FIX618: small VPS safety default. Only one heavy optimization may run at once.
    # Later this can be raised through /etc/adzaagt/metod-pax/metod-pax.env on a larger server.
    max_total = _env_int('PUBLIC_JOB_MAX_CONCURRENT', 1)
    max_per_ip = _env_int('PUBLIC_JOB_MAX_CONCURRENT_PER_IP', 1)
    with _PUBLIC_JOB_CREATE_LOCK:
        current_ip = int(_PUBLIC_JOB_CREATE_BY_IP.get(ip, 0) or 0)
        if _PUBLIC_JOB_CREATE_TOTAL >= max_total:
            return False, 'total'
        if current_ip >= max_per_ip:
            return False, 'ip'
        _PUBLIC_JOB_CREATE_TOTAL += 1
        _PUBLIC_JOB_CREATE_BY_IP[ip] = current_ip + 1
        return True, 'ok'


def _release_public_job_slot(ip: str) -> None:
    global _PUBLIC_JOB_CREATE_TOTAL
    ip = str(ip or '?')
    with _PUBLIC_JOB_CREATE_LOCK:
        current_ip = int(_PUBLIC_JOB_CREATE_BY_IP.get(ip, 0) or 0)
        if current_ip <= 1:
            _PUBLIC_JOB_CREATE_BY_IP.pop(ip, None)
        else:
            _PUBLIC_JOB_CREATE_BY_IP[ip] = current_ip - 1
        if _PUBLIC_JOB_CREATE_TOTAL > 0:
            _PUBLIC_JOB_CREATE_TOTAL -= 1

_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
_ALLOWED_SUBMIT_ROOT_KEYS = {
    'jobId','parentJobId','subjobId','ts','material','customer','note','grainEnabled',
    'quote','cart','extraPanels','priceInclVat','platesTotal','materialsSummary','checkout'
}

_PUBLIC_STATIC_ROOT_FILES = {
    "toolA.html",
    "embedded_dxfs_manifest.json",
    "toolA_template_helpers.js",
    "toolA_safe_helper_layer.js",
    "toolA_view_math_helpers.js",
    "toolA_render_helpers.js",
    "toolA_material_swatch_renderer.js",
    "toolA_template_view_helpers.js",
    "toolA_module_registry.js",
    "toolA_runtime_guard.js",
    "toolA_load_contract.js",
    "toolA_validators.js",
    "toolA_core_selectors.js",
    "toolA_panel_edit_context.js",
    "toolA_panel_form_state.js",
    "toolA_panel_form_apply.js",
    "toolA_extra_panel_form_apply.js",
    "toolA_type_size_decisions.js",
    "toolA_footer_decisions.js",
    "toolA_footer_view_state.js",
    "toolA_footer_apply.js",
    "toolA_footer_bindings.js",
    "toolA_extra_panel_view_state.js",
    "toolA_extra_panel_mutations.js",
    "toolA_extra_panel_submit_flow.js",
    "toolA_extra_panel_submit_apply.js",
    "toolA_panel_mutations.js",
    "toolA_panel_submit_flow.js",
    "toolA_panel_submit_apply.js",
    "toolA_panel_bootstrap_mutations.js",
    "toolA_panel_bootstrap_apply.js",
    "toolA_material_batch_mutations.js",
    "toolA_customer_validation.js",
    "toolA_grain_validation.js",
    "toolA_panel_ui_state.js",
    "toolA_panel_controls_apply.js",
    "toolA_panels_view_models.js",
    "toolA_panel_dock_state.js",
    "toolA_panel_row_view_models.js",
    "toolA_core_read_helpers.js",
    "toolA_core_split_readiness.js",
    "toolA_entrypoints.js",
    "toolA_route_state.js",
    "toolA_route_footer_helpers.js",
    "toolA_showstep_apply.js",
    "toolA_panels_entrypoints.js",
    "decor_library.js",
    "toolA_overview_fix655.js",
    "toolA_grain_mobile_scale.css",
    "toolA_grain_mobile_scale.js",
    "toolA_grain_studio_math.js",
    "toolA_grain_studio_renderer.js",
    "toolA_grain_studio.css",
}

_BLOCKED_STATIC_TOP_LEVEL = {
    "config",
    "jobs",
    "requests",
    "archive",
    "backups",
    "system",
    "docs",
    "__pycache__",
}


def _is_public_static_relpath(rel: str) -> bool:
    rel = str(rel or '').strip().lstrip('/')
    if not rel:
        rel = 'toolA.html'
    rel = rel.replace('\\', '/')
    if rel in _PUBLIC_STATIC_ROOT_FILES:
        return True
    if rel.startswith('embedded_dxfs/'):
        return rel.lower().endswith('.dxf')
    if rel.startswith('assets/'):
        return rel.lower().endswith(('.png', '.jpg', '.jpeg', '.webp', '.svg'))
    return False


def _is_blocked_static_relpath(rel: str) -> bool:
    rel = str(rel or '').strip().lstrip('/').replace('\\', '/')
    if not rel:
        return False
    parts = [p for p in rel.split('/') if p not in ('', '.')]
    if not parts:
        return False
    first = parts[0]
    if first in _BLOCKED_STATIC_TOP_LEVEL:
        return True
    if any(part.startswith('.') for part in parts):
        return True
    low = rel.lower()
    if low.endswith(('.log', '.jsonl', '.py', '.pyc', '.bat', '.ps1', '.sh')):
        return True
    return False


def _catalog_review_sha256(stage: dict) -> str:
    """Bind an Admin approval to the exact CSV, warnings and normalized records."""

    if not isinstance(stage, dict):
        raise SafetyContractError('Invalid catalog review')
    records = stage.get('records') if isinstance(stage.get('records'), list) else []
    review = {
        'schemaVersion': 1,
        'csvSha256': str(stage.get('csvSha256') or ''),
        'warnings': stage.get('warnings') if isinstance(stage.get('warnings'), list) else [],
        'excluded': stage.get('excluded') if isinstance(stage.get('excluded'), list) else [],
        'errors': stage.get('errors') if isinstance(stage.get('errors'), list) else [],
        'summary': stage.get('summary') if isinstance(stage.get('summary'), dict) else {},
        'taxonomySummary': stage.get('taxonomySummary') if isinstance(stage.get('taxonomySummary'), dict) else {},
        'recordsSha256': hashlib.sha256(strict_json_dumps(records).encode('utf-8')).hexdigest(),
    }
    return hashlib.sha256(strict_json_dumps(review).encode('utf-8')).hexdigest()


def _pbkdf2_hash_password(password: str, *, iterations: int = 260000, salt: Optional[str] = None) -> str:
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac('sha256', str(password).encode('utf-8'), str(salt).encode('utf-8'), int(iterations))
    return f"pbkdf2_sha256${int(iterations)}${salt}${dk.hex()}"

def _verify_password_against_stored(password: str, stored: str) -> bool:
    try:
        raw = str(stored or '')
        if not raw:
            return False
        if raw.startswith('pbkdf2_sha256$'):
            parts = raw.split('$', 3)
            if len(parts) != 4:
                return False
            _, iter_s, salt, expected = parts
            if int(iter_s) != _ADMIN_PBKDF2_ITERATIONS:
                return False
            if not re.fullmatch(r'[A-Za-z0-9._-]{16,128}', salt) or not re.fullmatch(r'[a-f0-9]{64}', expected):
                return False
            calc = _pbkdf2_hash_password(password, iterations=_ADMIN_PBKDF2_ITERATIONS, salt=salt)
            return hmac.compare_digest(calc, raw)
        return hmac.compare_digest(str(password or ''), raw)
    except Exception:
        return False


def _normalized_admin_users(credentials: dict | None) -> list[dict[str, Any]]:
    creds = credentials if isinstance(credentials, dict) else {}
    raw_users = creds.get('users')
    users: list[dict[str, Any]] = []
    if isinstance(raw_users, list):
        for raw in raw_users:
            if not isinstance(raw, dict) or raw.get('active') is False:
                continue
            username = str(raw.get('username') or '').strip()
            password_hash = str(raw.get('password_hash') or raw.get('passwordHash') or '').strip()
            roles = raw.get('roles') if isinstance(raw.get('roles'), list) else ['admin']
            roles = sorted({str(role).strip().lower() for role in roles if str(role).strip()})
            if username and password_hash:
                users.append({
                    'username': username,
                    'password_hash': password_hash,
                    'totp_secret': str(raw.get('totp_secret') or raw.get('totpSecret') or '').strip(),
                    'roles': roles or ['admin'],
                })
        return users
    username = str(creds.get('username') or '').strip()
    password_hash = str(creds.get('password_hash') or creds.get('passwordHash') or creds.get('password') or '').strip()
    if username and password_hash:
        users.append({
            'username': username,
            'password_hash': password_hash,
            'totp_secret': str(creds.get('totp_secret') or creds.get('totpSecret') or '').strip(),
            'roles': ['admin'],
        })
    return users


def _find_admin_user(credentials: dict | None, username: str) -> dict[str, Any] | None:
    supplied = str(username or '').strip()
    for user in _normalized_admin_users(credentials):
        if hmac.compare_digest(str(user.get('username') or ''), supplied):
            return user
    return None


def _totp_code(secret: str, counter: int, digits: int = 6) -> str:
    normalized = re.sub(r'\s+', '', str(secret or '')).upper()
    padded = normalized + ('=' * ((8 - len(normalized) % 8) % 8))
    key = base64.b32decode(padded, casefold=True)
    digest = hmac.new(key, int(counter).to_bytes(8, 'big'), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    binary = int.from_bytes(digest[offset:offset + 4], 'big') & 0x7FFFFFFF
    return str(binary % (10 ** digits)).zfill(digits)


def _verify_totp(secret: str, supplied: str, now: float | None = None) -> bool:
    value = re.sub(r'\s+', '', str(supplied or ''))
    if not re.fullmatch(r'\d{6}', value):
        return False
    try:
        counter = int((time.time() if now is None else float(now)) // 30)
        return any(hmac.compare_digest(_totp_code(secret, counter + offset), value) for offset in (-1, 0, 1))
    except Exception:
        return False



def _admin_session_create(actor: str, roles: list[str] | None = None) -> tuple[str, float]:
    token = secrets.token_urlsafe(32)
    now = time.time()
    idle = max(300, min(3600, int(_ADMIN_SESSION_IDLE_SEC or 1800)))
    absolute = max(idle, min(24 * 60 * 60, int(_ADMIN_SESSION_ABSOLUTE_SEC or 28800)))
    exp = now + absolute
    with _ADMIN_SESSIONS_LOCK:
        for k, v in list(_ADMIN_SESSIONS.items()):
            if float(v.get('absoluteExpiresAt') or 0) <= now or float(v.get('idleExpiresAt') or 0) <= now:
                _ADMIN_SESSIONS.pop(k, None)
        max_sessions = max(8, min(4096, _env_int('ADMIN_MAX_SESSIONS', 1024)))
        while len(_ADMIN_SESSIONS) >= max_sessions:
            oldest = min(
                _ADMIN_SESSIONS,
                key=lambda key: float(_ADMIN_SESSIONS[key].get('lastSeenAt') or 0),
            )
            _ADMIN_SESSIONS.pop(oldest, None)
        _ADMIN_SESSIONS[token] = {
            'actor': str(actor or '').strip(),
            'roles': sorted({str(role).strip().lower() for role in (roles or ['admin']) if str(role).strip()}),
            'createdAt': now,
            'lastSeenAt': now,
            'idleExpiresAt': now + idle,
            'absoluteExpiresAt': exp,
        }
    return token, exp


def _admin_session_valid(token: str) -> bool:
    raw = str(token or '').strip()
    if not raw:
        return False
    with _ADMIN_SESSIONS_LOCK:
        session = _ADMIN_SESSIONS.get(raw)
        if not session:
            return False
        now = time.time()
        if float(session.get('absoluteExpiresAt') or 0) <= now or float(session.get('idleExpiresAt') or 0) <= now:
            _ADMIN_SESSIONS.pop(raw, None)
            return False
        idle = max(300, min(3600, int(_ADMIN_SESSION_IDLE_SEC or 1800)))
        session['lastSeenAt'] = now
        session['idleExpiresAt'] = min(now + idle, float(session.get('absoluteExpiresAt') or now))
        return True


def _admin_session_revoke(token: str) -> None:
    raw = str(token or '').strip()
    if raw:
        with _ADMIN_SESSIONS_LOCK:
            _ADMIN_SESSIONS.pop(raw, None)


def _admin_session_actor(token: str) -> str:
    raw = str(token or '').strip()
    if not raw:
        return ''
    with _ADMIN_SESSIONS_LOCK:
        session = _ADMIN_SESSIONS.get(raw) or {}
        return str(session.get('actor') or '').strip()


def _admin_session_roles(token: str) -> frozenset[str]:
    raw = str(token or '').strip()
    if not raw:
        return frozenset()
    with _ADMIN_SESSIONS_LOCK:
        session = _ADMIN_SESSIONS.get(raw) or {}
        roles = session.get('roles') if isinstance(session.get('roles'), list) else []
        return frozenset(str(role).strip().lower() for role in roles if str(role).strip())


def _extract_bearer_token(auth: str) -> str:
    raw = str(auth or '').strip()
    if raw.lower().startswith('bearer '):
        return raw.split(' ', 1)[1].strip()
    return ''

def _extract_admin_session_cookie(cookie_header: str) -> str:
    try:
        raw = str(cookie_header or '')
        for part in raw.split(';'):
            if '=' not in part:
                continue
            k, v = part.split('=', 1)
            if k.strip() == 'adzaagt_admin_session':
                return v.strip()
    except Exception:
        pass
    return ''


def _is_password_hash_value(v: Any) -> bool:
    try:
        raw = str(v or '')
        return bool(re.fullmatch(r'pbkdf2_sha256\$260000\$[A-Za-z0-9._-]{16,128}\$[a-f0-9]{64}', raw))
    except Exception:
        return False

def _env_flag(name: str, default: bool = False) -> bool:
    raw = str(os.environ.get(name, '')).strip().lower()
    if not raw:
        return bool(default)
    return raw in ('1', 'true', 'yes', 'on', 'prod', 'production')

def _is_production_hardening_enabled() -> bool:
    if _env_flag('PRODUCTION_HARDENING', False) or _env_flag('ADMIN_HASH_ONLY', False):
        return True
    app_env = str(os.environ.get('APP_ENV', '')).strip().lower()
    return app_env in ('prod', 'production')

def _is_https_request(handler) -> bool:
    try:
        if _is_trusted_proxy_peer(handler):
            xf = str(handler.headers.get('X-Forwarded-Proto') or '').strip().lower()
            if xf:
                return xf == 'https'
    except Exception:
        pass
    try:
        return bool(getattr(handler.server, 'server_port', None) == 443)
    except Exception:
        return False

def _is_secure_admin_transport(handler) -> bool:
    try:
        if _is_loopback_client(handler):
            return True
    except Exception:
        pass
    return _is_https_request(handler)

def _is_production_runtime() -> bool:
    return _is_production_hardening_enabled()

def _get_admin_credentials_file_path() -> Path:
    raw = str(os.environ.get('ADMIN_CREDENTIALS_FILE') or os.environ.get('ADMIN_CREDENTIALS_PATH') or '').strip()
    if raw:
        try:
            return Path(raw).expanduser()
        except Exception:
            pass
    credential_dir = str(os.environ.get('CREDENTIALS_DIRECTORY') or '').strip()
    if credential_dir:
        candidate = Path(credential_dir) / 'admin_credentials.live.json'
        if candidate.is_file():
            return candidate
    # FIX618: live deployments must prefer credentials outside the app directory.
    # This preserves existing VPS convention and avoids shipping real credentials in ZIPs.
    external_default = Path('/etc/adzaagt/metod-pax/admin_credentials.live.json')
    try:
        if external_default.exists():
            return external_default
    except Exception:
        pass
    return ROOT / 'config' / 'admin_credentials.json'

def _get_admin_password_reset_activation_file_path() -> Path:
    raw = str(os.environ.get('ADMIN_PASSWORD_RESET_ACTIVATION_FILE') or os.environ.get('ADMIN_PASSWORD_RESET_ACTIVATION_PATH') or '').strip()
    if raw:
        try:
            return Path(raw).expanduser()
        except Exception:
            pass
    return ROOT / 'config' / 'admin_password_reset_activation.json'

def _load_admin_password_reset_activation() -> dict | None:
    path = _get_admin_password_reset_activation_file_path()
    try:
        obj = strict_json_load(path)
        if isinstance(obj, dict):
            obj['_path'] = str(path)
            return obj
    except Exception:
        return None
    return None

def _admin_password_reset_activation_is_enabled() -> bool:
    try:
        obj = _load_admin_password_reset_activation() or {}
        return bool(obj.get('enabled'))
    except Exception:
        return False

def _split_env_origins(name: str) -> list[str]:
    vals = []
    for raw in str(os.environ.get(name, '')).split(','):
        item = str(raw or '').strip()
        if item:
            vals.append(item)
    return vals

def _origin_allowed(origin: str, *, admin: bool = False) -> bool:
    origin = str(origin or '').strip()
    if not origin:
        return False
    extra = _split_env_origins('ALLOWED_ADMIN_ORIGINS' if admin else 'ALLOWED_ORIGINS')
    if origin in extra:
        return True
    try:
        parsed = urlparse(origin)
        host = str(parsed.hostname or '').strip().lower()
    except Exception:
        return False
    if not host:
        return False
    if _is_production_runtime():
        return False
    return _is_loopback_value(host)

def _public_error_message(code: int, fallback: str = 'Er ging iets mis.') -> str:
    code = int(code or 500)
    if code == 400:
        return 'Ongeldige aanvraag.'
    if code == 403:
        return 'Actie niet toegestaan.'
    if code == 404:
        return 'Niet gevonden.'
    if code == 413:
        return 'Aanvraag te groot.'
    if code == 429:
        return 'Te veel verzoeken. Probeer het later opnieuw.'
    return fallback

def _is_str(v: Any) -> bool:
    return isinstance(v, str)

def _clean_text(v: Any, max_len: int = 5000) -> str:
    s = str(v or '')
    if len(s) > int(max_len):
        s = s[:int(max_len)]
    return s


_FORBIDDEN_FILE_CHARS = set('/\\:*?"<>|')
_ALLOWED_USER_TEXT_EXTRA = set(" .,_-")
_ALLOWED_NOTE_EXTRA = set(" .,_-")

def _sanitize_user_text(v: Any, max_len: int = 240, *, allow_note_chars: bool = False) -> str:
    raw = _clean_text(v, max_len * 4 if max_len else 4000)
    extras = _ALLOWED_NOTE_EXTRA if allow_note_chars else _ALLOWED_USER_TEXT_EXTRA
    out = []
    last_space = False
    for ch in raw:
        if ch in ('\r', '\n', '\t'):
            ch = ' '
        allowed = ch.isalnum() or ch in extras
        if not allowed and ch in _FORBIDDEN_FILE_CHARS:
            ch = ' '
            allowed = True
        if not allowed:
            continue
        if ch.isspace():
            if last_space:
                continue
            out.append(' ')
            last_space = True
        else:
            out.append(ch)
            last_space = False
    s = ''.join(out).strip()
    if max_len and len(s) > int(max_len):
        s = s[:int(max_len)].rstrip()
    return s

def _sanitize_phone_text(v: Any, max_len: int = 60) -> str:
    raw = _clean_text(v, max_len * 2)
    out = []
    for ch in raw:
        if ch.isdigit() or ch in ' +()-':
            out.append(ch)
    s = re.sub(r'\s+', ' ', ''.join(out)).strip()
    return s[:max_len]

def _sanitize_postcode_text(v: Any, max_len: int = 16) -> str:
    raw = _clean_text(v, max_len * 2)
    out = []
    for ch in raw:
        if ch.isalnum() or ch == ' ':
            out.append(ch.upper())
    s = re.sub(r'\s+', ' ', ''.join(out)).strip()
    return s[:max_len]

def _validate_submit_payload(payload: Any) -> tuple[bool, list[str], dict]:
    errs: list[str] = []
    clean: dict = {}
    if not isinstance(payload, dict):
        return False, ['Payload must be a JSON object.'], {}

    unknown = [k for k in payload.keys() if k not in _ALLOWED_SUBMIT_ROOT_KEYS]
    if unknown:
        errs.append('Onbekende velden in aanvraagpayload.')

    def _safe_id_field(name: str, max_len: int = 200):
        val = payload.get(name)
        if val in (None, ''):
            return
        sval = str(val).strip()
        if len(sval) > min(120, int(max_len)) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', sval):
            errs.append(f'Ongeldige waarde voor {name}.')
        else:
            clean[name] = sval

    _safe_id_field('jobId')
    _safe_id_field('parentJobId')
    _safe_id_field('subjobId')

    if payload.get('ts') not in (None, ''):
        ts = str(payload.get('ts')).strip()
        if len(ts) > 80:
            errs.append('Tijdstempel is te lang.')
        else:
            clean['ts'] = ts

    if payload.get('material') is not None:
        if not isinstance(payload.get('material'), (str, dict, list, type(None))):
            errs.append('Materiaalveld heeft een ongeldig type.')
        else:
            clean['material'] = payload.get('material')

    if payload.get('grainEnabled') is not None and not isinstance(payload.get('grainEnabled'), bool):
        errs.append('grainEnabled moet true of false zijn.')
    else:
        clean['grainEnabled'] = bool(payload.get('grainEnabled')) if payload.get('grainEnabled') is not None else None

    note = payload.get('note')
    if note not in (None, ''):
        if not _is_str(note):
            errs.append('Opmerking moet tekst zijn.')
        else:
            clean['note'] = _sanitize_user_text(note, 4000, allow_note_chars=True)

    cust = payload.get('customer')
    if cust is None:
        cust = {}
    if not isinstance(cust, dict):
        errs.append('Klantgegevens moeten een object zijn.')
        cust = {}
    cc = {}
    allowed_customer_keys = {'name','fullName','firstName','lastName','email','mail','phone','tel','telephone','billingAddress','invoiceAddress','address','addressLine1','street','shippingAddress','deliveryAddress','address1','postalCode','postcode','city','plaats','country','note'}
    for k, v in list(cust.items())[:100]:
        if k not in allowed_customer_keys:
            continue
        if v in (None, ''):
            continue
        if not _is_str(v):
            errs.append(f'Klantveld {k} moet tekst zijn.')
            continue
        max_len = 320 if k in {'email','mail'} else 500
        if k in {'email','mail'}:
            cc[k] = _clean_text(v, max_len).strip()
        elif k in {'phone','tel','telephone'}:
            cc[k] = _sanitize_phone_text(v, min(max_len, 60))
        elif k in {'postalCode','postcode'}:
            cc[k] = _sanitize_postcode_text(v, 16)
        elif k in {'note'}:
            cc[k] = _sanitize_user_text(v, max_len, allow_note_chars=True)
        else:
            cc[k] = _sanitize_user_text(v, max_len)
    email = str(cc.get('email') or cc.get('mail') or '').strip()
    if not email:
        errs.append('E-mailadres ontbreekt.')
    elif not _EMAIL_RE.match(email):
        errs.append('E-mailadres is ongeldig.')
    clean['customer'] = cc

    quote = payload.get('quote')
    if quote is not None and not isinstance(quote, dict):
        errs.append('Quote moet een object zijn.')
    elif isinstance(quote, dict):
        try:
            ensure_finite_json(quote)
            if len(strict_json_dumps(quote)) > 400000:
                errs.append('Quote is te groot.')
            else:
                clean['quote'] = quote
        except Exception:
            errs.append('Quote kon niet worden verwerkt.')

    mats = payload.get('materialsSummary')
    if mats is not None:
        if not isinstance(mats, list):
            errs.append('materialsSummary moet een lijst zijn.')
        elif len(mats) > 100:
            errs.append('materialsSummary bevat te veel regels.')
        else:
            out = []
            for idx, it in enumerate(mats):
                if not isinstance(it, dict):
                    errs.append(f'materialsSummary regel {idx+1} is ongeldig.')
                    continue
                row = {}
                for k in ('code','name'):
                    if it.get(k) not in (None, ''):
                        if not _is_str(it.get(k)):
                            errs.append(f'materialsSummary.{k} op regel {idx+1} moet tekst zijn.')
                        else:
                            row[k] = _clean_text(it.get(k), 200)
                if it.get('plates') not in (None, ''):
                    try:
                        plates = finite_number(it.get('plates'), field='materialsSummary.plates', minimum=0, maximum=10000)
                        row['plates'] = plates
                    except Exception:
                        errs.append(f'materialsSummary.plates op regel {idx+1} is ongeldig.')
                out.append(row)
            clean['materialsSummary'] = out

    for num_name in ('priceInclVat','platesTotal'):
        if payload.get(num_name) not in (None, ''):
            try:
                val = finite_number(payload.get(num_name), field=num_name, minimum=0, maximum=100000000)
                clean[num_name] = val
            except Exception:
                errs.append(f'{num_name} is ongeldig.')

    def _validate_panel_list(name: str):
        arr = payload.get(name)
        if arr is None:
            clean[name] = []
            return
        if not isinstance(arr, list):
            errs.append(f'{name} moet een lijst zijn.')
            return
        if len(arr) > 1000:
            errs.append(f'{name} bevat te veel regels.')
            return
        out = []
        allowed_keys = {'id','type','size','qty','quantity','width','height','length','name','panelName','description','materialCode','materialKey','articleNumber','materialDisplayName','productName','decorName','grainGroupId','grainOrder','rotation','topExt','bottomExt','extensions','edgeBanding','material','hingeSide','swingDirection'}
        for idx, it in enumerate(arr):
            if not isinstance(it, dict):
                errs.append(f'{name} regel {idx+1} is ongeldig.')
                continue
            row = {}
            for k,v in list(it.items())[:80]:
                if k not in allowed_keys:
                    continue
                if isinstance(v, (str, int, float, bool)) or v is None:
                    if isinstance(v, str):
                        if k in {'name','panelName','description','productName','articleNumber'}:
                            row[k] = _sanitize_user_text(v, 240)
                        else:
                            row[k] = _clean_text(v, 500)
                    else:
                        row[k] = v
                elif isinstance(v, dict):
                    if k == 'edgeBanding':
                        eb = {}
                        for ek,ev in list(v.items())[:10]:
                            if ek in {'top','bottom','left','right'}:
                                eb[ek] = bool(ev)
                        row[k] = eb
                    elif k == 'extensions':
                        ex = {}
                        for ek,ev in list(v.items())[:10]:
                            if ek in {'top','bottom'}:
                                try:
                                    ex[ek] = finite_number(ev, field=f'{name}.{ek}', minimum=0, maximum=100000)
                                except Exception:
                                    pass
                        row[k] = ex
                # other nested values ignored
            qty = row.get('qty', row.get('quantity', 1))
            try:
                qtyn = int(qty)
                if qtyn < 1 or qtyn > 10000:
                    raise ValueError()
                row['qty'] = qtyn
                row.pop('quantity', None)
            except Exception:
                errs.append(f'{name} regel {idx+1} heeft een ongeldig aantal.')
            for nk in ('width','height','length','topExt','bottomExt'):
                if nk in row and row[nk] not in (None, ''):
                    try:
                        fv = finite_number(row[nk], field=f'{name}.{nk}', minimum=0, maximum=100000)
                        row[nk] = fv
                    except Exception:
                        errs.append(f'{name} regel {idx+1} heeft een ongeldig veld {nk}.')
            out.append(row)
        clean[name] = out

    _validate_panel_list('cart')
    _validate_panel_list('extraPanels')

    checkout = payload.get('checkout')
    if checkout is not None:
        if not isinstance(checkout, dict):
            errs.append('checkout moet een object zijn.')
        else:
            clean['checkout'] = checkout

    panel_count = len(clean.get('cart') or []) + len(clean.get('extraPanels') or [])
    if panel_count <= 0:
        errs.append('Geen panelen gevonden in de aanvraag.')

    return len(errs) == 0, errs, clean


def _extract_request_token(handler, parsed=None, body: Optional[dict]=None) -> str:
    return _helpers_extract_request_token(handler, parsed=parsed, body=body)

def _new_public_access_token() -> str:
    return uuid.uuid4().hex + uuid.uuid4().hex

def _write_job_access_token(job_id: str, token: str) -> None:
    try:
        job_root = resolve_identifier_child(JOBS, validate_job_id(job_id))
        if not job_root.exists():
            return
        _atomic_write_json(job_root / '.public_access.json', {'token': str(token), 'jobId': str(job_id), 'updatedAt': _utc_now_iso()})
    except Exception:
        pass

def _read_job_access_token(job_id: str) -> str:
    try:
        job_root = resolve_identifier_child(JOBS, validate_job_id(job_id))
        path = job_root / '.public_access.json'
        if not path.exists():
            return ''
        data = strict_json_load(path)
        return str(data.get('token') or '').strip()
    except Exception:
        return ''

# Prefer the Windows Python launcher (py -3) to avoid binding to a specific installed python.exe
# and to keep compatibility with environments where sys.executable may be a newer Python (e.g. 3.14).
def _get_python_base_cmd():
    # Use the same Python interpreter as the server for maximum compatibility and speed.
    # (Avoid calling the Windows py launcher for Tool B, which can be slow and may select a different Python version.)
    return [sys.executable]

# --- Server-Sent Events (SSE) for live updates (ToolA reload without page refresh) ---
_SSE_CLIENTS_LOCK = threading.Lock()
_SSE_CLIENTS: list[queue.Queue] = []
_MAX_SSE_CLIENTS = max(1, min(128, _env_int('MAX_SSE_CLIENTS', 24)))


_PUBLIC_SSE_EVENT_ALLOWLIST = frozenset({'dxf_changed'})

def _sse_broadcast(event: Optional[str] = None, data: Optional[dict] = None) -> None:
    """Broadcast only the tiny public DXF freshness event surface.

    FIX657 deliberately drops request/order lifecycle broadcasts. /api/events is public
    and therefore may never disclose request IDs, customer workflow state or errors.
    """
    if str(event or '') not in _PUBLIC_SSE_EVENT_ALLOWLIST:
        return
    safe_data = {}
    if str(event or '') == 'dxf_changed':
        # Keep only fields needed by Tool A. Category/filename are harmless but unnecessary
        # for the public client and are intentionally omitted to minimize metadata.
        safe_data = {'dxfVersion': str((data or {}).get('dxfVersion') or '')}
    payload = {
        "event": event,
        "data": safe_data,
        "ts": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
    }
    with _SSE_CLIENTS_LOCK:
        dead: list[queue.Queue] = []
        for q in _SSE_CLIENTS:
            try:
                q.put_nowait(payload)
            except Exception:
                dead.append(q)
        if dead:
            _SSE_CLIENTS[:] = [q for q in _SSE_CLIENTS if q not in dead]


def _sse_handler(handler) -> None:
    """Handle /api/events SSE stream."""
    q = queue.Queue(maxsize=64)
    with _SSE_CLIENTS_LOCK:
        if len(_SSE_CLIENTS) >= _MAX_SSE_CLIENTS:
            return handler._send_json({'ok': False, 'error': 'Event stream capacity reached'}, 503)
        _SSE_CLIENTS.append(q)

    handler.send_response(200)
    handler.send_header('Content-Type', 'text/event-stream; charset=utf-8')
    handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
    handler.send_header('Pragma', 'no-cache')
    handler.send_header('Connection', 'keep-alive')
    handler.end_headers()

    # Initial hello + current DXF version
    try:
        init = {
            "event": "hello",
            "data": {"dxfVersion": get_embedded_dxfs_version()},
            "ts": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        }
        handler.wfile.write(f"event: {init['event']}\n".encode('utf-8'))
        handler.wfile.write(f"data: {json.dumps(init)}\n\n".encode('utf-8'))
        handler.wfile.flush()
    except Exception:
        with _SSE_CLIENTS_LOCK:
            try:
                _SSE_CLIENTS.remove(q)
            except ValueError:
                pass
        return

    last_ping = time.time()
    try:
        while True:
            try:
                msg = q.get(timeout=5.0)
                handler.wfile.write(f"event: {msg['event']}\n".encode('utf-8'))
                handler.wfile.write(f"data: {json.dumps(msg)}\n\n".encode('utf-8'))
                handler.wfile.flush()
            except queue.Empty:
                pass

            now = time.time()
            if now - last_ping >= 15.0:
                last_ping = now
                handler.wfile.write(b": ping\n\n")
                handler.wfile.flush()
    except Exception:
        pass
    finally:
        with _SSE_CLIENTS_LOCK:
            try:
                _SSE_CLIENTS.remove(q)
            except ValueError:
                pass

# --- DXF startup migration (file-based, deterministic) ---
DXF_CATEGORIES = [
    "Deuren METOD",
    "Ladefront METOD",
    "Deuren PAX",
    "Overige panelen",
]

def _classify_dxf_filename(name: str) -> str:
    n = name.lower()
    # PAX first
    if n.startswith("pax"):
        return "Deuren PAX"
    # METOD ladefront
    if n.startswith("metod") and ("lade" in n or "ladefront" in n):
        return "Ladefront METOD"
    # METOD deuren
    if n.startswith("metod") and ("deur" in n or "deuren" in n):
        return "Deuren METOD"
    return "Overige panelen"

def migrate_embedded_dxfs_on_startup():
    # Moves DXF files from embedded_dxfs root into category folders.
    # One-time safe: only removes the original file after successful move.
    # Deterministic: classification uses filename only.
    dxf_root = DXF_LIBRARY_ROOT
    dxf_root.mkdir(parents=True, exist_ok=True)

    # Ensure category folders exist
    for cat in DXF_CATEGORIES:
        (dxf_root / cat).mkdir(parents=True, exist_ok=True)

    moved = 0
    for fp in sorted(dxf_root.iterdir()):
        if not fp.is_file():
            continue
        if fp.suffix.lower() != ".dxf":
            continue
        target_cat = _classify_dxf_filename(fp.name)
        dest = dxf_root / target_cat / fp.name
        if dest.exists():
            # Keep category version; leave root file untouched
            continue
        try:
            os.replace(fp, dest)
            fsync_directory(dest.parent)
            fsync_directory(dxf_root)
            moved += 1
        except Exception:
            continue
    return moved

OPTIMIZER_TOOL_B = 'dxf_nesting_optimizer.py'  # rollback: set to 'dxf_nesting_optimizer_v1_2.py'
JOBS = STATE_ROOT / "jobs"
DRAFTS = STATE_ROOT / "drafts"

# Lightweight index/registry folder (used by some endpoints).
INDEX_DIR = STATE_ROOT / "index"

# Append-only requests index (JSONL). This is used to power Admin inbox views
# without scanning the full requests tree. Must be defined at module load so
# endpoints like /api/submit_config never fail with NameError.
REQUESTS_INDEX = INDEX_DIR / "requests_index.jsonl"

# --- Requests/Queue (online A-only foundation; file-based, deterministic) ---
REQUESTS = STATE_ROOT / "requests"
QUEUE_DIR = STATE_ROOT / "queue"
QUEUE_PENDING = QUEUE_DIR / "pending"
QUEUE_PROCESSING = QUEUE_DIR / "processing"
QUEUE_DONE = QUEUE_DIR / "done"
QUEUE_FAILED = QUEUE_DIR / "failed"
SUBMISSION_IDEMPOTENCY_DIR = INDEX_DIR / "submission_idempotency"
_SUBMISSION_IDEMPOTENCY_LOCK = threading.Lock()

# --- Retention / archive (submitted/request-linked: 90 dagen actief -> archive, 90 dagen archive -> delete; orphan jobs: direct delete na 7 dagen) ---
ARCHIVE_ROOT = STATE_ROOT / "archive"
ARCHIVE_JOBS = ARCHIVE_ROOT / "jobs"
ARCHIVE_REQUESTS = ARCHIVE_ROOT / "requests"
ARCHIVE_QUEUE_DONE = ARCHIVE_ROOT / "queue_done"
ARCHIVE_QUEUE_FAILED = ARCHIVE_ROOT / "queue_failed"
RETENTION_ACTIVE_DAYS = 90
RETENTION_ARCHIVE_DAYS = 90
ORPHAN_JOB_RETENTION_DAYS = 7
ARCHIVE_META_NAME = ".archived_meta.json"
_LAST_RETENTION_RUN_TS = 0.0
_RETENTION_MIN_INTERVAL_SECONDS = 6 * 60 * 60  # max 1x per 6 uur per proces

# Queue / maintenance hardening
STALE_PENDING_QUEUE_DAYS = 7
STALE_PROCESSING_QUEUE_HOURS = 24
_LAST_QUEUE_MAINTENANCE_TS = 0.0
_QUEUE_MAINTENANCE_MIN_INTERVAL_SECONDS = 60 * 60  # max 1x per uur per proces
_SERVER_MAINTENANCE_LOOP_SECONDS = 15 * 60

# --- System logs / backups ---
SYSTEM_DIR = STATE_ROOT / "system"
CATALOG_IMPORT_ROOT = SYSTEM_DIR / "catalog_imports"
CATALOG_IMPORT_HISTORY = CATALOG_IMPORT_ROOT / "history"
SYSTEM_LOG_FILE = SYSTEM_DIR / "system_events.jsonl"
BACKUPS_DIR = STATE_ROOT / "backups"
AUTO_BACKUP_INTERVAL_DAYS = 7
AUTO_BACKUP_KEEP = 8
MANUAL_BACKUP_KEEP = 12
LAST_AUTO_BACKUP_FILE = SYSTEM_DIR / "last_auto_backup.json"
_STATE_SNAPSHOT_LOCK = threading.RLock()
_STATE_MUTATION_CV = threading.Condition(threading.RLock())
_STATE_MUTATION_COUNT = 0
_STATE_SNAPSHOT_ACTIVE = False


def _state_snapshot_is_active() -> bool:
    with _STATE_MUTATION_CV:
        return bool(_STATE_SNAPSHOT_ACTIVE)


def _begin_consistent_snapshot(timeout_seconds: float = 60.0) -> None:
    global _STATE_SNAPSHOT_ACTIVE
    deadline = time.monotonic() + max(5.0, float(timeout_seconds))
    with _STATE_MUTATION_CV:
        if _STATE_SNAPSHOT_ACTIVE:
            raise RuntimeError('Another state snapshot is already active')
        _STATE_SNAPSHOT_ACTIVE = True
        while _STATE_MUTATION_COUNT > 0:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                _STATE_SNAPSHOT_ACTIVE = False
                _STATE_MUTATION_CV.notify_all()
                raise RuntimeError('Timed out draining state mutations for backup')
            _STATE_MUTATION_CV.wait(timeout=min(0.5, remaining))
    while True:
        with _PUBLIC_JOB_CREATE_LOCK:
            active_creates = _PUBLIC_JOB_CREATE_TOTAL
        with _ACTIVE_JOB_PROCESSES_LOCK:
            active_processes = sum(len(items) for items in _ACTIVE_JOB_PROCESSES.values())
        with _CATALOG_IMAGE_SYNC_LOCK:
            active_catalog_sync = len(_CATALOG_IMAGE_SYNC_ACTIVE)
        queue_busy = any(QUEUE_PROCESSING.glob('*.json'))
        if active_creates == 0 and active_processes == 0 and active_catalog_sync == 0 and not queue_busy:
            return
        if time.monotonic() >= deadline:
            _end_consistent_snapshot()
            raise RuntimeError('Timed out draining active jobs for backup')
        time.sleep(0.25)


def _end_consistent_snapshot() -> None:
    global _STATE_SNAPSHOT_ACTIVE
    with _STATE_MUTATION_CV:
        _STATE_SNAPSHOT_ACTIVE = False
        _STATE_MUTATION_CV.notify_all()



def _ensure_system_dirs() -> None:
    for d in (SYSTEM_DIR, BACKUPS_DIR, CATALOG_IMPORT_ROOT, CATALOG_IMPORT_HISTORY):
        d.mkdir(parents=True, exist_ok=True)


def _initialize_external_state() -> None:
    """Bootstrap mutable state once, outside the immutable release tree."""

    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    if os.name != 'nt':
        os.chmod(STATE_ROOT, 0o750)
    for directory in (
        JOBS, DRAFTS, INDEX_DIR, REQUESTS, QUEUE_PENDING, QUEUE_PROCESSING,
        QUEUE_DONE, QUEUE_FAILED, SUBMISSION_IDEMPOTENCY_DIR, ARCHIVE_JOBS,
        ARCHIVE_REQUESTS, ARCHIVE_QUEUE_DONE, ARCHIVE_QUEUE_FAILED, SYSTEM_DIR,
        BACKUPS_DIR, DECOR_MEDIA_ROOT, CONFIG_DIR,
    ):
        directory.mkdir(parents=True, exist_ok=True)

    if not MATERIAL_LIBRARY_PATH.exists() and MATERIAL_LIBRARY_SEED_PATH.is_file():
        durable_copy_file(MATERIAL_LIBRARY_SEED_PATH, MATERIAL_LIBRARY_PATH, mode=0o640)

    if not DXF_LIBRARY_ROOT.exists():
        source_root = ROOT / 'embedded_dxfs'
        if not source_root.is_dir():
            raise RuntimeError('Immutable embedded DXF seed is missing')
        staging = STATE_ROOT / f'.embedded_dxfs.bootstrap.{os.getpid()}.{secrets.token_hex(6)}'
        try:
            staging.mkdir(parents=True, exist_ok=False)
            for source in sorted(source_root.rglob('*')):
                relative = source.relative_to(source_root)
                destination = staging / relative
                if source.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                elif source.is_file():
                    durable_copy_file(source, destination, mode=0o640)
            os.replace(staging, DXF_LIBRARY_ROOT)
            fsync_directory(STATE_ROOT)
        finally:
            if staging.exists():
                shutil.rmtree(staging, ignore_errors=True)


def _safe_text(v, max_len: int = 240) -> str:
    try:
        s = str(v or "").strip()
    except Exception:
        s = ""
    if len(s) > max_len:
        s = s[: max_len - 1] + "…"
    return s


_REDACT_EMAIL_RE = re.compile(r'([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+\.[A-Za-z]{2,})')
_REDACT_PHONE_RE = re.compile(r'(?<!\w)(?:\+?\d[\d()\-\s]{6,}\d)(?!\w)')
_REDACT_POSTCODE_RE = re.compile(r'\b\d{4}\s?[A-Za-z]{2}\b')
_REDACT_TOKEN_RE = re.compile(r'(?i)\b(?:token|password|passwd|secret|authorization|cookie|set-cookie)\b\s*[:=]\s*[^,;\s]+')
_REDACT_URL_QUERY_RE = re.compile(r'([?&](?:email|mail|phone|tel|telephone|address|postcode|postalcode|token|password|secret)=[^&#]*)', re.I)


def _redact_sensitive_text(v, max_len: int = 240) -> str:
    s = _safe_text(v, max_len=max_len * 2 if max_len and max_len > 0 else 480)
    if not s:
        return ""
    try:
        s = _REDACT_EMAIL_RE.sub(lambda m: f"{m.group(1)}***@{m.group(2)}", s)
        s = _REDACT_PHONE_RE.sub('[redacted-phone]', s)
        s = _REDACT_POSTCODE_RE.sub('[redacted-postcode]', s)
        s = _REDACT_TOKEN_RE.sub('[redacted-secret]', s)
        s = _REDACT_URL_QUERY_RE.sub('[redacted-query]', s)
    except Exception:
        pass
    if max_len and len(s) > max_len:
        s = s[: max_len - 1] + "…"
    return s


def _sanitize_log_value(value, *, max_depth: int = 2, max_items: int = 20):
    if max_depth < 0:
        return '[truncated]'
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return _redact_sensitive_text(value, 300)
    if isinstance(value, dict):
        out = {}
        for i, (k, v) in enumerate(value.items()):
            if i >= max_items:
                out['__truncated__'] = True
                break
            ks = str(k)[:80]
            low = ks.lower()
            if low in {'password', 'passwd', 'secret', 'token', 'authorization', 'cookie', 'set-cookie', 'email', 'mail', 'phone', 'tel', 'telephone', 'address', 'billingaddress', 'shippingaddress', 'postcode', 'postalcode'}:
                out[ks] = '[redacted]'
            else:
                out[ks] = _sanitize_log_value(v, max_depth=max_depth - 1, max_items=max_items)
        return out
    if isinstance(value, (list, tuple)):
        out = []
        for i, item in enumerate(value):
            if i >= max_items:
                out.append('[truncated]')
                break
            out.append(_sanitize_log_value(item, max_depth=max_depth - 1, max_items=max_items))
        return out
    return _redact_sensitive_text(value, 200)


def _guess_customer_name_from_payload(payload: dict | None) -> str:
    if not isinstance(payload, dict):
        return ""
    for key in ("customer", "client", "contact"):
        obj = payload.get(key)
        if isinstance(obj, dict):
            for nk in ("name", "fullName", "company", "companyName"):
                val = _safe_text(obj.get(nk), 120)
                if val:
                    return val
    for nk in ("customerName", "name", "companyName", "company"):
        val = _safe_text(payload.get(nk), 120)
        if val:
            return val
    return ""


def _guess_customer_name(request_id: str = "", payload: dict | None = None, status: dict | None = None) -> str:
    name = _guess_customer_name_from_payload(payload)
    if name:
        return name
    if isinstance(status, dict):
        for key in ("customerName", "customer", "clientName", "name"):
            val = status.get(key)
            if isinstance(val, dict):
                val = val.get("name") or val.get("company")
            val = _safe_text(val, 120)
            if val:
                return val
    rid = _safe_id(request_id or "", 120)
    if rid:
        try:
            fp = REQUESTS / rid / "input" / "submit_payload.json"
            if fp.exists():
                pl = strict_json_load(fp)
                return _guess_customer_name_from_payload(pl)
        except Exception:
            pass
    return ""


def _append_system_event(*, level: str = "error", component: str = "system", message_user: str, message_tech: str = "", request_id: str = "", job_id: str = "", customer_name: str = "", status: str = "open", details: dict | None = None) -> None:
    try:
        _ensure_system_dirs()
        rec = {
            "ts": _now_iso(),
            "level": _safe_text(level, 32) or "error",
            "component": _safe_text(component, 64) or "system",
            "messageUser": _safe_text(message_user, 400),
            "messageTech": _redact_sensitive_text(message_tech, 1200),
            "requestId": _safe_text(request_id, 120),
            "jobId": _safe_text(job_id, 120),
            "customerName": "",
            "status": _safe_text(status, 32) or "open",
            "details": _sanitize_log_value(details or {}, max_depth=2, max_items=20),
        }
        append_jsonl_rotating(
            SYSTEM_LOG_FILE,
            rec,
            max_bytes=_env_int('SYSTEM_LOG_MAX_BYTES', 20 * 1024 * 1024),
            backups=10,
        )
    except Exception:
        pass


def _read_system_events(limit: int = 200) -> list[dict]:
    try:
        if not SYSTEM_LOG_FILE.exists():
            return []
        lines = tail_text_lines(
            SYSTEM_LOG_FILE,
            max(1, int(limit) * 3),
            max_scan_bytes=_env_int('SYSTEM_LOG_MAX_SCAN_BYTES', 2 * 1024 * 1024),
        )
        out = []
        for line in reversed(lines[-max(1, int(limit)*3):]):
            try:
                rec = strict_json_loads(line)
                if isinstance(rec, dict):
                    out.append(rec)
                    if len(out) >= limit:
                        break
            except Exception:
                continue
        return out
    except Exception:
        return []


def _cleanup_old_backups() -> None:
    try:
        _ensure_system_dirs()
        removed = False
        auto_files = []
        manual_files = []
        for fp in BACKUPS_DIR.glob("*.zip"):
            nm = fp.name.lower()
            if nm.startswith("system_backup_auto_"):
                auto_files.append(fp)
            elif nm.startswith("system_backup_manual_"):
                manual_files.append(fp)
            elif nm.startswith("system_backup_"):
                manual_files.append(fp)
        auto_files = sorted(auto_files, key=lambda p: p.stat().st_mtime, reverse=True)
        manual_files = sorted(manual_files, key=lambda p: p.stat().st_mtime, reverse=True)
        for fp in auto_files[AUTO_BACKUP_KEEP:]:
            try:
                fp.unlink()
                removed = True
            except Exception:
                pass
        for fp in manual_files[MANUAL_BACKUP_KEEP:]:
            try:
                fp.unlink()
                removed = True
            except Exception:
                pass
        if removed:
            fsync_directory(BACKUPS_DIR)
    except Exception:
        pass


def _write_last_auto_backup(dt: datetime, file_name: str) -> None:
    try:
        _ensure_system_dirs()
        durable_write_json(LAST_AUTO_BACKUP_FILE, {
            "ts": dt.isoformat(),
            "file": file_name,
        })
    except Exception:
        pass


def _read_last_auto_backup_dt() -> datetime | None:
    try:
        if LAST_AUTO_BACKUP_FILE.exists():
            data = strict_json_load(LAST_AUTO_BACKUP_FILE)
            ts = str((data or {}).get("ts") or "").strip()
            if ts:
                return datetime.fromisoformat(ts)
    except Exception:
        pass
    try:
        auto_files = sorted(BACKUPS_DIR.glob("system_backup_auto_*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
        if auto_files:
            return datetime.fromtimestamp(auto_files[0].stat().st_mtime)
    except Exception:
        pass
    return None


def run_backup_maintenance(force: bool = False) -> dict:
    try:
        _ensure_system_dirs()
        _cleanup_old_backups()
        last_dt = _read_last_auto_backup_dt()
        now = datetime.now()
        if (not force) and last_dt and (now - last_dt) < timedelta(days=AUTO_BACKUP_INTERVAL_DAYS):
            return {
                "ok": True,
                "created": False,
                "reason": "recent_auto_backup_exists",
                "last": last_dt.isoformat(),
            }
        res = _create_system_backup(actor="system", backup_kind="auto")
        _write_last_auto_backup(now, str(res.get("file") or ""))
        return {"ok": True, "created": True, "backup": res}
    except Exception as e:
        _append_system_event(level="error", component="backup", message_user="Automatische backup is mislukt", message_tech=str(e), status="open")
        return {"ok": False, "error": str(e)}


def _create_system_backup(actor: str = "admin", backup_kind: str = "manual") -> dict:
    _ensure_system_dirs()
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f") + '_' + secrets.token_hex(3)
    prefix = "system_backup_auto" if str(backup_kind).lower() == "auto" else "system_backup_manual"
    out = BACKUPS_DIR / f"{prefix}_{ts}.zip"
    temp = BACKUPS_DIR / f'.{out.name}.{secrets.token_hex(8)}.tmp'
    manifest: dict[str, Any] = {
        'schemaVersion': 2,
        'createdAt': _now_iso(),
        'actor': str(actor or 'unknown'),
        'kind': str(backup_kind),
        'releaseBuild': SECURITY_BUILD,
        'stateRoot': str(STATE_ROOT),
        'files': {},
    }
    max_source_bytes = max(1, _env_int('BACKUP_MAX_SOURCE_BYTES', 16 * 1024 * 1024 * 1024))
    max_files = max(1, _env_int('BACKUP_MAX_FILES', 200_000))
    source_bytes = 0
    file_count = 0
    _begin_consistent_snapshot(timeout_seconds=max(10, _env_int('BACKUP_DRAIN_TIMEOUT_SEC', 60)))
    try:
        with _STATE_SNAPSHOT_LOCK:
            with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                def add_file(source: Path, archive_name: str) -> None:
                    nonlocal source_bytes, file_count
                    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0)
                    fd = os.open(str(source), flags)
                    try:
                        file_stat = os.fstat(fd)
                        if not stat.S_ISREG(file_stat.st_mode):
                            raise RuntimeError(f'Backup source is not a regular file: {source}')
                        file_count += 1
                        if file_count > max_files:
                            raise RuntimeError('Backup source exceeds BACKUP_MAX_FILES')
                        digest = hashlib.sha256()
                        copied = 0
                        with os.fdopen(fd, 'rb', closefd=False) as input_handle, zf.open(archive_name, 'w', force_zip64=True) as output_handle:
                            while True:
                                chunk = input_handle.read(1024 * 1024)
                                if not chunk:
                                    break
                                copied += len(chunk)
                                source_bytes += len(chunk)
                                if source_bytes > max_source_bytes:
                                    raise RuntimeError('Backup source exceeds BACKUP_MAX_SOURCE_BYTES')
                                digest.update(chunk)
                                output_handle.write(chunk)
                        manifest['files'][archive_name] = {'sha256': digest.hexdigest(), 'size': copied}
                    finally:
                        os.close(fd)

                for child in sorted(STATE_ROOT.rglob('*')):
                    if child.is_symlink():
                        raise RuntimeError(f'Symlink is forbidden in backup source: {child.relative_to(STATE_ROOT)}')
                    if not child.is_file():
                        continue
                    relative = child.relative_to(STATE_ROOT)
                    if not relative.parts or relative.parts[0] == 'backups':
                        continue
                    if relative.parts[:2] == ('system', 'exports'):
                        continue
                    archive_name = f'state/{relative.as_posix()}'
                    add_file(child, archive_name)
                for source in (ROOT / 'pricing_v13mm.json', ROOT / 'server_py.py'):
                    if source.is_file():
                        archive_name = f'release/{source.name}'
                        add_file(source, archive_name)
                zf.writestr('BACKUP_MANIFEST.json', strict_json_dumps(manifest, indent=2) + '\n')
            with open(temp, 'rb') as backup_handle:
                os.fsync(backup_handle.fileno())
            os.replace(temp, out)
            fsync_directory(BACKUPS_DIR)
            if os.name != 'nt':
                os.chmod(out, 0o600)
            with zipfile.ZipFile(out, 'r') as check:
                if check.testzip() is not None:
                    raise RuntimeError('Backup ZIP verification failed')
                stored = strict_json_loads(check.read('BACKUP_MANIFEST.json'))
                if stored.get('files') != manifest['files']:
                    raise RuntimeError('Backup manifest verification failed')
                for archive_name, evidence in manifest['files'].items():
                    digest = hashlib.sha256()
                    size = 0
                    with check.open(archive_name, 'r') as source:
                        for chunk in iter(lambda: source.read(1024 * 1024), b''):
                            digest.update(chunk)
                            size += len(chunk)
                    if size != int(evidence['size']) or not hmac.compare_digest(digest.hexdigest(), str(evidence['sha256'])):
                        raise RuntimeError(f'Backup content verification failed: {archive_name}')
    finally:
        temp.unlink(missing_ok=True)
        _end_consistent_snapshot()
    _cleanup_old_backups()
    msg = "Automatische backup voltooid" if str(backup_kind).lower() == "auto" else "Handmatige backup voltooid"
    _append_system_event(level="info", component="backup", message_user=msg, message_tech=f"Created {out.name}", status="resolved", details={"actor": actor, "file": out.name, "kind": backup_kind})
    st = out.stat()
    return {"ok": True, "file": out.name, "path": str(out), "size": st.st_size, "modified": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"), "kind": backup_kind}


def _list_backups(limit: int = 50) -> list[dict]:
    try:
        _ensure_system_dirs()
        items = []
        for fp in sorted(BACKUPS_DIR.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]:
            st = fp.stat()
            nm = fp.name.lower()
            kind = "auto" if nm.startswith("system_backup_auto_") else "manual"
            items.append({
                "name": fp.name,
                "size": st.st_size,
                "modified": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                "kind": kind,
            })
        return items
    except Exception:
        return []


# --- Notifications (ntfy) ---
CONFIG_NOTIFY = STATE_ROOT / "config_notify.json"
CONFIG_NOTIFY_EXAMPLE = ROOT / "config_notify.example.json"

def _get_notify_config_file_path() -> Path:
    raw = str(os.environ.get('NOTIFY_CONFIG_FILE') or os.environ.get('CONFIG_NOTIFY_FILE') or '').strip()
    if raw:
        try:
            return Path(raw).expanduser()
        except Exception:
            pass
    return CONFIG_NOTIFY

NTFY_LOG = STATE_ROOT / "client_logs" / "ntfy.log"

def _ntfy_log(line: str) -> None:
    try:
        append_jsonl_rotating(
            NTFY_LOG,
            {'ts': _now_iso(), 'event': _redact_sensitive_text(line, 400)},
            max_bytes=max(1024, _env_int('NTFY_LOG_MAX_BYTES', 5 * 1024 * 1024)),
            backups=3,
        )
    except Exception:
        pass


def _load_notify_config() -> dict:
    """
    Notification config is OPTIONAL.
    - If app/config_notify.json exists, it overrides defaults.
    - If missing, we use safe defaults so it works out-of-the-box.
    """
    defaults = {
        "ntfy": {
            "enabled": False,
            "topic_url": "",
            "title": "AD Zaagt Configurator",
            "include_customer_details": False,
            "include_price_breakdown": False,
            "minimal_order_notice": True,
        }
    }
    try:
        notify_cfg_path = _get_notify_config_file_path()
        if notify_cfg_path.exists():
            cfg = strict_json_load(notify_cfg_path)
            if isinstance(cfg, dict):
                # shallow-merge defaults
                out = defaults.copy()
                nt = defaults.get("ntfy", {}).copy()
                if isinstance(cfg.get("ntfy"), dict):
                    nt.update(cfg.get("ntfy"))
                out["ntfy"] = nt
                return out
    except Exception:
        pass
    return defaults



_MATERIAL_NAME_BY_CODE = None

def _load_material_name_by_code() -> dict:
    global _MATERIAL_NAME_BY_CODE
    if isinstance(_MATERIAL_NAME_BY_CODE, dict):
        return _MATERIAL_NAME_BY_CODE
    out = {}
    try:
        ml_path = MATERIAL_LIBRARY_PATH
        if ml_path.exists():
            raw = strict_json_load(ml_path)
            recs = raw.get("records") if isinstance(raw, dict) else raw
            if isinstance(recs, list):
                for r in recs:
                    if not isinstance(r, dict):
                        continue
                    code = str(r.get("articleNo") or r.get("articleNumber") or r.get("materialCode") or "").strip()
                    name = str(r.get("productName") or r.get("materialDisplayName") or r.get("materialName") or "").strip()
                    if code and name and code not in out:
                        out[code] = name
    except Exception:
        pass
    _MATERIAL_NAME_BY_CODE = out
    return out

def _looks_numeric_material_name(v: str) -> bool:
    vv = str(v or "").strip().replace(",", ".")
    if not vv:
        return False
    try:
        float(vv)
        return True
    except Exception:
        return False

def _best_material_name(code: str, *candidates) -> str:
    for c in candidates:
        name = str(c or "").strip()
        if name and not _looks_numeric_material_name(name):
            return name
    code = str(code or "").strip()
    if code:
        lib = _load_material_name_by_code()
        if code in lib:
            return lib[code]
    for c in candidates:
        name = str(c or "").strip()
        if name:
            return name
    return ""


def _material_label_for_filename(material_code: str, thickness_mm) -> str:
    """Build a human-readable material label for exported filenames.
    Prefer the real material/decor name from loaded material metadata; fall back to code.
    Thickness is intentionally omitted from the visible filename label for cleaner DXF names.
    """
    code = str(material_code or '').strip()
    name = _best_material_name(code, '') if code else ''
    return str(name or code or '').strip()

def _ntfy_send(
    title: Optional[str] = None,
    message: str = "",
    click_url: Optional[str] = None,
    priority: Optional[int] = None,
    tags: Optional[list[str]] = None,
) -> tuple[bool, str]:
    """Send ntfy notification. Never raises. Returns (ok, error)."""
    cfg = _load_notify_config()
    nt = cfg.get("ntfy") if isinstance(cfg, dict) else None
    if not isinstance(nt, dict):
        return (False, "ntfy config missing")
    if nt.get("enabled") is False:
        return (False, "ntfy disabled")
    topic_url = str(nt.get("topic_url") or "").strip()
    if not topic_url:
        return (False, "ntfy topic_url empty")
    try:
        parsed_topic = urlparse(topic_url)
        allowed_hosts = {host.lower() for host in _split_env_csv('NTFY_ALLOWED_HOSTS', 'ntfy.sh')}
        if (
            parsed_topic.scheme.lower() != 'https' or not parsed_topic.hostname
            or parsed_topic.username or parsed_topic.password
            or parsed_topic.hostname not in allowed_hosts
        ):
            return (False, 'ntfy endpoint is not an allowed HTTPS host')
    except Exception:
        return (False, 'ntfy endpoint is invalid')

    hdr_title = str(nt.get("title") or title or "").strip() or "Notification"
    auth = str(nt.get("authorization") or nt.get("auth") or nt.get("token") or "").strip()

    body = (message or "").encode("utf-8")
    headers = {
        "Title": hdr_title,
        "Content-Type": "text/plain; charset=utf-8",
        "User-Agent": "METOD-PAX-LocalServer/1.0",
    }
    if click_url:
        headers["Click"] = str(click_url)
    if priority is not None:
        headers["Priority"] = str(int(priority))
    if tags:
        headers["Tags"] = ",".join([str(t) for t in tags if t])
    if auth:
        # Allow both raw token and full 'Bearer ...'
        if auth.lower().startswith("bearer "):
            headers["Authorization"] = auth
        else:
            headers["Authorization"] = "Bearer " + auth

    req = Request(topic_url, data=body, headers=headers, method="POST")
    try:
        with urlopen(req, timeout=8, context=ssl.create_default_context()) as resp:
            resp.read(1)
        _ntfy_log(f"notification delivered host={parsed_topic.hostname}")
        return (True, "")
    except ssl.SSLCertVerificationError as e:
        _ntfy_log("notification failed: TLS verification")
        return (False, "tls_verification_failed")
    except Exception:
        _ntfy_log("notification delivery failed")
        return (False, "delivery_failed")


def _format_money_eur(x) -> str:
    try:
        v = float(x)
        if not (v == v):
            return ""
        s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        return f"€{s}"
    except Exception:
        return ""

def _extract_request_summary(payload: dict) -> dict:
    """Best-effort summary for notifications: customer, panels/plates, materials, price."""
    out = {
        "customerName": "",
        "customerEmail": "",
        "customerPhone": "",
        "customerAddress": "",
        "panelsTotal": None,
        "platesTotal": None,
        "materials": [],  # list of {code, name, plates}
        "priceInclVat": None,
        "materialsPrice": None,
    }
    try:
        cust = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
        if isinstance(cust, dict):
            first = str(cust.get("firstName") or "").strip()
            last = str(cust.get("lastName") or "").strip()
            full = " ".join([x for x in [first, last] if x]).strip()
            out["customerName"] = str(cust.get("name") or cust.get("fullName") or full or "").strip()
            out["customerEmail"] = str(cust.get("email") or cust.get("mail") or "").strip()
            out["customerPhone"] = str(cust.get("phone") or cust.get("tel") or cust.get("telephone") or "").strip()
            postcode = str(cust.get("postcode") or "").strip()
            house = str(cust.get("houseNumber") or "").strip()
            city = str(cust.get("city") or "").strip()
            addr_line = " ".join([x for x in [postcode, house] if x]).strip()
            bill = str(cust.get("billingAddress") or cust.get("invoiceAddress") or cust.get("address") or "").strip()
            ship = str(cust.get("shippingAddress") or cust.get("deliveryAddress") or cust.get("address1") or bill or "").strip()
            addr_parts = []
            if bill:
                addr_parts.append(("Factuur: " + " ".join([x for x in [bill, addr_line] if x]).strip()).strip())
            if ship and ship != bill:
                addr_parts.append(("Bezorg: " + " ".join([x for x in [ship, addr_line] if x]).strip()).strip())
            if city:
                addr_parts.append(city)
            out["customerAddress"] = " | ".join([x for x in addr_parts if x]).strip()
    except Exception:
        pass

    # Price incl VAT: prefer explicit field
    for k in ["priceInclVat", "totalPriceInclVat", "totalInclVat"]:
        try:
            if payload.get(k) is not None:
                out["priceInclVat"] = float(payload.get(k))
                break
        except Exception:
            pass

    quote = payload.get("quote") if isinstance(payload.get("quote"), dict) else None
    if out["priceInclVat"] is None and isinstance(quote, dict):
        for k in ["grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat"]:
            if quote.get(k) is not None:
                try:
                    out["priceInclVat"] = float(quote.get(k))
                    break
                except Exception:
                    pass
        if out["priceInclVat"] is None:
            try:
                t = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                for k in ["grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat"]:
                    if t.get(k) is not None:
                        out["priceInclVat"] = float(t.get(k))
                        break
            except Exception:
                pass
        if out["priceInclVat"] is None:
            try:
                t = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                base = None
                for k in ["grandTotal", "total", "subtotal"]:
                    if t.get(k) is not None:
                        base = float(t.get(k))
                        break
                if base is None:
                    for k in ["grandTotal", "total", "subtotal"]:
                        if quote.get(k) is not None:
                            base = float(quote.get(k))
                            break
                if base is not None:
                    out["priceInclVat"] = round(base * 1.21, 2)
            except Exception:
                pass

    # Materials: prefer explicit summary if ToolA provided it
    mats = payload.get("materialsSummary")
    if isinstance(mats, list):
        for m in mats:
            if not isinstance(m, dict):
                continue
            code = str(m.get("code") or m.get("articleNumber") or m.get("materialCode") or "").strip()
            name = _best_material_name(code, m.get("materialDisplayName"), m.get("materialName"), m.get("name"), m.get("productName"), m.get("decorName"))
            plates = m.get("plates")
            try:
                plates = int(plates) if plates is not None else None
            except Exception:
                plates = None
            if code or name:
                out["materials"].append({"code": code, "name": name, "plates": plates})
    else:
        # derive from cart + extraPanels
        codes = {}
        def _add(code, name=""):
            if not code and not name:
                return
            key = code or name
            if key not in codes:
                codes[key] = {"code": code, "name": name, "plates": None}
        for arr_key in ["cart", "extraPanels", "panels"]:
            arr = payload.get(arr_key)
            if not isinstance(arr, list):
                continue
            for p in arr:
                if not isinstance(p, dict):
                    continue
                code = str(p.get("articleNumber") or p.get("materialKey") or p.get("materialCode") or "").strip()
                name = _best_material_name(code, p.get("materialDisplayName"), p.get("productName"), p.get("decorName"), p.get("name"))
                _add(code, name)
        out["materials"] = list(codes.values())

    # Plates: from explicit fields, else from quote heuristics
    try:
        if payload.get("platesTotal") is not None:
            out["platesTotal"] = int(payload.get("platesTotal"))
    except Exception:
        pass
    if out["platesTotal"] is None and isinstance(quote, dict):
        # heuristics
        candidates = []
        def walk(o):
            if isinstance(o, dict):
                for k,v in o.items():
                    lk=str(k).lower()
                    if lk in ("plates", "platencount", "sheetcount", "sheetsused", "boardsused", "boardscount"):
                        if isinstance(v, (int,float)) and v>=0:
                            candidates.append(int(v))
                    walk(v)
            elif isinstance(o, list):
                for v in o: walk(v)
        walk(quote)
        if candidates:
            out["platesTotal"] = max(candidates)  # best-effort (often totals)
    # Also map per-material plates if possible
    if isinstance(quote, dict):
        mats2 = []
        try:
            qm = quote.get("materials") if isinstance(quote.get("materials"), list) else None
            if qm:
                for m in qm:
                    if not isinstance(m, dict):
                        continue
                    code = str(m.get("materialCode") or m.get("code") or m.get("articleNumber") or "").strip()
                    name = _best_material_name(code, m.get("materialDisplayName"), m.get("materialName"), m.get("name"), m.get("productName"), m.get("decorName"))
                    plates = None
                    for kk in ["plates", "sheets", "sheetsUsed", "boards", "boardsUsed", "sheetCount"]:
                        if m.get(kk) is not None:
                            try:
                                plates = int(m.get(kk))
                                break
                            except Exception:
                                pass
                    mats2.append({"code": code, "name": name, "plates": plates})
        except Exception:
            pass
        if mats2:
            # merge into existing list by code
            by = { (x.get("code") or x.get("name")): x for x in out["materials"] }
            for m in mats2:
                key = m.get("code") or m.get("name")
                if not key:
                    continue
                if key in by and m.get("plates") is not None:
                    by[key]["plates"] = m.get("plates")
                elif key not in by:
                    out["materials"].append(m)

    # Materials total if present in payload/quote
    for k in ["materialsPrice", "materialsTotal", "materialTotal", "materialsAmount"]:
        try:
            if payload.get(k) is not None:
                out["materialsPrice"] = float(payload.get(k))
                break
        except Exception:
            pass
    if out["materialsPrice"] is None and isinstance(quote, dict):
        try:
            mats_total = None
            for k in ["materialsTotal", "materialTotal", "subtotalMaterials", "materialsSubtotal"]:
                if quote.get(k) is not None:
                    mats_total = quote.get(k)
                    break
            if mats_total is None:
                totals = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                for k in ["materialsTotal", "materialTotal", "subtotalMaterials", "materialsSubtotal"]:
                    if totals.get(k) is not None:
                        mats_total = totals.get(k)
                        break
            if mats_total is None and isinstance(quote.get("materials"), list):
                vals = []
                for m in quote.get("materials") or []:
                    if not isinstance(m, dict):
                        continue
                    for k in ["priceInclVat", "totalInclVat", "grandTotal", "total", "subtotal", "price"]:
                        if m.get(k) is not None:
                            try:
                                vals.append(float(m.get(k)))
                                break
                            except Exception:
                                pass
                if vals:
                    mats_total = sum(vals)
            if mats_total is not None:
                out["materialsPrice"] = float(mats_total)
        except Exception:
            pass

    # Panels total from payload cart/extraPanels/panels (sum qty, fallback item count)
    try:
        panels_total = 0
        found_any = False
        for arr_key in ["cart", "extraPanels", "panels"]:
            arr = payload.get(arr_key)
            if not isinstance(arr, list):
                continue
            for p in arr:
                if not isinstance(p, dict):
                    continue
                found_any = True
                qty = None
                for k in ["qty", "quantity", "count", "aantal"]:
                    if p.get(k) is not None:
                        try:
                            qty = int(float(p.get(k)))
                            break
                        except Exception:
                            pass
                panels_total += qty if (qty is not None and qty > 0) else 1
        if found_any and panels_total > 0:
            out["panelsTotal"] = panels_total
    except Exception:
        pass

    return out

def _calculation_summary_text_for_ntfy(job_ids: list[str] | None) -> tuple[str, str]:
    """Return the first final calculation_summary.txt for the submitted order.

    ntfy must match the real backend/admin calculation, not the earlier frontend
    payload. Prefer the same human-readable calculation summary that Admin exposes.
    """
    for jid in (job_ids or []):
        jid = _safe_id(str(jid or '').strip(), 200)
        if not jid:
            continue
        for rel in ('output/calculation_summary.txt', 'input/calculation_summary.txt', 'calculation_summary.txt'):
            try:
                fp = JOBS / jid / rel
                if fp.exists() and fp.is_file():
                    txt = fp.read_text(encoding='utf-8', errors='ignore')
                    if txt.strip():
                        return txt, jid
            except Exception:
                pass
    return '', ''


def _parse_calculation_summary_for_ntfy(text: str) -> dict:
    """Small, safe parser for notification-only fields from calculation_summary.txt."""
    out = {
        'panelsTotal': None,
        'platesTotal': None,
        'materials': [],
        'edgeMeters': [],
        'pricing': {},
    }
    s = str(text or '')
    if not s.strip():
        return out

    def _eur_to_float(raw):
        try:
            return round(float(str(raw).replace('.', '').replace(',', '.')), 2)
        except Exception:
            return None

    def _m_to_float(raw):
        try:
            return round(float(str(raw).replace('.', '').replace(',', '.')), 2)
        except Exception:
            return None

    try:
        m = re.search(r'Aantal panelen:\s*([0-9]+)', s, re.I)
        if m:
            out['panelsTotal'] = int(m.group(1))
        m = re.search(r'Aantal platen:\s*([0-9]+)', s, re.I)
        if m:
            out['platesTotal'] = int(m.group(1))
    except Exception:
        pass

    pats = {
        'materialsTotalInclVat': r'Plaatmateriaal incl\. btw:\s*€\s*([0-9\.,]+)',
        'materialsTotal': r'Plaatmateriaal netto-equivalent:\s*€\s*([0-9\.,]+)',
        'materialsVatIncluded': r'BTW reeds in plaatprijs:\s*€\s*([0-9\.,]+)',
        'otherCostsExVat': r'Overige kosten excl\. btw:\s*€\s*([0-9\.,]+)',
        'otherCostsVat': r'BTW over overige kosten:\s*€\s*([0-9\.,]+)',
        'edgeBandTotal': r'Kantenband excl\. btw:\s*€\s*([0-9\.,]+)',
        'cncTotal': r'CNC excl\. btw:\s*€\s*([0-9\.,]+)',
        'drawingTotal': r'Tekenen excl\. btw:\s*€\s*([0-9\.,]+)',
        'transportTotal': r'Transport excl\. btw:\s*€\s*([0-9\.,]+)',
        'subtotalExVat': r'Subtotaal excl\. btw:\s*€\s*([0-9\.,]+)',
        'vatAmount': r'BTW\s*\(21%\):\s*€\s*([0-9\.,]+)',
        'totalInclVat': r'Totaal incl\. btw:\s*€\s*([0-9\.,]+)',
    }
    for key, pat in pats.items():
        try:
            m = re.search(pat, s, re.I)
            if m:
                out['pricing'][key] = _eur_to_float(m.group(1))
        except Exception:
            pass

    # Material block: keep the visible material line + next details line.
    try:
        mat_block = ''
        m = re.search(r'Materialen / platen\s*-+\s*(.*?)(?:\nKantenband \(m¹\) per decor|\nKostenopbouw|\Z)', s, re.I | re.S)
        if m:
            mat_block = m.group(1)
        cur = None
        for raw in mat_block.splitlines():
            line = raw.strip()
            if not line or line.startswith('Opslagfactor') or line.startswith('Plaatprijs') or line.startswith('Subtotaal'):
                continue
            if line.startswith('- '):
                if cur:
                    out['materials'].append(cur)
                cur = {'label': line[2:].strip(), 'detail': ''}
            elif cur and ('Platen:' in line or 'Dikte:' in line or 'Plaatmaat:' in line):
                cur['detail'] = line.strip()
        if cur:
            out['materials'].append(cur)
    except Exception:
        pass

    try:
        edge_block = ''
        m = re.search(r'Kantenband \(m¹\) per decor\s*-+\s*(.*?)(?:\nKostenopbouw|\Z)', s, re.I | re.S)
        if m:
            edge_block = m.group(1)
        for raw in edge_block.splitlines():
            line = raw.strip()
            if not line.startswith('- '):
                continue
            mm = re.search(r'^-\s*(.+?):\s*([0-9\.,]+)\s*m', line, re.I)
            if mm:
                out['edgeMeters'].append({'label': mm.group(1).strip(), 'meters': _m_to_float(mm.group(2))})
    except Exception:
        pass
    return out


def _merge_ntfy_pricing(summary: dict, calculation_info: dict, authoritative_pricing: dict | None) -> dict:
    pricing = {}
    try:
        if isinstance(summary, dict):
            if summary.get('materialsPrice') is not None:
                pricing['materialsTotal'] = float(summary.get('materialsPrice'))
            if summary.get('priceInclVat') is not None:
                pricing['totalInclVat'] = float(summary.get('priceInclVat'))
    except Exception:
        pass
    try:
        if isinstance(authoritative_pricing, dict):
            for k in ('materialsTotal','materialsTotalInclVat','materialsVatIncluded','otherCostsExVat','otherCostsVat','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
                if authoritative_pricing.get(k) is not None:
                    pricing[k] = authoritative_pricing.get(k)
    except Exception:
        pass
    try:
        calc_pr = (calculation_info or {}).get('pricing') if isinstance(calculation_info, dict) else {}
        if isinstance(calc_pr, dict):
            for k, v in calc_pr.items():
                if v is not None:
                    pricing[k] = v
    except Exception:
        pass
    return pricing


def _notify_privacy_options() -> dict:
    cfg = _load_notify_config()
    nt = cfg.get('ntfy') if isinstance(cfg, dict) else {}
    if not isinstance(nt, dict):
        nt = {}
    return {
        'include_customer_details': bool(nt.get('include_customer_details') is True),
        'include_price_breakdown': bool(nt.get('include_price_breakdown', True) is not False),
        'minimal_order_notice': bool(nt.get('minimal_order_notice', True) is not False),
    }

def _ntfy_public_safe_customer_lines(status: dict | None, payload: dict) -> list[str]:
    # Privacy-first default: never push name, email, phone or address unless explicitly enabled.
    opts = _notify_privacy_options()
    if not opts.get('include_customer_details'):
        return []
    cust_lines = _customer_block_from_sources(status if isinstance(status, dict) else None, payload if isinstance(payload, dict) else {})
    compact = []
    keep = False
    for line in cust_lines:
        line = str(line or '').strip()
        if line in ('Klant', 'Adres', 'Restmateriaal', 'Opmerking klant'):
            keep = line
            continue
        if not line or set(line) == {'-'} or line.startswith('Aanvraag') or line.startswith('Request ID') or line.startswith('Datum'):
            continue
        if keep == 'Klant' and (line.startswith('Naam:') or line.startswith('Email:') or line.startswith('Telefoon:')):
            compact.append(line)
        elif keep == 'Adres' and (line.startswith('Factuur:') or line.startswith('Bezorg:') or line.startswith('Plaats:') or line.startswith('Land:')):
            compact.append(line)
        elif keep == 'Restmateriaal' and line.startswith('Meeleveren:'):
            compact.append('Restmateriaal ' + line)
        elif keep == 'Opmerking klant' and line:
            compact.append('Opmerking: ' + line[:220])
    return compact[:10]

def _notify_submitted(request_id: str, payload: dict, status: dict | None = None, job_ids: list[str] | None = None, authoritative_pricing: dict | None = None) -> tuple[bool, str]:
    summ = _extract_request_summary(payload or {})
    calc_text, calc_job_id = _calculation_summary_text_for_ntfy(job_ids or [])
    calc_info = _parse_calculation_summary_for_ntfy(calc_text)
    pricing = _merge_ntfy_pricing(summ, calc_info, authoritative_pricing)
    notify_opts = _notify_privacy_options()

    parts = []
    parts.append("Nieuwe order ontvangen")

    total = pricing.get('totalInclVat')
    if total is not None:
        parts.append("Totaal: " + _format_money_eur(total))

    parts.append("Request: " + str(request_id))
    parts.append("Open admin voor details.")

    # VPS/live default: ntfy is only a lightweight signal. It must not receive
    # customer data, panel rows, material lines, address data, notes or job links.
    if notify_opts.get('minimal_order_notice', True):
        msg = "\n".join(parts)
        ok, err = _ntfy_send("AD Zaagt Configurator", msg, tags=["new"])
        if not ok:
            _ntfy_log(f"SUBMIT notify failed: {err}")
        return (ok, err)

    # Legacy verbose mode below is opt-in only through the private server-only
    # notify config. Keep it disabled for staging/live unless there is a strong
    # reason and an explicit privacy decision.
    parts = []
    parts.append("Nieuwe configuratie")

    # Customer/order info is privacy-first. By default, ntfy never receives customer PII
    # such as name, email, phone, address or free-text notes. Enable explicitly with
    # ntfy.include_customer_details=true in the private server-only config if required.
    try:
        compact = _ntfy_public_safe_customer_lines(status if isinstance(status, dict) else None, payload if isinstance(payload, dict) else {})
        if compact:
            parts.append("")
            parts.append("👤 Klant/order")
            parts.extend(compact[:10])
    except Exception:
        pass

    cfg_lines = []
    panel_count = calc_info.get('panelsTotal') if isinstance(calc_info, dict) else None
    if panel_count is None:
        panel_count = summ.get('panelsTotal')
    if panel_count is not None:
        cfg_lines.append(f"Panelen: {panel_count}")
    plate_count = calc_info.get('platesTotal') if isinstance(calc_info, dict) else None
    if plate_count is None:
        plate_count = summ.get('platesTotal')
    if plate_count is not None:
        cfg_lines.append(f"Platen: {plate_count}")

    calc_mats = (calc_info or {}).get('materials') if isinstance(calc_info, dict) else []
    if calc_mats:
        for m in calc_mats[:6]:
            label = str((m or {}).get('label') or '').strip()
            detail = str((m or {}).get('detail') or '').strip()
            if label:
                cfg_lines.append('• ' + label)
                if detail:
                    cfg_lines.append('  ' + detail)
    else:
        mats = summ.get("materials") or []
        for m in mats[:6]:
            name = str(m.get("name") or "").strip()
            code = str(m.get("code") or "").strip()
            if name and code and code.lower() not in name.lower():
                label = f"{name} ({code})"
            else:
                label = name or code
            if not label:
                continue
            if m.get("plates") is not None:
                cfg_lines.append(f"• {label} - {m['plates']} plaat/platen")
            else:
                cfg_lines.append(f"• {label}")
    if cfg_lines:
        parts.append("")
        parts.append("Configuratie")
        parts.extend(cfg_lines[:18])

    edge_lines = []
    for e in ((calc_info or {}).get('edgeMeters') if isinstance(calc_info, dict) else [])[:6]:
        label = str((e or {}).get('label') or '').strip()
        meters = (e or {}).get('meters')
        if label and meters is not None:
            edge_lines.append(f"• {label}: {_format_m(meters)}")
    if edge_lines:
        parts.append("")
        parts.append("Kantenband")
        parts.extend(edge_lines)

    price_lines = []
    labels = (
        ('materialsTotalInclVat', 'Plaatmateriaal incl. btw'),
        ('edgeBandTotal', 'Kantenband excl. btw'),
        ('cncTotal', 'CNC'),
        ('drawingTotal', 'Tekenen'),
        ('transportTotal', 'Transport'),
        ('subtotalExVat', 'Subtotaal excl. btw'),
        ('vatAmount', 'BTW'),
        ('totalInclVat', 'Totaal incl. btw'),
    )
    for key, label in labels:
        if pricing.get(key) is not None:
            price_lines.append(f"{label}: {_format_money_eur(pricing.get(key))}")
    if price_lines and notify_opts.get('include_price_breakdown'):
        parts.append("")
        parts.append("Berekening" + (" (exact uit calculation_summary)" if calc_text else ""))
        parts.extend(price_lines)
    elif pricing.get('totalInclVat') is not None:
        parts.append("")
        parts.append("Totaal incl. btw: " + _format_money_eur(pricing.get('totalInclVat')))

    parts.append("")
    parts.append("Request")
    parts.append(request_id)
    if calc_job_id:
        parts.append(f"Job: {calc_job_id}")

    msg = "\n".join(parts)
    ok, err = _ntfy_send("AD Zaagt Configurator", msg, tags=["new"])
    if not ok:
        _ntfy_log(f"SUBMIT notify failed: {err}")
    return (ok, err)

def _notify_failed(request_id: str, err: str) -> tuple[bool, str]:
    err1 = str(err or "").strip().splitlines()[0][:180]
    msg = "\n".join([
        "🔴 Optimizer fout",
        f"Request: {request_id}",
        err1 or "Onbekende fout",
        "Check Admin",
    ])
    # No auto-link to admin (user request)
    ok, err = _ntfy_send("AD Zaagt Configurator", msg, tags=["warning"])
    if not ok:
        _ntfy_log(f"FAIL notify failed: {err}")
    return (ok, err)

PORT = int(os.environ.get("METOD_PORT", "8787"))
JOB_OUTPUT_MAX_BYTES = int(os.environ.get("JOB_OUTPUT_MAX_BYTES", str(512 * 1024 * 1024)))


def _job_output_limit_message(size_bytes: int, limit_bytes: int) -> str:
    try:
        size_mb = float(size_bytes) / (1024.0 * 1024.0)
    except Exception:
        size_mb = 0.0
    try:
        limit_mb = float(limit_bytes) / (1024.0 * 1024.0)
    except Exception:
        limit_mb = 0.0
    return f"Job te groot tijdens verwerking ({size_mb:.1f} MB). Het maximum is {limit_mb:.0f} MB. Splits de job op in meerdere delen."


def _job_family_size_bytes(master_root: Path, subjob_roots: list[Path] | None = None) -> int:
    total = 0
    roots = [master_root]
    if isinstance(subjob_roots, list):
        roots.extend([r for r in subjob_roots if isinstance(r, Path)])
    for r in roots:
        try:
            total += _dir_size_bytes(r)
        except Exception:
            pass
    return int(total)


def _enforce_job_output_limit(master_root: Path, subjob_roots: list[Path] | None = None, limit_bytes: int | None = None) -> int:
    limit = int(limit_bytes or JOB_OUTPUT_MAX_BYTES)
    total = _job_family_size_bytes(master_root, subjob_roots)
    if total > limit:
        raise RuntimeError(_job_output_limit_message(total, limit))
    return total


def _enforce_state_capacity(projected_bytes: int, projected_inodes: int = 256) -> dict[str, int]:
    """Reserve configured free-space and inode headroom before creating a job."""

    projected = max(0, int(projected_bytes))
    inode_need = max(1, int(projected_inodes))
    usage = shutil.disk_usage(STATE_ROOT)
    reserve_bytes = max(64 * 1024 * 1024, _env_int('MIN_FREE_STATE_BYTES', 1024 * 1024 * 1024))
    required_free = reserve_bytes + projected
    if int(usage.free) < required_free:
        raise SafetyContractError('Onvoldoende veilige opslagruimte voor deze aanvraag.')
    result = {
        'freeBytes': int(usage.free),
        'requiredFreeBytes': int(required_free),
    }
    if hasattr(os, 'statvfs'):
        fs = os.statvfs(STATE_ROOT)
        free_inodes = int(fs.f_favail)
        reserve_inodes = max(100, _env_int('MIN_FREE_STATE_INODES', 10_000))
        required_inodes = reserve_inodes + inode_need
        if free_inodes < required_inodes:
            raise SafetyContractError('Onvoldoende vrije bestandsposities voor deze aanvraag.')
        result.update({'freeInodes': free_inodes, 'requiredFreeInodes': required_inodes})
    return result


def _expand_dxf_payload(payload: dict) -> dict[str, str]:
    """Return logical PartId -> DXF text from legacy or FIX655 compact transport.

    FIX655 sends each identical transformed DXF once (`dxfBlobs`) and maps PartIds
    through `dxfPartRefs`. This reduces customer-side preparation/JSON upload without
    changing the optimizer's proven per-PartId input contract.
    """
    if not isinstance(payload, dict):
        return {}

    def _valid_part_id(value: object) -> str:
        raw = str(value or '').strip()
        if not raw or len(raw) > 80 or not re.fullmatch(r'[A-Za-z0-9_-]+', raw):
            raise ValueError('Ongeldige DXF PartId in aanvraag.')
        return raw

    legacy = payload.get('dxfParts')
    if isinstance(legacy, dict) and legacy:
        if payload.get('dxfBlobs') or payload.get('dxfPartRefs'):
            raise ValueError('Ambigue DXF-transportvorm in aanvraag.')
        max_entries = _env_int('PUBLIC_DXF_MAX_COUNT', 500)
        if len(legacy) > max_entries:
            raise ValueError('Te veel DXF-bestanden in aanvraag.')
        max_blob_bytes = _env_int('PUBLIC_DXF_BLOB_MAX_BYTES', 2 * 1024 * 1024)
        max_total_bytes = _env_int('PUBLIC_DXF_TOTAL_MAX_BYTES', 12 * 1024 * 1024)
        total_bytes = 0
        out: dict[str, str] = {}
        for part_id, raw_text in legacy.items():
            pid = _valid_part_id(part_id)
            if not isinstance(raw_text, str) or not raw_text.strip():
                raise ValueError('Lege of ongeldige DXF in aanvraag.')
            blob_bytes = len(raw_text.encode('utf-8', errors='strict'))
            if blob_bytes > max_blob_bytes:
                raise ValueError('Een DXF-bestand is te groot voor deze aanvraag.')
            total_bytes += blob_bytes
            if total_bytes > max_total_bytes:
                raise ValueError('Totale DXF-invoer is te groot voor deze aanvraag.')
            out[pid] = raw_text
        return out

    blobs = payload.get('dxfBlobs')
    refs = payload.get('dxfPartRefs')
    if not isinstance(blobs, dict) or not isinstance(refs, dict) or not blobs or not refs:
        return {}
    if len(refs) > _env_int('PUBLIC_DXF_MAX_COUNT', 500):
        raise ValueError('Te veel DXF-referenties in aanvraag.')
    if len(blobs) > len(refs):
        raise ValueError('Ongeldige DXF-bibliotheek in aanvraag.')

    max_blob_bytes = _env_int('PUBLIC_DXF_BLOB_MAX_BYTES', 2 * 1024 * 1024)
    max_total_bytes = _env_int('PUBLIC_DXF_TOTAL_MAX_BYTES', 12 * 1024 * 1024)
    total_blob_bytes = 0
    safe_blobs: dict[str, str] = {}
    for blob_id, raw_text in blobs.items():
        bid = str(blob_id or '').strip()
        if not bid or len(bid) > 40 or not re.fullmatch(r'[A-Za-z0-9_-]+', bid):
            raise ValueError('Ongeldige DXF-referentie in aanvraag.')
        if not isinstance(raw_text, str) or not raw_text.strip():
            raise ValueError('Lege of ongeldige DXF in aanvraag.')
        blob_bytes = len(raw_text.encode('utf-8', errors='strict'))
        if blob_bytes > max_blob_bytes:
            raise ValueError('Een DXF-bestand is te groot voor deze aanvraag.')
        total_blob_bytes += blob_bytes
        if total_blob_bytes > max_total_bytes:
            raise ValueError('Totale DXF-invoer is te groot voor deze aanvraag.')
        safe_blobs[bid] = raw_text

    out: dict[str, str] = {}
    for part_id, blob_id in refs.items():
        pid = _valid_part_id(part_id)
        bid = str(blob_id or '').strip()
        if bid not in safe_blobs:
            raise ValueError('DXF-referentie verwijst naar ontbrekende geometrie.')
        out[pid] = safe_blobs[bid]
    return out


def _estimate_preflight_job_family_bytes(payload: dict) -> dict:
    try:
        panels_csv = str((payload or {}).get('panelsCsv') or '')
    except Exception:
        panels_csv = ''
    try:
        pricing_obj = (payload or {}).get('pricing')
        pricing_bytes = len(json.dumps(pricing_obj if pricing_obj is not None else {}, ensure_ascii=False).encode('utf-8'))
    except Exception:
        pricing_bytes = 0
    try:
        job_json_obj = (payload or {}).get('jobJson')
        job_json_bytes = len(json.dumps(job_json_obj if job_json_obj is not None else {}, ensure_ascii=False).encode('utf-8'))
    except Exception:
        job_json_bytes = 0
    try:
        panels_csv_bytes = len(panels_csv.encode('utf-8'))
    except Exception:
        panels_csv_bytes = 0
    try:
        rows = _parse_panels_csv(panels_csv)
    except Exception:
        rows = []
    seen_codes: set[str] = set()
    for r in rows or []:
        try:
            code = str((r or {}).get('MaterialCode') or '').strip()
        except Exception:
            code = ''
        if code:
            seen_codes.add(code)
    material_count = max(1, len(seen_codes))
    try:
        dxf_parts = _expand_dxf_payload(payload or {})
    except Exception:
        dxf_parts = {}
    dxf_count = len(dxf_parts)
    dxf_total_bytes = 0
    for _pid, dxf_text in dxf_parts.items():
        try:
            dxf_total_bytes += len(str(dxf_text).encode('utf-8'))
        except Exception:
            pass
    panel_rows = len(rows or [])
    total_qty = 0
    for r in rows or []:
        try:
            qty_raw = r.get('Qty') or r.get('qty') or r.get('quantity') or 1
            qty = int(float(qty_raw) or 0)
        except Exception:
            qty = 0
        if qty <= 0:
            qty = 1
        total_qty += qty
    total_qty = max(total_qty, panel_rows)
    # Lower-bound family input size before optimizer output: master input + all subjob inputs.
    # DXFs are copied to the master job and again to each material subjob, so this dominates
    # disk growth for extreme jobs. In practice, however, very large jobs scale mainly with the
    # effective number of produced panels (Qty totals), because each placed panel fans out into
    # more placement/report/export/zip output even when the DXF templates themselves are reused.
    # We therefore keep the DXF/input estimate but also add a conservative per-panel output floor
    # so absurd jobs (for example hundreds of repeated small parts) are stopped early.
    shared_json_bytes = pricing_bytes + job_json_bytes
    estimated_subjob_csv_total = int(panels_csv_bytes * 1.10)
    family_input_lower_bound = (dxf_total_bytes * (1 + material_count)) + (shared_json_bytes * (1 + material_count)) + panels_csv_bytes + estimated_subjob_csv_total
    per_panel_output_floor = total_qty * 262144  # 256 KB per effective panel as conservative early-stop floor
    projected_total_bytes = int(max((family_input_lower_bound * 1.22) + (dxf_count * 2048) + (panel_rows * 256), family_input_lower_bound + per_panel_output_floor + (material_count * 131072)))
    return {
        'panelRows': int(panel_rows),
        'totalQty': int(total_qty),
        'dxfCount': int(dxf_count),
        'materialCount': int(material_count),
        'panelsCsvBytes': int(panels_csv_bytes),
        'pricingBytes': int(pricing_bytes),
        'jobJsonBytes': int(job_json_bytes),
        'dxfTotalBytes': int(dxf_total_bytes),
        'familyInputLowerBoundBytes': int(family_input_lower_bound),
        'perPanelOutputFloorBytes': int(per_panel_output_floor),
        'projectedTotalBytes': int(projected_total_bytes),
    }


def _preflight_job_family_limit_message(projected_bytes: int, limit_bytes: int) -> str:
    try:
        projected_mb = float(projected_bytes) / (1024.0 * 1024.0)
    except Exception:
        projected_mb = 0.0
    try:
        limit_mb = float(limit_bytes) / (1024.0 * 1024.0)
    except Exception:
        limit_mb = 0.0
    return f"Deze job is te groot om veilig te verwerken. De geschatte jobgrootte is ongeveer {projected_mb:.1f} MB en dat overschrijdt het maximum van {limit_mb:.0f} MB. Splits de job op in meerdere delen."


def _get_payload_total_qty(payload: dict) -> int:
    try:
        panels_csv = str((payload or {}).get('panelsCsv') or '')
    except Exception:
        panels_csv = ''
    try:
        rows = _parse_panels_csv(panels_csv)
    except Exception:
        rows = []
    total_qty = 0
    for r in rows or []:
        try:
            qty_raw = r.get('Qty') or r.get('qty') or r.get('quantity') or 1
            qty = int(float(qty_raw) or 0)
        except Exception:
            qty = 0
        if qty <= 0:
            qty = 1
        total_qty += qty
    return int(max(total_qty, len(rows or [])))


def _enforce_job_total_qty_limit(payload: dict, limit_qty: int = 250) -> int:
    total_qty = _get_payload_total_qty(payload)
    if total_qty > int(limit_qty):
        raise RuntimeError('JOB_TOTAL_QTY_TOO_LARGE::%d::%d' % (total_qty, int(limit_qty)))
    return int(total_qty)


def _estimate_payload_area_lower_bound(payload: dict) -> dict:
    try:
        panels_csv = str((payload or {}).get('panelsCsv') or '')
    except Exception:
        panels_csv = ''
    try:
        pricing = (payload or {}).get('pricing') or {}
    except Exception:
        pricing = {}
    try:
        defaults = pricing.get('defaults') or {}
    except Exception:
        defaults = {}
    try:
        margin = float(defaults.get('sheetMarginMm') or 7.0)
    except Exception:
        margin = 7.0
    try:
        rows = _parse_panels_csv(panels_csv)
    except Exception:
        rows = []
    try:
        materials = pricing.get('materials') or []
    except Exception:
        materials = []
    mat_map = {}
    for m in materials if isinstance(materials, list) else []:
        try:
            code = str((m or {}).get('materialCode') or (m or {}).get('articleNumber') or '').strip()
            if code:
                mat_map[code] = m or {}
        except Exception:
            continue
    area_by_code = {}
    for r in rows or []:
        try:
            code = str(r.get('MaterialCode') or r.get('materialCode') or '').strip()
        except Exception:
            code = ''
        if not code:
            continue
        try:
            qty = int(float(r.get('Qty') or r.get('qty') or 1) or 1)
        except Exception:
            qty = 1
        if qty <= 0:
            qty = 1
        try:
            w = float(r.get('WidthMm') or r.get('widthMm') or 0.0)
            h = float(r.get('LengthMm') or r.get('lengthMm') or 0.0)
        except Exception:
            w = 0.0
            h = 0.0
        if w <= 0.0 or h <= 0.0:
            continue
        area_by_code[code] = area_by_code.get(code, 0.0) + (w * h * qty)
    by_material = []
    max_lb = 0
    for code, total_area in area_by_code.items():
        m = mat_map.get(code) or {}
        try:
            sheet = m.get('sheetSizeMm') or {}
            sheet_w = float(sheet.get('width') or m.get('sheetWid') or m.get('sheetW') or 0.0)
            sheet_h = float(sheet.get('height') or m.get('sheetLen') or m.get('sheetH') or 0.0)
        except Exception:
            sheet_w = 0.0
            sheet_h = 0.0
        usable_w = max(0.0, sheet_w - 2.0 * margin)
        usable_h = max(0.0, sheet_h - 2.0 * margin)
        usable_area = usable_w * usable_h
        area_lb = max(1, int(math.ceil((total_area / usable_area) - 1e-12))) if usable_area > 0.0 else 0
        by_material.append({'materialCode': code, 'areaLowerBound': int(area_lb), 'totalAreaMm2': float(total_area), 'usableAreaMm2': float(usable_area)})
        max_lb = max(max_lb, int(area_lb))
    return {'maxAreaLowerBound': int(max_lb), 'byMaterial': by_material}


DXF_CATEGORIES = [
    "Deuren METOD",
    "Ladefront METOD",
    "Deuren PAX",
    "Overige panelen",
]

def classify_dxf_category(filename: str) -> str:
    lower = str(filename or "").lower().strip()
    # Mirror Tool A parseMetaFromFilename() type logic
    if lower.startswith("pax"):
        return "Deuren PAX"
    if "lade" in lower and "apothekerslade" not in lower:
        return "Ladefront METOD"
    if "deur" in lower:
        return "Deuren METOD"
    return "Overige panelen"

def migrate_embedded_dxfs_to_categories():
    """One-time migration: move root-level DXFs in app/embedded_dxfs into category subfolders.
    This keeps Tool A behavior (manifest relative paths) and makes Admin categories match Tool A labels."""
    dxf_root = DXF_LIBRARY_ROOT
    dxf_root.mkdir(parents=True, exist_ok=True)

    # Ensure default categories exist
    for cat in DXF_CATEGORIES:
        (dxf_root / cat).mkdir(parents=True, exist_ok=True)

    # Move any DXF files in the root of embedded_dxfs into a category folder
    for p in sorted(dxf_root.iterdir()):
        if not p.is_file():
            continue
        if not p.name.lower().endswith(".dxf"):
            continue
        # Skip temp
        if p.name.lower().endswith(".tmp"):
            continue
        target_dir = dxf_root / classify_dxf_category(p.name)
        target = target_dir / p.name
        # If target exists, keep existing and avoid overwrite by renaming
        if target.exists():
            stem = target.stem
            suffix = target.suffix
            i = 2
            while True:
                cand = target_dir / f"{stem} ({i}){suffix}"
                if not cand.exists():
                    target = cand
                    break
                i += 1
        try:
            os.replace(p, target)
            fsync_directory(target_dir)
            fsync_directory(dxf_root)
        except Exception:
            # Best effort; if move fails, keep file in root
            pass

def get_embedded_dxfs_version():
    """Return a monotonic-ish version for embedded_dxfs tree (ms since epoch based on latest mtime).
    Used by Tool A to auto-refresh without server restart."""
    dxf_root = DXF_LIBRARY_ROOT
    latest = 0.0
    try:
        if dxf_root.exists():
            for p in dxf_root.rglob("*"):
                try:
                    st = p.stat()
                    if st.st_mtime > latest:
                        latest = st.st_mtime
                except Exception:
                    continue
    except Exception:
        pass
    try:
        man = DXF_MANIFEST_PATH
        if man.exists():
            mt = man.stat().st_mtime
            if mt > latest:
                latest = mt
    except Exception:
        pass
    return int(latest * 1000)


def rebuild_embedded_dxfs_manifest():
    """Rebuild app/embedded_dxfs_manifest.json from files inside app/embedded_dxfs.
    Includes files in root and subfolders (relative paths)."""
    dxf_root = DXF_LIBRARY_ROOT
    dxf_root.mkdir(parents=True, exist_ok=True)

    files = []
    for p in sorted(dxf_root.rglob("*")):
        if not p.is_file():
            continue
        name = p.name.lower()
        if name.endswith(".tmp"):
            continue
        if p.name == "embedded_dxfs_manifest.json":
            continue
        if not name.endswith(".dxf"):
            continue
        rel = p.relative_to(dxf_root).as_posix()
        files.append(rel)

    manifest = {"files": files, "count": len(files)}
    durable_write_json(DXF_MANIFEST_PATH, manifest)


CONFIG_DIR = STATE_ROOT / "config"
PRICING_ACTIVE = CONFIG_DIR / "pricing_active.json"
PRICING_VERSIONS = CONFIG_DIR / "pricing_versions"
PRICING_AUDIT = CONFIG_DIR / "pricing_audit.jsonl"

# --- Pricing rules (sell prices) ---
# Legacy factor is read only once for one-time migration of existing material prices.
# New calculations never apply a material factor: each material carries its own direct sell price.
LEGACY_SHEET_PRICE_FACTOR_DEFAULT = float(os.environ.get("METOD_SHEET_PRICE_FACTOR", "1.4"))
# Edge banding sell price per meter.
EDGE_BAND_PRICE_PER_M = float(os.environ.get("METOD_EDGE_BAND_PRICE_PER_M", "4.5"))
# CNC routing cost per used sheet.
CNC_COST_PER_SHEET = float(os.environ.get("METOD_CNC_COST_PER_SHEET", "85"))
# One-time drawing / setup cost per job.
DRAWING_COST_FIXED = float(os.environ.get("METOD_DRAWING_COST_FIXED", "125"))
# One-time transport cost per job.
TRANSPORT_COST_FIXED = float(os.environ.get("METOD_TRANSPORT_COST_FIXED", "54.95"))


HOST = "127.0.0.1"
PUBLIC_HOST = os.environ.get("METOD_PUBLIC_HOST", "werkplaats")
PUBLIC_BASE_URL = os.environ.get("METOD_PUBLIC_BASE_URL", f"http://{PUBLIC_HOST}:{PORT}")

JOBS.mkdir(parents=True, exist_ok=True)
DRAFTS.mkdir(parents=True, exist_ok=True)

# in-memory job status
_job_lock = threading.Lock()
_job_meta: dict[str, dict] = {}
_ACTIVE_JOB_PROCESSES_LOCK = threading.RLock()
_ACTIVE_JOB_PROCESSES: dict[str, set[subprocess.Popen]] = {}


class JobCancelledError(RuntimeError):
    pass


def _job_runtime_state_path(job_id: str) -> Path:
    root = resolve_identifier_child(JOBS, validate_job_id(job_id))
    return root / 'job_state.json'


def _load_job_runtime_state(job_id: str) -> dict:
    try:
        value = strict_json_load(_job_runtime_state_path(job_id))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _save_job_runtime_state(job_id: str, state: str, **extra: Any) -> dict:
    job_id = validate_job_id(job_id)
    previous = _load_job_runtime_state(job_id)
    value = {
        'schemaVersion': 1,
        'jobId': job_id,
        'state': str(state).upper(),
        'createdAt': previous.get('createdAt') or _utc_now_iso(),
        'updatedAt': _utc_now_iso(),
        **extra,
    }
    durable_write_json(_job_runtime_state_path(job_id), value)
    return value


def _job_cancel_requested(job_id: str) -> bool:
    return str(_load_job_runtime_state(job_id).get('state') or '').upper() in {'CANCEL_REQUESTED', 'CANCELLED'}


def _register_job_process(master_job_id: str, process: subprocess.Popen) -> None:
    with _ACTIVE_JOB_PROCESSES_LOCK:
        _ACTIVE_JOB_PROCESSES.setdefault(validate_job_id(master_job_id), set()).add(process)


def _unregister_job_process(master_job_id: str, process: subprocess.Popen) -> None:
    with _ACTIVE_JOB_PROCESSES_LOCK:
        processes = _ACTIVE_JOB_PROCESSES.get(master_job_id)
        if processes is not None:
            processes.discard(process)
            if not processes:
                _ACTIVE_JOB_PROCESSES.pop(master_job_id, None)


def _reconcile_interrupted_jobs_on_startup() -> int:
    reconciled = 0
    for path in sorted(JOBS.glob('*/job_state.json')):
        try:
            state = strict_json_load(path)
            job_id = validate_job_id(path.parent.name)
            current = str((state or {}).get('state') or '').upper()
            if current == 'CANCEL_REQUESTED':
                _save_job_runtime_state(job_id, 'CANCELLED', reason='startup-reconciliation')
                reconciled += 1
            elif current in {'ACCEPTED', 'PREPARING', 'PROCESSING', 'FINALIZING'}:
                _save_job_runtime_state(job_id, 'FAILED', reason='service-restarted-during-processing', retryable=True)
                reconciled += 1
        except Exception as exc:
            _append_system_event(
                level='error', component='jobs', message_user='Jobstate-reconciliatie mislukt',
                message_tech=str(exc), job_id=path.parent.name, status='open',
            )
    return reconciled


def _find_existing_file(base_dir: Path, candidates):
    """Return first existing path among candidates (relative to base_dir)."""
    for rel in candidates:
        p = base_dir / rel
        if p.exists():
            return p
    return None

def _find_placements_any(output_dir: Path):
    # common variants (windows may hide extension; toolb may output without)
    candidates = [Path('placements.json'), Path('placements'), Path('Placements.json'), Path('Placements')]
    p = _find_existing_file(output_dir, candidates)
    if p:
        return p
    for f in output_dir.iterdir():
        if f.is_file() and f.name.lower().startswith('placements'):
            return f
    return None

def _find_labels_any(output_dir: Path):
    candidates = [Path('labels.json'), Path('labels'), Path('Labels.json'), Path('Labels')]
    p = _find_existing_file(output_dir, candidates)
    if p:
        return p
    for f in output_dir.iterdir():
        if f.is_file() and f.name.lower().startswith('labels'):
            return f
    return None

def _now_iso() -> str:
    return time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime())


def _safe_json(data, code=200):
    body = strict_json_dumps(data).encode('utf-8')
    return body, code


def _read_json_body(handler: SimpleHTTPRequestHandler, max_bytes: Optional[int] = None) -> dict:
    return _helpers_read_json_body(handler, max_bytes=max_bytes)


def _read_json_body_limited(handler: SimpleHTTPRequestHandler, env_name: str, default_bytes: int) -> dict:
    return _helpers_read_json_body_limited(handler, env_name, default_bytes)


def _safe_job_file(job_root: Path, rel: str) -> Optional[Path]:
    return _helpers_safe_job_file(job_root, rel)


def _write_file(path: Path, text: str):
    durable_write_text(path, text)


def _write_bytes(path: Path, b: bytes):
    durable_write_bytes(path, b)


def _link_or_copy_file(src: Path, dst: Path) -> str:
    """Create dst without duplicating file bytes when the filesystem supports hardlinks."""
    src = Path(src); dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        if dst.exists() or dst.is_symlink():
            dst.unlink()
        os.link(src, dst)
        return 'hardlink'
    except Exception:
        durable_copy_file(src, dst)
        return 'copy'

# --- Atomic file utilities (avoid 0-byte / race conditions) ---
def _atomic_write_text(path: Path, text: str) -> None:
    _helpers_atomic_write_text(path, text)


def _atomic_write_json(path: Path, obj: dict) -> None:
    _helpers_atomic_write_json(path, obj)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def _safe_id(s: str, max_len: int = 80) -> str:
    raw = str(s or '').strip()
    limit = min(120, max(1, int(max_len or 80)))
    if len(raw) > limit or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', raw):
        return ''
    return raw


def _ensure_request_dirs() -> None:
    for d in [REQUESTS, QUEUE_DIR, QUEUE_PENDING, QUEUE_PROCESSING, QUEUE_DONE, QUEUE_FAILED, INDEX_DIR, SUBMISSION_IDEMPOTENCY_DIR, SYSTEM_DIR, BACKUPS_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def _ensure_archive_dirs() -> None:
    for d in [ARCHIVE_ROOT, ARCHIVE_JOBS, ARCHIVE_REQUESTS, ARCHIVE_QUEUE_DONE, ARCHIVE_QUEUE_FAILED]:
        d.mkdir(parents=True, exist_ok=True)


def _parse_iso_dt(value) -> Optional[datetime]:
    try:
        s = str(value or '').strip()
        if not s:
            return None
        if s.endswith('Z'):
            s = s[:-1] + '+00:00'
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is not None:
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
        return dt
    except Exception:
        return None


def _path_dt(path: Path) -> Optional[datetime]:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).replace(tzinfo=None)
    except Exception:
        return None


def _request_status_path(request_id: str) -> Path:
    rid = _safe_id(str(request_id or '').strip(), 120)
    return REQUESTS / rid / 'status.json'


def _request_created_dt_from_status(st: dict | None, request_root: Path | None = None) -> Optional[datetime]:
    if isinstance(st, dict):
        for k in ('createdAt', 'submittedAt', 'updatedAt'):
            dt = _parse_iso_dt(st.get(k))
            if dt is not None:
                return dt
    if request_root is not None:
        sp = Path(request_root) / 'status.json'
        if sp.exists():
            dt = _path_dt(sp)
            if dt is not None:
                return dt
        dt = _path_dt(Path(request_root))
        if dt is not None:
            return dt
    return None


def _request_archive_meta_dt(req_dir: Path) -> Optional[datetime]:
    meta_path = Path(req_dir) / ARCHIVE_META_NAME
    if meta_path.exists():
        try:
            meta = strict_json_load(meta_path)
            dt = _parse_iso_dt(meta.get('archivedAt'))
            if dt is not None:
                return dt
        except Exception:
            pass
    return _path_dt(req_dir)


def _job_created_dt(job_dir: Path) -> Optional[datetime]:
    try:
        meta = _job_meta.get(job_dir.name, {}) if isinstance(_job_meta, dict) else {}
        if isinstance(meta, dict):
            for k in ('createdAt', 'startedAt', 'updatedAt'):
                dt = _parse_iso_dt(meta.get(k))
                if dt is not None:
                    return dt
    except Exception:
        pass
    status_candidates = [job_dir / 'output' / 'meta_status.json', job_dir / 'output' / 'links.json', job_dir / 'input' / 'job.json']
    for fp in status_candidates:
        if fp.exists():
            dt = _path_dt(fp)
            if dt is not None:
                return dt
    return _path_dt(job_dir)


def _write_archive_meta(dest_dir: Path, *, kind: str, item_id: str, archived_at: datetime, active_created_at: Optional[datetime] = None) -> None:
    try:
        payload = {
            'kind': kind,
            'id': item_id,
            'archivedAt': archived_at.isoformat() + 'Z',
        }
        if active_created_at is not None:
            payload['activeCreatedAt'] = active_created_at.isoformat() + 'Z'
        _atomic_write_json(dest_dir / ARCHIVE_META_NAME, payload)
    except Exception:
        pass


def _unique_archive_dest(base_dir: Path, name: str) -> Path:
    dest = base_dir / name
    if not dest.exists():
        return dest
    stamp = time.strftime('%Y%m%d_%H%M%S')
    return base_dir / f"{name}__archived_{stamp}"


def _linked_job_ids_from_status(st: dict | None) -> list[str]:
    out = []
    if not isinstance(st, dict):
        return out
    job = st.get('job') if isinstance(st.get('job'), dict) else {}
    parent = _safe_id(str(job.get('parentJobId') or '').strip(), 200)
    if parent:
        out.append(parent)
    for sj in (job.get('subjobs') or []):
        sj_id = ''
        if isinstance(sj, dict):
            sj_id = str(sj.get('subjobId') or sj.get('jobId') or sj.get('id') or '').strip()
        else:
            sj_id = str(sj or '').strip()
        sj_id = _safe_id(sj_id, 200) if sj_id else ''
        if sj_id and sj_id not in out:
            out.append(sj_id)
    return out


def _archive_request_and_linked_jobs(request_id: str) -> dict:
    rid = _safe_id(str(request_id or '').strip(), 120)
    if not rid:
        return {'ok': False, 'error': 'missing requestId'}
    req_dir = REQUESTS / rid
    if not req_dir.exists() or not req_dir.is_dir():
        return {'ok': False, 'error': 'request missing'}
    try:
        st = _load_status(rid) or {}
    except Exception:
        st = {}
    active_created_at = _request_created_dt_from_status(st, req_dir)
    linked_jobs = _linked_job_ids_from_status(st)
    archived_at = datetime.now(timezone.utc).replace(tzinfo=None)
    _ensure_archive_dirs()
    moved_jobs = []
    errors = []
    active_references: set[str] = set()
    for other in REQUESTS.iterdir() if REQUESTS.exists() else []:
        if not other.is_dir() or other.name == rid:
            continue
        try:
            other_status = _load_status(other.name)
            active_references.update(_linked_job_ids_from_status(other_status))
        except Exception:
            continue
    for jid in linked_jobs:
        if jid in active_references:
            continue
        src = JOBS / jid
        if not src.exists() or not src.is_dir():
            continue
        dest = _unique_archive_dest(ARCHIVE_JOBS, jid)
        try:
            os.replace(src, dest)
            fsync_directory(dest.parent)
            fsync_directory(src.parent)
            _write_archive_meta(dest, kind='job', item_id=jid, archived_at=archived_at, active_created_at=active_created_at)
            moved_jobs.append(dest.name)
        except Exception as e:
            errors.append(f'job:{jid}:{e}')
    req_dest = _unique_archive_dest(ARCHIVE_REQUESTS, rid)
    try:
        os.replace(req_dir, req_dest)
        fsync_directory(req_dest.parent)
        fsync_directory(req_dir.parent)
        _write_archive_meta(req_dest, kind='request', item_id=rid, archived_at=archived_at, active_created_at=active_created_at)
    except Exception as e:
        return {'ok': False, 'error': f'request move failed: {e}', 'movedJobs': moved_jobs, 'errors': errors}

    # Queue item mirrors are optional; move only completed/failed queue items, never pending/processing.
    for src_dir, arc_dir in ((QUEUE_DONE, ARCHIVE_QUEUE_DONE), (QUEUE_FAILED, ARCHIVE_QUEUE_FAILED)):
        try:
            src = src_dir / f'{rid}.json'
            if src.exists() and src.is_file():
                destination = _unique_archive_dest(arc_dir, src.name)
                os.replace(src, destination)
                fsync_directory(destination.parent)
                fsync_directory(src.parent)
        except Exception:
            pass

    return {'ok': True, 'requestId': rid, 'archivedRequestDir': req_dest.name, 'movedJobs': moved_jobs, 'errors': errors}


def _purge_old_archives(now_dt: Optional[datetime] = None) -> dict:
    _ensure_archive_dirs()
    now_dt = now_dt or datetime.now(timezone.utc).replace(tzinfo=None)
    purged = {'requests': 0, 'jobs': 0, 'queue_done': 0, 'queue_failed': 0}

    def _purge_dir(base: Path, key: str):
        if not base.exists():
            return
        for child in sorted(base.iterdir()):
            if not child.exists():
                continue
            dt = _request_archive_meta_dt(child) if child.is_dir() else _path_dt(child)
            if dt is None:
                continue
            if now_dt - dt < timedelta(days=RETENTION_ARCHIVE_DAYS):
                continue
            try:
                if child.is_dir():
                    shutil.rmtree(child, ignore_errors=False)
                else:
                    child.unlink(missing_ok=True)
                fsync_directory(base)
                purged[key] += 1
            except Exception:
                continue

    _purge_dir(ARCHIVE_REQUESTS, 'requests')
    _purge_dir(ARCHIVE_JOBS, 'jobs')
    _purge_dir(ARCHIVE_QUEUE_DONE, 'queue_done')
    _purge_dir(ARCHIVE_QUEUE_FAILED, 'queue_failed')
    return purged


def _archive_expired_active_data(now_dt: Optional[datetime] = None) -> dict:
    _ensure_request_dirs()
    _ensure_archive_dirs()
    now_dt = now_dt or datetime.now(timezone.utc).replace(tzinfo=None)
    archived = {'requests': 0, 'orphanJobsDeleted': 0, 'errors': []}
    processed_job_ids = set()

    # First archive submitted requests as the leading contract; this pulls linked parent/subjobs with it.
    for req_dir in sorted(REQUESTS.iterdir()):
        if not req_dir.is_dir():
            continue
        rid = req_dir.name
        st = _load_status(rid) or {}
        created_dt = _request_created_dt_from_status(st, req_dir)
        if created_dt is None or (now_dt - created_dt) < timedelta(days=RETENTION_ACTIVE_DAYS):
            continue
        for jid in _linked_job_ids_from_status(st):
            processed_job_ids.add(jid)
        res = _archive_request_and_linked_jobs(rid)
        if res.get('ok'):
            archived['requests'] += 1
            for jid in (res.get('movedJobs') or []):
                processed_job_ids.add(str(jid))
        else:
            archived['errors'].append({'requestId': rid, 'error': res.get('error') or 'archive failed'})

    # Then delete orphan jobs with no request mapping after a much shorter retention window.
    for job_dir in sorted(JOBS.iterdir()):
        if not job_dir.is_dir():
            continue
        jid = job_dir.name
        if jid in processed_job_ids:
            continue
        if _find_request_status_for_job(jid):
            continue
        created_dt = _job_created_dt(job_dir)
        if created_dt is None or (now_dt - created_dt) < timedelta(days=ORPHAN_JOB_RETENTION_DAYS):
            continue
        try:
            shutil.rmtree(job_dir, ignore_errors=False)
            fsync_directory(JOBS)
            archived['orphanJobsDeleted'] += 1
        except Exception as e:
            archived['errors'].append({'jobId': jid, 'error': str(e)})
    return archived


def run_retention_maintenance(force: bool = False) -> dict:
    global _LAST_RETENTION_RUN_TS
    if _state_snapshot_is_active():
        return {'ok': True, 'skipped': True, 'reason': 'state-snapshot'}
    now_ts = time.time()
    if (not force) and _LAST_RETENTION_RUN_TS and (now_ts - _LAST_RETENTION_RUN_TS) < _RETENTION_MIN_INTERVAL_SECONDS:
        return {'ok': True, 'skipped': True, 'reason': 'interval'}
    _LAST_RETENTION_RUN_TS = now_ts
    now_dt = datetime.now(timezone.utc).replace(tzinfo=None)
    archived = _archive_expired_active_data(now_dt)
    purged = _purge_old_archives(now_dt)
    return {'ok': True, 'archived': archived, 'purged': purged, 'ranAt': now_dt.isoformat() + 'Z'}



def _move_queue_file_safe(src: Path, dest_dir: Path) -> Path:
    source_parent = Path(src).parent
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / src.name
    if dest.exists():
        stamp = time.strftime('%Y%m%d_%H%M%S')
        dest = dest_dir / f"{src.stem}__{stamp}{src.suffix}"
    os.replace(str(src), str(dest))
    fsync_directory(dest_dir)
    if source_parent.resolve() != dest_dir.resolve():
        fsync_directory(source_parent)
    return dest


def _mark_request_failed_if_stale(request_id: str, *, code: str, message: str) -> None:
    status = _load_status(request_id) or {}
    if status.get('internalStatus') in {'DONE', 'FAILED', 'CANCELLED'}:
        return
    status['internalStatus'] = 'FAILED'
    status['internalStatusLabel'] = 'Fout'
    status['error'] = {'code': code, 'message': message}
    _save_status(request_id, status)


def run_queue_maintenance(force: bool = False) -> dict:
    global _LAST_QUEUE_MAINTENANCE_TS
    if _state_snapshot_is_active():
        return {'ok': True, 'skipped': True, 'reason': 'state-snapshot'}
    now_ts = time.time()
    if (not force) and _LAST_QUEUE_MAINTENANCE_TS and (now_ts - _LAST_QUEUE_MAINTENANCE_TS) < _QUEUE_MAINTENANCE_MIN_INTERVAL_SECONDS:
        return {'ok': True, 'skipped': True, 'reason': 'interval'}
    _LAST_QUEUE_MAINTENANCE_TS = now_ts
    now_dt = datetime.now(timezone.utc).replace(tzinfo=None)
    result = {'ok': True, 'pendingFailed': 0, 'processingFailed': 0, 'errors': [], 'ranAt': now_dt.isoformat() + 'Z'}

    def _handle_stale(path: Path, *, age_delta: timedelta, bucket: str, code: str, message: str) -> None:
        try:
            mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).replace(tzinfo=None)
        except Exception as e:
            result['errors'].append({'file': path.name, 'error': str(e)})
            return
        if now_dt - mtime < age_delta:
            return
        request_id = ''
        try:
            payload = strict_json_load(path)
            request_id = _safe_id((payload or {}).get('requestId') or '', 120)
        except Exception:
            payload = None
        try:
            if request_id:
                _mark_request_failed_if_stale(request_id, code=code, message=message)
            _move_queue_file_safe(path, QUEUE_FAILED)
            result[bucket] += 1
            _append_system_event(level='warning', component='jobs', message_user='Een verouderd queue-item is automatisch afgehandeld', message_tech=f'{path.name} marked stale in {path.parent.name}', request_id=request_id or None, status='open')
        except Exception as e:
            result['errors'].append({'file': path.name, 'error': str(e)})

    for path in sorted(QUEUE_PENDING.glob('*.json')):
        _handle_stale(path, age_delta=timedelta(days=STALE_PENDING_QUEUE_DAYS), bucket='pendingFailed', code='STALE_PENDING_QUEUE_ITEM', message='Aanvraag te lang in wachtrij gebleven en automatisch als fout gemarkeerd.')
    for path in sorted(QUEUE_PROCESSING.glob('*.json')):
        _handle_stale(path, age_delta=timedelta(hours=STALE_PROCESSING_QUEUE_HOURS), bucket='processingFailed', code='STALE_PROCESSING_QUEUE_ITEM', message='Aanvraag bleef te lang in verwerking hangen en is automatisch als fout gemarkeerd.')
    return result


def _server_maintenance_loop(interval_seconds: float = _SERVER_MAINTENANCE_LOOP_SECONDS) -> None:
    while True:
        try:
            run_retention_maintenance(force=False)
        except Exception:
            pass
        try:
            run_backup_maintenance(force=False)
        except Exception:
            pass
        try:
            run_queue_maintenance(force=False)
        except Exception:
            pass
        time.sleep(interval_seconds)


def _append_jsonl(path: Path, obj: dict) -> None:
    append_jsonl_rotating(path, obj, max_bytes=_env_int('JSONL_MAX_BYTES', 20 * 1024 * 1024), backups=5)


def _new_request_id() -> str:
    # Deterministic-ish and readable: timestamp + short random
    return time.strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]


def _load_status(request_id: str) -> Optional[dict]:
    try:
        request_id = validate_request_id(request_id)
        sp = resolve_identifier_child(REQUESTS, request_id, kind='request') / 'status.json'
        data = strict_json_load(sp)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _save_status(request_id: str, status: dict) -> None:
    request_id = validate_request_id(request_id)
    request_root = resolve_identifier_child(REQUESTS, request_id, kind='request')
    status["updatedAt"] = _utc_now_iso()
    durable_write_json(request_root / 'status.json', status)
    # Update index (append-only; Admin can read tail for speed)
    idx_row = {
        "ts": status.get("updatedAt"),
        "requestId": request_id,
        "publicStatus": status.get("publicStatus"),
        "internalStatus": status.get("internalStatus"),
        "quoteStatus": status.get("quoteStatus"),
        "needsQuote": bool(status.get("needsQuote")),
        "customerName": (status.get("customer") or {}).get("name") if isinstance(status.get("customer"), dict) else None,
    }
    job = status.get("job") if isinstance(status.get("job"), dict) else {}
    idx_row["parentJobId"] = job.get("parentJobId")
    _append_jsonl(REQUESTS_INDEX, idx_row)


def _linked_subjob_ids(parent_job_id: str) -> list[str]:
    """Return private material subjob ids from the finalized parent job only."""
    try:
        parent = validate_job_id(parent_job_id)
        parent_root = resolve_identifier_child(JOBS, parent)
    except SafetyContractError:
        return []
    out: list[str] = []
    try:
        links_path = parent_root / 'output' / 'links.json'
        if links_path.exists():
            links = strict_json_load(links_path)
            raw = links.get('subjobs') if isinstance(links, dict) else []
            if isinstance(raw, list):
                for item in raw:
                    if isinstance(item, dict):
                        value = item.get('jobId') or item.get('subjobId') or item.get('id')
                    else:
                        value = item
                    try:
                        sj = validate_job_id(value)
                        resolve_identifier_child(JOBS, sj)
                    except SafetyContractError:
                        continue
                    if sj not in out:
                        out.append(sj)
    except Exception:
        return []
    return out


def _submission_marker_path(parent_job_id: str) -> Path:
    key = hashlib.sha256(str(parent_job_id or '').encode('utf-8')).hexdigest()
    return SUBMISSION_IDEMPOTENCY_DIR / f'{key}.json'


def _read_submission_claim(parent_job_id: str) -> str:
    """Return an existing final-submit request for this parent, if any.

    The marker is cross-process safe. A stale marker without a request can be reclaimed
    after five minutes, covering a crash between reservation and status persistence.
    """
    try:
        parent = validate_job_id(parent_job_id)
    except SafetyContractError:
        return ''
    marker = _submission_marker_path(parent)
    try:
        if marker.exists():
            obj = strict_json_load(marker)
            try:
                rid = validate_request_id(obj.get('requestId'))
            except SafetyContractError:
                rid = ''
            if rid and (REQUESTS / rid / 'status.json').exists():
                return rid
            try:
                if (time.time() - marker.stat().st_mtime) > 300:
                    marker.unlink(missing_ok=True)
                    fsync_directory(marker.parent)
            except Exception:
                pass
    except Exception:
        pass
    return ''


def _reserve_submission_claim(parent_job_id: str, request_id: str) -> tuple[bool, str]:
    """Atomically reserve one final submission per finalized optimization parent."""
    try:
        parent = validate_job_id(parent_job_id)
        rid = validate_request_id(request_id)
    except SafetyContractError:
        return False, ''
    SUBMISSION_IDEMPOTENCY_DIR.mkdir(parents=True, exist_ok=True)
    marker = _submission_marker_path(parent)
    existing = _read_submission_claim(parent)
    if existing:
        return False, existing
    data = {
        'schemaVersion': 1,
        'parentJobId': parent,
        'requestId': rid,
        'createdAt': _utc_now_iso(),
    }
    try:
        if not durable_create_json_exclusive(marker, data, mode=0o600):
            raise FileExistsError(str(marker))
        return True, rid
    except FileExistsError:
        existing = _read_submission_claim(parent)
        if existing:
            return False, existing
        # Another request can be between reservation and status write. Read the marker
        # once and return its id so a duplicate click cannot create a second request.
        try:
            obj = strict_json_load(marker)
            return False, validate_request_id(obj.get('requestId'))
        except Exception:
            return False, ''


def _submission_response_for_existing(request_id: str, parent_job_id: str) -> dict:
    status = _load_status(request_id) or {}
    cc = status.get('cancelControl') if isinstance(status.get('cancelControl'), dict) else {}
    candidates = [str(parent_job_id or '').strip()] + _linked_subjob_ids(parent_job_id)
    pricing = _extract_strict_calculation_pricing_summary([x for x in candidates if x]) or {}
    return {
        'ok': True,
        'duplicate': True,
        'requestId': request_id,
        'cancelToken': str(cc.get('cancelToken') or ''),
        'createdAt': status.get('createdAt'),
        'pricingSummary': pricing,
    }






# --- Pricing config (Option B: versioned active pricing) ---
def _default_pricing_config() -> dict:
    base = strict_json_load(PRICING_SEED_PATH)
    return {
        "pricing": base,
        "pricingModel": "catalog_sell_price_incl_vat_v2",
        "sellPricing": {
            "edgeBandPricePerM": EDGE_BAND_PRICE_PER_M,
            "cncCostPerSheet": 0.0,
            "drawingCostFixed": 0.0,
            "transportCostFixed": 0.0,
        },
    }

def _normalize_pricing_config_schema(cfg: dict) -> dict:
    """Normalize legacy pricing config without reintroducing a material factor."""
    if not isinstance(cfg, dict):
        cfg = _default_pricing_config()
    out = strict_json_loads(strict_json_dumps(cfg))
    if not isinstance(out.get('pricing'), dict):
        out['pricing'] = _default_pricing_config()['pricing']
    sp = out.get('sellPricing') if isinstance(out.get('sellPricing'), dict) else {}
    # sheetPriceFactor is deliberately removed from the active model. Existing material
    # values are migrated once to fixed per-material sell prices before the server starts.
    sp.pop('sheetPriceFactor', None)
    for key, default in (
        ('edgeBandPricePerM', EDGE_BAND_PRICE_PER_M),
        ('cncCostPerSheet', 0.0),
        ('drawingCostFixed', 0.0),
        ('transportCostFixed', 0.0),
    ):
        try:
            sp[key] = float(sp.get(key, default))
        except Exception:
            sp[key] = float(default)
    out['sellPricing'] = sp
    out['pricingModel'] = 'catalog_sell_price_incl_vat_v2'
    return out


def _load_pricing_config() -> dict:
    try:
        _ensure_pricing_config_files()
        if PRICING_ACTIVE.exists():
            return _normalize_pricing_config_schema(strict_json_load(PRICING_ACTIVE))
    except Exception:
        pass
    return _default_pricing_config()

def _ensure_pricing_config_files():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    PRICING_VERSIONS.mkdir(parents=True, exist_ok=True)
    if not PRICING_ACTIVE.exists():
        durable_write_json(PRICING_ACTIVE, _default_pricing_config(), mode=0o640)

def _save_pricing_config(new_cfg: dict, actor: str = "admin") -> dict:
    _ensure_pricing_config_files()
    if not isinstance(new_cfg, dict):
        raise ValueError("pricing config must be an object")
    if "pricing" not in new_cfg or not isinstance(new_cfg["pricing"], dict):
        raise ValueError("missing or invalid 'pricing' object")
    if "sellPricing" not in new_cfg or not isinstance(new_cfg["sellPricing"], dict):
        raise ValueError("missing or invalid 'sellPricing' object")

    cfg = _normalize_pricing_config_schema(new_cfg)
    sp = cfg['sellPricing']
    required = ["edgeBandPricePerM", "cncCostPerSheet", "drawingCostFixed", "transportCostFixed"]
    for k in required:
        try:
            sp[k] = float(sp[k])
        except Exception:
            raise ValueError(f"sellPricing '{k}' must be a number")
        if sp[k] < 0:
            raise ValueError(f"sellPricing '{k}' cannot be negative")

    with _PRICING_CONFIG_LOCK:
        ts = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
        version_path = PRICING_VERSIONS / f"{ts}_{secrets.token_hex(3)}.json"
        rec = {"ts": _utc_now_iso(), "actor": str(actor or 'unknown'), "version": version_path.name, "pricingModel": "catalog_sell_price_incl_vat_v2"}
        audit_limit = _env_int('PRICING_AUDIT_MAX_BYTES', 20 * 1024 * 1024)
        durable_write_json(version_path, cfg, mode=0o640)
        durable_write_json(PRICING_ACTIVE, cfg, mode=0o640)
        append_jsonl_rotating(PRICING_AUDIT, rec, max_bytes=audit_limit, backups=10)
    return {"ok": True, "version": version_path.name, "pricingModel": "catalog_sell_price_incl_vat_v2"}

def _migrate_legacy_materials_to_direct_sell_prices() -> dict:
    """Idempotently freeze legacy factor-based prices into per-material direct prices.

    This protects the live price level during the transition before the first website CSV
    is published. Prefer the historical retailPriceWithoutTax when available; otherwise
    use the previous active factor exactly once. New calculations never use the factor.
    """
    result = {'ok': True, 'updated': 0, 'factorUsedForFallback': None}
    try:
        raw_cfg = {}
        if PRICING_ACTIVE.exists():
            try:
                raw_cfg = strict_json_load(PRICING_ACTIVE)
            except Exception:
                raw_cfg = {}
        try:
            old_factor = float(((raw_cfg.get('sellPricing') or {}).get('sheetPriceFactor')) or LEGACY_SHEET_PRICE_FACTOR_DEFAULT)
        except Exception:
            old_factor = LEGACY_SHEET_PRICE_FACTOR_DEFAULT
        if old_factor <= 0:
            old_factor = LEGACY_SHEET_PRICE_FACTOR_DEFAULT
        result['factorUsedForFallback'] = old_factor

        if MATERIAL_LIBRARY_PATH.exists():
            lib = strict_json_load(MATERIAL_LIBRARY_PATH)
            if isinstance(lib, list):
                lib = {'source': 'legacy', 'records': lib}
            recs = lib.get('records') if isinstance(lib, dict) else None
            changed = False
            if isinstance(recs, list):
                for rec in recs:
                    if not isinstance(rec, dict):
                        continue
                    try: incl = float(rec.get('sellPriceInclVatPerSheet') or 0.0)
                    except Exception: incl = 0.0
                    try: ex = float(rec.get('sellPriceExVatPerSheet') or 0.0)
                    except Exception: ex = 0.0
                    if incl > 0 and ex <= 0:
                        rec['sellPriceExVatPerSheet'] = round(incl / (1.0 + CATALOG_VAT_RATE), 6)
                        changed = True; result['updated'] += 1
                    elif ex > 0 and incl <= 0:
                        rec['sellPriceInclVatPerSheet'] = round(ex * (1.0 + CATALOG_VAT_RATE), 2)
                        changed = True; result['updated'] += 1
                    elif incl <= 0 and ex <= 0:
                        legacy_ex = 0.0
                        try:
                            legacy_ex = float(rec.get('retailPriceWithoutTax') or 0.0)
                        except Exception:
                            legacy_ex = 0.0
                        source = 'LEGACY_RETAIL_PRICE_FROZEN'
                        if legacy_ex <= 0:
                            for key in ('purchasePrice', 'inkoopprijs', 'purchasePricePerSheet'):
                                try: purchase = float(rec.get(key) or 0.0)
                                except Exception: purchase = 0.0
                                if purchase > 0:
                                    legacy_ex = purchase * old_factor
                                    source = 'LEGACY_FACTOR_PRICE_FROZEN'
                                    break
                        if legacy_ex > 0:
                            rec['sellPriceExVatPerSheet'] = round(legacy_ex, 6)
                            rec['sellPriceInclVatPerSheet'] = round(legacy_ex * (1.0 + CATALOG_VAT_RATE), 2)
                            rec['priceVatRate'] = CATALOG_VAT_RATE
                            rec['priceSource'] = source
                            changed = True; result['updated'] += 1
                    if not rec.get('sourceKind'):
                        rec['sourceKind'] = 'LEGACY_LIBRARY'
                        changed = True
                if changed:
                    durable_write_json(MATERIAL_LIBRARY_PATH, lib, mode=0o640)

        normalized = _normalize_pricing_config_schema(raw_cfg if isinstance(raw_cfg, dict) and raw_cfg else _default_pricing_config())
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        durable_write_json(PRICING_ACTIVE, normalized, mode=0o640)
        marker = SYSTEM_DIR / 'catalog_direct_pricing_migration_v1.json'
        marker.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(marker, {'ranAt': _utc_now_iso(), **result})
    except Exception as e:
        result = {'ok': False, 'updated': result.get('updated', 0), 'error': str(e)}
    return result

def _material_direct_sell_incl_vat(rec: dict) -> float:
    """Return the authoritative direct CSV sell price per sheet INCLUDING VAT.

    FIX657 price truth: the website CSV column is explicitly ``Prijs per plaat inclusief
    BTW``.  That gross amount is the business truth and must never be reinterpreted as an
    ex-VAT sheet price.  A legacy ex-VAT field is accepted only as a migration fallback.
    """
    if not isinstance(rec, dict):
        return 0.0
    for key in ('sellPriceInclVatPerSheet', 'salePriceInclVatPerSheet', 'directSellPriceInclVatPerSheet'):
        try:
            value = float(rec.get(key) or 0.0)
            if value > 0:
                return round(value, 2)
        except Exception:
            pass
    for key in ('sellPriceExVatPerSheet', 'salePriceExVatPerSheet', 'directSellPriceExVatPerSheet'):
        try:
            value = float(rec.get(key) or 0.0)
            if value > 0:
                return round(value * (1.0 + CATALOG_VAT_RATE), 2)
        except Exception:
            pass
    return 0.0

def _material_direct_sell_ex_vat(rec: dict) -> float:
    """Return the accounting ex-VAT equivalent of the authoritative gross sheet price."""
    incl = _material_direct_sell_incl_vat(rec)
    return (incl / (1.0 + CATALOG_VAT_RATE)) if incl > 0 else 0.0


def _ensure_pricing_materials(pricing: dict, panels_csv: str) -> dict:
    """Build Tool B compatibility material pricing from the internal catalog.

    The CSV gross (incl-VAT) sheet price is authoritative. Tool B still expects a legacy
    field named purchasePricePerSheet, so it receives only the accounting ex-VAT equivalent
    for its internal arithmetic while the exact gross CSV cents travel alongside it. No sheet
    factor is used anywhere. Missing/invalid catalog prices are blocking errors.
    """
    if not isinstance(pricing, dict):
        raise SafetyContractError('Live pricing config is invalid')
    defaults = pricing.get('defaults')
    if not isinstance(defaults, dict):
        raise SafetyContractError('Live pricing defaults are missing')
    finite_number(defaults.get('sheetMarginMm'), field='pricing.defaults.sheetMarginMm', minimum=0.0, maximum=100.0)
    finite_number(defaults.get('nestingGapMm'), field='pricing.defaults.nestingGapMm', minimum=0.0, maximum=100.0)
    finite_number(defaults.get('kerfMm'), field='pricing.defaults.kerfMm', minimum=0.0, maximum=100.0)
    edge_cfg = pricing.get('edgeBanding')
    if not isinstance(edge_cfg, dict):
        raise SafetyContractError('Live edgeBanding config is missing')
    finite_number(edge_cfg.get('defaultLossPercent'), field='edgeBanding.defaultLossPercent', minimum=0.0, maximum=100.0)

    rows = _parse_panels_csv(panels_csv)
    codes = []
    seen = set()
    for r in rows:
        c = str(r.get('MaterialCode') or '').strip()
        if c and c not in seen:
            seen.add(c); codes.append(c)
    if not codes:
        raise ValueError('Geen materiaal gevonden in de paneellijst.')

    lib = strict_json_load(MATERIAL_LIBRARY_PATH)
    recs = lib.get('records', []) if isinstance(lib, dict) else []
    by_code = {}
    for rr in recs:
        if not isinstance(rr, dict):
            continue
        code = str(rr.get('articleNo') or rr.get('articleNumber') or rr.get('materialCode') or '').strip()
        if code:
            by_code[code] = rr

    def norm_decor(rec: dict, fallback: str) -> str:
        prod = str(rec.get('productName') or rec.get('publicName') or '').strip()
        if prod:
            return prod
        dn = str(rec.get('decorName') or '').strip()
        if dn and not re.fullmatch(r"[0-9]+(\.[0-9]+)?", dn):
            return dn
        return fallback

    def from_catalog(code: str) -> dict:
        rec = by_code.get(code)
        if not isinstance(rec, dict):
            raise ValueError(f'Materiaal {code} bestaat niet meer in de actieve Decor Library.')
        if str(rec.get('sourceKind') or '').upper() != 'CATALOG_IMPORT' or rec.get('catalogMissing') is True:
            raise ValueError(f'Materiaal {code} komt niet uit de actieve gepubliceerde CSV-catalogus.')
        if rec.get('active') is False or rec.get('archived') is True or rec.get('published') is False or rec.get('catalogExcluded') is True:
            raise ValueError(f'Materiaal {code} is niet beschikbaar voor nieuwe aanvragen.')
        try: t = float(rec.get('thicknessMm') or 0.0)
        except Exception: t = 0.0
        if not any(abs(t - float(x)) < 1e-9 for x in CATALOG_ALLOWED_THICKNESSES_MM):
            raise ValueError(f'Materiaal {code} heeft geen toegestane plaatdikte.')
        try: w = int(float(rec.get('sheetWid') or rec.get('sheetWidthMm') or 0))
        except Exception: w = 0
        try: h = int(float(rec.get('sheetLen') or rec.get('sheetHeightMm') or rec.get('height') or 0))
        except Exception: h = 0
        if w <= 0 or h <= 0:
            raise ValueError(f'Materiaal {code} heeft geen geldige plaatmaat.')
        sell_inc = _material_direct_sell_incl_vat(rec)
        if sell_inc <= 0:
            raise ValueError(f'Geen geldige directe verkoopprijs incl. BTW voor materiaal {code}.')
        # Tool B still has an old field name and performs arithmetic on an ex-VAT basis.
        # Feed it the accounting equivalent, but carry the exact CSV gross price alongside
        # it so every authoritative customer/Admin surface can preserve the original cents.
        sell_ex = float(sell_inc) / (1.0 + CATALOG_VAT_RATE)
        return {
            'materialCode': code,
            'decorName': norm_decor(rec, code),
            'thicknessMm': t,
            'sheetSizeMm': {'width': w, 'height': h},
            'purchasePricePerSheet': float(sell_ex),  # Tool B compatibility only
            'sellPriceExVatPerSheet': float(sell_ex),
            'sellPriceInclVatPerSheet': round(float(sell_inc), 2),
            'priceVatRate': CATALOG_VAT_RATE,
            'materialPriceBasis': 'CSV_SELL_PRICE_INCL_VAT',
            'pricingSource': str(rec.get('priceSource') or 'CSV_SALE_PRICE_INCL_VAT'),
        }

    # Always rebuild only the materials used by this job from the live catalog. This
    # avoids stale request/browser pricing and makes Admin CSV publication authoritative.
    pricing['materials'] = [from_catalog(code) for code in codes]
    by_material = {str(item['materialCode']): item for item in pricing['materials']}
    for row in rows:
        code = str(row.get('MaterialCode') or '').strip()
        authoritative = by_material.get(code)
        if not authoritative:
            raise SafetyContractError(f'{row.get("PartId")}: materiaal ontbreekt in serverpricing')
        row_thickness = finite_number(row.get('ThicknessMm'), field=f'{row.get("PartId")}.ThicknessMm', minimum=0.1, maximum=100.0)
        if abs(row_thickness - float(authoritative['thicknessMm'])) > 1e-9:
            raise SafetyContractError(f'{row.get("PartId")}: dikte wijkt af van servercatalogus')
    pricing['currency'] = 'EUR'
    pricing['units'] = 'mm'
    pricing['pricingModel'] = 'catalog_sell_price_incl_vat_v2'
    return pricing


def _apply_sell_pricing_to_quote(quote: dict) -> dict:
    """Apply the mixed VAT contract without changing the business price.

    - Sheet material: the CSV amount is already a SELL price INCLUDING 21% VAT and its
      exact cents are authoritative.
    - Edge banding, CNC, drawing and transport: Admin values remain EXCLUDING VAT.
    - No general material factor exists.

    Tool B still calculates with an ex-VAT compatibility field, but this postprocessor
    makes the gross material truth explicit and publishes an authoritative incl-VAT total.
    """
    if not isinstance(quote, dict):
        return quote
    q = json.loads(json.dumps(quote))
    q.setdefault('sellPricing', {})
    cfg = _load_pricing_config()
    sp = cfg.get('sellPricing') if isinstance(cfg, dict) and isinstance(cfg.get('sellPricing'), dict) else {}
    edge_band_price_per_m = float(sp.get('edgeBandPricePerM', EDGE_BAND_PRICE_PER_M))
    cnc_cost_per_sheet = float(sp.get('cncCostPerSheet', CNC_COST_PER_SHEET))
    drawing_cost_fixed = float(sp.get('drawingCostFixed', DRAWING_COST_FIXED))
    transport_cost_fixed = float(sp.get('transportCostFixed', TRANSPORT_COST_FIXED))
    q['sellPricing'].update({
        'pricingModel': 'catalog_sell_price_incl_vat_v2',
        'materialPriceBasis': 'CSV_SELL_PRICE_INCL_VAT',
        'materialVatRate': CATALOG_VAT_RATE,
        'otherCostsPriceBasis': 'ADMIN_EX_VAT',
        'edgeBandPricePerM': edge_band_price_per_m,
        'cncCostPerSheet': cnc_cost_per_sheet,
        'drawingCostFixed': drawing_cost_fixed,
        'transportCostFixed': transport_cost_fixed,
    })
    q['sellPricing'].pop('sheetPriceFactor', None)

    if 'totalsRaw' not in q and isinstance(q.get('totals'), dict):
        q['totalsRaw'] = dict(q['totals'])

    mats = q.get('materials') if isinstance(q.get('materials'), list) else []
    total_sheets = 0
    sheet_sell_total_ex = 0.0
    sheet_sell_total_inc = 0.0
    for m in mats:
        if not isinstance(m, dict):
            continue
        sc = int(m.get('sheetCount') or 0)
        total_sheets += sc

        unit_inc = m.get('sellPriceInclVatPerSheet')
        unit_ex = m.get('sellPriceExVatPerSheet')
        raw_unit = m.get('sheetUnitCost')
        if unit_ex is None:
            unit_ex = raw_unit
        try:
            unit_inc = float(unit_inc) if unit_inc is not None else 0.0
        except Exception:
            unit_inc = 0.0
        try:
            unit_ex = float(unit_ex) if unit_ex is not None else 0.0
        except Exception:
            unit_ex = 0.0
        if unit_inc <= 0 and unit_ex > 0:
            unit_inc = round(unit_ex * (1.0 + CATALOG_VAT_RATE), 2)
        if unit_ex <= 0 and unit_inc > 0:
            unit_ex = unit_inc / (1.0 + CATALOG_VAT_RATE)

        # Preserve website cents exactly. The accounting net equivalent is derived from
        # the full gross material subtotal so VAT rounding cannot alter the CSV amount.
        unit_inc = round(unit_inc, 2) if unit_inc > 0 else 0.0
        gross_total = round(unit_inc * sc + 1e-9, 2)
        net_total = round(gross_total / (1.0 + CATALOG_VAT_RATE) + 1e-9, 2) if gross_total > 0 else 0.0

        m['sheetUnitCostRaw'] = raw_unit
        m['sheetUnitCost'] = unit_ex  # legacy ex-VAT compatibility field
        m['sellPriceExVatPerSheet'] = unit_ex
        m['sellPriceInclVatPerSheet'] = unit_inc
        m['materialPriceBasis'] = 'CSV_SELL_PRICE_INCL_VAT'
        m['sheetCostTotalRaw'] = m.get('sheetCostTotal')
        m['sheetCostTotal'] = net_total  # legacy/ex-VAT compatibility
        m['sheetCostTotalExVat'] = net_total
        m['sheetCostTotalInclVat'] = gross_total
        sheet_sell_total_ex += net_total
        sheet_sell_total_inc += gross_total

    edge = q.get('edgeBanding') if isinstance(q.get('edgeBanding'), dict) else {}
    bwl = edge.get('byCodeMetersWithLoss') if isinstance(edge.get('byCodeMetersWithLoss'), dict) else {}
    try:
        meters_with_loss = sum(float(v or 0.0) for v in bwl.values())
    except Exception:
        meters_with_loss = 0.0
    edge_sell_total = round(meters_with_loss * edge_band_price_per_m + 1e-9, 2)
    if edge:
        edge.setdefault('sell', {})
        edge['sell'].update({
            'priceBasis': 'ADMIN_EX_VAT',
            'pricePerM': edge_band_price_per_m,
            'metersWithLossTotal': meters_with_loss,
            'edgeCostTotalRaw': edge.get('edgeCostTotal'),
        })
        by_code_cost = {}
        for code, mtrs in bwl.items():
            try:
                by_code_cost[str(code)] = round(float(mtrs or 0.0) * edge_band_price_per_m + 1e-9, 2)
            except Exception:
                by_code_cost[str(code)] = 0.0
        edge['byCodeCostRaw'] = edge.get('byCodeCost')
        edge['byCodeCost'] = by_code_cost
        edge['edgeCostTotalRaw'] = edge.get('edgeCostTotal')
        edge['edgeCostTotal'] = edge_sell_total

    cnc_total = round(total_sheets * cnc_cost_per_sheet + 1e-9, 2)
    drawing_total = round(drawing_cost_fixed + 1e-9, 2)
    transport_total = round(transport_cost_fixed + 1e-9, 2)
    q['extraCosts'] = {
        'priceBasis': 'ADMIN_EX_VAT',
        'sheetCount': total_sheets,
        'cncCostPerSheet': cnc_cost_per_sheet,
        'cncCostTotal': cnc_total,
        'drawingCostFixed': drawing_cost_fixed,
        'drawingCostTotal': drawing_total,
        'transportCostFixed': transport_cost_fixed,
        'transportCostTotal': transport_total,
    }

    other_ex = round(edge_sell_total + cnc_total + drawing_total + transport_total + 1e-9, 2)
    material_ex = round(sheet_sell_total_ex + 1e-9, 2)
    material_inc = round(sheet_sell_total_inc + 1e-9, 2)
    subtotal_ex = round(material_ex + other_ex + 1e-9, 2)
    other_vat = round(other_ex * CATALOG_VAT_RATE + 1e-9, 2)
    total_inc = round(material_inc + other_ex + other_vat + 1e-9, 2)
    vat_total = round(total_inc - subtotal_ex + 1e-9, 2)
    material_vat = round(material_inc - material_ex + 1e-9, 2)

    totals = q.get('totals') if isinstance(q.get('totals'), dict) else {}
    totals['sheetCostTotal'] = material_ex  # legacy ex-VAT compatibility
    totals['sheetCostTotalExVat'] = material_ex
    totals['sheetCostTotalInclVat'] = material_inc
    totals['edgeCostTotal'] = edge_sell_total
    totals['cncCostTotal'] = cnc_total
    totals['drawingCostTotal'] = drawing_total
    totals['transportCostTotal'] = transport_total
    totals['otherCostsExVat'] = other_ex
    totals['materialVatIncluded'] = material_vat
    totals['otherCostsVat'] = other_vat
    totals['subtotalExVat'] = subtotal_ex
    totals['vatAmount'] = vat_total
    totals['grandTotal'] = subtotal_ex  # legacy name retained as ex-VAT total
    totals['totalInclVat'] = total_inc
    totals['grandTotalInclVat'] = total_inc
    q['totals'] = totals
    q['totalInclVat'] = total_inc
    q['grandTotalInclVat'] = total_inc
    return q


def _format_eur(x: float) -> str:
    try:
        v = float(x or 0.0)
    except Exception:
        v = 0.0
    # EU format with comma decimals
    s = f"{v:,.2f}"
    s = s.replace(",", "X").replace(".", ",").replace("X", ".")
    return f"€{s}"

def _format_m(x: float) -> str:
    try:
        v = float(x or 0.0)
    except Exception:
        v = 0.0
    s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"{s} m"



def _iter_request_statuses():
    try:
        if not REQUESTS.exists():
            return
        for child in REQUESTS.iterdir():
            if not child.is_dir():
                continue
            sp = child / "status.json"
            if not sp.exists():
                continue
            try:
                data = strict_json_load(sp)
            except Exception:
                continue
            if isinstance(data, dict):
                yield data
    except Exception:
        return


def _find_request_status_for_job(job_id: str) -> Optional[dict]:
    jid = str(job_id or '').strip()
    if not jid:
        return None
    parent = jid.split('__mat_')[0] if '__mat_' in jid else jid
    candidates = {jid, parent}
    for st in _iter_request_statuses() or []:
        job = st.get('job') if isinstance(st.get('job'), dict) else {}
        if str(job.get('parentJobId') or '').strip() in candidates:
            return st
        for sj in (job.get('subjobs') or []):
            if not isinstance(sj, dict):
                continue
            if str(sj.get('subjobId') or sj.get('jobId') or '').strip() in candidates:
                return st
    return None


def _first_nonempty(*vals):
    for v in vals:
        if v is None:
            continue
        s = str(v).strip()
        if s:
            return s
    return ''


def _customer_block_from_status(request_status: dict | None) -> list[str]:
    lines = []
    if not isinstance(request_status, dict):
        return lines
    rid = request_status.get('requestId') or ''
    created = request_status.get('createdAt') or request_status.get('updatedAt') or ''
    cust = request_status.get('customer') if isinstance(request_status.get('customer'), dict) else {}
    name = _first_nonempty(cust.get('name'), cust.get('fullName'), ('%s %s' % (cust.get('firstName') or '', cust.get('lastName') or '')).strip())
    email = _first_nonempty(cust.get('email'))
    phone = _first_nonempty(cust.get('phone'), cust.get('telephone'), cust.get('tel'))
    fact = _first_nonempty(cust.get('billingAddress'), cust.get('factuurAdres'), cust.get('address'), cust.get('addressLine1'), cust.get('street'))
    ship = _first_nonempty(cust.get('shippingAddress'), cust.get('bezorgAdres'), cust.get('deliveryAddress'))
    city = _first_nonempty(cust.get('city'), cust.get('plaats'))
    postal = _first_nonempty(cust.get('postalCode'), cust.get('postcode'))
    # Heuristic: some payloads swap postcode/city; normalize if city looks like a postal code and postal is empty.
    try:
        if city and not postal and re.fullmatch(r'[0-9]{4}\s?[A-Za-z]{2}', str(city).strip()):
            postal, city = str(city).strip(), ''
    except Exception:
        pass
    country = _first_nonempty(cust.get('country'))

    if rid or created:
        lines.extend(['Aanvraag', '-' * 40])
        if rid:
            lines.append(f'Request ID: {rid}')
        if created:
            lines.append(f'Datum: {created}')
        lines.append('')
    if name or email or phone:
        lines.extend(['Klant', '-' * 40])
        if name:
            lines.append(f'Naam: {name}')
        if email:
            lines.append(f'Email: {email}')
        if phone:
            lines.append(f'Telefoon: {phone}')
        lines.append('')
    if fact or ship or city or postal or country:
        lines.extend(['Adres', '-' * 40])
        if fact:
            lines.append(f'Factuur: {fact}')
        if ship and ship != fact:
            lines.append(f'Bezorg: {ship}')
        city_line = ' '.join([x for x in [postal, city] if x]).strip()
        if city_line:
            lines.append(f'Plaats: {city_line}')
        if country:
            lines.append(f'Land: {country}')
        lines.append('')
    return lines


def _load_request_payload(request_id: str) -> dict:
    try:
        rid = _safe_id(str(request_id or '').strip(), 120)
        if not rid:
            return {}
        fp = REQUESTS / rid / 'input' / 'submit_payload.json'
        if not fp.exists():
            return {}
        data = strict_json_load(fp)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _customer_block_from_sources(request_status: dict | None, payload: dict | None = None) -> list[str]:
    lines = []
    rid = ''
    created = ''
    cust = {}
    note = ''
    rest_carry = None
    if isinstance(request_status, dict):
        rid = request_status.get('requestId') or ''
        created = request_status.get('createdAt') or request_status.get('updatedAt') or ''
        rc = request_status.get('customer') if isinstance(request_status.get('customer'), dict) else {}
        if isinstance(rc, dict):
            cust.update(rc)
    if isinstance(payload, dict):
        pc = payload.get('customer') if isinstance(payload.get('customer'), dict) else {}
        checkout = payload.get('checkout') if isinstance(payload.get('checkout'), dict) else {}
        cc = checkout.get('customer') if isinstance(checkout.get('customer'), dict) else {}
        try:
            if isinstance(checkout, dict):
                if 'restCarry' in checkout:
                    rest_carry = bool(checkout.get('restCarry'))
                elif isinstance(checkout.get('rest_material'), dict) and 'carry_out' in (checkout.get('rest_material') or {}):
                    rest_carry = bool((checkout.get('rest_material') or {}).get('carry_out'))
            if rest_carry is None and 'restCarry' in payload:
                rest_carry = bool(payload.get('restCarry'))
        except Exception:
            rest_carry = None
        merged = {}
        for src in (cust, cc, pc):
            if isinstance(src, dict):
                for k, v in src.items():
                    if v not in (None, ''):
                        merged[k] = v
        cust = merged
        note = _first_nonempty(
            checkout.get('note') if isinstance(checkout, dict) else '',
            payload.get('note'),
            pc.get('note') if isinstance(pc, dict) else '',
            cc.get('note') if isinstance(cc, dict) else '',
            pc.get('comment') if isinstance(pc, dict) else '',
            cc.get('comment') if isinstance(cc, dict) else '',
        )
    name = _first_nonempty(cust.get('name'), cust.get('fullName'), ('%s %s' % (cust.get('firstName') or '', cust.get('lastName') or '')).strip())
    email = _first_nonempty(cust.get('email'), cust.get('mail'))
    phone = _first_nonempty(cust.get('phone'), cust.get('telephone'), cust.get('tel'))
    fact = _first_nonempty(cust.get('billingAddress'), cust.get('invoiceAddress'), cust.get('factuurAdres'), cust.get('address'), cust.get('addressLine1'), ' '.join([x for x in [cust.get('street'), cust.get('houseNumber')] if x]).strip(), cust.get('street'))
    ship = _first_nonempty(cust.get('shippingAddress'), cust.get('bezorgAdres'), cust.get('deliveryAddress'), cust.get('address1'), ' '.join([x for x in [cust.get('deliveryStreet'), cust.get('deliveryHouseNumber')] if x]).strip())
    city = _first_nonempty(cust.get('city'), cust.get('plaats'))
    postal = _first_nonempty(cust.get('postalCode'), cust.get('postcode'))
    # Heuristic: some payloads swap postcode/city; normalize if city looks like a postal code and postal is empty.
    try:
        if city and not postal and re.fullmatch(r'[0-9]{4}\s?[A-Za-z]{2}', str(city).strip()):
            postal, city = str(city).strip(), ''
    except Exception:
        pass
    country = _first_nonempty(cust.get('country'))
    if rid or created:
        lines.extend(['Aanvraag', '-' * 40])
        if rid:
            lines.append(f'Request ID: {rid}')
        if created:
            lines.append(f'Datum: {created}')
        lines.append('')
    if name or email or phone:
        lines.extend(['Klant', '-' * 40])
        if name:
            lines.append(f'Naam: {name}')
        if email:
            lines.append(f'Email: {email}')
        if phone:
            lines.append(f'Telefoon: {phone}')
        lines.append('')
    if fact or ship or city or postal or country:
        lines.extend(['Adres', '-' * 40])
        if fact:
            lines.append(f'Factuur: {fact}')
        if ship and ship != fact:
            lines.append(f'Bezorg: {ship}')
        city_line = ' '.join([x for x in [postal, city] if x]).strip()
        if city_line:
            lines.append(f'Plaats: {city_line}')
        if country:
            lines.append(f'Land: {country}')
        lines.append('')
    if rest_carry is not None:
        lines.extend(['Restmateriaal', '-' * 40])
        lines.append(f"Meeleveren: {'JA' if rest_carry else 'NEE'}")
        lines.append('')
    if note:
        lines.extend(['Opmerking klant', '-' * 40, str(note).strip(), ''])
    return lines


def _extract_pricing_from_any(source: dict | None) -> dict:
    out = {
        'materialsTotal': None,
        'materialsTotalInclVat': None,
        'materialsVatIncluded': None,
        'otherCostsExVat': None,
        'otherCostsVat': None,
        'edgeBandTotal': None,
        'cncTotal': None,
        'drawingTotal': None,
        'transportTotal': None,
        'subtotalExVat': None,
        'vatAmount': None,
        'totalInclVat': None,
        'currency': 'EUR',
    }
    if not isinstance(source, dict):
        return out

    def _to_float(v):
        try:
            if v is None or v == '':
                return None
            return float(v)
        except Exception:
            return None

    def _first_num(*pairs):
        for obj, keys in pairs:
            if not isinstance(obj, dict):
                continue
            for key in keys:
                val = _to_float(obj.get(key))
                if val is not None:
                    return round(val, 2)
        return None

    def _walk(obj, keyset, results):
        if isinstance(obj, dict):
            for k, v in obj.items():
                lk = str(k).strip().lower()
                if lk in keyset:
                    val = _to_float(v)
                    if val is not None:
                        results.append(val)
                _walk(v, keyset, results)
        elif isinstance(obj, list):
            for it in obj:
                _walk(it, keyset, results)

    totals = source.get('totals') if isinstance(source.get('totals'), dict) else {}
    sell = source.get('sellPricing') if isinstance(source.get('sellPricing'), dict) else {}
    extra = source.get('extraCosts') if isinstance(source.get('extraCosts'), dict) else {}

    out['materialsTotalInclVat'] = _first_num(
        (totals, ('sheetCostTotalInclVat','materialsTotalInclVat','materialTotalInclVat')),
        (sell, ('sheetCostTotalInclVat','materialsTotalInclVat','materialTotalInclVat')),
        (extra, ('sheetCostTotalInclVat','materialsTotalInclVat','materialTotalInclVat')),
        (source, ('sheetCostTotalInclVat','materialsTotalInclVat','materialTotalInclVat')),
    )
    out['materialsVatIncluded'] = _first_num(
        (totals, ('materialVatIncluded','materialsVatIncluded')),
        (sell, ('materialVatIncluded','materialsVatIncluded')),
        (source, ('materialVatIncluded','materialsVatIncluded')),
    )
    out['otherCostsExVat'] = _first_num(
        (totals, ('otherCostsExVat',)), (sell, ('otherCostsExVat',)),
        (extra, ('otherCostsExVat',)), (source, ('otherCostsExVat',)),
    )
    out['otherCostsVat'] = _first_num(
        (totals, ('otherCostsVat',)), (sell, ('otherCostsVat',)),
        (extra, ('otherCostsVat',)), (source, ('otherCostsVat',)),
    )

    out['subtotalExVat'] = _first_num(
        (totals, ('subtotalExVat','grandTotal','total','subtotal','totalExVat','subTotalExVat')),
        (sell, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
        (extra, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
        (source, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
    )
    out['totalInclVat'] = _first_num(
        (totals, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
        (sell, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
        (extra, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
        (source, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
    )
    out['vatAmount'] = _first_num(
        (totals, ('vatAmount','btw','vat','taxAmount')),
        (sell, ('vatAmount','btw','vat','taxAmount')),
        (extra, ('vatAmount','btw','vat','taxAmount')),
        (source, ('vatAmount','btw','vat','taxAmount')),
    )
    if out['vatAmount'] is None and out['subtotalExVat'] is not None and out['totalInclVat'] is not None:
        out['vatAmount'] = round(out['totalInclVat'] - out['subtotalExVat'], 2)

    out['materialsTotal'] = _first_num(
        (totals, ('sheetCostTotalExVat','sheetCostTotal','materialsTotal','materialTotal')),
        (sell, ('sheetCostTotalExVat','sheetCostTotal','materialsTotal','materialTotal')),
        (source, ('sheetCostTotalExVat','sheetCostTotal','materialsTotal','materialTotal')),
    )

    mats = source.get('materials') if isinstance(source.get('materials'), list) else []
    if mats and out['materialsTotal'] is None:
        total = 0.0
        has = False
        for m in mats:
            if not isinstance(m, dict):
                continue
            for key in ('sellPrice','sellPriceTotal','totalSellPrice','sheetSellPriceTotal','sheetCostTotal','sheetTotal','materialTotal','materialsTotal'):
                val = _to_float(m.get(key))
                if val is not None:
                    total += val
                    has = True
                    break
        if has:
            out['materialsTotal'] = round(total, 2)
    if out['materialsTotal'] is None:
        out['materialsTotal'] = _first_num(
            (sell, ('materialsTotal','materialTotal','sheetTotal','sheetCostTotal')),
            (extra, ('materialsTotal','materialTotal','sheetTotal','sheetCostTotal')),
            (source, ('materialsTotal','materialTotal','sheetTotal','sheetCostTotal')),
        )

    comp_map = {
        'edgeBandTotal': {
            'edgebandtotal','edgebandselltotal','edgebandcost','edgecosttotal','edgecosttotalraw',
            'kantenband','kantenbandtotaal'
        },
        'cncTotal': {'cnctotal','cnccosttotal','routingtotal','cnc','routingcost'},
        'drawingTotal': {
            'drawingtotal','drawingcost','drawingcosttotal','setupcost','setuptotal',
            'tekenwerk','tekenkosten'
        },
        'transportTotal': {
            'transporttotal','transportcost','transportcosttotal','shippingtotal','deliverytotal',
            'transport','verzendkosten'
        },
    }
    for target, keys in comp_map.items():
        out[target] = _first_num((sell, tuple(keys)), (extra, tuple(keys)), (source, tuple(keys)))
        if out[target] is None:
            vals = []
            _walk(source, keys, vals)
            if vals:
                out[target] = round(sum(vals), 2)
    return out


def _aggregate_materials_from_subjob_quotes(parent_job_id: str) -> list[dict]:
    return _pricing_aggregate_materials_from_subjob_quotes(JOBS, parent_job_id)


def _parse_calculation_summary_totals(job_root: Path) -> dict:
    return _pricing_parse_calculation_summary_totals(job_root)


def _write_human_calculation_summary(job_root: Path, request_status: dict | None = None) -> None:
    """Write a human-readable calculation summary using the same pricing source as Admin/Tool A."""
    input_dir = job_root / "input"
    output_dir = job_root / "output"
    panels_path = input_dir / "panels.csv"

    jid = job_root.name
    parent_jid = jid.split('__mat_')[0] if '__mat_' in jid else jid
    candidate_job_ids = []
    for x in [parent_jid, jid]:
        if x and x not in candidate_job_ids:
            candidate_job_ids.append(x)

    if request_status is None:
        request_status = _find_request_status_for_job(jid)
    request_payload = _load_request_payload(str(request_status.get('requestId') or '')) if isinstance(request_status, dict) else {}

    quote = {}
    pricing = {}
    for cand in candidate_job_ids:
        try:
            qp = JOBS / cand / 'output' / 'quote.json'
            if qp.exists():
                quote = strict_json_load(qp)
                break
        except Exception:
            pass
    try:
        pp = input_dir / 'pricing.json'
        if pp.exists():
            pricing = strict_json_load(pp)
    except Exception:
        pricing = {}

    subjob_quote = {}
    try:
        sqp = output_dir / 'quote.json'
        if sqp.exists():
            subjob_quote = strict_json_load(sqp)
    except Exception:
        subjob_quote = {}

    if not isinstance(quote, dict):
        quote = {}
    if not isinstance(subjob_quote, dict):
        subjob_quote = {}
    if not isinstance(pricing, dict):
        pricing = {}
    if not panels_path.exists() and not quote and not subjob_quote and not request_status and not request_payload:
        return

    mat_meta = {}
    for m in (pricing.get("materials") or []):
        if not isinstance(m, dict):
            continue
        code = str(m.get("materialCode") or "")
        if not code:
            continue
        mat_meta[code] = {
            "productName": (m.get("productName") or m.get("materialDisplayName") or m.get("decorName") or m.get("name") or "").strip(),
            "articleNumber": (m.get("articleNumber") or m.get("materialCode") or "").strip(),
            "thicknessMm": m.get("thicknessMm"),
            "sheetSizeMm": m.get("sheetSizeMm") or {},
            "purchasePricePerSheet": m.get("purchasePricePerSheet"),
            "purchasePrice": m.get("purchasePrice"),
            "sellPriceExVatPerSheet": m.get("sellPriceExVatPerSheet"),
            "sellPriceInclVatPerSheet": m.get("sellPriceInclVatPerSheet"),
        }

    per_mat_meters = {}
    panel_qty_total = 0
    try:
        if panels_path.exists():
            rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
            for r in rows:
                code = str(r.get("MaterialCode") or r.get("materialCode") or "").strip()
                qty = int(float(r.get("Qty") or 0) or 0)
                panel_qty_total += qty
                if not code:
                    continue
                L = float(r.get("LengthMm") or 0.0)
                W = float(r.get("WidthMm") or 0.0)
                mtrs = 0.0
                for k, dim in (("H1", L), ("H2", L), ("W1", W), ("W2", W)):
                    try:
                        ec = int(float(r.get(k) or 0) or 0)
                    except Exception:
                        ec = 0
                    if ec != 0:
                        mtrs += (dim / 1000.0) * qty
                per_mat_meters[code] = per_mat_meters.get(code, 0.0) + mtrs
    except Exception:
        per_mat_meters = {}

    mats_used = []
    for src in (subjob_quote, quote, request_payload.get('quote') if isinstance(request_payload, dict) else {}):
        if isinstance(src, dict) and isinstance(src.get('materials'), list) and src.get('materials'):
            mats_used = src.get('materials')
            break
    if not mats_used:
        mats_payload = request_payload.get('materialsSummary') if isinstance(request_payload, dict) and isinstance(request_payload.get('materialsSummary'), list) else []
        if mats_payload:
            mats_used = []
            for m in mats_payload:
                if not isinstance(m, dict):
                    continue
                code = str(m.get('code') or m.get('articleNumber') or m.get('materialCode') or '').strip()
                name = _best_material_name(code, m.get('materialDisplayName'), m.get('materialName'), m.get('name'), m.get('productName'), m.get('decorName'))
                mats_used.append({
                    'materialCode': code,
                    'productName': name,
                    'sheetCount': m.get('plates') or m.get('sheetCount') or 0,
                    'thicknessMm': m.get('thicknessMm') or (mat_meta.get(code) or {}).get('thicknessMm'),
                    'sheetSizeMm': m.get('sheetSizeMm') or (mat_meta.get(code) or {}).get('sheetSizeMm') or {},
                    'sheetUnitCostRaw': (mat_meta.get(code) or {}).get('purchasePricePerSheet') or (mat_meta.get(code) or {}).get('purchasePrice'),
                })
    # For parent/master jobs, trust real material subjob quotes over request payload placeholders.
    subjob_mats = _aggregate_materials_from_subjob_quotes(parent_jid)
    if subjob_mats:
        try:
            existing_total = 0
            for _m in mats_used:
                if isinstance(_m, dict):
                    existing_total += int(float(_m.get('sheetCount') or _m.get('plates') or 0) or 0)
        except Exception:
            existing_total = 0
        try:
            sub_total = 0
            for _m in subjob_mats:
                if isinstance(_m, dict):
                    sub_total += int(float(_m.get('sheetCount') or _m.get('plates') or 0) or 0)
        except Exception:
            sub_total = 0
        if sub_total > existing_total:
            mats_used = subjob_mats

    if not mats_used:
        derived_codes = []
        for c in list(per_mat_meters.keys()) + list(mat_meta.keys()):
            c = str(c or '').strip()
            if c and c not in derived_codes:
                derived_codes.append(c)
        if derived_codes:
            mats_used = []
            total_guess = 0
            for code in derived_codes:
                meta = mat_meta.get(code, {})
                unit_raw = meta.get('purchasePricePerSheet') or meta.get('purchasePrice')
                cnt = 0
                try:
                    # FIX654: opaque __mat_### suffix is not a material code. Resolve it from panels.csv.
                    if '__mat_' in jid:
                        _ctx_code = str((_job_material_context(job_root) or {}).get('materialCode') or '').strip()
                        if code == _ctx_code:
                            cnt = 1
                except Exception:
                    cnt = 0
                # Parent / mixed-material fallback: when panels exist for a material but the quote did not report
                # sheet counts yet, assume at least one sheet for that used material instead of dropping material+CNC.
                if cnt <= 0 and code in per_mat_meters:
                    cnt = 1
                mats_used.append({
                    'materialCode': code,
                    'productName': meta.get('productName') or _best_material_name(code, ''),
                    'sheetCount': cnt,
                    'thicknessMm': meta.get('thicknessMm'),
                    'sheetSizeMm': meta.get('sheetSizeMm') or {},
                    'sheetUnitCostRaw': unit_raw,
                })
                total_guess += cnt
            if total_guess == 0 and len(mats_used) == 1:
                mats_used[0]['sheetCount'] = 1

    summary = _extract_admin_pricing_summary(candidate_job_ids, request_status)

    sell = quote.get("sellPricing") if isinstance(quote.get("sellPricing"), dict) else {}
    if not sell and isinstance(subjob_quote.get('sellPricing'), dict):
        sell = subjob_quote.get('sellPricing')
    live_sell = {}
    try:
        _live_cfg = _load_pricing_config()
        if isinstance(_live_cfg, dict) and isinstance(_live_cfg.get('sellPricing'), dict):
            live_sell = dict(_live_cfg.get('sellPricing') or {})
    except Exception:
        live_sell = {}
    # IMPORTANT: never fall back to stale request-payload pricing for the final calculation summary.
    # The summary must reflect the currently active live pricing config (or the quote that was just
    # post-processed from that config), especially when Admin values were changed right before a run.
    sell_effective = dict(live_sell)
    try:
        if isinstance(sell, dict) and sell:
            sell_effective.update(sell)
    except Exception:
        pass
    sell = sell_effective

    # Recalculate component totals from the live/quote source of truth. The exact CSV
    # material amount INCLUDING VAT is authoritative; a net equivalent is maintained only
    # for fiscal subtotal/VAT reporting. No general material factor exists.
    derived_materials_total = None
    derived_materials_total_inc = None
    derived_edge_total = None
    derived_cnc_total = None
    derived_drawing_total = None
    derived_transport_total = None
    try:
        if mats_used:
            mats_sell = 0.0
            mats_sell_inc = 0.0
            mats_have = False
            mats_inc_have = False
            for m in mats_used:
                if not isinstance(m, dict):
                    continue
                cnt = int(float(m.get('sheetCount') or 0) or 0)
                code = str(m.get('materialCode') or '').strip()
                meta_for_code = mat_meta.get(code) or {}
                unit_raw = m.get('sellPriceExVatPerSheet')
                if unit_raw is None:
                    unit_raw = m.get('sheetUnitCostRaw')
                if unit_raw is None:
                    unit_raw = meta_for_code.get('sellPriceExVatPerSheet')
                if unit_raw is None:
                    unit_raw = meta_for_code.get('purchasePricePerSheet') or meta_for_code.get('purchasePrice')
                unit_inc = m.get('sellPriceInclVatPerSheet')
                if unit_inc is None:
                    unit_inc = meta_for_code.get('sellPriceInclVatPerSheet')
                try:
                    unit_raw = float(unit_raw)
                except Exception:
                    unit_raw = None
                try:
                    unit_inc = float(unit_inc)
                except Exception:
                    unit_inc = None
                effective_cnt = cnt if cnt > 0 else (1 if len(mats_used) == 1 else 0)
                if unit_raw is not None and effective_cnt > 0:
                    mats_sell += round(unit_raw * effective_cnt, 2)
                    mats_have = True
                if unit_inc is not None and effective_cnt > 0:
                    # CSV sale price including VAT is authoritative. Preserve it exactly
                    # instead of reconstructing it from a two-decimal ex-VAT subtotal.
                    mats_sell_inc += round(unit_inc * effective_cnt, 2)
                    mats_inc_have = True
            if mats_have:
                derived_materials_total = round(mats_sell, 2)
            if mats_inc_have:
                derived_materials_total_inc = round(mats_sell_inc, 2)
    except Exception:
        pass
    try:
        total_m = sum(float(v or 0.0) for v in (per_mat_meters or {}).values())
        if total_m > 0:
            derived_edge_total = round(total_m * float((sell or {}).get('edgeBandPricePerM', EDGE_BAND_PRICE_PER_M)), 2)
    except Exception:
        pass
    try:
        total_sheets_guess = 0
        for m in mats_used:
            if isinstance(m, dict):
                total_sheets_guess += int(float(m.get('sheetCount') or 0) or 0)
        if total_sheets_guess <= 0 and len(mats_used) == 1:
            total_sheets_guess = 1
        if total_sheets_guess > 0:
            derived_cnc_total = round(total_sheets_guess * float((sell or {}).get('cncCostPerSheet', CNC_COST_PER_SHEET)), 2)
    except Exception:
        pass
    try:
        derived_drawing_total = round(float((sell or {}).get('drawingCostFixed', DRAWING_COST_FIXED)), 2)
    except Exception:
        pass
    try:
        derived_transport_total = round(float((sell or {}).get('transportCostFixed', TRANSPORT_COST_FIXED)), 2)
    except Exception:
        pass

    # Always let the live/quote-derived component values win for the final human summary.
    # This prevents stale request payload summaries from leaking old transport/factor values.
    if derived_materials_total is not None:
        summary['materialsTotal'] = derived_materials_total  # accounting ex-VAT equivalent
    if derived_materials_total_inc is not None:
        summary['materialsTotalInclVat'] = derived_materials_total_inc  # exact CSV gross truth
    if derived_edge_total is not None:
        summary['edgeBandTotal'] = derived_edge_total
    if derived_cnc_total is not None:
        summary['cncTotal'] = derived_cnc_total
    if derived_drawing_total is not None:
        summary['drawingTotal'] = derived_drawing_total
    if derived_transport_total is not None:
        summary['transportTotal'] = derived_transport_total

    subtotal_ex = 0.0
    for key in ('materialsTotal','edgeBandTotal','cncTotal','drawingTotal','transportTotal'):
        try:
            subtotal_ex += float(summary.get(key) or 0.0)
        except Exception:
            pass
    subtotal_ex = round(subtotal_ex, 2) if subtotal_ex > 0 else 0.0
    if subtotal_ex:
        summary['subtotalExVat'] = subtotal_ex
    # Preserve the website's authoritative per-sheet incl-VAT material price exactly.
    # Only the remaining Admin-configurable costs receive VAT on top.
    other_ex = 0.0
    for _key in ('edgeBandTotal','cncTotal','drawingTotal','transportTotal'):
        try:
            other_ex += float(summary.get(_key) or 0.0)
        except Exception:
            pass
    other_ex = round(other_ex, 2)
    if derived_materials_total_inc is not None:
        material_inc = round(float(derived_materials_total_inc), 2)
        material_ex = round(float(summary.get('materialsTotal') or (material_inc / (1.0 + CATALOG_VAT_RATE))), 2)
        material_vat = round(material_inc - material_ex, 2)
        other_vat = round(other_ex * CATALOG_VAT_RATE, 2)
        total_inc = round(material_inc + other_ex + other_vat, 2)
        summary['materialsVatIncluded'] = material_vat
        summary['otherCostsExVat'] = other_ex
        summary['otherCostsVat'] = other_vat
    else:
        total_inc = round(subtotal_ex * (1.0 + CATALOG_VAT_RATE), 2) if subtotal_ex else 0.0
        material_vat = None
        other_vat = None
    if total_inc:
        summary['totalInclVat'] = total_inc
    vat_amt = round(total_inc - subtotal_ex, 2) if total_inc and subtotal_ex else 0.0
    if vat_amt or total_inc:
        summary['vatAmount'] = vat_amt

    lines = []
    lines.append("METOD One-Click – Berekeningsoverzicht")
    lines.append("=" * 40)
    lines.append(f"Job: {jid}")
    lines.append("")
    lines.extend(_customer_block_from_sources(request_status, request_payload))

    lines.append("Configuratie")
    lines.append("-" * 40)
    if not panel_qty_total and isinstance(request_payload, dict):
        try:
            panel_qty_total = len(request_payload.get('cart') or []) + len(request_payload.get('extraPanels') or [])
        except Exception:
            panel_qty_total = 0
    if panel_qty_total:
        lines.append(f"Aantal panelen: {panel_qty_total}")
    total_sheets = 0
    if mats_used:
        for m in mats_used:
            if isinstance(m, dict):
                try:
                    total_sheets += int(m.get('sheetCount') or m.get('plates') or 0)
                except Exception:
                    pass
    if total_sheets:
        lines.append(f"Aantal platen: {total_sheets}")
    lines.append("")

    lines.append("Materialen / platen")
    lines.append("-" * 40)
    lines.append("Materiaalprijs: directe CSV-verkoopprijs per plaat; deze prijs is al inclusief 21% BTW")
    lines.append("")
    if mats_used:
        for m in mats_used:
            if not isinstance(m, dict):
                continue
            code = str(m.get("materialCode") or m.get('code') or "")
            meta = mat_meta.get(code, {})
            name = meta.get("productName") or m.get('productName') or m.get('materialDisplayName') or m.get('decorName') or m.get('name') or ''
            art = meta.get("articleNumber") or code
            th = m.get("thicknessMm") or meta.get("thicknessMm") or ""
            cnt = int(m.get("sheetCount") or m.get('plates') or 0)
            ss = m.get("sheetSizeMm") or meta.get("sheetSizeMm") or {}
            sw = ss.get("width") or ss.get("Width") or ""
            sh = ss.get("height") or ss.get("Height") or ""
            size_str = f"{int(sw)}×{int(sh)} mm" if sw and sh else ""
            lines.append(f"- {name} (artikel: {art})")
            detail = f"  Dikte: {th} mm | Platen: {cnt}"
            if size_str:
                detail += f" | Plaatmaat: {size_str}"
            lines.append(detail)
            unit_sell_inc = m.get("sellPriceInclVatPerSheet")
            if unit_sell_inc is None:
                unit_sell_inc = meta.get("sellPriceInclVatPerSheet")
            if unit_sell_inc is None:
                unit_sell_ex = m.get("sellPriceExVatPerSheet")
                if unit_sell_ex is None:
                    unit_sell_ex = m.get("sheetUnitCostRaw")
                if unit_sell_ex is None:
                    unit_sell_ex = meta.get("purchasePricePerSheet") or meta.get("purchasePrice")
                try:
                    unit_sell_inc = round(float(unit_sell_ex) * (1.0 + CATALOG_VAT_RATE), 2) if unit_sell_ex is not None else None
                except Exception:
                    unit_sell_inc = None
            try:
                unit_sell_inc = round(float(unit_sell_inc), 2) if unit_sell_inc is not None else None
            except Exception:
                unit_sell_inc = None
            cost_sell_inc = None
            if unit_sell_inc is not None and cnt:
                try:
                    cost_sell_inc = round(float(unit_sell_inc) * float(cnt) + 1e-9, 2)
                except Exception:
                    cost_sell_inc = None
            if unit_sell_inc is not None:
                lines.append(f"  Verkoopprijs plaat incl. btw: {_format_eur(unit_sell_inc)} p/st")
            if cost_sell_inc is not None:
                lines.append(f"  Subtotaal plaatmateriaal incl. btw: {_format_eur(cost_sell_inc)}")
            lines.append("")
    else:
        mats_payload = request_payload.get('materialsSummary') if isinstance(request_payload, dict) and isinstance(request_payload.get('materialsSummary'), list) else []
        if mats_payload:
            for m in mats_payload:
                if not isinstance(m, dict):
                    continue
                code = str(m.get('code') or m.get('articleNumber') or m.get('materialCode') or '').strip()
                name = _best_material_name(code, m.get('materialDisplayName'), m.get('materialName'), m.get('name'), m.get('productName'), m.get('decorName'))
                cnt = m.get('plates') or ''
                lines.append(f"- {name or code} (artikel: {code})")
                if cnt:
                    lines.append(f"  Platen: {cnt}")
                lines.append("")
        else:
            lines.append("(geen materialen gevonden in quote.json)")
            lines.append("")

    lines.append("Kantenband (m¹) per decor")
    lines.append("-" * 40)
    if per_mat_meters:
        for code, mtrs in sorted(per_mat_meters.items(), key=lambda kv: kv[0]):
            meta = mat_meta.get(code, {})
            name = meta.get("productName") or _best_material_name(code, '')
            art = meta.get("articleNumber") or code
            label = f"{name} (artikel: {art})" if name else f"Artikel: {art}"
            lines.append(f"- {label}: {_format_m(mtrs)}")
        lines.append("")
        total_m = sum(per_mat_meters.values())
        try:
            edge_price_live = float((sell or {}).get('edgeBandPricePerM', EDGE_BAND_PRICE_PER_M))
        except Exception:
            edge_price_live = EDGE_BAND_PRICE_PER_M
        lines.append(f"Totaal kantenband: {_format_m(total_m)}")
        lines.append(f"Prijs kantenband: {_format_eur(edge_price_live)} per meter")
        lines.append("")
    else:
        lines.append("(geen kantenband gevonden)")
        lines.append("")

    lines.append("Kostenopbouw")
    lines.append("-" * 40)
    if summary.get('materialsTotalInclVat') is not None:
        lines.append(f"Plaatmateriaal incl. btw: {_format_eur(summary['materialsTotalInclVat'])}")
    elif summary.get('materialsTotal') is not None:
        lines.append(f"Plaatmateriaal excl. btw (legacy fallback): {_format_eur(summary['materialsTotal'])}")
    if summary.get('edgeBandTotal') is not None:
        lines.append(f"Kantenband excl. btw:      {_format_eur(summary['edgeBandTotal'])}")
    if summary.get('cncTotal') is not None:
        lines.append(f"CNC excl. btw:             {_format_eur(summary['cncTotal'])}")
    if summary.get('drawingTotal') is not None:
        lines.append(f"Tekenen excl. btw:         {_format_eur(summary['drawingTotal'])}")
    if summary.get('transportTotal') is not None:
        lines.append(f"Transport excl. btw:       {_format_eur(summary['transportTotal'])}")
    lines.append("")
    lines.append("Fiscale uitsplitsing")
    lines.append("-" * 40)
    if summary.get('materialsTotal') is not None:
        lines.append(f"Plaatmateriaal netto-equivalent: {_format_eur(summary['materialsTotal'])}")
    if summary.get('materialsVatIncluded') is not None:
        lines.append(f"BTW reeds in plaatprijs:          {_format_eur(summary['materialsVatIncluded'])}")
    if summary.get('otherCostsExVat') is not None:
        lines.append(f"Overige kosten excl. btw:         {_format_eur(summary['otherCostsExVat'])}")
    if summary.get('otherCostsVat') is not None:
        lines.append(f"BTW over overige kosten:          {_format_eur(summary['otherCostsVat'])}")
    lines.append("")
    lines.append(f"Subtotaal excl. btw: {_format_eur(subtotal_ex)}")
    lines.append(f"BTW (21%):          {_format_eur(vat_amt)}")
    lines.append(f"Totaal incl. btw:    {_format_eur(total_inc)}")
    lines.append("")

    out_txt = "\n".join(lines).strip() + "\n"
    durable_write_text(output_dir / 'calculation_summary.txt', out_txt)
    try:
        durable_write_text(input_dir / 'calculation_summary.txt', out_txt)
    except Exception:
        pass

def _parse_panels_csv(text: str) -> list[dict]:
    '''
    Parse Tool A panels.csv (semicolon-delimited) into list of dict rows.
    '''
    rows = _parse_panels_csv_contract(
        str(text or ''),
        allowed_thicknesses=CATALOG_ALLOWED_THICKNESSES_MM,
        allowed_edge_codes={0, 1},
        max_rows=_env_int('PUBLIC_JOB_MAX_PANEL_ROWS', 500),
        max_total_qty=_env_int('PUBLIC_JOB_TOTAL_QTY_LIMIT', 250),
    )
    return [row.as_dict() for row in rows]



def _is_subjob(job_id: str) -> bool:
    return "__mat_" in (job_id or "")

def _sanitize_key(s: str) -> str:
    s = str(s or "").strip()
    # keep alnum, dash, underscore; replace others with underscore
    return re.sub(r'[^A-Za-z0-9_\-]+', '_', s) or "mat"

def _filter_panels_csv_by_material(panels_csv: str, material_code: str) -> str:
    """Return panels.csv containing only rows whose MaterialCode matches material_code."""
    panels_csv = panels_csv or ""
    lines = [ln for ln in panels_csv.splitlines() if ln.strip()]
    if not lines:
        return panels_csv
    header = lines[0]
    rows = _parse_panels_csv(panels_csv)
    filt = [r for r in rows if str(r.get("MaterialCode") or "").strip() == str(material_code).strip()]
    out = io.StringIO()
    out.write(header.strip() + "\n")
    if filt:
        writer = csv.DictWriter(out, fieldnames=header.split(';'), delimiter=';', lineterminator='\n')
        for r in filt:
            # DictWriter writes header only if writeheader() called; we already wrote it
            writer.writerow({k: r.get(k, "") for k in header.split(';')})
    return out.getvalue()

def _parts_for_panels_rows(rows: list[dict]) -> set[str]:
    part_ids = set()
    for r in rows:
        pid = str(r.get("PartId") or r.get("PartID") or r.get("partId") or "").strip()
        if pid:
            part_ids.add(pid)
    return part_ids

def _merge_raw_quotes(quotes: list[dict], master_job_id: str) -> dict:
    """Merge Tool B raw quote.json objects into one raw quote (purchase-cost model)."""
    out = {
        "jobId": master_job_id,
        "currency": "EUR",
        "settings": {},
        "materials": [],
        "edgeBanding": {
            "defaultLossPercent": 0.0,
            "byCodeMeters": {},
            "byCodeMetersWithLoss": {},
            "byCodeCost": {},
            "edgeCostTotal": 0.0,
        },
        "totals": {"sheetCostTotal": 0.0, "edgeCostTotal": 0.0, "grandTotal": 0.0},
        "outputs": {},
    }
    mats_acc = {}
    loss = 0.0
    by_m = {}
    by_m_loss = {}
    for q in quotes:
        if not isinstance(q, dict):
            continue
        out["currency"] = q.get("currency") or out["currency"]
        if isinstance(q.get("settings"), dict) and not out["settings"]:
            out["settings"] = dict(q["settings"])
        edge = q.get("edgeBanding") if isinstance(q.get("edgeBanding"), dict) else {}
        try:
            loss = float(edge.get("defaultLossPercent") or loss or 0.0)
        except Exception:
            pass
        # materials
        for m in q.get("materials") or []:
            if not isinstance(m, dict):
                continue
            key = (str(m.get("materialCode") or ""), float(m.get("thicknessMm") or 0.0))
            prev = mats_acc.get(key)
            if prev is None:
                mats_acc[key] = json.loads(json.dumps(m))
            else:
                prev["sheetCount"] = int(prev.get("sheetCount") or 0) + int(m.get("sheetCount") or 0)
                # recompute totals
                unit = float(prev.get("sheetUnitCost") or 0.0)
                prev["sheetCostTotal"] = round(unit * int(prev["sheetCount"]), 2)
        # edge meters
        bcm = edge.get("byCodeMeters") if isinstance(edge.get("byCodeMeters"), dict) else {}
        for k,v in bcm.items():
            try:
                by_m[str(k)] = by_m.get(str(k), 0.0) + float(v)
            except Exception:
                pass
        bcm2 = edge.get("byCodeMetersWithLoss") if isinstance(edge.get("byCodeMetersWithLoss"), dict) else {}
        for k,v in bcm2.items():
            try:
                by_m_loss[str(k)] = by_m_loss.get(str(k), 0.0) + float(v)
            except Exception:
                pass
        # totals
        tot = q.get("totals") if isinstance(q.get("totals"), dict) else {}
        for tk in ["sheetCostTotal","edgeCostTotal","grandTotal"]:
            try:
                out["totals"][tk] = round(float(out["totals"].get(tk) or 0.0) + float(tot.get(tk) or 0.0), 2)
            except Exception:
                pass

    out["materials"] = list(mats_acc.values())
    out["edgeBanding"]["defaultLossPercent"] = loss
    out["edgeBanding"]["byCodeMeters"] = {k: round(v,3) for k,v in by_m.items()}
    out["edgeBanding"]["byCodeMetersWithLoss"] = {k: round(v,3) for k,v in by_m_loss.items()}
    # costs by code (purchase) - sum if present
    for q in quotes:
        edge = q.get("edgeBanding") if isinstance(q, dict) and isinstance(q.get("edgeBanding"), dict) else {}
        bcc = edge.get("byCodeCost") if isinstance(edge.get("byCodeCost"), dict) else {}
        for k,v in bcc.items():
            try:
                out["edgeBanding"]["byCodeCost"][str(k)] = round(float(out["edgeBanding"]["byCodeCost"].get(str(k)) or 0.0) + float(v), 2)
            except Exception:
                pass
    out["edgeBanding"]["edgeCostTotal"] = out["totals"]["edgeCostTotal"]
    out["outputs"] = {"subjobs": True}
    return out

def _edge_name_from_code(pricing: dict, code_val) -> str:
    try:
        if code_val is None:
            return ""
        s = str(code_val).strip()
        if s == "" or s.lower() in ("0", "none", "null", "undefined"):
            return ""
        code = int(float(s))
        if code <= 0:
            return ""
        codes = (((pricing or {}).get("edgeBanding") or {}).get("codes") or [])
        for c in codes:
            try:
                if int(c.get("code")) == code:
                    return str(c.get("name") or "").strip()
            except Exception:
                continue
        return ""
    except Exception:
        return ""


def _guess_sheet_dxf_file(sheets_dir: Path, sheet_index: int) -> Optional[str]:
    '''Return filename like Sheet_001.dxf or <mat>_Sheet_001.dxf if found.'''
    if not sheets_dir.exists():
        return None
    token = f"Sheet_{sheet_index:03d}".lower()
    matches = [p.name for p in sheets_dir.glob("*.dxf") if token in p.name.lower()]
    return sorted(matches)[0] if matches else None


def _generate_labels_json(job_root: Path) -> None:
    '''
    Create output/labels.json by merging:
      - input/panels.csv
      - input/pricing.json (edgeBanding code->name)
      - output/placements.json
    '''
    input_dir = job_root / "input"
    output_dir = job_root / "output"
    panels_path = input_dir / "panels.csv"
    pricing_path = input_dir / "pricing.json"
    placements_path = _find_placements_any(output_dir) or (output_dir / "placements.json")
    if not (panels_path.exists() and pricing_path.exists() and placements_path and placements_path.exists()):
        return

    panels_rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
    pricing = strict_json_load(pricing_path)
    placements = strict_json_load(placements_path)

    job_json = {}
    job_json_path = input_dir / "job.json"
    if job_json_path.exists():
        try:
            job_json = strict_json_load(job_json_path)
        except Exception:
            job_json = {}

    by_part: dict[str, dict] = {}
    for r in panels_rows:
        pid = str(r.get("PartId") or "").strip()
        if pid:
            by_part[pid] = r

    sheets_out = []
    labels_out = []

    sheets_dir = output_dir / "sheets"
    job_id = placements.get("jobId", job_root.name)

    for sh in (placements.get("sheets") or []):
        si = int(sh.get("sheetIndex", 0))
        sheet_id = f"sheet_{si:03d}"
        sheet_size = sh.get("sheetSizeMm") or {}
        dxf_name = _guess_sheet_dxf_file(sheets_dir, si)

        sheets_out.append({
            "sheet_id": sheet_id,
            "dxf_file": (f"sheets/{dxf_name}" if dxf_name else ""),
            "width_mm": float(sheet_size.get("width") or sheet_size.get("w") or 0),
            "height_mm": float(sheet_size.get("height") or sheet_size.get("h") or 0),
            "margin_mm": float(sh.get("marginMm") or 0),
            "gap_mm": float(sh.get("gapMm") or 0),
            "material_code": str(sh.get("materialCode") or ""),
            "thickness_mm": float(sh.get("thicknessMm") or 0),
        })

        for pl in (sh.get("placements") or []):
            part_id = str(pl.get("partId") or "").strip()
            inst = int(pl.get("instanceIndex") or 1)
            x = float(pl.get("x") or 0)
            y = float(pl.get("y") or 0)
            rot = int(pl.get("rotDeg") or 0)

            pr = by_part.get(part_id, {})
            panel_name = str(pr.get("PanelName") or pl.get("panelName") or "")
            material_name = str(pr.get("DecorName") or "")
            material_code = str(pr.get("MaterialCode") or sh.get("materialCode") or "")
            order_number = str(pr.get("OrderNumber") or "")
            customer_name = ""

            length_mm = float(pr.get("LengthMm") or 0)
            width_mm = float(pr.get("WidthMm") or 0)
            thickness_mm = float(pr.get("ThicknessMm") or sh.get("thicknessMm") or 0)

            w_eff = width_mm
            h_eff = length_mm
            if rot % 180 != 0:
                w_eff, h_eff = h_eff, w_eff
            bbox = [x, y, x + w_eff, y + h_eff]

            edge_h1 = _edge_name_from_code(pricing, pr.get("H1"))
            edge_h2 = _edge_name_from_code(pricing, pr.get("H2"))
            edge_w1 = _edge_name_from_code(pricing, pr.get("W1"))
            edge_w2 = _edge_name_from_code(pricing, pr.get("W2"))

            label_id = f"{part_id}-{inst}"
            barcode_value = f"http://{PUBLIC_HOST}:{PORT}/m/{job_id}/{label_id}"

            labels_out.append({
                "label_id": label_id,
                "panel_id": part_id,
                "instance": inst,
                "qty_total": int(float(pr.get("Qty") or 1)) if str(pr.get("Qty") or "").strip() else 1,

                "order_number": order_number,
                "customer_name": customer_name,

                "panel_name": panel_name,
                "material_code": material_code,
                "material_name": material_name,

                "length_mm": length_mm,
                "width_mm": width_mm,
                "thickness_mm": thickness_mm,

                "edge_H1": edge_h1,
                "edge_H2": edge_h2,
                "edge_W1": edge_w1,
                "edge_W2": edge_w2,

                "barcode_type": "QR",
                "barcode_value": barcode_value,

                "placement": {
                    "sheet_id": sheet_id,
                    "origin": "bottom-left",
                    "y_axis": "up",
                    "x_mm": x,
                    "y_mm": y,
                    "bbox_mm": bbox,
                    "rotation_deg": rot,
                    "rotation_deg_cw": True,
                    "rotation_origin": "panel_center",
                }
            })

    labels_json = {
        "schema_version": 1,
        "units": "mm",
        "job_id": job_id,
        "order": {
            "order_number": (labels_out[0].get("order_number") if labels_out else ""),
            "customer_name": (labels_out[0].get("customer_name") if labels_out else ""),
        },
        "customer": (job_json.get("customer") or {}),
        "note": (job_json.get("note") or ""),
        "rest_material": {
            "carry_out": bool((job_json.get("rest_material") or {}).get("carry_out")) if (job_json.get("rest_material") is not None) else False,
            "label_text": ("Restmateriaal: JA" if bool((job_json.get("rest_material") or {}).get("carry_out")) else "Restmateriaal: NEE")
        },
        "sheets": sheets_out,
        "labels": labels_out,
    }

    durable_write_json(output_dir / "labels.json", labels_json, mode=0o640)


def _customer_name_from_job(job_json: dict) -> str:
    """Return a display-friendly customer name. Must always return a non-empty string."""
    try:
        cust = (job_json or {}).get("customer") or {}
        if isinstance(cust, dict):
            # Support both camelCase and snake_case keys.
            first = str(cust.get("firstName") or cust.get("first_name") or "").strip()
            last = str(cust.get("lastName") or cust.get("last_name") or "").strip()
            company = str(cust.get("company") or "").strip()
            name = (f"{first} {last}".strip())
            if name:
                return name
            if company:
                return company
    except Exception:
        pass
    return "Onbekend"


def _material_name_and_thickness(pricing: dict, material_code: str) -> tuple[str, float]:
    """Lookup the human material/decor name + thickness for a material code.

    IMPORTANT for StickerTool/admin exports:
    - materialCode must remain the article number/code.
    - materialDisplayName must be the human decor/product label, never the code just
      because a pricing row duplicated materialCode into decorName.
    """
    code = str(material_code or "").strip()
    try:
        mats = (pricing or {}).get("materials") or []
        for m in mats:
            if str(m.get("materialCode") or m.get("code") or m.get("articleNumber") or "").strip() == code:
                name = _best_material_name(
                    code,
                    m.get("materialDisplayName"),
                    m.get("materialName"),
                    m.get("name"),
                    m.get("productName"),
                    m.get("decorName"),
                )
                t = float(m.get("thicknessMm") or 0.0)
                return (name or code or "Onbekend"), t
    except Exception:
        pass
    return (_best_material_name(code, "") or code or "Onbekend"), 0.0


def _resolve_stickertool_material_display_name(material_code: str, job_json: dict, panels_rows: list[dict], pricing_obj: dict) -> str:
    """Resolve the StickerTool materialDisplayName from the richest available order data.

    This intentionally prefers order/catalog human labels over the subjob/material code.
    The bug fixed in FIX591 was that StickerTool could output:
      materialCode: "100817-1", materialDisplayName: "100817-1"
    while the expected display name is the decor/product name, e.g. "DecoLegno LS14 ...".
    """
    code = str(material_code or "").strip()

    def _code_of(rec: dict) -> str:
        return str(
            rec.get("materialCode") or rec.get("MaterialCode") or
            rec.get("code") or rec.get("articleNumber") or rec.get("articleNo") or
            rec.get("materialKey") or rec.get("ArticleNumber") or ""
        ).strip()

    def _name_of(rec: dict) -> str:
        return _best_material_name(
            code,
            rec.get("materialDisplayName"), rec.get("MaterialDisplayName"),
            rec.get("materialName"), rec.get("MaterialName"),
            rec.get("name"), rec.get("Name"),
            rec.get("productName"), rec.get("ProductName"),
            rec.get("decorName"), rec.get("DecorName"),
        )

    def _consider(rec: dict) -> str:
        if not isinstance(rec, dict):
            return ""
        rc = _code_of(rec)
        if code and rc and rc != code:
            return ""
        nm = _name_of(rec)
        # Do not accept the article number itself as display name when richer fallbacks may exist.
        if nm and (not code or nm != code):
            return nm
        return ""

    # 1) User/order payload sources are most accurate for custom/selected decor labels.
    try:
        if isinstance(job_json, dict):
            for key in ("materialsSummary", "materials", "materialBatches", "cart", "panels", "extraPanels"):
                arr = job_json.get(key)
                if isinstance(arr, list):
                    for rec in arr:
                        nm = _consider(rec)
                        if nm:
                            return nm
            quote = job_json.get("quote") if isinstance(job_json.get("quote"), dict) else {}
            q_mats = quote.get("materials") if isinstance(quote.get("materials"), list) else []
            for rec in q_mats:
                nm = _consider(rec)
                if nm:
                    return nm
    except Exception:
        pass

    # 2) panels.csv can carry DecorName/ProductName from Tool A.
    try:
        for rec in panels_rows or []:
            nm = _consider(rec)
            if nm:
                return nm
    except Exception:
        pass

    # 3) pricing.json generated by Tool B/admin.
    try:
        mats = (pricing_obj or {}).get("materials") or []
        if isinstance(mats, list):
            for rec in mats:
                nm = _consider(rec)
                if nm:
                    return nm
    except Exception:
        pass

    # 4) Embedded material library fallback.
    try:
        lib = strict_json_load(MATERIAL_LIBRARY_PATH)
        recs = lib.get("records") if isinstance(lib, dict) else lib
        if isinstance(recs, list):
            for rec in recs:
                nm = _consider(rec)
                if nm:
                    return nm
    except Exception:
        pass

    return _best_material_name(code, "") or code or "Onbekend"



def _job_material_context(job_root: Path) -> dict:
    """Resolve internal material metadata for a job/subjob from its server-side inputs.

    FIX654: public subjob IDs are deliberately opaque (``__mat_001`` etc.). Never
    interpret that suffix as an article/material code. Production/Admin helpers must
    resolve the real internal code from ``input/panels.csv`` (or output fallback).
    Nothing returned by this helper is itself exposed to Tool A.
    """
    root = Path(job_root)
    jid = root.name
    base_jid = jid.split('__mat_', 1)[0] if '__mat_' in jid else jid
    rows = []
    for cand in (root / 'input' / 'panels.csv', root / 'output' / 'panels.csv'):
        try:
            if cand.exists():
                rows = _parse_panels_csv(cand.read_text(encoding='utf-8'))
                if rows:
                    break
        except Exception:
            continue
    codes = []
    names = []
    thicknesses = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        code = str(row.get('MaterialCode') or row.get('materialCode') or row.get('ArticleNumber') or row.get('articleNumber') or '').strip()
        if code and code not in codes:
            codes.append(code)
        name = str(row.get('DecorName') or row.get('ProductName') or row.get('MaterialName') or row.get('materialName') or '').strip()
        if name and name not in names:
            names.append(name)
        try:
            tv = row.get('ThicknessMm') or row.get('ThicknessMM') or row.get('thicknessMm') or row.get('Thickness') or row.get('thickness')
            if tv not in (None, ''):
                f = float(str(tv).replace(',', '.'))
                if f not in thicknesses:
                    thicknesses.append(f)
        except Exception:
            pass
    code = codes[0] if len(codes) == 1 else ''
    name = names[0] if len(names) == 1 else ''
    thickness = thicknesses[0] if len(thicknesses) == 1 else None
    # Pricing is a secondary server-only fallback for human display metadata.
    if code and (not name or thickness is None):
        try:
            pp = root / 'input' / 'pricing.json'
            pricing = strict_json_load(pp) if pp.exists() else {}
            nm, th = _material_name_and_thickness(pricing, code)
            if not name and nm and nm != code:
                name = nm
            if thickness is None and th:
                thickness = float(th)
        except Exception:
            pass
    return {
        'jobId': jid,
        'baseJobId': base_jid,
        'materialCode': code,
        'materialName': name,
        'thicknessMm': thickness,
        'rows': rows,
    }

def _generate_stickertool_json(job_root: Path) -> Path:
    """Generate StickerTool v2.x contract JSON.

    R8 has one authoritative file: ``output/stickertool.json`` inside the
    material subjob. Duplicate compatibility mirrors were deliberately removed,
    because unsealed copies can diverge from the finalization manifest.
    """

    def _atomic_write_text(path: Path, text: str):
        durable_write_text(path, text)

    output_dir = job_root / "output"
    input_dir = job_root / "input"
    output_dir.mkdir(parents=True, exist_ok=True)

    # --- resolve jobId/subjobId/materialCode ---
    # FIX654: __mat_### is an opaque public-safe index, NOT an article number.
    subjob_id = job_root.name
    material_ctx = _job_material_context(job_root)
    base_job_id = str(material_ctx.get('baseJobId') or subjob_id)
    material_code = str(material_ctx.get('materialCode') or '').strip()

    # --- load job.json for customer/order info ---
    job_json = {}
    job_json_path = input_dir / "job.json"
    if job_json_path.exists():
        try:
            job_json = strict_json_load(job_json_path)
        except Exception:
            job_json = {}

    customer_name = _customer_name_from_job(job_json)
    order_number = str((job_json.get('order') or {}).get('orderNumber') or (job_json.get('order') or {}).get('order_number') or "").strip()

    # --- load placements.json ---
    placements_path = output_dir / "placements.json"
    placements_obj = {}
    if placements_path.exists():
        try:
            placements_obj = strict_json_load(placements_path)
        except Exception:
            placements_obj = {}

    placements_list = []
    if isinstance(placements_obj, dict):
        placements_list = placements_obj.get('placements') or []
    elif isinstance(placements_obj, list):
        placements_list = placements_obj
    else:
        placements_list = []

    # infer material_code if missing
    if not material_code:
        try:
            mats = sorted({str(p.get('materialCode') or '').strip() for p in placements_list if isinstance(p, dict) and str(p.get('materialCode') or '').strip()})
            if len(mats) == 1:
                material_code = mats[0]
        except Exception:
            pass

    # --- load panels.csv (output or input) ---
    panels_rows: list[dict] = []
    for cand in [output_dir / 'panels.csv', input_dir / 'panels.csv']:
        if cand.exists():
            try:
                panels_rows = _parse_panels_csv(cand.read_text(encoding='utf-8'))
                if panels_rows:
                    break
            except Exception:
                continue

    panels_by_part: dict[str, dict] = {}
    for r in panels_rows:
        if not isinstance(r, dict):
            continue
        pid = str(r.get('PartId') or r.get('PartID') or r.get('partId') or r.get('ID') or '').strip()
        if pid and pid not in panels_by_part:
            panels_by_part[pid] = r

    # --- material display name + thickness ---
    # FIX591: materialCode remains the article number/code; materialDisplayName must be
    # the human decor/product label from the order/catalog/pricing, not the code again.
    material_display_name = str(material_ctx.get('materialName') or material_code or "Onbekend")
    thickness_mm = material_ctx.get('thicknessMm')
    pricing_obj = {}
    try:
        pricing_path = output_dir / 'pricing.json'
        if pricing_path.exists():
            pricing_obj = strict_json_load(pricing_path)
        if material_code:
            nm, th = _material_name_and_thickness(pricing_obj, material_code)
            if nm:
                material_display_name = nm
            if th:
                thickness_mm = th
    except Exception:
        pass
    try:
        resolved_name = _resolve_stickertool_material_display_name(material_code, job_json, panels_rows, pricing_obj)
        if resolved_name:
            material_display_name = resolved_name
    except Exception:
        pass

    def _as_int(v, default=None):
        try:
            if v is None or v == '':
                return default
            return int(round(float(str(v).replace(',', '.'))))
        except Exception:
            return default

    def _rotation_0_90(rot_deg) -> int:
        r = _as_int(rot_deg, 0) or 0
        r = r % 360
        if r in (0, 180):
            return 0
        if r in (90, 270):
            return 90
        raise ValueError(f"Invalid rotation_deg (must be 0/90/180/270): {rot_deg}")

    # --- sheet size (placements meta first) ---
    sheet_w = None
    sheet_h = None
    try:
        meta_sheets = (placements_obj.get('sheets') or []) if isinstance(placements_obj, dict) else []
        pick = None
        for s in meta_sheets:
            if not isinstance(s, dict):
                continue
            if material_code and str(s.get('materialCode') or '').strip() != material_code:
                continue
            pick = s
            break
        if pick is None and meta_sheets:
            pick = meta_sheets[0]
        if isinstance(pick, dict):
            ss = pick.get('sheetSizeMm') or {}
            sheet_w = _as_int((ss or {}).get('width'))
            sheet_h = _as_int((ss or {}).get('height'))
            if thickness_mm is None:
                thickness_mm = _as_int(pick.get('thicknessMm'))
    except Exception:
        pass

    # last resort: material_library.json
    if (not sheet_w) or (not sheet_h):
        try:
            lib = strict_json_load(MATERIAL_LIBRARY_PATH)
            mats = lib.get('materials') if isinstance(lib, dict) else None
            if isinstance(mats, list) and material_code:
                hit = next((m for m in mats if str(m.get('articleNumber') or '').strip() == material_code), None)
                if isinstance(hit, dict):
                    ss = hit.get('sheetSizeMm') or hit.get('sheetSize') or {}
                    sheet_w = sheet_w or _as_int(ss.get('width') or ss.get('w'))
                    sheet_h = sheet_h or _as_int(ss.get('height') or ss.get('h'))
                    if thickness_mm is None:
                        thickness_mm = _as_int(hit.get('thicknessMm') or hit.get('thickness'))
                    if material_display_name == (material_code or "Onbekend"):
                        material_display_name = str(hit.get('productName') or hit.get('decorName') or material_display_name)
        except Exception:
            pass

    if not sheet_w:
        sheet_w = 2070
    if not sheet_h:
        sheet_h = 2800

    max_sheet_index = 1
    try:
        if placements_list:
            max_sheet_index = max(int(p.get('sheetIndex') or 1) for p in placements_list if isinstance(p, dict))
    except Exception:
        max_sheet_index = 1

    sheets_out = [
        {"sheetId": f"S{si:02d}", "width": int(sheet_w), "height": int(sheet_h)}
        for si in range(1, max_sheet_index + 1)
    ]

    # --- items ---
    items_out: list[dict] = []
    seen_part_ids: set[str] = set()

    for p in placements_list:
        if not isinstance(p, dict):
            continue
        pid_base = str(p.get('partId') or p.get('PartId') or '').strip()
        if not pid_base:
            continue
        inst = str(p.get('instanceIndex') if p.get('instanceIndex') is not None else '').strip()
        part_id = f"{pid_base}__{inst}" if inst else pid_base
        if part_id in seen_part_ids:
            k = 2
            while f"{part_id}__{k}" in seen_part_ids:
                k += 1
            part_id = f"{part_id}__{k}"
        seen_part_ids.add(part_id)

        row = panels_by_part.get(pid_base) or {}
        display_name = str(
            row.get('PanelName') or row.get('panelName') or
            row.get('Label') or row.get('label') or
            row.get('Name') or row.get('name') or
            pid_base
        ).strip() or pid_base
        display_name = (
            display_name
            .replace('Ã—', '×')
            .replace('â€“', '–')
            .replace('â€”', '—')
            .replace('Ã©', 'é')
            .replace('Ã‰', 'É')
            .replace('Ã¶', 'ö')
            .replace('Ã–', 'Ö')
        )

        part_mm = p.get('part_mm') or {}
        w = _as_int(part_mm.get('width_mm') or row.get('WidthMM') or row.get('Width') or row.get('width'))
        h = _as_int(part_mm.get('length_mm') or row.get('LengthMM') or row.get('HeightMM') or row.get('Height') or row.get('height'))
        t = _as_int(p.get('thicknessMm') or row.get('ThicknessMM') or row.get('Thickness') or row.get('thickness') or thickness_mm)
        if not w or not h or not t:
            continue

        rot = _rotation_0_90(p.get('rotation_deg') or p.get('rotationDeg') or p.get('rot') or 0)
        bbox_mm = p.get('bbox_mm') or {}
        bw = _as_int(bbox_mm.get('w_mm') or bbox_mm.get('w') or w)
        bh = _as_int(bbox_mm.get('h_mm') or bbox_mm.get('h') or h)
        if not bw or not bh:
            continue

        x = float(p.get('x_mm') or p.get('x') or 0.0)
        y = float(p.get('y_mm') or p.get('y') or 0.0)

        # placements.json uses origin bottom-left, y up.
        # Stickertool expects origin top-left, y down.
        x1 = x
        y1 = float(sheet_h) - (y + float(bh))
        x2 = x1 + float(bw)
        y2 = y1 + float(bh)
        if x1 < 0 or y1 < 0 or x2 <= x1 or y2 <= y1:
            continue

        sheet_index = int(p.get('sheetIndex') or 1)
        sheet_id = f"S{sheet_index:02d}"

        grain = str(row.get('Grain') or row.get('grain') or row.get('Nerf') or '').strip().lower()
        if grain not in ('vertical', 'horizontal'):
            grain = 'vertical'

        edges = p.get('edges') or {}
        edge_banding = {
            "top": bool(edges.get('H1')),
            "right": bool(edges.get('W2')),
            "bottom": bool(edges.get('H2')),
            "left": bool(edges.get('W1')),
        }

        items_out.append({
            "partId": part_id,
            "displayName": display_name,
            "qty": 1,
            "width": int(w),
            "height": int(h),
            "thickness": int(t),
            "grain": grain,
            "placement": {
                "sheetId": sheet_id,
                "bbox": [int(round(x1)), int(round(y1)), int(round(x2)), int(round(y2))],
                "rotation": int(rot),
            },
            "edgeBanding": {k: bool(v) for k, v in edge_banding.items() if bool(v)},
        })

    items_out.sort(key=lambda it: (str(it.get('displayName') or ''), str(it.get('partId') or '')))

    carry_out = bool((job_json.get("rest_material") or {}).get("carry_out")) if isinstance(job_json, dict) else False
    payload = {
        "schemaVersion": "2.0",
        "jobId": base_job_id,
        "subjobId": subjob_id,
        "customerName": customer_name,
        "materialCode": material_code or "",
        "materialDisplayName": material_display_name,
        "generatedAt": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        "optimizerVersionId": f"{OPTIMIZER_TOOL_B}::{STICKERTOOL_V2_BUILD}",
        "restMaterial": {
            "carryOut": carry_out,
            "labelText": ("Restmateriaal: JA" if carry_out else "Restmateriaal: NEE")
        },
        "sheets": sheets_out,
        "items": items_out,
    }
    if order_number:
        payload["orderNumber"] = order_number

    contract_path = output_dir / "stickertool.json"
    data_text = strict_json_dumps(payload, indent=2)
    _atomic_write_text(contract_path, data_text)
    return contract_path

def _rename_sheet_dxfs(job_root: Path):
    """Rename output sheet DXFs to include jobId, customer name and material.
    Format: <jobId>__<customer>__<material>__S<nn>.dxf
    """
    input_dir = job_root / "input"
    output_dir = job_root / "output"
    placements_path = output_dir / "placements.json"
    if not placements_path.exists():
        return
    try:
        placements = strict_json_load(placements_path)
    except Exception:
        with _SSE_CLIENTS_LOCK:
            try:
                _SSE_CLIENTS.remove(q)
            except ValueError:
                pass
        return

    job_json = {}
    job_json_path = input_dir / "job.json"
    if job_json_path.exists():
        try:
            job_json = strict_json_load(job_json_path)
        except Exception:
            job_json = {}

    job_id = str(placements.get("jobId") or job_root.name)
    customer_name = ""
    cust = (job_json.get("customer") or {})
    if isinstance(cust, dict):
        # Support both snake_case and camelCase keys
        fn = str(cust.get("first_name") or cust.get("firstName") or "").strip()
        ln = str(cust.get("last_name")  or cust.get("lastName")  or "").strip()
        customer_name = " ".join([fn, ln]).strip()
    if not customer_name:
        # fallback to older key names
        customer_name = str((job_json.get("order") or {}).get("customer_name") or "").strip()

    safe_job = _sanitize_filename(job_id, 40)
    safe_cust = _sanitize_filename(customer_name, 50)

    sheets_dir = output_dir / "sheets"
    if not sheets_dir.exists():
        return

    # If this job is a per-material subjob (panels.csv contains exactly 1 MaterialCode),
    # we can rename all sheet DXFs deterministically without relying on placements sheet metadata.
    # IMPORTANT: subjobs are contractually allowed to have ONLY job.json + panels.csv in /input.
    # So pricing.json may be absent. In that case we still include the material identity via
    # material_library.json (decor lookup) and/or the raw MaterialCode.
    single_mat_label = None
    try:
        panels_path = input_dir / "panels.csv"
        pricing_path = input_dir / "pricing.json"  # optional
        if panels_path.exists():
            _rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
            _codes = sorted({str(r.get("MaterialCode") or r.get("materialCode") or "").strip() for r in _rows
                             if str(r.get("MaterialCode") or r.get("materialCode") or "").strip()})
            if len(_codes) == 1:
                _code = _codes[0]
                _thick = ""
                _label_code = _code

                # If pricing.json is present (non-contract, but can exist in some builds),
                # use it to enrich thickness + decor label.
                if pricing_path.exists():
                    try:
                        _pricing = strict_json_load(pricing_path)
                        for _m in (_pricing.get("materials") or []):
                            if str(_m.get("materialCode") or "").strip() == _code:
                                _thick = _m.get("thicknessMm") or _m.get("thickness_mm") or _m.get("thickness") or ""
                                _label_code = _m.get("materialCode") or _code
                                # Prefer a human label if present; otherwise the code.
                                _human = _m.get("decorName") or _m.get("productName") or _m.get("name")
                                if _human:
                                    # _material_label_for_filename expects a code for library lookup; we pass the
                                    # material code and let the library resolve the decor when possible.
                                    _label_code = _code
                                break
                    except Exception:
                        pass

                # Always build a filename label from the (single) material code; decor is resolved via library lookup.
                single_mat_label = _material_label_for_filename(_code, _thick)
    except Exception:
        single_mat_label = None

    if single_mat_label:
        safe_mat = _sanitize_filename(single_mat_label, 80)
        files = list(sheets_dir.glob("*.dxf"))

        def _sheet_no(p: Path) -> int:
            try:
                mm = re.search(r"sheet[_\-\s]*0*([0-9]+)", p.name, flags=re.IGNORECASE)
                return int(mm.group(1)) if mm else 10**9
            except Exception:
                return 10**9

        for idx, f in enumerate(sorted(files, key=lambda p: (_sheet_no(p), p.name.lower())), start=1):
            new_name = f"{safe_cust}__{safe_mat}__S{idx:02d}.dxf"
            target = sheets_dir / new_name
            if f.name != target.name:
                if target.exists():
                    k = 2
                    while True:
                        target2 = sheets_dir / f"{safe_cust}__{safe_mat}__S{idx:02d}__{k}.dxf"
                        if not target2.exists():
                            target = target2
                            break
                        k += 1
                try:
                    f.rename(target)
                except Exception:
                    pass
        return


    # Build mapping from placements sheet entries to existing filenames
    sheets = placements.get("sheets") or []
    if not isinstance(sheets, list) or not sheets:
        # fallback: rename whatever exists without material
        for idx, f in enumerate(sorted(sheets_dir.glob("*.dxf")), start=1):
            new_name = f"{safe_cust}__S{idx:02d}.dxf"
            target = sheets_dir / new_name
            if f.name != target.name and not target.exists():
                f.rename(target)
        return

    for sh in sheets:
        try:
            sheet_idx = int(sh.get("index") or sh.get("sheetIndex") or sh.get("sheet") or 1)
        except Exception:
            sheet_idx = 1
        mat_code = sh.get("materialCode") or sh.get("material_code") or sh.get("material") or sh.get("materialName") or "Materiaal"
        thick = sh.get("thicknessMm") or sh.get("thickness_mm") or sh.get("thickness") or ""
        mat_str = _material_label_for_filename(mat_code, thick)
        safe_mat = _sanitize_filename(mat_str, 80)

        # locate source file
        src_name = sh.get("dxf") or sh.get("dxfFile") or sh.get("file") or sh.get("path")
        src_path = sheets_dir / str(src_name) if src_name else None
        if src_path and src_path.exists():
            src = src_path
        else:
            # fallback by index ordering
            candidates = sorted(sheets_dir.glob("*.dxf"))
            src = candidates[sheet_idx-1] if 0 <= sheet_idx-1 < len(candidates) else None
        if not src:
            continue

        new_name = f"{safe_cust}__{safe_mat}__S{sheet_idx:02d}.dxf"
        target = sheets_dir / new_name
        if src.name != target.name:
            # If a file with target name already exists, add suffix
            if target.exists():
                k = 2
                while True:
                    target2 = sheets_dir / f"{safe_cust}__{safe_mat}__S{sheet_idx:02d}__{k}.dxf"
                    if not target2.exists():
                        target = target2
                        break
                    k += 1
            try:
                src.rename(target)
            except Exception:
                pass

def _build_admin_dxf_exports(job_root: Path):
    """Create customer-friendly DXF export folders for Admin.

    output/DXF_Zaagplaten  -> renamed sheet DXFs (customer + decor + code + thickness + Sxx)
    output/DXF_Onderdelen  -> part DXFs (customer + partname)
    """
    input_dir = job_root / "input"
    output_dir = job_root / "output"
    sheets_src = output_dir / "sheets"
    if not output_dir.exists():
        return

    job_json = {}
    job_json_path = input_dir / "job.json"
    if job_json_path.exists():
        try:
            job_json = strict_json_load(job_json_path)
        except Exception:
            job_json = {}

    cust = (job_json.get("customer") or {})
    fn = ln = ""
    if isinstance(cust, dict):
        fn = str(cust.get("first_name") or cust.get("firstName") or "").strip()
        ln = str(cust.get("last_name")  or cust.get("lastName")  or "").strip()
    customer_name = " ".join([fn, ln]).strip()
    safe_cust = _sanitize_filename(customer_name, 50)

    # --- Zaagplaten ---
    out_sheets = output_dir / "DXF_Zaagplaten"
    out_sheets.mkdir(parents=True, exist_ok=True)

    # Tool B historically wrote sheets to output/sheets/*.dxf, but some versions or edge-cases may
    # output directly into output/ (e.g. sheet_1.dxf). Admin must be robust: show zaagplaten whenever
    # any sheet DXFs exist.
    sheet_sources = []

    # 1) canonical folder (RECURSIVE): output/sheets can contain nested folders in some Tool B versions.
    if sheets_src.exists():
        sheet_sources.extend(sorted(sheets_src.rglob("*.dxf")))
        sheet_sources.extend(sorted(sheets_src.rglob("*.DXF")))
        # Some environments/exporters may write DXF files without an extension (e.g. 'Sheet_001').
        # Include those as potential sheet sources as well.
        for f in sorted(sheets_src.rglob("*")):
            if f.is_file() and f.suffix == "" and f.name.lower().startswith("sheet"):
                sheet_sources.append(f)

    # 2) fallback: output root (non-recursive)
    sheet_sources.extend(sorted(output_dir.glob("sheet_*.dxf")))
    sheet_sources.extend(sorted(output_dir.glob("sheet_*.DXF")))
    sheet_sources.extend(sorted(output_dir.glob("Sheet_*.dxf")))
    sheet_sources.extend(sorted(output_dir.glob("Sheet_*.DXF")))

    # 3) last resort: recursive search under output/ for anything that looks like a sheet,
    # excluding the export folders themselves to avoid loops/dupes.
    for f in sorted(output_dir.rglob("*.dxf")) + sorted(output_dir.rglob("*.DXF")):
        try:
            rel = f.relative_to(output_dir).as_posix().lower()
        except Exception:
            rel = str(f).lower()
        if rel.startswith("dxf_zaagplaten/") or rel.startswith("dxf_onderdelen/"):
            continue
        n = f.name.lower()
        if (
            n.startswith("sheet_") or n.startswith("sheet") or
            n.startswith("plaat") or n.startswith("zaag") or
            "__s" in n
        ):
            sheet_sources.append(f)


    # 4) extra fallback: suffix-less sheet files anywhere under output/
    for f in sorted(output_dir.rglob("*")):
        try:
            rel = f.relative_to(output_dir).as_posix().lower()
        except Exception:
            rel = str(f).lower()
        if rel.startswith("dxf_zaagplaten/") or rel.startswith("dxf_onderdelen/"):
            continue
        if f.is_file() and f.suffix == "" and f.name.lower().startswith("sheet"):
            sheet_sources.append(f)

    # Deduplicate while preserving deterministic order.
    # Several glob patterns above can match the same file.
    _seen = set()
    _uniq = []
    for f in sheet_sources:
        try:
            key = str(f.resolve())
        except Exception:
            key = str(f)
        if key in _seen:
            continue
        _seen.add(key)
        _uniq.append(f)
    # Sort by filename for determinism across platforms/filesystems.
    sheet_sources = sorted(_uniq, key=lambda p: p.name.lower())

    # Copy/rename into export folder.
    # IMPORTANT: always include material identity in the exported sheet names.
    # Some Tool B versions write sheets to output/sheets/, others directly into output/.
    # We derive the material label from panels.csv (preferred) or placements.json sheets metadata.
    mat_label = None
    try:
        # 1) panels.csv -> single MaterialCode
        panels_path = input_dir / "panels.csv"
        if panels_path.exists():
            _rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
            _codes = sorted({str(r.get("MaterialCode") or r.get("materialCode") or "").strip() for r in _rows
                             if str(r.get("MaterialCode") or r.get("materialCode") or "").strip()})
            if len(_codes) == 1:
                mat_label = _material_label_for_filename(_codes[0], "")
    except Exception:
        mat_label = None

    if not mat_label:
        try:
            # 2) placements.json -> sheets metadata
            placements_path = _find_placements_any(output_dir) or (output_dir / "placements.json")
            if placements_path and placements_path.exists():
                _pl = strict_json_load(placements_path)
                _sh = (_pl.get("sheets") or [])
                if isinstance(_sh, list) and _sh:
                    _code = str((_sh[0].get("materialCode") or "")).strip()
                    _th = _sh[0].get("thicknessMm") or ""
                    if _code:
                        mat_label = _material_label_for_filename(_code, _th)
        except Exception:
            mat_label = None

    safe_mat = _sanitize_filename(mat_label or "materiaal_onbekend", 80)

    # Determine sheet indices deterministically by sorted discovery order.
    # We always export as <customer>__<material>__Sxx.dxf
    for i, f in enumerate(sheet_sources, start=1):
        name = f"{safe_cust}__{safe_mat}__S{i:02d}.dxf" if safe_cust else f"{safe_mat}__S{i:02d}.dxf"
        target = out_sheets / name
        if not target.exists():
            try:
                _link_or_copy_file(f, target)
            except Exception:
                pass

    # --- Onderdelen ---
    parts_src = None
    for cand in ["dxf_parts", "parts", "input_parts"]:
        p = input_dir / cand
        if p.exists():
            parts_src = p
            break
    out_parts = output_dir / "DXF_Onderdelen"
    out_parts.mkdir(parents=True, exist_ok=True)
    if parts_src and parts_src.exists():
        for f in sorted(parts_src.glob("*.dxf")):
            base = _sanitize_filename(f.stem, 90)
            target = out_parts / f"{safe_cust}__{base}.dxf"
            if not target.exists():
                try:
                    _link_or_copy_file(f, target)
                except Exception:
                    pass


def _placements_item_count(placements_obj) -> int:
    try:
        if isinstance(placements_obj, dict):
            top = placements_obj.get('placements')
            if isinstance(top, list):
                return len(top)
            total = 0
            for sh in (placements_obj.get('sheets') or []):
                if isinstance(sh, dict) and isinstance(sh.get('placements'), list):
                    total += len(sh.get('placements') or [])
            return total
        if isinstance(placements_obj, list):
            return len(placements_obj)
    except Exception:
        pass
    return 0


def _generate_labels_json_strict(job_root: Path) -> Path:
    input_dir = Path(job_root) / 'input'
    output_dir = Path(job_root) / 'output'
    placements_obj = strict_json_load(output_dir / 'placements.json')
    rows = _parse_panels_csv((input_dir / 'panels.csv').read_text(encoding='utf-8', errors='strict'))
    job_json = strict_json_load(input_dir / 'job.json')
    placements = placements_obj.get('placements') if isinstance(placements_obj, dict) else None
    if not isinstance(placements, list):
        raise SafetyContractError('placements.json has no placements list')
    rows_by_id = {str(row['PartId']): row for row in rows}
    labels = []
    identities = set()
    for placement in placements:
        if not isinstance(placement, dict):
            raise SafetyContractError('placement must be an object')
        part_id = str(placement.get('partId') or '')
        row = rows_by_id.get(part_id)
        if row is None:
            raise SafetyContractError(f'placement references unknown PartId {part_id}')
        instance = int(finite_number(placement.get('instanceIndex'), field=f'{part_id}.instanceIndex', minimum=1, maximum=10000))
        identity = (part_id, instance)
        if identity in identities:
            raise SafetyContractError(f'duplicate placement label identity {part_id}/{instance}')
        identities.add(identity)
        rotation = int(finite_number(placement.get('rotation_deg'), field=f'{part_id}.rotation_deg', minimum=0, maximum=270))
        if rotation not in {0, 90, 180, 270}:
            raise SafetyContractError(f'{part_id}: invalid label rotation')
        x = finite_number(placement.get('x_mm'), field=f'{part_id}.x_mm', minimum=0, maximum=10000)
        y = finite_number(placement.get('y_mm'), field=f'{part_id}.y_mm', minimum=0, maximum=10000)
        bbox = placement.get('bbox_mm') if isinstance(placement.get('bbox_mm'), dict) else {}
        bbox_w = finite_number(bbox.get('w_mm'), field=f'{part_id}.bbox.w', minimum=0.1, maximum=10000)
        bbox_h = finite_number(bbox.get('h_mm'), field=f'{part_id}.bbox.h', minimum=0.1, maximum=10000)
        label_id = f'{part_id}-{instance}'
        labels.append({
            'label_id': label_id,
            'panel_id': part_id,
            'instance': instance,
            'panel_name': str(row.get('PanelName') or part_id),
            'length_mm': float(row['LengthMm']),
            'width_mm': float(row['WidthMm']),
            'thickness_mm': float(row['ThicknessMm']),
            'grain_group': str(row.get('GrainGroup') or ''),
            'edges': {key: int(row[key]) for key in ('H1', 'H2', 'W1', 'W2')},
            'barcode_type': 'QR',
            'barcode_value': f"{PUBLIC_BASE_URL.rstrip('/')}/m/{job_root.name}/{label_id}",
            'placement': {
                'sheet_index': int(placement.get('sheetIndex') or 0),
                'origin': 'bottom-left',
                'y_axis': 'up',
                'x_mm': x,
                'y_mm': y,
                'bbox_mm': [x, y, x + bbox_w, y + bbox_h],
                'rotation_deg': rotation,
            },
        })
    expected = {(str(row['PartId']), index) for row in rows for index in range(1, int(row['Qty']) + 1)}
    if identities != expected:
        raise SafetyContractError('labels do not match requested panel instances')
    result = {
        'schema_version': 2,
        'build': 'FIX660R8',
        'units': 'mm',
        'job_id': job_root.name,
        'customer': job_json.get('customer') if isinstance(job_json.get('customer'), dict) else {},
        'note': str(job_json.get('note') or ''),
        'rest_material': {
            'carry_out': bool((job_json.get('rest_material') or {}).get('carry_out')),
        },
        'sheets': placements_obj.get('sheets') or [],
        'labels': labels,
    }
    target = output_dir / 'labels.json'
    durable_write_json(target, result)
    return target


def _finalize_subjob_outputs_legacy_unused(job_root: Path) -> dict:
    """Create and verify every production/Admin output for one optimizer subjob.

    A completed optimizer process is not enough: FIX654 introduces an explicit,
    atomic finalization contract so Tool A cannot wait forever on a best-effort text
    summary and Admin never silently misses DXF/StickerTool files.
    """
    job_root = Path(job_root)
    output_dir = job_root / 'output'
    output_dir.mkdir(parents=True, exist_ok=True)
    result = {
        'schemaVersion': 1,
        'build': 'FIX654_OUTPUT_PIPELINE_AUDIT',
        'jobId': job_root.name,
        'state': 'FINALIZING',
        'startedAt': _utc_now_iso(),
        'errors': [],
        'warnings': [],
        'counts': {},
    }
    final_path = output_dir / 'finalization.json'
    try:
        placements_path = _find_placements_any(output_dir) or (output_dir / 'placements.json')
        report_path = output_dir / 'report.json'
        quote_path = output_dir / 'quote.json'
        for fp, label in ((placements_path, 'placements.json'), (report_path, 'report.json'), (quote_path, 'quote.json')):
            if fp is None or not Path(fp).exists():
                result['errors'].append(f'Kernoutput ontbreekt: {label}')

        placements_obj = {}
        if placements_path is not None and Path(placements_path).exists():
            try:
                placements_obj = strict_json_load(Path(placements_path))
            except Exception as e:
                result['errors'].append(f'placements.json kon niet worden gelezen: {e}')
        placement_count = _placements_item_count(placements_obj)
        result['counts']['placements'] = placement_count

        if not result['errors']:
            try:
                _generate_labels_json(job_root)
            except Exception as e:
                result['warnings'].append(f'labels.json: {e}')
            try:
                _generate_stickertool_json(job_root)
            except Exception as e:
                result['errors'].append(f'StickerTool genereren mislukt: {e}')
                try:
                    durable_write_text(output_dir / 'stickers_error.txt', str(e), mode=0o640)
                except Exception:
                    pass
            try:
                _rename_sheet_dxfs(job_root)
                _build_admin_dxf_exports(job_root)
            except Exception as e:
                result['errors'].append(f'DXF-export postprocessing mislukt: {e}')

            # Calculation summary is required for the authoritative public price. If
            # it fails we return ERROR instead of an infinite PROCESSING state.
            try:
                _write_human_calculation_summary(job_root)
            except Exception as e:
                result['errors'].append(f'Berekeningsoverzicht genereren mislukt: {e}')

        sheet_dxfs = []
        zaag = output_dir / 'DXF_Zaagplaten'
        if zaag.exists():
            sheet_dxfs = sorted([p for p in zaag.rglob('*') if p.is_file() and p.suffix.lower() == '.dxf'])
        result['counts']['sheetDxfs'] = len(sheet_dxfs)

        sticker_file = output_dir / 'stickertool.json'
        sticker_items = 0
        if sticker_file.exists():
            try:
                st = strict_json_load(sticker_file)
                sticker_items = len(st.get('items') or []) if isinstance(st, dict) else 0
                if placement_count > 0 and sticker_items <= 0:
                    result['errors'].append('StickerTool bevat geen items terwijl er wel placements zijn.')
                if isinstance(st, dict) and not str(st.get('materialCode') or '').strip():
                    result['errors'].append('StickerTool mist intern materialCode.')
            except Exception as e:
                result['errors'].append(f'StickerTool-validatie mislukt: {e}')
        elif placement_count > 0:
            result['errors'].append('stickertool.json ontbreekt.')
        result['counts']['stickerItems'] = sticker_items

        # At least one sheet DXF is required if Tool B reports sheets.
        expected_sheets = 0
        try:
            expected_sheets = len((placements_obj.get('sheets') or [])) if isinstance(placements_obj, dict) else 0
        except Exception:
            expected_sheets = 0
        result['counts']['expectedSheets'] = expected_sheets
        if expected_sheets > 0 and not sheet_dxfs:
            result['errors'].append('Geen DXF-zaagplaten gevonden na succesvolle optimalisatie.')

        has_summary = (output_dir / 'calculation_summary.txt').exists() or (job_root / 'calculation_summary.txt').exists() or (job_root / 'input' / 'calculation_summary.txt').exists()
        result['counts']['calculationSummary'] = 1 if has_summary else 0
        if not has_summary:
            result['errors'].append('Definitief berekeningsoverzicht ontbreekt.')

        result['state'] = 'COMPLETE' if not result['errors'] else 'ERROR'
        result['finishedAt'] = _utc_now_iso()
        _atomic_write_json(final_path, result)
        if result['errors']:
            raise RuntimeError('; '.join(result['errors'][:6]))
        return result
    except Exception as e:
        if result.get('state') != 'ERROR':
            result['state'] = 'ERROR'
            result['errors'].append(str(e))
            result['finishedAt'] = _utc_now_iso()
            try:
                _atomic_write_json(final_path, result)
            except Exception:
                pass
        raise


def _finalize_subjob_outputs(job_root: Path) -> dict:
    """Verify optimizer evidence and atomically publish a complete subjob manifest."""

    job_root = Path(job_root)
    validate_job_id(job_root.name)
    if job_root.resolve().parent != JOBS.resolve():
        raise SafetyContractError('Subjob root is outside the fixed jobs root')
    input_dir = job_root / 'input'
    output_dir = job_root / 'output'
    final_path = output_dir / 'finalization.json'
    result: dict[str, Any] = {
        'schemaVersion': 2,
        'build': 'FIX660R8_PRELIVE_HARDENED',
        'jobId': job_root.name,
        'state': 'FINALIZING',
        'startedAt': _utc_now_iso(),
        'errors': [],
    }
    try:
        report_path = output_dir / 'report.json'
        optimizer_manifest_path = output_dir / 'optimizer_manifest.json'
        placements_path = output_dir / 'placements.json'
        quote_path = output_dir / 'quote.json'
        for path in (report_path, optimizer_manifest_path, placements_path, quote_path):
            if not path.is_file() or path.stat().st_size <= 0:
                raise SafetyContractError(f'Required optimizer artifact missing: {path.name}')

        report = strict_json_load(report_path)
        optimizer_manifest = strict_json_load(optimizer_manifest_path)
        placements_obj = strict_json_load(placements_path)
        strict_json_load(quote_path)
        if not isinstance(report, dict) or report.get('ok') is not True:
            raise SafetyContractError('Optimizer report is not an explicit success')
        if report.get('optimizerManifestSha256') != sha256_file(optimizer_manifest_path):
            raise SafetyContractError('Optimizer manifest hash does not match report')
        if not isinstance(optimizer_manifest, dict) or optimizer_manifest.get('release') != 'FIX660R8':
            raise SafetyContractError('Unexpected optimizer manifest release')

        def verify_hashes(root: Path, mapping: Any, label: str) -> dict[str, str]:
            if not isinstance(mapping, dict) or not mapping:
                raise SafetyContractError(f'{label} hash map is empty')
            verified: dict[str, str] = {}
            for relative, expected in sorted(mapping.items()):
                path = resolve_relative_file(root, str(relative))
                if not path.is_file():
                    raise SafetyContractError(f'{label} file missing: {relative}')
                actual = sha256_file(path)
                if not hmac.compare_digest(actual, str(expected)):
                    raise SafetyContractError(f'{label} hash mismatch: {relative}')
                verified[str(relative)] = actual
            return verified

        verified_inputs = verify_hashes(input_dir, optimizer_manifest.get('inputsSha256'), 'input')
        verified_outputs = verify_hashes(output_dir, optimizer_manifest.get('outputsSha256'), 'output')

        rows = _parse_panels_csv((input_dir / 'panels.csv').read_text(encoding='utf-8', errors='strict'))
        placements = placements_obj.get('placements') if isinstance(placements_obj, dict) else None
        if not isinstance(placements, list):
            raise SafetyContractError('placements.json has no placements list')
        expected_identities = {
            (str(row['PartId']), index)
            for row in rows
            for index in range(1, int(row['Qty']) + 1)
        }
        actual_identities = {
            (str(item.get('partId') or ''), int(item.get('instanceIndex') or 0))
            for item in placements
            if isinstance(item, dict)
        }
        if len(actual_identities) != len(placements) or actual_identities != expected_identities:
            raise SafetyContractError('Final placements do not exactly match requested instances')

        manifest_counts = optimizer_manifest.get('counts') if isinstance(optimizer_manifest.get('counts'), dict) else {}
        expected_sheets = int(manifest_counts.get('productionSheets') or 0)
        if expected_sheets <= 0:
            raise SafetyContractError('Optimizer manifest reports no production sheets')
        sheet_files = sorted((output_dir / 'sheets').glob('*.dxf'))
        mirrored_sheets = sorted((output_dir / 'DXF_Zaagplaten').glob('*.dxf'))
        if len(sheet_files) != expected_sheets or len(mirrored_sheets) != expected_sheets:
            raise SafetyContractError('Exact sheet DXF count mismatch')
        if len(report.get('sheetValidation') or []) != expected_sheets:
            raise SafetyContractError('Sheet geometry validation evidence count mismatch')

        parts_export = output_dir / 'DXF_Onderdelen'
        parts_export.mkdir(parents=True, exist_ok=True)
        expected_part_names = {f"{row['PartId']}.dxf" for row in rows}
        existing_part_names = {path.name for path in parts_export.glob('*.dxf')}
        if existing_part_names - expected_part_names:
            raise SafetyContractError('Unexpected file in DXF_Onderdelen')
        for row in rows:
            part_name = f"{row['PartId']}.dxf"
            source = resolve_relative_file(input_dir, f'dxf_parts/{part_name}')
            destination = parts_export / part_name
            durable_copy_file(source, destination)
            if sha256_file(source) != sha256_file(destination):
                raise SafetyContractError(f'{part_name}: DXF_Onderdelen hash mismatch')

        labels_path = _generate_labels_json_strict(job_root)
        _generate_stickertool_json(job_root)
        stickertool_path = output_dir / 'stickertool.json'
        labels_obj = strict_json_load(labels_path)
        sticker_obj = strict_json_load(stickertool_path)
        label_count = len(labels_obj.get('labels') or []) if isinstance(labels_obj, dict) else 0
        sticker_items = sticker_obj.get('items') if isinstance(sticker_obj, dict) else None
        sticker_count = len(sticker_items) if isinstance(sticker_items, list) else 0
        if label_count != len(expected_identities) or sticker_count != len(expected_identities):
            raise SafetyContractError('Label/StickerTool count does not match requested instances')
        expected_sticker_ids = {f'{part_id}__{instance}' for part_id, instance in expected_identities}
        actual_sticker_ids = {
            str(item.get('partId') or '')
            for item in sticker_items
            if isinstance(item, dict)
        }
        if len(actual_sticker_ids) != sticker_count or actual_sticker_ids != expected_sticker_ids:
            raise SafetyContractError('StickerTool identities do not exactly match requested instances')
        material_codes = {
            str(row.get('MaterialCode') or '').strip()
            for row in rows
            if str(row.get('MaterialCode') or '').strip()
        }
        if len(material_codes) != 1 or str(sticker_obj.get('materialCode') or '').strip() not in material_codes:
            raise SafetyContractError('StickerTool material does not match the subjob input')

        _write_human_calculation_summary(job_root)
        summary_path = output_dir / 'calculation_summary.txt'
        if not summary_path.is_file() or summary_path.stat().st_size <= 0:
            raise SafetyContractError('Authoritative calculation summary is missing')

        production_paths = (
            [report_path, optimizer_manifest_path, placements_path, quote_path, labels_path, stickertool_path, summary_path]
            + sheet_files
            + mirrored_sheets
            + sorted(parts_export.glob('*.dxf'))
        )
        artifact_hashes = {
            path.relative_to(output_dir).as_posix(): sha256_file(path)
            for path in sorted(set(production_paths), key=lambda item: item.as_posix())
        }
        result.update({
            'state': 'COMPLETE',
            'finishedAt': _utc_now_iso(),
            'counts': {
                'panelRows': len(rows),
                'instances': len(expected_identities),
                'placements': len(placements),
                'sheetDxfs': len(sheet_files),
                'mirroredSheetDxfs': len(mirrored_sheets),
                'partDxfs': len(expected_part_names),
                'labels': label_count,
                'stickerItems': sticker_count,
            },
            'optimizerManifestSha256': sha256_file(optimizer_manifest_path),
            'verifiedInputHashes': verified_inputs,
            'verifiedOptimizerOutputHashes': verified_outputs,
            'artifactsSha256': artifact_hashes,
        })
        durable_write_json(final_path, result)
        return result
    except Exception as exc:
        result.update({
            'state': 'ERROR',
            'finishedAt': _utc_now_iso(),
            'errors': [str(exc)[:1000]],
        })
        durable_write_json(final_path, result)
        raise


def _write_master_job_links(master_job_id: str, subjobs: list[dict]) -> None:
    """Persist the private parent/subjob relation atomically for Admin recovery."""
    master_job_id = validate_job_id(master_job_id)
    root = resolve_identifier_child(JOBS, master_job_id)
    clean_subjobs = []
    for item in subjobs or []:
        if not isinstance(item, dict):
            raise SafetyContractError('Invalid subjob link')
        subjob_id = validate_job_id(item.get('subjobId') or item.get('jobId'))
        resolve_identifier_child(JOBS, subjob_id)
        clean_subjobs.append({
            'subjobId': subjob_id,
            'status': str(item.get('status') or ''),
            'outputsReady': bool(item.get('outputsReady')),
        })
    durable_write_json(root / 'output' / 'links.json', {
        'schemaVersion': 2,
        'build': 'FIX660R8_PRELIVE_HARDENED',
        'parentJobId': master_job_id,
        'subjobs': clean_subjobs,
        'updatedAt': _utc_now_iso(),
    })


def _finalization_complete(job_root: Path) -> bool:
    try:
        root = Path(job_root).resolve()
        if root.parent != JOBS.resolve():
            return False
        validate_job_id(root.name)
        # A cancellation is authoritative for the complete job family.  Partial or
        # previously finalized files remain on disk for forensic recovery, but they
        # must never become downloadable production output after cancellation.
        master_job_id = root.name.split('__mat_', 1)[0]
        master_state = str(_load_job_runtime_state(master_job_id).get('state') or '').upper()
        if master_state in {'CANCEL_REQUESTED', 'CANCELLED'}:
            return False
        output_root = root / 'output'
        p = output_root / 'finalization.json'
        if not p.exists():
            return False
        d = strict_json_load(p)
        if not isinstance(d, dict) or str(d.get('state') or '').upper() != 'COMPLETE':
            return False
        if d.get('kind') == 'master':
            linked = d.get('subjobFinalizationsSha256')
            if not isinstance(linked, dict) or not linked:
                return False
            for subjob_id, expected_hash in linked.items():
                subjob_root = resolve_identifier_child(JOBS, str(subjob_id))
                subjob_final = subjob_root / 'output' / 'finalization.json'
                if not _finalization_complete(subjob_root):
                    return False
                if not hmac.compare_digest(sha256_file(subjob_final), str(expected_hash)):
                    return False
        else:
            manifest_path = output_root / 'optimizer_manifest.json'
            if d.get('optimizerManifestSha256') != sha256_file(manifest_path):
                return False
        artifacts = d.get('artifactsSha256')
        if not isinstance(artifacts, dict) or not artifacts:
            return False
        for relative, expected_hash in artifacts.items():
            artifact = resolve_relative_file(output_root, str(relative))
            if not artifact.is_file() or not hmac.compare_digest(sha256_file(artifact), str(expected_hash)):
                return False
        return True
    except Exception:
        return False


def _sealed_output_artifacts(job_root: Path) -> dict[str, Path]:
    """Return only output files covered by a valid finalization hash manifest."""
    try:
        root = Path(job_root).resolve()
        if not _finalization_complete(root):
            return {}
        output_root = root / 'output'
        finalization = strict_json_load(output_root / 'finalization.json')
        artifacts = finalization.get('artifactsSha256') if isinstance(finalization, dict) else None
        if not isinstance(artifacts, dict) or not artifacts:
            return {}
        sealed: dict[str, Path] = {}
        for relative, expected_hash in artifacts.items():
            relative = str(relative)
            path = resolve_relative_file(output_root, relative)
            if not path.is_file() or not hmac.compare_digest(sha256_file(path), str(expected_hash)):
                return {}
            sealed[f'output/{relative}'] = path
        return sealed
    except Exception:
        return {}

ADMIN_HTML = """<!doctype html>
<html lang=\"nl\"><head>
<meta charset=\"utf-8\" />
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
<title>METOD Admin</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial; background:#0f1314; color:#e8f3ee; margin:0;}
  header{padding:16px 18px; border-bottom:1px solid rgba(255,255,255,.08); display:flex; gap:12px; align-items:center;}
  h1{font-size:16px; margin:0; letter-spacing:.2px;}
  main{padding:18px;}
  .card{background:#141a1c; border:1px solid rgba(255,255,255,.08); border-radius:14px; padding:14px; margin-bottom:12px;}
  .row{display:flex; gap:12px; flex-wrap:wrap; align-items:center; justify-content:space-between;}
  .muted{color:rgba(232,243,238,.7); font-size:12px;}
  button,a.btn{background:#2fbf6a; border:0; color:#08110b; padding:10px 12px; border-radius:10px; font-weight:700; cursor:pointer; text-decoration:none; display:inline-block;}
  button.secondary{background:rgba(255,255,255,.08); color:#e8f3ee; font-weight:600;}
  table{width:100%; border-collapse:collapse; font-size:13px;}
  th,td{padding:8px 10px; border-bottom:1px solid rgba(255,255,255,.08); text-align:left;}
  td.outputsTd{vertical-align:top;}
  .outputsCell{display:flex; justify-content:flex-end; align-items:flex-start;}
  .outputsCell > *{max-width:100%;}
  code{background:rgba(255,255,255,.08); padding:2px 6px; border-radius:8px;}
  details{margin-top:6px;}
  summary{cursor:pointer; user-select:none;}
  summary::-webkit-details-marker{display:none;}
  summary::marker{content:'';}

  details.jobOut{display:inline-block;}
  details.jobOut > summary{
    list-style:none;
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:8px 10px;
    border-radius:10px;
    background:rgba(255,255,255,.06);
    border:1px solid rgba(255,255,255,.10);
    color:#e8f3ee;
    font-weight:800;
    width:fit-content;
  }
  details.jobOut[open] > summary{background:rgba(47,191,106,.18); border-color:rgba(47,191,106,.35);}
  .jobOutBody{margin-top:8px;}

  .groupToggle{background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.12); color:#e8f3ee; font-weight:900; border-radius:10px; padding:6px 8px; cursor:pointer;}
  .groupToggle:hover{background:rgba(255,255,255,.12);}
  tr.childRow{display:none;}
  tr.childRow td{opacity:0.98;}
  tr.childRow td:first-child .arrow{color:rgba(232,243,238,.65); margin-right:6px;}
  tr.childRow td:first-child .jobIndent{display:inline-flex; align-items:center; gap:6px; padding-left:18px;}
  details.jobOut.zaagHi > summary{background:rgba(47,191,106,.22); border-color:rgba(47,191,106,.45);}
  tr.childRow.zaagRow td:first-child{box-shadow: inset 3px 0 0 rgba(47,191,106,.9);}


  /* Mailbox (requests) */
  .tabs{display:flex; gap:6px; flex-wrap:wrap;}
  .tabBtn{border:1px solid rgba(0,0,0,.12); background:#fff; padding:6px 10px; border-radius:999px; cursor:pointer; font-weight:700;}
  .tabBtn.active{box-shadow: inset 0 0 0 2px rgba(47,191,106,.35); border-color:rgba(47,191,106,.45);}
  .dot{width:10px; height:10px; border-radius:50%; display:inline-block;}
  .dot.green{background:rgba(47,191,106,.95);}
  .dot.red{background:rgba(214,69,69,.95);}
  .dot.blue{background:rgba(64,120,240,.95);}
  .dot.yellow{background:rgba(245,178,37,.95);}
  .dot.gray{background:rgba(140,140,140,.95);}
  tr.mbRow{cursor:pointer;}
  tr.mbRow:hover{background:rgba(255,255,255,.03);}
  .mbDetailsCard{margin-top:14px; border:1px solid rgba(255,255,255,.08); border-radius:16px; background:linear-gradient(180deg, rgba(255,255,255,.025), rgba(255,255,255,.012)); overflow:hidden;}
  .mbDetailsHead{padding:12px 14px; border-bottom:1px solid rgba(255,255,255,.06); display:flex; align-items:center; justify-content:space-between; gap:12px;}
  .mbDetailsBody{padding:14px;}
  .mbInfoGrid{display:grid; grid-template-columns:repeat(auto-fit, minmax(220px,1fr)); gap:12px;}
  .mbInfoCard{border:1px solid rgba(255,255,255,.08); background:rgba(255,255,255,.025); border-radius:14px; padding:12px;}
  .mbLabel{font-size:11px; letter-spacing:.04em; text-transform:uppercase; color:rgba(232,243,238,.62); font-weight:800; margin-bottom:6px;}
  .mbValue{font-size:14px; font-weight:700; color:#e8f3ee;}
  .mbValue.mono{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; font-size:12px;}
  .mbBadgeRow{display:flex; gap:8px; flex-wrap:wrap; margin-top:2px;}
  .mbBadge{display:inline-flex; align-items:center; gap:6px; border-radius:999px; padding:4px 10px; font-size:12px; font-weight:800; border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.05);}
  .mbBadge.green{background:rgba(47,191,106,.12); border-color:rgba(47,191,106,.28); color:#d9f7e4;}
  .mbBadge.blue{background:rgba(64,120,240,.12); border-color:rgba(64,120,240,.28); color:#dce7ff;}
  .mbBadge.yellow{background:rgba(245,178,37,.14); border-color:rgba(245,178,37,.28); color:#fff0c8;}
  .mbBadge.red{background:rgba(214,69,69,.14); border-color:rgba(214,69,69,.28); color:#ffd8d8;}
  .mbBadge.gray{background:rgba(255,255,255,.06); border-color:rgba(255,255,255,.12); color:#d8dee1;}
  .mbSectionTitle{font-weight:900; margin-top:14px; margin-bottom:8px;}
  .mbFileGrid{display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;}
  .mbPill, .mbFileGrid a.pill, .mbFileLine a.pill, .mbActionBtn{display:inline-flex; align-items:center; justify-content:center; min-height:28px; padding:0 11px; border-radius:9px; border:1px solid rgba(255,255,255,.14); background:rgba(255,255,255,.055); color:#e8f3ee; font-size:12px; font-weight:800; text-decoration:none; white-space:nowrap; transition:all .15s ease;}
  .mbPill:hover, .mbFileGrid a.pill:hover, .mbFileLine a.pill:hover, .mbActionBtn:hover{background:rgba(47,191,106,.12); border-color:rgba(47,191,106,.32); transform:translateY(-1px);}
  .mbActionBtn{background:rgba(47,191,106,.14); border-color:rgba(47,191,106,.28); color:#ddf8e6; cursor:pointer;}
  .mbActionBtn[disabled]{opacity:.55; pointer-events:none; transform:none;}
  .mbFileGroup{margin-top:10px; border:1px solid rgba(255,255,255,.06); border-radius:14px; overflow:hidden;}
  .mbFileGroupHead{padding:10px 12px; background:rgba(255,255,255,.03); font-weight:800;}
  .mbFileLine{display:flex; justify-content:space-between; gap:12px; align-items:center; padding:10px 12px; border-top:1px dashed rgba(255,255,255,.08);}
  .mbFileMeta{font-size:12px; opacity:.8;}
  .mbPriceCard{margin-top:10px; border:1px solid rgba(255,255,255,.08); background:rgba(255,255,255,.03); border-radius:14px; padding:12px;}
  .mbPriceRow{display:flex; align-items:center; justify-content:space-between; gap:12px; padding:7px 0; border-top:1px dashed rgba(255,255,255,.08);}
  .mbPriceRow:first-child{border-top:none; padding-top:0;}
  .mbPriceRow:last-child{padding-bottom:0;}
  .mbPriceRow span{color:rgba(232,243,238,.82); font-size:13px;}
  .mbPriceRow strong{color:#f6fbf8; font-size:13px;}
  .mbPriceRow.emph span,.mbPriceRow.emph strong{font-weight:900; font-size:14px; color:#fff;}

  .adminShell{display:grid; grid-template-columns:76px minmax(0,1fr); gap:18px; align-items:start;}
  .adminRail{position:sticky; top:18px; display:flex; flex-direction:column; gap:10px; padding:10px 8px; border:1px solid rgba(255,255,255,.08); border-radius:18px; background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));}
  .adminNavBtn{display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; min-height:66px; border-radius:16px; border:1px solid rgba(255,255,255,.10); background:rgba(255,255,255,.03); color:#dfeae4; cursor:pointer; transition:all .18s ease; padding:8px 6px;}
  .adminNavBtn:hover{transform:translateY(-1px); border-color:rgba(47,191,106,.24); background:rgba(47,191,106,.08);}
  .adminNavBtn.active{background:rgba(47,191,106,.14); border-color:rgba(47,191,106,.34); box-shadow:inset 3px 0 0 rgba(47,191,106,.9);}
  .adminNavIcon{font-size:18px; line-height:1;}
  .adminNavLabel{font-size:11px; font-weight:800; letter-spacing:.01em; text-align:center;}
  .adminPages{min-width:0; display:grid; gap:16px;}
  .adminSection{display:none;}
  .adminSection.active{display:block;}
  .adminSectionTitle{font-size:18px; font-weight:900; margin-bottom:6px;}
  .adminSectionIntro{color:rgba(232,243,238,.7); margin-bottom:12px;}
  .pricingShell{display:grid; gap:14px;}
  .pricingHero{display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap;}
  .pricingHeroMeta{display:flex; gap:8px; flex-wrap:wrap; align-items:center;}
  .pricingTag{display:inline-flex; align-items:center; gap:6px; border-radius:999px; padding:6px 10px; font-size:12px; font-weight:800; border:1px solid rgba(47,191,106,.24); background:rgba(47,191,106,.10); color:#dff7e7;}
  .pricingGrid{display:grid; grid-template-columns:repeat(auto-fit, minmax(260px,1fr)); gap:14px;}
  .pricingCard{border:1px solid rgba(255,255,255,.08); border-radius:18px; background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015)); padding:16px;}
  .pricingCard h3{margin:0 0 6px 0; font-size:16px; font-weight:900;}
  .pricingCard p{margin:0 0 14px 0; color:rgba(232,243,238,.72); font-size:13px;}
  .pricingFields{display:grid; gap:12px;}
  .pricingField label{display:block; font-size:12px; font-weight:800; color:rgba(232,243,238,.78); margin-bottom:6px;}
  .pricingField input,.pricingField select,.pricingField textarea{width:100%; box-sizing:border-box; padding:11px 12px; border-radius:12px; border:1px solid rgba(255,255,255,.12); background:#0f1518; color:#e8f3ee; font-size:14px;}
  .pricingField .help{margin-top:5px; font-size:11px; color:rgba(232,243,238,.55);}
  .pricingActions{display:flex; gap:10px; flex-wrap:wrap; align-items:center;}
  .pricingStatusLine{font-size:12px; color:rgba(232,243,238,.72); min-height:18px;}
  .materialsGrid{display:grid; grid-template-columns:minmax(320px, 420px) minmax(480px, 1fr); gap:18px; align-items:start;}
  .materialsListCard,.materialsDetailCard{border:1px solid rgba(255,255,255,.08); border-radius:20px; background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015)); padding:16px;}
  .materialsList{display:grid; gap:10px; max-height:70vh; overflow:auto; padding-right:4px;}
  .materialsRow{border:1px solid rgba(255,255,255,.08); border-radius:14px; background:#0f1518; padding:12px 13px; cursor:pointer; transition:.15s ease; color:#e8f3ee; text-align:left; appearance:none; -webkit-appearance:none;}
  .materialsRow:hover{border-color:rgba(62,201,120,.45); transform:translateY(-1px);}
  .materialsRow.active{border-color:#3ec978; box-shadow:0 0 0 1px rgba(62,201,120,.25) inset;}
  .materialsRowTitle{font-weight:900; font-size:14px; margin-bottom:3px; color:#f3fbf7;}
  .materialsRowMeta{font-size:12px; color:rgba(232,243,238,.65); display:flex; gap:8px; flex-wrap:wrap;}
  .materialsForm{display:grid; grid-template-columns:repeat(2, minmax(220px, 1fr)); gap:14px;}
  .materialsWide{grid-column:1 / -1;}
  .decorAdminImageCard{grid-column:1 / -1;display:grid;grid-template-columns:minmax(180px,260px) minmax(0,1fr);gap:16px;align-items:start;padding:15px;border:1px solid rgba(255,255,255,.09);border-radius:18px;background:rgba(255,255,255,.025);}
  .decorAdminToolACardWrap{grid-column:1/-1;border:1px solid rgba(84,108,136,.16);border-radius:18px;padding:16px;background:linear-gradient(180deg,rgba(255,255,255,.98),rgba(246,249,247,.96));}
.decorAdminToolACard{max-width:300px;border:1px solid rgba(49,68,58,.13);border-radius:16px;background:#fff;overflow:hidden;box-shadow:0 10px 24px rgba(25,39,32,.09);}
.decorAdminToolACardMedia{aspect-ratio:4/3;background:linear-gradient(135deg,#f0ece6,#d8d1c6);overflow:hidden;display:flex;align-items:center;justify-content:center;color:rgba(33,52,42,.42);font-size:32px;}
.decorAdminToolACardMedia img{width:100%;height:100%;object-fit:cover;display:block;}
.decorAdminToolACardBody{padding:13px 14px 14px;}
.decorAdminToolACardBrand{font-size:10px;letter-spacing:.055em;text-transform:uppercase;color:#69766f;font-weight:850;}
.decorAdminToolACardName{font-size:16px;font-weight:900;color:#17261e;margin-top:5px;line-height:1.25;}
.decorAdminToolACardTags{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px;}
.decorAdminToolACardTag{font-size:11px;color:#53615a;background:#f2f4f2;border-radius:8px;padding:5px 8px;}
.decorAdminPreview{aspect-ratio:4/3;border-radius:14px;overflow:hidden;background:linear-gradient(135deg,#25302c,#121917);border:1px solid rgba(255,255,255,.10);display:flex;align-items:center;justify-content:center;color:rgba(232,243,238,.5);}
  .decorAdminPreview img{width:100%;height:100%;object-fit:cover;display:block;}
  .materialsRowWithImage{display:grid;grid-template-columns:56px minmax(0,1fr);gap:11px;align-items:center;}
  .materialsRowThumb{width:56px;aspect-ratio:4/3;border-radius:9px;overflow:hidden;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;color:rgba(232,243,238,.35);}
  .materialsRowThumb img{width:100%;height:100%;object-fit:cover;display:block;}
  @media (max-width: 1180px){ .materialsGrid{grid-template-columns:1fr;} .materialsForm{grid-template-columns:1fr;} }
  .jobsSummary{display:flex; align-items:center; justify-content:space-between; gap:12px; cursor:pointer; font-weight:900; list-style:none;}
  .jobsSummary::-webkit-details-marker{display:none;}
  .jobsSummary::after{content:'▾'; opacity:.72; transition:transform .15s ease;}
  #jobsDetails:not([open]) .jobsSummary::after{transform:rotate(-90deg);}
  .jobsCollapsedHint{color:rgba(232,243,238,.6); font-size:12px; margin-top:8px;}

</style></head>
<body>
<script>window.__ADZAAGT_ADMIN_AUTH_FIX626__=true;</script>
<script>
(function(){
  'use strict';
  // FIX626: clean admin session login.
  // No native Basic Auth in Safari; no stale Basic-session route; no unauthenticated
  // admin data loads before a successful token login.
  if (window.__ADZAAGT_ADMIN_AUTH_FIX626__) return;
  window.__ADZAAGT_ADMIN_AUTH_FIX626__ = true;

  const STORAGE_KEY = 'adzaagt_admin_bearer_token_v2';
  const OLD_KEYS = ['adzaagt_admin_basic_auth_v1','adzaagt_admin_auth_v1'];
  const nativeFetch = window.fetch ? window.fetch.bind(window) : null;
  let memoryToken = '';
  let overlayReady = false;
  let loginInProgress = false;

  function readToken(){
    try { return sessionStorage.getItem(STORAGE_KEY) || memoryToken || ''; }
    catch(e){ return memoryToken || ''; }
  }
  function writeToken(token){
    memoryToken = token || '';
    try {
      OLD_KEYS.forEach(function(k){ try { sessionStorage.removeItem(k); } catch(e){} });
      if (token) sessionStorage.setItem(STORAGE_KEY, token);
      else sessionStorage.removeItem(STORAGE_KEY);
    } catch(e){}
  }
  function clearToken(){ writeToken(''); }
  function adminApiUrl(input){
    try {
      const raw = (typeof input === 'string') ? input : ((input && input.url) || '');
      if (!raw) return false;
      const u = new URL(raw, window.location.href);
      return u.origin === window.location.origin && (u.pathname.startsWith('/api/admin/') || u.pathname === '/api/send_to_odoo');
    } catch(e){
      const raw = String(input || '');
      return raw.startsWith('/api/admin/') || raw.startsWith('/api/send_to_odoo');
    }
  }
  function authHeaders(init, token){
    const out = Object.assign({}, init || {});
    const h = new Headers(out.headers || {});
    h.set('X-Requested-With', 'fetch');
    if (token) h.set('Authorization', 'Bearer ' + token);
    out.headers = h;
    out.credentials = 'same-origin';
    return out;
  }
  function authRequiredResponse(){
    return new Response(JSON.stringify({ok:false, authRequired:true, error:'Admin login required'}), {
      status: 401,
      headers: {'Content-Type':'application/json; charset=utf-8', 'X-Admin-Auth-Required':'1'}
    });
  }
  function patchFetch(){
    if (!nativeFetch || window.__ADZAAGT_ADMIN_FETCH_PATCHED_FIX626__) return;
    window.__ADZAAGT_ADMIN_FETCH_PATCHED_FIX626__ = true;
    window.fetch = function(input, init){
      const isAdmin = adminApiUrl(input);
      if (!isAdmin) return nativeFetch(input, init);
      const tokenAtStart = readToken();
      if (!tokenAtStart) {
        if (!loginInProgress) showLoginOverlay('Log in om admin-data te laden.');
        return Promise.resolve(authRequiredResponse());
      }
      const patched = authHeaders(init, tokenAtStart);
      return nativeFetch(input, patched).then(function(res){
        if ((res.status === 401 || res.status === 403) && readToken() === tokenAtStart) {
          clearToken();
          if (!loginInProgress) showLoginOverlay('Sessie verlopen. Log opnieuw in.');
        }
        return res;
      });
    };
  }
  function ensureOverlay(){
    if (overlayReady) return;
    overlayReady = true;
    const style = document.createElement('style');
    style.textContent = `
      #adminLoginOverlay{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(8,12,18,.78);backdrop-filter:blur(14px);font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#fff;}
      #adminLoginOverlay[hidden]{display:none!important;}
      .adminLoginCard{width:min(420px,calc(100vw - 32px));border-radius:24px;background:linear-gradient(180deg,#172036,#0d1322);box-shadow:0 24px 90px rgba(0,0,0,.45);border:1px solid rgba(255,255,255,.14);padding:24px;}
      .adminLoginCard h2{margin:0 0 8px;font-size:24px;line-height:1.15;}
      .adminLoginCard p{margin:0 0 18px;color:rgba(255,255,255,.72);font-size:14px;line-height:1.45;}
      .adminLoginCard label{display:block;margin:12px 0 6px;font-size:13px;color:rgba(255,255,255,.78);font-weight:700;}
      .adminLoginCard input{width:100%;box-sizing:border-box;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.08);color:#fff;border-radius:14px;padding:13px 14px;font-size:16px;outline:none;}
      .adminLoginCard input:focus{border-color:rgba(74,222,128,.75);box-shadow:0 0 0 4px rgba(74,222,128,.14);}
      .adminLoginActions{display:flex;gap:10px;margin-top:18px;align-items:center;}
      .adminLoginActions button{border:0;border-radius:14px;padding:13px 16px;font-weight:900;cursor:pointer;background:#22c55e;color:#052e16;flex:1;font-size:15px;}
      .adminLoginMsg{margin-top:12px;min-height:18px;color:#fecaca;font-size:13px;font-weight:700;}
      #adminLogoutBtn{position:fixed;right:14px;bottom:14px;z-index:2147482000;border:1px solid rgba(15,23,42,.12);background:#fff;color:#111827;border-radius:999px;padding:10px 14px;font-size:13px;font-weight:900;box-shadow:0 10px 30px rgba(15,23,42,.18);cursor:pointer;}
      @media(max-width:700px){#adminLogoutBtn{bottom:calc(14px + env(safe-area-inset-bottom));}.adminLoginCard{padding:22px;}}
    `;
    document.head.appendChild(style);
    const overlay = document.createElement('div');
    overlay.id = 'adminLoginOverlay';
    overlay.innerHTML = `
      <form class="adminLoginCard" id="adminLoginForm" autocomplete="on">
        <h2>Admin login</h2>
        <p>Vul je admin-gegevens in. Data wordt pas geladen na een geldige login.</p>
        <label for="adminLoginUser">Gebruikersnaam</label>
        <input id="adminLoginUser" name="username" autocomplete="username" value="admin" required>
        <label for="adminLoginPass">Wachtwoord</label>
        <input id="adminLoginPass" name="password" autocomplete="current-password" type="password" required>
        <div class="adminLoginActions"><button type="submit" id="adminLoginSubmit">Inloggen</button></div>
        <div class="adminLoginMsg" id="adminLoginMsg"></div>
      </form>`;
    document.body.appendChild(overlay);
    const logout = document.createElement('button');
    logout.id = 'adminLogoutBtn';
    logout.type = 'button';
    logout.textContent = 'Uitloggen';
    logout.addEventListener('click', function(){ clearToken(); showLoginOverlay('Je bent uitgelogd.'); });
    document.body.appendChild(logout);
    document.getElementById('adminLoginForm').addEventListener('submit', function(ev){ ev.preventDefault(); doLogin(); });
  }
  function showLoginOverlay(msg){
    ensureOverlay();
    const overlay = document.getElementById('adminLoginOverlay');
    const m = document.getElementById('adminLoginMsg');
    if (m) m.textContent = msg || '';
    if (overlay) overlay.hidden = false;
    setTimeout(function(){ const p=document.getElementById('adminLoginPass'); if(p) p.focus(); }, 50);
  }
  function hideLoginOverlay(){ const overlay=document.getElementById('adminLoginOverlay'); if(overlay) overlay.hidden=true; }
  function refreshAdminData(){
    const names = ['load','reloadPricing','mb_load','adminLoadJobs','adminLoadRequests','loadRequests','loadJobs','loadPricing','loadSystem','loadMaterials'];
    names.forEach(function(n){ try { if (typeof window[n] === 'function') window[n](); } catch(e){} });
    try { window.dispatchEvent(new CustomEvent('adzaagt-admin-authenticated')); } catch(e){}
  }
  function doLogin(){
    ensureOverlay();
    const user = ((document.getElementById('adminLoginUser') || {}).value || 'admin').trim();
    const pass = (document.getElementById('adminLoginPass') || {}).value || '';
    const msg = document.getElementById('adminLoginMsg');
    if (!pass) { if(msg) msg.textContent='Vul je wachtwoord in.'; return; }
    clearToken();
    loginInProgress = true;
    if(msg) msg.textContent='Login controleren...';
    nativeFetch('/api/admin/login', {
      method:'POST', cache:'no-store', credentials:'same-origin',
      headers:{'Content-Type':'application/json','X-Requested-With':'fetch'},
      body: JSON.stringify({username:user, password:pass})
    }).then(function(res){
      return res.json().catch(function(){ return {}; }).then(function(j){ return {res:res, json:j}; });
    }).then(function(pair){
      if (!pair.res.ok || !pair.json || !pair.json.ok || !pair.json.token) throw new Error((pair.json && pair.json.error) || ('HTTP '+pair.res.status));
      const token = String(pair.json.token || '');
      writeToken(token);
      // Verify the token before hiding login, so stale background calls cannot fake success.
      return nativeFetch('/api/admin/jobs', authHeaders({cache:'no-store'}, token)).then(function(check){
        if (!check.ok) throw new Error('Token check failed: HTTP '+check.status);
        return check;
      });
    }).then(function(){
      loginInProgress = false;
      if(msg) msg.textContent='';
      hideLoginOverlay();
      setTimeout(refreshAdminData, 80);
    }).catch(function(err){
      loginInProgress = false;
      clearToken();
      const txt = (err && String(err.message || '').includes('Too many')) ? 'Te veel loginpogingen. Wacht even en probeer opnieuw.' : 'Login mislukt. Controleer gebruikersnaam/wachtwoord.';
      if(msg) msg.textContent=txt;
      showLoginOverlay(txt);
    });
  }
  patchFetch();
  document.addEventListener('DOMContentLoaded', function(){
    ensureOverlay();
    clearToken(); // FIX626: always start clean; no stale old Basic/session auth.
    showLoginOverlay('Log in om admin-data te laden.');
  });
})();
</script>
<header>
  <h1>METOD Admin</h1>
  <div class=\"muted\">Jobs + outputs (DXF sheets download)</div>
  <div style=\"margin-left:auto\"></div>
  <a class=\"btn\" href=\"/\">Tool A</a>
  <button class=\"btn secondary\" id=\"adminLogoutBtn\" type=\"button\">Uitloggen</button>
</header>
<main>
  <div class="adminShell">
    <aside class="adminRail" aria-label="Admin navigatie">
      <button class="adminNavBtn active" type="button" data-section="inbox" title="Inbox">
        <span class="adminNavIcon">📥</span>
        <span class="adminNavLabel">Inbox</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="beheer" title="Beheer">
        <span class="adminNavIcon">🛠</span>
        <span class="adminNavLabel">Beheer</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="materials" title="Materialen">
        <span class="adminNavIcon">🪵</span>
        <span class="adminNavLabel">Decor Library</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="pricing" title="Prijsinstellingen">
        <span class="adminNavIcon">💶</span>
        <span class="adminNavLabel">Prijzen</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="system" title="Systeem">
        <span class="adminNavIcon">🖥️</span>
        <span class="adminNavLabel">Systeem</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="jobs" title="Jobs">
        <span class="adminNavIcon">🧰</span>
        <span class="adminNavLabel">Jobs</span>
      </button>
    </aside>

    <div class="adminPages">
      <section class="adminSection active" id="adminSection-inbox" data-section="inbox">
        <div class="card" id="mbCard">
          <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
            <div style="font-weight:900; font-size:16px;">📥 Inbox</div>
            <div class="tabs" id="mbTabs">
              <button class="tabBtn active" data-tab="inbox" type="button">Inbox</button>
              <button class="tabBtn" data-tab="processing" type="button">Processing</button>
              <button class="tabBtn" data-tab="errors" type="button">Errors</button>
              <button class="tabBtn" data-tab="afgehandeld" type="button">Afgehandeld</button>
              <button class="tabBtn" data-tab="alles" type="button">Alles</button>
            </div>
            <div style="margin-left:auto; display:flex; gap:8px; align-items:center;">
              <input id="mbSearch" placeholder="Zoeken (klant / requestId)" style="min-width:220px; padding:8px 10px; border-radius:10px; border:1px solid rgba(0,0,0,.12);" />
              <button class="btn" id="mbRefreshBtn" type="button">Refresh</button>
            </div>
          </div>
          <div class="muted" style="margin-top:8px;">Nieuwe aanvragen komen binnen in Inbox. Na 'Aanvraag afhandelen' schuiven ze door naar Afgehandeld. Alles blijft file-based & deterministisch.</div>

          <div style="margin-top:12px; overflow:auto;">
            <table id="mbTable" style="width:100%;">
              <thead>
                <tr>
                  <th style="width:34px;"></th>
                  <th>Request</th>
                  <th>Klant</th>
                  <th>Public</th>
                  <th>Intern</th>
                  <th>Created</th>
                  <th style="width:200px;">Acties</th>
                </tr>
              </thead>
              <tbody id="mbTbody">
                <tr><td colspan="7" class="muted">laden…</td></tr>
              </tbody>
            </table>
          </div>

          <details id="mbDetails" style="margin-top:10px; display:none;">
            <summary style="cursor:pointer; font-weight:900;">Details</summary>
            <div id="mbDetailsBody" class="muted" style="margin-top:8px;">—</div>
          </details>
        </div>
      </section>

      <section class="adminSection" id="adminSection-beheer" data-section="beheer">
        <div class="card">
          <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:16px; flex-wrap:wrap;">
            <div>
              <div style="font-weight:900; font-size:16px;">📐 DXF Beheer</div>
              <div class="muted" style="margin-top:6px; max-width:900px;">Beheer hier alle DXF templates per categorie. <code>(root)</code> is de hoofdmap voor bestaande templates. Materialen en prijsinstellingen hebben nu hun eigen pagina links in de adminbalk.</div>
            </div>
          </div>

          <div style="margin-top:16px; padding-top:10px; border-top:1px solid rgba(255,255,255,0.08);">
            <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
              <label class="muted" style="font-size:12px;">Categorie</label>
              <select id="dxfCatSel" style="min-width:200px;"></select>
              <button class="btn" id="dxfRefreshBtn" type="button">Ververs</button>
            </div>

            <div style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
              <input id="dxfNewCat" placeholder="Nieuwe categorie (bv. metod)" style="min-width:220px;" />
              <button class="btn" id="dxfCreateCatBtn" type="button">Maak categorie</button>
            </div>

            <div style="margin-top:12px; display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
              <input type="file" id="dxfFileInput" accept=".dxf" />
              <button class="btn" id="dxfUploadBtn" type="button">Upload DXF</button>
            </div>

            <div class="muted" id="dxfStatus" style="margin-top:6px; font-size:12px;">—</div>

            <div style="margin-top:12px;">
              <div style="font-weight:800; margin-bottom:6px;">Bestanden</div>
              <div id="dxfFiles" class="muted" style="font-size:12px;">—</div>
            </div>
          </div>

              <script>
              async function _postJson(url, body){
                const r = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
                let j = {};
                try{ j = await r.json(); }catch(e){}
                return {ok:r.ok, json:j};
              }
              async function _getJson(url){
                const r = await fetch(url, {cache:'no-store'});
                let j = {};
                try{ j = await r.json(); }catch(e){}
                return {ok:r.ok, json:j};
              }

              function esc(s){ return String(s).replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }

              async function dxf_load_categories(){
                const sel = document.getElementById('dxfCatSel');
                if(!sel) return;
                const prev = sel.value || '';
                const {ok, json} = await _getJson('/api/admin/dxf/categories');
                sel.innerHTML = '';
                (json.categories || []).forEach(c=>{
                  const o = document.createElement('option');
                  o.value = c;
                  o.textContent = (c === '(root)') ? '(root)' : c;
                  sel.appendChild(o);
                });
                if(prev){
                  const opt = Array.from(sel.options).find(o=>o.value===prev);
                  if(opt) sel.value = prev;
                }
              }

              async function dxf_load_files(){
                const sel = document.getElementById('dxfCatSel');
                const box = document.getElementById('dxfFiles');
                const st = document.getElementById('dxfStatus');
                let cat = sel ? sel.value : '';
                const catText = (sel && sel.options && sel.selectedIndex>=0) ? (sel.options[sel.selectedIndex].textContent||'') : '';
                if(cat === '(root)' && catText && catText !== '(root)') cat = catText;
                if(!cat){ if(box) box.textContent='Geen categorie geselecteerd.'; return; }
                const {ok, json} = await _getJson('/api/admin/dxf/list?category=' + encodeURIComponent(cat));
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                const files = json.files || [];
                if(!files.length){ if(box) box.textContent='Geen DXF bestanden in deze categorie.'; return; }
                box.innerHTML = files.map(fn=>(
                  `<div style="display:flex; justify-content:space-between; gap:12px; align-items:center; padding:6px 0; border-bottom:1px dashed rgba(255,255,255,0.08);">
                    <div style="font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;">${esc(fn)}</div>
                    <button class="btn danger" type="button" data-act="delete-dxf" data-cat="${encodeURIComponent(cat)}" data-file="${encodeURIComponent(fn)}">Verwijder</button>
                  </div>`
                )).join('');
                box.querySelectorAll('[data-act="delete-dxf"]').forEach(btn=>{
                  btn.addEventListener('click', ()=>{
                    const catVal = decodeURIComponent(btn.getAttribute('data-cat') || '');
                    const fileVal = decodeURIComponent(btn.getAttribute('data-file') || '');
                    dxf_delete_file(catVal, fileVal);
                  });
                });
              }

              async function dxf_create_category(){
                const inp = document.getElementById('dxfNewCat');
                const st = document.getElementById('dxfStatus');
                const name = inp ? inp.value.trim() : '';
                if(!name){ if(st) st.textContent='Vul een categorie naam in.'; return; }
                const {ok, json} = await _postJson('/api/admin/dxf/create_category', {category:name});
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                if(st) st.textContent='Categorie aangemaakt: ' + name;
                if(inp) inp.value='';
                await dxf_load_categories();
                const sel = document.getElementById('dxfCatSel');
                if(sel) sel.value = name;
                await dxf_load_files();
              }

              async function dxf_upload_file(){
                const sel = document.getElementById('dxfCatSel');
                let cat = sel ? sel.value : '';
                const catText = (sel && sel.options && sel.selectedIndex>=0) ? (sel.options[sel.selectedIndex].textContent||'') : '';
                if(cat === '(root)' && catText && catText !== '(root)') cat = catText;
                const inp = document.getElementById('dxfFileInput');
                const st = document.getElementById('dxfStatus');
                if(!cat){ if(st) st.textContent='Selecteer eerst een categorie.'; return; }
                if(!inp || !inp.files || !inp.files.length){ if(st) st.textContent='Kies eerst een DXF bestand.'; return; }
                const file = inp.files[0];
                const buf = await file.arrayBuffer();
                let bin = '';
                const bytes = new Uint8Array(buf);
                const chunk = 0x8000;
                for(let i=0;i<bytes.length;i+=chunk){
                  bin += String.fromCharCode.apply(null, bytes.subarray(i,i+chunk));
                }
                const b64 = btoa(bin);
                const {ok, json} = await _postJson('/api/admin/dxf/upload', {category:cat, filename:file.name, dataBase64:b64});
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                if(st) st.textContent='Upload OK: ' + file.name;
                inp.value='';
                await dxf_load_files();
              }

              async function dxf_delete_file(cat, fn){
                if(!confirm('Verwijderen: ' + fn + ' ?')) return;
                const st = document.getElementById('dxfStatus');
                const {ok, json} = await _postJson('/api/admin/dxf/delete', {category:cat, filename:fn});
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                if(st) st.textContent='Verwijderd: ' + fn;
                await dxf_load_files();
              }

              document.addEventListener('DOMContentLoaded', ()=>{
                const r = document.getElementById('dxfRefreshBtn');
                const c = document.getElementById('dxfCreateCatBtn');
                const u = document.getElementById('dxfUploadBtn');
                if(r) r.addEventListener('click', async()=>{ await dxf_load_categories(); await dxf_load_files(); });
                if(c) c.addEventListener('click', dxf_create_category);
                if(u) u.addEventListener('click', dxf_upload_file);
                (async()=>{ await dxf_load_categories(); await dxf_load_files(); })();
              });
              </script>
        </div>
      </section>

      <section class="adminSection" id="adminSection-materials" data-section="materials">
        <div class="card">
          <div style="display:flex;justify-content:space-between;gap:16px;align-items:flex-start;flex-wrap:wrap;">
            <div>
              <div class="adminSectionTitle">Websitecatalogus</div>
              <div class="adminSectionIntro" style="max-width:900px;margin-bottom:0;">FIX654_CSV_ONLY_ADMIN · Dit is de enige actieve materiaalbron voor Tool A. Upload een website-CSV, controleer de wijzigingen en publiceer pas daarna. Oude seed-/JSON-materialen en losse handmatige decors maken geen deel meer uit van de actieve library.</div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
              <span class="pricingTag">CSV is bron van waarheid</span>
              <button class="btn secondary" type="button" data-admin-action="materialsReload">Herladen</button>
            </div>
          </div>

          <div class="card" style="margin-top:16px;padding:18px;border:1px solid rgba(52,211,153,.28);background:linear-gradient(135deg,rgba(52,211,153,.08),rgba(255,255,255,.025));">
            <div style="display:flex;justify-content:space-between;gap:14px;align-items:flex-start;flex-wrap:wrap;">
              <div>
                <div style="font-size:18px;font-weight:900;">Nieuwe catalogusversie</div>
                <div class="help" style="margin-top:5px;max-width:850px;line-height:1.55;">Alleen 18, 19 en 20 mm wordt toegelaten. CSV-prijzen zijn verkoopprijzen per plaat inclusief BTW. Ontbrekende DecoLegno-maten worden volgens de vaste importregels gecontroleerd aangevuld. Artikelnummers en afbeeldingsbron-URL's blijven uitsluitend in Admin/backend.</div>
              </div>
              <span class="pricingTag">1. upload → 2. controle + beelden voorbereiden → 3. publiceer</span>
            </div>
            <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:15px;">
              <input type="file" id="matCsvInput" accept=".csv,text/csv" style="flex:1 1 360px;min-width:260px;" />
              <button class="btn" id="matCsvPreviewBtn" type="button">CSV controleren</button>
              <button class="btn" id="matCsvPublishBtn" type="button" disabled>Catalogus publiceren</button>
            </div>
            <div id="matCsvStatus" class="pricingStatusLine" style="margin-top:10px;">Nog geen CSV gecontroleerd.</div>
            <div id="matCsvSummary" style="display:none;grid-template-columns:repeat(auto-fit,minmax(125px,1fr));gap:8px;margin-top:12px;"></div>
            <div id="matCsvNotices" style="display:none;margin-top:12px;"></div>
            <div id="matCsvImageSync" style="display:none;margin-top:12px;padding:12px;border-radius:12px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.08);"></div>
          </div>

          <div id="materialsCatalogState" class="card" style="margin-top:14px;padding:14px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.08);">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;">
              <div><strong>Actieve catalogus</strong><div id="materialsCatalogStateText" class="muted" style="font-size:12px;margin-top:3px;">Laden…</div></div>
              <div class="muted" style="font-size:11px;">Alleen de laatst gepubliceerde CSV voedt Tool A.</div>
            </div>
          </div>

          <div class="materialsGrid" style="margin-top:14px;">
            <div class="materialsListCard">
              <div class="pricingField">
                <label for="materialsSearch">Zoeken in actieve CSV-catalogus</label>
                <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                  <input id="materialsSearch" placeholder="Zoek op artikelnummer, decornaam of merk…" style="flex:1 1 320px;" />
                  <button class="btn secondary" id="materialsFiltersToggle" type="button">Filters</button>
                </div>
                <div class="help">Artikelnummer is alleen hier in Admin zichtbaar en wordt nooit aan Tool A geleverd.</div>
              </div>
              <div id="materialsFiltersPanel" class="card" style="display:none;margin-top:12px;padding:12px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.08);">
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">
                  <div class="pricingField" style="margin:0;"><label for="materialsFilterThickness">Dikte</label><select id="materialsFilterThickness"><option value="">Alle diktes</option></select></div>
                  <div class="pricingField" style="margin:0;"><label for="materialsFilterDimension">Afmeting plaat</label><select id="materialsFilterDimension"><option value="">Alle afmetingen</option></select></div>
                  <div class="pricingField" style="margin:0;"><label for="materialsFilterCategory">Plaatsoort / categorie</label><select id="materialsFilterCategory"><option value="">Alle plaatsoorten</option></select></div>
                  <div class="pricingField" style="margin:0;"><label for="materialsFilterBrandText">Merk / producttekst</label><input id="materialsFilterBrandText" placeholder="Bijv. Unilin, DecoLegno, Shinnoki…" /></div>
                </div>
                <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:12px;"><button class="btn secondary" id="materialsResetFiltersBtn" type="button">Reset filters</button></div>
              </div>
              <div id="materialsMeta" class="muted" style="margin-top:12px;font-size:12px;">Laden…</div>
              <div id="materialsList" class="materialsList" style="margin-top:12px;"></div>
            </div>

            <div class="materialsDetailCard">
              <div class="adminSectionTitle" style="font-size:22px;margin-bottom:4px;">Catalogusproduct</div>
              <div class="adminSectionIntro" style="margin-bottom:14px;">Productdata blijft uitsluitend afkomstig uit de gepubliceerde CSV. Alleen de filtercategorie kun je hieronder handmatig corrigeren; die private override blijft bij toekomstige CSV-imports behouden totdat je hem terugzet op Automatisch.</div>
              <div id="materialsDetailState" class="pricingStatusLine">Geen product geselecteerd.</div>
              <div id="matCsvOnlyDetailEmpty" class="card" style="margin-top:14px;padding:22px;text-align:center;background:rgba(255,255,255,.02);"><div class="muted">Selecteer links een product uit de actieve catalogus.</div></div>
              <div id="matCsvOnlyDetail" style="display:none;margin-top:14px;">
                <div style="display:grid;grid-template-columns:minmax(180px,260px) 1fr;gap:18px;align-items:start;">
                  <div id="matCsvOnlyImage" style="aspect-ratio:4/3;border-radius:14px;overflow:hidden;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.09);display:flex;align-items:center;justify-content:center;color:#81909a;">Geen afbeelding</div>
                  <div>
                    <div id="matCsvOnlyBrand" class="muted" style="font-size:12px;font-weight:900;text-transform:uppercase;letter-spacing:.08em;"></div>
                    <div id="matCsvOnlyName" style="font-size:24px;font-weight:900;line-height:1.15;margin-top:4px;"></div>
                    <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:16px;">
                      <div class="card" style="padding:11px;background:rgba(255,255,255,.025);"><div class="muted" style="font-size:10px;">DIKTE</div><strong id="matCsvOnlyThickness">—</strong></div>
                      <div class="card" style="padding:11px;background:rgba(255,255,255,.025);"><div class="muted" style="font-size:10px;">PLAATMAAT</div><strong id="matCsvOnlySize">—</strong></div>
                      <div class="card" style="padding:11px;background:rgba(255,255,255,.025);"><div class="muted" style="font-size:10px;">VERKOOPPRIJS INCL. BTW</div><strong id="matCsvOnlyPrice">—</strong></div>
                      <div class="card" style="padding:11px;background:rgba(255,255,255,.025);"><div class="muted" style="font-size:10px;">AFBEELDING</div><strong id="matCsvOnlyImageState">—</strong></div>
                    </div>
                  </div>
                </div>
                <div class="card" style="margin-top:16px;padding:14px;background:rgba(255,255,255,.02);">
                  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
                    <div><div class="muted" style="font-size:10px;">INTERN ARTIKELNUMMER · ALLEEN ADMIN</div><div id="matCsvOnlyArticle" style="font-weight:800;margin-top:3px;"></div></div>
                    <div><div class="muted" style="font-size:10px;">PUBLIEKE OPAQUE DECOR-ID</div><div id="matCsvOnlyPublicId" style="font-family:monospace;margin-top:3px;word-break:break-all;"></div></div>
                    <div><div class="muted" style="font-size:10px;">MAATBRON</div><div id="matCsvOnlyDimensionSource" style="margin-top:3px;"></div></div>
                    <div><div class="muted" style="font-size:10px;">PRIJSBRON</div><div id="matCsvOnlyPriceSource" style="margin-top:3px;">CSV verkoopprijs per plaat incl. BTW</div></div>
                  </div>
                </div>
                <div class="card" style="margin-top:12px;padding:14px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.09);">
                  <div style="display:flex;justify-content:space-between;gap:14px;align-items:flex-end;flex-wrap:wrap;">
                    <div style="flex:1 1 280px;">
                      <div style="font-size:12px;font-weight:900;">Filtercategorie</div>
                      <div class="muted" style="font-size:11px;line-height:1.45;margin-top:3px;">Alleen dit veld is handmatig aanpasbaar. De CSV en de overige productdata worden niet gewijzigd.</div>
                    </div>
                    <div style="flex:0 1 270px;min-width:220px;">
                      <select id="matCsvOnlyFamilyOverride" aria-label="Filtercategorie" style="width:100%;">
                        <option value="AUTO">Automatisch</option>
                        <option value="Hout">Hout</option>
                        <option value="Uni">Uni</option>
                        <option value="Steen &amp; beton">Steen &amp; beton</option>
                        <option value="Metaal">Metaal</option>
                        <option value="Textiel &amp; leer">Textiel &amp; leer</option>
                        <option value="Grafisch">Grafisch</option>
                        <option value="Fantasie">Fantasie</option>
                      </select>
                      <div id="matCsvOnlyFamilyOverrideState" class="muted" style="font-size:10px;margin-top:5px;min-height:14px;"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="materialsStatus" class="pricingStatusLine" style="margin-top:12px;">CSV-only beheer actief.</div>
            </div>
          </div>
        </div>
      </section>

      <section class="adminSection" id="adminSection-pricing" data-section="pricing">
        <div class="card">
          <div class="pricingShell">
            <div class="pricingHero">
              <div>
                <div class="adminSectionTitle">Prijsinstellingen</div>
              </div>
              <div class="pricingHeroMeta">
                <span class="pricingTag">Live voor nieuwe berekeningen</span>
                <span class="pricingTag">Versies worden automatisch opgeslagen</span>
              </div>
            </div>

            <div class="pricingGrid">
              <div class="pricingCard">
                <h3>Algemene instellingen</h3>
                <p>Technische defaults voor de actieve pricing-configuratie.</p>
                <div class="pricingFields">
                  <div class="pricingField"><label for="priceSheetMargin">Plaatmarge (mm)</label><input id="priceSheetMargin" type="number" step="0.1" min="0" /><div class="help">Vrije marge langs de plaatranden.</div></div>
                  <div class="pricingField"><label for="priceNestingGap">Nesting gap (mm)</label><input id="priceNestingGap" type="number" step="0.1" min="0" /><div class="help">Afstand tussen onderdelen op de plaat.</div></div>
                  <div class="pricingField"><label for="priceKerf">Kerf / zaagverlies (mm)</label><input id="priceKerf" type="number" step="0.1" min="0" /><div class="help">Technische kerf-waarde in de pricing-config.</div></div>
                  <div class="pricingField"><label for="priceMoneyDecimals">Bedragen afronden</label><input id="priceMoneyDecimals" type="number" step="1" min="0" max="4" /><div class="help">Aantal decimalen voor geldbedragen.</div></div>
                  <div class="pricingField"><label for="priceMetersDecimals">Meters afronden</label><input id="priceMetersDecimals" type="number" step="1" min="0" max="4" /><div class="help">Aantal decimalen voor meters/kantenband.</div></div>
                </div>
              </div>

              <div class="pricingCard">
                <h3>Kosten & toeslagen</h3>
                <p>Deze waarden worden gebruikt voor nieuwe offertes en berekeningen.</p>
                <div class="pricingFields">
                  <div class="pricingField materialsWide" style="grid-column:1/-1;"><label>Materiaalprijs</label><div class="help" style="font-size:13px;line-height:1.5;">Geen algemene factor meer. De verkoopprijs per plaat komt rechtstreeks uit de gepubliceerde Decor Library / catalogus-CSV. De CSV-prijs is inclusief BTW; de backend rekent die intern netto om zodat de bestaande overige kosten correct worden opgeteld en daarna 21% BTW wordt toegepast.</div></div>
                  <div class="pricingField"><label for="priceEdgeBand">Kantenband per meter excl. BTW (€)</label><input id="priceEdgeBand" type="number" step="0.01" min="0" /><div class="help">Bestaande verkoopprijs per meter; blijft volledig instelbaar en wordt bovenop de netto materiaalprijs geteld.</div></div>
                  <div class="pricingField"><label for="priceCnc">CNC per plaat excl. BTW (€)</label><input id="priceCnc" type="number" step="0.01" min="0" /><div class="help">Bestaande CNC-kosten per gebruikte plaat; blijft volledig instelbaar.</div></div>
                  <div class="pricingField"><label for="priceDrawing">Tekenwerk vast excl. BTW (€)</label><input id="priceDrawing" type="number" step="0.01" min="0" /><div class="help">Bestaande vaste teken-/voorbereidingskosten per aanvraag; blijft volledig instelbaar.</div></div>
                  <div class="pricingField"><label for="priceTransport">Transport vast excl. BTW (€)</label><input id="priceTransport" type="number" step="0.01" min="0" /><div class="help">Bestaande vaste transportkosten per aanvraag; blijft volledig instelbaar.</div></div>
                </div>
              </div>
            </div>

            <div class="pricingCard">
              <div style="display:flex; justify-content:space-between; gap:12px; align-items:flex-start; flex-wrap:wrap;">
                <div>
                  <h3 style="margin-bottom:4px;">Status</h3>
                </div>
                <div id="pricingMeta" class="pricingStatusLine">Nog niet geladen.</div>
              </div>
              <div class="pricingActions" style="margin-top:14px;">
                <button class="btn" type="button" data-admin-action="savePricing">Opslaan</button>
                <button class="btn" type="button" data-admin-action="reloadPricing">Herladen</button>
                <span id="pricingStatus" class="pricingStatusLine"></span>
              </div>
            </div>
          </div>
        </div>
      </section>


      <section class="adminSection" id="adminSection-system" data-section="system">
        <div class="card" style="padding:18px; display:grid; gap:16px;">
          <div>
            <div class="adminSectionTitle">Systeem</div>
            <div class="adminSectionIntro">Duidelijke systeemmeldingen en backups op één plek. Per melding zie je mensentaal, technische details en – als beschikbaar – jobId en klantnaam.</div>
          </div>
          <div class="grid2" style="gap:14px; align-items:start;">
            <details class="card" style="padding:14px; display:grid; gap:10px;" id="systemBackupsDetails">
              <summary style="list-style:none; cursor:pointer; display:flex; justify-content:space-between; align-items:center; gap:10px; font-weight:900; font-size:15px;">
                <span>Backups</span>
                <span class="pill" id="systemBackupsCount">0</span>
              </summary>
              <div class="muted" style="margin-top:8px;">Maak handmatig een backup van code, config en data. Daarnaast maakt het systeem automatisch 1 backup per week en bewaart het de lijsten compact.</div>
              <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:4px;">
                <button class="btn secondary" type="button" data-admin-action="refreshSystemPage">Verversen</button>
                <button class="btn" type="button" data-admin-action="createSystemBackup">Nu backup maken</button>
              </div>
              <div id="systemBackupStatus" class="muted">Nog geen data geladen…</div><div class="muted" style="margin-top:6px;">Automatisch: 1 backup per 7 dagen · bewaren: 8 automatische + 12 handmatige backups</div>
              <div id="systemBackupsList" style="display:grid; gap:8px;"></div>
            </details>
            <details class="card" style="padding:14px; display:grid; gap:10px;" id="systemOpenIssuesDetails">
              <summary style="list-style:none; cursor:pointer; display:flex; justify-content:space-between; align-items:center; gap:10px; font-weight:900; font-size:15px;">
                <span>Open fouten & meldingen</span>
                <span class="pill" id="systemOpenIssuesCount">0</span>
              </summary>
              <div class="muted" style="margin-top:8px;">Alleen meldingen die aandacht nodig hebben. Standaard ingeklapt voor rust.</div>
              <div id="systemLogsStatus" class="muted">Nog geen data geladen…</div>
              <div id="systemOpenIssuesList" style="display:grid; gap:10px;"></div>
            </details>
          </div>
          <details class="card" style="padding:14px; display:grid; gap:10px; margin-top:14px;" id="systemRecentActionsDetails">
            <summary style="list-style:none; cursor:pointer; display:flex; justify-content:space-between; align-items:center; gap:10px; font-weight:900; font-size:15px;">
              <span>Recente systeemacties</span>
              <span class="pill" id="systemRecentActionsCount">0</span>
            </summary>
            <div class="muted" style="margin-top:8px;">Compact overzicht van de laatste belangrijke successen. Standaard ingeklapt.</div>
            <div id="systemRecentActionsList" style="display:grid; gap:8px;"></div>
          </details>
          <details class="card" style="padding:14px; display:grid; gap:10px; margin-top:14px;" id="systemHistoryDetails">
            <summary style="list-style:none; cursor:pointer; display:flex; justify-content:space-between; align-items:center; gap:10px; font-weight:900; font-size:15px;">
              <span>Volledige geschiedenis</span>
              <span class="pill" id="systemHistoryCount">0</span>
            </summary>
            <div class="muted" style="margin-top:8px;">Alles blijft beschikbaar, maar standaard netjes ingeklapt.</div>
            <div id="systemHistoryList" style="display:grid; gap:10px;"></div>
          </details>
        </div>
      </section>

      <section class="adminSection" id="adminSection-jobs" data-section="jobs">
        <div class="card">
          <details id="jobsDetails">
            <summary class="jobsSummary">
              <span>Jobs</span>
              <span class="muted" style="font-weight:600; font-size:12px;">Technische joblijst — standaard ingeklapt</span>
            </summary>
            <div class="jobsCollapsedHint">Open alleen wanneer je technische jobs of orphan runs wilt controleren.</div>
            <div class="row" style="margin-top:12px;">
              <div>
                <div style="font-weight:800">Technische jobs</div>
                <div class="muted">Inbox blijft de hoofdflow. Deze lijst is puur voor controle/debug.</div>
              </div>
              <button class="secondary" type="button" data-admin-action="load">Ververs</button>
            </div>
            <div id="out" style="margin-top:10px"></div>
          </details>
        </div>
      </section>
    </div>
  </div>
</main>
<script>
// ADMIN guard: prevent double-execution (hot reload / injected twice)
if (window.__ADMIN_JS_LOADED__) { console.warn('Admin JS already loaded'); } else {
  window.__ADMIN_JS_LOADED__ = true;

	function _zaagFile(z){ return (typeof z === 'string') ? z : (z && z.file ? z.file : ''); }
	function _zaagLabel(z){ return (typeof z === 'string') ? z : (z && (z.label || z.file) ? (z.label || z.file) : ''); }
	function _h(s){
	  return String(s==null?'':s).replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
	}
	function _jobLabel(j){
	  const cn = String((j && j.customerName) ? j.customerName : '').trim();
	  const id = String((j && j.jobId) ? j.jobId : '');
	  return cn ? (_h(cn) + ' · ' + _h(id)) : _h(id);
	}
window.reloadPricing = async function reloadPricing(){
  const st = document.getElementById('pricingStatus');
  const meta = document.getElementById('pricingMeta');
  if(st) st.textContent = 'laden...';
  try{
    const r = await fetch('/api/admin/pricing', {cache:'no-store'});
    const j = await r.json();
    window.__pricingCfg = j;
    const pricing = j.pricing || {};
    const defaults = pricing.defaults || {};
    const rounding = defaults.rounding || {};
    const sell = j.sellPricing || {};
    const setVal = (id, val) => { const el = document.getElementById(id); if(el) el.value = (val !== undefined && val !== null) ? String(val) : ''; };
    setVal('priceSheetMargin', defaults.sheetMarginMm);
    setVal('priceNestingGap', defaults.nestingGapMm);
    setVal('priceKerf', defaults.kerfMm);
    setVal('priceMoneyDecimals', rounding.moneyDecimals);
    setVal('priceMetersDecimals', rounding.metersDecimals);
    setVal('priceEdgeBand', sell.edgeBandPricePerM);
    setVal('priceCnc', sell.cncCostPerSheet);
    setVal('priceDrawing', sell.drawingCostFixed);
    setVal('priceTransport', sell.transportCostFixed);
    if(st) st.textContent = 'geladen';
    if(meta) meta.textContent = 'Live configuratie geladen';
  }catch(e){
    if(st) st.textContent = 'fout bij laden: ' + (e && e.message ? e.message : e);
    if(meta) meta.textContent = 'Kon pricing-config niet laden';
  }
}

function pricingReadNumber(id, label, integerOnly=false){
  const el = document.getElementById(id);
  const raw = String(el && el.value!=null ? el.value : '').trim().replace(',', '.');
  if(!raw) throw new Error(label + ' is leeg');
  const n = integerOnly ? parseInt(raw, 10) : parseFloat(raw);
  if(!Number.isFinite(n)) throw new Error(label + ' is ongeldig');
  if(n < 0) throw new Error(label + ' mag niet negatief zijn');
  return integerOnly ? Math.round(n) : n;
}

window.savePricing = async function savePricing(){
  const st = document.getElementById('pricingStatus');
  const meta = document.getElementById('pricingMeta');
  if(st) st.textContent = 'opslaan...';
  try{
    const base = window.__pricingCfg ? JSON.parse(JSON.stringify(window.__pricingCfg)) : null;
    const cfg = base || await (async()=>{ const r = await fetch('/api/admin/pricing', {cache:'no-store'}); return await r.json(); })();
    cfg.pricing = cfg.pricing || {};
    cfg.pricing.defaults = cfg.pricing.defaults || {};
    cfg.pricing.defaults.rounding = cfg.pricing.defaults.rounding || {};
    cfg.sellPricing = cfg.sellPricing || {};
    cfg.pricing.defaults.sheetMarginMm = pricingReadNumber('priceSheetMargin', 'Plaatmarge');
    cfg.pricing.defaults.nestingGapMm = pricingReadNumber('priceNestingGap', 'Nesting gap');
    cfg.pricing.defaults.kerfMm = pricingReadNumber('priceKerf', 'Kerf');
    cfg.pricing.defaults.rounding.moneyDecimals = pricingReadNumber('priceMoneyDecimals', 'Bedragen afronden', true);
    cfg.pricing.defaults.rounding.metersDecimals = pricingReadNumber('priceMetersDecimals', 'Meters afronden', true);
    cfg.sellPricing.edgeBandPricePerM = pricingReadNumber('priceEdgeBand', 'Kantenband per meter');
    cfg.sellPricing.cncCostPerSheet = pricingReadNumber('priceCnc', 'CNC per plaat');
    cfg.sellPricing.drawingCostFixed = pricingReadNumber('priceDrawing', 'Tekenwerk vast');
    cfg.sellPricing.transportCostFixed = pricingReadNumber('priceTransport', 'Transport vast');

    const r = await fetch('/api/admin/pricing', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(cfg)});
    const j = await r.json();
    if(!r.ok){ if(st) st.textContent = 'fout: ' + (j.error || r.status); return; }
    if(st) st.textContent = 'opgeslagen (' + (j.version || 'ok') + ')';
    if(meta) meta.textContent = 'Laatste save: ' + (j.version || 'ok');
    window.__pricingCfg = cfg;
  }catch(e){
    if(st) st.textContent = 'fout bij opslaan: ' + (e && e.message ? e.message : e);
  }
}

function _escapeHtml(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function _fmtBytes(n){ n = Number(n||0); if(n < 1024) return n + ' B'; if(n < 1024*1024) return (n/1024).toFixed(1) + ' KB'; if(n < 1024*1024*1024) return (n/1024/1024).toFixed(1) + ' MB'; return (n/1024/1024/1024).toFixed(1) + ' GB'; }
function _systemTone(it){
  return (it.level === 'error') ? 'rgba(255,107,107,.14)' : (it.level === 'warning' ? 'rgba(255,196,87,.12)' : 'rgba(47,191,106,.08)');
}
function _systemRefs(it){
  return [it.requestId ? ('Request: ' + it.requestId) : '', it.jobId ? ('Job: ' + it.jobId) : '', it.customerName ? ('Klant: ' + it.customerName) : ''].filter(Boolean).join(' · ');
}
function _renderSystemDetailCard(it){
  const user = _escapeHtml(it.messageUser || 'Onbekende melding');
  const tech = _escapeHtml(it.messageTech || '—');
  const meta = [it.component || 'systeem', it.level || 'info', it.ts || ''].filter(Boolean).join(' · ');
  const refs = _systemRefs(it);
  return `<details class="card systemLogItem" style="padding:0; border-color:rgba(255,255,255,.08); background:${_systemTone(it)}; overflow:hidden;">
    <summary style="list-style:none; cursor:pointer; padding:14px; display:grid; gap:8px;">
      <div style="display:flex; justify-content:space-between; gap:10px; align-items:start;">
        <div style="font-weight:900;">${user}</div>
        <div class="pill">${_escapeHtml(it.status || 'open')}</div>
      </div>
      <div class="muted">${_escapeHtml(meta)}</div>
      ${refs ? `<div style="font-size:12px; color:#e6f2ec;">${_escapeHtml(refs)}</div>` : ''}
    </summary>
    <div style="padding:0 14px 14px 14px;">
      <div style="border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:10px 12px; background:rgba(10,14,12,.26);">
        <div style="font-size:12px; font-weight:800; color:#b9c9c0; margin-bottom:4px;">Technische details</div>
        <code style="white-space:pre-wrap; word-break:break-word; font-size:12px; color:#f4f7f5;">${tech}</code>
      </div>
    </div>
  </details>`;
}
function _renderSystemCompactRow(it){
  const refs = _systemRefs(it);
  const meta = [it.component || 'systeem', it.ts || ''].filter(Boolean).join(' · ');
  return `<div class="card" style="padding:12px 14px; background:${_systemTone(it)}; display:grid; gap:5px;">
    <div style="display:flex; justify-content:space-between; gap:10px; align-items:start;">
      <div style="font-weight:800;">${_escapeHtml(it.messageUser || 'Onbekende melding')}</div>
      <div class="pill">${_escapeHtml(it.status || 'resolved')}</div>
    </div>
    <div class="muted">${_escapeHtml(meta)}</div>
    ${refs ? `<div style="font-size:12px; color:#dfeae4;">${_escapeHtml(refs)}</div>` : ''}
  </div>`;
}
async function refreshSystemPage(){
  const logsStatus = document.getElementById('systemLogsStatus');
  const openIssuesList = document.getElementById('systemOpenIssuesList');
  const recentActionsList = document.getElementById('systemRecentActionsList');
  const historyList = document.getElementById('systemHistoryList');
  const backupStatus = document.getElementById('systemBackupStatus');
  const backupsList = document.getElementById('systemBackupsList');
  const openIssuesCount = document.getElementById('systemOpenIssuesCount');
  const recentActionsCount = document.getElementById('systemRecentActionsCount');
  const historyCount = document.getElementById('systemHistoryCount');
  const backupsCount = document.getElementById('systemBackupsCount');
  if(logsStatus) logsStatus.textContent = 'Systeemmeldingen laden…';
  if(backupStatus) backupStatus.textContent = 'Backups laden…';
  try{
    const [lr, br] = await Promise.all([
      fetch('/api/admin/system/logs', {cache:'no-store', credentials:'same-origin'}),
      fetch('/api/admin/system/backups', {cache:'no-store', credentials:'same-origin'})
    ]);
    const lj = await lr.json().catch(()=>({ok:false,error:'Ongeldige log-response'}));
    const bj = await br.json().catch(()=>({ok:false,error:'Ongeldige backup-response'}));
    const logItems = (lr.ok && lj.ok) ? (lj.items||[]) : [];
    const backupItems = (br.ok && bj.ok) ? (bj.items||[]) : [];
    const openItems = logItems.filter(it => {
      const status = String(it && it.status || '').toLowerCase();
      const level = String(it && it.level || '').toLowerCase();
      return status !== 'resolved' || level === 'error' || level === 'warning';
    });
    const recentItems = logItems.filter(it => !openItems.includes(it)).slice(0, 5);
    if(logsStatus) logsStatus.textContent = (lr.ok && lj.ok) ? `${logItems.length||0} meldingen geladen` : ('Fout: ' + (lj.error || ('HTTP ' + lr.status)));
    if(backupStatus) backupStatus.textContent = (br.ok && bj.ok) ? `${backupItems.length||0} backups gevonden` : ('Fout: ' + (bj.error || ('HTTP ' + br.status)));
    if(openIssuesCount) openIssuesCount.textContent = String(openItems.length || 0);
    if(recentActionsCount) recentActionsCount.textContent = String(recentItems.length || 0);
    if(historyCount) historyCount.textContent = String(logItems.length || 0);
    if(backupsCount) backupsCount.textContent = String(backupItems.length || 0);
    if(openIssuesList){
      openIssuesList.innerHTML = openItems.length ? openItems.map(_renderSystemDetailCard).join('') : `<div class="card" style="padding:12px 14px;">Geen open fouten of waarschuwingen.</div>`;
    }
    if(recentActionsList){
      recentActionsList.innerHTML = recentItems.length ? recentItems.map(_renderSystemCompactRow).join('') : `<div class="card" style="padding:12px 14px;">Nog geen recente systeemacties.</div>`;
    }
    if(historyList){
      historyList.innerHTML = logItems.length ? logItems.map(_renderSystemDetailCard).join('') : `<div class="card" style="padding:14px;">Geen systeemmeldingen gevonden.</div>`;
    }
    if(backupsList){
      backupsList.innerHTML = backupItems.length ? backupItems.map(it => `<div class="card" style="padding:12px 14px; display:flex; justify-content:space-between; gap:10px; align-items:center;"><div><div style="font-weight:800; display:flex; align-items:center; gap:10px; flex-wrap:wrap;"><span>${_escapeHtml(it.name || '')}</span><span class="pill">${(it.kind||'manual')==='auto'?'Automatisch':'Handmatig'}</span></div><div class="muted">${_escapeHtml(it.modified || '')}</div></div><div style="display:flex; align-items:center; gap:10px;"><div class="pill">${_fmtBytes(it.size || 0)}</div><a class="btn secondary" href="/api/admin/system/backup_download?name=${encodeURIComponent(it.name || '')}">Download</a></div></div>`).join('') : `<div class="card" style="padding:12px 14px;">Nog geen backups gevonden.</div>`;
    }
  }catch(err){
    if(logsStatus) logsStatus.textContent = 'Fout: ' + (err && err.message || err);
    if(backupStatus) backupStatus.textContent = 'Fout: ' + (err && err.message || err);
  }
}
async function createSystemBackup(){
  const st = document.getElementById('systemBackupStatus');
  if(st) st.textContent = 'Backup wordt gemaakt…';
  try{
    const r = await fetch('/api/admin/system/backup_now', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'});
    const j = await r.json().catch(()=>({ok:false,error:'Ongeldige serverresponse'}));
    if(!r.ok || !j.ok){ if(st) st.textContent = 'Fout: ' + (j.error || ('HTTP ' + r.status)); return; }
    if(st) st.textContent = `Backup gemaakt: ${j.file || ''}`;
    refreshSystemPage();
  }catch(err){ if(st) st.textContent = 'Fout: ' + (err && err.message || err); }
}
window.refreshSystemPage = refreshSystemPage;
window.createSystemBackup = createSystemBackup;

function switchAdminSection(section){
  document.querySelectorAll('.adminNavBtn').forEach(btn=>{
    btn.classList.toggle('active', btn.getAttribute('data-section') === section);
  });
  document.querySelectorAll('.adminSection').forEach(sec=>{
    sec.classList.toggle('active', sec.getAttribute('data-section') === section);
  });
  if(section === 'system'){ try{ refreshSystemPage(); }catch(_e){} }
}

function initAdminShell(){
  if(window.__adminShellInit) return;
  window.__adminShellInit = true;
  document.querySelectorAll('.adminNavBtn').forEach(btn=>{
    btn.addEventListener('click', ()=> switchAdminSection(btn.getAttribute('data-section') || 'inbox'));
  });
  switchAdminSection('inbox');
}

let materialsCache = [];
let materialsSelectedKey = '';
function matNum(v){
  const raw = String(v == null ? '' : v).trim().replace(',', '.');
  if(!raw) return null;
  const n = parseFloat(raw);
  return Number.isFinite(n) ? n : null;
}
function materialKeyOf(r){ return String((r && (r.articleNo || r.articleNumber || r.materialCode)) || '').trim(); }
function materialDecorOf(r){ return String((r && (r.decorName || r.productName || r.materialDisplayName || '')) || '').trim(); }
function materialCodeOf(r){ return String((r && (r.materialCode || r.articleNo || '')) || '').trim(); }
function materialsDimensionOf(r){
  const w = materialsFormatDim(r?.sheetWid || r?.sheetWidth || '');
  const l = materialsFormatDim(r?.sheetLen || r?.sheetHeight || r?.height || '');
  return w && l ? (w + '×' + l + ' mm') : '';
}
function materialsThicknessOf(r){
  return materialsFormatDim(r?.thicknessMm || r?.thickness || '');
}
function materialsGetFilterState(){
  return {
    search: String(document.getElementById('materialsSearch')?.value || '').trim().toLowerCase(),
    thickness: String(document.getElementById('materialsFilterThickness')?.value || '').trim(),
    dimension: String(document.getElementById('materialsFilterDimension')?.value || '').trim(),
    category: String(document.getElementById('materialsFilterCategory')?.value || '').trim().toLowerCase(),
    brandText: String(document.getElementById('materialsFilterBrandText')?.value || '').trim().toLowerCase(),
    availability: String(document.getElementById('materialsFilterAvailability')?.value || '').trim(),
  };
}
function materialsActiveFilterCount(){
  const f = materialsGetFilterState();
  return [f.thickness, f.dimension, f.category, f.brandText, f.availability].filter(Boolean).length;
}
function materialsUpdateFiltersToggleLabel(){
  const btn = document.getElementById('materialsFiltersToggle');
  if(!btn) return;
  const n = materialsActiveFilterCount();
  btn.textContent = n ? ('Filters (' + n + ')') : 'Filters';
}
function materialsToggleFilters(forceOpen){
  const panel = document.getElementById('materialsFiltersPanel');
  if(!panel) return;
  const open = forceOpen === true ? true : !(panel.style.display === 'block');
  panel.style.display = open ? 'block' : 'none';
}
function materialsPopulateFilterOptions(){
  const thicknessEl = document.getElementById('materialsFilterThickness');
  const dimEl = document.getElementById('materialsFilterDimension');
  const catEl = document.getElementById('materialsFilterCategory');
  const current = materialsGetFilterState();
  const uniqueSorted = (vals, numeric=false) => Array.from(new Set(vals.filter(Boolean))).sort((a,b)=>{
    if(numeric){ return parseFloat(a) - parseFloat(b); }
    return String(a).localeCompare(String(b), 'nl', {numeric:true, sensitivity:'base'});
  });
  const thicknesses = uniqueSorted(materialsCache.map(r=>materialsThicknessOf(r)), true);
  const dims = uniqueSorted(materialsCache.map(r=>materialsDimensionOf(r)));
  const cats = uniqueSorted(materialsCache.map(r=>String(r.categoryName || '').trim()));
  if(thicknessEl) thicknessEl.innerHTML = '<option value="">Alle diktes</option>' + thicknesses.map(v=>`<option value="${esc(v)}">${esc(v)} mm</option>`).join('');
  if(dimEl) dimEl.innerHTML = '<option value="">Alle afmetingen</option>' + dims.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');
  if(catEl) catEl.innerHTML = '<option value="">Alle plaatsoorten</option>' + cats.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');
  if(thicknessEl) thicknessEl.value = current.thickness;
  if(dimEl) dimEl.value = current.dimension;
  if(catEl) catEl.value = current.category ? (cats.find(v=>String(v).toLowerCase()===current.category) || '') : '';
  materialsUpdateFiltersToggleLabel();
}
function materialsFilterRows(){
  const f = materialsGetFilterState();
  return materialsCache.filter(r=>{
    const hay = [r.articleNo, r.articleNumber, r.materialCode, r.decorName, r.productName, r.categoryName, r.shortDescription].map(v=>String(v||'').toLowerCase());
    if(f.search && !hay.some(v=>v.includes(f.search))) return false;
    const thickness = materialsThicknessOf(r);
    if(f.thickness && thickness !== f.thickness) return false;
    const dimension = materialsDimensionOf(r);
    if(f.dimension && dimension !== f.dimension) return false;
    const category = String(r.categoryName || '').trim().toLowerCase();
    if(f.category && category !== f.category) return false;
    if(f.brandText){
      const brandHay = [r.productName, r.decorName, r.shortDescription, r.categoryName, r.articleNo].map(v=>String(v||'').toLowerCase()).join(' | ');
      if(!brandHay.includes(f.brandText)) return false;
    }
    if(f.availability === 'yes' && r.active === false) return false;
    if(f.availability === 'no' && r.active !== false) return false;
    return true;
  });
}
function materialsSetCategoryValue(val){
  const el = document.getElementById('matCategoryName');
  if(!el) return;
  const v = String(val || '').trim();
  if(v && !Array.from(el.options).some(o=>o.value===v)){
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = v;
    opt.dataset.dynamic = '1';
    el.appendChild(opt);
  }
  el.value = v;
}
function materialsFormatDim(n){
  const num = Number(n);
  if(!Number.isFinite(num)) return '';
  return Number.isInteger(num) ? String(Math.trunc(num)) : String(num).replace(/\\.0+$/,'').replace(/(\\.\\d*?)0+$/,'$1');
}
function materialsUpdateDerivedFields(){
  if(materialsSelectedKey) return;
  const descEl = document.getElementById('matShortDescription');
  const w = matNum(document.getElementById('matSheetWid')?.value);
  const l = matNum(document.getElementById('matSheetLen')?.value);
  const t = matNum(document.getElementById('matThickness')?.value);
  if(!descEl) return;
  const prevAuto = descEl.dataset.auto === '1';
  const canAuto = prevAuto || !String(descEl.value || '').trim();
  if(!canAuto) return;
  if(w>0 && l>0 && t>0){
    descEl.value = `${materialsFormatDim(l)}x${materialsFormatDim(w)}x${materialsFormatDim(t)}mm`;
    descEl.dataset.auto = '1';
  }else if(prevAuto){
    descEl.value = '';
    descEl.dataset.auto = '0';
  }
}
function materialsRenderPublicPreview(){
  const target=document.getElementById('matToolAPreview'); if(!target) return;
  const publicName=String(document.getElementById('matPublicName')?.value||'Publieke decornaam').trim()||'Publieke decornaam';
  const brand=String(document.getElementById('matBrand')?.value||'Merk').trim()||'Merk';
  const type=String(document.getElementById('matDecorType')?.value||'Overig').trim()||'Overig';
  const thickness=materialsFormatDim(document.getElementById('matThickness')?.value)||'—';
  const grain=!!document.getElementById('matHasGrain')?.checked;
  const source=document.querySelector('#matImagePreview img')?.getAttribute('src')||'';
  const media=source?`<img src="${esc(source)}" alt="">`:'▧';
  target.innerHTML=`<div class="decorAdminToolACardMedia">${media}</div><div class="decorAdminToolACardBody"><div class="decorAdminToolACardBrand">${esc(brand)}</div><div class="decorAdminToolACardName">${esc(publicName)}</div><div class="decorAdminToolACardTags"><span class="decorAdminToolACardTag">${grain?'Nerf':'Uni'}</span><span class="decorAdminToolACardTag">${esc(thickness)} mm</span><span class="decorAdminToolACardTag">${esc(type)}</span></div></div>`;
}
function materialsSetForm(rec){
  const state=document.getElementById('materialsDetailState');
  const empty=document.getElementById('matCsvOnlyDetailEmpty');
  const detail=document.getElementById('matCsvOnlyDetail');
  if(!rec){
    if(state) state.textContent='Geen product geselecteerd.';
    if(empty) empty.style.display='block';
    if(detail) detail.style.display='none';
    return;
  }
  if(state) state.textContent='CSV-product geselecteerd';
  if(empty) empty.style.display='none';
  if(detail) detail.style.display='block';
  const txt=(id,val)=>{const el=document.getElementById(id);if(el)el.textContent=String(val??'');};
  txt('matCsvOnlyBrand',rec.brand||'Overig');
  txt('matCsvOnlyName',rec.publicName||rec.productName||rec.decorName||'Decor');
  txt('matCsvOnlyThickness',(materialsFormatDim(rec.thicknessMm||rec.thickness)||'—')+' mm');
  txt('matCsvOnlySize',materialsDimensionOf(rec)||'—');
  const price=Number(rec.sellPriceInclVatPerSheet||0);
  txt('matCsvOnlyPrice',price>0?new Intl.NumberFormat('nl-NL',{style:'currency',currency:'EUR'}).format(price):'—');
  txt('matCsvOnlyImageState',rec.imageAvailable?'Lokaal beschikbaar':'Wordt opgehaald / ontbreekt');
  txt('matCsvOnlyArticle',rec.articleNo||rec.articleNumber||rec.materialCode||'—');
  txt('matCsvOnlyPublicId',rec.publicMaterialId||'—');
  const ds=String(rec.dimensionSource||'csv');
  txt('matCsvOnlyDimensionSource',ds==='csv'?'CSV':(ds==='image_url'?'Afbeeldings-URL':(ds==='decolegno_18_fallback'?'DecoLegno 18 mm fallback':ds)));
  const familySelect=document.getElementById('matCsvOnlyFamilyOverride');
  const manualFamily=String(rec.taxonomyManualFamilyOverride||'').trim();
  if(familySelect){
    familySelect.value=manualFamily||'AUTO';
    familySelect.disabled=false;
  }
  txt('matCsvOnlyFamilyOverrideState',manualFamily ? ('Handmatig vastgezet op '+manualFamily) : ('Automatisch · '+String(rec.primaryVisualFamily||rec.decorType||'Onbekend')));
  const image=document.getElementById('matCsvOnlyImage');
  if(image){
    const url=String(rec.imagePreviewUrl||rec.imageThumbUrl||'').trim();
    image.innerHTML=url?`<img src="${esc(url)}" alt="Decorafbeelding" style="width:100%;height:100%;object-fit:cover;">`:'Geen afbeelding';
  }
}
async function materialsSaveFamilyOverride(){
  const select=document.getElementById('matCsvOnlyFamilyOverride');
  const state=document.getElementById('matCsvOnlyFamilyOverrideState');
  if(!select||!materialsSelectedKey) return;
  const rec=materialsCache.find(x=>materialKeyOf(x)===materialsSelectedKey)||null;
  const pid=String(rec?.publicMaterialId||'').trim();
  if(!pid){ if(state) state.textContent='Opslaan niet mogelijk: publieke decor-ID ontbreekt.'; return; }
  const requested=String(select.value||'AUTO');
  try{
    select.disabled=true;
    if(state) state.textContent='Opslaan…';
    const r=await fetch('/api/admin/materials/live_taxonomy_family',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({publicMaterialId:pid,primaryVisualFamily:requested})});
    const j=await r.json().catch(()=>({}));
    if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    const idx=materialsCache.findIndex(x=>materialKeyOf(x)===materialsSelectedKey);
    if(idx>=0&&j.record) materialsCache[idx]=j.record;
    const updated=idx>=0?materialsCache[idx]:j.record;
    materialsSetForm(updated||null);
    materialsPopulateFilterOptions();
    materialsRenderList();
    if(state) state.textContent=j.manualOverride ? ('Handmatig vastgezet op '+j.primaryVisualFamily) : ('Automatisch · '+j.primaryVisualFamily);
  }catch(e){
    select.disabled=false;
    select.value=String(rec?.taxonomyManualFamilyOverride||'').trim()||'AUTO';
    if(state) state.textContent='Opslaan mislukt: '+(e?.message||e);
  }
}

function materialsRenderList(){
  const list = document.getElementById('materialsList');
  const meta = document.getElementById('materialsMeta');
  if(!list) return;
  const rows = materialsFilterRows();
  const activeCount = materialsActiveFilterCount();
  if(meta) meta.textContent = rows.length + ' van ' + materialsCache.length + ' materialen zichtbaar' + (activeCount ? (' · ' + activeCount + ' filter' + (activeCount===1?'':'s') + ' actief') : '');
  materialsUpdateFiltersToggleLabel();
  if(!rows.length){ list.innerHTML = '<div class="muted">Geen materialen gevonden.</div>'; return; }
  list.innerHTML = rows.map(r=>{
    const key = materialKeyOf(r);
    const title = esc(r.publicName || r.productName || r.decorName || r.articleNo || 'Materiaal');
    const status = 'CSV actief';
    const metaText = [r.articleNo, r.brand || '', r.primaryVisualFamily || r.decorType || '', r.substrateLabel || '', materialsDimensionOf(r), materialsThicknessOf(r) ? (materialsThicknessOf(r) + ' mm') : '', status].filter(Boolean).map(esc).join('<span>·</span>');
    const thumb = r.imageThumbUrl ? `<img src="${esc(r.imageThumbUrl)}" alt="">` : '▧';
    return `<button class="materialsRow${materialsSelectedKey===key?' active':''}" type="button" data-key="${esc(key)}"><div class="materialsRowWithImage"><div class="materialsRowThumb">${thumb}</div><div><div class="materialsRowTitle">${title}</div><div class="materialsRowMeta">${metaText}</div></div></div></button>`;
  }).join('');
  list.querySelectorAll('.materialsRow').forEach(btn=>btn.addEventListener('click', ()=>{
    const key = btn.getAttribute('data-key') || '';
    const rec = materialsCache.find(x=>materialKeyOf(x)===key) || null;
    materialsSelectedKey = key;
    materialsSetForm(rec);
    materialsRenderList();
  }));
}
window.materialsNew = function materialsNew(){
  const st=document.getElementById('materialsStatus');
  if(st) st.textContent='Nieuwe materialen worden uitsluitend via de catalogus-CSV toegevoegd.';
};
window.materialsReload = async function materialsReload(){
  const st=document.getElementById('materialsStatus');
  if(st) st.textContent='Catalogus laden…';
  try{
    const r=await fetch('/api/admin/materials/library',{cache:'no-store'});
    const j=await r.json();
    if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    materialsCache=Array.isArray(j.records)?j.records:[];
    materialsPopulateFilterOptions();
    const chosen=materialsSelectedKey?materialsCache.find(x=>materialKeyOf(x)===materialsSelectedKey):null;
    if(materialsSelectedKey&&!chosen) materialsSelectedKey='';
    materialsSetForm(chosen||null);
    materialsRenderList();
    const state=document.getElementById('materialsCatalogStateText');
    if(state){
      const li=j?.meta?.lastCatalogImport||null;
      if(materialsCache.length){
        const when=li?.publishedAt?(' · gepubliceerd '+String(li.publishedAt).replace('T',' ').replace('Z',' UTC')):'';
        state.textContent=`${materialsCache.length} CSV-producten actief${when}`;
      }else{
        state.textContent='Nog geen actieve CSV-catalogus. Upload en publiceer hierboven eerst een catalogus.';
      }
    }
    if(st) st.textContent='CSV-only beheer actief.';
  }catch(e){if(st)st.textContent='Fout bij laden: '+(e?.message||e);}
};
window.materialsSave = async function materialsSave(){ throw new Error('Handmatig materiaalbeheer is uitgeschakeld. Publiceer een nieuwe CSV.'); };
window.materialsDelete = async function materialsDelete(){ throw new Error('Handmatig materiaalbeheer is uitgeschakeld. Publiceer een nieuwe CSV.'); };

document.getElementById('matCsvOnlyFamilyOverride')?.addEventListener('change', materialsSaveFamilyOverride);

let materialsCatalogImportId = '';
let materialsCatalogPollTimer = null;
let materialsCatalogCanPublishAfterImages = false;
let materialsCatalogLastPreview = null;
function catalogSummaryBox(value,label,detail){
  return `<div style="padding:10px 11px;border-radius:11px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.08);"><div style="font-size:19px;font-weight:900;">${esc(value)}</div><div style="font-size:11px;font-weight:800;margin-top:2px;">${esc(label)}</div>${detail?`<div class="muted" style="font-size:10px;margin-top:3px;">${esc(detail)}</div>`:''}</div>`;
}
function materialsCatalogRenderPreview(j){
  materialsCatalogLastPreview=j||materialsCatalogLastPreview;
  const summary=document.getElementById('matCsvSummary');
  const notices=document.getElementById('matCsvNotices');
  const publish=document.getElementById('matCsvPublishBtn');
  const s=j?.summary||{};
  if(summary){
    summary.style.display='grid';
    summary.innerHTML=[
      catalogSummaryBox(s.rowsRead||0,'CSV-regels','gelezen'),
      catalogSummaryBox(s.eligible||0,'Toegelaten','18 / 19 / 20 mm'),
      catalogSummaryBox(s.excludedThickness||0,'Uitgesloten','andere dikte'),
      catalogSummaryBox(s.new||0,'Nieuw','artikel'),
      catalogSummaryBox(s.changed||0,'Gewijzigd','prijs / maat / beeld'),
      catalogSummaryBox(s.unchanged||0,'Ongewijzigd','zelfde brondata'),
      catalogSummaryBox(s.missingFromSource||0,'Niet meer in nieuwe CSV','verdwijnt uit actief'),
      catalogSummaryBox(s.taxonomyVerified||0,'Geclassificeerd','filter + drager'),
      catalogSummaryBox(s.taxonomyReviewRequired||0,'Controle nodig','publicatie geblokkeerd'),
      catalogSummaryBox(s.warnings||0,'Waarschuwingen','controleren')
    ].join('');
  }
  const warnings=Array.isArray(j?.warnings)?j.warnings:[];
  const errors=Array.isArray(j?.errors)?j.errors:[];
  const excluded=Array.isArray(j?.excluded)?j.excluded:[];
  const taxonomyReview=Array.isArray(j?.taxonomyReview)?j.taxonomyReview:[];
  if(notices){
    notices.style.display=(warnings.length||errors.length||excluded.length||taxonomyReview.length)?'block':'none';
    const section=(title,arr,kind)=>!arr.length?'':`<details style="margin-top:7px;"${kind==='error'?' open':''}><summary style="cursor:pointer;font-weight:850;">${esc(title)} · ${arr.length}</summary><div style="display:grid;gap:5px;margin-top:8px;max-height:240px;overflow:auto;">${arr.map(x=>`<div style="padding:8px 10px;border-radius:9px;background:rgba(255,255,255,.035);font-size:11px;line-height:1.4;"><strong>${esc(x.articleNo||('regel '+(x.row||'')))}</strong> · ${esc(x.message||x.reason||'')}</div>`).join('')}</div></details>`;
    const families=Array.isArray(j?.taxonomyFamilies)?j.taxonomyFamilies:['Hout','Uni','Steen & beton','Metaal','Textiel & leer','Grafisch','Fantasie'];
    const substrates=Array.isArray(j?.taxonomySubstrates)?j.taxonomySubstrates:[{value:'MDF',label:'MDF'},{value:'SPAANPLAAT',label:'Spaanplaat'},{value:'MULTIPLEX',label:'Multiplex'},{value:'OVERIG',label:'Overig'}];
    const reviewHtml=!taxonomyReview.length?'':`<details style="margin-top:7px;" open><summary style="cursor:pointer;font-weight:900;">Classificatie controleren · ${taxonomyReview.length}</summary><div class="muted" style="font-size:11px;margin:6px 0 9px;">Alleen twijfelgevallen verschijnen hier. Publiceren blijft geblokkeerd totdat ieder product één primaire decorfamilie en drager heeft.</div><div style="display:grid;gap:8px;max-height:360px;overflow:auto;">${taxonomyReview.map(x=>`<div data-tax-row="${esc(x.articleNo)}" style="padding:10px;border-radius:11px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.08);"><div style="font-size:12px;font-weight:850;">${esc(x.productName||x.articleNo)}</div><div class="muted" style="font-size:10px;margin-top:3px;">${esc([x.brand,x.manufacturerCode,x.collection].filter(Boolean).join(' · '))} · ${esc(x.reason||'controle nodig')}</div><div style="display:grid;grid-template-columns:minmax(120px,1fr) minmax(120px,1fr) auto;gap:7px;margin-top:8px;"><select data-tax-family>${families.map(v=>`<option value="${esc(v)}"${v===x.suggestedFamily?' selected':''}>${esc(v)}</option>`).join('')}</select><select data-tax-substrate>${substrates.map(v=>`<option value="${esc(v.value)}"${v.value===x.suggestedSubstrate?' selected':''}>${esc(v.label)}</option>`).join('')}</select><button class="btn secondary" type="button" data-tax-save="${esc(x.articleNo)}">Opslaan</button></div></div>`).join('')}</div></details>`;
    notices.innerHTML=section('Blokkerende fouten',errors,'error')+reviewHtml+section('Waarschuwingen',warnings,'warning')+section('Door diktefilter uitgesloten',excluded,'excluded');
    notices.querySelectorAll('[data-tax-save]').forEach(btn=>btn.addEventListener('click',()=>materialsCatalogApplyTaxonomy(btn.getAttribute('data-tax-save'),btn)));
  }
  materialsCatalogCanPublishAfterImages = !!j?.canPublishAfterImages || !!j?.canPublish;
  if(publish) publish.disabled=!j?.canPublish;
}
async function materialsCatalogApplyTaxonomy(articleNo,btn){
  if(!materialsCatalogImportId||!articleNo) return;
  const row=btn?.closest?.('[data-tax-row]');
  const family=row?.querySelector?.('[data-tax-family]')?.value||'';
  const substrate=row?.querySelector?.('[data-tax-substrate]')?.value||'';
  const status=document.getElementById('matCsvStatus');
  try{
    if(btn) btn.disabled=true;
    const r=await fetch('/api/admin/materials/catalog_taxonomy_override',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({importId:materialsCatalogImportId,articleNo,primaryVisualFamily:family,substrateType:substrate})});
    const j=await r.json().catch(()=>({}));
    if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    const base=materialsCatalogLastPreview||{};
    base.reviewSha256=String(j.reviewSha256||'');
    base.taxonomySummary=j.taxonomySummary||{};
    base.taxonomyReview=j.taxonomyReview||[];
    base.canPublishAfterImages=!!j.canPublishAfterImages;
    base.canPublish=!!j.canPublish;
    base.summary=Object.assign({},base.summary||{}, {
      taxonomyVerified:Number(j.taxonomySummary?.verified||0),
      taxonomyReused:Number(j.taxonomySummary?.reused||0),
      taxonomyAutoVerified:Number(j.taxonomySummary?.autoVerified||0),
      taxonomyAdminVerified:Number(j.taxonomySummary?.adminVerified||0),
      taxonomyReviewRequired:Number(j.taxonomySummary?.reviewRequired||0)
    });
    materialsCatalogCanPublishAfterImages=!!j.canPublishAfterImages;
    materialsCatalogRenderPreview(base);
    if(status) status.textContent=(j.taxonomySummary?.reviewRequired||0)>0
      ? `${j.taxonomySummary.reviewRequired} product(en) moeten nog worden gecontroleerd.`
      : 'Classificatie compleet. Wacht zo nodig nog op de afbeeldingen; daarna kun je publiceren.';
  }catch(e){
    if(status) status.textContent='Classificatie opslaan mislukt: '+(e?.message||e);
    if(btn) btn.disabled=false;
  }
}

async function materialsCatalogPreview(){
  const input=document.getElementById('matCsvInput');
  const status=document.getElementById('matCsvStatus');
  const btn=document.getElementById('matCsvPreviewBtn');
  const pub=document.getElementById('matCsvPublishBtn');
  materialsCatalogImportId='';
  materialsCatalogCanPublishAfterImages=false;
  if(materialsCatalogPollTimer){clearInterval(materialsCatalogPollTimer);materialsCatalogPollTimer=null;}
  if(pub) pub.disabled=true;
  if(!input?.files?.length){ if(status) status.textContent='Kies eerst een CSV-bestand.'; return; }
  const file=input.files[0];
  if(file.size>4*1024*1024){ if(status) status.textContent='CSV is groter dan 4 MB.'; return; }
  if(status) status.textContent='CSV controleren…';
  try{
    if(btn) btn.disabled=true;
    const text=await file.text();
    const r=await fetch('/api/admin/materials/catalog_preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({csvText:text})});
    const j=await r.json().catch(()=>({}));
    if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    materialsCatalogImportId=String(j.importId||'');
    materialsCatalogRenderPreview(j);
    const imageTotal=Number(j.imageSyncTotal||0);
    if(j.canPublish){
      if(status) status.textContent='Controle klaar. Alle benodigde beelden zijn al lokaal beschikbaar; je kunt publiceren.';
      materialsCatalogRenderSync({ok:true,state:'DONE',total:0,processed:0,success:0,failed:0});
    }else if(j.canPublishAfterImages && imageTotal>0){
      if(status) status.textContent=`CSV-data is geldig. ${imageTotal} afbeeldingen worden nu lokaal voorbereid vóór publicatie…`;
      materialsCatalogStartPolling();
    }else{
      const review=Number(j?.taxonomySummary?.reviewRequired||0);
      if(status) status.textContent=review>0
        ? `CSV-data is geldig, maar ${review} product(en) vereisen classificatiecontrole vóór publicatie.`
        : 'Controle klaar, maar er zijn blokkerende fouten.';
    }
  }catch(e){
    if(status) status.textContent='Fout: '+(e?.message||e);
  }finally{ if(btn) btn.disabled=false; }
}
function materialsCatalogRenderSync(st){
  const el=document.getElementById('matCsvImageSync'); if(!el) return;
  el.style.display='block';
  const total=Number(st?.total||0), processed=Number(st?.processed||0), ok=Number(st?.success||0), failed=Number(st?.failed||0);
  const pct=total?Math.min(100,Math.round((processed/total)*100)):100;
  const done=['DONE','DONE_WITH_ERRORS','FAILED'].includes(String(st?.state||''));
  const fullyPrepared=String(st?.state||'')==='DONE' && failed===0 && processed>=total;
  const readyToPublish=!!materialsCatalogCanPublishAfterImages && fullyPrepared && !st?.published;
  const publicationGate=st?.published
    ? `<div style="margin-top:11px;padding:11px 12px;border-radius:11px;background:rgba(52,211,153,.12);border:1px solid rgba(52,211,153,.28);font-size:12px;font-weight:850;">Actief gepubliceerd. Tool A gebruikt nu deze catalogus en afbeeldingen.</div>`
    : readyToPublish
      ? `<div style="margin-top:11px;padding:12px;border-radius:11px;background:rgba(251,191,36,.11);border:1px solid rgba(251,191,36,.34);"><div style="font-size:12px;font-weight:900;line-height:1.4;">100% voorbereid, maar nog niet actief in Tool A</div><div class="muted" style="font-size:11px;line-height:1.45;margin-top:4px;">De beelden staan veilig in staging. Publiceer de catalogus nog expliciet om records en afbeeldingen samen live te zetten.</div><button class="btn" type="button" id="matCsvPublishReadyBtn" style="margin-top:9px;width:100%;">Nu catalogus publiceren</button></div>`
      : '';
  el.innerHTML=`<div style="display:flex;justify-content:space-between;gap:10px;align-items:center;"><strong>Afbeeldingen voorbereiden vóór publicatie</strong><span>${pct}%</span></div><div style="height:7px;border-radius:99px;background:rgba(255,255,255,.08);overflow:hidden;margin-top:8px;"><div style="height:100%;width:${pct}%;background:currentColor;opacity:.55;"></div></div><div class="muted" style="font-size:11px;margin-top:7px;">${processed} / ${total} verwerkt · ${ok} gelukt · ${failed} mislukt${done?' · klaar':''}</div>${publicationGate}${failed&&done?`<button class="btn secondary" type="button" id="matCsvRetryImagesBtn" style="margin-top:9px;">Afbeeldingen opnieuw proberen</button>`:''}`;
  const retry=document.getElementById('matCsvRetryImagesBtn'); if(retry) retry.addEventListener('click',materialsCatalogRetryImages);
  const publishReady=document.getElementById('matCsvPublishReadyBtn'); if(publishReady) publishReady.addEventListener('click',materialsCatalogPublish);
}
async function materialsCatalogPollImages(){
  if(!materialsCatalogImportId) return;
  try{
    const r=await fetch('/api/admin/materials/catalog_status?importId='+encodeURIComponent(materialsCatalogImportId),{cache:'no-store'});
    const st=await r.json().catch(()=>({}));
    if(r.ok&&st.ok!==false){
      materialsCatalogRenderSync(st);
      if(['DONE','DONE_WITH_ERRORS','FAILED'].includes(String(st.state||''))){
        if(materialsCatalogPollTimer){clearInterval(materialsCatalogPollTimer);materialsCatalogPollTimer=null;}
        const pub=document.getElementById('matCsvPublishBtn');
        const status=document.getElementById('matCsvStatus');
        const fullyPrepared=String(st.state||'')==='DONE' && Number(st.failed||0)===0 && Number(st.processed||0)>=Number(st.total||0);
        if(pub) pub.disabled=!(materialsCatalogCanPublishAfterImages && fullyPrepared);
        if(status && materialsCatalogCanPublishAfterImages){
          status.textContent=fullyPrepared
            ? '100% voorbereid, maar nog niet actief in Tool A. Klik nu op Catalogus publiceren.'
            : 'Niet alle afbeeldingen konden worden voorbereid. Probeer de mislukte afbeeldingen opnieuw; publiceren blijft geblokkeerd.';
        }
      }
    }
  }catch(_){ }
}
function materialsCatalogStartPolling(){
  if(materialsCatalogPollTimer) clearInterval(materialsCatalogPollTimer);
  materialsCatalogPollTimer=setInterval(materialsCatalogPollImages,2000);
  materialsCatalogPollImages();
}
async function materialsCatalogPublish(){
  const status=document.getElementById('matCsvStatus'); const btn=document.getElementById('matCsvPublishBtn');
  if(!materialsCatalogImportId){ if(status) status.textContent='Controleer eerst de CSV.'; return; }
  const reviewSha256=String(materialsCatalogLastPreview?.reviewSha256||'');
  if(!/^[a-f0-9]{64}$/.test(reviewSha256)){ if(status) status.textContent='Controlebewijs ontbreekt. Controleer de CSV opnieuw.'; return; }
  const warningCount=Number(materialsCatalogLastPreview?.warnings?.length||0);
  const excludedCount=Number(materialsCatalogLastPreview?.excluded?.length||0);
  if(!confirm(`Nieuwe catalogus publiceren en expliciet aftekenen? Je bevestigt ${warningCount} waarschuwing(en) en ${excludedCount} uitgesloten regel(s). De actieve Decor Library wordt exact vervangen door de toegestane 18/19/20-mm producten uit deze CSV. Producten die niet meer in de CSV staan verdwijnen uit Tool A. Er wordt vooraf automatisch een volledige snapshot gemaakt.`)) return;
  try{
    if(btn) btn.disabled=true; if(status) status.textContent='Catalogus veilig publiceren…';
    const r=await fetch('/api/admin/materials/catalog_publish',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({importId:materialsCatalogImportId,reviewSha256})});
    const j=await r.json().catch(()=>({})); if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    if(status) status.textContent=`Actief in Tool A: ${j.published||0} CSV-producten en ${j.preparedImages||0} voorbereide afbeeldingen gepubliceerd · ${j.excludedThickness||0} door diktefilter uitgesloten · ${j.removedFromActive||0} niet meer in bron verwijderd · snapshot ${j.snapshot||'gemaakt'}.`;
    await materialsReload(); await reloadPricing();
    materialsCatalogCanPublishAfterImages=false;
    materialsCatalogRenderSync({ok:true,state:'DONE',published:true,total:Number(j.preparedImages||0),processed:Number(j.preparedImages||0),success:Number(j.preparedImages||0),failed:0});
  }catch(e){ if(status) status.textContent='Fout: '+(e?.message||e); if(btn) btn.disabled=false; }
}
async function materialsCatalogRetryImages(){
  if(!materialsCatalogImportId) return;
  const status=document.getElementById('matCsvStatus');
  try{
    const r=await fetch('/api/admin/materials/catalog_retry_images',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({importId:materialsCatalogImportId})});
    const j=await r.json().catch(()=>({})); if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    if(status) status.textContent='Afbeeldingen opnieuw voorbereiden gestart. Publiceren wordt vrijgegeven zodra alles gelukt is.';
    materialsCatalogStartPolling();
  }catch(e){ if(status) status.textContent='Afbeeldingen opnieuw proberen mislukt: '+(e?.message||e); }
}

function materialsResetFilters(){
  const ids = ['materialsFilterThickness','materialsFilterDimension','materialsFilterCategory','materialsFilterBrandText','materialsFilterAvailability'];
  ids.forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  materialsRenderList();
}
function initMaterialsManager(){
  if(window.__materialsManagerInit) return;
  window.__materialsManagerInit = true;
  const s = document.getElementById('materialsSearch');
  if(s) s.addEventListener('input', ()=>materialsRenderList());
  const toggle = document.getElementById('materialsFiltersToggle');
  if(toggle) toggle.addEventListener('click', ()=>materialsToggleFilters());
  const reset = document.getElementById('materialsResetFiltersBtn');
  if(reset) reset.addEventListener('click', materialsResetFilters);
  ['materialsFilterThickness','materialsFilterDimension','materialsFilterCategory','materialsFilterBrandText','materialsFilterAvailability'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.addEventListener(id==='materialsFilterBrandText' ? 'input' : 'change', ()=>materialsRenderList());
  });
  const csvPreview = document.getElementById('matCsvPreviewBtn');
  if(csvPreview) csvPreview.addEventListener('click', materialsCatalogPreview);
  const csvPublish = document.getElementById('matCsvPublishBtn');
  if(csvPublish) csvPublish.addEventListener('click', materialsCatalogPublish);
  const csvInput = document.getElementById('matCsvInput');
  if(csvInput) csvInput.addEventListener('change', ()=>{
    materialsCatalogImportId='';
    materialsCatalogCanPublishAfterImages=false;
    if(materialsCatalogPollTimer){clearInterval(materialsCatalogPollTimer);materialsCatalogPollTimer=null;}
    const pub=document.getElementById('matCsvPublishBtn'); if(pub) pub.disabled=true;
    const status=document.getElementById('matCsvStatus'); if(status) status.textContent=csvInput.files?.length?'CSV gekozen. Klik op “CSV controleren”.':'Nog geen CSV gekozen.';
    const summary=document.getElementById('matCsvSummary'); if(summary){summary.style.display='none';summary.innerHTML='';}
    const notices=document.getElementById('matCsvNotices'); if(notices){notices.style.display='none';notices.innerHTML='';}
  });
  materialsUpdateFiltersToggleLabel();
}

async function loadControlCenter(){
  const el = document.getElementById('ccOut');
  if(!el) return;
  try{
    const r = await fetch('/api/admin/control_center', {cache:'no-store'});
    const j = await r.json();
    const v = j.versions || {};
    const s = j.storage || {};
    const f = j.failures || [];
    const pricing = v.pricing || {};
    const materials = v.materials || {};
    const dxf = v.dxfLibrary || {};
    const opt = v.optimizer || {};
    function fmtBytes(n){
      n = Number(n||0);
      const u=['B','KB','MB','GB','TB']; let i=0;
      while(n>=1024 && i<u.length-1){ n/=1024; i++; }
      return (i===0? String(Math.round(n)) : n.toFixed(1)) + ' ' + u[i];
    }
    let html = '';
    html += `<div style="display:grid; gap:8px;">`;
    html += `<div><b>Actief nu</b></div>`;
    html += `<div>💶 Prijzen: <code>${pricing.exists? 'pricing_active.json' : '—'}</code> <span class="muted">${pricing.modified?('(' + pricing.modified + ')'):''}</span></div>`;
    html += `<div>🪵 Materialen: <code>${materials.file||'material_library.json'}</code> <span class="muted">${materials.modified?('(' + materials.modified + ')'):''}</span></div>`;
    html += `<div>📐 DXF lijst: <code>${dxf.file||'embedded_dxfs_manifest.json'}</code> <span class="muted">${dxf.modified?('(' + dxf.modified + ')'):''}</span></div>`;
    html += `<div>🧠 Optimizer: <code>${opt.active||'—'}</code></div>`;
    html += `<hr style="border:0; border-top:1px solid rgba(255,255,255,.08); margin:6px 0;">`;
    html += `<div><b>Opslag</b></div>`;
    html += `<div>Jobs: <code>${s.jobsCount??'—'}</code> · Grootte jobs-map: <code>${fmtBytes(s.jobsBytes||0)}</code></div>`;
    if(s.largestJob && s.largestJob.jobId){
      html += `<div>Grootste job: <code>${_h(s.largestJob.jobId)}</code> · <code>${fmtBytes(s.largestJob.bytes||0)}</code></div>`;
    }
    if(f && f.length){
      html += `<hr style="border:0; border-top:1px solid rgba(255,255,255,.08); margin:6px 0;">`;
      html += `<div><b>Laatste fouten</b> <span class="muted">(laatste 5)</span></div>`;
      for(const x of f){
        html += `<div style="padding:8px 10px; border:1px solid rgba(255,255,255,.08); border-radius:10px; background:#0e1416;">`
             + `<div><code>${_h(x.jobId||'')}</code> <span class="muted">${_h(x.modified||'')}</span></div>`
             + `<div class="muted" style="white-space:pre-wrap; margin-top:4px;">${_h(x.excerpt||'')}</div>`
             + `</div>`;
      }
    }else{
      html += `<div class="muted">Geen recente fouten gevonden.</div>`;
    }
    html += `</div>`;
    el.className = '';
    el.innerHTML = html;
  }catch(e){
    el.className = 'muted';
    el.textContent = 'Kon beheer-info niet laden: ' + (e && e.message ? e.message : e);
  }
}

// --- Mailbox (Requests) ---
let mb_tab = 'inbox';
let mb_cache = [];
let mb_openRid = null;
function mb_dotClass(st){
  const pub = String(st.publicStatus||'').toUpperCase();
  const intr = String(st.internalStatus||'').toUpperCase();
  if(pub === 'CANCELLED') return 'gray';
  if(intr === 'FAILED' || pub === 'FAILED' || pub === 'ERROR') return 'red';
  if(pub === 'DONE' || pub === 'AFGEHANDELD') return 'yellow';
  if(pub === 'OFFER_SENT' || pub === 'IN_PRODUCTION' || intr === 'PROCESSING') return 'blue';
  if(pub === 'SUBMITTED') return 'green';
  return 'gray';
}
function mb_statusBadge(label, cls){
  return `<span class="mbBadge ${cls}">${esc(label||'—')}</span>`;
}
function mb_matchesTab(st){
  const pub = String(st.publicStatus||'').toUpperCase();
  const intr = String(st.internalStatus||'').toUpperCase();
  if(mb_tab === 'inbox') return pub === 'SUBMITTED';
  if(mb_tab === 'processing') return (pub === 'OFFER_SENT' || pub === 'IN_PRODUCTION' || intr === 'PROCESSING');
  if(mb_tab === 'errors') return intr === 'FAILED' || pub === 'FAILED' || pub === 'ERROR';
  if(mb_tab === 'afgehandeld') return pub === 'DONE' || pub === 'AFGEHANDELD';
  if(mb_tab === 'alles') return true;
  return true;
}
function mb_matchesSearch(st, q){
  q = String(q||'').trim().toLowerCase();
  if(!q) return true;
  const rid = String(st.requestId||'').toLowerCase();
  const cn = String(st.customer?.name||'').toLowerCase();
  return rid.includes(q) || cn.includes(q);
}
function mb_money(v){ const n = Number(v); return Number.isFinite(n) ? new Intl.NumberFormat('nl-NL',{style:'currency',currency:'EUR'}).format(n) : '—'; }
function mb_formatBytes(v){
  const n = Number(v||0);
  if(!Number.isFinite(n) || n <= 0) return '0 B';
  const units = ['B','KB','MB','GB','TB'];
  let i = 0; let val = n;
  while(val >= 1024 && i < units.length-1){ val /= 1024; i++; }
  const digits = (i === 0 ? 0 : (val >= 100 ? 0 : val >= 10 ? 1 : 2));
  return `${val.toFixed(digits)} ${units[i]}`;
}
function mb_renderStorageSummary(ss){
  if(!ss || typeof ss !== 'object') return '';
  const total = Number(ss.totalBytes||0);
  if(!Number.isFinite(total) || total <= 0) return '';
  const jobs = Number(ss.jobsBytes||0);
  const req = Number(ss.requestBytes||0);
  const bits = [];
  if(jobs > 0) bits.push(`Jobs ${mb_formatBytes(jobs)}`);
  if(req > 0) bits.push(`Request ${mb_formatBytes(req)}`);
  return `<div class="mbSectionTitle">Opslag</div><div class="mbPriceCard"><div class="mbPriceRow emph"><span>Totale jobgrootte</span><strong>${esc(mb_formatBytes(total))}</strong></div><div class="mbFileMeta" style="margin-top:8px;">${esc(bits.join(' · '))}</div></div>`;
}
function mb_renderPricingSummary(ps){
  if(!ps || typeof ps !== 'object') return '';
  const rows = [];
  const push = (label, val, emph=false) => { if(val===null || val===undefined || val==='') return; rows.push(`<div class="mbPriceRow${emph?' emph':''}"><span>${esc(label)}</span><strong>${esc(mb_money(val))}</strong></div>`); };
  const totalEx = (ps.subtotalExVat!==null && ps.subtotalExVat!==undefined) ? ps.subtotalExVat : null;
  const totalIncl = (ps.totalInclVat!==null && ps.totalInclVat!==undefined) ? ps.totalInclVat : null;
  if(totalEx===null && totalIncl===null) return '';
  push('Plaatmateriaal (CSV, incl. btw)', ps.materialsTotalInclVat, false);
  push('Kantenband (excl. btw)', ps.edgeBandTotal, false);
  push('CNC (excl. btw)', ps.cncTotal, false);
  push('Tekenen (excl. btw)', ps.drawingTotal, false);
  push('Transport (excl. btw)', ps.transportTotal, false);
  push('Fiscaal subtotaal excl. btw', totalEx, false);
  push('Totaal incl. btw', totalIncl, true);
  return `<div class="mbSectionTitle">Prijs</div><div class="mbPriceCard">${rows.join('')}</div>`;
}
function mb_renderFileActions(manifest){
  const parts = [];
  const zip = manifest?.zip || {};
  const pricingSummary = manifest?.pricingSummary || {};
  const storageSummary = manifest?.storageSummary || {};
  const summaryFiles = Array.isArray(manifest?.summaryFiles) ? manifest.summaryFiles : [];
  const groups = Array.isArray(manifest?.dxfGroups) ? manifest.dxfGroups : [];
  const summaryKinds = ['quote','report','placements','stickertool','stickers','summary','pricing'];
  const labels = {quote:'Quote', report:'Report', placements:'Placements', stickers:'Stickers', stickertool:'Stickertool', summary:'Berekening', pricing:'Pricing'};
  parts.push(`<div class="mbSectionTitle">Downloads</div>`);
  parts.push(`<div class="mbFileGrid">`);
  if(zip.allOutputsUrl) parts.push(`<a class="pill premiumPill" download data-stop-propagation="1" href="${esc(zip.allOutputsUrl)}">Alles ZIP</a>`);
  if(zip.allDxfUrl) parts.push(`<a class="pill premiumPill" download data-stop-propagation="1" href="${esc(zip.allDxfUrl)}">Alle DXF's ZIP</a>`);
  for(const kind of summaryKinds){
    const f = summaryFiles.find(x => String(x.kind||'')===kind);
    if(f) parts.push(`<a class="pill premiumPill" download data-stop-propagation="1" href="${esc(f.url||'#')}">${esc(labels[kind]||f.name||kind)}</a>`);
  }
  parts.push(`</div>`);
  parts.push(mb_renderStorageSummary(storageSummary));
  parts.push(mb_renderPricingSummary(pricingSummary));
  parts.push(`<div class="mbSectionTitle">DXF bestanden</div>`);
  if(!groups.length){
    parts.push(`<div class="muted">Geen DXF bestanden gevonden voor deze order.</div>`);
  } else {
    for(const g of groups){
      const glabel = esc(g.label || g.materialName || g.materialCode || g.jobId || 'DXF');
      parts.push(`<div class="mbFileGroup"><div class="mbFileGroupHead">${glabel}</div>`);
      for(const f of (g.files || [])){
        const meta = [];
        if(f.size) meta.push(Math.max(1, Math.round(Number(f.size||0)/1024)) + ' KB');
        if(f.mtime) meta.push(String(f.mtime).replace('T',' ').replace('Z',''));
        parts.push(`<div class="mbFileLine"><div><div style="font-family:ui-monospace,Menlo,monospace; font-size:12px;">${esc(f.name||'')}</div><div class="mbFileMeta">${esc(meta.join(' · '))}</div></div><a class="pill" data-stop-propagation="1" href="${esc(f.url||'#')}">Download</a></div>`);
      }
      parts.push(`</div>`);
    }
  }
  return parts.join('');
}

async function mb_loadRequestFiles(rid){
  const box = document.getElementById('mbFilesBox');
  if(!box) return;
  box.innerHTML = `<div class="muted">Bestanden laden…</div>`;
  try{
    const r = await fetch('/api/admin/request_files?requestId=' + encodeURIComponent(rid), {cache:'no-store'});
    const j = await r.json().catch(()=>({}));
    if(!r.ok || !j.ok){
      box.innerHTML = `<div class="muted">Kon bestanden niet laden.</div>`;
      return;
    }
    box.innerHTML = mb_renderFileActions(j.files || {});
  }catch(e){
    box.innerHTML = `<div class="muted">Kon bestanden niet laden.</div>`;
  }
}

function mb_setDetails(st){
  const det = document.getElementById('mbDetails');
  const body = document.getElementById('mbDetailsBody');
  if(!det || !body) return;
  document.querySelectorAll('#mbTbody tr.mbRow').forEach(row=>row.classList.toggle('active', !!st && String(row.getAttribute('data-rid')||'')===String(st.requestId||'')));
  if(!st){
    mb_openRid = null;
    det.open = false;
    det.style.display='none';
    try{ if(location.hash && location.hash.startsWith('#request=')) history.replaceState(null,'',location.pathname + location.search); }catch(e){}
    return;
  }
  mb_openRid = String(st.requestId||'');
  det.style.display='block';
  const err = st.error ? JSON.stringify(st.error, null, 2) : '';
  const job = st.job || {};
  const sj = Array.isArray(job.subjobs) ? job.subjobs : [];
  const customerName = st.customer?.name || '—';
  const dot = mb_dotClass(st);
  const pub = String(st.publicStatusLabel || st.publicStatus || '—');
  const intr = String(st.internalStatusLabel || st.internalStatus || '—');
  const parts = [];
  parts.push(`<div class="mbDetailsCard">`);
  parts.push(`<div class="mbDetailsHead"><div style="font-weight:900; font-size:15px;">Orderdetails</div><div class="mbBadgeRow">${mb_statusBadge(pub, dot)}${mb_statusBadge(intr, dot==='green'?'gray':dot)}</div></div>`);
  parts.push(`<div class="mbDetailsBody">`);
  parts.push(`<div class="mbInfoGrid">`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Request</div><div class="mbValue mono">${esc(st.requestId||'')}</div></div>`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Klant</div><div class="mbValue">${esc(customerName)}</div>${st.customer?.email ? `<div class="mbFileMeta">${esc(st.customer.email)}</div>` : ``}${st.customer?.phone ? `<div class="mbFileMeta">${esc(st.customer.phone)}</div>` : ``}</div>`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Job</div><div class="mbValue mono">${esc(job.parentJobId||'—')}</div><div class="mbFileMeta">Subjobs: ${esc(String(sj.length||0))}</div></div>`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Aangemaakt</div><div class="mbValue mono">${esc(st.createdAt||'—')}</div></div>`);
  parts.push(`</div>`);
  parts.push(`<div id="mbFilesBox" style="margin-top:12px;"></div>`);
  if(err){
    parts.push(`<div style="margin-top:12px;"><div class="mbLabel">Error</div><pre style="white-space:pre-wrap; background:rgba(255,255,255,.03); border:1px solid rgba(255,255,255,.08); padding:12px; border-radius:12px;">${esc(err)}</pre></div>`);
  }
  parts.push(`</div></div>`);
  body.innerHTML = parts.join('');
  try{ det.open = true; }catch(e){}
  mb_loadRequestFiles(st.requestId||'');
}

async function mb_load(){
  const tb = document.getElementById('mbTbody');
  if(tb) tb.innerHTML = `<tr><td colspan="7" class="muted">laden…</td></tr>`;
  const r = await fetch('/api/admin/requests?limit=500', {cache:'no-store', credentials:'same-origin'});
  const j = await r.json().catch(()=>({}));
  mb_cache = (j.requests || []);
  mb_render();
}
function mb_render(){
  const tb = document.getElementById('mbTbody');
  if(!tb) return;
  const q = document.getElementById('mbSearch')?.value || '';
  const rows = mb_cache.filter(st=>mb_matchesTab(st) && mb_matchesSearch(st, q));
  if(!rows.length){
    tb.innerHTML = `<tr><td colspan="7" class="muted">Geen items</td></tr>`;
    mb_setDetails(null);
    return;
  }
  let html = '';
  for(const st of rows){
    const dot = mb_dotClass(st);
    const rid = esc(st.requestId||'');
    const cn = esc(st.customer?.name||'—');
    const pub = esc(st.publicStatus||'');
    const intr = esc(st.internalStatus||'');
    const created = esc(st.createdAt||'');
    const canMark = (String(st.publicStatus||'').toUpperCase()==='SUBMITTED' && String(st.quoteStatus||'').toUpperCase()==='TODO');
    html += `<tr class="mbRow" data-rid="${rid}">
      <td><span class="dot ${dot}"></span></td>
      <td style="font-family:ui-monospace,Menlo,monospace; font-size:12px;">${rid}</td>
      <td>${cn}</td>
      <td>${mb_statusBadge(pub, dot)}</td>
      <td>${mb_statusBadge(intr, dot==='green'?'gray':dot)}</td>
      <td style="font-size:12px;">${created}</td>
      <td>
        ${canMark ? `<button class="mbActionBtn" data-act="sent" data-rid="${rid}" type="button">Aanvraag afhandelen</button>` : ``}
        ${(!canMark && (['AFGEHANDELD','DONE'].includes(String(st.publicStatus||'').toUpperCase()))) ? `<button class="mbActionBtn" data-act="reopen" data-rid="${rid}" type="button">Heropen</button>` : ``}
      </td>
    </tr>`;
  }
  tb.innerHTML = html;
  tb.querySelectorAll('tr.mbRow').forEach(tr=>{
    tr.addEventListener('click', (ev)=>{
      const rid = String(tr.getAttribute('data-rid')||'');
      const isSameOpen = (mb_openRid === rid) && !!document.getElementById('mbDetails') && document.getElementById('mbDetails').style.display !== 'none';
      if(isSameOpen){
        mb_setDetails(null);
        return;
      }
      const st = mb_cache.find(x=>String(x.requestId||'')===rid);
      mb_setDetails(st||null);
      try{ location.hash = 'request=' + rid; }catch(e){}
    });
  });
  tb.querySelectorAll('button[data-act]').forEach(btn=>{
    btn.addEventListener('click', async (ev)=>{
      ev.stopPropagation();
      const rid = btn.getAttribute('data-rid');
      const act = btn.getAttribute('data-act');
      btn.disabled = true;
      const rr = await fetch('/api/admin/requests/update', {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'}, body: JSON.stringify({requestId: rid, action: act==='sent'?'mark_quote_sent':'reopen'})});
      await rr.json().catch(()=>({}));
      await mb_load();
    });
  });
}
function mb_init(){
  const tabs = document.getElementById('mbTabs');
  const search = document.getElementById('mbSearch');
  const ref = document.getElementById('mbRefreshBtn');
  if(tabs && !tabs.__bound){
    tabs.querySelectorAll('button.tabBtn').forEach(b=>{
      b.addEventListener('click', ()=>{
        tabs.querySelectorAll('button.tabBtn').forEach(x=>x.classList.remove('active'));
        b.classList.add('active');
        mb_tab = b.getAttribute('data-tab')||'alles';
        mb_render();
      });
    });
    tabs.__bound=true;
  }
  if(search && !search.__bound){
    search.addEventListener('input', ()=>mb_render());
    search.__bound=true;
  }
  if(ref && !ref.__bound){
    ref.addEventListener('click', ()=>mb_load());
    ref.__bound=true;
  }
  // hash jump
  try{
    if(location.hash && location.hash.startsWith('#request=')){
      const rid = decodeURIComponent(location.hash.replace('#request=',''));
      const st = mb_cache.find(x=>String(x.requestId||'')===rid);
      if(st) mb_setDetails(st);
    }
  }catch(e){}
}

async function load(){
  initAdminShell();
  reloadPricing();
  loadControlCenter();
  initMaterialsManager();
  materialsReload();
  try{ mb_init(); }catch(e){}
  try{ await mb_load(); }catch(e){}
  const r = await fetch('/api/admin/jobs', {cache:'no-store', credentials:'same-origin'});
  const data = await r.json();
  const el = document.getElementById('out');
  if(!data.jobs.length){ el.innerHTML = '<div class="muted">Nog geen jobs.</div>'; return; }
  let html = '<table><thead><tr><th>JobId</th><th>Status</th><th>Created</th><th>Outputs</th></tr></thead><tbody>';
  const childrenMap = {};
  const masters = [];
  const masterSet = new Set();
  for(const jj of data.jobs){
    const id = String(jj.jobId||'');
    if(id.includes('__mat_')){
      const master = id.split('__mat_')[0];
      (childrenMap[master] = childrenMap[master] || []).push(jj);
    }else{
      masters.push(jj);
      masterSet.add(id);
    }
  }

  function safeKey(s){
    return String(s||'').replace(/[^a-zA-Z0-9_-]/g,'_');
  }

  function sealedMetaLinks(j){
    const files=(j.sealedFiles||[]).filter(f=>String(f.kind||'')!=='dxf');
    return files.map(f=>{
      const rel=String(f.rel||'');
      const name=String(f.name||rel||'bestand');
      const url=`/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent(rel)}`;
      if(name==='calculation_summary.txt'){
        return `<a class="btn" style="padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px; background:rgba(47,191,106,.18); border:1px solid rgba(47,191,106,.35); color:#e8f3ee; font-weight:800" href="${url}" download>Berekening</a>`
             + `<button class="btn secondary" style="padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px;" type="button" data-open-text-url="${esc(url)}" data-open-text-title="Berekening">Bekijk</button>`;
      }
      if(name==='stickertool.json'){
        return `<a class="btn" style="padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px; background:rgba(47,191,106,.18); border:1px solid rgba(47,191,106,.35); color:#e8f3ee; font-weight:900" href="${url}" download>stickertool.json (v2)</a>`;
      }
      return `<a class="btn secondary" style="padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px;" href="${url}" download>${esc(name)}</a>`;
    }).join('');
  }

  for(const j of masters){
    const jid = String(j.jobId||'');
    const gkey = safeKey(jid);
    const kids0 = (childrenMap[j.jobId]||[]);
    const kids = kids0.sort((a,b)=>String(a.jobId||'').localeCompare(String(b.jobId||'')));
    const kidCount = kids.length;

	    const dlZaag = j.zaagplaten && j.zaagplaten.length
	      ? j.zaagplaten.map(z=>{
	          const f=_zaagFile(z), t=_zaagLabel(z);
	          return `<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Zaagplaten/' + f)}\">${t}</a>`;
	        }).join('')
	      : '';
    const dlParts = j.onderdelen && j.onderdelen.length
      ? j.onderdelen.map(s=>`<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Onderdelen/' + s)}\">${esc(s)}</a>`).join('')
      : '';
    const dlSheetsFallback = j.sheets && j.sheets.length
      ? j.sheets.map(s=>`<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/download/${encodeURIComponent(s)}\">${esc(s)}</a>`).join('')
      : '';
    const dlSheets = (dlZaag || dlParts)
      ? (`<div style=\"margin-bottom:6px\"><span class=\"muted\">Zaagplaten:</span> ${dlZaag || '<span class=\\"muted\\">—</span>'}</div>`
         + `<div><span class=\"muted\">Onderdelen:</span> ${dlParts || '<span class=\\"muted\\">—</span>'}</div>`)
      : (dlSheetsFallback || '<span class=\"muted\">—</span>');

    const dlMeta = sealedMetaLinks(j);

    
    const edgeDecor = j.edgeBandByDecorMeters || {};
    let edgeHtml = '';
    try{
      const keys = Object.keys(edgeDecor||{});
      if(keys.length){
        edgeHtml = '<div style="margin-top:8px"><div class="muted" style="margin-bottom:4px">Kantenband per decor (m):</div>'
          + keys.map(k=>`<div style="display:flex; gap:10px"><div style="min-width:220px; font-weight:800">${esc(k)}</div><div>${Number(edgeDecor[k]||0).toFixed(2)}</div></div>`).join('')
          + `<div style="display:flex; gap:10px; margin-top:6px; padding-top:6px; border-top:1px solid rgba(255,255,255,.12)"><div style="min-width:220px; font-weight:900">Totaal</div><div>${keys.reduce((a,k)=>a+Number(edgeDecor[k]||0),0).toFixed(2)}</div></div>`
          + '</div>';
      }
    }catch(e){}

    const _cntZaag = (j.zaagplaten&&j.zaagplaten.length)?j.zaagplaten.length:0;
    const _cntOnd = (j.onderdelen&&j.onderdelen.length)?j.onderdelen.length:0;
    const _cntMeta = (j.sealedFiles||[]).filter(f=>String(f.kind||'')!=='dxf').length;
    const _sum = `DXF: ${_cntZaag+_cntOnd} · Overig: ${_cntMeta}`;
    const _body = `<div class=\"jobOutBody\" style=\"display:flex; flex-wrap:wrap; gap:6px;\">${dlSheets}${dlMeta}</div>` + edgeHtml;
    const dl = `<details class=\"jobOut\"><summary>${_sum}</summary>${_body}</details>`;
    const toggleBtn = kidCount
      ? `<button class="groupToggle" type="button" data-group="${gkey}" aria-expanded="false">▸</button>`
      : `<span style="display:inline-block; width:34px"></span>`;
    const kidBadge = kidCount ? `<span class="muted" style="margin-left:8px">(${kidCount} materiaal)</span>` : '';
    html += `<tr class="masterRow" data-group="${gkey}"><td><div style="display:flex; align-items:center; gap:10px">${toggleBtn}<code>${_jobLabel(j)}</code>${kidBadge}</div></td><td>${esc(j.status||'')}</td><td class="muted">${esc(j.createdAt||'')}</td><td class="outputsTd"><div class="outputsCell">${dl}</div></td></tr>`;
    for(const c of kids){
      // reuse dl generation by temporarily mapping j->c
      const j = c;
      const masterJobId = jid;

	  const hasZaag = !!(j.zaagplaten && j.zaagplaten.length);
	      const dlZaag = j.zaagplaten && j.zaagplaten.length
	        ? j.zaagplaten.map(z=>{
	            const f=_zaagFile(z), t=_zaagLabel(z);
	            return `<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Zaagplaten/' + f)}\">${t}</a>`;
	          }).join('')
	        : '';
      const dlParts = j.onderdelen && j.onderdelen.length
        ? j.onderdelen.map(s=>`<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Onderdelen/' + s)}\">${esc(s)}</a>`).join('')
        : '';
      const dlSheetsFallback = j.sheets && j.sheets.length
        ? j.sheets.map(s=>`<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/download/${encodeURIComponent(s)}\">${esc(s)}</a>`).join('')
        : '';
      const partsCount = (j.onderdelen && j.onderdelen.length) ? j.onderdelen.length : 0;
      const partsBlock = partsCount
        ? (`<details>`
            + `<summary class=\"muted\">Onderdelen (${partsCount})</summary>`
            + `<div style=\"margin-top:6px; display:flex; flex-wrap:wrap; gap:6px\">${dlParts}</div>`
          + `</details>`)
        : (`<div><span class=\"muted\">Onderdelen:</span> <span class=\"muted\">—</span></div>`);

      const dlSheets = (dlZaag || dlParts)
        ? (`<div style=\"margin-bottom:6px\"><span class=\"muted\">Zaagplaten:</span> <div style=\"margin-top:6px; display:flex; flex-wrap:wrap; gap:6px\">${dlZaag || '<span class=\\\"muted\\\">—</span>'}</div></div>`
           + partsBlock)
        : (dlSheetsFallback || '<span class=\"muted\">—</span>');
      const dlMeta = sealedMetaLinks(j);
      const _cntZaag = (j.zaagplaten&&j.zaagplaten.length)?j.zaagplaten.length:0;
      const _cntOnd = (j.onderdelen&&j.onderdelen.length)?j.onderdelen.length:0;
      const _cntMeta = (j.sealedFiles||[]).filter(f=>String(f.kind||'')!=='dxf').length;
      const _sum = `DXF: ${_cntZaag+_cntOnd} · Overig: ${_cntMeta}`;
      const _body = `<div class=\"jobOutBody\" style=\"display:flex; flex-wrap:wrap; gap:6px;\">${dlSheets}${dlMeta}</div>`;
      const dl = `<details class=\"jobOut ${hasZaag?'zaagHi':''}\"><summary>${_sum}</summary>${_body}</details>`;
      html += `<tr class=\"childRow ${hasZaag?'zaagRow':''}\" data-parent=\"${gkey}\" style=\"background:rgba(255,255,255,.02)\"><td><span class=\"jobIndent\"><span class=\"arrow\">↳</span><code>${_jobLabel(j)}</code></span></td><td>${esc(j.status||'')}</td><td class=\"muted\">${esc(j.createdAt||'')}</td><td class=\"outputsTd\"><div class=\"outputsCell\">${dl}</div></td></tr>`;
    }

  }
  html += '</tbody></table>';
  el.innerHTML = html;

  el.querySelectorAll('[data-open-text-url]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      e.stopPropagation();
      openTextModal(btn.getAttribute('data-open-text-url') || '', btn.getAttribute('data-open-text-title') || 'Bestand');
    });
  });

  // toggle groups
  function setGroupVisible(groupKey, visible){
    const rows = el.querySelectorAll(`tr.childRow[data-parent="${groupKey}"]`);
    rows.forEach(r=>{ r.style.display = visible ? 'table-row' : 'none'; });
    const btn = el.querySelector(`button.groupToggle[data-group="${groupKey}"]`);
    if(btn){
      btn.textContent = visible ? '▾' : '▸';
      btn.setAttribute('aria-expanded', visible ? 'true' : 'false');
    }
  }
  el.querySelectorAll('button.groupToggle').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      e.stopPropagation();
      const k = btn.getAttribute('data-group');
      const expanded = btn.getAttribute('aria-expanded')==='true';
      setGroupVisible(k, !expanded);
    });
  });
}
load();
  loadControlCenter();

function openTextModal(url, title){
  const m = document.getElementById('textModal');
  const t = document.getElementById('textModalTitle');
  const b = document.getElementById('textModalBody');
  const dl = document.getElementById('textModalDownload');
  if(!m||!t||!b||!dl) return;
  t.textContent = title || 'Bestand';
  b.textContent = 'Laden…';
  dl.href = url;
  m.style.display = 'flex';
  fetch(url).then(r=>r.text()).then(txt=>{ b.textContent = txt; }).catch(()=>{ b.textContent='Kon bestand niet laden.'; });
}
function closeTextModal(){
  const m = document.getElementById('textModal');
  if(m) m.style.display='none';
}
document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeTextModal(); });
document.addEventListener('click', (e)=>{
  const stop=e.target.closest('[data-stop-propagation="1"]');
  if(stop) e.stopPropagation();
  const trigger=e.target.closest('[data-admin-action]');
  if(!trigger) return;
  const action=trigger.getAttribute('data-admin-action');
  const allowed=new Set(['materialsReload','savePricing','reloadPricing','refreshSystemPage','createSystemBackup','load']);
  if(allowed.has(action) && typeof window[action]==='function') window[action]();
});
document.getElementById('adminLogoutBtn')?.addEventListener('click', async ()=>{
  try {
    await fetch('/api/admin/logout', {method:'POST', credentials:'same-origin', headers:{'X-Requested-With':'fetch'}});
  } finally {
    window.location.replace('/admin/');
  }
});

  try { window.load = load; } catch(e) {}
}
</script>
</body></html>"""

ADMIN_LOGIN_HTML = """<!doctype html>
<html lang="nl"><head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>METOD Admin Login</title>
<style>
  :root{color-scheme:dark;}
  *{box-sizing:border-box;}
  body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:22px;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:radial-gradient(circle at 20% 12%,rgba(47,191,106,.18),transparent 32%),linear-gradient(135deg,#0b1014,#121a20 55%,#0a0e11);color:#e8f3ee;}
  .card{width:min(440px,100%);border:1px solid rgba(255,255,255,.12);border-radius:28px;background:linear-gradient(180deg,rgba(255,255,255,.075),rgba(255,255,255,.035));box-shadow:0 28px 100px rgba(0,0,0,.45);padding:28px;}
  .brand{display:flex;align-items:center;gap:12px;margin-bottom:18px;}
  .logo{width:42px;height:42px;border-radius:14px;background:linear-gradient(135deg,#2fbf6a,#9de8b7);box-shadow:0 10px 30px rgba(47,191,106,.24);}
  h1{font-size:24px;margin:0 0 6px;font-weight:950;letter-spacing:-.03em;}
  p{margin:0;color:rgba(232,243,238,.72);font-size:14px;line-height:1.45;}
  label{display:block;margin:16px 0 7px;font-size:13px;font-weight:850;color:rgba(232,243,238,.84);}
  input{width:100%;border:1px solid rgba(255,255,255,.14);background:#0f1518;color:#fff;border-radius:15px;padding:14px 14px;font-size:16px;outline:none;}
  input:focus{border-color:rgba(47,191,106,.82);box-shadow:0 0 0 4px rgba(47,191,106,.14);}
  button{width:100%;margin-top:20px;border:0;border-radius:16px;padding:14px 16px;font-size:15px;font-weight:950;cursor:pointer;color:#062312;background:linear-gradient(135deg,#2fbf6a,#9de8b7);}
  button:disabled{opacity:.62;cursor:wait;}
  .msg{min-height:20px;margin-top:14px;font-size:13px;font-weight:800;color:#fecaca;}
  .hint{margin-top:18px;font-size:12px;color:rgba(232,243,238,.52);}
</style></head><body>
  <main class="card">
    <div class="brand"><div class="logo"></div><div><h1>Admin login</h1><p>Log in om jobs, aanvragen, pricing en DXF te beheren.</p></div></div>
    <form id="loginForm" autocomplete="on">
      <label for="user">Gebruikersnaam</label>
      <input id="user" name="username" autocomplete="username" value="admin" required />
      <label for="pass">Wachtwoord</label>
      <input id="pass" name="password" type="password" autocomplete="current-password" required />
      <label for="otp">Authenticatorcode</label>
      <input id="otp" name="otp" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required />
      <button id="btn" type="submit">Inloggen</button>
      <div id="msg" class="msg"></div>
      <div class="hint">Het wachtwoord wordt server-side gecontroleerd. Alleen een HttpOnly sessiecookie wordt opgeslagen.</div>
    </form>
  </main>
<script>
(function(){
  const form=document.getElementById('loginForm');
  const btn=document.getElementById('btn');
  const msg=document.getElementById('msg');
  const pass=document.getElementById('pass');
  function setMsg(t){ msg.textContent=t||''; }
  try { sessionStorage.clear(); } catch(e) {}
  form.addEventListener('submit', async function(ev){
    ev.preventDefault();
    setMsg('');
    const username=(document.getElementById('user').value||'admin').trim();
    const password=pass.value||'';
    if(!password){ setMsg('Vul je wachtwoord in.'); pass.focus(); return; }
    btn.disabled=true; btn.textContent='Controleren...';
    try{
      const otp=(document.getElementById('otp').value||'').replace(/\\s+/g,'');
      const r=await fetch('/api/admin/login', {method:'POST', credentials:'same-origin', cache:'no-store', headers:{'Content-Type':'application/json','X-Requested-With':'fetch'}, body:JSON.stringify({username,password,otp})});
      let j={}; try{j=await r.json();}catch(e){}
      if(!r.ok || !j.ok){ throw new Error(j.error || ('HTTP '+r.status)); }
      // FIX629: Safari/iOS can set the HttpOnly cookie only after the current JS turn.
      // Do not immediately call /api/admin/jobs here; redirect and let the next page load use the cookie.
      window.location.href='/admin/?v=629ok&ts='+Date.now();
    }catch(e){
      setMsg('Login mislukt. Controleer gebruikersnaam/wachtwoord.');
      btn.disabled=false; btn.textContent='Inloggen';
      pass.focus(); pass.select();
    }
  });
  setTimeout(()=>pass.focus(),80);
})();
</script>
</body></html>"""



class Handler(SimpleHTTPRequestHandler):
    # Serve files from ROOT directory
    def _prepare_html(self, text: str) -> str:
        nonce = secrets.token_urlsafe(18)
        self._csp_nonce = nonce
        return re.sub(
            r'<(script|style)(?=[\s>])',
            lambda match: f'<{match.group(1)} nonce="{nonce}"',
            str(text),
            flags=re.IGNORECASE,
        )

    def translate_path(self, path: str) -> str:
        # Serve static files from an explicit public allowlist only.
        parsed = urlparse(path)
        rel = unquote(parsed.path.lstrip('/'))
        if rel == '':
            rel = 'toolA.html'
        if rel == 'admin':
            # pseudo path
            return str(ROOT / '__admin__.html')
        if _is_blocked_static_relpath(rel) or not _is_public_static_relpath(rel):
            return str(ROOT / '__forbidden_static__.404')
        if rel == 'embedded_dxfs_manifest.json':
            target = DXF_MANIFEST_PATH.resolve()
            allowed_root = STATE_ROOT.resolve()
        elif rel.startswith('embedded_dxfs/'):
            suffix = rel[len('embedded_dxfs/'):]
            try:
                target = resolve_relative_file(DXF_LIBRARY_ROOT, suffix)
            except SafetyContractError:
                return str(ROOT / '__forbidden_static__.404')
            allowed_root = DXF_LIBRARY_ROOT.resolve()
        else:
            target = (ROOT / rel).resolve()
            allowed_root = ROOT.resolve()
        if target != allowed_root and allowed_root not in target.parents:
            return str(ROOT / '__forbidden_static__.404')
        if target.is_dir():
            return str(ROOT / '__forbidden_static__.404')
        return str(target)

    def guess_type(self, path: str) -> str:
        if str(path).lower().endswith('.dxf'):
            return 'application/dxf'
        return super().guess_type(path)

    def end_headers(self):
        origin = str(self.headers.get('Origin') or '').strip()
        if origin:
            try:
                if _origin_allowed(origin, admin=False) or _origin_allowed(origin, admin=True):
                    self.send_header('Access-Control-Allow-Origin', origin)
                    self.send_header('Vary', 'Origin')
            except Exception:
                pass
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        # Prevent stale HTML/JS being cached between zip updates.
        # Users often unzip over the existing folder; without this, old toolA.html
        # can remain cached and cause "random" JS errors that were already fixed.
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'strict-origin-when-cross-origin')
        self.send_header('Permissions-Policy', 'accelerometer=(), autoplay=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        try:
            if urlparse(self.path).path.lower().startswith('/embedded_dxfs/') and urlparse(self.path).path.lower().endswith('.dxf'):
                name = _sanitize_filename(Path(unquote(urlparse(self.path).path)).name, 120) or 'drawing.dxf'
                self.send_header('Content-Disposition', f'attachment; filename="{name}"')
        except Exception:
            pass
        if _is_production_hardening_enabled():
            nonce = str(getattr(self, '_csp_nonce', '') or '')
            nonce_source = f" 'nonce-{nonce}'" if nonce else ''
            csp = "; ".join([
                "default-src 'self'",
                "base-uri 'self'",
                "object-src 'none'",
                "frame-ancestors 'none'",
                "frame-src 'none'",
                "img-src 'self' data: blob:",
                "font-src 'self' data:",
                f"style-src-elem 'self'{nonce_source}",
                "style-src-attr 'unsafe-inline'",
                f"script-src 'self'{nonce_source}",
                "script-src-attr 'none'",
                "connect-src 'self'",
                "worker-src 'self' blob:",
                "manifest-src 'self'",
                "media-src 'self' data: blob:",
                "form-action 'self'"
            ])
            self.send_header('Content-Security-Policy', csp)
            if _is_https_request(self):
                self.send_header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()


    def _load_admin_credentials(self):
        # Environment credentials remain a development-only compatibility path.
        u = os.environ.get("ADMIN_USER")
        p = os.environ.get("ADMIN_PASS")
        ph = os.environ.get("ADMIN_PASS_HASH")
        if u and (p or ph):
            return {
                "username": u, "password": p, "password_hash": ph,
                "totp_secret": os.environ.get('ADMIN_TOTP_SECRET') or '', "source": "env",
            }

        # Priority 2: external credentials file via env var (recommended production setup)
        creds_path = _get_admin_credentials_file_path()
        try:
            obj = strict_json_load(creds_path)
            if isinstance(obj, dict) and _normalized_admin_users(obj):
                result = dict(obj)
                result['source'] = "external_config" if creds_path != (ROOT / "config" / "admin_credentials.json") else "config"
                result['path'] = str(creds_path)
                return result
        except FileNotFoundError:
            pass
        except Exception:
            pass
        return None


    def _warn_if_local_admin_credentials_in_production(self, creds: dict | None) -> None:
        try:
            if not _is_production_hardening_enabled():
                return
            creds = creds or {}
            source = str(creds.get("source") or "")
            if source != "config":
                return
            msg = (
                "Production hardening is active, but admin credentials are still loaded from "
                "app/config/admin_credentials.json. Move credentials to an external path and set "
                "ADMIN_CREDENTIALS_FILE or ADMIN_CREDENTIALS_PATH for live deployment."
            )
            try:
                if not getattr(self.server, "_local_admin_credentials_warned", False):
                    print("[SECURITY WARNING] " + msg)
                    setattr(self.server, "_local_admin_credentials_warned", True)
            except Exception:
                print("[SECURITY WARNING] " + msg)
        except Exception:
            pass


    def _require_admin_write_origin(self) -> bool:
        ok, error = _helpers_require_same_origin_admin_write(
            self,
            is_loopback_value=_is_loopback_value,
            is_loopback_client=_is_loopback_client,
        )
        if ok:
            return True
        return self._send_json({'ok': False, 'error': error or 'Admin write origin blocked'}, 403)

    def _require_same_origin_public_write(self) -> bool:
        try:
            origin = str(self.headers.get('Origin') or '').strip()
            referer = str(self.headers.get('Referer') or '').strip()
            host_header = str(self.headers.get('Host') or '').strip()
            host_name = host_header.split(':', 1)[0].strip().lower() if host_header else ''

            def _matches_host(candidate_host: str) -> bool:
                # Development convenience only. Production writes require an exact
                # ALLOWED_ORIGINS match and never trust a client-controlled Host header.
                if _is_production_runtime():
                    return False
                candidate_host = str(candidate_host or '').strip().lower()
                if not candidate_host:
                    return False
                if host_name and candidate_host == host_name:
                    return True
                if host_name and _is_loopback_value(candidate_host) and _is_loopback_value(host_name):
                    return True
                return False

            if origin:
                if _origin_allowed(origin, admin=False):
                    return True
                try:
                    o = urlparse(origin)
                    if _matches_host(o.hostname or ''):
                        return True
                except Exception:
                    pass
                return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)

            if referer:
                try:
                    r = urlparse(referer)
                    ref_origin = f"{r.scheme}://{r.netloc}" if r.scheme and r.netloc else ''
                    if ref_origin and _origin_allowed(ref_origin, admin=False):
                        return True
                    if _matches_host(r.hostname or ''):
                        return True
                except Exception:
                    pass
                return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)

            if not _is_production_runtime() and _is_loopback_client(self):
                return True
            return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)
        except Exception:
            return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)

    def _api_admin_login(self):
        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
        except Exception:
            return self._send_json({'ok': False, 'authRequired': True, 'error': 'Invalid login payload'}, 400)
        creds = self._load_admin_credentials() or {}
        self._warn_if_local_admin_credentials_in_production(creds)
        users = _normalized_admin_users(creds)
        if not users:
            return self._send_json({'ok': False, 'authRequired': True, 'error': 'Admin authentication not configured'}, 403)
        if _is_production_hardening_enabled() and not _is_secure_admin_transport(self):
            return self._send_json({'ok': False, 'authRequired': True, 'error': 'Admin authentication requires HTTPS'}, 403)
        ip = _client_ip(self)
        if _rate_limit_is_blocked('admin_auth_fail', ip, 10, 300):
            return self._send_json({'ok': False, 'authRequired': True, 'error': 'Too many login attempts'}, 429)
        u_in = str(data.get('username') or '').strip()
        p_in = str(data.get('password') or '')
        otp_in = str(data.get('otp') or '')
        user = _find_admin_user(creds, u_in)
        stored_hash = str(user.get('password_hash') or '') if user else _DUMMY_ADMIN_PASSWORD_HASH
        stored_totp = str(user.get('totp_secret') or '') if user else _DUMMY_ADMIN_TOTP_SECRET
        # Always execute the expensive password and MFA paths so username existence
        # cannot be inferred from response time.
        password_ok = _verify_password_against_stored(p_in, stored_hash)
        mfa_ok = _verify_totp(stored_totp or _DUMMY_ADMIN_TOTP_SECRET, otp_in)
        if user and password_ok and (mfa_ok or (not _is_production_runtime() and not stored_totp)):
            _rate_limit_clear('admin_auth_fail', ip)
            token, exp = _admin_session_create(u_in, list(user.get('roles') or ['admin']))
            body = strict_json_dumps({'ok': True, 'expiresAt': int(exp), 'actor': u_in}).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            secure = '; Secure' if (_is_production_runtime() or _is_https_request(self)) else ''
            max_age = max(300, min(24 * 60 * 60, int(_ADMIN_SESSION_ABSOLUTE_SEC or 28800)))
            self.send_header('Set-Cookie', f"adzaagt_admin_session={token}; Path=/; SameSite=Strict; HttpOnly{secure}; Max-Age={max_age}")
            self.end_headers()
            self.wfile.write(body)
            return
        _rate_limit_record('admin_auth_fail', ip)
        _append_system_event(level="warning", component="auth", message_user="Admin login mislukt", message_tech=f"Invalid overlay login for user={u_in}", status="open")
        return self._send_json({'ok': False, 'authRequired': True, 'error': 'Invalid admin credentials'}, 401)


    def _check_admin_auth_silent(self) -> bool:
        creds = self._load_admin_credentials() or {}
        self._warn_if_local_admin_credentials_in_production(creds)
        if not _normalized_admin_users(creds):
            return False
        auth = self.headers.get("Authorization") or ""
        bearer = _extract_bearer_token(auth)
        if bearer and _admin_session_valid(bearer) and 'admin' in _admin_session_roles(bearer):
            return True
        cookie_token = _extract_admin_session_cookie(self.headers.get('Cookie') or '')
        if cookie_token and _admin_session_valid(cookie_token) and 'admin' in _admin_session_roles(cookie_token):
            return True
        if _is_production_runtime():
            return False
        if not auth.startswith("Basic "):
            return False
        try:
            decoded = base64.b64decode(auth.split(" ", 1)[1].strip()).decode("utf-8")
            supplied_user, supplied_pw = decoded.split(":", 1)
        except Exception:
            return False
        user = _find_admin_user(creds, supplied_user)
        return bool(user and _verify_password_against_stored(supplied_pw, str(user.get('password_hash') or '')))

    def _current_admin_session_token(self) -> str:
        bearer = _extract_bearer_token(self.headers.get('Authorization') or '')
        if bearer and _admin_session_valid(bearer) and 'admin' in _admin_session_roles(bearer):
            return bearer
        cookie = _extract_admin_session_cookie(self.headers.get('Cookie') or '')
        if cookie and _admin_session_valid(cookie) and 'admin' in _admin_session_roles(cookie):
            return cookie
        return ''

    def _current_admin_actor(self) -> str:
        token = self._current_admin_session_token()
        return _admin_session_actor(token) if token else ('local-development' if not _is_production_runtime() else '')

    def _api_admin_logout(self):
        token = self._current_admin_session_token()
        actor = _admin_session_actor(token)
        _admin_session_revoke(token)
        body = b'{"ok":true}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        secure = '; Secure' if (_is_production_runtime() or _is_https_request(self)) else ''
        self.send_header('Set-Cookie', f'adzaagt_admin_session=; Path=/; SameSite=Strict; HttpOnly{secure}; Max-Age=0')
        self.end_headers()
        self.wfile.write(body)
        if actor:
            _append_system_event(level='info', component='auth', message_user='Admin uitgelogd', message_tech='Session revoked', status='resolved', details={'actor': actor})

    def _wants_native_basic_prompt(self) -> bool:
        """Return True only for real browser navigations where native Basic Auth is acceptable.

        Admin HTML is served without Basic Auth. Admin API calls from the overlay/fetch layer
        should never receive WWW-Authenticate, because iOS Safari can turn that into the
        "download admin" prompt or a native modal instead of letting the overlay handle login.
        """
        try:
            xrw = (self.headers.get('X-Requested-With') or '').lower()
            if xrw:
                return False
            accept = (self.headers.get('Accept') or '').lower()
            sec_dest = (self.headers.get('Sec-Fetch-Dest') or '').lower()
            sec_mode = (self.headers.get('Sec-Fetch-Mode') or '').lower()
            if sec_dest == 'empty' or sec_mode in ('cors', 'same-origin'):
                return False
            # Direct URL navigation to /api/admin/* can still get the browser Basic prompt.
            return ('text/html' in accept) or sec_dest in ('document', '')
        except Exception:
            return False

    def _send_admin_auth_challenge(self, code: int = 401, message: str = 'Admin authentication required'):
        """Send auth-required response for admin API without triggering native Basic prompt for fetch.

        Fetch/XHR receives JSON + X-Admin-Auth-Required. Real browser navigation may receive
        WWW-Authenticate. This keeps /api/admin/* protected while allowing the admin overlay to
        control login on iOS Safari.
        """
        try:
            if not self._wants_native_basic_prompt():
                self.send_response(code)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
                self.send_header('X-Admin-Auth-Required', '1')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.end_headers()
                body = json.dumps({'ok': False, 'authRequired': True, 'error': message}, ensure_ascii=False).encode('utf-8')
                self.wfile.write(body)
                return False
        except Exception:
            pass
        self.send_response(code)
        if code == 401 and not _is_production_runtime():
            self.send_header('WWW-Authenticate', 'Basic realm="Admin"')
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.end_headers()
        try:
            self.wfile.write(str(message).encode('utf-8'))
        except Exception:
            pass
        return False

    def _require_admin_auth(self) -> bool:
        # FIX618: never allow ADMIN_STAGING_OPEN to expose Admin publicly.
        # It is only tolerated for local-loopback development when production hardening is off.
        if os.environ.get('ADMIN_STAGING_OPEN') == '1':
            if (not _is_production_runtime()) and _is_loopback_client(self):
                return True
            try:
                _append_system_event(level='error', component='auth', message_user='Admin staging bypass geblokkeerd', message_tech='ADMIN_STAGING_OPEN was set but public admin bypass is disabled in FIX618', status='open')
            except Exception:
                pass
        creds = self._load_admin_credentials() or {}
        self._warn_if_local_admin_credentials_in_production(creds)
        if not _normalized_admin_users(creds):
            _append_system_event(level="error", component="auth", message_user="Admin-login is niet geconfigureerd", message_tech=f"Missing username/password in {creds.get('path') or _get_admin_credentials_file_path()}", status="open")
            return self._send_admin_auth_challenge(403, 'Admin authentication not configured.')

        if _is_production_hardening_enabled() and not _is_secure_admin_transport(self):
            _append_system_event(level="error", component="auth", message_user="Admin-login geblokkeerd", message_tech="Admin authentication requires HTTPS or loopback in production hardening mode", status="open")
            return self._send_admin_auth_challenge(403, 'Admin authentication requires HTTPS.')

        ip = _client_ip(self)
        auth = self.headers.get("Authorization") or ""
        bearer = _extract_bearer_token(auth)
        if bearer and _admin_session_valid(bearer) and 'admin' in _admin_session_roles(bearer):
            _rate_limit_clear('admin_auth_fail', ip)
            return True
        cookie_token = _extract_admin_session_cookie(self.headers.get('Cookie') or '')
        if cookie_token and _admin_session_valid(cookie_token) and 'admin' in _admin_session_roles(cookie_token):
            _rate_limit_clear('admin_auth_fail', ip)
            return True
        if _is_production_runtime():
            return self._send_admin_auth_challenge(401, 'Admin authentication required')
        if not auth.startswith("Basic "):
            return self._send_admin_auth_challenge(401, 'Admin authentication required')

        b64 = auth.split(" ", 1)[1].strip()
        try:
            decoded = base64.b64decode(b64).decode("utf-8")
        except Exception:
            if _rate_limit_is_blocked('admin_auth_fail', ip, 10, 300):
                self.send_response(429)
                self.end_headers()
                self.wfile.write(b"Too many login attempts.")
                return False
            _rate_limit_record('admin_auth_fail', ip)
            _append_system_event(level="warning", component="auth", message_user="Admin login mislukt", message_tech="Invalid Basic auth encoding", status="open")
            return self._send_admin_auth_challenge(401, 'Admin authentication required')

        u_in, _, p_in = decoded.partition(":")
        user = _find_admin_user(creds, u_in)
        if user and _verify_password_against_stored(p_in, str(user.get('password_hash') or '')):
            _rate_limit_clear('admin_auth_fail', ip)
            return True

        if _rate_limit_is_blocked('admin_auth_fail', ip, 10, 300):
            self.send_response(429)
            self.end_headers()
            self.wfile.write(b"Too many login attempts.")
            return False
        _rate_limit_record('admin_auth_fail', ip)
        _append_system_event(level="warning", component="auth", message_user="Admin login mislukt", message_tech=f"Invalid credentials for user={u_in}", status="open")
        return self._send_admin_auth_challenge(401, 'Invalid admin credentials')


    def _dxf_root(self) -> Path:
        return DXF_LIBRARY_ROOT

    def _sanitize_category(self, cat: str):
        if not isinstance(cat, str):
            return None
        cat = cat.strip()
        if not cat:
            return None
        # Keep legacy behavior: allow "(root)" to point to the base folder.
        if cat == "(root)":
            return cat
        # Prevent path traversal / separators
        if "/" in cat or "\\" in cat or ".." in cat:
            return None
        # Allow categories with spaces (labels must match Tool A)
        if len(cat) > 60:
            return None
        if not re.fullmatch(r"[\w \-]{1,60}", cat, flags=re.UNICODE):
            return None
        return cat

    def _sanitize_filename(self, name: str):
        if not isinstance(name, str):
            return None
        name = name.strip()
        if not name:
            return None
        if "/" in name or "\\" in name or ".." in name:
            return None
        if not name.lower().endswith(".dxf"):
            return None
        if not re.fullmatch(r"[A-Za-z0-9 _,.-]{1,80}\.dxf", name, flags=re.IGNORECASE):
            return None
        return name

    def _dxf_category_folder(self, cat: str) -> Path:
        root = self._dxf_root()
        root.mkdir(parents=True, exist_ok=True)
        if cat == "(root)":
            return root
        return root / cat

    def _list_dxf_categories(self):
        root = self._dxf_root()
        root.mkdir(parents=True, exist_ok=True)
        cats = ["(root)"]
        for p in sorted(root.iterdir()):
            if p.is_dir():
                cats.append(p.name)
        return cats

    def _list_dxf_files_in_category(self, cat: str):
        folder = self._dxf_category_folder(cat)
        if not folder.exists() or not folder.is_dir():
            return None
        files = []
        for p in sorted(folder.iterdir()):
            if not p.is_file():
                continue
            name = p.name
            if name.startswith('.'):
                continue
            # Accept normal .dxf and (optionally) extensionless DXF files
            if name.lower().endswith(".dxf") or p.suffix == "":
                files.append(name)
        return files

    def _new_public_material_id(self, used: set[str] | None = None) -> str:
        used = used if isinstance(used, set) else set()
        for _ in range(100):
            value = 'decor_' + secrets.token_hex(10)
            if value not in used:
                used.add(value)
                return value
        raise RuntimeError('Kon geen unieke publieke decor-ID genereren')

    def _infer_material_brand(self, rec: dict) -> str:
        existing = str((rec or {}).get('brand') or '').strip()
        if existing:
            return existing[:80]
        hay = ' '.join(str((rec or {}).get(k) or '') for k in ('productName','categoryName','shortDescription')).upper()
        for brand in ('EGGER','PFLEIDERER','UNILIN','DECORLEGNO','DECOLEGNO','SHINNOKI','CLEAF','FINSA','KRONOSPAN','ARPA','FENIX','NUXE','TOPFIX'):
            if brand in hay:
                return brand if brand in ('EGGER','ARPA','FENIX') else brand.title()
        return 'Overig'

    def _material_presentation(self, rec: dict) -> dict:
        rec = rec or {}
        return _catalog_classify_presentation(
            str(rec.get('productName') or rec.get('publicName') or rec.get('decorName') or ''),
            str(rec.get('brand') or self._infer_material_brand(rec) or ''),
            str(rec.get('categoryName') or ''),
            rec.get('imageSourceUrls') or [],
        )

    def _infer_material_decor_type(self, rec: dict) -> str:
        presentation = self._material_presentation(rec)
        return str(presentation.get('visualFamily') or 'Overig')[:60]

    def _public_material_name(self, rec: dict) -> str:
        rec = rec or {}
        art = str(rec.get('articleNo') or rec.get('articleNumber') or rec.get('materialCode') or '').strip()
        name = str(rec.get('publicName') or rec.get('displayName') or rec.get('productName') or rec.get('decorName') or 'Decor').strip()
        if art:
            name = name.replace(art, '').strip(' -/|') or 'Decor'
        return name[:180]

    def _ensure_material_public_metadata(self, raw: dict, recs: list[dict]) -> bool:
        changed = False
        used: set[str] = set()
        for r in recs:
            if not isinstance(r, dict):
                continue
            pid = str(r.get('publicMaterialId') or '').strip().lower()
            if _PUBLIC_MATERIAL_ID_RE.fullmatch(pid) and pid not in used:
                used.add(pid)
            else:
                r['publicMaterialId'] = self._new_public_material_id(used)
                changed = True
        for r in recs:
            if not isinstance(r, dict):
                continue
            # FIX656: CSV publication already persists presentation fields. Do not run the
            # classifier four/five times again on every public library request. Only infer
            # presentation once when an older record genuinely misses one of these fields.
            brand = str(r.get('brand') or '').strip() or self._infer_material_brand(r)
            presentation_keys_ok = (
                bool(str(r.get('visualFamily') or r.get('decorType') or '').strip()) and
                isinstance(r.get('visualTags'), list) and
                bool(str(r.get('colorGroup') or '').strip()) and
                isinstance(r.get('searchTags'), list)
            )
            presentation = None if presentation_keys_ok else self._material_presentation({**r, 'brand': brand})
            family = str(r.get('visualFamily') or r.get('decorType') or (presentation or {}).get('visualFamily') or 'Overig').strip() or 'Overig'
            defaults = {
                'publicName': self._public_material_name(r),
                'brand': brand,
                'decorType': family,
                'visualFamily': family,
                'visualTags': list(r.get('visualTags') or (presentation or {}).get('visualTags') or [family]),
                'colorGroup': str(r.get('colorGroup') or (presentation or {}).get('colorGroup') or 'Overig').strip() or 'Overig',
                'searchTags': list(r.get('searchTags') or (presentation or {}).get('searchTags') or []),
                'published': bool(r.get('active', True)) if r.get('published') is None else bool(r.get('published')),
                'isPopular': bool(r.get('isPopular', False)),
                'isNew': bool(r.get('isNew', False)),
                'hasGrain': True if r.get('hasGrain') is None else bool(r.get('hasGrain')),
                'grainDefaultOn': True if r.get('grainDefaultOn') is None else bool(r.get('grainDefaultOn')),
                'archived': bool(r.get('archived', False)),
                'sourceKind': str(r.get('sourceKind') or 'LEGACY_LIBRARY').strip() or 'LEGACY_LIBRARY',
                'catalogMissing': bool(r.get('catalogMissing', False)),
            }
            for key, value in defaults.items():
                if key not in r:
                    r[key] = value
                    changed = True
        if raw.get('decorLibrarySchemaVersion') != 4:
            raw['decorLibrarySchemaVersion'] = 4
            changed = True
        return changed

    def _load_material_library_bundle(self):
        with _MATERIAL_LIBRARY_LOCK:
            target = MATERIAL_LIBRARY_PATH
            if target.exists():
                raw = strict_json_load(target)
            else:
                raw = {'source': 'admin', 'records': []}
            if isinstance(raw, list):
                raw = {'source': 'admin', 'records': raw}
            if not isinstance(raw, dict):
                raise ValueError('Material library must be a JSON object or list')
            recs = raw.get('records')
            if recs is None:
                recs = []
                raw['records'] = recs
            if not isinstance(recs, list):
                raise ValueError('material_library.json must contain a records list')
            changed = self._ensure_material_public_metadata(raw, recs)
            if changed:
                raw['recordCountOriginal'] = len(recs)
                raw['recordCountFiltered'] = len(recs)
                self._save_material_library_bundle(raw)
            return raw, recs

    def _save_material_library_bundle(self, raw):
        global _MATERIAL_NAME_BY_CODE
        with _MATERIAL_LIBRARY_LOCK:
            target = MATERIAL_LIBRARY_PATH
            durable_write_json(target, raw, mode=0o640)
            _invalidate_public_materials_response_cache()
            _MATERIAL_NAME_BY_CODE = None

    def _normalize_material_record_for_admin(self, rec):
        if not isinstance(rec, dict):
            rec = {}
        out = dict(rec)
        art = str(out.get('articleNo') or out.get('articleNumber') or out.get('materialCode') or '').strip()
        out['articleNo'] = art
        out['materialCode'] = str(out.get('materialCode') or art).strip()
        if out.get('sheetWid') is None and out.get('sheetWidth') is not None:
            out['sheetWid'] = out.get('sheetWidth')
        if out.get('sheetLen') is None:
            for k in ('sheetHeight', 'height'):
                if out.get(k) is not None:
                    out['sheetLen'] = out.get(k); break
        if out.get('thicknessMm') is None and out.get('thickness') is not None:
            out['thicknessMm'] = out.get('thickness')

        # Direct per-material sell price is the active pricing model. Keep legacy purchase
        # fields only as internal historical data; never expose them to Tool A.
        try: incl = float(out.get('sellPriceInclVatPerSheet') or 0.0)
        except Exception: incl = 0.0
        try: ex = float(out.get('sellPriceExVatPerSheet') or 0.0)
        except Exception: ex = 0.0
        if incl <= 0 and ex > 0:
            incl = round(ex * (1.0 + CATALOG_VAT_RATE), 2)
        if ex <= 0 and incl > 0:
            ex = round(incl / (1.0 + CATALOG_VAT_RATE), 6)
        out['sellPriceInclVatPerSheet'] = incl if incl > 0 else None
        out['sellPriceExVatPerSheet'] = ex if ex > 0 else None

        pid = str(out.get('publicMaterialId') or '').strip().lower()
        if pid and not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
            pid = ''
        out['publicMaterialId'] = pid
        out['publicName'] = self._public_material_name(out)
        out['brand'] = str(out.get('brand') or '').strip() or self._infer_material_brand(out)
        # FIX656 fast path: imported CSV records already contain deterministic presentation
        # fields. Reclassify only legacy/incomplete records, never 597 records per request.
        have_presentation = (
            bool(str(out.get('visualFamily') or out.get('decorType') or '').strip()) and
            isinstance(out.get('visualTags'), list) and
            bool(str(out.get('colorGroup') or '').strip()) and
            isinstance(out.get('searchTags'), list)
        )
        presentation = {} if have_presentation else self._material_presentation(out)
        out['visualFamily'] = str(out.get('visualFamily') or out.get('decorType') or presentation.get('visualFamily') or 'Overig')
        out['visualTags'] = list(out.get('visualTags') or presentation.get('visualTags') or [out['visualFamily']])
        out['decorType'] = str(out.get('decorType') or out['visualFamily'])
        out['colorGroup'] = str(out.get('colorGroup') or presentation.get('colorGroup') or 'Overig')
        out['searchTags'] = list(out.get('searchTags') or presentation.get('searchTags') or [])
        out['published'] = bool(out.get('published', out.get('active', True)))
        out['isPopular'] = bool(out.get('isPopular', False))
        out['isNew'] = bool(out.get('isNew', False))
        out['hasGrain'] = True if out.get('hasGrain') is None else bool(out.get('hasGrain'))
        out['grainDefaultOn'] = True if out.get('grainDefaultOn') is None else bool(out.get('grainDefaultOn'))
        out['archived'] = bool(out.get('archived', False))
        out['sourceKind'] = str(out.get('sourceKind') or 'LEGACY_LIBRARY').strip() or 'LEGACY_LIBRARY'
        out['catalogMissing'] = bool(out.get('catalogMissing', False))
        out['catalogExcluded'] = bool(out.get('catalogExcluded', False))

        if pid:
            version = str(out.get('imageVersion') or '').strip()
            thumb = DECOR_MEDIA_ROOT / pid / 'thumb.webp'
            preview = DECOR_MEDIA_ROOT / pid / 'preview.webp'
            catalog_cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            prefer_catalog = str(out.get('sourceKind') or '').upper() == 'CATALOG_IMPORT'
            catalog_meta = catalog_cached[1] if catalog_cached else {}
            catalog_version = str(version or catalog_meta.get('sha256') or '')[:64]
            suffix = ('?v=' + quote(catalog_version)) if catalog_version else ''
            variants = catalog_meta.get('variants') if isinstance(catalog_meta, dict) and isinstance(catalog_meta.get('variants'), dict) else {}
            # FIX654: imported images are prepared before publication. Prefer the lightweight
            # WebP variants when the cache metadata confirms they belong to the current source.
            if prefer_catalog and catalog_cached and thumb.exists() and preview.exists() and 'thumb.webp' in variants and 'preview.webp' in variants:
                out['imageAvailable'] = True
                out['imageThumbUrl'] = f'/api/materials/image/{pid}/thumb.webp{suffix}'
                out['imagePreviewUrl'] = f'/api/materials/image/{pid}/preview.webp{suffix}'
                out['imageCacheKind'] = 'catalog_webp'
            elif prefer_catalog and catalog_cached:
                out['imageAvailable'] = True
                out['imageThumbUrl'] = f'/api/materials/image/{pid}/catalog{suffix}'
                out['imagePreviewUrl'] = f'/api/materials/image/{pid}/catalog{suffix}'
                out['imageCacheKind'] = 'catalog_cache'
            elif thumb.exists() and preview.exists():
                out['imageAvailable'] = True
                suffix = ('?v=' + quote(version)) if version else ''
                out['imageThumbUrl'] = f'/api/materials/image/{pid}/thumb.webp{suffix}'
                out['imagePreviewUrl'] = f'/api/materials/image/{pid}/preview.webp{suffix}'
                out['imageCacheKind'] = 'manual_webp'
            elif catalog_cached:
                out['imageAvailable'] = True
                meta = catalog_cached[1]
                catalog_version = str(version or meta.get('sha256') or '')[:64]
                suffix = ('?v=' + quote(catalog_version)) if catalog_version else ''
                out['imageThumbUrl'] = f'/api/materials/image/{pid}/catalog{suffix}'
                out['imagePreviewUrl'] = f'/api/materials/image/{pid}/catalog{suffix}'
                out['imageCacheKind'] = 'catalog_cache'
            else:
                out['imageAvailable'] = False
        return out

    def _material_record_to_toola_catalog(self, rec, already_normalized: bool = False):
        """Return the minimal public material contract.

        Internal article numbers, supplier fields and purchase prices never leave this
        method. Tool A creates its own opaque compatibility aliases client-side.
        """
        rr = rec if already_normalized and isinstance(rec, dict) else self._normalize_material_record_for_admin(rec)
        pid = str(rr.get('publicMaterialId') or '').strip()
        public_name = self._public_material_name(rr)
        try: w = float(rr.get('sheetWid') or rr.get('sheetWidth') or 0)
        except Exception: w = 0.0
        try: h = float(rr.get('sheetLen') or rr.get('sheetHeight') or rr.get('height') or 0)
        except Exception: h = 0.0
        try: t = float(rr.get('thicknessMm') or rr.get('thickness') or 0)
        except Exception: t = 0.0
        active = bool(rr.get('active', True)) and not bool(rr.get('archived', False))
        return {
            'publicMaterialId': pid,
            'publicName': public_name,
            'brand': str(rr.get('brand') or 'Overig').strip() or 'Overig',
            'decorType': str(rr.get('primaryVisualFamily') or rr.get('decorType') or rr.get('visualFamily') or 'Onbekend').strip() or 'Onbekend',
            'primaryVisualFamily': str(rr.get('primaryVisualFamily') or rr.get('visualFamily') or rr.get('decorType') or 'Onbekend').strip() or 'Onbekend',
            'visualFamily': str(rr.get('primaryVisualFamily') or rr.get('visualFamily') or rr.get('decorType') or 'Onbekend').strip() or 'Onbekend',
            'visualTags': [str(x)[:40] for x in (rr.get('visualTags') or []) if str(x).strip()][:12],
            'substrateType': str(rr.get('substrateType') or 'ONBEKEND').strip().upper() or 'ONBEKEND',
            'substrateLabel': str(rr.get('substrateLabel') or 'Onbekend').strip() or 'Onbekend',
            'collection': str(rr.get('collection') or '').strip()[:80],
            'colorGroup': str(rr.get('colorGroup') or 'Overig').strip() or 'Overig',
            'searchTags': [str(x)[:60] for x in (rr.get('searchTags') or []) if str(x).strip()][:48],
            'thicknessMm': t,
            'sheetSizeMm': {'width': w, 'height': h},
            'hasGrain': bool(rr.get('hasGrain', True)),
            'grainDefaultOn': bool(rr.get('grainDefaultOn', True)),
            'active': active,
            'published': bool(rr.get('published', active)),
            'isPopular': bool(rr.get('isPopular', False)),
            'isNew': bool(rr.get('isNew', False)),
            'imageAvailable': bool(rr.get('imageAvailable', False)),
            'imageThumbUrl': rr.get('imageThumbUrl') or '',
            'imagePreviewUrl': rr.get('imagePreviewUrl') or '',
        }

    def _material_id_maps(self) -> tuple[dict[str, str], dict[str, str]]:
        _, recs = self._load_material_library_bundle()
        public_to_internal: dict[str, str] = {}
        internal_to_public: dict[str, str] = {}
        for rec in recs:
            if not isinstance(rec, dict):
                continue
            rr = self._normalize_material_record_for_admin(rec)
            pid = str(rr.get('publicMaterialId') or '').strip()
            internal = str(rr.get('articleNo') or rr.get('materialCode') or '').strip()
            if pid and internal:
                public_to_internal[pid] = internal
                internal_to_public[internal] = pid
        return public_to_internal, internal_to_public

    def _resolve_public_material_value(self, value, public_to_internal: dict[str, str]):
        if not isinstance(value, str):
            raise ValueError('Publieke materiaal-ID moet tekst zijn.')
        raw = validate_public_material_id(value.strip().lower())
        if raw not in public_to_internal:
            raise ValueError('Dit decor is niet meer beschikbaar. Kies het materiaal opnieuw.')
        return public_to_internal[raw]

    def _rewrite_panels_csv_material_ids(self, text: str, public_to_internal: dict[str, str]) -> str:
        text = str(text or '')
        if not text.strip():
            return text
        inp = io.StringIO(text)
        reader = csv.DictReader(inp, delimiter=';')
        if not reader.fieldnames:
            return text
        out = io.StringIO(newline='')
        writer = csv.DictWriter(out, fieldnames=reader.fieldnames, delimiter=';', lineterminator='\n', extrasaction='ignore')
        writer.writeheader()
        for row in reader:
            for key in ('MaterialCode','ArticleNumber','articleNumber','articleNo','materialCode'):
                if key in row and row.get(key) is not None:
                    row[key] = self._resolve_public_material_value(str(row.get(key) or ''), public_to_internal)
            writer.writerow(row)
        return out.getvalue()

    def _canonicalize_public_job_payload(self, payload: dict) -> dict:
        """Convert browser intent into the complete server-owned production contract."""

        if not isinstance(payload, dict):
            raise SafetyContractError('Job payload must be an object')
        allowed_keys = {
            'panelsCsv', 'dxfParts', 'dxfBlobs', 'dxfPartRefs', 'jobJson',
            'pricing', 'preflightEstimate', 'payloadSchema',
        }
        unknown = sorted(set(payload) - allowed_keys)
        if unknown:
            raise SafetyContractError(f'Unknown job payload fields: {unknown[:8]}')

        public_to_internal, _ = self._material_id_maps()
        if not public_to_internal:
            raise SafetyContractError('De actieve materiaalcatalogus is leeg')
        raw_csv = payload.get('panelsCsv')
        if not isinstance(raw_csv, str):
            raise SafetyContractError('panelsCsv is required')
        rows = _parse_panels_csv_contract(
            raw_csv,
            allowed_thicknesses=CATALOG_ALLOWED_THICKNESSES_MM,
            allowed_edge_codes={0, 1},
            max_rows=_env_int('PUBLIC_JOB_MAX_PANEL_ROWS', 500),
            max_total_qty=_env_int('PUBLIC_JOB_TOTAL_QTY_LIMIT', 250),
        )

        _, catalog_records = self._load_material_library_bundle()
        catalog_by_internal: dict[str, dict] = {}
        for record in catalog_records:
            if not isinstance(record, dict):
                continue
            internal = str(record.get('articleNo') or record.get('articleNumber') or record.get('materialCode') or '').strip()
            if internal:
                catalog_by_internal[internal] = record

        canonical_rows = []
        for row in rows:
            public_id = validate_public_material_id(row.MaterialCode.lower())
            internal = public_to_internal.get(public_id)
            if not internal:
                raise SafetyContractError('Dit decor is niet meer beschikbaar. Kies het materiaal opnieuw.')
            record = catalog_by_internal.get(internal)
            if not isinstance(record, dict):
                raise SafetyContractError('Materiaal ontbreekt in de actieve servercatalogus')
            if (
                str(record.get('sourceKind') or '').upper() != 'CATALOG_IMPORT'
                or record.get('catalogMissing') is True
                or record.get('active') is False
                or record.get('archived') is True
                or record.get('published') is False
                or record.get('catalogExcluded') is True
            ):
                raise SafetyContractError('Materiaal is niet actief gepubliceerd')
            live_thickness = finite_number(
                record.get('thicknessMm'),
                field=f'{public_id}.thicknessMm',
                minimum=0.1,
                maximum=100.0,
            )
            if abs(live_thickness - row.ThicknessMm) > 1e-9:
                raise SafetyContractError(f'{row.PartId}: plaatdikte wijkt af van de actieve catalogus')
            if row.GrainGroup and record.get('hasGrain') is False:
                raise SafetyContractError(f'{row.PartId}: dit materiaal staat geen GrainGroup toe')
            canonical_rows.append(replace(row, MaterialCode=internal, ThicknessMm=live_thickness))

        dxf_parts = _expand_dxf_payload(payload)
        expected_part_ids = {row.PartId for row in canonical_rows}
        supplied_part_ids = set(dxf_parts)
        if supplied_part_ids != expected_part_ids:
            missing = sorted(expected_part_ids - supplied_part_ids)[:10]
            extra = sorted(supplied_part_ids - expected_part_ids)[:10]
            raise SafetyContractError(f'DXF-set komt niet exact overeen met panelen; ontbreekt={missing}, extra={extra}')

        max_blob_bytes = _env_int('PUBLIC_DXF_BLOB_MAX_BYTES', 2 * 1024 * 1024)
        max_total_bytes = _env_int('PUBLIC_DXF_TOTAL_MAX_BYTES', 12 * 1024 * 1024)
        total_dxf_bytes = 0
        row_by_id = {row.PartId: row for row in canonical_rows}
        bbox_tolerance = finite_number(
            os.environ.get('DXF_BBOX_TOLERANCE_MM', '0.1'),
            field='DXF_BBOX_TOLERANCE_MM',
            minimum=0.0,
            maximum=1.0,
        )
        for part_id, dxf_text in dxf_parts.items():
            encoded = dxf_text.encode('utf-8', errors='strict')
            if len(encoded) > max_blob_bytes:
                raise SafetyContractError(f'{part_id}: DXF is te groot')
            total_dxf_bytes += len(encoded)
            if total_dxf_bytes > max_total_bytes:
                raise SafetyContractError('Totale DXF-invoer is te groot')
            pairs = _strict_dxf_parse_pairs(dxf_text)
            entities = _strict_dxf_split_entities(_strict_dxf_entities_section(pairs))
            if not entities:
                raise SafetyContractError(f'{part_id}: DXF bevat geen geometrie')
            for entity in entities:
                kind = _strict_dxf_entity_type(entity)
                if kind not in {'LINE', 'CIRCLE', 'ARC', 'LWPOLYLINE'}:
                    raise SafetyContractError(f'{part_id}: niet-ondersteund DXF-entitytype {kind}')
                if kind == 'LWPOLYLINE' and _strict_dxf_entity_layer(entity).upper() != 'OUTLINE':
                    raise SafetyContractError(f'{part_id}: alleen OUTLINE LWPOLYLINE is toegestaan')
                if _strict_dxf_entity_bbox(entity) is None:
                    raise SafetyContractError(f'{part_id}: DXF-entity heeft geen geldige bbox')
            bbox = _strict_dxf_entities_bbox(entities)
            row = row_by_id[part_id]
            if abs(bbox.width - row.WidthMm) > bbox_tolerance or abs(bbox.height - row.LengthMm) > bbox_tolerance:
                raise SafetyContractError(
                    f'{part_id}: DXF bbox {bbox.width:.3f}x{bbox.height:.3f} wijkt af van CSV '
                    f'{row.WidthMm:.3f}x{row.LengthMm:.3f}'
                )

        raw_job = payload.get('jobJson') if isinstance(payload.get('jobJson'), dict) else {}
        raw_customer = raw_job.get('customer') if isinstance(raw_job.get('customer'), dict) else {}
        customer: dict[str, str] = {}
        for key in ('name', 'fullName', 'firstName', 'lastName', 'city', 'country'):
            if raw_customer.get(key) not in (None, ''):
                customer[key] = _sanitize_user_text(raw_customer.get(key), 240)
        for key in ('email', 'mail'):
            if raw_customer.get(key) not in (None, ''):
                value = _clean_text(raw_customer.get(key), 320).strip()
                if not _EMAIL_RE.fullmatch(value):
                    raise SafetyContractError('E-mailadres is ongeldig')
                customer[key] = value
        for key in ('phone', 'tel', 'telephone'):
            if raw_customer.get(key) not in (None, ''):
                customer[key] = _sanitize_phone_text(raw_customer.get(key), 60)
        for key in ('address', 'addressLine1', 'street', 'postalCode', 'postcode'):
            if raw_customer.get(key) not in (None, ''):
                customer[key] = _sanitize_user_text(raw_customer.get(key), 320)
        rest = raw_job.get('rest_material') if isinstance(raw_job.get('rest_material'), dict) else {}
        carry_out = rest.get('carry_out') is True
        note = _sanitize_user_text(raw_job.get('note'), 2000, allow_note_chars=True)
        canonical_job = {
            'createdAt': _utc_now_iso(),
            'project': 'METOD_PAX',
            'grainEnabled': any(bool(row.GrainGroup) for row in canonical_rows),
            'grainPolicy': 'server-canonical-v1',
            'rest_material': {'carry_out': carry_out},
            'customer': customer,
            'note': note,
        }
        return {
            'panelsCsv': _canonical_panels_csv(canonical_rows),
            'dxfParts': dxf_parts,
            'jobJson': canonical_job,
            'payloadSchema': 'FIX660R8_SERVER_CANONICAL_V1',
        }

    def _resolve_public_material_payload(self, payload: dict) -> dict:
        if not isinstance(payload, dict):
            return payload
        public_to_internal, _ = self._material_id_maps()
        if not public_to_internal:
            raise ValueError('De actieve materiaalcatalogus is leeg.')
        if isinstance(payload.get('panelsCsv'), str):
            payload['panelsCsv'] = self._rewrite_panels_csv_material_ids(payload.get('panelsCsv') or '', public_to_internal)
        code_keys = {'articleNumber','articleNo','materialCode','MaterialCode','ArticleNumber','materialKey','material'}
        def walk(value, parent_key=''):
            if isinstance(value, dict):
                for key in list(value.keys()):
                    if key == 'panelsCsv':
                        continue
                    item = value.get(key)
                    if key in code_keys and isinstance(item, str):
                        value[key] = self._resolve_public_material_value(item, public_to_internal)
                    else:
                        walk(item, key)
            elif isinstance(value, list):
                for item in value:
                    walk(item, parent_key)
        walk(payload)
        return payload

    def _sanitize_public_material_response(self, obj):
        """Remove or replace internal material identifiers in public job output."""
        _, internal_to_public = self._material_id_maps()
        replacements = sorted(
            ((str(internal), str(public_id)) for internal, public_id in internal_to_public.items() if internal and public_id),
            key=lambda item: len(item[0]),
            reverse=True,
        )
        sensitive = {
            'purchaseprice', 'purchasepricepersheet', 'purchase_price', 'inkoopprijs',
            'supplier', 'suppliername', 'leverancier', 'suppliercode', 'supplierarticle',
            'internalarticlenumber', 'internal_article_number', 'internalcode',
            # Raw/internal pricing audit fields never belong in customer responses.
            'sheetunitcostraw', 'sheetcosttotalraw', 'bycodecostraw', 'edgecosttotalraw',
            'imagesourceurl', 'imagesourceurls', 'sourceimageurl', 'catalogsourceurl',
        }
        code_keys = {
            'articlenumber', 'articleno', 'article_number', 'article_no',
            'materialcode', 'material_code', 'sku',
        }

        def replace_codes(text: str) -> str:
            result = str(text)
            for internal, public_id in replacements:
                if internal in result:
                    result = result.replace(internal, public_id)
            return result

        def clean(value, key=''):
            if isinstance(value, dict):
                out = {}
                for k, v in value.items():
                    lk = str(k).lower()
                    if lk in sensitive:
                        continue
                    if lk in code_keys and isinstance(v, str):
                        mapped = internal_to_public.get(v)
                        out[k] = mapped or (v if v.startswith('decor_') else replace_codes(v))
                        continue
                    out[k] = clean(v, k)
                return out
            if isinstance(value, list):
                return [clean(v, key) for v in value]
            if isinstance(value, str):
                return replace_codes(value)
            return value
        return clean(obj)

    def _public_quote_view(self, quote):
        """Return the minimum customer-safe quote projection Tool A needs.

        Internal quote.json can contain production identifiers and audit fields. Public
        callers receive only totals plus opaque public material IDs, display names and
        sheet counts. This makes article numbers unavailable even to a customer who
        inspects the network response instead of merely hiding them in the UI.
        """
        if not isinstance(quote, dict):
            return None
        safe = self._sanitize_public_material_response(quote)
        out = {'currency': str(safe.get('currency') or 'EUR')}
        totals_in = safe.get('totals') if isinstance(safe.get('totals'), dict) else {}
        totals = {}
        for key in ('grandTotal','total','totalInclVat','grandTotalInclVat','sheetCount'):
            if totals_in.get(key) is not None:
                totals[key] = totals_in.get(key)
        if totals:
            out['totals'] = totals
        for key in ('grandTotal','total','totalInclVat','grandTotalInclVat','total_incl_vat','sheetCount'):
            if safe.get(key) is not None:
                out[key] = safe.get(key)
        mats_out = []
        for m in safe.get('materials') or []:
            if not isinstance(m, dict):
                continue
            code = str(m.get('publicMaterialId') or m.get('materialCode') or m.get('code') or m.get('articleNumber') or '').strip()
            if code and not code.startswith('decor_'):
                # Never echo an unresolved identifier to a public caller.
                code = ''
            name = str(m.get('publicName') or m.get('materialDisplayName') or m.get('materialName') or m.get('productName') or m.get('decorName') or m.get('name') or '').strip()
            item = {}
            if code:
                item['publicMaterialId'] = code
                item['materialCode'] = code  # compatibility alias; value is opaque public ID
            if name:
                item['name'] = name
            for src, dst in (('sheetCount','sheetCount'),('plates','plates'),('sheets','sheets')):
                if m.get(src) is not None:
                    item[dst] = m.get(src)
            if item:
                mats_out.append(item)
        if mats_out:
            out['materials'] = mats_out
        return out

    def _decor_image_file(self, public_id: str, variant: str) -> Path | None:
        pid = str(public_id or '').strip().lower()
        if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
            return None
        root = DECOR_MEDIA_ROOT.resolve()
        if variant == 'catalog':
            cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            if not cached:
                return None
            target = cached[0].resolve()
        elif variant in ('thumb.webp','preview.webp'):
            target = (DECOR_MEDIA_ROOT / pid / variant).resolve()
        else:
            return None
        if root not in target.parents:
            return None
        return target

    def _webp_dimensions(self, data: bytes) -> tuple[int, int] | None:
        try:
            if len(data) < 30 or data[:4] != b'RIFF' or data[8:12] != b'WEBP':
                return None
            pos = 12
            while pos + 8 <= len(data):
                fourcc = data[pos:pos+4]
                size = int.from_bytes(data[pos+4:pos+8], 'little')
                chunk = data[pos+8:pos+8+size]
                if len(chunk) < size:
                    return None
                if fourcc == b'VP8X' and len(chunk) >= 10:
                    w = 1 + int.from_bytes(chunk[4:7], 'little')
                    h = 1 + int.from_bytes(chunk[7:10], 'little')
                    return w, h
                if fourcc == b'VP8 ' and len(chunk) >= 10 and chunk[3:6] == b'\x9d\x01\x2a':
                    w = int.from_bytes(chunk[6:8], 'little') & 0x3fff
                    h = int.from_bytes(chunk[8:10], 'little') & 0x3fff
                    return w, h
                if fourcc == b'VP8L' and len(chunk) >= 5 and chunk[0] == 0x2f:
                    b1,b2,b3,b4 = chunk[1],chunk[2],chunk[3],chunk[4]
                    w = 1 + (b1 | ((b2 & 0x3f) << 8))
                    h = 1 + ((b2 >> 6) | (b3 << 2) | ((b4 & 0x0f) << 10))
                    return w, h
                pos += 8 + size + (size & 1)
        except Exception:
            return None
        return None

    def _public_materials_response_bytes(self, force_rebuild: bool = False) -> tuple[bytes, str, str]:
        """Return a prebuilt PUBLIC-ONLY catalog JSON response.

        FIX656 moves the expensive 597-record normalization/media discovery out of every
        customer page load. The cache key is material_library.json mtime, so every Admin
        publish invalidates automatically. A disk cache survives server restarts.
        """
        try:
            source_mtime_ns = int(MATERIAL_LIBRARY_PATH.stat().st_mtime_ns)
        except Exception:
            source_mtime_ns = 0
        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
            if (not force_rebuild and _PUBLIC_MATERIALS_RESPONSE_CACHE.get('mtimeNs') == source_mtime_ns
                    and isinstance(_PUBLIC_MATERIALS_RESPONSE_CACHE.get('body'), (bytes, bytearray))):
                return (bytes(_PUBLIC_MATERIALS_RESPONSE_CACHE['body']),
                        str(_PUBLIC_MATERIALS_RESPONSE_CACHE.get('etag') or ''), str(source_mtime_ns))

        if not force_rebuild and source_mtime_ns:
            try:
                meta = strict_json_load(PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH)
                if (
                    int(meta.get('schemaVersion') or 0) == PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA
                    and str(meta.get('build') or '') == PUBLIC_MATERIAL_CATALOG_CACHE_BUILD
                    and int(meta.get('sourceMtimeNs') or -1) == source_mtime_ns
                    and PUBLIC_MATERIAL_CATALOG_CACHE_PATH.exists()
                ):
                    body = PUBLIC_MATERIAL_CATALOG_CACHE_PATH.read_bytes()
                    etag = str(meta.get('etag') or '')
                    if body and etag:
                        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
                            _PUBLIC_MATERIALS_RESPONSE_CACHE.update({'mtimeNs': source_mtime_ns, 'body': body, 'etag': etag})
                        return body, etag, str(source_mtime_ns)
            except Exception:
                pass

        raw, recs = self._load_material_library_bundle()
        norm = []
        for r in recs:
            if not isinstance(r, dict):
                continue
            rr = self._normalize_material_record_for_admin(r)
            if str(rr.get('sourceKind') or '').upper() != 'CATALOG_IMPORT' or rr.get('active') is False or rr.get('archived') is True or rr.get('published') is False or rr.get('catalogExcluded') is True or rr.get('catalogMissing') is True:
                continue
            try:
                thickness_public = float(rr.get('thicknessMm') or 0.0)
            except Exception:
                thickness_public = 0.0
            if not any(abs(thickness_public - float(x)) < 1e-9 for x in CATALOG_ALLOWED_THICKNESSES_MM):
                continue
            pub = self._material_record_to_toola_catalog(rr, already_normalized=True)
            if pub.get('publicMaterialId'):
                norm.append(pub)
        try:
            source_mtime_ns = int(MATERIAL_LIBRARY_PATH.stat().st_mtime_ns)
        except Exception:
            source_mtime_ns = int(time.time() * 1_000_000_000)
        version = str(source_mtime_ns)
        body = json.dumps({'ok': True, 'records': norm, 'version': version, 'count': len(norm), 'schemaVersion': 1},
                          ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        etag = '"fix656-' + hashlib.sha256(body).hexdigest()[:24] + '"'
        try:
            durable_write_bytes(PUBLIC_MATERIAL_CATALOG_CACHE_PATH, body, mode=0o640)
            _atomic_write_json(PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH, {
                'schemaVersion': PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA,
                'sourceMtimeNs': source_mtime_ns, 'etag': etag,
                'count': len(norm), 'builtAt': _utc_now_iso(),
                'build': PUBLIC_MATERIAL_CATALOG_CACHE_BUILD,
            })
        except Exception:
            pass
        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
            _PUBLIC_MATERIALS_RESPONSE_CACHE.update({'mtimeNs': source_mtime_ns, 'body': body, 'etag': etag})
        return body, etag, version

    def _api_public_materials_library(self):
        try:
            body, etag, version = self._public_materials_response_bytes()
            incoming = str(self.headers.get('If-None-Match') or '').strip()
            if incoming and incoming == etag:
                self.send_response(304)
                self.send_header('ETag', etag)
                self.send_header('Cache-Control', 'private, max-age=0, must-revalidate')
                self.send_header('X-ToolA-Catalog-Build', 'FIX656')
                self.end_headers()
                return
            accept_encoding = str(self.headers.get('Accept-Encoding') or '').lower()
            wire_body = gzip.compress(body, compresslevel=5) if 'gzip' in accept_encoding else body
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(wire_body)))
            if wire_body is not body:
                self.send_header('Content-Encoding', 'gzip')
            self.send_header('Vary', 'Accept-Encoding')
            self.send_header('ETag', etag)
            self.send_header('Cache-Control', 'private, max-age=0, must-revalidate')
            self.send_header('X-ToolA-Catalog-Build', 'FIX656')
            self.end_headers()
            self.wfile.write(wire_body)
        except Exception as e:
            _append_system_event(level='error', component='materials', message_user='Materiaalbibliotheek laden is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Materiaalbibliotheek kon niet worden geladen'}, 500)

    def _api_admin_materials_library(self):
        try:
            raw, recs = self._load_material_library_bundle()
            norm = []
            for r in recs:
                if not isinstance(r, dict):
                    continue
                rr = self._normalize_material_record_for_admin(r)
                if str(rr.get('sourceKind') or '').upper() != 'CATALOG_IMPORT' or rr.get('catalogMissing') is True or rr.get('catalogExcluded') is True:
                    continue
                norm.append(rr)
            return self._send_json({'ok': True, 'records': norm, 'meta': {'source': 'CSV_CATALOG_ONLY', 'count': len(norm), 'decorLibrarySchemaVersion': raw.get('decorLibrarySchemaVersion', 4), 'mode': 'CSV_ONLY', 'lastCatalogImport': raw.get('lastCatalogImport')}})
        except Exception as e:
            _append_system_event(level='error', component='materials', message_user='Materiaalbeheer laden is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Materiaalbeheer kon niet worden geladen'}, 500)

    def _api_admin_materials_save_item(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)
        data = {}
        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 524288) or {}
            prev_article = str(data.get('prevArticleNo') or '').strip()
            rec = data.get('record') or {}
            if not isinstance(rec, dict):
                return self._send_json({'ok': False, 'error': 'Invalid record'}, 400)
            norm = self._normalize_material_record_for_admin(rec)
            article = str(norm.get('articleNo') or '').strip()
            if not article:
                return self._send_json({'ok': False, 'error': 'Intern artikelnummer ontbreekt'}, 400)
            for nk in ('sheetWid', 'sheetLen', 'thicknessMm'):
                try:
                    if float(norm.get(nk) or 0) <= 0:
                        return self._send_json({'ok': False, 'error': f'{nk} moet groter zijn dan 0'}, 400)
                except Exception:
                    return self._send_json({'ok': False, 'error': f'{nk} is ongeldig'}, 400)
            try:
                sell_inc = float(norm.get('sellPriceInclVatPerSheet') or 0.0)
            except Exception:
                sell_inc = 0.0
            if sell_inc <= 0:
                return self._send_json({'ok': False, 'error': 'Verkoopprijs per plaat incl. BTW moet groter zijn dan 0'}, 400)
            thickness = float(norm.get('thicknessMm') or 0.0)
            if bool(norm.get('published')) and not any(abs(thickness - float(x)) < 1e-9 for x in CATALOG_ALLOWED_THICKNESSES_MM):
                return self._send_json({'ok': False, 'error': 'Tool A staat alleen 18, 19 of 20 mm materiaal toe.'}, 400)

            raw, recs = self._load_material_library_bundle()
            used = {str(x.get('publicMaterialId') or '').strip() for x in recs if isinstance(x, dict)}
            existing_match = None
            for existing in recs:
                if not isinstance(existing, dict):
                    continue
                ex_art = str(existing.get('articleNo') or existing.get('articleNumber') or existing.get('materialCode') or '').strip()
                if ex_art == article and ex_art != prev_article:
                    return self._send_json({'ok': False, 'error': 'Artikelnummer bestaat al'}, 400)
                if ex_art == prev_article or (not prev_article and ex_art == article):
                    existing_match = existing
            pid = str(norm.get('publicMaterialId') or '').strip().lower()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                old_pid = str((existing_match or {}).get('publicMaterialId') or '').strip().lower()
                pid = old_pid if _PUBLIC_MATERIAL_ID_RE.fullmatch(old_pid) else self._new_public_material_id(used)
            elif pid in used and (not existing_match or pid != str(existing_match.get('publicMaterialId') or '').strip()):
                return self._send_json({'ok': False, 'error': 'Publieke decor-ID bestaat al'}, 400)

            norm['publicMaterialId'] = pid
            norm['publicName'] = self._public_material_name(norm)
            norm['brand'] = self._infer_material_brand(norm)
            norm['decorType'] = self._infer_material_decor_type(norm)
            norm['colorGroup'] = str(norm.get('colorGroup') or 'Overig').strip() or 'Overig'
            norm['published'] = bool(norm.get('published', norm.get('active', True)))
            norm['isPopular'] = bool(norm.get('isPopular', False))
            norm['isNew'] = bool(norm.get('isNew', False))
            norm['hasGrain'] = bool(norm.get('hasGrain', True))
            norm['grainDefaultOn'] = bool(norm.get('grainDefaultOn', True))
            norm['archived'] = bool(norm.get('archived', False))
            norm['sellPriceInclVatPerSheet'] = round(sell_inc, 2)
            norm['sellPriceExVatPerSheet'] = round(sell_inc / (1.0 + CATALOG_VAT_RATE), 6)
            norm['priceVatRate'] = CATALOG_VAT_RATE
            norm['priceSource'] = 'ADMIN_DIRECT_SELL_PRICE'
            norm['catalogMissing'] = False if str(norm.get('sourceKind') or '').upper() != 'CATALOG_IMPORT' else bool(norm.get('catalogMissing', False))
            if isinstance(existing_match, dict):
                # Preserve imported source ownership and all internal source/image metadata.
                merged = dict(existing_match)
                merged.update(norm)
                norm = merged
            else:
                norm['sourceKind'] = 'MANUAL'

            updated = False
            for i, existing in enumerate(recs):
                if not isinstance(existing, dict):
                    continue
                ex_art = str(existing.get('articleNo') or existing.get('articleNumber') or existing.get('materialCode') or '').strip()
                if ex_art == prev_article or (not prev_article and ex_art == article):
                    recs[i] = norm; updated = True; break
            if not updated:
                recs.append(norm)
            raw['records'] = recs
            raw['recordCountOriginal'] = len(recs)
            raw['recordCountFiltered'] = len(recs)
            raw['decorLibrarySchemaVersion'] = 2
            self._save_material_library_bundle(raw)
            _append_system_event(level='info', component='materials', message_user='Materiaal opgeslagen', message_tech=f'Saved internal articleNo={article}, publicMaterialId={pid} with direct sell price', customer_name=article, status='resolved')
            return self._send_json({'ok': True, 'articleNo': article, 'publicMaterialId': pid, 'count': len(recs)})
        except Exception as e:
            _append_system_event(level='error', component='materials', message_user='Materiaal kon niet worden opgeslagen', message_tech=str(e), customer_name=_safe_text((data or {}).get('record',{}).get('publicName') if isinstance((data or {}).get('record'), dict) else '', 160), status='open')
            return self._send_json({'ok': False, 'error': 'Materiaal opslaan is mislukt'}, 400)

    def _api_admin_materials_delete_item(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)
        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
            article = str(data.get('articleNo') or '').strip()
            if not article:
                return self._send_json({'ok': False, 'error': 'Artikelnummer ontbreekt'}, 400)
            raw, recs = self._load_material_library_bundle()
            changed = 0
            for r in recs:
                if not isinstance(r, dict):
                    continue
                ex_art = str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip()
                if ex_art == article:
                    r['active'] = False
                    r['published'] = False
                    r['archived'] = True
                    r['archivedAt'] = _utc_now_iso()
                    changed += 1
            if not changed:
                return self._send_json({'ok': False, 'error': 'Materiaal niet gevonden'}, 404)
            raw['records'] = recs
            self._save_material_library_bundle(raw)
            _append_system_event(level='info', component='materials', message_user='Materiaal gearchiveerd', message_tech=f'Archived articleNo={article}', customer_name=article, status='resolved')
            return self._send_json({'ok': True, 'archived': changed, 'count': len(recs)})
        except Exception as e:
            _append_system_event(level='error', component='materials', message_user='Materiaal archiveren is mislukt', message_tech=str(e), customer_name=_safe_text((data or {}).get('articleNo'), 120), status='open')
            return self._send_json({'ok': False, 'error': 'Materiaal archiveren is mislukt'}, 400)

    def _api_admin_materials_upload(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)
        """Legacy/advanced JSON library replacement.

        Kept for recovery/admin migration only. It obeys the same direct-price and
        thickness rules as the CSV catalog so the old import path cannot reintroduce
        factor pricing or unsupported public materials.
        """
        data = _read_json_body_limited(self, 'ADMIN_MATERIALS_UPLOAD_MAX_BYTES', 8388608)
        if isinstance(data, list):
            data = {'source': 'admin upload', 'records': data}
        if not isinstance(data, dict) or not data:
            return self._send_json({'ok': False, 'error': 'Material library must be a non-empty JSON object'}, 400)
        recs = data.get('records')
        if not isinstance(recs, list) or not recs:
            return self._send_json({'ok': False, 'error': 'Material library must contain a non-empty records list'}, 400)
        _, existing = self._load_material_library_bundle()
        existing_pid_by_article = {
            str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip(): str(r.get('publicMaterialId') or '').strip()
            for r in existing if isinstance(r, dict)
        }
        used = {v for v in existing_pid_by_article.values() if _PUBLIC_MATERIAL_ID_RE.fullmatch(v)}
        norm = []
        seen_articles = set()
        for r in recs:
            if not isinstance(r, dict):
                return self._send_json({'ok': False, 'error': 'Every record must be an object'}, 400)
            rr = self._normalize_material_record_for_admin(r)
            art = str(rr.get('articleNo') or '').strip()
            if not art:
                return self._send_json({'ok': False, 'error': 'Elke record moet een artikelnummer hebben'}, 400)
            if art in seen_articles:
                return self._send_json({'ok': False, 'error': f'Dubbel artikelnummer: {art}'}, 400)
            seen_articles.add(art)
            try:
                wid = float(rr.get('sheetWid') or 0)
                leng = float(rr.get('sheetLen') or 0)
                thick = float(rr.get('thicknessMm') or 0)
            except Exception:
                return self._send_json({'ok': False, 'error': f'Ongeldige maat in {art}'}, 400)
            if wid <= 0 or leng <= 0:
                return self._send_json({'ok': False, 'error': f'Breedte/lengte ongeldig in {art}'}, 400)
            if not any(abs(thick - float(x)) < 1e-9 for x in CATALOG_ALLOWED_THICKNESSES_MM):
                return self._send_json({'ok': False, 'error': f'{art}: alleen 18, 19 of 20 mm is toegestaan'}, 400)

            # New JSON exports should carry direct sell price. For recovery of an older
            # Admin JSON export, freeze its already-computed retail ex-VAT price once.
            try: sell_inc = float(rr.get('sellPriceInclVatPerSheet') or 0.0)
            except Exception: sell_inc = 0.0
            try: sell_ex = float(rr.get('sellPriceExVatPerSheet') or 0.0)
            except Exception: sell_ex = 0.0
            if sell_inc <= 0 and sell_ex <= 0:
                try: sell_ex = float(r.get('retailPriceWithoutTax') or 0.0)
                except Exception: sell_ex = 0.0
                if sell_ex > 0:
                    sell_inc = round(sell_ex * (1.0 + CATALOG_VAT_RATE), 2)
            if sell_inc <= 0 and sell_ex > 0:
                sell_inc = round(sell_ex * (1.0 + CATALOG_VAT_RATE), 2)
            if sell_ex <= 0 and sell_inc > 0:
                sell_ex = round(sell_inc / (1.0 + CATALOG_VAT_RATE), 6)
            if sell_inc <= 0 or sell_ex <= 0:
                return self._send_json({'ok': False, 'error': f'{art}: directe verkoopprijs ontbreekt'}, 400)
            rr['sellPriceInclVatPerSheet'] = round(sell_inc, 2)
            rr['sellPriceExVatPerSheet'] = round(sell_ex, 6)
            rr['priceVatRate'] = CATALOG_VAT_RATE
            rr['priceSource'] = str(rr.get('priceSource') or 'ADMIN_JSON_DIRECT_SELL_PRICE')

            pid = str(rr.get('publicMaterialId') or existing_pid_by_article.get(art) or '').strip().lower()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid) or pid in {x.get('publicMaterialId') for x in norm}:
                pid = self._new_public_material_id(used)
            rr['publicMaterialId'] = pid
            rr['publicName'] = self._public_material_name(rr)
            rr['brand'] = self._infer_material_brand(rr)
            rr['decorType'] = self._infer_material_decor_type(rr)
            rr['colorGroup'] = str(rr.get('colorGroup') or 'Overig').strip() or 'Overig'
            rr['published'] = bool(rr.get('published', rr.get('active', True)))
            rr['sourceKind'] = str(rr.get('sourceKind') or 'LEGACY_LIBRARY').strip() or 'LEGACY_LIBRARY'
            norm.append(rr)
        data['records'] = norm
        data['recordCountOriginal'] = len(norm)
        data['recordCountFiltered'] = len(norm)
        data['decorLibrarySchemaVersion'] = 2
        data['pricingModel'] = 'catalog_sell_price_incl_vat_v2'
        self._save_material_library_bundle(data)
        _append_system_event(level='info', component='materials', message_user='Material Library vervangen via geavanceerde JSON-upload', message_tech=f'Uploaded {len(norm)} records with direct sell prices and preserved public IDs', status='resolved')
        return self._send_json({'ok': True, 'count': len(norm), 'pricingModel': 'catalog_sell_price_incl_vat_v2'})

    def _api_public_material_image(self, public_id: str, variant: str):
        pid = str(public_id or '').strip().lower()
        if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
            return self._send_text('Not found', 404)
        ctype = 'image/webp'
        path = None
        if variant == 'catalog':
            cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            if cached:
                path, meta = cached
                ctype = str(meta.get('mime') or 'application/octet-stream')
        else:
            path = self._decor_image_file(pid, variant)
        if path is None or not path.exists() or not path.is_file():
            return self._send_text('Not found', 404)
        try:
            data = path.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'public, max-age=31536000, immutable')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)
        except Exception:
            return self._send_text('Image unavailable', 500)

    def _api_admin_material_image_upload(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)
        try:
            data = _read_json_body_limited(self, 'ADMIN_DECOR_IMAGE_MAX_BYTES', 8388608) or {}
            pid = str(data.get('publicMaterialId') or '').strip().lower()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                return self._send_json({'ok': False, 'error': 'Sla het decor eerst op om een publieke ID te maken.'}, 400)
            thumb_raw = base64.b64decode(str(data.get('thumbnailBase64') or ''), validate=True)
            preview_raw = base64.b64decode(str(data.get('previewBase64') or ''), validate=True)
            if len(thumb_raw) > 1200000 or len(preview_raw) > 5000000:
                return self._send_json({'ok': False, 'error': 'Afbeelding is te groot.'}, 413)
            thumb_dim = self._webp_dimensions(thumb_raw)
            preview_dim = self._webp_dimensions(preview_raw)
            if thumb_dim != (720, 540) or preview_dim != (1600, 1200):
                return self._send_json({'ok': False, 'error': 'Afbeelding heeft een ongeldig formaat.'}, 400)
            raw, recs = self._load_material_library_bundle()
            rec = next((r for r in recs if isinstance(r, dict) and str(r.get('publicMaterialId') or '').strip() == pid), None)
            if rec is None:
                return self._send_json({'ok': False, 'error': 'Decor niet gevonden.'}, 404)
            folder = DECOR_MEDIA_ROOT / pid
            folder.mkdir(parents=True, exist_ok=True)
            for name, blob in (('thumb.webp', thumb_raw), ('preview.webp', preview_raw)):
                target = folder / name
                durable_write_bytes(target, blob, mode=0o640)
            version = str(int(time.time() * 1000))
            rec['imageVersion'] = version
            rec['imageUpdatedAt'] = _utc_now_iso()
            self._save_material_library_bundle(raw)
            _append_system_event(level='info', component='materials', message_user='Decorafbeelding opgeslagen', message_tech=f'Uploaded WebP images for {pid}', status='resolved')
            return self._send_json({'ok': True, 'publicMaterialId': pid, 'imageVersion': version, 'imageThumbUrl': f'/api/materials/image/{pid}/thumb.webp?v={version}', 'imagePreviewUrl': f'/api/materials/image/{pid}/preview.webp?v={version}'})
        except (ValueError, binascii.Error):
            return self._send_json({'ok': False, 'error': 'Ongeldige afbeeldingsdata.'}, 400)
        except Exception as e:
            _append_system_event(level='error', component='materials', message_user='Decorafbeelding opslaan is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Afbeelding opslaan is mislukt.'}, 400)

    def _api_admin_material_image_delete(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)

    def _catalog_import_file(self, import_id: str) -> Path | None:
        iid = str(import_id or '').strip().lower()
        if not re.fullmatch(r'cat_[a-f0-9]{24}', iid):
            return None
        root = CATALOG_IMPORT_ROOT.resolve()
        path = (CATALOG_IMPORT_ROOT / f'{iid}.json').resolve()
        if root not in path.parents:
            return None
        return path

    def _catalog_import_status_file(self, import_id: str) -> Path | None:
        iid = str(import_id or '').strip().lower()
        if not re.fullmatch(r'cat_[a-f0-9]{24}', iid):
            return None
        root = CATALOG_IMPORT_ROOT.resolve()
        path = (CATALOG_IMPORT_ROOT / f'{iid}_images.json').resolve()
        if root not in path.parents:
            return None
        return path

    def _catalog_import_media_dir(self, import_id: str) -> Path | None:
        iid = str(import_id or '').strip().lower()
        if not re.fullmatch(r'cat_[a-f0-9]{24}', iid):
            return None
        root = CATALOG_IMPORT_ROOT.resolve()
        path = (CATALOG_IMPORT_ROOT / f'{iid}_media').resolve()
        if root not in path.parents:
            return None
        return path

    def _reserve_catalog_stage_ids_and_images(self, stage: dict) -> tuple[dict[str, str], list[dict]]:
        """Reserve stable opaque IDs and decide which images must be prepared.

        Reservation is private/backend-only and does not publish catalog records. This
        lets the potentially slow network/image work happen during Admin review rather
        than after customers can already see the new catalog.
        """
        _, existing_all = self._load_material_library_bundle()
        existing = [r for r in existing_all if isinstance(r, dict) and str(r.get('sourceKind') or '').upper() == 'CATALOG_IMPORT']
        existing_by_article = {str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip(): r for r in existing if str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip()}
        registry = self._load_catalog_public_id_registry()
        for rec in existing_all:
            if not isinstance(rec, dict):
                continue
            art = str(rec.get('articleNo') or rec.get('articleNumber') or rec.get('materialCode') or '').strip()
            pid = str(rec.get('publicMaterialId') or '').strip().lower()
            if art and _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                registry.setdefault(art, pid)
        used = set(registry.values())
        reserved = {}
        targets = []
        for rec in (stage.get('records') or []):
            if not isinstance(rec, dict):
                continue
            art = str(rec.get('articleNo') or '').strip()
            if not art:
                continue
            old = existing_by_article.get(art) or {}
            pid = str(registry.get(art) or old.get('publicMaterialId') or '').strip().lower()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                pid = self._new_public_material_id(used)
            used.add(pid); registry[art] = pid; reserved[art] = pid
            urls = [str(u or '').strip() for u in (rec.get('imageSourceUrls') or []) if str(u or '').strip()]
            source_hash = hashlib.sha256('|'.join(urls).encode('utf-8')).hexdigest() if urls else ''
            old_hash = str(old.get('catalogImageSourceHash') or '')
            cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            # Reuse an already prepared live image only when its source set is unchanged.
            if urls and (not cached or source_hash != old_hash):
                targets.append({'articleNo': art, 'publicMaterialId': pid, 'urls': urls, 'sourceHash': source_hash})
        self._save_catalog_public_id_registry(registry)
        stage['reservedPublicIds'] = reserved
        stage['imageTargets'] = targets
        stage['imagePreparationRequired'] = len(targets)
        return reserved, targets

    def _promote_catalog_stage_images(self, import_id: str, stage: dict) -> int:
        """Promote fully prepared staged images into the live opaque media cache."""
        iid = str(import_id or '').strip().lower()
        stage_root = self._catalog_import_media_dir(iid)
        if stage_root is None:
            raise ValueError('Ongeldige catalogus-image stagingmap.')
        promoted = 0
        for target in (stage.get('imageTargets') or []):
            if not isinstance(target, dict):
                continue
            pid = str(target.get('publicMaterialId') or '').strip().lower()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                raise ValueError('Ongeldige publieke decor-ID in image staging.')
            src = stage_root / pid
            cached = _catalog_read_cached_image(src)
            if not cached:
                raise RuntimeError('Niet alle catalogusafbeeldingen zijn voorbereid.')
            dst = DECOR_MEDIA_ROOT / pid
            dst.mkdir(parents=True, exist_ok=True)
            # Copy current prepared files to same-filesystem temp names, then replace.
            staged_names = {fp.name for fp in src.iterdir() if fp.is_file() and fp.name in {'catalog.img','catalog.meta.json','thumb.webp','preview.webp'}}
            if not {'catalog.img','catalog.meta.json'}.issubset(staged_names):
                raise RuntimeError('Catalogusafbeelding staging is incompleet.')
            for name in ('catalog.img','thumb.webp','preview.webp','catalog.meta.json'):
                srcf = src / name
                dstf = dst / name
                if srcf.exists():
                    durable_copy_file(srcf, dstf, mode=0o640)
                elif name in ('thumb.webp','preview.webp') and dstf.exists():
                    # Prevent an old WebP variant from being paired with a new raw image.
                    dstf.unlink(missing_ok=True)
                    fsync_directory(dst)
            promoted += 1
        return promoted

    def _api_admin_live_taxonomy_family(self):
        """Persist one Admin-only filter-family override for an active CSV product.

        This endpoint deliberately cannot mutate CSV truth fields such as price, size,
        thickness, product name, image source or catalog membership.
        """
        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 65536) or {}
            pid = str(data.get('publicMaterialId') or '').strip().lower()
            requested = str(data.get('primaryVisualFamily') or '').strip()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                return self._send_json({'ok': False, 'error': 'Ongeldige publieke decor-ID.'}, 400)
            if requested != 'AUTO' and requested not in CATALOG_PUBLIC_FAMILIES:
                return self._send_json({'ok': False, 'error': 'Ongeldige filtercategorie.'}, 400)

            with _MATERIAL_LIBRARY_LOCK:
                raw, records = self._load_material_library_bundle()
                idx = next((i for i,r in enumerate(records) if isinstance(r,dict) and str(r.get('publicMaterialId') or '').strip().lower()==pid), None)
                if idx is None:
                    return self._send_json({'ok': False, 'error': 'Catalogusproduct niet gevonden.'}, 404)
                original = records[idx]
                if str(original.get('sourceKind') or '').upper() != 'CATALOG_IMPORT' or original.get('catalogMissing') is True or original.get('catalogExcluded') is True or original.get('active') is False or original.get('published') is False:
                    return self._send_json({'ok': False, 'error': 'Alleen een actief gepubliceerd CSV-product kan worden aangepast.'}, 409)

                immutable_before = {k: json.dumps(original.get(k), ensure_ascii=False, sort_keys=True) for k in (
                    'articleNo','publicMaterialId','productName','publicName','sheetWid','sheetLen','thicknessMm',
                    'sellPriceInclVatPerSheet','sellPriceExVatPerSheet','priceVatRate','priceSource',
                    'imageSourceUrl','imageVersion','sourceKind','active','published'
                )}
                updated = _taxonomy_clear_admin_family_override(original) if requested == 'AUTO' else _taxonomy_apply_admin_family_override(original, requested)
                immutable_after = {k: json.dumps(updated.get(k), ensure_ascii=False, sort_keys=True) for k in immutable_before}
                if immutable_before != immutable_after:
                    raise RuntimeError('Taxonomy override probeerde CSV-waarheid te wijzigen.')
                records[idx] = updated
                raw['records'] = records
                registry = _taxonomy_load_registry(CATALOG_TAXONOMY_REGISTRY)
                registry = _taxonomy_registry_with_records(registry, [updated])
                # Registry first is safe: it cannot activate products; active catalog remains CSV-only.
                _taxonomy_save_registry(CATALOG_TAXONOMY_REGISTRY, registry)
                self._save_material_library_bundle(raw)

            normalized = self._normalize_material_record_for_admin(updated)
            _append_system_event(
                level='info', component='catalog_taxonomy',
                message_user='Filtercategorie materiaal aangepast',
                message_tech=f'publicMaterialId={pid}; mode={"AUTO" if requested=="AUTO" else "MANUAL"}; family={normalized.get("primaryVisualFamily")}',
                status='resolved', details={'actor': self._current_admin_actor() or 'unknown-admin', 'publicMaterialId': pid}
            )
            return self._send_json({
                'ok': True,
                'record': normalized,
                'primaryVisualFamily': normalized.get('primaryVisualFamily'),
                'manualOverride': bool(normalized.get('taxonomyManualFamilyOverride')),
            })
        except ValueError as e:
            return self._send_json({'ok': False, 'error': str(e)}, 400)
        except Exception as e:
            _append_system_event(level='error', component='catalog_taxonomy', message_user='Filtercategorie opslaan is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Filtercategorie opslaan is mislukt.'}, 500)

    def _api_admin_catalog_preview(self):
        try:
            data = _read_json_body_limited(self, 'ADMIN_CATALOG_IMPORT_MAX_BYTES', 4 * 1024 * 1024) or {}
            csv_text = data.get('csvText') if isinstance(data, dict) else None
            if not isinstance(csv_text, str) or not csv_text.strip():
                return self._send_json({'ok': False, 'error': 'Kies eerst een CSV-bestand.'}, 400)
            parsed = _parse_catalog_csv(csv_text)
            taxonomy_registry = _taxonomy_load_registry(CATALOG_TAXONOMY_REGISTRY)
            enriched_records, taxonomy_summary, taxonomy_review = _taxonomy_enrich_records(parsed.get('records') or [], taxonomy_registry)
            parsed['records'] = enriched_records
            raw, existing_all = self._load_material_library_bundle()
            existing = [r for r in existing_all if isinstance(r, dict) and str(r.get('sourceKind') or '').upper() == 'CATALOG_IMPORT']
            diff = _catalog_diff(parsed.get('records') or [], existing, parsed.get('excluded') or [])
            import_id = 'cat_' + secrets.token_hex(12)
            stage = {
                'schemaVersion': 1,
                'importId': import_id,
                'createdAt': _utc_now_iso(),
                'createdAtEpoch': time.time(),
                'csvSha256': parsed.get('csvSha256'),
                'sourceType': parsed.get('sourceType'),
                'records': parsed.get('records') or [],
                'excluded': parsed.get('excluded') or [],
                'warnings': parsed.get('warnings') or [],
                'errors': parsed.get('errors') or [],
                'summary': parsed.get('summary') or {},
                'diff': diff,
                'taxonomySummary': taxonomy_summary,
                'taxonomyReview': taxonomy_review,
            }
            path = self._catalog_import_file(import_id)
            if path is None:
                raise ValueError('Kon import-ID niet aanmaken')
            _, image_targets = self._reserve_catalog_stage_ids_and_images(stage)
            _atomic_write_json(path, stage)
            image_started = False
            if image_targets and not stage.get('errors'):
                image_started = self._start_catalog_image_sync(import_id, image_targets, staging=True)
            elif not image_targets:
                status_path = self._catalog_import_status_file(import_id)
                if status_path is not None:
                    _atomic_write_json(status_path, {'ok': True, 'importId': import_id, 'state': 'DONE', 'phase':'PREPARE_BEFORE_PUBLISH', 'total':0, 'processed':0, 'success':0, 'failed':0, 'skipped':0, 'errors':[], 'finishedAt':_utc_now_iso()})
            summary = dict(stage['summary'])
            summary.update(diff.get('counts') or {})
            summary.update({
                'taxonomyVerified': int(taxonomy_summary.get('verified') or 0),
                'taxonomyReused': int(taxonomy_summary.get('reused') or 0),
                'taxonomyAutoVerified': int(taxonomy_summary.get('autoVerified') or 0),
                'taxonomyAdminVerified': int(taxonomy_summary.get('adminVerified') or 0),
                'taxonomyReviewRequired': int(taxonomy_summary.get('reviewRequired') or 0),
            })
            preview_rows = []
            for r in (stage['records'] or [])[:60]:
                preview_rows.append({
                    'articleNo': r.get('articleNo'),
                    'productName': r.get('productName'),
                    'thicknessMm': r.get('thicknessMm'),
                    'sheetLen': r.get('sheetLen'),
                    'sheetWid': r.get('sheetWid'),
                    'sellPriceInclVatPerSheet': r.get('sellPriceInclVatPerSheet'),
                    'dimensionSource': r.get('dimensionSource'),
                    'imageCount': len(r.get('imageSourceUrls') or []),
                    'primaryVisualFamily': r.get('primaryVisualFamily'),
                    'substrateLabel': r.get('substrateLabel'),
                    'collection': r.get('collection'),
                })
            return self._send_json({
                'ok': True,
                'importId': import_id,
                'reviewSha256': _catalog_review_sha256(stage),
                'summary': summary,
                'warnings': stage['warnings'][:120],
                'errors': stage['errors'][:120],
                'excluded': stage['excluded'][:120],
                'recordsPreview': preview_rows,
                'taxonomySummary': taxonomy_summary,
                'taxonomyReview': taxonomy_review[:120],
                'taxonomyFamilies': list(CATALOG_PUBLIC_FAMILIES),
                'taxonomySubstrates': [{'value': k, 'label': v} for k,v in CATALOG_SUBSTRATE_LABELS.items() if k != 'ONBEKEND'],
                # Publication is unlocked only when taxonomy is complete and all required images are local.
                'canPublish': len(stage['errors']) == 0 and len(stage['records']) > 0 and int(taxonomy_summary.get('reviewRequired') or 0) == 0 and len(image_targets) == 0,
                'canPublishAfterImages': len(stage['errors']) == 0 and len(stage['records']) > 0 and int(taxonomy_summary.get('reviewRequired') or 0) == 0,
                'imagePreparationStarted': image_started,
                'imageSyncTotal': len(image_targets),
            })
        except Exception as e:
            _append_system_event(level='error', component='catalog_import', message_user='CSV controleren is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'CSV kon niet veilig worden gecontroleerd.'}, 400)

    def _catalog_snapshot_before_publish(self, import_id: str) -> str:
        CATALOG_IMPORT_HISTORY.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
        folder = CATALOG_IMPORT_HISTORY / f'{stamp}_{import_id}_{secrets.token_hex(3)}'
        folder.mkdir(parents=True, exist_ok=True)
        if MATERIAL_LIBRARY_PATH.exists():
            durable_copy_file(MATERIAL_LIBRARY_PATH, folder / 'material_library.json', mode=0o640)
        if PRICING_ACTIVE.exists():
            durable_copy_file(PRICING_ACTIVE, folder / 'pricing_active.json', mode=0o640)
        return folder.name

    def _load_catalog_public_id_registry(self) -> dict[str, str]:
        try:
            if CATALOG_PUBLIC_ID_REGISTRY.exists():
                raw = strict_json_load(CATALOG_PUBLIC_ID_REGISTRY)
                if isinstance(raw, dict):
                    values = raw.get('byArticle') if isinstance(raw.get('byArticle'), dict) else raw
                    return {str(k): str(v).lower() for k,v in values.items() if str(k).strip() and _PUBLIC_MATERIAL_ID_RE.fullmatch(str(v).strip().lower())}
        except Exception:
            pass
        return {}

    def _save_catalog_public_id_registry(self, mapping: dict[str, str]) -> None:
        CATALOG_PUBLIC_ID_REGISTRY.parent.mkdir(parents=True, exist_ok=True)
        clean = {str(k).strip(): str(v).strip().lower() for k,v in mapping.items() if str(k).strip() and _PUBLIC_MATERIAL_ID_RE.fullmatch(str(v).strip().lower())}
        _atomic_write_json(CATALOG_PUBLIC_ID_REGISTRY, {'schemaVersion': 1, 'updatedAt': _utc_now_iso(), 'byArticle': dict(sorted(clean.items()))})

    def _merge_catalog_stage(self, stage: dict) -> dict:
        """Publish the staged CSV as the *entire* active catalog.

        FIX652 deliberately has no merge-with-legacy semantics. The active records list is
        exactly the eligible current CSV rows. A snapshot and an internal opaque-ID registry
        preserve history/stable public IDs without keeping old seed records active.
        """
        raw, existing_all = self._load_material_library_bundle()
        existing = [r for r in existing_all if isinstance(r, dict) and str(r.get('sourceKind') or '').upper() == 'CATALOG_IMPORT']
        existing_by_article = {str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip(): r for r in existing if str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip()}
        registry = self._load_catalog_public_id_registry()
        # Seed/refresh registry from anything that ever had a valid opaque ID, including a
        # pre-FIX652 legacy library. This preserves opaque IDs without preserving fake data.
        for rec in existing_all:
            if not isinstance(rec, dict):
                continue
            art = str(rec.get('articleNo') or rec.get('articleNumber') or rec.get('materialCode') or '').strip()
            pid = str(rec.get('publicMaterialId') or '').strip().lower()
            if art and _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                registry.setdefault(art, pid)
        used_ids = set(registry.values())
        staged_records = [r for r in (stage.get('records') or []) if isinstance(r, dict)]
        now = _utc_now_iso()
        final_records = []
        image_targets = []

        authoritative_fields = (
            'articleNo','materialCode','productName','decorName','thicknessMm','sheetLen','sheetWid',
            'sellPriceInclVatPerSheet','sellPriceExVatPerSheet','priceVatRate','priceSource',
            'imageSourceUrls','imageSourceUrl','dimensionSource','catalogSource','brand','categoryName',
            'primaryVisualFamily','visualFamily','visualTags','substrateType','substrateLabel','manufacturerCode','collection',
            'taxonomyStatus','taxonomySource','taxonomyConfidence','taxonomyRulesetVersion','classificationFingerprint','taxonomyManualFamilyOverride',
            'colorGroup','searchTags',
        )
        for staged in staged_records:
            art = str(staged.get('articleNo') or '').strip()
            if not art:
                continue
            old = existing_by_article.get(art) or {}
            merged = {}
            for key in authoritative_fields:
                if key in staged:
                    merged[key] = staged.get(key)
            reserved_ids = stage.get('reservedPublicIds') if isinstance(stage.get('reservedPublicIds'), dict) else {}
            pid = str(reserved_ids.get(art) or registry.get(art) or old.get('publicMaterialId') or '').strip().lower()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                pid = self._new_public_material_id(used_ids)
            used_ids.add(pid)
            registry[art] = pid
            merged['publicMaterialId'] = pid
            merged['publicName'] = str(staged.get('publicName') or staged.get('productName') or 'Decor').strip()[:180]
            merged['brand'] = str(staged.get('brand') or self._infer_material_brand(merged)).strip() or 'Overig'
            merged['categoryName'] = str(staged.get('categoryName') or '').strip()
            presentation = self._material_presentation(merged)
            merged['primaryVisualFamily'] = str(staged.get('primaryVisualFamily') or staged.get('visualFamily') or presentation.get('visualFamily') or 'Onbekend')
            merged['visualFamily'] = merged['primaryVisualFamily']
            merged['visualTags'] = [merged['primaryVisualFamily']]
            merged['decorType'] = merged['primaryVisualFamily']
            merged['substrateType'] = str(staged.get('substrateType') or 'ONBEKEND').upper()
            merged['substrateLabel'] = str(staged.get('substrateLabel') or CATALOG_SUBSTRATE_LABELS.get(merged['substrateType']) or 'Onbekend')
            merged['colorGroup'] = str(staged.get('colorGroup') or presentation.get('colorGroup') or 'Overig')
            merged['searchTags'] = list(staged.get('searchTags') or presentation.get('searchTags') or [])
            # No second hand-maintained catalog: these presentation flags are deterministic defaults.
            merged['hasGrain'] = True
            merged['grainDefaultOn'] = True
            merged['isPopular'] = False
            merged['isNew'] = False
            merged['active'] = True
            merged['published'] = True
            merged['archived'] = False
            merged['sourceKind'] = 'CATALOG_IMPORT'
            merged['catalogMissing'] = False
            merged['catalogExcluded'] = False
            merged['catalogImportedAt'] = now
            urls = list(staged.get('imageSourceUrls') or [])
            source_hash = hashlib.sha256('|'.join(urls).encode('utf-8')).hexdigest() if urls else ''
            merged['catalogImageSourceHash'] = source_hash
            old_hash = str(old.get('catalogImageSourceHash') or '')
            cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            if urls and (not cached or source_hash != old_hash):
                image_targets.append({'articleNo': art, 'publicMaterialId': pid, 'urls': urls})
            final_records.append(merged)

        old_active_articles = {str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip() for r in existing if str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip()}
        new_articles = {str(r.get('articleNo') or '').strip() for r in final_records}
        removed_from_active = len(old_active_articles - new_articles)

        new_raw = {
            'source': 'CSV_CATALOG_ONLY',
            'pricingModel': 'catalog_sell_price_incl_vat_v2',
            'decorLibrarySchemaVersion': 4,
            'records': final_records,
            'recordCountOriginal': len(final_records),
            'recordCountFiltered': len(final_records),
            'lastCatalogImport': {
                'importId': stage.get('importId'),
                'publishedAt': now,
                'csvSha256': stage.get('csvSha256'),
                'eligibleRows': len(final_records),
                'excludedThickness': len(stage.get('excluded') or []),
                'warnings': len(stage.get('warnings') or []),
                'removedFromActive': removed_from_active,
                'taxonomyVerified': int((stage.get('taxonomySummary') or {}).get('verified') or 0),
                'taxonomyReviewRequired': int((stage.get('taxonomySummary') or {}).get('reviewRequired') or 0),
            },
        }
        taxonomy_registry = _taxonomy_load_registry(CATALOG_TAXONOMY_REGISTRY)
        taxonomy_registry = _taxonomy_registry_with_records(taxonomy_registry, final_records)
        # Safe to write first: an orphan private taxonomy entry can never activate a product.
        _taxonomy_save_registry(CATALOG_TAXONOMY_REGISTRY, taxonomy_registry)
        self._save_material_library_bundle(new_raw)
        self._save_catalog_public_id_registry(registry)
        return {'count': len(final_records), 'imageTargets': image_targets, 'missingFromSource': removed_from_active, 'removedFromActive': removed_from_active, 'catalogExcludedExisting': 0}

    def _start_catalog_image_sync(self, import_id: str, targets: list[dict], staging: bool = False) -> bool:
        iid = str(import_id or '').strip().lower()
        status_path = self._catalog_import_status_file(iid)
        if status_path is None:
            return False
        with _CATALOG_IMAGE_SYNC_LOCK:
            if iid in _CATALOG_IMAGE_SYNC_ACTIVE:
                return False
            _CATALOG_IMAGE_SYNC_ACTIVE.add(iid)

        initial = {
            'ok': True, 'importId': iid, 'state': 'RUNNING', 'phase': ('PREPARE_BEFORE_PUBLISH' if staging else 'LIVE_RETRY'), 'startedAt': _utc_now_iso(),
            'total': len(targets), 'processed': 0, 'success': 0, 'failed': 0, 'skipped': 0, 'errors': [],
        }
        _atomic_write_json(status_path, initial)

        def run():
            st = dict(initial)
            status_lock = threading.Lock()
            target_root = self._catalog_import_media_dir(iid) if staging else DECOR_MEDIA_ROOT
            if target_root is None:
                st['state'] = 'FAILED'; st['fatalError'] = 'Ongeldige image stagingmap.'; st['finishedAt'] = _utc_now_iso()
                _atomic_write_json(status_path, st)
                with _CATALOG_IMAGE_SYNC_LOCK:
                    _CATALOG_IMAGE_SYNC_ACTIVE.discard(iid)
                return
            target_root.mkdir(parents=True, exist_ok=True)

            def process_one(target):
                pid = str(target.get('publicMaterialId') or '').strip().lower()
                article = str(target.get('articleNo') or '').strip()
                urls = [str(u or '').strip() for u in (target.get('urls') or []) if str(u or '').strip()]
                last_error = ''
                if _PUBLIC_MATERIAL_ID_RE.fullmatch(pid) and urls:
                    for url in urls:
                        try:
                            payload = _catalog_download_image(url)
                            meta = _catalog_atomic_write_cached_image(target_root / pid, payload)
                            return {'ok': True, 'articleNo': article, 'pid': pid, 'variantGenerator': meta.get('variantGenerator')}
                        except Exception as e:
                            last_error = str(e)
                else:
                    last_error = 'Geen geldige publieke decor-ID of afbeeldingslink.'
                return {'ok': False, 'articleNo': article, 'pid': pid, 'error': last_error}

            try:
                # A small bounded pool keeps Admin imports practical without hammering the
                # source website or the VPS. Public Tool A never waits for this work.
                from concurrent.futures import ThreadPoolExecutor, as_completed
                max_workers = max(1, min(6, _env_int('CATALOG_IMAGE_WORKERS', 4)))
                with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix='catalog-img') as pool:
                    futures = [pool.submit(process_one, t) for t in targets]
                    for fut in as_completed(futures):
                        res = fut.result()
                        with status_lock:
                            if res.get('ok'):
                                st['success'] += 1
                                if res.get('variantGenerator') == 'pillow-webp':
                                    st['webpPrepared'] = int(st.get('webpPrepared') or 0) + 1
                                else:
                                    st['rawFallback'] = int(st.get('rawFallback') or 0) + 1
                            else:
                                st['failed'] += 1
                                if len(st['errors']) < 100:
                                    st['errors'].append({'articleNo': res.get('articleNo') or '', 'message': _safe_text(res.get('error') or '', 220)})
                            st['processed'] = int(st.get('processed') or 0) + 1
                            st['updatedAt'] = _utc_now_iso()
                            _atomic_write_json(status_path, st)
                st['state'] = 'DONE' if st['failed'] == 0 else 'DONE_WITH_ERRORS'
                st['finishedAt'] = _utc_now_iso()
                _atomic_write_json(status_path, st)
                _append_system_event(level='info' if st['failed'] == 0 else 'warning', component='catalog_images', message_user='Catalogusafbeeldingen voorbereid' if staging else 'Catalogusafbeeldingen bijgewerkt', message_tech=f"import={iid}; staging={staging}; success={st['success']}; failed={st['failed']}; webp={st.get('webpPrepared',0)}", status='resolved' if st['failed'] == 0 else 'open')
            except Exception as e:
                st['state'] = 'FAILED'; st['fatalError'] = _safe_text(str(e), 240); st['finishedAt'] = _utc_now_iso()
                try: _atomic_write_json(status_path, st)
                except Exception: pass
                _append_system_event(level='error', component='catalog_images', message_user='Catalogusafbeeldingen voorbereiden is mislukt', message_tech=str(e), status='open')
            finally:
                with _CATALOG_IMAGE_SYNC_LOCK:
                    _CATALOG_IMAGE_SYNC_ACTIVE.discard(iid)

        threading.Thread(target=run, name=f'catalog-images-{iid[-8:]}', daemon=True).start()
        return True

    def _api_admin_catalog_taxonomy_override(self):
        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
            iid = str(data.get('importId') or '').strip().lower()
            article = str(data.get('articleNo') or '').strip()
            family = str(data.get('primaryVisualFamily') or '').strip()
            substrate = str(data.get('substrateType') or '').strip().upper()
            path = self._catalog_import_file(iid)
            if path is None or not path.exists():
                return self._send_json({'ok': False, 'error': 'Importpreview niet gevonden.'}, 404)
            stage = strict_json_load(path)
            if stage.get('publishedAt'):
                return self._send_json({'ok': False, 'error': 'Deze import is al gepubliceerd.'}, 409)
            records = list(stage.get('records') or [])
            found = False
            for idx, rec in enumerate(records):
                if isinstance(rec, dict) and str(rec.get('articleNo') or '').strip() == article:
                    records[idx] = _taxonomy_apply_admin_override(rec, family, substrate)
                    found = True
                    break
            if not found:
                return self._send_json({'ok': False, 'error': 'Product niet gevonden in deze import.'}, 404)
            stage['records'] = records
            tax_summary, tax_review = _taxonomy_summary(records)
            stage['taxonomySummary'] = tax_summary
            stage['taxonomyReview'] = tax_review
            _atomic_write_json(path, stage)
            _append_system_event(
                level='info', component='catalog_taxonomy',
                message_user='Catalogusclassificatie beoordeeld',
                message_tech=f'import={iid}; article={article}; family={family}; substrate={substrate}',
                status='resolved',
                details={'actor': self._current_admin_actor() or 'unknown-admin', 'importId': iid, 'articleNo': article},
            )
            return self._send_json({
                'ok': True,
                'importId': iid,
                'reviewSha256': _catalog_review_sha256(stage),
                'taxonomySummary': tax_summary,
                'taxonomyReview': tax_review[:120],
                'canPublishAfterImages': len(stage.get('errors') or []) == 0 and len(records) > 0 and int(tax_summary.get('reviewRequired') or 0) == 0,
                'canPublish': len(stage.get('errors') or []) == 0 and len(records) > 0 and int(tax_summary.get('reviewRequired') or 0) == 0 and len(stage.get('imageTargets') or []) == 0,
            })
        except ValueError as e:
            return self._send_json({'ok': False, 'error': str(e)}, 400)
        except Exception as e:
            _append_system_event(level='error', component='catalog_taxonomy', message_user='Productclassificatie opslaan is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Classificatie kon niet veilig worden opgeslagen.'}, 400)

    def _api_admin_catalog_publish(self):
        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
            iid = str(data.get('importId') or '').strip().lower()
            path = self._catalog_import_file(iid)
            if path is None or not path.exists():
                return self._send_json({'ok': False, 'error': 'Importpreview niet gevonden. Controleer de CSV opnieuw.'}, 404)
            stage = strict_json_load(path)
            if stage.get('publishedAt'):
                return self._send_json({'ok': False, 'error': 'Deze import is al gepubliceerd.'}, 409)
            if time.time() - float(stage.get('createdAtEpoch') or 0) > 24 * 60 * 60:
                return self._send_json({'ok': False, 'error': 'Importpreview is ouder dan 24 uur. Controleer de CSV opnieuw.'}, 409)
            if stage.get('errors'):
                return self._send_json({'ok': False, 'error': 'Import bevat blokkerende fouten en kan niet worden gepubliceerd.'}, 400)
            if not stage.get('records'):
                return self._send_json({'ok': False, 'error': 'Import bevat geen toegestane 18/19/20 mm materialen.'}, 400)
            taxonomy_summary, taxonomy_review = _taxonomy_summary(stage.get('records') or [])
            stage['taxonomySummary'] = taxonomy_summary
            stage['taxonomyReview'] = taxonomy_review
            if int(taxonomy_summary.get('reviewRequired') or 0) != 0:
                _atomic_write_json(path, stage)
                return self._send_json({'ok': False, 'error': f"Classificatie is nog niet compleet: {int(taxonomy_summary.get('reviewRequired') or 0)} product(en) vereisen Admin-controle."}, 409)
            expected_review_sha256 = _catalog_review_sha256(stage)
            supplied_review_sha256 = str(data.get('reviewSha256') or '').strip().lower()
            if not re.fullmatch(r'[a-f0-9]{64}', supplied_review_sha256) or not hmac.compare_digest(supplied_review_sha256, expected_review_sha256):
                return self._send_json({'ok': False, 'error': 'De gecontroleerde catalogus is gewijzigd. Controleer waarschuwingen en CSV opnieuw.'}, 409)
            actor = self._current_admin_actor()
            if not actor:
                return self._send_json({'ok': False, 'error': 'Admin-identiteit ontbreekt; log opnieuw in.'}, 403)
            required_images = list(stage.get('imageTargets') or [])
            if required_images:
                status_path = self._catalog_import_status_file(iid)
                image_status = {}
                try:
                    image_status = strict_json_load(status_path) if status_path and status_path.exists() else {}
                except Exception:
                    image_status = {}
                if str(image_status.get('state') or '') != 'DONE' or int(image_status.get('failed') or 0) != 0 or int(image_status.get('processed') or 0) < len(required_images):
                    return self._send_json({'ok': False, 'error': 'De catalogusafbeeldingen zijn nog niet volledig voorbereid. Wacht tot 100% en probeer daarna opnieuw te publiceren.'}, 409)
            snapshot = self._catalog_snapshot_before_publish(iid)
            promoted_images = self._promote_catalog_stage_images(iid, stage) if required_images else 0
            signoff_path = Path(os.environ.get('CATALOG_SIGNOFF_FILE') or (SYSTEM_DIR / 'catalog_signoff.json')).expanduser()
            previous_library = MATERIAL_LIBRARY_PATH.read_bytes()
            previous_signoff = signoff_path.read_bytes() if signoff_path.is_file() else None
            try:
                merged = self._merge_catalog_stage(stage)
                durable_write_json(signoff_path, {
                    'schemaVersion': 1,
                    'approved': True,
                    'approvedBy': actor,
                    'approvedAt': _utc_now_iso(),
                    'importId': iid,
                    'csvSha256': str(stage.get('csvSha256') or ''),
                    'reviewSha256': expected_review_sha256,
                    'warningCount': len(stage.get('warnings') or []),
                    'excludedCount': len(stage.get('excluded') or []),
                    'materialLibrarySha256': sha256_file(MATERIAL_LIBRARY_PATH),
                }, mode=0o640)
            except Exception as commit_error:
                rollback_errors = []
                try:
                    durable_write_bytes(MATERIAL_LIBRARY_PATH, previous_library, mode=0o640)
                    _invalidate_public_materials_response_cache()
                except Exception as rollback_error:
                    rollback_errors.append(f'library rollback: {rollback_error}')
                try:
                    if previous_signoff is None:
                        signoff_path.unlink(missing_ok=True)
                        fsync_directory(signoff_path.parent)
                    else:
                        durable_write_bytes(signoff_path, previous_signoff, mode=0o640)
                except Exception as rollback_error:
                    rollback_errors.append(f'signoff rollback: {rollback_error}')
                suffix = '; ' + '; '.join(rollback_errors) if rollback_errors else ''
                raise RuntimeError(f'catalog commit rolled back: {commit_error}{suffix}') from commit_error
            # FIX656: pay catalog normalization/cache cost during Admin publication, not on
            # the customer's first Tool A page load.
            try:
                self._public_materials_response_bytes(force_rebuild=True)
            except Exception as cache_err:
                _append_system_event(level='warning', component='catalog_cache', message_user='Publieke cataloguscache wordt later opgebouwd', message_tech=str(cache_err), status='open')
            stage['publishedAt'] = _utc_now_iso()
            stage['snapshot'] = snapshot
            stage['publishedResult'] = {'count': merged['count'], 'removedFromActive': merged.get('removedFromActive', 0)}
            try:
                _atomic_write_json(path, stage)
                _append_system_event(level='info', component='catalog_import', message_user='CSV-catalogus gepubliceerd', message_tech=f"import={iid}; records={len(stage.get('records') or [])}; preparedImages={promoted_images}; snapshot={snapshot}", status='resolved', details={'actor': actor, 'reviewSha256': expected_review_sha256, 'warningCount': len(stage.get('warnings') or [])})
            except Exception as audit_error:
                # The active library + hash-bound signoff are already the atomic commit.
                # A private history/audit write cannot turn that success into an ambiguous
                # client retry that might publish twice.
                print('[CATALOG AUDIT WARNING]', audit_error)
            return self._send_json({
                'ok': True, 'importId': iid, 'published': len(stage.get('records') or []),
                'libraryCount': merged['count'], 'missingFromSource': merged.get('removedFromActive', 0), 'removedFromActive': merged.get('removedFromActive', 0),
                'excludedThickness': len(stage.get('excluded') or []),
                'imageSyncStarted': False, 'imageSyncTotal': 0, 'preparedImages': promoted_images,
                'snapshot': snapshot,
            })
        except Exception as e:
            _append_system_event(level='error', component='catalog_import', message_user='CSV-catalogus publiceren is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Catalogus kon niet veilig worden gepubliceerd.'}, 400)

    def _api_admin_catalog_status(self, parsed):
        try:
            qs = parse_qs(parsed.query)
            iid = str((qs.get('importId') or [''])[0]).strip().lower()
            path = self._catalog_import_status_file(iid)
            if path is None or not path.exists():
                return self._send_json({'ok': True, 'importId': iid, 'state': 'NOT_STARTED', 'total': 0, 'processed': 0, 'success': 0, 'failed': 0})
            data = strict_json_load(path)
            return self._send_json(data)
        except Exception:
            return self._send_json({'ok': False, 'error': 'Importstatus kon niet worden geladen.'}, 400)

    def _api_admin_catalog_retry_images(self):
        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
            iid = str(data.get('importId') or '').strip().lower()
            stage_path = self._catalog_import_file(iid)
            if stage_path is None or not stage_path.exists():
                return self._send_json({'ok': False, 'error': 'Import niet gevonden.'}, 404)
            stage = strict_json_load(stage_path)
            if stage.get('publishedAt'):
                return self._send_json({'ok': False, 'error': 'Deze import is al gepubliceerd. Controleer voor een nieuwe versie opnieuw de CSV.'}, 409)
            targets = list(stage.get('imageTargets') or [])
            status_path = self._catalog_import_status_file(iid)
            if status_path and status_path.exists():
                status_path.unlink(missing_ok=True)
                fsync_directory(status_path.parent)
            stage_media = self._catalog_import_media_dir(iid)
            if stage_media and stage_media.exists():
                shutil.rmtree(stage_media, ignore_errors=True)
                fsync_directory(stage_media.parent)
            started = self._start_catalog_image_sync(iid, targets, staging=True)
            return self._send_json({'ok': started, 'importId': iid, 'imageSyncTotal': len(targets), 'error': None if started else 'Afbeeldingssync draait al.'})
        except Exception:
            return self._send_json({'ok': False, 'error': 'Afbeeldingen opnieuw ophalen is mislukt.'}, 400)

    def _api_admin_system_logs(self):
        try:
            items = _read_system_events(limit=200)
            return self._send_json({"ok": True, "items": items, "count": len(items)})
        except Exception as e:
            _append_system_event(level="error", component="system", message_user="Systeemlog laden is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Systeemlog kon niet worden geladen"}, 500)

    def _api_admin_system_backups(self):
        try:
            items = _list_backups(limit=50)
            return self._send_json({"ok": True, "items": items, "count": len(items)})
        except Exception as e:
            _append_system_event(level="error", component="backup", message_user="Backuplijst laden is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Backuplijst kon niet worden geladen"}, 500)

    def _api_admin_system_backup_download(self, parsed):
        try:
            qs = parse_qs(parsed.query)
            name = str((qs.get('name') or [''])[0]).strip()
            if not name or '/' in name or '\\' in name or '..' in name:
                return self._send_text('Not found', 404)
            fpath = BACKUPS_DIR / name
            if not fpath.exists() or not fpath.is_file() or fpath.suffix.lower() != '.zip':
                return self._send_text('Not found', 404)
            return self._stream_file(
                fpath,
                content_type='application/zip',
                download_name=fpath.name,
                max_bytes=max(1, _env_int('ADMIN_BACKUP_DOWNLOAD_MAX_BYTES', 4 * 1024 * 1024 * 1024)),
            )
        except Exception as e:
            _append_system_event(level="error", component="backup", message_user="Backup downloaden is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Backup downloaden is mislukt"}, 500)

    def _api_admin_system_backup_now(self):
        try:
            actor = self._current_admin_actor() or 'unknown-admin'
            res = _create_system_backup(actor=actor)
            return self._send_json(res, 200)
        except Exception as e:
            _append_system_event(level="error", component="backup", message_user="Backup maken is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Backup maken is mislukt"}, 500)

    def _api_admin_dxf_categories(self):
        return self._send_json({"ok": True, "categories": self._list_dxf_categories()})

    def _api_admin_dxf_list(self, parsed):
        qs = parse_qs(parsed.query)
        cat = self._sanitize_category((qs.get("category") or [""])[0])
        if not cat:
            return self._send_json({"ok": False, "error": "Invalid category"}, 400)
        folder = self._dxf_category_folder(cat)
        files = self._list_dxf_files_in_category(cat)
        if files is None:
            return self._send_json({"ok": False, "error": "Category not found"}, 404)
        return self._send_json({
            "ok": True,
            "category": cat,
            "files": files,
            "count": len(files),
        })

    def _api_admin_dxf_create_category(self):
        data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
        cat = self._sanitize_category(data.get("category", ""))
        if not cat or cat == "(root)":
            return self._send_json({"ok": False, "error": "Invalid category"}, 400)
        folder = self._dxf_category_folder(cat)
        folder.mkdir(parents=True, exist_ok=True)
        fsync_directory(folder.parent)
        rebuild_embedded_dxfs_manifest()
        _sse_broadcast('dxf_changed', {"dxfVersion": get_embedded_dxfs_version()})
        _append_system_event(level='info', component='dxf_library', message_user='DXF-categorie aangemaakt', message_tech=f'category={cat}', status='resolved', details={'actor': self._current_admin_actor() or 'unknown-admin', 'category': cat})
        return self._send_json({"ok": True, "category": cat})

    def _api_admin_dxf_upload(self):
        data = _read_json_body_limited(self, 'ADMIN_DXF_UPLOAD_MAX_BYTES', 15728640) or {}
        cat = self._sanitize_category(data.get("category", ""))
        filename = self._sanitize_filename(data.get("filename", ""))
        b64data = data.get("dataBase64", "")
        if not cat or not filename or not isinstance(b64data, str) or not b64data:
            return self._send_json({"ok": False, "error": "Invalid payload"}, 400)

        folder = self._dxf_category_folder(cat)
        if not folder.exists() or not folder.is_dir():
            return self._send_json({"ok": False, "error": "Category not found"}, 404)

        try:
            raw = base64.b64decode(b64data, validate=True)
        except Exception:
            return self._send_json({"ok": False, "error": "Invalid base64"}, 400)

        if len(raw) > 10 * 1024 * 1024:
            return self._send_json({"ok": False, "error": "File too large"}, 400)

        try:
            text = raw.decode('utf-8', errors='strict')
            pairs = _strict_dxf_parse_pairs(text)
            if len(pairs) > 500_000 or not any(code == 0 and str(value).strip().upper() == 'EOF' for code, value in pairs[-4:]):
                raise SafetyContractError('DXF is incomplete or exceeds the entity budget')
            entities = _strict_dxf_split_entities(_strict_dxf_entities_section(pairs))
            if not entities or len(entities) > 50_000:
                raise SafetyContractError('DXF entity count is outside the allowed range')
            for entity in entities:
                kind = _strict_dxf_entity_type(entity)
                if kind not in {'LINE', 'CIRCLE', 'ARC', 'LWPOLYLINE'}:
                    raise SafetyContractError(f'Unsupported production DXF entity: {kind}')
                if kind == 'LWPOLYLINE' and _strict_dxf_entity_layer(entity).upper() != 'OUTLINE':
                    raise SafetyContractError('Only OUTLINE LWPOLYLINE entities are accepted')
                _strict_dxf_entity_bbox(entity)
            bbox = _strict_dxf_entities_bbox(entities)
            if bbox.width > 10_000 or bbox.height > 10_000:
                raise SafetyContractError('DXF bbox exceeds 10,000 mm')
        except Exception:
            return self._send_json({"ok": False, "error": "DXF structure or machining contract is invalid"}, 400)

        target = folder / filename
        durable_write_bytes(target, raw, mode=0o640)

        rebuild_embedded_dxfs_manifest()
        _sse_broadcast('dxf_changed', {"dxfVersion": get_embedded_dxfs_version(), "category": cat, "filename": filename})
        _append_system_event(level='info', component='dxf_library', message_user='DXF geüpload', message_tech=f'category={cat}; filename={filename}; bytes={len(raw)}', status='resolved', details={'actor': self._current_admin_actor() or 'unknown-admin', 'category': cat, 'filename': filename, 'sha256': sha256_file(target)})
        return self._send_json({"ok": True})

    def _api_admin_dxf_delete(self):
        data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
        cat = self._sanitize_category(data.get("category", ""))
        filename = self._sanitize_filename(data.get("filename", ""))
        if not cat or not filename:
            return self._send_json({"ok": False, "error": "Invalid payload"}, 400)
        folder = self._dxf_category_folder(cat)
        target = folder / filename
        if not target.exists() or not target.is_file():
            return self._send_json({"ok": False, "error": "File not found"}, 404)
        try:
            deleted_hash = sha256_file(target)
            target.unlink()
            fsync_directory(folder)
        except Exception:
            return self._send_json({"ok": False, "error": "Delete failed"}, 500)
        rebuild_embedded_dxfs_manifest()
        _sse_broadcast('dxf_changed', {"dxfVersion": get_embedded_dxfs_version(), "category": cat, "filename": filename})
        _append_system_event(level='info', component='dxf_library', message_user='DXF verwijderd', message_tech=f'category={cat}; filename={filename}', status='resolved', details={'actor': self._current_admin_actor() or 'unknown-admin', 'category': cat, 'filename': filename, 'deletedSha256': deleted_hash})
        return self._send_json({"ok": True})

    def _require_job_access(self, job_id: str, parsed=None, body: Optional[dict]=None, deny_as_json: bool = False) -> bool:
        try:
            job_id = validate_job_id(job_id)
            resolve_identifier_child(JOBS, job_id)
        except SafetyContractError:
            if deny_as_json:
                return self._send_json({'ok': False, 'error': 'Not found'}, 404)
            return self._send_text('Not found', 404)
        try:
            if self._check_admin_auth_silent():
                return True
        except Exception:
            pass
        expected = _read_job_access_token(job_id)
        supplied = _extract_request_token(self, parsed=parsed, body=body)
        if expected and supplied and hmac.compare_digest(str(supplied), str(expected)):
            return True
        if deny_as_json:
            return self._send_json({'ok': False, 'error': 'Forbidden'}, 403)
        return self._send_text('Forbidden', 403)

    def do_HEAD(self):
        parsed = urlparse(self.path)
        if parsed.path in ('/admin', '/admin/', '/admin/index.html'):
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            return
        if parsed.path.startswith('/api/admin/'):
            if not self._require_admin_auth():
                return
            self.send_response(204)
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            return
        return super().do_HEAD()

    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path == '/health/live':
            return self._send_json({'ok': True, 'build': SECURITY_BUILD})
        if parsed.path == '/health/ready':
            payload, code = _readiness_report()
            return self._send_json(payload, code)

        if parsed.path in ('', '/', '/toolA.html'):
            try:
                return self._send_text((ROOT / 'toolA.html').read_text(encoding='utf-8'), 200, 'text/html; charset=utf-8')
            except Exception:
                return self._send_text('Tool A kon niet worden geladen', 500)

        # Public SSE stream used by Tool A to refresh embedded DXF catalog live.
        if parsed.path == '/api/events':
            return _sse_handler(self)

        # FIX622: Serve the Admin shell itself without browser Basic Auth.
        # The admin data/actions under /api/admin/* remain protected and the
        # Admin shell adds Authorization headers from its own login overlay.
        # This avoids iOS Safari offering /admin as a download on 401 responses.
        if parsed.path.startswith('/api/admin/'):
            if not self._require_admin_auth():
                return

        # FIX628: clean admin login rebuild.
        # /admin/ is never Basic-Auth challenged. If no valid session cookie/basic auth is
        # present, serve a standalone login page. After /api/admin/login sets the HttpOnly
        # session cookie, serve the real Admin HTML.
        if parsed.path in ('/admin', '/admin/', '/admin/index.html'):
            if self._check_admin_auth_silent():
                return self._send_text(ADMIN_HTML, 200, 'text/html; charset=utf-8')
            return self._send_text(ADMIN_LOGIN_HTML, 200, 'text/html; charset=utf-8')

        if parsed.path == '/favicon.ico':
            # Avoid noisy 404s in the browser console.
            self.send_response(204)
            self.end_headers()
            return

        if parsed.path == '/.well-known/appspecific/com.chrome.devtools.json':
            # Chrome DevTools sometimes probes this path; respond without crashing.
            self.send_response(204)
            self.end_headers()
            return

        if parsed.path == '/api/draft/load':
            return api_draft_load(self, parsed)

        if parsed.path == '/api/dxf_manifest_meta':
            return api_dxf_manifest_meta(self, parsed)


        if parsed.path == '/api/admin/jobs':
            return api_admin_jobs(self)

        if parsed.path == '/api/admin/metrics':
            return self._send_text(_prometheus_metrics(), 200, 'text/plain; version=0.0.4; charset=utf-8')

        if parsed.path == '/api/admin/requests':
            return api_admin_requests(self)
        if parsed.path == '/api/admin/request_files':
            return api_admin_request_files(self)
        if parsed.path == '/api/admin/request_file':
            return api_admin_request_file(self)
        if parsed.path == '/api/admin/request_download_zip':
            return api_admin_request_download_zip(self)
        if parsed.path == '/api/admin/requests/update':
            return api_admin_requests_update(self)

        if parsed.path == '/api/admin/control_center':
            return api_admin_control_center(self)

        if parsed.path == '/api/admin/dxf/categories':
            return self._api_admin_dxf_categories()

        if parsed.path == '/api/admin/dxf/list':
            return self._api_admin_dxf_list(parsed)

        if parsed.path == '/api/admin/materials/library':
            return self._api_admin_materials_library()
        if parsed.path == '/api/admin/materials/catalog_status':
            return self._api_admin_catalog_status(parsed)

        if parsed.path == '/api/materials/library':
            return self._api_public_materials_library()

        if parsed.path.startswith('/api/materials/image/'):
            parts = parsed.path.split('/')
            if len(parts) == 6:
                return self._api_public_material_image(unquote(parts[4]), unquote(parts[5]))
            return self._send_text('Not found', 404)

        if parsed.path == '/api/admin/system/logs':
            return self._api_admin_system_logs()

        if parsed.path == '/api/admin/system/backups':
            return self._api_admin_system_backups()
        if parsed.path == '/api/admin/system/backup_download':
            return self._api_admin_system_backup_download(parsed)

        if parsed.path == '/api/admin/pricing':
            cfg = _load_pricing_config()
            body, code = _safe_json(cfg, 200)
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return


        # Deprecated: unauthenticated StickerTool v2 direct route. Admin obtains
        # the single sealed output/stickertool.json through the file manifest.
        if parsed.path.startswith('/api/stickertool_v2/'):
            return self._send_text('Deprecated. Use the authenticated Admin output manifest.', 410)

        if parsed.path.startswith('/api/jobs/') and '/download/' in parsed.path:
            # /api/jobs/<jobId>/download/<filename>
            parts = parsed.path.split('/')
            try:
                job_id = parts[3]
                fname = parts[5]
            except Exception:
                return self._send_text('Bad request', 400)
            return api_download(self, job_id, fname, parsed)

        # Subjob file serving (Stickertool v2 contract)
        # /api/jobs/<jobId>/subjobs/<subjobId>/file/<relpath>
        if parsed.path.startswith('/api/jobs/') and '/subjobs/' in parsed.path and '/file/' in parsed.path:
            parts = parsed.path.split('/')
            # ['', 'api', 'jobs', <jobId>, 'subjobs', <subjobId>, 'file', <relpath...>]
            if len(parts) >= 8 and parts[4] == 'subjobs' and parts[6] == 'file':
                job_id = unquote(parts[3])
                subjob_id = unquote(parts[5])
                rel = '/'.join(parts[7:])
                rel = unquote(rel)
                return api_subjob_file(self, job_id, subjob_id, rel, parsed)

        if parsed.path.startswith('/api/jobs/') and '/file/' in parsed.path:
            # /api/jobs/<jobId>/file/<relpath>
            parts = parsed.path.split('/')
            if len(parts) >= 6:
                job_id = unquote(parts[3])
                rel = '/'.join(parts[5:])
                rel = unquote(rel)
                return api_job_file(self, job_id, rel, parsed)


        if parsed.path.startswith('/api/jobs/') and parsed.path.endswith('/status'):
            # /api/jobs/<jobId>/status
            job_id = parsed.path.split('/')[3]
            return self._api_status(job_id, parsed)

        if parsed.path in ('/admin', '/admin/'):
            # serve admin html
            body = ADMIN_HTML.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        return super().do_GET()

    def do_POST(self):
        global _STATE_MUTATION_COUNT
        path = urlparse(self.path).path
        if path == '/api/admin/system/backup_now':
            return self._do_POST_impl()
        with _STATE_MUTATION_CV:
            if _STATE_SNAPSHOT_ACTIVE:
                return self._send_json({'ok': False, 'error': 'Systeemonderhoud actief; probeer het zo opnieuw.'}, 503)
            _STATE_MUTATION_COUNT += 1
        try:
            return self._do_POST_impl()
        finally:
            with _STATE_MUTATION_CV:
                _STATE_MUTATION_COUNT = max(0, _STATE_MUTATION_COUNT - 1)
                _STATE_MUTATION_CV.notify_all()

    def _do_POST_impl(self):
        parsed = urlparse(self.path)
        if parsed.path == '/api/admin/login':
            if _is_production_runtime() and not self._require_admin_write_origin():
                return
            return self._api_admin_login()

        if parsed.path in ('/admin', '/admin/') or parsed.path.startswith('/api/admin/'):
            if not self._require_admin_auth():
                return
            if parsed.path.startswith('/api/admin/') and not self._require_admin_write_origin():
                return

        if parsed.path == '/api/admin/logout':
            return self._api_admin_logout()

        if parsed.path == '/api/admin/materials/catalog_preview':
            return self._api_admin_catalog_preview()
        if parsed.path == '/api/admin/materials/catalog_publish':
            return self._api_admin_catalog_publish()
        if parsed.path == '/api/admin/materials/catalog_taxonomy_override':
            return self._api_admin_catalog_taxonomy_override()
        if parsed.path == '/api/admin/materials/live_taxonomy_family':
            return self._api_admin_live_taxonomy_family()
        if parsed.path == '/api/admin/materials/catalog_retry_images':
            return self._api_admin_catalog_retry_images()

        if parsed.path == '/api/admin/materials/upload':
            return self._api_admin_materials_upload()

        if parsed.path == '/api/admin/materials/save_item':
            return self._api_admin_materials_save_item()

        if parsed.path == '/api/admin/materials/delete_item':
            return self._api_admin_materials_delete_item()

        if parsed.path == '/api/admin/materials/image_upload':
            return self._api_admin_material_image_upload()

        if parsed.path == '/api/admin/materials/image_delete':
            return self._api_admin_material_image_delete()

        if parsed.path == '/api/admin/system/backup_now':
            return self._api_admin_system_backup_now()

        if parsed.path == '/api/admin/dxf/create_category':
            return self._api_admin_dxf_create_category()

        if parsed.path == '/api/admin/dxf/upload':
            return self._api_admin_dxf_upload()

        if parsed.path == '/api/admin/dxf/delete':
            return self._api_admin_dxf_delete()

        if parsed.path == '/api/admin/requests/update':
            return api_admin_requests_update(self)

        if parsed.path in ('/api/submit_config', '/api/cancel', '/api/jobs/cancel', '/api/jobs', '/api/draft/save', '/api/client_log'):
            if _is_production_runtime() and not self._require_same_origin_public_write():
                return

        if parsed.path == '/api/submit_config':
            try:
                return self._api_submit_config()
            except Exception as e:
                _append_system_event(level="error", component="toola", message_user="Aanvraag verwerken is mislukt", message_tech=str(e), status="open")
                return self._send_json({"ok": False, "error": _public_error_message(500)}, 500)
        if parsed.path == '/api/cancel':
            return self._api_cancel_request()

        if parsed.path == '/api/client_log':
            return self._api_client_log(parsed=parsed)
        if parsed.path == '/api/send_to_odoo':
            if not self._require_admin_auth():
                return
            if not self._require_admin_write_origin():
                return
            return self._api_send_to_odoo()
        if parsed.path == '/api/jobs/cancel':
            return self._api_cancel_job(parsed=parsed)
        if parsed.path == '/api/jobs':
            return self._api_create_job()

        if parsed.path == '/api/draft/save':
            return api_draft_save(self)

        if parsed.path == '/api/admin/pricing':
            try:
                data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
                actor = self._current_admin_actor() or 'unknown-admin'
                res = _save_pricing_config(data, actor=actor)
                _append_system_event(level="info", component="pricing", message_user="Prijsinstellingen opgeslagen", message_tech=f"Saved pricing config by {actor}", status="resolved", details={'actor': actor, 'version': res.get('version')})
                body, code = _safe_json(res, 200)
            except Exception as e:
                _append_system_event(level="error", component="pricing", message_user="Prijsinstellingen konden niet worden opgeslagen", message_tech=str(e), status="open")
                body, code = _safe_json({'ok': False, 'error': str(e)}, 400)
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        return self._send_text('Not found', 404)

    def _api_send_to_odoo(self):
        """Store a payload for later Odoo integration.

        This route is admin-only and should never be exposed as a public write
        surface. It persists a bounded JSON payload inside the target job.
        """
        try:
            payload = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
        except Exception:
            return self._send_json({'ok': False, 'error': 'Invalid JSON'}, 400)

        try:
            job_id = validate_job_id(payload.get('jobId'))
            job_root = resolve_identifier_child(JOBS, job_id)
            if not job_root.is_dir() or not _finalization_complete(job_root):
                return self._send_json({'ok': False, 'error': 'Job is niet definitief afgerond'}, 409)
            durable_write_json(job_root / 'output' / 'odoo_payload.json', {
                'schemaVersion': 1,
                'jobId': job_id,
                'state': 'STAGED_NOT_SENT',
                'createdAt': _utc_now_iso(),
                'actor': self._current_admin_actor() or 'unknown-admin',
                'payload': {key: value for key, value in payload.items() if key != 'jobId'},
            })
        except SafetyContractError:
            return self._send_json({'ok': False, 'error': 'Ongeldige jobId'}, 400)
        except Exception as exc:
            _append_system_event(
                level='error', component='odoo',
                message_user='Odoo-export kon niet worden klaargezet',
                message_tech=str(exc), status='open',
            )
            return self._send_json({'ok': False, 'error': 'Failed to store payload'}, 500)

        return self._send_json({'ok': True, 'stored': True, 'jobId': job_id})


    
    def _api_submit_config(self):
        """Finalize a customer submission by linking an already-finalized Tool A job.

        FIX657 invariant: /api/jobs is the only route that performs optimization. Submit
        never nests again. It requires the parent job bearer token, verifies finalization,
        links server-derived subjobs, and is idempotent per parent job.
        """
        _ensure_request_dirs()
        ip = _client_ip(self)
        if not _rate_limit_allow('submit_config', ip, 30, 300):
            return self._send_json({"ok": False, "error": "Te veel verzoeken. Probeer het later opnieuw."}, 429)
        try:
            # Size limit (basic anti-abuse). Default 1 MB.
            payload = _read_json_body_limited(self, 'SUBMIT_MAX_BYTES', 8388608 if _is_production_runtime() else 16777216)
            if not isinstance(payload, dict) or not payload:
                return self._send_json({"ok": False, "error": "Lege aanvraagpayload."}, 400)
        except Exception as e:
            return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

        ok_payload, payload_errors, cleaned_payload = _validate_submit_payload(payload)
        if not ok_payload:
            return self._send_json({"ok": False, "error": "Validatie mislukt"}, 400)
        # Build a new request DTO. Browser quote/pricing/material summaries and unknown
        # nested checkout fields are deliberately not persisted or trusted.
        payload = {
            key: cleaned_payload[key]
            for key in ('jobId', 'parentJobId', 'customer', 'note', 'cart', 'extraPanels')
            if key in cleaned_payload
        }

        # Minimal customer info (optional but useful for Admin index)
        customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
        customer_name = ""
        if isinstance(customer, dict):
            first = str(customer.get("firstName") or "").strip()
            last = str(customer.get("lastName") or "").strip()
            full = " ".join([x for x in [first, last] if x]).strip()
            customer_name = str(customer.get("name") or customer.get("fullName") or full or "").strip()

        # A final submission MUST refer to the already-calculated parent job. Never accept
        # a bare cart here, because that would recreate the historical duplicate optimization.
        parent_job_id = str(payload.get("parentJobId") or payload.get("jobId") or "").strip()
        quote_for_link = payload.get("quote") if isinstance(payload.get("quote"), dict) else {}
        if not parent_job_id and isinstance(quote_for_link, dict):
            parent_job_id = str(quote_for_link.get("parentJobId") or quote_for_link.get("jobId") or "").strip()
        parent_job_id = _safe_id(parent_job_id, 200) if parent_job_id else ''
        if not parent_job_id:
            return self._send_json({"ok": False, "error": "Bereken de prijs opnieuw voordat je de aanvraag verstuurt."}, 409)
        try:
            parent_root = resolve_identifier_child(JOBS, validate_job_id(parent_job_id))
        except SafetyContractError:
            return self._send_json({"ok": False, "error": "Bereken de prijs opnieuw voordat je de aanvraag verstuurt."}, 409)
        if not parent_root.exists() or not _finalization_complete(parent_root):
            return self._send_json({"ok": False, "error": "De berekening is nog niet volledig afgerond. Bereken opnieuw en verstuur daarna de aanvraag."}, 409)
        if _job_cancel_requested(parent_job_id):
            return self._send_json({"ok": False, "error": "Deze berekening is geannuleerd. Bereken opnieuw."}, 409)
        if not self._require_job_access(parent_job_id, deny_as_json=True):
            return

        linked_subjobs = _linked_subjob_ids(parent_job_id)
        if not linked_subjobs or any(not _finalization_complete(resolve_identifier_child(JOBS, subjob_id)) for subjob_id in linked_subjobs):
            return self._send_json({"ok": False, "error": "De productie-output kon niet opnieuw worden geverifieerd. Bereken opnieuw."}, 409)
        candidate_job_ids = [parent_job_id] + [sj for sj in linked_subjobs if sj and sj != parent_job_id]
        authoritative_pricing = _extract_strict_calculation_pricing_summary(candidate_job_ids) or {}
        try:
            authoritative_total = float(authoritative_pricing.get('totalInclVat'))
        except Exception:
            authoritative_total = 0.0
        if authoritative_total <= 0:
            return self._send_json({"ok": False, "error": "De definitieve serverprijs ontbreekt. Bereken de prijs opnieuw voordat je verstuurt."}, 409)

        request_id = _new_request_id()
        with _SUBMISSION_IDEMPOTENCY_LOCK:
            claimed, existing_request_id = _reserve_submission_claim(parent_job_id, request_id)
        if not claimed:
            existing_request_id = _safe_id(str(existing_request_id or '').strip(), 120)
            if existing_request_id and (REQUESTS / existing_request_id / 'status.json').exists():
                return self._send_json(_submission_response_for_existing(existing_request_id, parent_job_id))
            return self._send_json({"ok": False, "error": "Deze aanvraag wordt al verwerkt. Gebruik de bestaande aanvraag in plaats van opnieuw te versturen."}, 409)

        cancel_token = secrets.token_urlsafe(32)
        req_root = resolve_identifier_child(REQUESTS, validate_request_id(request_id), kind='request')
        inp = req_root / "input"
        inp.mkdir(parents=True, exist_ok=True)

        # Store raw payload (so we can process later without ToolA changes)
        _atomic_write_json(inp / "submit_payload.json", payload)

        created = _utc_now_iso()
        status = {
            "schemaVersion": "1.0",
            "requestId": request_id,
            "createdAt": created,
            "updatedAt": created,
            "customer": {
                "name": customer_name,
                "fullName": customer_name,
                "firstName": str(customer.get("firstName") or "").strip() if isinstance(customer, dict) else "",
                "lastName": str(customer.get("lastName") or "").strip() if isinstance(customer, dict) else "",
                "email": str(customer.get("email") or customer.get("mail") or "").strip() if isinstance(customer, dict) else "",
                "phone": str(customer.get("phone") or customer.get("tel") or customer.get("telephone") or "").strip() if isinstance(customer, dict) else "",
                "billingAddress": str(customer.get("billingAddress") or customer.get("invoiceAddress") or customer.get("address") or customer.get("addressLine1") or customer.get("street") or "").strip() if isinstance(customer, dict) else "",
                "shippingAddress": str(customer.get("shippingAddress") or customer.get("deliveryAddress") or customer.get("address1") or "").strip() if isinstance(customer, dict) else "",
                "postalCode": str(customer.get("postalCode") or customer.get("postcode") or "").strip() if isinstance(customer, dict) else "",
                "city": str(customer.get("city") or customer.get("plaats") or "").strip() if isinstance(customer, dict) else "",
                "country": str(customer.get("country") or "").strip() if isinstance(customer, dict) else "",
                "note": str(payload.get("note") or customer.get("note") or "").strip(),
            },
            # Mailbox semantics:
            "publicStatus": "SUBMITTED",
            "publicStatusLabel": "Aanvraag verzonden",
            "needsQuote": True,
            "quoteStatus": "TODO",
            # The optimization already completed under /api/jobs; submit only links it.
            "internalStatus": "DONE",
            "internalStatusLabel": "Gekoppeld aan afgeronde berekening",
            "job": {
                "parentJobId": parent_job_id,
                "subjobs": linked_subjobs
            },
            "source": "submit-config-link",
            "error": None,
            "cancel": None,
            "cancelControl": {
                "cancelToken": cancel_token,
                "issuedAt": created,
            },
        }
        try:
            status['summary'] = _extract_request_summary(payload)
        except Exception:
            pass

        # Linkage is derived from the finalized server job above. Client quote/subjob ids
        # are deliberately not authoritative and cannot change this relation.

        _save_status(request_id, status)

        # No queue item is created: the expensive work is already finalized and immutable.
        # authoritative_pricing/candidate_job_ids were validated before request creation.

        # Push notification (best-effort; never breaks flow).
        # IMPORTANT FIX590: send it after reading the authoritative calculation summary,
        # so ntfy matches Admin/berekening instead of stale frontend payload totals.
        notify_ok = False
        notify_err = ""
        try:
            notify_ok, notify_err = _notify_submitted(request_id, payload, status=status, job_ids=candidate_job_ids, authoritative_pricing=authoritative_pricing)
        except Exception as e:
            notify_ok, notify_err = (False, str(e))

        _sse_broadcast("request_submitted", {"requestId": request_id})
        return self._send_json({"ok": True, "requestId": request_id, "cancelToken": cancel_token, "notificationQueued": bool(notify_ok), "createdAt": created, "pricingSummary": authoritative_pricing})

    def _api_cancel_request(self):
        """Public endpoint: mark a request as cancelled by the customer."""
        _ensure_request_dirs()
        try:
            payload = _read_json_body_limited(self, 'CLIENT_LOG_MAX_BYTES', 65536)
        except Exception:
            return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

        ip = _client_ip(self)
        if not _rate_limit_allow('public_cancel_request', ip, 10, 60):
            return self._send_json({"ok": False, "error": "Too many requests"}, 429)

        request_id = str(payload.get("requestId") or "").strip()
        if not request_id:
            return self._send_json({"ok": False, "error": "Missing requestId"}, 400)
        request_id = _safe_id(request_id, 120)

        supplied_cancel_token = str(payload.get("cancelToken") or payload.get("token") or '').strip()
        if not supplied_cancel_token:
            return self._send_json({"ok": False, "error": "Forbidden"}, 403)

        status = _load_status(request_id)
        if not isinstance(status, dict):
            return self._send_json({"ok": False, "error": "Unknown requestId"}, 404)

        expected_cancel_token = ''
        try:
            cc = status.get('cancelControl') if isinstance(status.get('cancelControl'), dict) else {}
            expected_cancel_token = str(cc.get('cancelToken') or '').strip()
        except Exception:
            expected_cancel_token = ''
        if not expected_cancel_token or not hmac.compare_digest(supplied_cancel_token, expected_cancel_token):
            return self._send_json({"ok": False, "error": "Forbidden"}, 403)

        # Update status
        status["publicStatus"] = "CANCELLED"
        status["publicStatusLabel"] = "Geannuleerd door klant"
        status["needsQuote"] = False
        status["quoteStatus"] = "CANCELLED"
        # If it hasn't started processing, cancel internal as well
        if status.get("internalStatus") in ("QUEUED", "RECEIVED", None, ""):
            status["internalStatus"] = "CANCELLED"
            status["internalStatusLabel"] = "Geannuleerd"
        status["cancel"] = {
            "cancelledAt": _utc_now_iso(),
            "cancelReason": str(payload.get("reason") or "USER_CANCELLED"),
            "context": str(payload.get("context") or "PRICE_OVERLAY"),
        }
        try:
            if isinstance(status.get('cancelControl'), dict):
                status['cancelControl']['cancelledAt'] = status['cancel'].get('cancelledAt')
                status['cancelControl'].pop('cancelToken', None)
        except Exception:
            pass
        _save_status(request_id, status)

        _sse_broadcast("request_cancelled", {"requestId": request_id})
        return self._send_json({"ok": True, "requestId": request_id, "cancelled": True})

    def _api_cancel_job(self, parsed=None):
        """Durably cancel a job and terminate its active optimizer process."""

        ip = _client_ip(self)
        if not _rate_limit_allow('cancel_job', ip, 20, 300):
            return self._send_json({'ok': False, 'error': 'Te veel verzoeken. Probeer het later opnieuw.'}, 429)
        try:
            payload = _read_json_body_limited(self, 'PUBLIC_JSON_MAX_BYTES', 262144)
            job_id = validate_job_id(payload.get('jobId') or payload.get('parentJobId'))
            job_root = resolve_identifier_child(JOBS, job_id)
        except Exception:
            return self._send_json({'ok': False, 'error': 'Ongeldige job.'}, 400)
        if not job_root.is_dir():
            return self._send_json({'ok': False, 'error': 'Job niet gevonden.'}, 404)
        if not self._require_job_access(job_id, parsed=parsed, body=payload, deny_as_json=True):
            return

        _save_job_runtime_state(job_id, 'CANCEL_REQUESTED', reason='user-cancelled')
        with _ACTIVE_JOB_PROCESSES_LOCK:
            processes = list(_ACTIVE_JOB_PROCESSES.get(job_id) or ())
        for process in processes:
            if process.poll() is not None:
                continue
            try:
                process.terminate()
                process.wait(timeout=5)
            except Exception:
                try:
                    process.kill()
                    process.wait(timeout=2)
                except Exception:
                    pass
        _save_job_runtime_state(job_id, 'CANCELLED', reason='user-cancelled')
        with _job_lock:
            meta = _job_meta.get(job_id, {}) or {}
            meta.update({'status': 'cancelled', 'phase': 'cancelled', 'finishedAt': _now_iso()})
            _job_meta[job_id] = meta
        return self._send_json({'ok': True, 'jobId': job_id, 'state': 'cancelled'})


    def _send_text(self, text: str, code: int = 200, ctype: str = 'text/plain; charset=utf-8'):
        if str(ctype).lower().startswith('text/html'):
            text = self._prepare_html(text)
        b = text.encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _send_json(self, obj, code: int = 200):
        try:
            b = strict_json_dumps(obj).encode('utf-8')
        except Exception:
            b = b'{"ok":false,"error":"Response serialization failed"}'
            code = 500
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _stream_file(self, path: Path, *, content_type: str, download_name: str, max_bytes: int) -> None:
        resolved = Path(path)
        stat = resolved.stat()
        if not resolved.is_file() or stat.st_size < 0 or stat.st_size > max_bytes:
            return self._send_text('Download exceeds the configured limit', 413)
        safe_name = _sanitize_filename(download_name, 160) or 'download.bin'
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Disposition', f'attachment; filename="{safe_name}"')
        self.send_header('Content-Length', str(stat.st_size))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        with resolved.open('rb') as source:
            while True:
                chunk = source.read(1024 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)


    def _api_client_log(self, parsed=None):
        """Receive bounded client-side debug logs.

        Security policy:
        - same-origin / loopback only
        - small payloads only
        - rate-limited per client IP
        - best-effort logging with generic failures
        """
        if not self._require_same_origin_public_write():
            return
        ip = _client_ip(self)
        if not _rate_limit_allow('client_log', ip, 120, 300):
            return self._send_json({"ok": False, "error": "Te veel verzoeken. Probeer het later opnieuw."}, 429)
        try:
            payload = _read_json_body_limited(self, 'CLIENT_LOG_MAX_BYTES', 16384)
        except Exception:
            return self._send_json({"ok": False, "error": "Invalid JSON"}, 400)

        try:
            job_id = str(payload.get("jobId") or "").strip()
            if job_id:
                try:
                    job_id = validate_job_id(job_id)
                    job_root = resolve_identifier_child(JOBS, job_id)
                except SafetyContractError:
                    return self._send_json({"ok": False, "error": "Ongeldige job."}, 400)
                supplied = _extract_request_token(self, parsed=parsed, body=payload)
                expected = _read_job_access_token(job_id)
                is_admin = self._check_admin_auth_silent()
                if not is_admin and not (expected and supplied and hmac.compare_digest(expected, supplied)):
                    return self._send_json({"ok": False, "error": "Geen toegang tot deze job."}, 403)
                if not job_root.is_dir():
                    return self._send_json({"ok": False, "error": "Job niet gevonden."}, 404)
            ts = payload.get("ts") or _now_iso()
            rec = {
                "ts": ts,
                "level": str(payload.get("level") or "info")[:24],
                "event": str(payload.get("event") or "")[:120],
                "message": _redact_sensitive_text(payload.get("message") or "", 400),
                "url": _redact_sensitive_text(str(payload.get("url") or "").split("#",1)[0].split("?",1)[0], 300),
                "ua": "",
                "data": _sanitize_log_value(payload.get("data"), max_depth=1, max_items=10),
            }
            if job_id:
                path = job_root / "client_log.jsonl"
            else:
                path = STATE_ROOT / "client_logs" / "general_client_log.jsonl"
            append_jsonl_rotating(path, rec, max_bytes=max(1024, _env_int('CLIENT_LOG_QUOTA_BYTES', 10 * 1024 * 1024)), backups=3)
            return self._send_json({"ok": True})
        except Exception:
            return self._send_json({"ok": False, "error": "Log write failed"}, 500)


    def _estimate_job_complexity(self, payload: dict) -> dict:
        try:
            panels_csv = str((payload or {}).get('panelsCsv') or '')
        except Exception:
            panels_csv = ''
        try:
            dxf_count = len(_expand_dxf_payload(payload or {}))
        except Exception:
            dxf_count = 0
        try:
            panel_rows = max(0, len([ln for ln in panels_csv.splitlines() if ln.strip()]) - 1)
        except Exception:
            panel_rows = 0
        try:
            approx_bytes = len(json.dumps(payload or {}, ensure_ascii=False).encode('utf-8'))
        except Exception:
            approx_bytes = 0
        try:
            area_info = _estimate_payload_area_lower_bound(payload)
        except Exception:
            area_info = {'maxAreaLowerBound': 0}
        return {
            'panelRows': panel_rows,
            'dxfCount': dxf_count,
            'approxBytes': approx_bytes,
            'maxAreaLowerBound': int((area_info or {}).get('maxAreaLowerBound') or 0),
        }

    def _start_async_job_create(self, payload: dict, master_job_id: str, public_access_token: str = '', acquired_ip: str = '') -> None:
        def _runner():
            try:
                create_result = _create_job_from_payload(payload, master_job_id=master_job_id, public_access_token=public_access_token)
                if _job_cancel_requested(master_job_id):
                    raise JobCancelledError('Job was cancelled before publication')
                _save_job_runtime_state(master_job_id, 'DONE')
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    meta['status'] = 'done'
                    meta['progressPct'] = 100
                    meta['progressMessage'] = 'Optimalisatie afgerond'
                    meta['phase'] = 'done'
                    meta['finishedAt'] = _now_iso()
                    _job_meta[master_job_id] = meta
            except Exception as e:
                cancelled = isinstance(e, JobCancelledError) or _job_cancel_requested(master_job_id)
                try:
                    jr = resolve_identifier_child(JOBS, master_job_id)
                    (jr / 'output').mkdir(parents=True, exist_ok=True)
                    durable_write_text(jr / 'output' / 'create_job_error.txt', str(e))
                except Exception:
                    pass
                _save_job_runtime_state(
                    master_job_id,
                    'CANCELLED' if cancelled else 'FAILED',
                    reason='user-cancelled' if cancelled else str(e)[:500],
                    retryable=not cancelled,
                )
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    meta['status'] = 'cancelled' if cancelled else 'error'
                    meta['finishedAt'] = _now_iso()
                    if not cancelled:
                        meta['error'] = str(e)
                    _job_meta[master_job_id] = meta
            finally:
                if acquired_ip:
                    try:
                        _release_public_job_slot(acquired_ip)
                    except Exception:
                        pass
        t = threading.Thread(target=_runner, daemon=True, name=f'job-create-{master_job_id}')
        t.start()


    def _write_api_jobs_crashlog(self, label: str, payload: dict | None = None, err: Exception | None = None, extra: dict | None = None) -> None:
        try:
            log_dir = JOBS / '_crash_logs'
            log_dir.mkdir(parents=True, exist_ok=True)
            ts = time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6]
            rec = {
                'ts': _now_iso(),
                'label': label,
                'error': _redact_sensitive_text(str(err), 600) if err else '',
                'traceback': _redact_sensitive_text(traceback.format_exc(), 4000) if err else '',
                'extra': extra or {},
            }
            if isinstance(payload, dict):
                try:
                    rec['complexity'] = self._estimate_job_complexity(payload)
                except Exception:
                    pass
                try:
                    rec['payload_keys'] = sorted(list(payload.keys()))
                except Exception:
                    pass
            _atomic_write_json(log_dir / f'api_jobs_{ts}.json', rec)
        except Exception:
            pass

    def _api_create_job(self):
        """Create a Tool B job using the proven synchronous path.

        Public route, but security-hardened with payload limits and basic abuse
        throttling because job creation is disk- and CPU-expensive.
        """
        ip = _client_ip(self)
        if not _rate_limit_allow('api_jobs', ip, 12 if _is_production_runtime() else 20, 300):
            try:
                _append_system_event(level="warning", component="jobs", message_user="Publieke jobroute rate-limited", message_tech=f"api_jobs rate limit for {ip}", status="open")
            except Exception:
                pass
            return self._send_json({"ok": False, "error": _public_error_message(429)}, 429)

        acquired = False
        slot_handed_off = False
        try:
            acquired, slot_reason = _try_acquire_public_job_slot(ip)
            if not acquired:
                try:
                    _append_system_event(level="warning", component="jobs", message_user="Publieke jobroute is te druk", message_tech=f"api_jobs concurrency block ({slot_reason}) for {ip}", status="open")
                except Exception:
                    pass
                return self._send_json({"ok": False, "error": "Er wordt nu al een aanvraag geoptimaliseerd. Wacht heel even en probeer het daarna opnieuw.", "busy": True, "maxConcurrentOptimizations": 1}, 429)

            max_bytes = _env_int('PUBLIC_JSON_MAX_BYTES', 16777216 if _is_production_runtime() else 134217728)
            try:
                content_length = int(self.headers.get('Content-Length', '0') or '0')
            except Exception:
                content_length = 0
            if content_length and content_length > max_bytes:
                actual_mb = float(content_length) / 1024.0 / 1024.0
                limit_mb = float(max_bytes) / 1024.0 / 1024.0
                try:
                    _append_client_log('server', 'api_jobs_payload_block', 'Public job payload too large', {'contentLengthMb': round(actual_mb, 1), 'limitMb': round(limit_mb, 1)})
                except Exception:
                    pass
                return self._send_json({"ok": False, "error": "De aanvraag kon niet volledig worden ontvangen. Herlaad de pagina en probeer opnieuw."}, 413)

            try:
                payload = _read_json_body_limited(self, 'PUBLIC_JSON_MAX_BYTES', max_bytes)
            except Exception as e:
                err_text = str(e)
                if err_text.startswith('JOB_PAYLOAD_TOO_LARGE::'):
                    return self._send_json({"ok": False, "error": "De aanvraag kon niet volledig worden ontvangen. Herlaad de pagina en probeer opnieuw."}, 413)
                raise
            if not isinstance(payload, dict) or not payload:
                return self._send_json({"ok": False, "error": "Lege jobpayload."}, 400)

            # Convert browser intent into a strict, server-owned production DTO before
            # any persistent job/request path is created.
            payload = self._canonicalize_public_job_payload(payload)

            try:
                top_level_keys = set(payload.keys())
                if top_level_keys and len(top_level_keys) > 64:
                    return self._send_json({"ok": False, "error": "Ongeldige aanvraag."}, 400)
            except Exception:
                pass
            qty_limit = _env_int('PUBLIC_JOB_TOTAL_QTY_LIMIT', 250)
            area_lb_limit = _env_int('PUBLIC_JOB_MAX_AREA_LB', 250)
            total_qty = _enforce_job_total_qty_limit(payload, qty_limit)
            live_cfg = _load_pricing_config()
            live_pricing = (live_cfg or {}).get('pricing') if isinstance(live_cfg, dict) else None
            if not isinstance(live_pricing, dict):
                live_pricing = strict_json_load(PRICING_SEED_PATH)
            authoritative_pricing = _ensure_pricing_materials(
                strict_json_loads(strict_json_dumps(live_pricing)),
                payload['panelsCsv'],
            )
            area_info = _estimate_payload_area_lower_bound({
                'panelsCsv': payload['panelsCsv'],
                'pricing': authoritative_pricing,
            })
            max_area_lb = int((area_info or {}).get('maxAreaLowerBound') or 0)
            try:
                _append_client_log('server', 'api_jobs_preflight', 'Public job guards passed', {'totalQty': int(total_qty), 'limitQty': int(qty_limit), 'maxAreaLowerBound': int(max_area_lb), 'maxAreaLowerBoundLimit': int(area_lb_limit)})
            except Exception:
                pass
            if max_area_lb > int(area_lb_limit):
                return self._send_json({"ok": False, "error": f"Deze configuratie is te groot voor één aanvraag. De geschatte minimale plaatbehoefte is minstens {max_area_lb} platen. Splits de bestelling op in meerdere aanvragen."}, 413)
            family_estimate = _estimate_preflight_job_family_bytes(payload)
            if int(family_estimate.get('projectedTotalBytes') or 0) > int(JOB_OUTPUT_MAX_BYTES):
                return self._send_json({
                    'ok': False,
                    'error': _job_output_limit_message(
                        int(family_estimate.get('projectedTotalBytes') or 0),
                        int(JOB_OUTPUT_MAX_BYTES),
                    ),
                }, 413)
            _enforce_state_capacity(
                int(family_estimate.get('projectedTotalBytes') or 0),
                projected_inodes=max(
                    256,
                    int(family_estimate.get('totalQty') or 0) * 8
                    + int(family_estimate.get('dxfCount') or 0) * 4,
                ),
            )

            created_at = _now_iso()
            master_job_id = time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6]
            job_root = JOBS / master_job_id
            (job_root / 'input').mkdir(parents=True, exist_ok=True)
            (job_root / 'output').mkdir(parents=True, exist_ok=True)
            access_token = _new_public_access_token()
            _atomic_write_json(job_root / '.public_access.json', {
                'token': access_token,
                'jobId': master_job_id,
                'updatedAt': _utc_now_iso(),
            })
            _save_job_runtime_state(master_job_id, 'ACCEPTED')
            complexity = self._estimate_job_complexity(payload)
            with _job_lock:
                _job_meta[master_job_id] = {
                    'status': 'processing',
                    'createdAt': created_at,
                    'acceptedAt': created_at,
                    'progressPct': 1,
                    'progressMessage': 'Aanvraag gestart',
                    'phase': 'accepted',
                    'complexity': complexity,
                }
            self._start_async_job_create(payload, master_job_id, access_token, ip)
            slot_handed_off = True
            return self._send_json({
                'ok': True,
                'jobId': master_job_id,
                'parentJobId': master_job_id,
                'subjobs': [],
                'accessToken': access_token,
                'meta': {
                    'status': 'processing',
                    'progressPct': 1,
                    'progressMessage': 'Aanvraag gestart',
                }
            }, 202)
        except Exception as e:
            err_text = str(e)
            if err_text.startswith('JOB_PAYLOAD_TOO_LARGE::'):
                try:
                    _, actual_s, limit_s = err_text.split('::', 2)
                    actual_mb = float(actual_s) / 1024.0 / 1024.0
                    limit_mb = float(limit_s) / 1024.0 / 1024.0
                    return self._send_json({
                        "ok": False,
                        "error": f"Deze aanvraag is te groot om veilig te verwerken ({actual_mb:.1f} MB). Het maximum is {limit_mb:.0f} MB. Splits de job op in meerdere delen en probeer het opnieuw."
                    }, 413)
                except Exception:
                    return self._send_json({
                        "ok": False,
                        "error": "Deze aanvraag is te groot om veilig te verwerken. Splits de job op in meerdere delen en probeer het opnieuw."
                    }, 413)
            if err_text.startswith('JOB_TOTAL_QTY_TOO_LARGE::'):
                try:
                    _, actual_s, limit_s = err_text.split('::', 2)
                    return self._send_json({
                        "ok": False,
                        "error": f"Deze aanvraag bevat te veel panelen om veilig te verwerken ({int(actual_s)}). Het maximum is {int(limit_s)} panelen. Splits de job op in meerdere delen."
                    }, 413)
                except Exception:
                    return self._send_json({
                        "ok": False,
                        "error": "Deze aanvraag bevat te veel panelen om veilig te verwerken. Splits de job op in meerdere delen."
                    }, 413)
            try:
                self._write_api_jobs_crashlog('api_create_job_exception', payload if 'payload' in locals() and isinstance(payload, dict) else None, e, {
                    'path': '/api/jobs',
                    'contentLength': str(self.headers.get('Content-Length') or ''),
                })
            except Exception:
                pass
            safe_msg = str(e).strip()
            if safe_msg and not safe_msg.startswith(('JOB_PAYLOAD_TOO_LARGE::', 'JOB_TOTAL_QTY_TOO_LARGE::')) and len(safe_msg) <= 240 and not any(ch in safe_msg for ch in ['Traceback', 'File "', '\n']):
                safe_obj = self._sanitize_public_material_response({"ok": False, "error": safe_msg})
                return self._send_json(safe_obj, 400)
            return self._send_json({"ok": False, "error": "Jobaanmaak mislukt"}, 400)
        finally:
            if acquired and not slot_handed_off:
                _release_public_job_slot(ip)


    def _api_status(self, job_id: str, parsed=None):
        """Return lightweight job status + quote for Tool A polling.

        Old builds relied on in-memory _job_meta, but that breaks after restarts and
        for parent/subjob fan-out runs. We infer status from the file-based outputs,
        keeping the system deterministic and resilient.
        """
        try:
            job_id = validate_job_id(job_id)
            job_root = resolve_identifier_child(JOBS, job_id)
        except SafetyContractError:
            return self._send_json({'meta': {'status': 'unknown'}, 'quote': None}, 404)
        if not self._require_job_access(job_id, parsed=parsed, deny_as_json=True):
            return
        if not job_root.exists():
            return self._send_json({'meta': {'status': 'unknown'}, 'quote': None})
        runtime_state = str(_load_job_runtime_state(job_id).get('state') or '').lower()
        family_finalized = _finalization_complete(job_root)
        if runtime_state in {'cancel_requested', 'cancelled'}:
            return self._send_json({
                'meta': {'status': 'cancelled', 'progressPct': 0, 'progressMessage': 'Berekening geannuleerd'},
                'quote': None,
                'pricingSummary': {},
            })
        if runtime_state == 'failed':
            return self._send_json({
                'meta': {'status': 'error', 'progressPct': 0, 'progressMessage': 'Berekening mislukt'},
                'quote': None,
                'pricingSummary': {},
            })
        if runtime_state == 'done' and not family_finalized:
            return self._send_json({
                'meta': {'status': 'error', 'progressPct': 0, 'progressMessage': 'Integriteitscontrole van productie-output is mislukt'},
                'quote': None,
                'pricingSummary': {},
            }, 409)

        def _load_quote(path: Path):
            if not path.exists():
                return None
            try:
                q = strict_json_load(path)
            except Exception:
                return None
            # ensure sell pricing shape compatibility where possible
            try:
                if isinstance(q, dict) and (q.get('sellPricing') is None):
                    q = _apply_sell_pricing_to_quote(q)
            except Exception:
                pass
            return q

        def _quote_grand_total(q: dict) -> float:
            """Best-effort extract of grand total from various quote formats."""
            if not isinstance(q, dict):
                return 0.0
            # Most authoritative: quote.json format uses totals.grandTotal
            cand = None
            try:
                cand = (q.get('totals') or {}).get('grandTotal')
            except Exception:
                cand = None
            if cand is None:
                # legacy / status-summary formats
                for k in ('grandTotal', 'total_incl_vat', 'totalInclVat', 'total'):
                    if q.get(k) is not None:
                        cand = q.get(k)
                        break
            try:
                return float(cand or 0.0)
            except Exception:
                return 0.0

        def _quote_sheet_count(q: dict) -> int:
            """Best-effort extract of sheet count."""
            if not isinstance(q, dict):
                return 0
            # Prefer explicit if present
            for k in ('sheetCount', 'sheetsCount'):
                if q.get(k) is not None:
                    try:
                        return int(q.get(k) or 0)
                    except Exception:
                        pass
            # quote.json format: sum materials[*].sheetCount if available
            try:
                mats = q.get('materials')
                if isinstance(mats, list):
                    s = 0
                    for m in mats:
                        if isinstance(m, dict) and m.get('sheetCount') is not None:
                            try:
                                s += int(m.get('sheetCount') or 0)
                            except Exception:
                                pass
                    if s:
                        return s
            except Exception:
                pass
            # fallback: totals.sheetCount
            try:
                return int((q.get('totals') or {}).get('sheetCount') or 0)
            except Exception:
                return 0


        inferred_status = 'unknown'
        quote = None

        # Parent job? (fan-out into __mat_ subjobs)
        subjob_dirs = [p for p in sorted(JOBS.glob(f"{job_id}__mat_*")) if p.is_dir()]
        if subjob_dirs:
            # FIX654: new jobs use an explicit finalization contract. Legacy jobs retain
            # the old core-output fallback, but a missing best-effort summary can no longer
            # silently make a new job spin forever.
            all_done = True
            any_finalization = False
            finalization_error = ''
            sub_quotes = []
            for sp in subjob_dirs:
                out = sp / 'output'
                fin = out / 'finalization.json'
                if fin.exists():
                    any_finalization = True
                    try:
                        fd = strict_json_load(fin)
                        fstate = str(fd.get('state') or '').upper()
                        if fstate == 'ERROR':
                            finalization_error = str((fd.get('errors') or [fd.get('error') or 'Outputfinalisatie mislukt'])[0])
                            all_done = False
                        elif fstate != 'COMPLETE':
                            all_done = False
                    except Exception:
                        all_done = False
                else:
                    if not (out / 'placements.json').exists() or not (out / 'report.json').exists():
                        all_done = False
                    if not ((sp / 'calculation_summary.txt').exists() or (out / 'calculation_summary.txt').exists() or (sp / 'input' / 'calculation_summary.txt').exists()):
                        all_done = False
                q = _load_quote(out / 'quote.json') if _finalization_complete(sp) else None
                if isinstance(q, dict):
                    sub_quotes.append((sp.name, q))
            if finalization_error:
                inferred_status = 'error'
            else:
                inferred_status = 'done' if all_done else 'processing'

            # Aggregate quote (best-effort) if parent quote is missing
            parent_quote = _load_quote((job_root / 'output' / 'quote.json'))
            if isinstance(parent_quote, dict):
                quote = parent_quote
            elif sub_quotes:
                total = 0.0
                sheet_count = 0
                currency = None
                for sid, q in sub_quotes:
                    if currency is None:
                        currency = q.get('currency')
                    try:
                        total += _quote_grand_total(q)
                    except Exception:
                        pass
                    try:
                        sheet_count += _quote_sheet_count(q)
                    except Exception:
                        pass
                # Provide BOTH the modern quote.json-like shape (totals.grandTotal) and
                # legacy summary fields (grandTotal/sheetCount) so Tool A can accept all formats.
                quote = {
                    'currency': currency or 'EUR',
                    'totals': {
                        'grandTotal': round(total, 2),
                        'sheetCount': sheet_count,
                    },
                    'grandTotal': round(total, 2),
                    'sheetCount': sheet_count,
                    'perSubjob': [
                        {
                            'subjobId': sid,
                            'currency': (q.get('currency') if isinstance(q, dict) else None) or (currency or 'EUR'),
                            'totals': {
                                'grandTotal': _quote_grand_total(q),
                                'sheetCount': _quote_sheet_count(q),
                            },
                            'grandTotal': _quote_grand_total(q),
                            'sheetCount': _quote_sheet_count(q),
                        }
                        for sid, q in sub_quotes
                    ],
                }
        else:
            out = job_root / 'output'
            quote = _load_quote(out / 'quote.json')
            has_calc = (job_root / 'calculation_summary.txt').exists() or (out / 'calculation_summary.txt').exists()
            if (((out / 'report.json').exists() or (out / 'placements.json').exists() or isinstance(quote, dict)) and has_calc):
                inferred_status = 'done'
            elif out.exists() or isinstance(quote, dict):
                inferred_status = 'processing'

        def _read_progress(root: Path):
            try:
                pp = root / 'output' / 'progress.json'
                if pp.exists():
                    pdata = strict_json_load(pp)
                    pct = pdata.get('percent')
                    msg = str(pdata.get('message') or pdata.get('phase') or '').strip()
                    if pct is not None:
                        try:
                            pct = max(0, min(100, int(round(float(pct)))))
                            return {'pct': pct, 'message': msg}
                        except Exception:
                            pass
                rp = root / 'output' / 'report.json'
                if not rp.exists():
                    return None
                data = strict_json_load(rp)
                prog = data.get('progress') if isinstance(data.get('progress'), dict) else {}
                pct = prog.get('percent') if isinstance(prog, dict) else None
                msg = str(prog.get('message') or prog.get('phase') or '').strip() if isinstance(prog, dict) else ''
                if pct is None and data.get('ok') is True:
                    pct = 100
                if pct is None:
                    return None
                try:
                    pct = max(0, min(100, int(round(float(pct)))))
                except Exception:
                    return None
                return {'pct': pct, 'message': msg}
            except Exception:
                return None

        with _job_lock:
            meta = _job_meta.get(job_id, {}) or {}
        meta2 = dict(meta)
        if inferred_status != 'unknown':
            meta2['status'] = inferred_status
        else:
            meta2.setdefault('status', 'unknown')

        progress_info = None
        meta_pct = int(meta2.get('progressPct') or 0)
        meta_msg = str(meta2.get('progressMessage') or '').strip()

        # Prefer live subjob progress while a job is still processing. The coarse master/meta
        # progress is only a floor/fallback; otherwise the UI can jump early to a stale 84/86/98.
        if subjob_dirs and meta2.get('status') not in ('done', 'ready', 'ok'):
            total = len(subjob_dirs)
            done_count = 0
            current_fraction = 0.0
            current_message = ''
            for sj in subjob_dirs:
                sj_out = sj / 'output'
                sj_quote = _load_quote(sj_out / 'quote.json')
                has_calc_summary = ((sj / 'calculation_summary.txt').exists()) or ((sj_out / 'calculation_summary.txt').exists()) or ((sj / 'input' / 'calculation_summary.txt').exists())
                fin_path = sj_out / 'finalization.json'
                if fin_path.exists():
                    sj_done = _finalization_complete(sj)
                else:
                    # Legacy jobs created before FIX654 have no finalization marker.
                    sj_done = (((sj_out / 'report.json').exists() or (sj_out / 'placements.json').exists() or isinstance(sj_quote, dict)) and has_calc_summary)
                if sj_done:
                    done_count += 1
                    continue
                prog = _read_progress(sj)
                if prog and prog.get('pct', 0) > 0:
                    frac = max(0.0, min(0.99, prog['pct'] / 100.0))
                    if frac >= current_fraction:
                        current_fraction = frac
                        current_message = prog.get('message') or current_message
            if total > 0:
                if done_count >= total:
                    # all subjobs finished; keep the master meta progress as the source for the true final server phase
                    if meta_pct > 0:
                        progress_info = {'pct': meta_pct, 'message': meta_msg}
                    else:
                        progress_info = {'pct': 99, 'message': meta_msg or 'Resultaten verwerken…'}
                else:
                    pct = int(round(((done_count + current_fraction) / float(total)) * 96.0))
                    pct = max(pct, min(96, meta_pct))
                    if pct > 0:
                        progress_info = {'pct': pct, 'message': current_message or meta_msg}
        elif meta_pct > 0:
            progress_info = {'pct': meta_pct, 'message': meta_msg}
        else:
            prog = _read_progress(job_root)
            if prog:
                progress_info = prog

        if progress_info:
            pct_val = int(progress_info.get('pct') or 0)
            if meta2.get('status') not in ('done', 'ready', 'ok'):
                pct_val = min(99, pct_val)
            meta2['progressPct'] = pct_val
            if progress_info.get('message'):
                meta2['progressMessage'] = progress_info.get('message')
            elif pct_val >= 95 and meta2.get('status') not in ('done', 'ready', 'ok'):
                meta2['progressMessage'] = 'Resultaten verwerken…'
        elif meta2.get('status') in ('done', 'ready', 'ok'):
            meta2['progressPct'] = 100
            meta2['progressMessage'] = meta2.get('progressMessage') or 'Optimalisatie afgerond'

        pricing_summary = {}
        try:
            candidate_job_ids = []
            for jid in [job_id] + [p.name for p in subjob_dirs]:
                if jid and jid not in candidate_job_ids:
                    candidate_job_ids.append(jid)
            # STRICT for Tool A status: only return a visible price once a finished
            # calculation summary exists. Never generate one on the fly from quote or
            # request payload fallbacks.
            pricing_summary = _extract_strict_calculation_pricing_summary(candidate_job_ids) if candidate_job_ids and family_finalized else {}
        except Exception:
            pricing_summary = {}

        if inferred_status == 'done' and not family_finalized:
            if runtime_state in {'accepted', 'preparing', 'processing', 'finalizing'}:
                meta2['status'] = 'processing'
                meta2['progressPct'] = min(99, max(1, int(meta2.get('progressPct') or 99)))
                meta2['progressMessage'] = str(meta2.get('progressMessage') or 'Resultaten verzegelen…')
            else:
                public_meta = {'status': 'error', 'progressPct': 0, 'progressMessage': 'Integriteitscontrole van productie-output is mislukt'}
                return self._send_json({'meta': public_meta, 'quote': None, 'pricingSummary': {}}, 409)
        public_quote = self._public_quote_view(quote) if quote is not None and family_finalized else None
        public_pricing_summary = self._sanitize_public_material_response(pricing_summary or {})
        public_meta = self._sanitize_public_material_response(meta2 or {})
        return self._send_json({'meta': public_meta, 'quote': public_quote, 'pricingSummary': public_pricing_summary})

def api_draft_save(self):
    """Compatibility no-op.

    Tool A no longer stores shared server-side drafts. The historical endpoint was
    unauthenticated and could expose or overwrite data. Empty reset writes remain
    accepted so the current reset flow stays compatible.
    """
    try:
        data = _read_json_body_limited(self, 'PUBLIC_DRAFT_MAX_BYTES', 16384) or {}
        draft = data.get('draft')
        if draft not in (None, {}):
            return self._send_json({'ok': False, 'error': 'Serverconcepten worden niet meer ondersteund'}, code=410)
        return self._send_json({'ok': True, 'disabled': True})
    except Exception:
        return self._send_json({'ok': False, 'error': 'Ongeldig conceptverzoek'}, code=400)


def api_dxf_manifest_meta(handler, parsed):
    """Return current embedded DXF catalog version.

    IMPORTANT: must not be cached by browsers/proxies, because Tool A relies on this
    to detect live updates when SSE is flaky or blocked.
    """
    try:
        version = get_embedded_dxfs_version()
        body = json.dumps({"version": version}).encode("utf-8")
        handler.send_response(200)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate")
        handler.send_header("Pragma", "no-cache")
        handler.send_header("Expires", "0")
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)
    except Exception:
        handler._send_json({"version": None, "error": "Manifest ophalen is mislukt"}, code=500)


def api_draft_load(self, parsed):
    # Shared server-side drafts are disabled. Returning an empty result preserves
    # compatibility without reading historical files containing internal data.
    return self._send_json({'ok': True, 'draft': None, 'disabled': True})



def _edge_meters_by_decor(job_dir: Path):
    """Read input/panels.csv and sum required edge band meters per DecorName.

    Reporting-only helper for /admin. Never affects pricing or nesting.
    """
    try:
        import csv
        panels_path = job_dir / 'input' / 'panels.csv'
        if not panels_path.exists():
            return {}
        out = {}
        with panels_path.open('r', encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            for r in reader:
                try:
                    qty = int(float((r.get('Qty') or '1').strip() or '1'))
                except Exception:
                    qty = 1
                try:
                    L = float((r.get('LengthMm') or '0').strip() or '0')
                    W = float((r.get('WidthMm') or '0').strip() or '0')
                except Exception:
                    L = 0.0; W = 0.0

                decor = (r.get('DecorName') or r.get('MaterialCode') or '').strip() or '—'

                def _code(name: str) -> int:
                    try:
                        return int(float((r.get(name) or '0').strip() or '0'))
                    except Exception:
                        return 0

                # Same meter model as Tool B quote: H* uses LengthMm, W* uses WidthMm
                meters = 0.0
                if _code('H1') != 0: meters += (L/1000.0) * qty
                if _code('H2') != 0: meters += (L/1000.0) * qty
                if _code('W1') != 0: meters += (W/1000.0) * qty
                if _code('W2') != 0: meters += (W/1000.0) * qty

                if meters <= 0:
                    continue
                out[decor] = out.get(decor, 0.0) + meters
        # round for display
        return {k: round(v, 3) for k, v in sorted(out.items(), key=lambda kv: kv[0].lower())}
    except Exception:
        return {}
def api_admin_jobs(self):
    jobs = []
    for p in sorted(JOBS.glob('*')):
        if not p.is_dir():
            continue
        job_id = p.name
        with _job_lock:
            meta = _job_meta.get(job_id, {})
        output_dir = p / 'output'
        sealed = _sealed_output_artifacts(p)
        # Read-only endpoint: production exports are created and sealed by the
        # finalizer. Admin browsing must never mutate a completed job.
        sheets_dir = output_dir / 'sheets'
        sheets = []
        if sealed:
            # Tool B may output sheet files with .dxf/.DXF or (on some systems) without an extension (e.g. 'Sheet_001').
            # Also allow nested folders under sheets/.
            sheet_files = [
                fp for rel, fp in sorted(sealed.items())
                if rel.startswith('output/sheets/') and fp.suffix.lower() == '.dxf'
            ]
            # Return relative names (under output/sheets) so download endpoint works.
            rels = []
            for f in sheet_files:
                try:
                    rels.append(str(f.relative_to(sheets_dir)).replace('\\','/'))
                except Exception:
                    rels.append(f.name)
            seen=set(); sheets=[x for x in rels if (x.lower() not in seen and not seen.add(x.lower()))]


        # --- Zaagplaten ---
        # Return both the real filename (for download) and a human-friendly label for display.
        # Some runs use short filenames (e.g. "105574_S01.dxf") as a fallback for Windows path limits.
        # The workshop still needs to SEE customer + material in Admin.
        zaag_dir = output_dir / 'DXF_Zaagplaten'
        zaag_files = []
        if sealed:
            zaag_files = [
                fp.name for rel, fp in sorted(sealed.items())
                if rel.startswith('output/DXF_Zaagplaten/') and fp.suffix.lower() == '.dxf'
            ]
            seen=set(); zaag_files=[x for x in zaag_files if (x.lower() not in seen and not seen.add(x.lower()))]
            # De-duplicate per sheet index (S01, S02, ...) in case both a short and a long filename exist.
            # Preference: short physical filename like "105574_S01.dxf", otherwise the shortest name.
            try:
                import re as _re
                def _sheet_key(fn: str):
                    mm = _re.search(r'(S\d{2})', fn or '')
                    return mm.group(1).upper() if mm else (fn or '').lower()

                def _score(fn: str):
                    low = (fn or '').lower()
                    if _re.match(r'^\d+_s\d{2}\.dxf$', low):
                        return (0, len(fn))
                    return (1, len(fn))

                chosen = {}
                for fn in zaag_files:
                    k = _sheet_key(fn)
                    if k not in chosen or _score(fn) < _score(chosen[k]):
                        chosen[k] = fn
                zaag_files = [chosen[k] for k in sorted(chosen.keys())]
            except Exception:
                pass


        # Build label context from input.
        customer_name = ""
        try:
            job_json_path = (p / 'input' / 'job.json')
            if job_json_path.exists():
                jj = strict_json_load(job_json_path)
                cust = (jj.get('customer') or {})
                if isinstance(cust, dict):
                    fn = str(cust.get('first_name') or cust.get('firstName') or '').strip()
                    ln = str(cust.get('last_name')  or cust.get('lastName')  or '').strip()
                    customer_name = " ".join([fn, ln]).strip()
        except Exception:
            customer_name = ""

        decor_name = ""
        mat_code = ""
        try:
            panels_path = (p / 'input' / 'panels.csv')
            if panels_path.exists():
                rows = _parse_panels_csv(panels_path.read_text(encoding='utf-8'))
                if rows:
                    r0 = rows[0]
                    decor_name = (r0.get('DecorName') or r0.get('decorName') or '').strip()
                    mat_code = (r0.get('MaterialCode') or r0.get('materialCode') or '').strip()
        except Exception:
            decor_name = ""; mat_code = ""

        def _label_for_file(fname: str) -> str:
            # If already contains customer/material, keep as-is.
            low = (fname or '').lower()
            if '__' in low or (customer_name and customer_name.lower().replace(' ','_') in low):
                return fname
            # Build friendly label for short fallback names like 105574_S01.dxf / S01.dxf
            base = fname
            try:
                import re
                m = re.search(r'(S\d{2})', fname)
                sfx = m.group(1) if m else ''
                parts = []
                if customer_name:
                    parts.append(_sanitize_filename(customer_name, 30))
                if decor_name:
                    parts.append(_sanitize_filename(decor_name, 40))
                if mat_code:
                    parts.append(_sanitize_filename(mat_code, 20))
                if sfx:
                    parts.append(sfx)
                if parts:
                    base = "_".join(parts) + '.dxf'
            except Exception:
                base = fname
            return base

        zaag = [{'file': f, 'label': _label_for_file(f)} for f in zaag_files]


        parts_dir = output_dir / 'DXF_Onderdelen'
        parts = []
        if sealed:
            parts = [
                fp.name for rel, fp in sorted(sealed.items())
                if rel.startswith('output/DXF_Onderdelen/') and fp.suffix.lower() == '.dxf'
            ]
            seen=set(); parts=[x for x in parts if (x.lower() not in seen and not seen.add(x.lower()))]


        jobs.append({
            'jobId': job_id,
            'status': meta.get('status', 'unknown'),
            'createdAt': meta.get('createdAt', ''),
            'sheets': sheets,
            'zaagplaten': zaag,
            'onderdelen': parts,
            'sealedFiles': [
                {'rel': rel, 'name': fp.name, 'kind': _classify_output_kind(fp.name)}
                for rel, fp in sorted(sealed.items())
            ],
            'edgeBandByDecorMeters': _edge_meters_by_decor(p),
            'customerName': customer_name,
        })
    return self._send_json({'jobs': jobs})



def _classify_output_kind(name: str) -> str:
    n = str(name or '').lower()
    if n.endswith('.dxf'):
        return 'dxf'
    if n == 'quote.json':
        return 'quote'
    if n == 'report.json':
        return 'report'
    if n == 'placements.json':
        return 'placements'
    if n == 'stickertool.json':
        return 'stickertool'
    if n == 'calculation_summary.txt':
        return 'summary'
    if n == 'pricing.json':
        return 'pricing'
    return 'other'


def _collect_job_output_files(job_id: str) -> list[dict]:
    try:
        job_id = validate_job_id(job_id)
        job_root = resolve_identifier_child(JOBS, job_id)
    except SafetyContractError:
        return []
    sealed = _sealed_output_artifacts(job_root)
    if not sealed:
        return []
    ctx = _job_material_context(job_root)
    code = str(ctx.get('materialCode') or '').strip()
    material_name = str(ctx.get('materialName') or (_best_material_name(code, '') if code else '')).strip()
    rows = []
    for rel, fp in sorted(sealed.items()):
        kind = _classify_output_kind(fp.name)
        rows.append({
            'jobId': job_id,
            'materialCode': code,
            'materialName': material_name,
            'name': fp.name,
            'rel': rel,
            'kind': kind,
            'size': fp.stat().st_size if fp.exists() else 0,
            'mtime': datetime.fromtimestamp(fp.stat().st_mtime, tz=timezone.utc).isoformat().replace('+00:00', 'Z') if fp.exists() else '',
        })
    return rows




def _dedupe_admin_dxf_files(files: list[dict]) -> list[dict]:
    """Hide duplicate generic Sheet_001.dxf-style files in Admin when a renamed
    workshop-friendly S01 export exists for the same sheet. Keep generic Sheet files
    only as a fallback when no nicer counterpart is available.
    """
    try:
        import re as _re
        rows = list(files or [])

        def _sheet_key(name: str) -> str:
            n = str(name or '').strip()
            m = _re.search(r'(?:^|[^a-z0-9])s(\d{2})(?:\.dxf)?$', n, _re.I)
            if m:
                return f"S{int(m.group(1)):02d}"
            m = _re.fullmatch(r'sheet[_\- ]?(\d+)(?:\.dxf)?', n, _re.I)
            if m:
                return f"S{int(m.group(1)):02d}"
            return n.lower()

        def _is_generic_sheet(name: str) -> bool:
            return bool(_re.fullmatch(r'sheet[_\- ]?\d+(?:\.dxf)?', str(name or '').strip(), _re.I))

        chosen = {}
        for f in rows:
            name = str((f or {}).get('name') or '')
            key = _sheet_key(name)
            cur = chosen.get(key)
            if cur is None:
                chosen[key] = f
                continue
            cur_generic = _is_generic_sheet(str(cur.get('name') or ''))
            new_generic = _is_generic_sheet(name)
            if cur_generic and not new_generic:
                chosen[key] = f
                continue
            if cur_generic == new_generic:
                # Keep shorter rel/name as a deterministic fallback.
                cur_score = (len(str(cur.get('rel') or cur.get('name') or '')), len(str(cur.get('name') or '')))
                new_score = (len(str(f.get('rel') or f.get('name') or '')), len(name))
                if new_score < cur_score:
                    chosen[key] = f

        # Preserve stable ordering from original rows.
        keep_ids = {id(v) for v in chosen.values()}
        return [f for f in rows if id(f) in keep_ids]
    except Exception:
        return list(files or [])

def _extract_strict_calculation_pricing_summary(job_ids: list[str]) -> dict:
    """Strict authoritative pricing for Tool A status/submit flows.

    Only return pricing when a final human calculation summary exists for one of the
    candidate jobs. Never fall back to request payloads, legacy quote totals, or
    interim frontend values. This prevents stale/partial prices from surfacing in
    the first price overlay before the true server calculation is finished.
    """
    out = {
        'materialsTotal': None,
        'materialsTotalInclVat': None,
        'materialsVatIncluded': None,
        'otherCostsExVat': None,
        'otherCostsVat': None,
        'edgeBandTotal': None,
        'cncTotal': None,
        'drawingTotal': None,
        'transportTotal': None,
        'subtotalExVat': None,
        'vatAmount': None,
        'totalInclVat': None,
        'currency': 'EUR',
        'source': '',
    }
    for jid in (job_ids or []):
        if not jid:
            continue
        try:
            jr = JOBS / jid
            calc = _parse_calculation_summary_totals(jr)
            if isinstance(calc, dict) and (calc.get('subtotalExVat') is not None or calc.get('totalInclVat') is not None):
                for k in ('materialsTotal','materialsTotalInclVat','materialsVatIncluded','otherCostsExVat','otherCostsVat','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
                    out[k] = calc.get(k)
                out['source'] = 'calculation-summary'
                return out
        except Exception:
            pass
    return out

def _extract_admin_pricing_summary(job_ids: list[str], request_status: dict | None = None) -> dict:
    """Best-effort compact price breakdown for Admin orderdetails.

    STRICT: prefer totals from calculation_summary.txt when available,
    so the Admin card matches the downloadable berekening exactly.
    """
    out = {
        'materialsTotal': None,
        'materialsTotalInclVat': None,
        'materialsVatIncluded': None,
        'otherCostsExVat': None,
        'otherCostsVat': None,
        'edgeBandTotal': None,
        'cncTotal': None,
        'drawingTotal': None,
        'transportTotal': None,
        'subtotalExVat': None,
        'vatAmount': None,
        'totalInclVat': None,
        'currency': 'EUR',
        'source': '',
    }

    # STRICT source of truth: the human calculation summary.
    for jid in job_ids:
        if not jid:
            continue
        try:
            calc = _parse_calculation_summary_totals(JOBS / jid)
            if isinstance(calc, dict) and (calc.get('subtotalExVat') is not None or calc.get('totalInclVat') is not None):
                for k in ('materialsTotal','materialsTotalInclVat','materialsVatIncluded','otherCostsExVat','otherCostsVat','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
                    out[k] = calc.get(k)
                out['source'] = 'calculation-summary'
                return out
        except Exception:
            pass


    def _merge(candidate: dict, label: str) -> bool:
        changed = False
        for k in ('materialsTotal','materialsTotalInclVat','materialsVatIncluded','otherCostsExVat','otherCostsVat','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
            v = candidate.get(k)
            if v is not None and out.get(k) is None:
                out[k] = v
                changed = True
        if changed and not out.get('source'):
            out['source'] = label
        return (out.get('totalInclVat') is not None) or (out.get('subtotalExVat') is not None and any(out.get(x) is not None for x in ('materialsTotal','edgeBandTotal','cncTotal','drawingTotal','transportTotal')))

    for jid in job_ids:
        if not jid:
            continue
        for fp, label in (
            (JOBS / jid / 'output' / 'quote.json', 'job-output-quote'),
            (JOBS / jid / 'output' / 'pricing.json', 'job-output-pricing'),
            (JOBS / jid / 'input' / 'pricing.json', 'job-input-pricing'),
        ):
            try:
                if fp.exists():
                    data = strict_json_load(fp)
                    if _merge(_extract_pricing_from_any(data), label):
                        return out
            except Exception:
                pass

    payload = _load_request_payload(str(request_status.get('requestId') or '')) if isinstance(request_status, dict) else {}
    if isinstance(payload, dict) and payload:
        for src_name in ('quote','pricing','summary'):
            src = payload.get(src_name)
            if isinstance(src, dict):
                if _merge(_extract_pricing_from_any(src), f'request-payload-{src_name}'):
                    return out
        try:
            summ = _extract_request_summary(payload)
            if out['totalInclVat'] is None and summ.get('priceInclVat') is not None:
                out['totalInclVat'] = round(float(summ['priceInclVat']), 2)
            if out['materialsTotal'] is None and summ.get('materialsPrice') is not None:
                out['materialsTotal'] = round(float(summ['materialsPrice']), 2)
            if out['vatAmount'] is None and out['subtotalExVat'] is not None and out['totalInclVat'] is not None:
                out['vatAmount'] = round(out['totalInclVat'] - out['subtotalExVat'], 2)
            if (out['totalInclVat'] is not None or out['materialsTotal'] is not None) and not out.get('source'):
                out['source'] = 'request-payload-summary'
        except Exception:
            pass

    if isinstance(request_status, dict):
        for src_name in ('quote','summary','pricing'):
            src = request_status.get(src_name)
            if isinstance(src, dict):
                if _merge(_extract_pricing_from_any(src), f'request-status-{src_name}'):
                    return out

    if out['subtotalExVat'] is None and out['totalInclVat'] is not None:
        try:
            out['subtotalExVat'] = round(float(out['totalInclVat']) / 1.21, 2)
        except Exception:
            pass
    if out['vatAmount'] is None and out['subtotalExVat'] is not None and out['totalInclVat'] is not None:
        out['vatAmount'] = round(out['totalInclVat'] - out['subtotalExVat'], 2)
    return out

def _find_or_generate_stickertool_file(job_id: str):
    """Return an already-finalized sticker file for a material subjob.

    Admin reads are deliberately side-effect free.  FIX660R7 generated this file
    lazily while constructing a download manifest, which could invalidate an already
    sealed output hash.  R8 creates it in the finalizer and only reads it here.
    """
    try:
        jid = validate_job_id(job_id)
        if '__mat_' not in jid:
            return None
        job_root = resolve_identifier_child(JOBS, jid)
        fp = _sealed_output_artifacts(job_root).get('output/stickertool.json')
        if fp is not None:
            data = strict_json_load(fp)
            if str(data.get('materialCode') or '').strip() and isinstance(data.get('items'), list) and len(data.get('items') or []) > 0:
                return fp
    except Exception:
        pass
    return None




def _dir_size_bytes(root: Path) -> int:
    try:
        total = 0
        if not root.exists() or not root.is_dir():
            return 0
        for fp in root.rglob('*'):
            try:
                if fp.is_file():
                    total += fp.stat().st_size
            except Exception:
                pass
        return int(total)
    except Exception:
        return 0

def _build_request_file_manifest(request_id: str) -> dict:
    st = _load_status(request_id) or {}
    job = st.get('job') if isinstance(st.get('job'), dict) else {}
    parent = _safe_id(str(job.get('parentJobId') or '').strip(), 200)
    subjobs = []
    for sj in (job.get('subjobs') or []):
        sj_id = ''
        if isinstance(sj, dict):
            sj_id = str(sj.get('subjobId') or sj.get('jobId') or sj.get('id') or '').strip()
        else:
            sj_id = str(sj or '').strip()
        sj_id = _safe_id(sj_id, 200) if sj_id else ''
        if sj_id and sj_id not in subjobs:
            subjobs.append(sj_id)
    # FIX654 recovery: older async /api/jobs runs could finish without persisting
    # status.job.subjobs. Recover from the private links manifest or filesystem so
    # existing completed jobs become downloadable in Admin too.
    if parent and not subjobs:
        try:
            links_path = JOBS / parent / 'output' / 'links.json'
            if links_path.exists():
                links = strict_json_load(links_path)
                for sj in (links.get('subjobs') or []):
                    sid = str((sj or {}).get('subjobId') if isinstance(sj, dict) else sj or '').strip()
                    sid = _safe_id(sid, 200) if sid else ''
                    if sid and sid not in subjobs:
                        subjobs.append(sid)
        except Exception:
            pass
        if not subjobs:
            try:
                for sp in sorted(JOBS.glob(f'{parent}__mat_*')):
                    if sp.is_dir():
                        sid = _safe_id(sp.name, 200)
                        if sid and sid not in subjobs:
                            subjobs.append(sid)
            except Exception:
                pass

    job_ids = []
    for jid in ([parent] if parent else []) + subjobs:
        if jid and jid not in job_ids:
            job_ids.append(jid)

    groups = []
    summary_files = []
    all_files = []
    seen_summary = set()
    for jid in job_ids:
        files = _collect_job_output_files(jid)
        # Surface only the sticker artifact sealed by the worker finalizer.
        st_fp = _find_or_generate_stickertool_file(jid)
        if st_fp is not None:
            rel = st_fp.relative_to(JOBS / jid).as_posix()
            if not any(str(f.get('rel') or '') == rel for f in files):
                _ctx2 = _job_material_context(JOBS / jid)
                code2 = str(_ctx2.get('materialCode') or '').strip()
                files.append({
                    'jobId': jid,
                    'materialCode': code2,
                    'materialName': str(_ctx2.get('materialName') or (_best_material_name(code2, '') if code2 else '')).strip(),
                    'name': st_fp.name,
                    'rel': rel,
                    'kind': _classify_output_kind(st_fp.name),
                    'size': st_fp.stat().st_size if st_fp.exists() else 0,
                    'mtime': datetime.fromtimestamp(st_fp.stat().st_mtime, tz=timezone.utc).isoformat().replace('+00:00', 'Z') if st_fp.exists() else '',
                })
        if not files:
            continue
        all_files.extend(files)
        _ctx = _job_material_context(JOBS / jid)
        code = str(_ctx.get('materialCode') or '').strip()
        material_name = str(_ctx.get('materialName') or (_best_material_name(code, '') if code else '')).strip()
        label = material_name or code or jid
        # Admin request detail should show only full sheet-layout DXFs here.
        # Part DXFs live in output/DXF_Onderdelen and must stay hidden in this block.
        sheet_dxf_files = _dedupe_admin_dxf_files([
            f for f in files
            if str(f.get('kind') or '') == 'dxf'
            and str(f.get('rel') or '').startswith('output/DXF_Zaagplaten/')
        ])
        if sheet_dxf_files:
            groups.append({
                'jobId': jid,
                'materialCode': code,
                'materialName': material_name,
                'label': label,
                'files': sheet_dxf_files,
            })
        for f in files:
            fkind = str(f.get('kind') or '')
            if fkind in ('quote','report','placements','stickers','stickertool','summary','pricing'):
                # Stickertool/Stickers are only valid per material subjob. Never surface
                # parent-level fallback files in Admin, because they produce empty items
                # and unknown material info.
                if fkind in ('stickers','stickertool') and '__mat_' not in str(jid or ''):
                    continue
                key = (fkind, jid)
                if key not in seen_summary:
                    seen_summary.add(key)
                    summary_files.append(f)

    for f in all_files:
        jid = quote(str(f.get('jobId') or ''), safe='')
        relq = quote(str(f.get('rel') or ''), safe='/')
        f['url'] = f"/api/admin/request_file?requestId={quote(request_id)}&jobId={jid}&rel={relq}"

    pricing_summary = (
        _extract_strict_calculation_pricing_summary(job_ids)
        if job_ids and all(_finalization_complete(resolve_identifier_child(JOBS, jid)) for jid in job_ids)
        else {}
    )

    request_dir = REQUESTS / request_id
    request_bytes = _dir_size_bytes(request_dir)
    jobs_bytes = 0
    for jid in job_ids:
        try:
            jobs_bytes += _dir_size_bytes(JOBS / jid)
        except Exception:
            pass
    total_bytes = int(request_bytes + jobs_bytes)

    return {
        'requestId': request_id,
        'parentJobId': parent,
        'subjobs': subjobs,
        'summaryFiles': summary_files,
        'dxfGroups': groups,
        'allFiles': all_files,
        'pricingSummary': pricing_summary,
        'storageSummary': {
            'requestBytes': int(request_bytes),
            'jobsBytes': int(jobs_bytes),
            'totalBytes': total_bytes,
            'jobCount': len(job_ids),
            'subjobCount': len(subjobs),
        },
        'zip': {
            'allOutputsUrl': f"/api/admin/request_download_zip?requestId={quote(request_id)}&scope=all",
            'allDxfUrl': f"/api/admin/request_download_zip?requestId={quote(request_id)}&scope=dxf",
        }
    }


def api_admin_request_files(self):
    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or '')
    rid = _safe_id(str((qs.get('requestId') or [''])[0]).strip(), 120)
    if not rid:
        return self._send_json({'ok': False, 'error': 'Missing requestId'}, 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_json({'ok': False, 'error': 'Unknown requestId'}, 404)
    manifest = _build_request_file_manifest(rid)
    return self._send_json({'ok': True, 'requestId': rid, 'files': manifest})


def api_admin_request_file(self):
    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or '')
    rid = _safe_id(str((qs.get('requestId') or [''])[0]).strip(), 120)
    job_id = _safe_id(str((qs.get('jobId') or [''])[0]).strip(), 200)
    rel = str((qs.get('rel') or [''])[0]).strip()
    if not rid or not job_id or not rel:
        return self._send_text('Missing requestId/jobId/rel', 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_text('Unknown requestId', 404)
    manifest = _build_request_file_manifest(rid)
    allowed = False
    for f in (manifest.get('allFiles') or []):
        if str(f.get('jobId') or '') == job_id and str(f.get('rel') or '') == rel:
            allowed = True
            break
    if not allowed:
        return self._send_text('File not linked to this request', 404)
    return api_job_file(self, job_id, rel)


def api_admin_request_download_zip(self):
    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or '')
    try:
        rid = validate_request_id(str((qs.get('requestId') or [''])[0]).strip())
    except SafetyContractError:
        return self._send_text('Invalid requestId', 400)
    scope = str((qs.get('scope') or ['all'])[0]).strip().lower()
    if scope not in {'all', 'dxf'}:
        return self._send_text('Invalid scope', 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_text('Unknown requestId', 404)
    manifest = _build_request_file_manifest(rid)
    files = manifest.get('allFiles') or []
    if scope == 'dxf':
        files = [f for f in files if f.get('kind') == 'dxf']
    if not files:
        return self._send_text('No files for this request', 404)
    export_limit = max(1, _env_int('ADMIN_EXPORT_MAX_INPUT_BYTES', 1024 * 1024 * 1024))
    selected: list[tuple[Path, str]] = []
    sealed_by_job: dict[str, dict[str, Path]] = {}
    total_input = 0
    for item in files[:10_000]:
        try:
            job_id = validate_job_id(str(item.get('jobId') or ''))
            job_root = resolve_identifier_child(JOBS, job_id)
            if not _finalization_complete(job_root):
                raise SafetyContractError('job is not finalized')
            rel = str(item.get('rel') or '')
            if job_id not in sealed_by_job:
                sealed_by_job[job_id] = _sealed_output_artifacts(job_root)
            safe = sealed_by_job[job_id].get(rel)
            if safe is None:
                raise SafetyContractError('file is not sealed')
            if not safe.is_file():
                raise SafetyContractError('file missing')
            total_input += safe.stat().st_size
            if total_input > export_limit:
                return self._send_text('Export exceeds the configured limit', 413)
            code = _sanitize_filename(item.get('materialCode') or '', 80)
            prefix = code if scope == 'dxf' and code else job_id
            rel_parts = [
                _sanitize_filename(part, 120)
                for part in Path(rel).parts
                if part not in {'', '.', 'output'}
            ]
            if not rel_parts or any(not part for part in rel_parts):
                raise SafetyContractError('invalid export path')
            selected.append((safe, '/'.join([prefix, *rel_parts])))
        except Exception:
            return self._send_text('Export manifest is no longer valid', 409)
    if not selected:
        return self._send_text('No valid files for this request', 404)

    export_dir = SYSTEM_DIR / 'exports'
    export_dir.mkdir(parents=True, exist_ok=True)
    export_path = export_dir / f'.request_export_{rid}_{secrets.token_hex(8)}.zip'
    try:
        with zipfile.ZipFile(export_path, 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
            for source, arcname in selected:
                zf.write(source, arcname)
        with export_path.open('rb') as handle:
            os.fsync(handle.fileno())
        fsync_directory(export_dir)
        if export_path.stat().st_size > export_limit:
            return self._send_text('Compressed export exceeds the configured limit', 413)
        fname = f"{rid}_{'dxf' if scope == 'dxf' else 'outputs'}.zip"
        return self._stream_file(export_path, content_type='application/zip', download_name=fname, max_bytes=export_limit)
    finally:
        try:
            export_path.unlink(missing_ok=True)
            fsync_directory(export_dir)
        except Exception:
            pass


def api_admin_requests(self):
    """Admin endpoint: list requests (mailbox)."""
    _ensure_request_dirs()
    # optional limit
    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or "")
    try:
        limit = int((qs.get("limit") or ["200"])[0])
    except Exception:
        limit = 200
    limit = max(1, min(2000, limit))

    rows = []
    for p in sorted(REQUESTS.glob("*")):
        if not p.is_dir():
            continue
        rid = p.name
        st_path = p / "status.json"
        if not st_path.exists():
            continue
        try:
            st = strict_json_load(st_path)
        except Exception:
            continue
        st["requestId"] = rid
        rows.append(st)

    # FIX594: direct Tool A optimization jobs may exist without a REQUESTS mailbox row.
    # Mirror those master jobs into the admin request list so Tool A -> Admin is live.
    try:
        existing_ids = {str(r.get("requestId") or "") for r in rows}
        # Calculations are not sales requests. Only REQUESTS rows created by the final,
        # idempotent submit route belong in the Admin mailbox.
        for jp in []:
            if not jp.is_dir():
                continue
            job_id = jp.name
            # Material subjobs are children of a master order; show the master only in the mailbox.
            if "__mat_" in job_id:
                continue
            if job_id in existing_ids:
                continue
            job_json = {}
            try:
                jpath = jp / "input" / "job.json"
                if jpath.exists():
                    job_json = strict_json_load(jpath)
            except Exception:
                job_json = {}
            cust = job_json.get("customer") if isinstance(job_json.get("customer"), dict) else {}
            if not cust:
                order = job_json.get("order") if isinstance(job_json.get("order"), dict) else {}
                cust = {
                    "name": order.get("customer_name") or order.get("customerName") or "—",
                    "email": order.get("email") or "",
                    "phone": order.get("phone") or "",
                }
            created = ""
            try:
                created = datetime.datetime.fromtimestamp(jp.stat().st_mtime).isoformat(timespec="seconds")
            except Exception:
                created = ""
            status = "DONE" if (jp / "output" / "calculation_summary.txt").exists() else "PROCESSING"
            subjobs = []
            try:
                for child in sorted(JOBS.glob(job_id + "__mat_*")):
                    if child.is_dir():
                        subjobs.append({"subjobId": child.name, "jobId": child.name, "status": "DONE" if (child / "output").exists() else "PROCESSING"})
            except Exception:
                subjobs = []
            rows.append({
                "requestId": job_id,
                "createdAt": created,
                "updatedAt": created,
                "customer": cust or {"name": "—"},
                "publicStatus": "DONE" if status == "DONE" else "SUBMITTED",
                "publicStatusLabel": "Klaar" if status == "DONE" else "Aanvraag verzonden",
                "internalStatus": status,
                "internalStatusLabel": "Klaar" if status == "DONE" else "Bezig",
                "quoteStatus": "DONE" if status == "DONE" else "TODO",
                "needsQuote": False if status == "DONE" else True,
                "job": {"parentJobId": job_id, "subjobs": subjobs},
                "source": "jobs-fallback",
            })
            existing_ids.add(job_id)
    except Exception as e:
        try:
            _append_system_event(level="warning", component="admin", message_user="Admin kon job fallback niet volledig opbouwen", message_tech=str(e), status="open")
        except Exception:
            pass

    # newest first
    def _key(x):
        return str(x.get("createdAt") or x.get("updatedAt") or "")
    rows.sort(key=_key, reverse=True)
    rows = rows[:limit]
    return self._send_json({"ok": True, "requests": rows})

def api_admin_requests_update(self):
    """Admin endpoint: update request mailbox status (e.g., mark quote sent)."""
    _ensure_request_dirs()
    try:
        body = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
    except Exception as e:
        return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

    try:
        rid = validate_request_id(body.get("requestId"))
    except SafetyContractError:
        return self._send_json({"ok": False, "error": "Missing requestId"}, 400)

    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_json({"ok": False, "error": "Unknown requestId"}, 404)

    action = str(body.get("action") or "").strip().lower()
    before = {
        'publicStatus': st.get('publicStatus'),
        'internalStatus': st.get('internalStatus'),
        'quoteStatus': st.get('quoteStatus'),
    }
    if action == "mark_quote_sent":
        st["quoteStatus"] = "DONE"
        st["needsQuote"] = False
        st["publicStatus"] = "DONE"
        st["publicStatusLabel"] = "Afgehandeld"
        st["internalStatus"] = "DONE"
        st["internalStatusLabel"] = "Afgehandeld"
    elif action == "reopen":
        st["quoteStatus"] = "TODO"
        st["needsQuote"] = True
        st["publicStatus"] = "SUBMITTED"
        st["publicStatusLabel"] = "Aanvraag verzonden"
        if str(st.get("internalStatus") or "").upper() in ("PROCESSING", "OFFER_SENT", ""):
            st["internalStatus"] = "QUEUED"
            st["internalStatusLabel"] = "In wachtrij"
    else:
        return self._send_json({"ok": False, "error": "Unknown action"}, 400)

    _save_status(rid, st)
    _append_system_event(
        level='info', component='admin_request',
        message_user='Aanvraagstatus aangepast',
        message_tech=f'request={rid}; action={action}',
        request_id=rid, status='resolved',
        details={
            'actor': self._current_admin_actor() or 'unknown-admin',
            'action': action,
            'before': before,
            'after': {
                'publicStatus': st.get('publicStatus'),
                'internalStatus': st.get('internalStatus'),
                'quoteStatus': st.get('quoteStatus'),
            },
        },
    )
    return self._send_json({"ok": True})


def api_job_file(self, job_id: str, rel: str, parsed=None):
    """Serve a file inside jobs/<jobId> safely.

    This endpoint is used by Admin downloads. It must never fail silently
    (ERR_EMPTY_RESPONSE). If something goes wrong, return an error body.
    """
    try:
        job_id = validate_job_id(job_id)
        job_root = resolve_identifier_child(JOBS, job_id)
        if not self._require_job_access(job_id, parsed=parsed):
            return
        is_admin_request = bool(self._check_admin_auth_silent())
        rel_norm_public = (rel or '').replace('\\', '/').lstrip('/').lower()
        # Public job tokens are only allowed to read a sanitized quote. Production
        # inputs, CSV, pricing, stickers and DXF remain Admin-only.
        if not is_admin_request and rel_norm_public != 'output/quote.json':
            return self._send_text('Forbidden', 403)
        if not job_root.exists():
            return self._send_text('Not found', 404)

        if not _finalization_complete(job_root):
            return self._send_text('Production output is not finalized', 409)

        rel_norm = (rel or '').replace('\\', '/').lstrip('/')
        fpath = _sealed_output_artifacts(job_root).get(rel_norm)
        if fpath is None:
            return self._send_text('Not found', 404)

        if (not fpath.exists()) or (not fpath.is_file()):
            return self._send_text('Not found', 404)

        data: bytes | None = None
        if not is_admin_request and rel_norm_public == 'output/quote.json':
            try:
                data = fpath.read_bytes()
                obj = strict_json_loads(data)
                obj = self._public_quote_view(obj)
                data = strict_json_dumps(obj).encode('utf-8')
            except Exception:
                return self._send_text('Quote unavailable', 500)

        ctype = 'application/octet-stream'
        name = fpath.name.lower()
        if name.endswith('.json'):
            ctype = 'application/json'
        elif name.endswith('.csv'):
            ctype = 'text/csv'
        elif name.endswith('.txt'):
            ctype = 'text/plain'
        elif name.endswith('.dxf'):
            ctype = 'application/dxf'
        elif name.endswith('.html'):
            ctype = 'text/html'

        # Friendly download name for Stickertool v2
        download_name = fpath.name
        try:
            if rel_norm == 'output/stickertool.json':
                job_json_path = job_root / 'input' / 'job.json'
                job_json = {}
                if job_json_path.exists():
                    try:
                        job_json = strict_json_load(job_json_path)
                    except Exception:
                        job_json = {}
                cust_name = _customer_name_from_job(job_json)
                safe_cust = _sanitize_filename(cust_name or 'Onbekend', 50)
                safe_job = _sanitize_filename(job_id, 60)
                download_name = f"{safe_cust}__{safe_job}__stickertool.json"
        except Exception:
            download_name = fpath.name

        if is_admin_request:
            return self._stream_file(
                fpath,
                content_type='application/json; charset=utf-8' if ctype == 'application/json' else ctype,
                download_name=download_name,
                max_bytes=max(1, _env_int('ADMIN_FILE_DOWNLOAD_MAX_BYTES', 2 * 1024 * 1024 * 1024)),
            )
        if data is None:
            return self._send_text('Forbidden', 403)

        self.send_response(200)
        self.send_header('Cache-Control', 'no-store')
        if ctype == 'application/json':
            self.send_header('Content-Type', 'application/json; charset=utf-8')
        else:
            self.send_header('Content-Type', ctype)
        self.send_header('Content-Disposition', f'attachment; filename="{download_name}"')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(data)
        return
    except Exception as e:
        return self._send_text('Error serving file', 500)



def api_stickertool_v2(self, subjob_id: str):
    """Retired unauthenticated compatibility route."""
    return self._send_text('Deprecated. Use an authenticated job file route.', 410)


def api_subjob_file(self, job_id: str, subjob_id: str, rel: str, parsed=None):
    """Serve a sealed file from a subjob linked to the specified master job."""
    try:
        job_id = validate_job_id(job_id)
        subjob_id = validate_job_id(subjob_id)
        master_root = resolve_identifier_child(JOBS, job_id)
        subjob_root = resolve_identifier_child(JOBS, subjob_id)
    except SafetyContractError:
        return self._send_text('Not found', 404)
    if subjob_id not in _linked_subjob_ids(job_id):
        return self._send_text('Not found', 404)
    if not master_root.is_dir() or not subjob_root.is_dir() or not _finalization_complete(subjob_root):
        return self._send_text('Production output is not finalized', 409)

    is_admin_request = bool(self._check_admin_auth_silent())
    if not is_admin_request:
        supplied = _extract_request_token(self, parsed=parsed)
        expected_master = _read_job_access_token(job_id)
        expected_subjob = _read_job_access_token(subjob_id)
        allowed = bool(supplied) and any(
            expected and hmac.compare_digest(str(supplied), str(expected))
            for expected in (expected_master, expected_subjob)
        )
        if not allowed:
            return self._send_text('Forbidden', 403)
    rel_norm_public = (rel or '').replace('\\', '/').lstrip('/').lower()
    if not is_admin_request and rel_norm_public != 'output/quote.json':
        return self._send_text('Forbidden', 403)
    rel_norm = (rel or '').replace('\\', '/').lstrip('/')
    fpath = _sealed_output_artifacts(subjob_root).get(rel_norm)
    if fpath is None:
        return self._send_text('Not found', 404)
    if not fpath.exists() or not fpath.is_file():
        return self._send_text('Not found', 404)

    data: bytes | None = None
    if not is_admin_request and rel_norm_public == 'output/quote.json':
        try:
            data = fpath.read_bytes()
            obj = strict_json_loads(data)
            obj = self._public_quote_view(obj)
            data = strict_json_dumps(obj).encode('utf-8')
        except Exception:
            return self._send_text('Quote unavailable', 500)
    ctype = 'application/octet-stream'
    name = fpath.name.lower()
    if name.endswith('.json'):
        ctype = 'application/json'
    elif name.endswith('.csv'):
        ctype = 'text/csv'
    elif name.endswith('.txt'):
        ctype = 'text/plain'

    # Friendly filename for the sealed StickerTool contract.
    download_name = fpath.name
    try:
        if rel_norm.lower() == 'output/stickertool.json':
            # Try to derive customer from the subjob's job.json if present
            job_json_path = subjob_root / 'input' / 'job.json'
            job_json = {}
            if job_json_path.exists():
                try:
                    job_json = strict_json_load(job_json_path)
                except Exception:
                    job_json = {}
            cust_name = _customer_name_from_job(job_json)
            safe_cust = _sanitize_filename(cust_name or 'Onbekend', 50)
            safe_sub = _sanitize_filename(subjob_id, 80)
            download_name = f"{safe_cust}__{safe_sub}__stickertool.json"
    except Exception:
        download_name = fpath.name

    if is_admin_request:
        return self._stream_file(
            fpath,
            content_type='application/json; charset=utf-8' if ctype == 'application/json' else ctype,
            download_name=download_name,
            max_bytes=max(1, _env_int('ADMIN_FILE_DOWNLOAD_MAX_BYTES', 2 * 1024 * 1024 * 1024)),
        )
    if data is None:
        return self._send_text('Forbidden', 403)

    self.send_response(200)
    self.send_header('Content-Type', ctype)
    self.send_header('Cache-Control', 'no-store')
    self.send_header('Content-Disposition', f'attachment; filename="{download_name}"')
    self.send_header('Content-Length', str(len(data)))
    self.end_headers()
    self.wfile.write(data)

def _fmt_bytes(n: int) -> str:
    try:
        n = int(n)
    except Exception:
        return "0 B"
    units = ["B","KB","MB","GB","TB"]
    i = 0
    f = float(n)
    while f >= 1024 and i < len(units)-1:
        f /= 1024.0
        i += 1
    if i == 0:
        return f"{int(f)} {units[i]}"
    return f"{f:.1f} {units[i]}"

def _dir_size_bytes(p: Path) -> int:
    total = 0
    try:
        for f in p.rglob('*'):
            try:
                if f.is_file():
                    total += f.stat().st_size
            except Exception:
                pass
    except Exception:
        pass
    return total

def api_admin_control_center(self):
    """Read-only info for the Admin Control Center (Phase 1)."""
    # Active versions (Phase 1 = simple file timestamps; no editing here)
    def _file_ver(path: Path) -> dict:
        if not path.exists():
            return {"exists": False}
        st = path.stat()
        return {
            "exists": True,
            "file": path.name,
            "modified": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(st.st_mtime)),
            "bytes": int(st.st_size),
        }

    pricing = _file_ver(PRICING_ACTIVE)
    materials = _file_ver(MATERIAL_LIBRARY_PATH)
    dxf_library = _file_ver(DXF_MANIFEST_PATH)
    optimizer = {"active": OPTIMIZER_TOOL_B}

    # Storage
    jobs_count = 0
    largest = {"jobId": None, "bytes": 0}
    try:
        for p in JOBS.glob('*'):
            if not p.is_dir(): 
                continue
            jobs_count += 1
            sz = _dir_size_bytes(p)
            if sz > largest["bytes"]:
                largest = {"jobId": p.name, "bytes": sz}
    except Exception:
        pass

    # Recent failures (best-effort): jobs with non-empty toolb_stderr.txt
    failures = []
    try:
        job_dirs = [p for p in JOBS.glob('*') if p.is_dir()]
        job_dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        for p in job_dirs[:200]:
            err = p / 'output' / 'toolb_stderr.txt'
            if err.exists():
                try:
                    txt = err.read_text(encoding='utf-8', errors='ignore').strip()
                except Exception:
                    txt = ''
                if txt:
                    # short excerpt
                    excerpt = '\n'.join(txt.splitlines()[:5]).strip()
                    failures.append({
                        "jobId": p.name,
                        "modified": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(p.stat().st_mtime)),
                        "excerpt": excerpt[:600],
                    })
            if len(failures) >= 5:
                break
    except Exception:
        pass

    # Disk usage (jobs folder only)
    jobs_bytes = _dir_size_bytes(JOBS)

    payload = {
        "versions": {
            "pricing": pricing,
            "materials": materials,
            "dxfLibrary": dxf_library,
            "optimizer": optimizer,
        },
        "storage": {
            "jobsCount": jobs_count,
            "jobsBytes": jobs_bytes,
            "largestJob": largest,
        },
        "failures": failures,
    }
    body, code = _safe_json(payload, 200)
    self.send_response(code)
    self.send_header('Content-Type', 'application/json; charset=utf-8')
    self.send_header('Content-Length', str(len(body)))
    self.end_headers()
    self.wfile.write(body)


def api_download(self, job_id: str, fname: str, parsed=None):
    try:
        job_id = validate_job_id(job_id)
        job_root = resolve_identifier_child(JOBS, job_id)
    except SafetyContractError:
        return self._send_text('Not found', 404)
    if not self._require_job_access(job_id, parsed=parsed):
        return
    if not self._check_admin_auth_silent():
        return self._send_text('Forbidden', 403)
    rel = 'output/sheets/' + str(fname).replace('\\', '/')
    fpath = _sealed_output_artifacts(job_root).get(rel)
    if fpath is None:
        return self._send_text('Not found', 404)
    if not fpath.exists():
        return self._send_text('Not found', 404)
    return self._stream_file(
        fpath,
        content_type='application/dxf',
        download_name=str(fname),
        max_bytes=max(1, _env_int('ADMIN_FILE_DOWNLOAD_MAX_BYTES', 2 * 1024 * 1024 * 1024)),
    )



# --- Queue worker (Release 1 foundation) ---
_WORKER_LOCK_FD: int | None = None


def _acquire_worker_lock() -> bool:
    global _WORKER_LOCK_FD
    try:
        WORKER_LOCK.parent.mkdir(parents=True, exist_ok=True)
        if _WORKER_LOCK_FD is not None:
            return False
        if _fcntl is None:
            fd = os.open(str(WORKER_LOCK), os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o640)
        else:
            fd = os.open(str(WORKER_LOCK), os.O_RDWR | os.O_CREAT, 0o640)
            try:
                _fcntl.flock(fd, _fcntl.LOCK_EX | _fcntl.LOCK_NB)
            except Exception:
                os.close(fd)
                return False
        os.ftruncate(fd, 0)
        os.write(fd, (str(os.getpid()) + '\n').encode('ascii'))
        os.fsync(fd)
        fsync_directory(WORKER_LOCK.parent)
        _WORKER_LOCK_FD = fd
        return True
    except Exception:
        return False


def _release_worker_lock() -> None:
    global _WORKER_LOCK_FD
    try:
        fd = _WORKER_LOCK_FD
        _WORKER_LOCK_FD = None
        if fd is not None:
            if _fcntl is not None:
                _fcntl.flock(fd, _fcntl.LOCK_UN)
            os.close(fd)
        if _fcntl is None and WORKER_LOCK.exists():
            WORKER_LOCK.unlink()
            fsync_directory(WORKER_LOCK.parent)
    except Exception:
        pass


def _create_job_from_payload(payload: dict, master_job_id: str | None = None, public_access_token: str = '') -> dict:
    """Internal helper used by both /api/jobs and the queue worker.

    NOTE: payload format is the same as /api/jobs expects today:
      {panelsCsv: str, dxfParts: dict, pricing?: dict, jobJson?: dict}
    """
    if not isinstance(payload, dict) or payload.get('payloadSchema') != 'FIX660R8_SERVER_CANONICAL_V1':
        raise SafetyContractError('Internal job payload is not server-canonical')
    panels_csv = payload.get('panelsCsv', '')
    dxf_parts = _expand_dxf_payload(payload)
    job_json = payload.get('jobJson', {}) or {}

    if not panels_csv or not dxf_parts:
        raise ValueError('Missing panelsCsv or DXF geometry')

    # Always start from the live pricing config on disk so Admin changes apply immediately
    # to new jobs, even when Tool A still sends an older client-side pricing skeleton.
    cfg = _load_pricing_config()
    live_cfg = cfg if isinstance(cfg, dict) else {}
    live_pricing = live_cfg.get('pricing') if isinstance(live_cfg.get('pricing'), dict) else None
    if not isinstance(live_pricing, dict):
        live_pricing = strict_json_load(PRICING_SEED_PATH)

    # Browser pricing, currency, edge loss and dimensions are never merged here.
    pricing_base = strict_json_loads(strict_json_dumps(live_pricing))
    pricing = _ensure_pricing_materials(pricing_base, panels_csv)

    # Keep production layout settings authoritative from the live pricing config so
    # Admin changes (plaatmarge / nesting gap / kerf) apply immediately to new jobs,
    # even when Tool A still sends older client-side defaults.
    try:
        live_defaults = pricing.get('defaults') if isinstance(pricing.get('defaults'), dict) else {}
        job_json = dict(job_json or {})
        if isinstance(live_defaults, dict):
            if live_defaults.get('sheetMarginMm') is not None:
                job_json['sheetMarginMm'] = float(live_defaults.get('sheetMarginMm'))
            if live_defaults.get('nestingGapMm') is not None:
                job_json['nestingGapMm'] = float(live_defaults.get('nestingGapMm'))
            if live_defaults.get('kerfMm') is not None:
                job_json['kerfMm'] = float(live_defaults.get('kerfMm'))
    except Exception:
        pass

    master_job_id = validate_job_id(str(master_job_id or (time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6])))
    master_root = resolve_identifier_child(JOBS, master_job_id)
    master_input = master_root / 'input'
    master_output = master_root / 'output'
    master_input.mkdir(parents=True, exist_ok=True)
    master_output.mkdir(parents=True, exist_ok=True)
    _save_job_runtime_state(master_job_id, 'PREPARING')
    if public_access_token:
        try:
            _atomic_write_json(master_root / '.public_access.json', {
                'token': str(public_access_token),
                'jobId': str(master_job_id),
                'updatedAt': _utc_now_iso(),
            })
        except Exception:
            pass
    if master_job_id:
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'createdAt': meta.get('createdAt') or _now_iso(),
                    'progressPct': max(int(meta.get('progressPct') or 0), 3),
                    'progressMessage': 'Voorbereiden van de job…',
                    'phase': 'prepare',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass

    # Master input (record of the full order)
    _write_file(master_input / 'panels.csv', panels_csv)
    _write_file(master_input / 'pricing.json', json.dumps(pricing, indent=2))
    _write_file(master_input / 'job.json', json.dumps(job_json, indent=2))

    parts_dir = master_input / 'dxf_parts'
    parts_dir.mkdir(parents=True, exist_ok=True)
    # FIX656: compact transport must stay compact on disk too. 100 identical doors used
    # to become 100 separate ~100KB writes again here. Write one unique DXF body and
    # hard-link duplicate PartId filenames to it; the visible per-PartId contract remains.
    unique_dxf_paths: dict[str, Path] = {}
    master_dxf_unique = 0
    master_dxf_linked = 0
    for part_id, dxf_text in dxf_parts.items():
        name = str(part_id)
        if not name.lower().endswith('.dxf'):
            name = name + '.dxf'
        target = parts_dir / name
        text = str(dxf_text)
        digest = hashlib.sha256(text.encode('utf-8')).hexdigest()
        canonical = unique_dxf_paths.get(digest)
        if canonical is not None and canonical.exists():
            try:
                mode = _link_or_copy_file(canonical, target)
                if mode == 'hardlink':
                    master_dxf_linked += 1
                else:
                    master_dxf_unique += 1
            except Exception:
                _write_file(target, text)
                master_dxf_unique += 1
        else:
            _write_file(target, text)
            unique_dxf_paths[digest] = target
            master_dxf_unique += 1

    # Split into subjobs per MaterialCode (deterministic)
    rows = _parse_panels_csv(panels_csv)
    required_part_ids = {str((r or {}).get('PartId') or '').strip() for r in rows if str((r or {}).get('PartId') or '').strip()}
    missing_dxf_ids = sorted(pid for pid in required_part_ids if pid not in dxf_parts)
    if missing_dxf_ids:
        raise ValueError(f'DXF-geometrie ontbreekt voor {len(missing_dxf_ids)} paneelregel(s).')
    material_codes: list[str] = []
    seen: set[str] = set()
    for r in rows:
        c = str(r.get('MaterialCode') or '').strip()
        if c and c not in seen:
            seen.add(c)
            material_codes.append(c)

    # Resolve human names from pricing material library
    mats = pricing.get('materials', []) if isinstance(pricing, dict) else []

    def mat_name_for(code: str) -> str:
        for m in mats:
            if str(m.get('materialCode') or '').strip() == str(code).strip():
                return str(m.get('decorName') or m.get('materialName') or m.get('materialCode') or code)
        return str(code)

    subjobs = []
    subjob_roots: list[Path] = []
    timing_profile: dict[str, Any] = {
        'version': 'FIX656',
        'startedAt': _utc_now_iso(),
        'masterJobId': master_job_id,
        'subjobs': [],
    }
    total_started_perf = time.perf_counter()
    timing_profile['masterDxfFiles'] = len(dxf_parts)
    timing_profile['masterDxfUniqueBodies'] = int(master_dxf_unique)
    timing_profile['masterDxfHardlinks'] = int(master_dxf_linked)

    # Guard against runaway disk growth before optimizer work starts
    _enforce_job_output_limit(master_root, subjob_roots)

    # Run optimizer per material code (deterministic ordering)
    total_subjobs = max(1, len(material_codes))
    for subjob_index, code in enumerate(material_codes, start=1):
        if _job_cancel_requested(master_job_id):
            raise JobCancelledError('Job cancelled before optimizer start')
        _save_job_runtime_state(master_job_id, 'PROCESSING', currentSubjobIndex=subjob_index, subjobsTotal=total_subjobs)
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                base_pct = 5 + int(round(((subjob_index - 1) / float(total_subjobs)) * 90.0))
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), base_pct),
                    'progressMessage': f'Materiaal {subjob_index}/{total_subjobs} voorbereiden…',
                    'phase': 'subjob_prepare',
                    'currentSubjobIndex': subjob_index,
                    'subjobsTotal': total_subjobs,
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
        # Subjob IDs are deliberately opaque; internal article numbers must never appear in public job identifiers.
        sub_id = f"{master_job_id}__mat_{subjob_index:03d}"
        sub_root = JOBS / sub_id
        subjob_roots.append(sub_root)
        sub_inp = sub_root / 'input'
        sub_out = sub_root / 'output'
        if public_access_token:
            try:
                sub_root.mkdir(parents=True, exist_ok=True)
                _atomic_write_json(sub_root / '.public_access.json', {
                    'token': str(public_access_token),
                    'jobId': str(sub_id),
                    'updatedAt': _utc_now_iso(),
                })
            except Exception:
                pass
        # Filter panels.csv for this material (preserve header/order)
        sub_csv = _filter_panels_csv_by_material(panels_csv, code)
        _write_file(sub_inp / 'panels.csv', sub_csv)
        _write_file(sub_inp / 'pricing.json', json.dumps(pricing, indent=2))
        _write_file(sub_inp / 'job.json', json.dumps(job_json, indent=2))
        # FIX655: a material subjob receives only the PartIds it actually contains.
        # Master input remains complete. Prefer hard-links to avoid rewriting the same
        # ~100KB DXF data; fall back to a normal write when links are unavailable.
        sub_parts_dir = sub_inp / 'dxf_parts'
        sub_parts_dir.mkdir(parents=True, exist_ok=True)
        sub_rows = _parse_panels_csv(sub_csv)
        relevant_part_ids = []
        relevant_seen = set()
        for _r in sub_rows:
            _pid = str((_r or {}).get('PartId') or '').strip()
            if _pid and _pid not in relevant_seen:
                relevant_seen.add(_pid)
                relevant_part_ids.append(_pid)
        for part_id in relevant_part_ids:
            if part_id not in dxf_parts:
                raise ValueError(f'DXF-geometrie ontbreekt voor paneel {part_id}.')
            name = str(part_id) + '.dxf'
            src_path = parts_dir / name
            dst_path = sub_parts_dir / name
            try:
                _link_or_copy_file(src_path, dst_path)
            except Exception:
                _write_file(dst_path, str(dxf_parts[part_id]))

        # Guard after writing subjob inputs, before expensive optimizer work
        _enforce_job_output_limit(master_root, subjob_roots)

        # Run optimizer script
        cmd = _get_python_base_cmd() + ["-u", str(ROOT / OPTIMIZER_TOOL_B), '--input', str(sub_inp), '--output', str(sub_out)]
        try:
            _write_file(sub_out / 'toolb_cmd.txt', ' '.join(cmd))
        except Exception:
            pass
        # Capture logs
        sub_out.mkdir(parents=True, exist_ok=True)
        stdout_path = sub_out / 'toolb_stdout.txt'
        stderr_path = sub_out / 'toolb_stderr.txt'
        progress_path = sub_out / 'progress.json'

        def _read_subjob_progress_snapshot() -> tuple[int|None, str]:
            try:
                if not progress_path.exists():
                    return (None, '')
                pdata = strict_json_load(progress_path)
                pct_raw = pdata.get('percent')
                if pct_raw is None:
                    return (None, '')
                pct_val = max(0, min(100, int(round(float(pct_raw)))))
                msg_val = str(pdata.get('message') or pdata.get('phase') or '').strip()
                return (pct_val, msg_val)
            except Exception:
                return (None, '')

        def _publish_master_progress_from_subjob() -> None:
            if not master_job_id:
                return
            pct_val, msg_val = _read_subjob_progress_snapshot()
            if pct_val is None:
                return
            try:
                base_pct = 5 + int(round(((subjob_index - 1) / float(total_subjobs)) * 93.0))
                done_pct = 5 + int(round((subjob_index / float(total_subjobs)) * 93.0))
                mapped_pct = base_pct + int(round((max(0, min(99, pct_val)) / 100.0) * max(0, done_pct - base_pct - 1)))
                mapped_pct = max(base_pct, min(done_pct - 1, mapped_pct))
                if pct_val >= 100:
                    mapped_pct = min(done_pct - 1, max(mapped_pct, done_pct - 1))
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    current_pct = int(meta.get('progressPct') or 0)
                    if mapped_pct > current_pct:
                        meta.update({
                            'status': 'processing',
                            'progressPct': mapped_pct,
                            'progressMessage': msg_val or f'Materiaal {subjob_index}/{total_subjobs} optimaliseren…',
                            'phase': 'subjob_progress',
                            'currentSubjobIndex': subjob_index,
                            'subjobsTotal': total_subjobs,
                            'updatedAt': _utc_now_iso(),
                        })
                        _job_meta[master_job_id] = meta
            except Exception:
                pass

        subjob_started_perf = time.perf_counter()
        with open(stdout_path, 'w', encoding='utf-8') as f_out, open(stderr_path, 'w', encoding='utf-8') as f_err:
            p = subprocess.Popen(cmd, cwd=str(ROOT), stdout=f_out, stderr=f_err)
            _register_job_process(master_job_id, p)
            deadline = time.time() + float(_env_int('OPTIMIZER_TIMEOUT_SECONDS', 300))
            timed_out = False
            try:
                while True:
                    rc = p.poll()
                    _publish_master_progress_from_subjob()
                    if rc is not None:
                        break
                    if _job_cancel_requested(master_job_id):
                        try:
                            p.terminate()
                            p.wait(timeout=5)
                        except Exception:
                            p.kill()
                        raise JobCancelledError(f'Job cancelled during {sub_id}')
                    if time.time() > deadline:
                        timed_out = True
                        try:
                            p.terminate()
                            p.wait(timeout=5)
                        except Exception:
                            try:
                                p.kill()
                            except Exception:
                                pass
                        rc = -9
                        break
                    time.sleep(0.08)
            finally:
                _unregister_job_process(master_job_id, p)
            _publish_master_progress_from_subjob()
            if timed_out:
                raise RuntimeError(f"Optimizer timeout for {sub_id}")
        optimizer_done_perf = time.perf_counter()

        if rc != 0:
            raise RuntimeError(f"Optimizer failed for {sub_id} (rc={rc}). See {stderr_path.name}")

        # Guard again after optimizer output landed on disk
        _enforce_job_output_limit(master_root, subjob_roots)
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                summary_pct = 94 + int(round((((subjob_index - 1) + 0.25) / float(total_subjobs)) * 2.0))
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), summary_pct),
                    'progressMessage': f'Materiaal {subjob_index}/{total_subjobs} berekening opbouwen…',
                    'phase': 'subjob_summary',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass

        summary_started_perf = time.perf_counter()
        if _job_cancel_requested(master_job_id):
            raise JobCancelledError('Job cancelled before output finalization')
        _save_job_runtime_state(master_job_id, 'FINALIZING', currentSubjobIndex=subjob_index, subjobsTotal=total_subjobs)
        try:
            _finalize_subjob_outputs(sub_root)
        except Exception as e:
            raise RuntimeError(f'Outputfinalisatie mislukt voor {sub_id}: {e}') from e
        summary_done_perf = time.perf_counter()
        try:
            _atomic_write_json(sub_out / 'timing_profile_server.json', {
                'version': 'FIX656',
                'jobId': sub_id,
                'startedAt': _utc_now_iso(),
                'optimizerSeconds': round(max(0.0, optimizer_done_perf - subjob_started_perf), 3),
                'summarySeconds': round(max(0.0, summary_done_perf - summary_started_perf), 3),
                'totalSeconds': round(max(0.0, summary_done_perf - subjob_started_perf), 3),
                'updatedAt': _utc_now_iso(),
            })
        except Exception:
            pass
        timing_profile['subjobs'].append({
            'subjobId': sub_id,
            'optimizerSeconds': round(max(0.0, optimizer_done_perf - subjob_started_perf), 3),
            'summarySeconds': round(max(0.0, summary_done_perf - summary_started_perf), 3),
            'totalSeconds': round(max(0.0, summary_done_perf - subjob_started_perf), 3),
        })

        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                done_pct = 97 + int(round((subjob_index / float(total_subjobs)) * 1.0))
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), done_pct),
                    'progressMessage': f'Materiaal {subjob_index}/{total_subjobs} afgerond',
                    'phase': 'subjob_done',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass

        subjobs.append({
            "subjobId": sub_id,
            "materialCode": code,
            "materialDisplayName": mat_name_for(code),
            "status": "DONE",
            "outputsReady": _finalization_complete(sub_root),
        })
        _write_master_job_links(master_job_id, subjobs)

    # Final guard on the full job family before reporting success
    if _job_cancel_requested(master_job_id):
        raise JobCancelledError('Job cancelled before master finalization')
    _enforce_job_output_limit(master_root, subjob_roots)
    if master_job_id:
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), 95),
                    'progressMessage': 'Subjobs samenvoegen…',
                    'phase': 'finalize_merge',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
    master_summary_started_perf = time.perf_counter()
    try:
        _write_human_calculation_summary(master_root)
        if not ((master_root / 'output' / 'calculation_summary.txt').exists() or (master_root / 'input' / 'calculation_summary.txt').exists() or (master_root / 'calculation_summary.txt').exists()):
            raise RuntimeError('Definitief master-berekeningsoverzicht ontbreekt.')
        _write_master_job_links(master_job_id, subjobs)
        master_artifacts = [
            master_root / 'output' / 'links.json',
            master_root / 'output' / 'calculation_summary.txt',
        ]
        for path in master_artifacts:
            if not path.is_file() or path.stat().st_size <= 0:
                raise RuntimeError(f'Masterartifact ontbreekt: {path.name}')
        subjob_finalizations = {}
        for subjob in subjobs:
            subjob_id = validate_job_id(subjob.get('subjobId'))
            subjob_root = resolve_identifier_child(JOBS, subjob_id)
            if not _finalization_complete(subjob_root):
                raise RuntimeError(f'Subjobfinalisatie ongeldig: {subjob_id}')
            subjob_finalizations[subjob_id] = sha256_file(subjob_root / 'output' / 'finalization.json')
        durable_write_json(master_root / 'output' / 'finalization.json', {
            'schemaVersion': 2,
            'build': 'FIX660R8_PRELIVE_HARDENED',
            'kind': 'master',
            'jobId': master_job_id,
            'state': 'COMPLETE',
            'subjobCount': len(subjobs),
            'subjobFinalizationsSha256': subjob_finalizations,
            'artifactsSha256': {
                path.relative_to(master_root / 'output').as_posix(): sha256_file(path)
                for path in master_artifacts
            },
            'finishedAt': _utc_now_iso(),
        })
    except Exception as e:
        try:
            _atomic_write_json(master_root / 'output' / 'finalization.json', {
                'schemaVersion': 1, 'build': 'FIX654_OUTPUT_PIPELINE_AUDIT',
                'jobId': master_job_id, 'state': 'ERROR', 'error': str(e)[:500], 'finishedAt': _utc_now_iso(),
            })
        except Exception:
            pass
        raise RuntimeError(f'Masteroutput finaliseren mislukt: {e}') from e
    master_summary_done_perf = time.perf_counter()
    if master_job_id:
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), 97),
                    'progressMessage': 'Resultaten verwerken…',
                    'phase': 'finalize',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), 99),
                    'progressMessage': 'Afronden…',
                    'phase': 'finalize_done',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
    try:
        timing_profile['masterSummarySeconds'] = round(max(0.0, master_summary_done_perf - master_summary_started_perf), 3)
        timing_profile['totalSeconds'] = round(max(0.0, time.perf_counter() - total_started_perf), 3)
        timing_profile['finishedAt'] = _utc_now_iso()
        _atomic_write_json(master_root / 'output' / 'timing_profile.json', timing_profile)
    except Exception:
        pass

    return {
        "jobId": master_job_id,
        "parentJobId": master_job_id,
        "subjobs": subjobs,
    }


def process_one_queue_item() -> bool:
    """Process one pending queue item. Returns True if something was processed."""
    if _state_snapshot_is_active():
        return False
    _ensure_request_dirs()
    items = sorted(QUEUE_PENDING.glob("*.json"))
    if not items:
        return False

    item_path = items[0]
    try:
        q_item = strict_json_load(item_path)
    except Exception as e:
        _append_system_event(level="error", component="jobs", message_user="Een queue-item kon niet worden gelezen", message_tech=str(e), job_id=_safe_text(item_path.stem, 120), status="open")
        # bad queue item -> move to failed
        try:
            _move_queue_file_safe(item_path, QUEUE_FAILED)
        except Exception:
            pass
        return True

    request_id = _safe_id(q_item.get("requestId") or "", 120)
    if not request_id:
        _append_system_event(level="error", component="jobs", message_user="Een queue-item mist requestId", message_tech=f"Queue item {item_path.name} has no requestId", status="open")
        try:
            _move_queue_file_safe(item_path, QUEUE_FAILED)
        except Exception:
            pass
        return True

    # Move to processing (atomic)
    try:
        processing_path = _move_queue_file_safe(item_path, QUEUE_PROCESSING)
    except Exception:
        return True

    status = _load_status(request_id) or {}
    # If cancelled, skip
    if status.get("publicStatus") == "CANCELLED" or status.get("internalStatus") == "CANCELLED":
        status["internalStatus"] = "CANCELLED"
        status["internalStatusLabel"] = "Geannuleerd"
        _save_status(request_id, status)
        try:
            _move_queue_file_safe(processing_path, QUEUE_DONE)
        except Exception:
            pass
        return True

    # Update status: processing
    status["internalStatus"] = "PROCESSING"
    status["internalStatusLabel"] = "Bezig"
    _save_status(request_id, status)
    _sse_broadcast("request_processing", {"requestId": request_id})

    try:
        # FIX657: the queue is link-only. It must never call _create_job_from_payload;
        # optimization already happened under /api/jobs before final submission.
        job = status.get('job') if isinstance(status.get('job'), dict) else {}
        parent_job_id = _safe_id(str(q_item.get('parentJobId') or job.get('parentJobId') or '').strip(), 200)
        if not parent_job_id or not _finalization_complete(JOBS / parent_job_id):
            raise RuntimeError('LEGACY_QUEUE_ITEM_REQUIRES_REVIEW')
        status["internalStatus"] = "DONE"
        status["internalStatusLabel"] = "Gekoppeld aan afgeronde berekening"
        status["job"] = {
            "parentJobId": parent_job_id,
            "subjobs": _linked_subjob_ids(parent_job_id),
        }
        status["error"] = None
        _save_status(request_id, status)
        _move_queue_file_safe(processing_path, QUEUE_DONE)
    except Exception as e:
        # Fail closed. Re-optimizing a submitted request could change price/output and is
        # therefore never an acceptable recovery strategy.
        status["internalStatus"] = "FAILED"
        status["internalStatusLabel"] = "Handmatige controle nodig"
        status["error"] = {
            "code": "LEGACY_QUEUE_ITEM_REQUIRES_REVIEW",
            "message": "Bestaand queue-item kon niet veilig aan een afgeronde job worden gekoppeld.",
        }
        _save_status(request_id, status)
        _append_system_event(level="error", component="jobs", message_user="Bestaand queue-item vereist handmatige controle", message_tech=str(e), request_id=request_id, job_id=_safe_text((status.get('job') or {}).get('parentJobId'), 120), customer_name=_guess_customer_name(request_id=request_id, status=status), status="open")
        try:
            _move_queue_file_safe(processing_path, QUEUE_FAILED)
        except Exception:
            pass

    return True


def _recover_processing_queue_items_fix657() -> dict:
    """Recover only processing items that can be linked without doing new work."""
    result = {'requeued': 0, 'failed': 0}
    _ensure_request_dirs()
    for path in sorted(QUEUE_PROCESSING.glob('*.json')):
        try:
            q_item = strict_json_load(path)
            request_id = _safe_id(str(q_item.get('requestId') or path.stem).strip(), 120)
            status = _load_status(request_id) or {}
            job = status.get('job') if isinstance(status.get('job'), dict) else {}
            parent = _safe_id(str(q_item.get('parentJobId') or job.get('parentJobId') or '').strip(), 200)
            if parent and _finalization_complete(JOBS / parent):
                _move_queue_file_safe(path, QUEUE_PENDING)
                result['requeued'] += 1
                continue
            status['internalStatus'] = 'FAILED'
            status['internalStatusLabel'] = 'Handmatige controle nodig'
            status['error'] = {
                'code': 'LEGACY_QUEUE_ITEM_REQUIRES_REVIEW',
                'message': 'Queue-item uit een eerdere release kan niet veilig automatisch worden hervat.',
            }
            if request_id:
                _save_status(request_id, status)
            _move_queue_file_safe(path, QUEUE_FAILED)
            result['failed'] += 1
        except Exception:
            try:
                _move_queue_file_safe(path, QUEUE_FAILED)
                result['failed'] += 1
            except Exception:
                pass
    return result


def worker_loop(poll_seconds: float = 1.0) -> None:
    if not _acquire_worker_lock():
        print("Worker already running (lock exists).")
        return
    print("Worker started.")
    try:
        recovery = _recover_processing_queue_items_fix657()
        if recovery.get('requeued') or recovery.get('failed'):
            print(f"FIX657 queue recovery: {recovery}")
    except Exception as e:
        print("FIX657 queue recovery error:", e)
    try:
        while True:
            did = False
            try:
                did = process_one_queue_item()
            except Exception as e:
                print("Worker error:", e)
            if not did:
                try:
                    run_retention_maintenance(force=False)
                except Exception:
                    pass
                try:
                    run_backup_maintenance(force=False)
                except Exception:
                    pass
                try:
                    run_queue_maintenance(force=False)
                except Exception:
                    pass
                time.sleep(poll_seconds)
    except KeyboardInterrupt:
        pass
    finally:
        _release_worker_lock()
        print("Worker stopped.")


def _readiness_report() -> tuple[dict[str, Any], int]:
    checks: dict[str, bool] = {}
    details: dict[str, Any] = {}
    try:
        lib = strict_json_load(MATERIAL_LIBRARY_PATH)
        records = lib.get('records') if isinstance(lib, dict) else []
        count = sum(
            1 for rec in records if isinstance(rec, dict)
            and str(rec.get('sourceKind') or '').upper() == 'CATALOG_IMPORT'
            and rec.get('active') is not False and rec.get('archived') is not True
            and rec.get('published') is True and rec.get('catalogMissing') is not True
            and rec.get('catalogExcluded') is not True
        )
        checks['catalog'] = count >= max(1, _env_int('PRODUCTION_MIN_CATALOG_RECORDS', 1))
        details['catalogRecords'] = count
    except Exception:
        checks['catalog'] = False

    if _is_production_hardening_enabled():
        try:
            signoff_path = Path(os.environ.get('CATALOG_SIGNOFF_FILE') or (SYSTEM_DIR / 'catalog_signoff.json')).expanduser()
            signoff = strict_json_load(signoff_path)
            signed_hash = str(signoff.get('materialLibrarySha256') or '') if isinstance(signoff, dict) else ''
            checks['catalogSignoff'] = bool(
                isinstance(signoff, dict)
                and signoff.get('approved') is True
                and str(signoff.get('approvedBy') or '').strip()
                and str(signoff.get('approvedAt') or '').strip()
                and re.fullmatch(r'[a-f0-9]{64}', signed_hash)
                and hmac.compare_digest(signed_hash, sha256_file(MATERIAL_LIBRARY_PATH))
            )
            details['catalogSignoffActor'] = str(signoff.get('approvedBy') or '') if isinstance(signoff, dict) else ''
        except Exception:
            checks['catalogSignoff'] = False

    try:
        pricing = _load_pricing_config()
        ensure_finite_json(pricing)
        checks['pricing'] = isinstance(pricing, dict) and str(pricing.get('currency') or 'EUR').upper() == 'EUR'
    except Exception:
        checks['pricing'] = False

    probe = STATE_ROOT / f'.readiness.{os.getpid()}.{secrets.token_hex(4)}'
    try:
        durable_write_text(probe, 'ok\n', mode=0o600)
        checks['stateWritable'] = probe.read_text(encoding='utf-8') == 'ok\n'
    except Exception:
        checks['stateWritable'] = False
    finally:
        probe.unlink(missing_ok=True)

    try:
        usage = shutil.disk_usage(STATE_ROOT)
        min_free = max(64 * 1024 * 1024, _env_int('MIN_FREE_STATE_BYTES', 1024 * 1024 * 1024))
        checks['freeBytes'] = usage.free >= min_free
        details['freeBytes'] = int(usage.free)
        if hasattr(os, 'statvfs'):
            fs = os.statvfs(STATE_ROOT)
            free_inodes = int(fs.f_favail)
            checks['freeInodes'] = free_inodes >= max(100, _env_int('MIN_FREE_STATE_INODES', 10_000))
            details['freeInodes'] = free_inodes
    except Exception:
        checks['freeBytes'] = False
        checks['freeInodes'] = False

    try:
        checks['dxfLibrary'] = DXF_LIBRARY_ROOT.is_dir() and any(DXF_LIBRARY_ROOT.rglob('*.dxf'))
    except Exception:
        checks['dxfLibrary'] = False
    ok = bool(checks) and all(checks.values())
    return ({'ok': ok, 'build': SECURITY_BUILD, 'checks': checks, 'details': details}, 200 if ok else 503)


def _prometheus_metrics() -> str:
    with _SSE_CLIENTS_LOCK:
        sse_clients = len(_SSE_CLIENTS)
    with _PUBLIC_JOB_CREATE_LOCK:
        active_creates = _PUBLIC_JOB_CREATE_TOTAL
    try:
        catalog = strict_json_load(MATERIAL_LIBRARY_PATH)
        catalog_records = len(catalog.get('records') or []) if isinstance(catalog, dict) else 0
    except Exception:
        catalog_records = 0
    values = {
        'metod_sse_clients': sse_clients,
        'metod_job_creates_active': active_creates,
        'metod_jobs_total': sum(1 for p in JOBS.iterdir() if p.is_dir()) if JOBS.exists() else 0,
        'metod_requests_total': sum(1 for p in REQUESTS.iterdir() if p.is_dir()) if REQUESTS.exists() else 0,
        'metod_queue_pending': len(list(QUEUE_PENDING.glob('*.json'))),
        'metod_queue_processing': len(list(QUEUE_PROCESSING.glob('*.json'))),
        'metod_catalog_records': catalog_records,
        'metod_state_free_bytes': shutil.disk_usage(STATE_ROOT).free,
    }
    return ''.join(f'# TYPE {name} gauge\n{name} {int(value)}\n' for name, value in values.items())

def _validate_production_runtime_or_die() -> None:
    """Fail closed before binding a public socket when production invariants are unsafe."""
    if not _is_production_hardening_enabled():
        return
    errors: list[str] = []
    app_env = str(os.environ.get('APP_ENV') or '').strip().lower()
    if app_env not in ('prod', 'production'):
        errors.append('APP_ENV must be production')
    if not _env_flag('PRODUCTION_HARDENING', False):
        errors.append('PRODUCTION_HARDENING must be 1')
    if not _env_flag('ADMIN_HASH_ONLY', False):
        errors.append('ADMIN_HASH_ONLY must be 1')
    if _env_flag('ADMIN_STAGING_OPEN', False):
        errors.append('ADMIN_STAGING_OPEN must be 0')

    if _env_flag('LEGACY_HTTP_COMPAT', False) or str(os.environ.get('LEGACY_HTTP_ORIGIN') or '').strip():
        errors.append('legacy plaintext HTTP compatibility is forbidden in production')

    def _check_origins(name: str) -> None:
        vals = _split_env_origins(name)
        if not vals:
            errors.append(f'{name} must be set')
            return
        for origin in vals:
            try:
                u = urlparse(origin)
                structural_ok = bool(
                    u.hostname and not u.username and not u.password and '*' not in origin
                    and not u.query and not u.fragment and u.path in ('', '/')
                )
                if not (structural_ok and u.scheme.lower() == 'https'):
                    raise ValueError('origin must be exact HTTPS origin')
            except Exception:
                errors.append(f'{name} contains unsafe origin: {origin!r}')
    _check_origins('ALLOWED_ORIGINS')
    _check_origins('ALLOWED_ADMIN_ORIGINS')

    try:
        public_url = urlparse(str(os.environ.get('METOD_PUBLIC_BASE_URL') or '').strip())
        if not (
            public_url.scheme.lower() == 'https' and public_url.hostname
            and not public_url.username and not public_url.password
            and not public_url.query and not public_url.fragment
        ):
            raise ValueError('invalid HTTPS URL')
    except Exception:
        errors.append('METOD_PUBLIC_BASE_URL must be an absolute HTTPS URL')

    try:
        release_resolved = RELEASE_ROOT.resolve()
        state_resolved = STATE_ROOT.resolve()
        if state_resolved == release_resolved or release_resolved in state_resolved.parents:
            errors.append('METOD_STATE_ROOT must be outside the immutable release directory')
    except Exception:
        errors.append('METOD_STATE_ROOT cannot be resolved')
    if os.name != 'nt' and hasattr(os, 'geteuid') and os.geteuid() == 0:
        errors.append('the application service must run as a dedicated non-root user')

    public_limit = _env_int('PUBLIC_JSON_MAX_BYTES', 16 * 1024 * 1024)
    submit_limit = _env_int('SUBMIT_MAX_BYTES', 8 * 1024 * 1024)
    dxf_limit = _env_int('PUBLIC_DXF_BLOB_MAX_BYTES', 2 * 1024 * 1024)
    dxf_count_limit = _env_int('PUBLIC_DXF_MAX_COUNT', 500)
    if public_limit <= 0 or public_limit > 16 * 1024 * 1024:
        errors.append('PUBLIC_JSON_MAX_BYTES must be between 1 and 16777216')
    if submit_limit <= 0 or submit_limit > 8 * 1024 * 1024:
        errors.append('SUBMIT_MAX_BYTES must be between 1 and 8388608')
    if dxf_limit <= 0 or dxf_limit > 2 * 1024 * 1024:
        errors.append('PUBLIC_DXF_BLOB_MAX_BYTES must be between 1 and 2097152')
    if dxf_count_limit <= 0 or dxf_count_limit > 500:
        errors.append('PUBLIC_DXF_MAX_COUNT must be between 1 and 500')
    if _env_int('PUBLIC_JOB_MAX_CONCURRENT', 1) != 1:
        errors.append('PUBLIC_JOB_MAX_CONCURRENT must be 1 on the current production baseline')
    if _env_int('PUBLIC_JOB_MAX_CONCURRENT_PER_IP', 1) != 1:
        errors.append('PUBLIC_JOB_MAX_CONCURRENT_PER_IP must be 1 on the current production baseline')
    if not (1 <= _env_int('HTTP_MAX_CONCURRENT', 64) <= 256):
        errors.append('HTTP_MAX_CONCURRENT must be between 1 and 256')
    if not (1 <= _env_int('MAX_SSE_CLIENTS', 24) <= 128):
        errors.append('MAX_SSE_CLIENTS must be between 1 and 128')

    try:
        lib = strict_json_load(MATERIAL_LIBRARY_PATH)
        records = lib.get('records') if isinstance(lib, dict) else None
        if not isinstance(records, list):
            raise SafetyContractError('records must be a list')
        active_count = sum(
            1 for rec in records
            if isinstance(rec, dict)
            and str(rec.get('sourceKind') or '').upper() == 'CATALOG_IMPORT'
            and rec.get('active') is not False and rec.get('archived') is not True
            and rec.get('published') is True and rec.get('catalogMissing') is not True
            and rec.get('catalogExcluded') is not True
        )
        required_count = max(1, _env_int('PRODUCTION_MIN_CATALOG_RECORDS', 1))
        if active_count < required_count:
            errors.append(f'active published catalog has {active_count} records; requires at least {required_count}')
        signoff_path = Path(os.environ.get('CATALOG_SIGNOFF_FILE') or (SYSTEM_DIR / 'catalog_signoff.json')).expanduser()
        signoff = strict_json_load(signoff_path)
        if not isinstance(signoff, dict) or signoff.get('approved') is not True:
            errors.append('catalog signoff must explicitly be approved')
        elif not hmac.compare_digest(str(signoff.get('materialLibrarySha256') or ''), sha256_file(MATERIAL_LIBRARY_PATH)):
            errors.append('catalog signoff hash does not match the active material library')
        elif not str(signoff.get('approvedBy') or '').strip() or not str(signoff.get('approvedAt') or '').strip():
            errors.append('catalog signoff must contain approvedBy and approvedAt')
    except Exception as e:
        errors.append(f'catalog/signoff validation failed: {e}')

    creds_path = _get_admin_credentials_file_path()
    try:
        root_resolved = ROOT.resolve()
        creds_resolved = creds_path.resolve()
        if creds_resolved == root_resolved or root_resolved in creds_resolved.parents:
            errors.append('ADMIN_CREDENTIALS_FILE must be outside the application directory')
    except Exception:
        errors.append('ADMIN_CREDENTIALS_FILE path cannot be resolved')
    try:
        creds = strict_json_load(creds_path)
        users = _normalized_admin_users(creds if isinstance(creds, dict) else {})
        if not users:
            errors.append('admin credentials must contain at least one active individual user')
        usernames = [str(user.get('username') or '') for user in users]
        if len(usernames) != len(set(usernames)):
            errors.append('admin usernames must be unique')
        for user in users:
            username = str(user.get('username') or '')
            if not re.fullmatch(r'[A-Za-z0-9_.@-]{3,80}', username):
                errors.append(f'admin username is invalid: {username!r}')
            if not _is_password_hash_value(user.get('password_hash')):
                errors.append(f'admin user {username!r} requires a PBKDF2-SHA256 password_hash')
            secret = str(user.get('totp_secret') or '')
            try:
                _totp_code(secret, 0)
            except Exception:
                errors.append(f'admin user {username!r} requires a valid TOTP secret')
            if 'admin' not in set(user.get('roles') or []):
                errors.append(f'admin user {username!r} requires the admin role')
        if isinstance(creds, dict) and (str(creds.get('password') or '').strip() or creds.get('username')):
            errors.append('legacy shared/plaintext admin credentials are forbidden in production')
        if isinstance(creds, dict):
            for raw_user in creds.get('users') or []:
                if isinstance(raw_user, dict) and str(raw_user.get('password') or '').strip():
                    errors.append('plaintext passwords are forbidden in production credentials')
        if os.name != 'nt' and (creds_path.stat().st_mode & 0o777) not in {0o400, 0o600}:
            errors.append('admin credentials permissions must be 0400 or 0600')
    except Exception as e:
        errors.append(f'admin credentials unreadable: {e}')
    if _admin_password_reset_activation_is_enabled():
        errors.append('admin password reset activation must be disabled')

    if not _env_flag('OFFSITE_BACKUP_VERIFIED', False):
        errors.append('OFFSITE_BACKUP_VERIFIED must be 1 after encrypted off-host backup verification')
    if not str(os.environ.get('OFFSITE_BACKUP_PROVIDER') or '').strip():
        errors.append('OFFSITE_BACKUP_PROVIDER must identify the encrypted off-host backup target')
    try:
        restore_proof_path = Path(os.environ.get('RESTORE_TEST_PROOF_FILE') or (SYSTEM_DIR / 'restore_test_proof.json')).expanduser()
        proof = strict_json_load(restore_proof_path)
        verified_at = datetime.fromisoformat(str(proof.get('verifiedAt') or '').replace('Z', '+00:00'))
        if verified_at.tzinfo is None:
            verified_at = verified_at.replace(tzinfo=timezone.utc)
        age = datetime.now(timezone.utc) - verified_at.astimezone(timezone.utc)
        if proof.get('ok') is not True or age < timedelta(0) or age > timedelta(days=max(1, _env_int('RESTORE_TEST_MAX_AGE_DAYS', 90))):
            errors.append('restore-test proof is missing, failed or too old')
        if not re.fullmatch(r'[a-f0-9]{64}', str(proof.get('backupSha256') or '')):
            errors.append('restore-test proof requires backupSha256')
    except Exception as e:
        errors.append(f'restore-test proof validation failed: {e}')

    if errors:
        for err in errors:
            print('[SECURITY ERROR]', err)
        raise SystemExit(2)


def main():
    os.chdir(str(ROOT))
    _initialize_external_state()
    _validate_production_runtime_or_die()
    _ensure_request_dirs()
    _ensure_archive_dirs()
    _ensure_system_dirs()
    migration = _migrate_legacy_materials_to_direct_sell_prices()
    if not migration.get('ok'):
        print('[PRICING MIGRATION ERROR]', migration.get('error') or 'unknown')
        raise SystemExit(2)
    if migration.get('updated'):
        print(f"[PRICING MIGRATION] froze {migration.get('updated')} legacy material prices into direct per-material sell prices")
    try:
        run_retention_maintenance(force=True)
    except Exception:
        pass
    _reconcile_interrupted_jobs_on_startup()
    try:
        run_queue_maintenance(force=True)
    except Exception:
        pass
    # Align embedded DXFs with Tool A categories and rebuild manifest
    migrate_embedded_dxfs_to_categories()
    rebuild_embedded_dxfs_manifest()
    httpd = BoundedThreadingHTTPServer((HOST, PORT), Handler)
    maintenance_thread = threading.Thread(target=_server_maintenance_loop, name='server-maintenance', daemon=True)
    maintenance_thread.start()
    print(f"Server listening on http://{HOST}:{PORT}")
    print(f"Admin: http://{HOST}:{PORT}/admin")
    creds_path = _get_admin_credentials_file_path()
    print(f"Admin credentials source: {creds_path}")
    httpd.serve_forever()





if __name__ == '__main__':
    # Mode switch:
    #   python server_py.py          -> run server
    #   python server_py.py --worker -> run queue worker
    if '--worker' in sys.argv:
        os.chdir(str(ROOT))
        _initialize_external_state()
        _validate_production_runtime_or_die()
        _ensure_request_dirs()
        _ensure_archive_dirs()
        _ensure_system_dirs()
        migration = _migrate_legacy_materials_to_direct_sell_prices()
        if not migration.get('ok'):
            print('[PRICING MIGRATION ERROR]', migration.get('error') or 'unknown')
            raise SystemExit(2)
        try:
            run_retention_maintenance(force=True)
        except Exception:
            pass
        _reconcile_interrupted_jobs_on_startup()
        try:
            run_queue_maintenance(force=True)
        except Exception:
            pass
        worker_loop()
    else:
        main()
