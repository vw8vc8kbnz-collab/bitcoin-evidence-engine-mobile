from datetime import datetime, timezone
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="AlgoRoute API", version="0.3.2")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": "0.3.2", "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/dashboard")
def dashboard():
    return {
        "routes": 12,
        "on_time": 98,
        "stops": 256,
        "kilometers": 1248,
        "fuel_liters": 412,
        "co2_saved_kg": 125,
        "load_capacity": 84,
        "alerts": [
            {"type":"traffic", "title":"Verkeersvertraging A2", "message":"10 min extra reistijd", "time":"10:24"},
            {"type":"route", "title":"Afwijking leveradres", "message":"Route aangepast", "time":"09:15"},
            {"type":"delay", "title":"Stop vertraagd", "message":"Klant niet aanwezig", "time":"08:47"}
        ]
    }

@app.get("/api/fleet")
def fleet():
    return [
        {"id":"V-01", "driver":"Jan de Vries", "vehicle":"Scania P320", "status":"Actief", "load":85, "speed":60, "stops_done":8, "stops_total":12, "next":"Klant A - Utrecht", "eta":"10:45"},
        {"id":"V-02", "driver":"Pieter Smit", "vehicle":"Volvo FMX", "status":"Actief", "load":72, "speed":52, "stops_done":5, "stops_total":10, "next":"Klant B - Breda", "eta":"11:20"},
        {"id":"V-03", "driver":"Marco Jansen", "vehicle":"DAF CF", "status":"Onderhoud", "load":30, "speed":0, "stops_done":0, "stops_total":0, "next":"Niet beschikbaar", "eta":"-"}
    ]
