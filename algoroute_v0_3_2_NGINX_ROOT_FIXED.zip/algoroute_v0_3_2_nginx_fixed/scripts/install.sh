#!/usr/bin/env bash
set -euo pipefail
echo "Installing AlgoRoute v0.3.2 nginx/root fixed..."
command -v docker >/dev/null 2>&1 || { echo "Docker is missing. Install Docker first."; exit 1; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose plugin is missing."; exit 1; }
echo "OK: Docker present"
