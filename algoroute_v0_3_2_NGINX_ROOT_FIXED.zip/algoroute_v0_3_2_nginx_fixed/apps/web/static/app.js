async function boot(){
  try { const h = await fetch('/api/health').then(r=>r.json()); console.log('AlgoRoute API', h); } catch(e){ console.warn(e); }
  const truck = document.querySelector('.truck');
  let i=0; const pts=[[68,74],[61,58],[53,50],[45,48],[38,59],[33,73],[43,82],[57,77],[70,72]];
  setInterval(()=>{ const p=pts[i++%pts.length]; truck.style.left=p[0]+'%'; truck.style.top=p[1]+'%'; },1200);
}
boot();
