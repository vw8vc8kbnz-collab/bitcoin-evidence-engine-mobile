# AlgoRoute v0.3.2 — Nginx Root Fixed

Deze build fixt expliciet het probleem waarbij `/` een 403 gaf terwijl `/api/health` wel werkte.

- Frontend root: `/`
- API health: `/api/health`
- Host poort: `8787`

Architectuur:
- `algoroute-web`: Nginx serveert `/usr/share/nginx/html`
- `algoroute-api`: FastAPI draait intern op poort 8000
- Nginx proxyt alleen `/api/` door naar de API
