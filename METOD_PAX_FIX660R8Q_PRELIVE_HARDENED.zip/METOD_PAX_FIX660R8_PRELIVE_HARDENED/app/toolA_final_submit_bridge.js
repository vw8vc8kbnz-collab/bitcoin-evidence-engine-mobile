(function(root){
  'use strict';

  const BUILD = 'FIX660R8Q_SINGLE_SUBMIT_OWNER';
  const boundButtons = typeof WeakSet === 'function' ? new WeakSet() : null;

  function submitButtonFromTarget(target){
    try{
      const button = target && target.closest ? target.closest('#sendConfigBtn, #btnSendConfig') : null;
      return button && String(button.id || '') ? button : null;
    }catch(_){ return null; }
  }

  function routeClick(event){
    const button = submitButtonFromTarget(event && (event.currentTarget || event.target));
    if(!button) return false;
    try{ event.preventDefault(); }catch(_){ }
    try{ event.stopImmediatePropagation(); }catch(_){ try{ event.stopPropagation(); }catch(__){ } }

    const submit = root.__metodSubmitFinalConfiguration;
    if(typeof submit !== 'function'){
      try{
        if(typeof root.statusMsg === 'function') root.statusMsg('De verzendfunctie is nog niet gereed. Herlaad de pagina en probeer opnieuw.', true);
        else root.alert && root.alert('De verzendfunctie is nog niet gereed. Herlaad de pagina en probeer opnieuw.');
      }catch(_){ }
      return true;
    }
    try{
      const result = submit(button);
      if(result && typeof result.catch === 'function'){
        result.catch(function(error){
          try{ root.console && root.console.error && root.console.error('Final submit failed', error); }catch(_){ }
        });
      }
    }catch(error){
      try{ root.console && root.console.error && root.console.error('Final submit failed', error); }catch(_){ }
    }
    return true;
  }

  function bindButton(button){
    if(!button || typeof button.addEventListener !== 'function') return false;
    if((boundButtons && boundButtons.has(button)) || button.dataset.metodSubmitOwner === BUILD) return true;
    // Retire both legacy target listeners before they can attach. This element
    // now has exactly one owner and one canonical submission path.
    button.dataset.metodSubmitOwner = BUILD;
    button.dataset.bound = 'canonical';
    button.__bound = true;
    button.addEventListener('click', routeClick, true);
    if(boundButtons) boundButtons.add(button);
    return true;
  }

  function bind(documentRef){
    const doc = documentRef || root.document;
    if(!doc || typeof doc.querySelectorAll !== 'function') return false;
    let found = false;
    doc.querySelectorAll('#sendConfigBtn, #btnSendConfig').forEach(function(button){
      found = bindButton(button) || found;
    });
    return found;
  }

  function init(){
    bind(root.document);
    try{
      const observer = new MutationObserver(function(){ bind(root.document); });
      observer.observe(root.document.documentElement || root.document.body, {childList:true, subtree:true});
      root.__metod_submit_owner_observer = observer;
    }catch(_){ }
  }

  root.ToolAFinalSubmitBridge = Object.freeze({ BUILD, submitButtonFromTarget, routeClick, bindButton, bind });
  root.__TOOLA_FINAL_SUBMIT_BUILD = BUILD;
  if(root.document){
    if(root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', init, {once:true});
    else init();
  }
})(typeof window !== 'undefined' ? window : globalThis);
