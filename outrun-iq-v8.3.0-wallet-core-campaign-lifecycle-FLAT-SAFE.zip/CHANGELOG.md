# v8.3.0 — Wallet Core & Campaign Lifecycle

- Outrun Wallet als append-only grootboek toegevoegd.
- Campagnebudget wordt vooraf gereserveerd vanuit wallet.
- Stoppen van campagnes refundt ongebruikt budget automatisch naar wallet.
- Campagnes kunnen worden gepauzeerd/hervat/gestopt vanuit Partner Promote.
- Wallet-overzicht toegevoegd aan Promoten en Geld.
- Ledger entries hebben idempotency keys en hash-chain voor auditbaarheid.

# v8.3.0 — Wallet Core & Campaign Lifecycle

- Discovery Engine v1: gebruikerssignalen uit saves/orders, categorieën, partners, merken en prijsklasse.
- Ranking Engine v1: persoonlijke match + deal quality + partner trust + versheid + voorraadschaarste + subtiele promotieboost.
- Promote Rotation Engine: budget, relevantie, fairness, CTR en campaign fatigue wegen mee; geen first-come-first-serve.
- Home Builder AI: DeepSeek/OpenAI router kan sectieplan voorstellen; rules fallback blijft stabiel.
- Partner Coach AI: promotie-advies per voorraadset met OpenAI/DeepSeek en rules fallback.
- AI Decision Logger uitgebreid voor ranking en promotierotatie.
