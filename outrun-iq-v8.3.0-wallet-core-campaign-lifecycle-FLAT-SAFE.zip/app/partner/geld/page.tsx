import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { sweepOrders, getPartnerWallet } from "@/lib/data";
import { eur } from "@/lib/types";
import { Mark } from "@/components/icons";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";

const fmt = (iso: string) => new Date(iso).toLocaleDateString("nl-NL", { day: "numeric", month: "short" });

export default async function Geld() {
  await sweepOrders();
  const db = await read();
  const user = await getUser();
  const orders = db.orders.filter(o => o.sellerSlug === user?.partnerSlug).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const escrow = orders.filter(o => !["paid_out", "cancelled"].includes(o.status));
  const paid = orders.filter(o => o.status === "paid_out");
  const d30 = Date.now() - 30 * 864e5;
  const wallet = user?.partnerSlug ? await getPartnerWallet(user.partnerSlug) : null;
  return (
    <main className="page partnerScreen moneyScreen">
      <header className="hd">
        <Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />Geld</Link>
        <span className="sp" />
      </header>
      <section className="moneyHero"><div className="big"><label>OUTRUN WALLET · VRIJ BESTEEDBAAR</label>
        <b>{eur((wallet?.summary.availableCents ?? 0) / 100)}</b><small>Gebruik direct voor AI-campagnes of vraag later bankuitbetaling aan.</small></div>
      <div className="dkchips moneyStats">
        <span className="dkc"><label>IN ESCROW</label><b>{eur(escrow.reduce((s, o) => s + o.sellerNet, 0))}</b></span>
        <span className="dkc"><label>GERESERVEERD</label><b>{eur((wallet?.summary.reservedCents ?? 0) / 100)}</b></span>
        <span className="dkc"><label>UITBETAALD 30D</label><b>{eur(paid.filter(o => +new Date(o.createdAt) > d30).reduce((s, o) => s + o.sellerNet, 0))}</b></span>
        <span className="dkc"><label>COMMISSIE 30D</label><b>{eur(paid.filter(o => +new Date(o.createdAt) > d30).reduce((s, o) => s + o.commission, 0))}</b></span>
      </div></section>
      {orders.length === 0 && <Empty title="Nog geen geldstromen" text="Uitbetalingen en escrow-bedragen verschijnen hier per order, netto na 10% commissie." />}
      {orders.length > 0 && <div className="dsec"><h2>Per order</h2><span>NA 10% COMMISSIE</span></div>}
      {orders.map(o => (
        <div key={o.id} className="pay premiumPay">
          <b>{o.itemTitle} · {o.id}{o.partnerRef ? ` · ${o.partnerRef}` : ""}<small>{fmt(o.createdAt)} · {o.status.replaceAll("_", " ").toUpperCase()}</small></b>
          <span className={`flag ${o.status === "paid_out" ? "ok3" : "hot"}`}>{o.status === "paid_out" ? "BETAALD" : "IN ESCROW"}</span>
          <span className="amt2">{eur(o.sellerNet)}</span>
        </div>
      ))}
      <div className="dsec"><h2>Wallet grootboek</h2><span>LAATSTE TRANSACTIES</span></div>
      {(wallet?.ledger ?? []).slice(0, 8).map(tx => <div key={tx.id} className="pay premiumPay"><b>{tx.note ?? tx.type}<small>{new Date(tx.at).toLocaleString("nl-NL")} · {tx.type}</small></b><span className={`flag ${tx.creditAccount.includes(":wallet") ? "ok3" : "hot"}`}>{tx.creditAccount.includes(":wallet") ? "+" : "-"}</span><span className="amt2">{eur(tx.amountCents / 100)}</span></div>)}
      <p className="note">Uitbetaling volgt automatisch zodra de koper de levering bevestigt. Wallettransacties zijn append-only en krijgen een hash-chain voor audit.</p>
    </main>
  );
}
