#!/usr/bin/env bash
set -euo pipefail
BASE="${BEE_BASE:-/home/ubuntu/bitcoin-engine-deploy/current}"
HOME_EXPORT="/home/ubuntu/bee_latest_export.zip"
LEGACY_EXPORT="/home/ubuntu/bee_live_debug_export.zip"
cd "$BASE"

echo "============================================================"
echo "BEE Live Forecast V4.1.10 — one-line update/test/export"
echo "============================================================"

echo "[0/7] Cleaning old mobile exports..."
rm -f /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export*.zip || true

echo "[1/7] Installing live forecast..."
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh

cd "$BASE/live_forecast"
if [ -f ".venv/bin/activate" ]; then
  source ".venv/bin/activate"
elif [ -f "$BASE/.venv/bin/activate" ]; then
  source "$BASE/.venv/bin/activate"
fi

echo "[2/7] Checking version/options..."
python bee_live_forecast_v4_1_paper.py --help | grep -E "test-trade-ntfy|force-notify|export-debug|inspect-live-data" >/dev/null
python - <<'PY'
import re, pathlib
s=pathlib.Path('bee_live_forecast_v4_1_paper.py').read_text()
m=re.search(r'VERSION\s*=\s*"([^"]+)"', s)
print('VERSION:', m.group(1) if m else 'unknown')
PY

echo "[3/7] Validating ntfy topic..."
python - <<'PY'
import json, os, sys
cfg=json.load(open('bee_live_config.json'))
topic=(os.environ.get('BEE_NTFY_TOPIC') or cfg.get('ntfy_topic') or '').strip()
if (not topic) or topic == 'PASTE_PRIVATE_NTFY_TOPIC_HERE' or 'PASTE' in topic.upper() or 'PLACEHOLDER' in topic.upper():
    print('ERROR: ntfy_topic is missing or still placeholder in live_forecast/bee_live_config.json')
    print('Open nano live_forecast/bee_live_config.json and fill ntfy_topic first.')
    sys.exit(2)
print('ntfy topic configured: yes (redacted)')
PY

echo "[4/7] Testing live data fetch..."
python bee_live_forecast_v4_1_paper.py --test-fetch

echo "[5/7] Sending synthetic PAPER TRADE ntfy test..."
python bee_live_forecast_v4_1_paper.py --test-trade-ntfy

echo "[6/7] Running real live once with force-notify to prove server -> phone path..."
python bee_live_forecast_v4_1_paper.py --once --force-notify

echo "[7/7] Creating/overwriting mobile debug export..."
python bee_live_forecast_v4_1_paper.py --export-debug

# Extra safety: if python created timestamped export but did not copy for any reason, copy newest now.
LATEST="$(find "$BASE" /home/ubuntu/bitcoin-engine-deploy/releases -name 'bee_live_debug_export_*.zip' -type f 2>/dev/null | sort | tail -1 || true)"
if [ -n "$LATEST" ] && [ -f "$LATEST" ]; then
  rm -f "$HOME_EXPORT" "$LEGACY_EXPORT" /home/ubuntu/bee_live_debug_export_*.zip 2>/dev/null || true
  cp "$LATEST" "$HOME_EXPORT"
  cp "$LATEST" "$LEGACY_EXPORT"
fi

echo ""
echo "============================================================"
echo "DONE — EXPORT READY"
echo "$HOME_EXPORT"
echo "Termius: Connect via SFTP -> home -> ubuntu -> bee_latest_export.zip"
echo "============================================================"
ls -lah "$HOME_EXPORT" "$LEGACY_EXPORT"
