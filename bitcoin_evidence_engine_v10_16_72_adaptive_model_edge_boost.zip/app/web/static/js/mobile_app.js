const $ = (id)=>document.getElementById(id);
const BEE_APP_VERSION = '10_16_72_adaptive_model_edge_boost';
// V10.16.32: Safari-safe debug export + honest Data/Model cockpit + Time Machine progress. First paint is instant; quick heartbeat loads first; heavy evidence/chart load later.
function authHeaders(){ return {}; }
const fmtUsd = (v)=> v==null || isNaN(v) ? '—' : '$' + Number(v).toLocaleString('nl-NL',{maximumFractionDigits:0});
function currentDisplayedPrice(){ try{ const t=($('priceLabel')&&$('priceLabel').textContent||'').replace(/[^0-9,.-]/g,'').replace(/\./g,'').replace(',','.'); const n=Number(t); return isFinite(n)&&n>1000?n:null; }catch(e){ return null; } }
const fmtPct = (v)=> v==null || isNaN(v) ? '—' : (Number(v)*100).toFixed(1)+'%';
const fmtTs = (ms)=> ms ? new Date(Number(ms)).toLocaleDateString('nl-NL',{day:'2-digit',month:'2-digit',year:'2-digit'}) : '—';
let installPrompt=null;
window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); installPrompt=e; $('installBtn').hidden=false; });
function toast(msg){ const t=$('toast'); if(!t) return; t.textContent=msg; t.hidden=false; clearTimeout(window.__toastTimer); window.__toastTimer=setTimeout(()=>t.hidden=true,3600); }
function hideBoot(){ const b=document.getElementById('bootSplash'); if(b){ b.classList.add('hide'); setTimeout(()=>{ try{b.remove()}catch(e){} },350); } }
function safeSet(id, value){ const el=$(id); if(el) el.textContent=value; }
function cacheSet(k,v){ try{ localStorage.setItem(k, JSON.stringify({t:Date.now(), v})); }catch(e){} }
function cacheGet(k,maxAgeMs=86400000){ try{ const o=JSON.parse(localStorage.getItem(k)||'null'); if(o&&Date.now()-o.t<maxAgeMs) return o.v; }catch(e){} return null; }

async function beeVersionRescue(){
  try{
    const last=localStorage.getItem('bee_app_version');
    if(last!==BEE_APP_VERSION){
      localStorage.setItem('bee_app_version', BEE_APP_VERSION);
      if(window.caches){ const keys=await caches.keys(); await Promise.all(keys.filter(k=>k.indexOf('bee-mobile-')===0 && k!=='bee-mobile-'+BEE_APP_VERSION).map(k=>caches.delete(k))); }
      if('serviceWorker' in navigator){ const regs=await navigator.serviceWorker.getRegistrations(); await Promise.all(regs.map(r=>{ try{return r.update();}catch(e){return null;} })); }
    }
  }catch(e){}
}
beeVersionRescue();

function showDownloadOverlay(title,url,kind,filename){
  try{
    let m=document.getElementById('downloadOverlay');
    if(!m){
      m=document.createElement('div'); m.id='downloadOverlay';
      m.innerHTML='<div class="download-sheet"><button id="downloadCloseBtn" class="download-x">×</button><h3 id="downloadTitle">Download</h3><p id="downloadText">Je bestand staat klaar.</p><a id="downloadDirectBtn" class="primary-action wide" rel="noopener" download>Download bestand</a><button id="downloadCopyBtn" class="secondary-action wide" type="button">Kopieer downloadlink</button><small class="hint">Geen lege pagina meer: de download blijft in de app. Tik op × om terug te gaan.</small></div>';
      document.body.appendChild(m);
      const st=document.createElement('style'); st.textContent='#downloadOverlay{position:fixed;inset:0;z-index:99999;background:rgba(2,7,17,.72);backdrop-filter:blur(10px);display:grid;place-items:end center;padding:18px}.download-sheet{width:min(520px,100%);box-sizing:border-box;border:1px solid rgba(130,165,225,.32);border-radius:28px;background:#0b172d;color:#eef5ff;padding:22px;box-shadow:0 -12px 60px rgba(0,0,0,.45);position:relative}.download-x{position:absolute;right:14px;top:12px;width:42px;height:42px;border-radius:16px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.08);color:#fff;font-size:28px;font-weight:900}.download-sheet h3{margin:2px 50px 8px 0;font-size:22px}.download-sheet p{color:#a9b8d4;line-height:1.45}.download-sheet a,.download-sheet button.secondary-action{display:block;text-align:center;text-decoration:none;margin:14px 0 10px;width:100%;box-sizing:border-box}'; document.head.appendChild(st);
      m.querySelector('#downloadCloseBtn').onclick=()=>{ m.style.display='none'; };
      m.querySelector('#downloadCopyBtn').onclick=async()=>{ try{ await navigator.clipboard.writeText(m.dataset.url||''); toast('Downloadlink gekopieerd'); }catch(e){ toast('Kopiëren niet gelukt'); } };
    }
    m.dataset.url=url;
    m.querySelector('#downloadTitle').textContent=title||'Download klaar';
    m.querySelector('#downloadText').textContent=kind==='zip'?'Je ZIP staat klaar. Download start zonder dat de app naar een lege pagina gaat.': 'Je TXT-log staat klaar. Download start zonder lege pagina.';
    const a=m.querySelector('#downloadDirectBtn'); a.href=url; a.removeAttribute('target'); if(filename) a.setAttribute('download', filename); a.textContent=kind==='zip'?'Download ZIP opnieuw':'Download TXT opnieuw';
    m.style.display='grid';
  }catch(e){}
}

async function stableDownload(url, filename, kind, title){
  const cleanUrl=url+(url.indexOf('?')>=0?'&':'?')+'download_ts='+Date.now();
  sessionLog('frontend_stable_download_start',{url:cleanUrl, filename:filename, kind:kind});
  try{
    const res=await fetch(cleanUrl,{method:'GET',cache:'no-store',credentials:'same-origin',headers:{'Accept': kind==='txt'?'text/plain,*/*':'application/zip,*/*'}});
    if(!res.ok) throw new Error('HTTP '+res.status);
    const blob=await res.blob();
    if(!blob || blob.size<1) throw new Error('Leeg downloadbestand');
    const objectUrl=URL.createObjectURL(blob);
    const a=document.createElement('a');
    a.href=objectUrl; a.download=filename || (kind==='txt'?'bee_session_log.txt':'bee_export.zip');
    a.style.display='none'; document.body.appendChild(a); a.click();
    setTimeout(()=>{ try{URL.revokeObjectURL(objectUrl); a.remove();}catch(e){} },30000);
    showDownloadOverlay(title||'Download klaar', cleanUrl, kind, filename);
    sessionLog('frontend_stable_download_ok',{url:cleanUrl, filename:filename, kind:kind, bytes:blob.size});
    return true;
  }catch(err){
    sessionLog('frontend_stable_download_error',{url:cleanUrl, filename:filename, kind:kind, error:String(err&&err.message||err)});
    showDownloadOverlay((title||'Download klaar')+' · handmatig', cleanUrl, kind, filename);
    toast('Download staat klaar. Tik op de knop in de pop-up; de app blijft open.');
    return false;
  }
}

function cacheRemove(k){ try{ localStorage.removeItem(k); }catch(e){} }
const __inflightApi = new Map();
let __lastSessionLogAt = 0;
let __sessionLogBuffer = [];
function endpointKey(path){ return String(path||'').replace(/[?&]_=\d+/g,''); }
function shouldLogFrontend(event){
  // V10.16.49: log everything important, but do not DDOS our own backend with hundreds of identical abort rows.
  const now=Date.now();
  if(String(event||'').includes('api_error') || String(event||'').includes('chart_draw')){
    if(now-__lastSessionLogAt<2500) return false;
  }
  __lastSessionLogAt=now; return true;
}
function applyCachedLiveProgress(){
  const p=cacheGet('bee_last_live_progress', 7*86400000);
  if(p){ try{ setBootProgressPayload(p); }catch(e){} }
  const st=cacheGet('bee_last_tm_status', 7*86400000);
  if(st){ try{
    const running=(st.status==='running'||st.status==='queued'||st.status==='stalled');
    const completed=(st.status==='completed'||st.phase==='export_ready'||st.export_ready===true);
    if(running){ window.__tmPriorityMode=true; }
    progressFromStatus(st, Number(st.count||1000)||1000, 0);
    if(completed){ setTmProgress(true,'Laatste Random'+(st.count||1000)+' klaar',100,'Resultaat is bewaard op de VPS. Je kunt Download ZIP gebruiken of opnieuw Random1000 draaien.'); }
  }catch(e){} }
}

function applyQuick(data){
  if(!data) return;
  const cached = cacheGet('bee_last_quick', 30*86400000) || cacheGet('bee_last_summary', 30*86400000);
  const rows=Number(data.raw_candles || (data.candle_range&&data.candle_range.rows) || (data.history&&(data.history.stored_rows||data.history.rows)) || 0);
  if((data.served_minimal || data.db_busy) && rows<1000 && cached){ return applyQuick(cached); }
  if(rows>=1000) cacheSet('bee_last_quick', data);
  setApi(data.sync_busy?'loading':'ok', data.sync_busy?'bezig':'online');
  safeSet('versionLabel', data.engine_version||'v10.16.72_adaptive_model_edge_boost');
  if(data.btc_price!=null) safeSet('priceLabel', fmtUsd(data.btc_price));
  const target=Number(data.target_rows || (data.history&&data.history.target_rows) || 70000);
  const pct=Math.min(100, target?rows/target*100:0);
  if(rows>=1000){ safeSet('historyPct', pct.toFixed(1)+'%'); safeSet('historyRows', `${rows.toLocaleString('nl-NL')} / ${target.toLocaleString('nl-NL')} candles`); if($('historyBar')) $('historyBar').style.width=pct+'%'; safeSet('dataRows', rows.toLocaleString('nl-NL')); }
  const nativeOk = !!(data.native_available||data.native_core_available||(data.native&&data.native.available)||(data.native_core&&data.native_core.available));
  if(nativeOk || !(data.served_minimal||data.db_busy)){ safeSet('nativeState', nativeOk?'Actief':'Check'); safeSet('nativeDetail', nativeOk?'C++ cloud core OK':'C++ check loopt'); }
  const tm=data.learning||{}; safeSet('tmTests', Number(tm.time_machine_tests||data.time_machine_tests||0).toLocaleString('nl-NL')); safeSet('tmSnapshots', Number(tm.feature_snapshots||data.time_machine_feature_snapshots||0).toLocaleString('nl-NL')); safeSet('tmSignals', Number(tm.signal_events||data.time_machine_signal_scores||0).toLocaleString('nl-NL'));
  if(data.raw_candles_min_ms || data.raw_candles_max_ms){ safeSet('dataRange', `${fmtTs(data.raw_candles_min_ms)} → ${fmtTs(data.raw_candles_max_ms)}`); }
  hideBoot();
}
function sessionLog(event,payload){
  try{
    if(!shouldLogFrontend(event)) return;
    __sessionLogBuffer.push({event:event,payload:payload||{}, browser_ts:Date.now()});
    if(__sessionLogBuffer.length>60) __sessionLogBuffer.splice(0,__sessionLogBuffer.length-60);
    if(window.__sessionLogFlushTimer) return;
    window.__sessionLogFlushTimer=setTimeout(()=>{
      const batch=__sessionLogBuffer.splice(0,40);
      window.__sessionLogFlushTimer=null;
      if(!batch.length) return;
      try{
        fetch('/api/session-log',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({events:batch}),keepalive:true}).catch(()=>{});
      }catch(e){}
    }, 2500);
  }catch(e){}
}
document.addEventListener('DOMContentLoaded',()=>{ setTimeout(hideBoot, 1200); sessionLog('bee_reliability_first_paint',{}); });
window.addEventListener('load',()=>sessionLog('frontend_page_load',{href:location.href, user_agent:navigator.userAgent, viewport:{w:innerWidth,h:innerHeight}, standalone:!!(window.navigator.standalone || matchMedia('(display-mode: standalone)').matches)}));
document.addEventListener('visibilitychange',()=>sessionLog('frontend_visibility_change',{state:document.visibilityState, href:location.href}));
window.addEventListener('online',()=>sessionLog('frontend_online',{}));
window.addEventListener('offline',()=>sessionLog('frontend_offline',{}));
window.addEventListener('error',(e)=>sessionLog('frontend_js_error',{message:String(e.message||''), source:e.filename, line:e.lineno, col:e.colno}));
window.addEventListener('unhandledrejection',(e)=>sessionLog('frontend_unhandled_rejection',{reason:String(e.reason&&e.reason.message||e.reason||'')}));
async function api(path, opts={}){
  const started=Date.now();
  const key=endpointKey(path);
  if(!opts.noDedupe && __inflightApi.has(key)) return __inflightApi.get(key);
  const runner=(async()=>{
    const attempts=opts.attempts||1; let lastErr=null;
    for(let a=0;a<attempts;a++){
      const useTimeout=opts.timeout!==0; const timeoutMs=opts.timeout||30000;
      const ctrl=useTimeout?new AbortController():null; const to=useTimeout?setTimeout(()=>ctrl.abort(), timeoutMs):null;
      try{
        const clean={...opts}; delete clean.timeout; delete clean.attempts; delete clean.noDedupe;
        const r=await fetch(path,{...clean, signal:ctrl?ctrl.signal:undefined, headers:{'Content-Type':'application/json',...authHeaders(),...(opts.headers||{})}, cache:'no-store'});
        if(!r.ok) throw new Error('HTTP '+r.status);
        const json=await r.json();
        sessionLog('frontend_api_ok',{url:path,method:clean.method||'GET',duration_ms:Date.now()-started});
        return json;
      }catch(e){ lastErr=e; sessionLog('frontend_api_error',{url:path,error:String(e&&e.message||e),duration_ms:Date.now()-started,attempt:a+1, timeout_ms:timeoutMs}); if(a<attempts-1) await new Promise(r=>setTimeout(r, 1200*(a+1))); }
      finally{ if(to) clearTimeout(to); }
    }
    throw lastErr || new Error('request failed');
  })();
  if(!opts.noDedupe) __inflightApi.set(key, runner.finally(()=>__inflightApi.delete(key)));
  return runner;
}
function setApi(state,msg){ const dot=$('apiDot'); dot.className='status-dot '+state; $('apiLabel').textContent=msg; }
function drawChart(points){ try{ sessionLog('frontend_chart_draw',{points:(points||[]).length}); }catch(e){} const c=$('priceChart'); if(!c) return; const dpr=window.devicePixelRatio||1; const rect=c.getBoundingClientRect(); c.width=Math.max(300,Math.floor(rect.width*dpr)); c.height=Math.floor(190*dpr); const ctx=c.getContext('2d'); ctx.scale(dpr,dpr); ctx.clearRect(0,0,rect.width,190); let arr=(points||[]).map(p=>({x:p.time||p.timestamp_ms||p.t, y:Number(p.close ?? p.c ?? p.value)})).filter(p=>isFinite(p.y)&&p.y>1000); arr=arr.sort((a,b)=>Number(a.x||0)-Number(b.x||0)); if(arr.length<2){ ctx.fillStyle='rgba(220,235,255,.55)'; ctx.font='13px -apple-system'; ctx.fillText('Chart wordt geladen…',14,28); return; } const ys=arr.map(p=>p.y).sort((a,b)=>a-b); const q=(r)=>ys[Math.max(0,Math.min(ys.length-1,Math.floor((ys.length-1)*r)))]; let min=q(.02), max=q(.98); const rawMin=ys[0], rawMax=ys[ys.length-1]; if(!isFinite(min)||!isFinite(max)||max<=min){ min=rawMin; max=rawMax; } const margin=(max-min)*0.12||1000; min=Math.max(0,min-margin); max=max+margin; const pad=12, w=rect.width-pad*2, h=166; const sx=(i)=>pad+(i/(arr.length-1))*w; const sy=(y)=>pad+(1-(Math.max(min,Math.min(max,y))-min)/(max-min||1))*h; const grad=ctx.createLinearGradient(0,0,0,190); grad.addColorStop(0,'rgba(24,210,255,.25)'); grad.addColorStop(1,'rgba(24,210,255,0)'); ctx.beginPath(); arr.forEach((p,i)=>{ const x=sx(i), y=sy(p.y); i?ctx.lineTo(x,y):ctx.moveTo(x,y); }); ctx.lineTo(pad+w,188); ctx.lineTo(pad,188); ctx.closePath(); ctx.fillStyle=grad; ctx.fill(); ctx.beginPath(); arr.forEach((p,i)=>{ const x=sx(i), y=sy(p.y); i?ctx.lineTo(x,y):ctx.moveTo(x,y); }); ctx.lineWidth=2; ctx.strokeStyle='#18d2ff'; ctx.stroke(); ctx.fillStyle='rgba(237,245,255,.72)'; ctx.font='11px -apple-system'; ctx.fillText(fmtUsd(rawMax), pad, 16); ctx.fillText(fmtUsd(rawMin), pad, 184); }
function normProb(v){ const n=Number(v); if(!isFinite(n)) return 0.5; return n>1.5 ? Math.max(0,Math.min(1,n/100)) : Math.max(0,Math.min(1,n)); }
function normConf(v){ const n=Number(v); if(!isFinite(n)) return 0; return Math.max(0,Math.min(100, n>100 ? n/100 : n)); }
function normMovePct(v){ const n=Number(v); if(!isFinite(n)) return 0; return Math.max(-80,Math.min(80,n)); }
function forecastCard(item){
  const bull=normProb(item.bullish_probability); const bear=normProb(item.bearish_probability);
  const edgePct=(bull-0.5)*200; const dir=bull>=bear?'UP bias':'DOWN bias';
  const move=normMovePct(item.expected_move_pct); const conf=normConf(item.confidence);
  const strong=(conf>=62 && Math.abs(edgePct)>=8); const weak=(conf<38 || Math.abs(edgePct)<3);
  const cls=bull>=bear?'good':'danger';
  let contrib=[]; try{ const raw=item.contributions_json||item.contributions; const arr=typeof raw==='string'?JSON.parse(raw):raw; if(Array.isArray(arr)) contrib=arr.slice(0,4).map(x=>x.model||x.name||x.id||String(x).slice(0,18)); else if(arr&&typeof arr==='object') contrib=Object.keys(arr).slice(0,4); }catch(e){}
  const quality=strong?'sterk':(weak?'zwak':'medium');
  const why=contrib.length?`<div class="why">${contrib.map(x=>`<em>${x}</em>`).join('')}<em>${quality}</em></div>`:`<div class="why"><em>${quality}</em></div>`;
  let entry=Number(item.entry_price||item.start_price||0);
  if(!isFinite(entry)||entry<=1000) entry=currentDisplayedPrice()||0;
  let target=Number(item.target_price||item.expected_price||0);
  if((!isFinite(target)||target<=1000) && entry>1000) target=entry*(1+move/100);
  const invalid=Number(item.invalidation_price||0);
  const targetUsd=Number(item.target_distance_usd ?? (entry&&target?target-entry:0));
  const targetPct=Number(item.target_distance_pct ?? (entry&&target?(target-entry)/entry*100:move));
  const invUsd=Number(item.invalidation_distance_usd ?? (entry&&invalid?invalid-entry:0));
  const invPct=Number(item.invalidation_distance_pct ?? (entry&&invalid?(invalid-entry)/entry*100:0));
  const econ= entry>1000 ? `<div class="sub">Entry ${fmtUsd(entry)} → Target ${fmtUsd(target)} <b>${targetUsd>=0?'+':'-'}${fmtUsd(Math.abs(targetUsd)).replace('$',' $')}</b> / ${targetPct>=0?'+':''}${targetPct.toFixed(2)}%</div><div class="sub">Invalidatie ${fmtUsd(invalid)} · ${invUsd>=0?'+':'-'}${fmtUsd(Math.abs(invUsd)).replace('$',' $')} / ${invPct>=0?'+':''}${invPct.toFixed(2)}%</div>` : `<div class="sub">Entry wordt geladen · target ${fmtUsd(target)}</div>`;
  return `<div class="forecast-row"><div class="h">${item.horizon||'—'}</div><div><div class="dir ${cls}">${dir} · edge ${edgePct.toFixed(1)}% · move ${move.toFixed(2)}%</div>${econ}${why}</div><div class="conf">${Math.round(conf)}%</div></div>`;
}
function accuracyRow(row){ const hit = row.hitrate==null ? '—' : (Number(row.hitrate)*100).toFixed(1)+'%'; return `<div class="accuracy-row"><div><b>${row.horizon}</b><br><span>${row.total||0} samples · score ${row.avg_score==null?'—':Number(row.avg_score).toFixed(1)}</span></div><b>${hit}</b></div>`; }

function tmHorizonCard(r){
  const total=Number(r.total||0), wins=Number(r.wins||0), partials=Number(r.partials||0), fails=Number(r.fails||0);
  const wp=total?wins/total*100:0, pp=total?partials/total*100:0, fp=total?fails/total*100:0;
  const hwp=Number(r.hitrate_with_partial||0)*100;
  return `<div class="tm-score-card"><div class="tm-score-head"><b>${r.horizon}</b><span>${total.toLocaleString('nl-NL')} tests · ${(Number(r.hitrate||0)*100).toFixed(1)}% exact</span></div><div class="tm-score-bars"><i><em style="width:${wp}%"></em></i><i><em style="width:${pp}%"></em></i><i><em style="width:${fp}%"></em></i></div><div class="tm-score-meta"><span>win ${wp.toFixed(0)}%</span><span>partial ${pp.toFixed(0)}%</span><span>win+partial ${hwp.toFixed(1)}%</span></div></div>`;
}
function renderTmVisual(v){
  const box=$('tmVisualCards'); if(!box) return;
  if(!v||!v.ok||!(v.horizons||[]).length){ box.innerHTML='<p class="hint">Nog geen Time Machine resultaat. Draai Random1000; daarna verschijnt hier het bewijs per horizon.</p>'; safeSet('tmVisualSummary','geen batch'); return; }
  const s=v.summary||{}; const total=Number(s.total||0); safeSet('tmVisualSummary', `${total.toLocaleString('nl-NL')} tests · ${((Number(s.hitrate_with_partial||0))*100).toFixed(1)}% incl. partial`);
  box.innerHTML=(v.horizons||[]).map(tmHorizonCard).join('');
  const rb=$('tmRegimeCards'); if(rb){
    const regimes=(v.regimes||[]).slice(0,7).map(r=>`<div class="tm-insight"><b>${r.regime||'unknown'} · ${r.horizon||''}</b><span>${Number(r.sample||0).toLocaleString('nl-NL')} samples · win+partial ${(Number(r.hitrate_with_partial||0)*100).toFixed(1)}% · score ${Number(r.avg_score||0).toFixed(1)}</span></div>`);
    const sigs=(v.top_signals||[]).slice(0,5).map(r=>`<div class="tm-insight"><b>${r.signal_label||r.signal_key}</b><span>${r.horizon||''} · ${r.regime||''} · ${Number(r.total||0).toLocaleString('nl-NL')} samples · ${(Number(r.hitrate_with_partial||0)*100).toFixed(1)}% win+partial</span></div>`);
    rb.innerHTML=[...regimes,...sigs].join('') || '<p class="hint">Regime learning wordt gevuld na Random1000.</p>';
    safeSet('tmRegimeSummary', `${(v.regimes||[]).length} regimes · ${(v.top_signals||[]).length} signalen`);
  }
}

function renderFeaturePairs(pairs){
  const box=$('tmPairCards'); if(!box) return;
  const rows=(pairs||[]).slice(0,10);
  box.innerHTML = rows.map(r=>{
    const edge=Number(r.edge||0)*100; const hwp=Number(r.hitrate_with_partial||0)*100;
    const title=`${r.feature_a}:${r.bucket_a} + ${r.feature_b}:${r.bucket_b}`;
    const cls=edge>=0?'active':'partial';
    return `<div class="tm-insight"><b>${title}</b><span>${r.horizon||''} · ${r.regime||''} · ${Number(r.sample||0).toLocaleString('nl-NL')} samples · win+partial ${hwp.toFixed(1)}% · edge ${edge.toFixed(1)}%</span></div>`;
  }).join('') || '<p class="hint">Nog geen combinatie-learning. Draai Random1000 en herbereken Learning.</p>';
  safeSet('tmPairSummary', rows.length?`${rows.length} sterke combinaties`:'geen pairs');
}
async function loadHistoricalTwins(horizon='1h'){
  const box=$('historicalTwinsBox'); if(!box) return;
  box.innerHTML='<p class="hint">Historical twins laden…</p>';
  try{
    const res=await api('/api/historical-twins/latest?horizon='+encodeURIComponent(horizon)+'&top_n=10',{timeout:30000,attempts:1});
    if(!res||!res.ok) throw new Error((res&&res.error)||'twins error');
    const matches=res.matches||[];
    safeSet('historicalTwinsSummary', `${res.evidence_count||0} matches · median move ${Number(res.expected_move_pct||0).toFixed(2)}%`);
    box.innerHTML=matches.map(m=>{
      const mv=Number(m.future_move_pct||0); const cls=mv>=0?'active':'partial';
      return `<div class="tm-insight"><b>${m.date||'historisch moment'} · ${Number(m.similarity_pct||0).toFixed(0)}% match</b><span>Prijs ${fmtUsd(m.close)} · daarna ${mv>=0?'+':''}${mv.toFixed(2)}% (${horizon})</span></div>`;
    }).join('') || '<p class="hint">Geen betrouwbare twins gevonden voor deze horizon.</p>';
  }catch(err){ box.innerHTML='<p class="hint">Historical twins konden niet geladen worden: '+err.message+'</p>'; }
}

async function loadTmVisual(){ try{ const v=await api('/api/time-machine/visual-summary',{timeout:9000,attempts:1}); renderTmVisual(v); renderFeaturePairs(v.pair_weights||[]); }catch(_){ } }
let __forecastEnsureStarted=false;
async function ensureForecastIfEmpty(items){
  if((items||[]).length || __forecastEnsureStarted) return;
  __forecastEnsureStarted=true;
  if($('forecastCards')) $('forecastCards').innerHTML='<div class="forecast-empty"><b>Forecast wordt automatisch opgebouwd…</b>De app maakt zelf een nieuwe 7-horizon forecast uit de lokale DuckDB-cache.</div>';
  if($('forecastFull')) $('forecastFull').innerHTML='<div class="forecast-empty"><b>Forecast wordt automatisch opgebouwd…</b>Even wachten; hij blijft niet meer leeg hangen.</div>';
  try{ await api('/api/forecast/ensure',{method:'POST',body:'{}',timeout:8000,attempts:1}); setTimeout(loadSummary, 9000); }catch(_){ setTimeout(()=>{__forecastEnsureStarted=false;},60000); }
}

function syncStateLabel(states){ if(!Array.isArray(states)||!states.length) return '—'; const preferred=['historical_memory','sync_phase','startup_sync_status','manual_sync_status','external_evidence_backfill']; for(const k of preferred){ const hit=states.find(s=>s.key===k); if(hit) return `${hit.key}: ${hit.value}`; } return `${states[0].key}: ${states[0].value}`; }

function dataStatusLabel(s){ return s==='active'?'actief':(s==='partial'?'deels':'mist'); }
function renderExternalData(ed){
  const box=$('externalDataList'); if(!box) return;
  const rows=(ed&&ed.rows)||[];
  const sum=(ed&&ed.summary)||{};
  const f=(ed&&ed.features)||{};
  $('externalDataSummary') && ($('externalDataSummary').textContent=`${sum.active||0} actief · ${sum.partial||0} deels · ${sum.missing||0} mist`);
  box.innerHTML = rows.map(r=>`<div><span>${r.label}</span><b>${Number(r.rows||0).toLocaleString('nl-NL')} · ${dataStatusLabel(r.status)}</b></div>`).join('') || '<p class="hint">Nog geen externe datasources gemeten.</p>';
  const fb=$('featureEvidenceSummary'); if(fb){ fb.innerHTML = `<div><span>Feature rows</span><b>${Number(f.feature_rows||0).toLocaleString('nl-NL')}</b></div><div><span>Funding/OI rows</span><b>${Number(f.funding_rate_rows||0).toLocaleString('nl-NL')} / ${Number(f.open_interest_rows||0).toLocaleString('nl-NL')}</b></div><div><span>Orderflow rows</span><b>${Number(f.taker_rows||0).toLocaleString('nl-NL')}</b></div><div><span>Sentiment/on-chain</span><b>${Number(f.fear_greed_rows||0).toLocaleString('nl-NL')} / ${Number(f.mvrv_rows||0).toLocaleString('nl-NL')}</b></div>`; }
  renderProviderCockpit(rows);
}
function renderProviderCockpit(rows){
  const box=$('providerCockpit'); if(!box) return;
  const groups={}; (rows||[]).forEach(r=>{ const g=r.group||r.source||'overig'; groups[g]=groups[g]||{rows:0,active:0,partial:0,missing:0}; groups[g].rows+=Number(r.rows||0); groups[g][r.status==='active'?'active':(r.status==='partial'?'partial':'missing')]++; });
  const labels={core_price:'Binance Spot', futures:'Futures', orderflow:'Orderflow', orderbook:'Orderbook', sentiment:'Sentiment', cross_exchange:'Exchanges', onchain:'On-chain'};
  const html=Object.keys(groups).sort().map(k=>{ const g=groups[k]; const status=g.active?'active':(g.partial?'proxy':'missing'); return `<div class="data-pill"><span>${labels[k]||k}</span><b>${Number(g.rows||0).toLocaleString('nl-NL')}</b><small>${g.active} actief · ${g.partial} deels · ${g.missing} mist</small></div>`; }).join('');
  box.innerHTML = html || '<p class="hint">Providerstatus wordt geladen…</p>';
  $('providerSummary') && ($('providerSummary').textContent = Object.keys(groups).length ? `${Object.keys(groups).length} groepen` : 'geen data');
}
function renderModelStatus(ms){
  const box=$('modelCockpit'); if(!box) return;
  const rows=(ms&&ms.rows)||[]; const sum=(ms&&ms.summary)||{};
  $('modelSummary') && ($('modelSummary').textContent=`${sum.active||0} actief · ${sum.proxy||0} proxy · ${sum.missing||0} mist`);
  box.innerHTML = rows.map(m=>{ const cls=m.status==='active'?'active':(m.status==='proxy'?'proxy':(m.status==='partial'||m.status==='live_only'?'proxy':'missing')); const txt=m.status==='active'?'ACTIEF':(m.status==='partial'?'DEELS':(m.status==='live_only'?'LIVE':(m.status==='proxy'?'PROXY':'MIST'))); return `<div class="model-row"><div><b>${m.name||m.id}</b><span>${m.id} · ${m.group||'model'} · ${m.source||''} · ${Number(m.rows||0).toLocaleString('nl-NL')} rows</span></div><em class="badge ${cls}">${txt}</em></div>`; }).join('') || '<p class="hint">Modelstatus wordt geladen…</p>';
}


function renderForecastIntelligence(ad, tm){
  const box=$('forecastIntelBox'); if(!box) return;
  const pairs=(ad&&ad.pair_weights||[]).concat((tm&&tm.pair_weights||[]));
  const models=(ad&&ad.model_weights||[]).concat((tm&&tm.model_weights||[]));
  const features=(ad&&ad.feature_weights||[]).concat((tm&&tm.feature_weights||[]));
  const bestPairs=pairs.filter(r=>Number(r.sample||0)>=20).slice().sort((a,b)=>(Number(b.quality||0)-Number(a.quality||0))||(Number(b.edge||0)-Number(a.edge||0))).slice(0,5);
  const bestModels=models.filter(r=>Number(r.sample||0)>=20).slice().sort((a,b)=>(Number(b.quality||0)-Number(a.quality||0))||(Number(b.hitrate_with_partial||0)-Number(a.hitrate_with_partial||0))).slice(0,4);
  const bestFeatures=features.slice().sort((a,b)=>Number(b.weight||0)-Number(a.weight||0)).slice(0,3);
  const rows=[];
  bestPairs.forEach(r=>rows.push(`<div class="tm-insight"><b>${r.feature_a||''}:${r.bucket_a||''} + ${r.feature_b||''}:${r.bucket_b||''}</b><span>${r.horizon||''} · ${r.regime||''} · sample ${Number(r.sample||0).toLocaleString('nl-NL')} · edge ${(Number(r.edge||0)*100).toFixed(1)}% · weight ${Number(r.weight||0).toFixed(2)}</span></div>`));
  bestFeatures.forEach(r=>rows.push(`<div class="tm-insight"><b>Feature weight · ${r.dimension||r.feature||'feature'}</b><span>weight ${Number(r.weight||0).toFixed(2)} · sample ${Number(r.sample||0).toLocaleString('nl-NL')} · quality ${Number(r.quality||0).toFixed(2)}</span></div>`));
  bestModels.forEach(r=>rows.push(`<div class="tm-insight"><b>Model · ${r.model_id||r.model||'model'} ${r.horizon?('· '+r.horizon):''}</b><span>hitrate ${(Number(r.hitrate_with_partial||r.hitrate||0)*100).toFixed(1)}% · weight ${Number(r.weight||0).toFixed(2)} · sample ${Number(r.sample||0).toLocaleString('nl-NL')}</span></div>`));
  box.innerHTML=rows.join('') || '<p class="hint">Nog geen Adaptive Intelligence. Draai Random1000 en herbereken Learning.</p>';
  safeSet('forecastIntelSummary', bestPairs.length?`${bestPairs.length} actieve combinaties`:'wacht op learning');
}
async function loadForecastIntelligence(){
  try{
    const ad=await api('/api/adaptive-learning/status',{timeout:30000,attempts:1});
    let tm=null; try{ tm=await api('/api/time-machine/visual-summary',{timeout:12000,attempts:1}); }catch(e){}
    if(ad&&ad.ok) renderForecastIntelligence(ad, tm);
  }catch(e){}
}

function renderAdaptiveLearning(ad){
  const box=$('adaptiveLearningBox'); if(!box) return;
  const sum=(ad&&ad.summary)||{};
  const fw=(ad&&ad.feature_weights)||[];
  const mw=(ad&&ad.model_weights)||[];
  const pw=(ad&&ad.pair_weights)||[];
  $('adaptiveSummary') && ($('adaptiveSummary').textContent=`${sum.feature_dimensions||0} features · ${sum.model_dimensions||0} modellen · ${sum.pair_dimensions||pw.length||0} combinaties`);
  const topF=fw.slice(0,8).map(r=>`<div class="model-row"><div><b>${r.dimension||'feature'}</b><span>weight ${Number(r.weight||0).toFixed(3)} · sample ${Number(r.sample||0).toLocaleString('nl-NL')} · quality ${Number(r.quality||0).toFixed(3)}</span></div><em class="badge active">LEERT</em></div>`);
  const topM=mw.slice(0,5).map(r=>`<div class="model-row"><div><b>${r.model_id||'model'} · ${r.horizon||''}</b><span>weight ${Number(r.weight||0).toFixed(3)} · hitrate ${(Number(r.hitrate||0)*100).toFixed(1)}% · sample ${Number(r.sample||0).toLocaleString('nl-NL')}</span></div><em class="badge proxy">DARWIN</em></div>`);
  const topP=pw.slice(0,6).map(r=>`<div class="model-row"><div><b>${r.feature_a||''}:${r.bucket_a||''} + ${r.feature_b||''}:${r.bucket_b||''}</b><span>${r.horizon||''} · edge ${(Number(r.edge||0)*100).toFixed(1)}% · sample ${Number(r.sample||0).toLocaleString('nl-NL')} · weight ${Number(r.weight||0).toFixed(3)}</span></div><em class="badge active">COMBO</em></div>`);
  box.innerHTML = [...topF, ...topP, ...topM].join('') || '<p class="hint">Nog geen adaptive weights. Draai Random1000 en wacht tot export klaar is.</p>';
}

async function loadAdaptiveLearning(){
  try{ const ad=await api('/api/adaptive-learning/status',{timeout:30000,attempts:1}); if(ad&&ad.ok) renderAdaptiveLearning(ad); }catch(_){ }
}


function statusWord(st){
  if(st==='active'||st==='done'||st==='complete'||st==='current') return 'klaar';
  if(st==='provider_limited_current') return 'provider-limiet · klaar';
  if(st==='provider_limited') return 'provider-limiet';
  if(st==='gap_repair_needed') return 'gap-repair';
  if(st==='stuck') return 'vast';
  if(st==='error') return 'fout';
  if(st==='partial'||st==='loading') return 'laden';
  if(st==='api_key_needed') return 'API-key';
  if(st==='missing') return 'mist';
  return st||'—';
}
function setBootProgressPayload(p){
  if(!p||!p.ok) return;
  let pct=Math.max(0,Math.min(100,Number(p.overall_pct||0)));
  const coreReady=(p.history&&(p.history.complete||Number(p.history.rows||p.history.stored_rows||0)>=69000)) && (p.native&&p.native.available) && !p.sync_busy;
  if(coreReady && pct>=90) pct=100;
  safeSet('bootProgressPct', Math.round(pct)+'%');
  safeSet('bootProgressTitle', pct>=99?'Tool klaar':'Tool laadt op achtergrond');
  if($('bootProgressBar')) $('bootProgressBar').style.width=pct+'%';
  const steps=p.boot_steps||[];
  const stepBox=$('bootStepList');
  if(stepBox){ stepBox.innerHTML=steps.map(x=>`<div><span>${x.label||x.key}</span><b>${Math.round(Number(x.pct||0))}%</b><em>${statusWord(x.status)}${x.detail?' · '+x.detail:''}</em></div>`).join('') || '<div><span>Status</span><b>—</b></div>'; }
  const ex=p.external||{}; const epct=Math.max(0,Math.min(100,Number(ex.overall_pct||0)));
  safeSet('liveDataProgressPct', Math.round(epct)+'%');
  if($('liveDataProgressBar')) $('liveDataProgressBar').style.width=epct+'%';
  if($('liveDataProgressDetail')) $('liveDataProgressDetail').textContent = `Externe evidence warehouse: ${Math.round(epct)}% indicatief · ${p.phase||'idle'}`;
  const list=$('providerProgressList');
  if(list){
    const providers=(ex.providers||[]).slice(0,14);
    list.innerHTML = providers.map(r=>{ const rp=Math.max(0,Math.min(100,Number(r.coverage_pct||0))); return `<div class="provider-progress-row"><div class="r1"><b>${r.label}</b><span>${Number(r.rows||0).toLocaleString('nl-NL')} / ${Number(r.target_rows||0).toLocaleString('nl-NL')} · ${statusWord(r.status)}</span></div><div class="mini"><i style="width:${rp}%"></i></div><small>${r.source||''} · ${r.metric||''}</small></div>`; }).join('') || '<p class="hint">Providerstatus wordt geladen…</p>';
  }
}
let __bgProgressBusy=false;
async function loadBackgroundProgress(){
  if(__bgProgressBusy) return;
  __bgProgressBusy=true;
  try{ const p=await api('/api/mobile/live-progress',{timeout:10000,attempts:1}); cacheSet('bee_last_live_progress',p); setBootProgressPayload(p); }
  catch(_){ const p=cacheGet('bee_last_live_progress',7*86400000); if(p) setBootProgressPayload(p); }
  finally{ __bgProgressBusy=false; }
}

function healthToMobile(data){
  return {
    ok: !!data.ok, engine_version: data.engine_version, api_status:'ok', sync_busy:false,
    btc_price:null, history:data.history||{}, native:data.native_core||data.native||{},
    learning:{time_machine_tests:data.time_machine_tests||0,time_machine_batches:data.time_machine_batches||0,feature_snapshots:data.time_machine_feature_snapshots||0,signal_events:data.time_machine_signal_scores||0},
    candle_range:{from_ms:data.raw_candles_min_ms,to_ms:data.raw_candles_max_ms,rows:data.raw_candles||0},
    latest_items:[], accuracy:[], sync_state:[]
  };
}
async function loadEvidenceStatus(){
  try{ const e=await api('/api/mobile/evidence-status',{timeout:30000,attempts:1}); if(e&&e.ok){ renderExternalData(e.external_data); renderModelStatus(e.model_status); }
    loadAdaptiveLearning(); }catch(_){ /* evidence status is optional */ }
}
async function loadSummary(){
  try{
    let data;
    try{ data=await api('/api/mobile/status-fast',{timeout:30000,attempts:1}); }
    catch(_){
      try{ data=await api('/api/health',{timeout:4500,attempts:1}); data=healthToMobile(data); }
      catch(__){ data=await api('/api/mobile/summary',{timeout:30000,attempts:1}); }
    }
    if(!data.ok) throw new Error(data.error||'summary error');
    const hist=data.history||{}; const cr=data.candle_range||{};
    let rows=Number(hist.stored_rows ?? hist.rows ?? cr.rows ?? 0); let target=Number(hist.target_rows ?? 70000);
    if((data.served_minimal||data.db_busy) && rows<1000){ const cached=cacheGet('bee_last_summary',30*86400000)||cacheGet('bee_last_quick',30*86400000); if(cached){ data=cached; rows=Number(((data.history||{}).stored_rows) ?? ((data.history||{}).rows) ?? ((data.candle_range||{}).rows) ?? data.raw_candles ?? 0); target=Number(((data.history||{}).target_rows) ?? data.target_rows ?? 70000); } }
    setApi(data.sync_busy?'loading':'ok', data.sync_busy?'bezig':'online');
    $('versionLabel').textContent=data.engine_version||'Cloud Mobile App';
    if(data.btc_price!=null) $('priceLabel').textContent=fmtUsd(data.btc_price);
    const pct=Math.min(100, target? rows/target*100:0);
    $('historyPct').textContent=pct.toFixed(1)+'%'; $('historyRows').textContent=`${rows.toLocaleString('nl-NL')} / ${target.toLocaleString('nl-NL')} candles`; $('historyBar').style.width=pct+'%';
    if((data.native&&data.native.available) || !(data.served_minimal||data.db_busy)){ $('nativeState').textContent=(data.native&&data.native.available)?'Actief':'Check'; $('nativeDetail').textContent=(data.native&&data.native.available)?'C++ cloud core OK':'C++ check loopt'; }
    const items=data.latest_items||[];
    if($('forecastCount')) $('forecastCount').textContent=items.length?`${items.length} items`:'geen run';
    if($('forecastCards')) $('forecastCards').innerHTML=items.slice(0,4).map(forecastCard).join('') || '<div class="forecast-empty"><b>Nog geen forecast zichtbaar.</b>Ik start automatisch een nieuwe forecast vanuit de cache.</div>';
    if($('forecastFull')) $('forecastFull').innerHTML=items.map(forecastCard).join('') || '<div class="forecast-empty"><b>Forecast leeg.</b>Automatische forecast wordt gestart; je hoeft niet meer handmatig op Sync + Forecast te drukken.</div>';
    ensureForecastIfEmpty(items);
    const learn=data.learning||{};
    $('tmTests').textContent=(learn.time_machine_tests||0).toLocaleString('nl-NL'); $('tmSnapshots').textContent=(learn.feature_snapshots||0).toLocaleString('nl-NL'); $('tmSignals').textContent=(learn.signal_events||0).toLocaleString('nl-NL');
    if($('accuracyList')) $('accuracyList').innerHTML=(data.accuracy||[]).map(accuracyRow).join('') || '<p class="hint">Nog geen accuracy samples.</p>';
    loadTmVisual();
    $('dataRows').textContent=((data.candle_range||{}).rows||0).toLocaleString('nl-NL'); $('dataRange').textContent=`${fmtTs((data.candle_range||{}).from_ms)} → ${fmtTs((data.candle_range||{}).to_ms)}`; $('syncStateLabel').textContent=syncStateLabel(data.sync_state);
    renderExternalData(data.external_data);
    cacheSet('bee_last_summary', data);
    window.__summaryErrorShown=false;
  }catch(err){
    // Quiet retry: the server may be doing external backfill or Random1000.
    // V10.16.48: during Random1000, do not switch the whole app back to "herladen".
    // That made the Machine tab feel stuck even while the backend job was progressing.
    const tmActive=!!localStorage.getItem('bee_active_tm_job_id');
    if(!tmActive) setApi('loading','herladen');
    else setApi('ok','Time Machine draait');
    sessionLog('frontend_summary_error',{error:String(err&&err.message||err), tm_active:tmActive});
    if(!window.__summaryErrorShown && !tmActive){ toast('Status wordt op de achtergrond bijgewerkt; ik probeer automatisch opnieuw.'); window.__summaryErrorShown=true; }
  }
}
let __chartBusy=false;
async function loadChart(){
  if(__chartBusy) return; __chartBusy=true;
  try{ const data=await api('/api/mobile/chart?limit=720',{timeout:30000,attempts:1}); const pts=data.points || data.items || data.candles || []; if(pts&&pts.length){ cacheSet('bee_last_chart_points',pts); drawChart(pts); } else { const last=cacheGet('bee_last_chart_points',7*86400000); if(last&&last.length) drawChart(last); } }
  catch(err){ const last=cacheGet('bee_last_chart_points',7*86400000); if(last&&last.length) drawChart(last); sessionLog('frontend_chart_error',{error:String(err&&err.message||err), cached_points:(last||[]).length}); }
  finally{ __chartBusy=false; }
}
async function postAction(path,label){ toast(label+' gestart…'); setApi('loading','bezig'); await loadBackgroundProgress(); try{ const res=await api(path,{method:'POST',body:'{}',timeout:0}); toast(res.message || res.reason || label+' OK'); await loadSummary(); await loadBackgroundProgress(); }catch(err){ toast(label+' draait mogelijk nog; status blijft live zichtbaar.'); await loadBackgroundProgress(); } }
document.querySelectorAll('.bottom-tabs button').forEach(btn=>btn.addEventListener('click',()=>{ document.querySelectorAll('.bottom-tabs button').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); const target=btn.dataset.target; document.querySelectorAll('.mobile-page').forEach(p=>p.classList.toggle('active',p.dataset.page===target)); window.scrollTo({top:0,behavior:'smooth'}); }));
$('installBtn').addEventListener('click', async()=>{ if(installPrompt){ installPrompt.prompt(); await installPrompt.userChoice; installPrompt=null; } else { toast('iPhone: open Delen → Zet op beginscherm.'); } });
$('syncBtn').addEventListener('click',()=>postAction('/api/sync/background','Sync + Forecast'));
$('historyBtn').addEventListener('click',()=>postAction('/api/historical-memory/backfill?mode=daemon','History check'));

let tmProgressTimer=null;
let tmProgressLocal=0;
let __lastTmStatusPollAt=0;
let __tmCompletionLocked=false;
function setTmProgress(visible, title, pct, detail){
  const card=$('tmProgressCard'); if(!card) return;
  card.hidden=!visible;
  if(title) safeSet('tmProgressTitle', title);
  if(pct!=null){ const p=Math.max(0,Math.min(100,Number(pct)||0)); safeSet('tmProgressPct', Math.round(p)+'%'); if($('tmProgressBar')) $('tmProgressBar').style.width=p+'%'; }
  if(detail) $('tmProgressDetail').innerHTML=detail;
}
function stopTmProgressTimer(){ if(tmProgressTimer){ clearInterval(tmProgressTimer); tmProgressTimer=null; } }
function startLocalProgress(n){
  stopTmProgressTimer(); tmProgressLocal=2; const start=Date.now();
  setTmProgress(true, 'Random'+n+' wordt gestart…', tmProgressLocal, 'Systeem klaar. Batch wordt op de VPS gestart; resultaten verschijnen zodra de backend tests schrijft.');
  tmProgressTimer=setInterval(()=>{
    const elapsed=(Date.now()-start)/1000;
    // V10.16.68: geen fake 95% meer. De vorige fallback liep te snel naar 95%,
    // terwijl de native/persist fase nog bezig kon zijn. Daardoor leek TM vast.
    // Lokale fallback blijft laag; alleen backend-status/completion mag 90-100% zetten.
    const cap=n>=1000?82:90;
    const estimated=Math.min(cap, 4 + elapsed*(n>=1000?0.22:1.2));
    tmProgressLocal=Math.max(tmProgressLocal||0, estimated);
    setTmProgress(true, 'Random'+n+' bezig…', tmProgressLocal, `Systeem klaar · Random${n} batch draait op VPS · ${Math.round(elapsed)} sec verstreken`);
  },2000);
}
function progressFromStatus(st, n, beforeTests){
  const expected=Number(st.expected_tests||n*7||0);
  // Also accept /api/mobile/live-progress payload shape.
  if(st && st.time_machine && !st.cumulative){ st={...st.time_machine, cumulative:{tests:st.time_machine.tests, feature_snapshots:st.time_machine.snapshots, signal_scores:st.time_machine.signals}, phase:(st.time_machine.current_job_parsed&&st.time_machine.current_job_parsed.phase)||'processing'}; }
  const cumulative=st&&st.cumulative||{};
  const tests=Number(st.tests_written||cumulative.tests||0);
  const snap=Number(st.snapshots_written||cumulative.feature_snapshots||0);
  const sig=Number(st.signals_written||cumulative.signal_scores||0);
  const phase=String(st.phase||st.status||'processing');
  const status=String(st.status||'');
  const completed=(status==='completed'||phase==='export_ready'||st.export_ready===true);
  let pct=Number(st.progress_pct||0);
  if(completed){
    pct=100;
    tmProgressLocal=100;
    try{ localStorage.removeItem('bee_active_tm_job_id'); }catch(e){}
  } else if(!pct){
    pct=Math.min(98, Math.max(tmProgressLocal||0, (tests/Math.max(1,expected))*70 + Math.min(20,(snap/Math.max(1,expected))*20) + (sig>0?6:0)));
  }
  // V10.16.70: backend completion is absolute truth. The old code referenced `phase`
  // before declaration, so Safari could throw, ignore the completed status, and keep
  // showing the stale local 72/82/95% card even while Termius showed 100% completed.
  if(!completed) pct=Math.max(Math.min(Number(tmProgressLocal||0),82), pct);
  tmProgressLocal=completed ? 100 : Math.max(Number(tmProgressLocal||0), pct);
  const label=completed?'klaar':phase;
  setTmProgress(true, `Random${n}: ${label}`, pct, `<b>${tests.toLocaleString('nl-NL')} / ${expected.toLocaleString('nl-NL')}</b> horizon-tests · snapshots ${snap.toLocaleString('nl-NL')} · signals ${sig.toLocaleString('nl-NL')}${st.download_url||st.export_ready?' · export klaar':''}${st.error?' · fout: '+st.error:''}`);
}
async function runRandomBatch(n){
  try{ const rd=await loadTimeMachineReady(); if(rd && rd.random1000_ready===false){ toast('Time Machine is nog niet klaar: '+(rd.reason||'wacht op data/native core')); return; } }catch(e){}
  window.__tmPriorityMode=true;
  toast('Random'+n+' gestart. Je ziet nu live voortgang onder de knoppen.'); sessionLog('frontend_tm_random_clicked',{count:n});
  let jobId=null;
  let beforeTests=0;
  try{ const s=await api('/api/mobile/status-fast',{timeout:6000}); beforeTests=Number(((s.learning||{}).time_machine_tests)||0); }catch(_){ }
  startLocalProgress(n);
  try{
    const res=await api('/api/time-machine/random-tests/background',{method:'POST',body:JSON.stringify({count:n}),timeout:30000,attempts:1});
    jobId=res.job_id||res.batch_id||null; try{ localStorage.setItem('bee_active_tm_job_id', jobId||''); }catch(e){}
    setTmProgress(true, 'Random'+n+' gestart', 8, 'Batch draait nu op de VPS. Tests/snapshots/signals worden apart gevolgd; export komt na completion.');
    toast(res.message || ('Random'+n+' gestart'));
  }catch(err){
    stopTmProgressTimer();
    setTmProgress(true, 'Random'+n+' status controleren…', Math.max(35,tmProgressLocal||35), 'Startbevestiging duurde te lang. Systeem is klaar; ik volg nu de laatst bekende backend-batch.');
    toast('Random'+n+' draait mogelijk nog; ik blijf status controleren…');
  }
  for(let i=0;i<240;i++){
    await new Promise(r=>setTimeout(r,2500));
    try{
      const path='/api/time-machine/random-status'+(jobId?('?job_id='+encodeURIComponent(jobId)):'' );
      const st=await api(path,{timeout:20000,attempts:1});
      cacheSet('bee_last_tm_status', st); progressFromStatus(st,n,beforeTests);
      // V10.16.48: do not reload full Home/chart state every poll; keep Machine stable during long runs.
      const expected=Number(st.expected_tests||n*7||0);
      const tests=Number(st.tests_written||((st.cumulative||{}).tests)||0);
      const snapshots=Number(st.snapshots_written||((st.cumulative||{}).feature_snapshots)||0);
      const completed=(st.status==='completed' || st.phase==='export_ready' || st.export_ready===true || (expected && tests>=expected && snapshots>=expected));
      if(st.status==='error'){ stopTmProgressTimer(); setTmProgress(true,'Random'+n+' fout',100,st.error||'Backend gaf een fout terug. Maak debug export.'); toast('Random'+n+' fout. Maak debug export.'); return; }
      if(completed){
        stopTmProgressTimer();
        tmProgressLocal=100;
        setTmProgress(true,'Random'+n+' klaar',100,`Volledig opgeslagen: ${tests.toLocaleString('nl-NL')} tests, ${snapshots.toLocaleString('nl-NL')} snapshots, export klaar.`);
        toast('Random'+n+' volledig opgeslagen. Download ZIP is klaar.');
        sessionLog('frontend_tm_random_completed',{count:n, tests:tests, snapshots:snapshots, status:st.status, phase:st.phase}); setTimeout(()=>{ loadSummary().catch(()=>{}); loadTmVisual().catch(()=>{}); }, 1200);
        try{ localStorage.removeItem('bee_active_tm_job_id'); }catch(e){}
        window.__tmPriorityMode=false;
        setTimeout(()=>setTmProgress(false),12000);
        return;
      }
    }catch(_){ /* keep polling */ }
  }
  stopTmProgressTimer();
  window.__tmPriorityMode=false;
  setTmProgress(true,'Statuscheck gestopt',96,'De backend kan nog draaien. Open Data → Debug Export als dit blijft staan.');
}
$('random100Btn')?.addEventListener('click',()=>runRandomBatch(100));
$('random1000Btn')?.addEventListener('click',()=>runRandomBatch(1000));
$('tmExportBtn')?.addEventListener('click',async()=>{
  let url='/api/time-machine/export/download?ts='+Date.now();
  try{
    toast('Time Machine ZIP zoeken…');
    const info=await api('/api/time-machine/export/latest',{timeout:8000,attempts:1});
    if(info&&info.download_url){ url=info.download_url+(info.download_url.includes('?')?'&':'?')+'ts='+Date.now(); }
  }catch(err){}
  await stableDownload(url, 'bee_time_machine_export.zip', 'zip', 'Time Machine ZIP klaar');
});
$('tmResetBtn')?.addEventListener('click',async()=>{
  if(!confirm('Time Machine run/progress wissen? Dit wist tests/snapshots/signals/jobs, maar NIET candles, data warehouse, forecast of adaptive learning.')) return;
  toast('Time Machine reset…');
  try{ localStorage.removeItem('bee_active_tm_job_id'); cacheRemove('bee_last_tm_status'); }catch(e){}
  stopTmProgressTimer(); setTmProgress(false); safeSet('tmTests','0'); safeSet('tmSnapshots','0'); safeSet('tmSignals','0');
  try{
    const res=await api('/api/time-machine/reset',{method:'POST',body:JSON.stringify({delete_exports:false, reset_learning:false, background:true}),timeout:12000,attempts:1,noDedupe:true});
    if(res&&res.ok){ toast(res.background?'Reset gestart op VPS':'Time Machine runstatus geleegd'); } else { toast('Reset gestart; status wordt zo bijgewerkt'); }
  }catch(err){ toast('Reset gestart/gevraagd; status wordt zo bijgewerkt'); }
  let done=false;
  for(let i=0;i<12;i++){
    await new Promise(r=>setTimeout(r,1500));
    try{
      const st=await api('/api/time-machine/reset/status?ts='+Date.now(),{timeout:5000,attempts:1,noDedupe:true});
      if(st && String(st.status||'').indexOf('complete')>=0){ done=true; break; }
      if(st && String(st.status||'').indexOf('error')===0){ toast('Reset fout: '+st.status); break; }
    }catch(e){}
  }
  toast(done?'Time Machine reset klaar':'Reset is aangevraagd; controleer status opnieuw als teller blijft staan.');
  await loadTimeMachineReady().catch(()=>{});
  await loadSummary().catch(()=>{}); await loadTmVisual().catch(()=>{});
});
$('seedExportBtn').addEventListener('click',async()=>{ $('seedMsg').textContent='Export wordt gemaakt…'; try{ const res=await api('/api/seed-export/create',{method:'POST',body:'{}',timeout:60000}); $('seedMsg').textContent=res.path ? 'Seed ZIP klaar: '+res.path : (res.error||'klaar'); }catch(err){ $('seedMsg').textContent='Export fout: '+err.message; }});

document.querySelectorAll('.twin-horizon').forEach(btn=>btn.addEventListener('click',()=>{ document.querySelectorAll('.twin-horizon').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); loadHistoricalTwins(btn.dataset.horizon||'1h'); }));

$('adaptiveRebuildBtn')?.addEventListener('click', async ()=>{ const btn=$('adaptiveRebuildBtn'); const msg=$('adaptiveLearningMsg'); if(btn){btn.disabled=true;btn.textContent='Learning herberekenen…';} if(msg) msg.textContent='Adaptive Learning wordt opnieuw opgebouwd uit Time Machine resultaten.'; try{ const res=await api('/api/adaptive-learning/rebuild',{method:'POST',body:'{}',timeout:60000,attempts:1}); if(msg) msg.textContent=res.ok?`Learning klaar: ${res.feature_dimensions||0} features, ${res.model_dimensions||0} modelgewichten.`:'Learning fout'; await loadAdaptiveLearning(); }catch(err){ if(msg) msg.textContent='Learning fout: '+err.message; } finally{ if(btn){btn.disabled=false;btn.textContent='Herbereken Learning';} } });


$('sessionLogBtn')?.addEventListener('click', async ()=>{
  const btn=$('sessionLogBtn');
  const direct=$('sessionLogDirectLink');
  const msg=$('debugExportMsg');
  if(btn){ btn.disabled=true; btn.textContent='Sessie-log voorbereiden…'; }
  try{
    sessionLog('frontend_session_log_download_clicked',{href:location.href});
    const url='/api/session-log/download?ts='+Date.now();
    if(direct){ direct.href=url; direct.removeAttribute('target'); direct.setAttribute('download','bee_full_tool_session_log.txt'); direct.style.display='block'; direct.textContent='Download sessie-log TXT opnieuw'; }
    if(msg) msg.textContent='Sessie-log TXT staat klaar. De app blijft open; geen lege pagina meer.';
    await stableDownload(url, 'bee_full_tool_session_log.txt', 'txt', 'Sessie-log TXT klaar');
  }catch(err){
    if(msg) msg.textContent='Sessie-log download fout: '+err.message;
    if(direct){ direct.href='/api/session-log/download?ts='+Date.now(); direct.style.display='block'; }
  }finally{
    setTimeout(()=>{ if(btn){ btn.disabled=false; btn.textContent='Download sessie-log TXT'; } }, 1200);
  }
});

$('debugExportBtn')?.addEventListener('click', async ()=>{
  const btn=$('debugExportBtn');
  const msg=$('debugExportMsg');
  const direct=$('debugExportDirectLink');
  if(btn){ btn.disabled=true; btn.textContent='Debug ZIP maken…'; }
  if(msg) msg.textContent='Debug ZIP wordt op de server gemaakt. Blijf op deze pagina; daarna start de download.';
  try{
    const res=await api('/api/debug/export/create',{method:'POST',body:'{}',timeout:120000,attempts:1});
    if(!res || res.ok===false) throw new Error((res&&res.error)||'export create failed');
    const url=(res.download_url||'/api/debug/export/download')+'?ts='+Date.now();
    if(direct){ direct.href=url; direct.removeAttribute('target'); direct.setAttribute('download', res.filename||'bee_debug_export.zip'); direct.style.display='block'; direct.textContent='Download Debug ZIP opnieuw'; }
    if(msg) msg.textContent='Debug ZIP klaar. De download blijft in de app; geen lege pagina meer.';
    await stableDownload(url, res.filename||'bee_debug_export.zip', 'zip', 'Debug ZIP klaar');
  }catch(err){
    if(msg) msg.textContent='Debug export fout: '+err.message+' — probeer de directe downloadknop.';
    if(direct){ direct.href='/api/debug/export/download?ts='+Date.now(); direct.style.display='block'; direct.textContent='Probeer directe download alsnog'; }
    toast('Debug export fout: '+err.message);
  }finally{
    if(btn){ btn.disabled=false; btn.textContent='Maak Debug Export ZIP'; }
  }
});


function renderTmReady(payload){
  if(!payload) return;
  cacheSet('bee_last_tm_ready', payload);
  const ready=!!payload.random1000_ready;
  const pct=Number(payload.readiness_pct||0);
  safeSet('tmReadyBadge', ready?'klaar':'check');
  safeSet('tmReadyTitle', ready?'Time Machine klaar voor Random1000':'Time Machine data wordt gecontroleerd');
  safeSet('tmReadyPct', Math.round(Math.max(0,Math.min(100,pct)))+'%');
  if($('tmReadyBar')) $('tmReadyBar').style.width=Math.max(0,Math.min(100,pct))+'%';
  const c=payload.checks||{};
  const line=(name,x)=>`${x&&x.ok?'✅':'⏳'} <b>${name}</b>: ${x&&x.label?x.label:(x&&x.ok?'ok':'wacht')}`;
  if($('tmReadyDetail')) $('tmReadyDetail').innerHTML=[
    line('Candles',c.candles), line('Native core',c.native_core), line('Feature warehouse',c.features), line('Modellen/learning',c.models), line('Export/logs',c.exports)
  ].join('<br>') + (payload.note?'<br><span>'+payload.note+'</span>':'');
  const btn=$('random1000Btn'); const btn100=$('random100Btn');
  if(btn){ btn.disabled=!ready; btn.textContent=ready?'Random1000':'Random1000 · wacht op TM'; }
  if(btn100){ btn100.disabled=!ready; btn100.textContent=ready?'Random100':'Random100 · wacht'; }
  // Fill core counters immediately, without waiting for full forecast/dashboard.
  if(payload.counts){
    safeSet('tmTests', Number(payload.counts.time_machine_tests||0).toLocaleString('nl-NL'));
    safeSet('tmSnapshots', Number(payload.counts.feature_snapshots||0).toLocaleString('nl-NL'));
    safeSet('tmSignals', Number(payload.counts.signal_events||0).toLocaleString('nl-NL'));
  }
  if(payload.price!=null && !$('priceLabel').textContent.includes('$')) safeSet('priceLabel', fmtUsd(payload.price));
  if(payload.candles&&payload.candles.rows){
    const rows=Number(payload.candles.rows||0), target=Number(payload.candles.target_rows||70000); const hp=Math.min(100, rows/target*100);
    safeSet('historyPct', hp.toFixed(1)+'%'); safeSet('historyRows', `${rows.toLocaleString('nl-NL')} / ${target.toLocaleString('nl-NL')} candles`); if($('historyBar')) $('historyBar').style.width=hp+'%'; safeSet('dataRows', rows.toLocaleString('nl-NL'));
  }
  if(payload.native_available!=null){ safeSet('nativeState', payload.native_available?'Actief':'Check'); safeSet('nativeDetail', payload.native_available?'C++ cloud core OK':'native core wordt gecontroleerd'); }
}
async function loadTimeMachineReady(){
  const cached=cacheGet('bee_last_tm_ready', 7*86400000); if(cached) renderTmReady(cached);
  try{ const p=await api('/api/time-machine/boot-ready',{timeout:5000,attempts:1}); if(p&&p.ok) renderTmReady(p); hideBoot(); return p; }
  catch(e){ const c=cacheGet('bee_last_tm_ready', 7*86400000); if(c){ renderTmReady(c); hideBoot(); return c; } hideBoot(); return null; }
}
async function loadQuick(){
  try{ const q=await api('/api/mobile/quick',{timeout:4500,attempts:1}); if(q&&q.ok) applyQuick(q); }
  catch(e){
    try{ const h=await api('/api/health',{timeout:4500,attempts:1}); applyQuick({ok:true, engine_version:h.engine_version, raw_candles:h.raw_candles, raw_candles_min_ms:h.raw_candles_min_ms, raw_candles_max_ms:h.raw_candles_max_ms, time_machine_tests:h.time_machine_tests, time_machine_feature_snapshots:h.time_machine_feature_snapshots, time_machine_signal_scores:h.time_machine_signal_scores, native_available:h.native_core&&h.native_core.available}); }
    catch(_){ setApi('loading','opstarten'); hideBoot(); }
  }
}

async function resumeTimeMachineProgress(reason='manual'){
  const now=Date.now();
  if(now-__lastTmStatusPollAt<900 && reason!=='visible' && reason!=='boot') return;
  __lastTmStatusPollAt=now;
  try{
    const active=localStorage.getItem('bee_active_tm_job_id')||'';
    const url='/api/time-machine/random-status'+(active?('?job_id='+encodeURIComponent(active)):'');
    const st=await api(url,{timeout:5000,attempts:1});
    if(st&&st.ok!==false){
      cacheSet('bee_last_tm_status', st);
      const completed=(st.status==='completed'||st.phase==='export_ready'||st.export_ready===true);
      const running=(st.status==='running'||st.status==='queued'||st.status==='stalled');
      if(running){ window.__tmPriorityMode=true; }
      if(running||completed){
        progressFromStatus(st, Number(st.count||1000)||1000, 0);
        sessionLog('frontend_tm_status_resume',{reason:reason,status:st.status,phase:st.phase,progress_pct:st.progress_pct,job_id:st.job_id,batch_id:st.batch_id});
      }
      if(completed){
        stopTmProgressTimer(); tmProgressLocal=100; __tmCompletionLocked=true; window.__tmPriorityMode=false;
        try{ localStorage.removeItem('bee_active_tm_job_id'); }catch(e){}
        setTmProgress(true,'Laatste Random'+(st.count||1000)+' klaar',100,'Backend staat op completed/export_ready. ZIP is beschikbaar; zware dashboards laden nu pas na de completion-lock.');
        setTimeout(()=>{ loadSummary().catch(()=>{}); loadTmVisual().catch(()=>{}); }, 1200);
        return st;
      }
    }
  }catch(err){
    sessionLog('frontend_tm_status_resume_error',{reason:reason,error:String(err&&err.message||err)});
    const st=cacheGet('bee_last_tm_status',7*86400000); if(st) try{ progressFromStatus(st, Number(st.count||1000)||1000, 0); }catch(e){}
  }
}



// V10.16.71: iOS Safari can pause timers/network while the page is hidden. When
// the tab becomes visible again, immediately ask the authoritative backend for
// Time Machine status before chart/forecast/dashboard work resumes.
document.addEventListener('visibilitychange',()=>{
  try{ if(document.visibilityState==='visible') setTimeout(()=>resumeTimeMachineProgress('visible'), 50); }catch(e){}
});
window.addEventListener('focus',()=>{ try{ setTimeout(()=>resumeTimeMachineProgress('focus'), 80); }catch(e){} });
window.addEventListener('pageshow',()=>{ try{ setTimeout(()=>resumeTimeMachineProgress('pageshow'), 80); }catch(e){} });

async function tick(){ await loadSummary(); }
try{ const cq=cacheGet('bee_last_quick',30*86400000); if(cq) applyQuick(cq); const cs=cacheGet('bee_last_summary',30*86400000); if(cs) { applyQuick(cs); } const ch=cacheGet('bee_last_chart_points',30*86400000); if(ch&&ch.length) drawChart(ch); applyCachedLiveProgress(); }catch(e){}
async function bootSequence(){
  // V10.16.56: Time Machine First Boot. Random1000 is the primary workflow.
  // Only check the minimum prerequisites first: DuckDB candle warehouse, native core, models/export/log endpoints.
  setTimeout(hideBoot, 900);
  // V10.16.71: Time Machine status is the first network call. It must not wait for
  // the full dashboard/chart/forecast stack, because Safari can throttle hidden tabs.
  resumeTimeMachineProgress('boot');
  try{ await loadTimeMachineReady(); }catch(e){}
  // Quick/mobile status may be busy; keep it secondary.
  setTimeout(()=>loadQuick().catch(()=>{}), 900);
  setTimeout(()=>resumeTimeMachineProgress('boot-followup'), 1800);
  // Forecast/chart/adaptive/twins are explicitly lazy-loaded after TM is usable.
  setTimeout(()=>{ if(!window.__tmPriorityMode) loadSummary().catch(()=>{}); }, 15000);
  setTimeout(()=>{ if(!window.__tmPriorityMode) loadChart().catch(()=>{}); }, 18000);
  setTimeout(()=>{ if(!window.__tmPriorityMode) loadBackgroundProgress(); }, 22000);
  setTimeout(()=>{ if(!window.__tmPriorityMode) loadEvidenceStatus(); }, 45000);
  setTimeout(()=>{ if(!window.__tmPriorityMode) loadAdaptiveLearning(); }, 40000);
  setTimeout(()=>{ if(!window.__tmPriorityMode) loadForecastIntelligence(); }, 45000);
  setTimeout(()=>{ if(!window.__tmPriorityMode) loadTmVisual(); }, 50000);
  setTimeout(()=>{ if(!window.__tmPriorityMode) loadHistoricalTwins('1h'); }, 55000);
}
bootSequence();
setInterval(()=>{ if(!window.__tmPriorityMode) tick(); },90000); setInterval(()=>{ if(!window.__tmPriorityMode) loadBackgroundProgress(); },60000); setInterval(()=>{ if(!window.__tmPriorityMode) loadChart(); },360000); setInterval(()=>{ if(!window.__tmPriorityMode) loadEvidenceStatus(); },420000); setInterval(()=>{ if(!window.__tmPriorityMode) loadAdaptiveLearning(); },240000); setInterval(()=>{ if(!window.__tmPriorityMode) loadForecastIntelligence(); },240000); setInterval(()=>{ if(!window.__tmPriorityMode) loadTmVisual(); },240000); window.addEventListener('resize',()=>{ if(!window.__tmPriorityMode) setTimeout(loadChart,500); });
if('serviceWorker' in navigator){ navigator.serviceWorker.register('/service-worker.js?v=10_16_72_adaptive_model_edge_boost&ts='+Date.now(), {updateViaCache:'none'}).then(function(reg){ try{reg.update();}catch(e){} }).catch(()=>{}); }


// V10.16.27 VISUAL DATA COCKPIT OVERRIDES
function v27StatusClass(st){
  if(st==='active'||st==='done'||st==='complete'||st==='current'||st==='provider_limited_current') return 'active';
  if(st==='partial'||st==='loading'||st==='provider_limited'||st==='gap_repair_needed'||st==='stuck'||st==='error'||st==='live_only') return 'partial';
  if(st==='api_key_needed') return 'key';
  return 'missing';
}
function v27RenderProviderProgress(p){
  const list=$('providerProgressList');
  if(!list) return;
  const ex=(p&&p.external)||{};
  const providers=(ex.providers||[]).slice().sort((a,b)=>{
    const pr={'missing':0,'error':0,'stuck':0,'partial':1,'loading':1,'provider_limited':1,'gap_repair_needed':1,'live_only':1,'active':2,'complete':2,'current':2,'provider_limited_current':2,'api_key_needed':3};
    return (pr[a.status]||0)-(pr[b.status]||0) || String(a.label).localeCompare(String(b.label));
  });
  const pct=Number((ex.overall_pct!=null?ex.overall_pct:p.overall_pct)||0);
  safeSet('liveDataProgressPct', Math.round(Math.max(0,Math.min(100,pct)))+'%');
  if($('liveDataProgressBar')) $('liveDataProgressBar').style.width=Math.max(0,Math.min(100,pct))+'%';
  const busy=(p.sync_busy?' · forecast/sync bezig':'');
  const phase=p.phase&&p.phase!=='idle'?' · '+p.phase:'';
  if($('liveDataProgressDetail')) $('liveDataProgressDetail').innerHTML=`<b>Backfill live:</b> ${Math.round(pct)}% totaal${busy}${phase}<br><span>Alles wordt éénmalig in /home/ubuntu/bitcoin_evidence_data bewaard. Bij volgende start leest de app direct uit deze lokale DuckDB-cache.</span>`;
  list.innerHTML = providers.map(r=>{
    const rp=Math.max(0,Math.min(100,Number(r.coverage_pct||0)));
    const cls=v27StatusClass(r.status);
    const eta=r.eta_text||'';
    return `<div class="provider-progress-row ${cls}">
      <div class="r1"><b>${r.label}</b><em>${Math.round(rp)}%</em></div>
      <div class="mini"><i style="width:${rp}%"></i></div>
      <small>${Number(r.rows||0).toLocaleString('nl-NL')} / ${Number(r.target_rows||0).toLocaleString('nl-NL')} · ${statusWord(r.status)} · ${eta}</small>
    </div>`;
  }).join('') || '<p class="hint">Providerstatus wordt geladen…</p>';
}
const __oldSetBootProgressPayload = setBootProgressPayload;
setBootProgressPayload = function(p){
  try{ __oldSetBootProgressPayload(p); }catch(e){}
  try{ v27RenderProviderProgress(p); }catch(e){}
};
async function loadEvidenceStatus(){
  try{
    const e=await api('/api/mobile/evidence-status',{timeout:30000,attempts:1});
    if(e&&e.ok){ renderExternalData(e.external_data); renderModelStatus(e.model_status); }
    loadAdaptiveLearning();
  }catch(_){ }
  try{ const p=await api('/api/mobile/live-progress',{timeout:10000,attempts:1}); cacheSet('bee_last_live_progress', p); setBootProgressPayload(p); const pst=p&&p.time_machine&&p.time_machine.persistent_status; if(pst) cacheSet('bee_last_tm_status', pst); }catch(_){ }
}

// V10.16.57: service-worker update rescue. If a new SW took control, reload once into the new shell.
try{
  if('serviceWorker' in navigator){
    navigator.serviceWorker.addEventListener('message', function(ev){
      try{ if(ev.data && ev.data.type==='BEE_SW_UPDATED' && ev.data.version){ location.replace('/mobile?app_v='+encodeURIComponent(ev.data.version)+'&r='+Date.now()); } }catch(e){}
    });
    navigator.serviceWorker.getRegistration().then(function(reg){
      try{ if(reg) reg.update().catch(function(){}); }catch(e){}
    }).catch(function(){});
  }
}catch(e){}
