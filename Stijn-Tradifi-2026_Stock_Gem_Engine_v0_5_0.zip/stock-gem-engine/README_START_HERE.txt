Stijn-Tradifi-2026 Stock Gem Engine v0.5.0
- IBKR/Saxo live broker API hooks (credentials required)
- clearer company explanation and why-attractive sections
- market cap source/confidence visible
- permission-safe installer
