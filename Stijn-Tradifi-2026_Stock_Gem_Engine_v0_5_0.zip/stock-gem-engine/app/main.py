import os, json, time, threading, sqlite3, math
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Any, Optional

import requests
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse

ROOT = Path('/home/ubuntu/stock-gem-engine') if Path('/home/ubuntu/stock-gem-engine').exists() else Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'; LOGS = ROOT / 'logs'
DATA.mkdir(parents=True, exist_ok=True); LOGS.mkdir(parents=True, exist_ok=True)
load_dotenv(ROOT / '.env')

APP_VERSION = '0.5.0-ibkr-saxo-company-clarity'
PORT = int(os.getenv('APP_PORT','8791'))
NTFY_TOPIC = os.getenv('NTFY_TOPIC','Stijn-Tradifi-2026')
SCAN_INTERVAL_MINUTES = int(os.getenv('SCAN_INTERVAL_MINUTES','60'))
AUTO_SCAN_ENABLED = os.getenv('AUTO_SCAN_ENABLED','true').lower() == 'true'
DB = DATA / 'stock_gems.sqlite3'

app = FastAPI(title='Stijn-Tradifi-2026 Stock Gem Engine', version=APP_VERSION)
state = {'running': False, 'last_scan': None, 'last_alerts': 0, 'error': None}

def log(msg: str):
    LOGS.mkdir(parents=True, exist_ok=True)
    with open(LOGS / 'app.log', 'a', encoding='utf-8') as f:
        f.write(f"{datetime.now(timezone.utc).isoformat()} {msg}\n")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute('''CREATE TABLE IF NOT EXISTS gems (
      ticker TEXT PRIMARY KEY, name TEXT, sector TEXT, country TEXT, exchange TEXT,
      mcap_usd REAL, mcap_source TEXT, mcap_confidence TEXT,
      gem_score REAL, early_signal REAL, hype_risk REAL, risk_score REAL,
      company_short TEXT, why_attractive TEXT, risk_plain TEXT, catalyst_plain TEXT,
      broker_json TEXT, news_json TEXT, first_seen TEXT, last_seen TEXT, alerted INTEGER DEFAULT 0
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS scan_runs(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, count INTEGER, alerts INTEGER, note TEXT)''')
    return con

UNIVERSE = [
 {'ticker':'DPRO','name':'Draganfly','sector':'Drones / Defense Tech','country':'Canada/US','exchange':'NASDAQ/CSE','mcap':187_000_000,'news':['Defense drone integration deals','Autonomous counter-UAS platform mentions']},
 {'ticker':'PRZO','name':'ParaZero Technologies','sector':'Drone safety / Defense','country':'Israel/US','exchange':'NASDAQ','mcap':38_000_000,'news':['DefendAir net pod integration deal','Autonomous counter-UAS platform']},
 {'ticker':'QBTS','name':'D-Wave Quantum','sector':'Quantum computing','country':'Canada/US','exchange':'NYSE','mcap':1_900_000_000,'news':['Quantum adoption narrative','Enterprise optimization pilots']},
 {'ticker':'RGTI','name':'Rigetti Computing','sector':'Quantum computing','country':'US','exchange':'NASDAQ','mcap':2_100_000_000,'news':['Quantum hardware roadmap','Government research funding']},
 {'ticker':'KULR','name':'KULR Technology','sector':'Battery safety / Energy storage','country':'US','exchange':'NYSE American','mcap':410_000_000,'news':['Battery safety contracts','Defense/space thermal management']},
 {'ticker':'OPTT','name':'Ocean Power Technologies','sector':'Marine energy / Defense','country':'US','exchange':'NYSE American','mcap':34_000_000,'news':['Maritime surveillance buoys','Defense ocean monitoring']},
 {'ticker':'ONDS','name':'Ondas Holdings','sector':'Autonomous drones / Networks','country':'US','exchange':'NASDAQ','mcap':92_000_000,'news':['Autonomous drone platform','Industrial private wireless']},
 {'ticker':'LIDR','name':'AEye','sector':'LiDAR / Autonomy','country':'US','exchange':'NASDAQ','mcap':45_000_000,'news':['Automotive lidar pipeline','Industrial sensing applications']},
 {'ticker':'MVIS','name':'MicroVision','sector':'LiDAR / Automotive sensors','country':'US','exchange':'NASDAQ','mcap':260_000_000,'news':['ADAS sensor narrative','Strategic alternatives discussion']},
 {'ticker':'ASTI','name':'Ascent Solar Technologies','sector':'Thin-film solar / Space','country':'US','exchange':'NASDAQ','mcap':16_000_000,'news':['Lightweight solar modules','Aerospace/space application potential']},
 {'ticker':'BBAI','name':'BigBear.ai','sector':'AI / Defense analytics','country':'US','exchange':'NYSE','mcap':1_200_000_000,'news':['AI defense analytics','Government contract narrative']},
 {'ticker':'SOUN','name':'SoundHound AI','sector':'Voice AI','country':'US','exchange':'NASDAQ','mcap':3_100_000_000,'news':['Enterprise voice AI adoption','Automotive assistant traction']},
 {'ticker':'REKR','name':'Rekor Systems','sector':'AI infrastructure / Public safety','country':'US','exchange':'NASDAQ','mcap':180_000_000,'news':['Roadway intelligence platform','Public sector AI analytics']},
 {'ticker':'KSCP','name':'Knightscope','sector':'Security robotics','country':'US','exchange':'NASDAQ','mcap':30_000_000,'news':['Autonomous security robots','Recurring security contracts']},
 {'ticker':'AISP','name':'Airship AI','sector':'AI video analytics','country':'US','exchange':'NASDAQ','mcap':140_000_000,'news':['Edge AI surveillance','Government/enterprise analytics']},
 {'ticker':'GEVO','name':'Gevo','sector':'Sustainable aviation fuel','country':'US','exchange':'NASDAQ','mcap':420_000_000,'news':['SAF plant financing','Airline offtake agreements']},
 {'ticker':'UUUU','name':'Energy Fuels','sector':'Uranium / Rare earths','country':'US/Canada','exchange':'NYSE American/TSX','mcap':1_050_000_000,'news':['Uranium cycle strength','Rare earth processing']},
 {'ticker':'UEC','name':'Uranium Energy','sector':'Uranium','country':'US/Canada','exchange':'NYSE American','mcap':2_600_000_000,'news':['Uranium restart optionality','US nuclear fuel narrative']},
 {'ticker':'HYSR','name':'SunHydrogen','sector':'Hydrogen research','country':'US','exchange':'OTC','mcap':65_000_000,'news':['Green hydrogen prototype','Research milestone watch']},
 {'ticker':'CYBN','name':'Cybin','sector':'Biotech / Neuropsychiatry','country':'Canada/US','exchange':'NYSE American/NEO','mcap':370_000_000,'news':['Clinical-stage neuropsychiatry pipeline','Trial catalyst watch']},
 {'ticker':'ATOS','name':'Atossa Therapeutics','sector':'Biotech / Oncology','country':'US','exchange':'NASDAQ','mcap':150_000_000,'news':['Breast cancer therapy trials','Clinical catalyst watch']},
 {'ticker':'TNYA','name':'Tenaya Therapeutics','sector':'Biotech / Gene therapy','country':'US','exchange':'NASDAQ','mcap':220_000_000,'news':['Cardiac gene therapy pipeline','Clinical readout watch']},
 {'ticker':'EOSE','name':'Eos Energy Enterprises','sector':'Grid storage','country':'US','exchange':'NASDAQ','mcap':1_400_000_000,'news':['Long-duration storage demand','US manufacturing support']},
 {'ticker':'ABAT','name':'American Battery Technology','sector':'Battery recycling / Lithium','country':'US','exchange':'NASDAQ','mcap':120_000_000,'news':['Battery recycling ramp','Lithium resource development']},
]

BROKER_CACHE: Dict[str, Any] = {}

def classify_mcap(m):
    if m is None: return 'onbekend'
    if m < 50_000_000: return 'nano/microcap'
    if m < 300_000_000: return 'microcap'
    if m < 2_000_000_000: return 'smallcap'
    return 'groter dan echte microcap'

def fmt_mcap(m):
    if not m: return 'Onbekend'
    if m >= 1_000_000_000: return f"${m/1_000_000_000:.2f}B"
    return f"${m/1_000_000:.1f}M"

def live_market_cap(item):
    # v0.5 policy: known curated/last verified baseline > wrong estimate. Later can attach paid API.
    m = float(item.get('mcap') or 0)
    return m, 'curated_verified_baseline' if item['ticker']=='DPRO' else 'curated_reference', 'medium' if item['ticker']!='DPRO' else 'high'

def ibkr_check(ticker, exchange):
    url = os.getenv('IBKR_GATEWAY_URL','').rstrip('/')
    if not url:
        return {'status':'not_configured','label':'IBKR API nog niet gekoppeld','route':None,'detail':'Vul IBKR_GATEWAY_URL in wanneer Client Portal Gateway draait.'}
    try:
        verify = os.getenv('IBKR_VERIFY_SSL','false').lower() == 'true'
        r = requests.get(f"{url}/iserver/secdef/search", params={'symbol':ticker}, timeout=6, verify=verify)
        if r.status_code == 200:
            rows = r.json() if isinstance(r.json(), list) else []
            for row in rows:
                if str(row.get('symbol','')).upper() == ticker.upper():
                    return {'status':'verified','label':'IBKR verified','route':f"{ticker} / conid {row.get('conid','?')}", 'detail':row.get('companyName') or row.get('description') or 'gevonden via IBKR'}
            return {'status':'not_found','label':'Niet gevonden op IBKR','route':None,'detail':'IBKR API gaf geen exacte ticker-match terug.'}
        return {'status':'api_error','label':'IBKR API fout','route':None,'detail':f'HTTP {r.status_code}'}
    except Exception as e:
        return {'status':'api_error','label':'IBKR niet bereikbaar','route':None,'detail':str(e)[:120]}

def saxo_check(ticker, exchange):
    token = os.getenv('SAXO_ACCESS_TOKEN','')
    base = os.getenv('SAXO_BASE_URL','https://gateway.saxobank.com/sim/openapi').rstrip('/')
    if not token:
        return {'status':'not_configured','label':'Saxo API nog niet gekoppeld','route':None,'detail':'Vul SAXO_ACCESS_TOKEN in na Saxo OpenAPI setup.'}
    try:
        headers={'Authorization':f'Bearer {token}'}
        r = requests.get(f"{base}/ref/v1/instruments", params={'Keywords':ticker,'AssetTypes':'Stock','$top':10}, headers=headers, timeout=8)
        if r.status_code == 200:
            data = r.json().get('Data', [])
            for row in data:
                sym = str(row.get('Symbol','')).upper()
                if sym == ticker.upper() or ticker.upper() in sym:
                    exch = row.get('ExchangeId') or row.get('Exchange') or ''
                    return {'status':'verified','label':'Saxo verified','route':f"{sym}:{exch}" if exch else sym, 'detail':row.get('Description') or 'gevonden via Saxo OpenAPI'}
            return {'status':'not_found','label':'Niet gevonden op Saxo','route':None,'detail':'Saxo API gaf geen exacte ticker-match terug.'}
        return {'status':'api_error','label':'Saxo API fout','route':None,'detail':f'HTTP {r.status_code}'}
    except Exception as e:
        return {'status':'api_error','label':'Saxo niet bereikbaar','route':None,'detail':str(e)[:120]}

def broker_availability(ticker, exchange):
    cache_key = ticker + '|' + exchange
    # avoid repeated external calls in same process for 15 min
    now = time.time(); cached = BROKER_CACHE.get(cache_key)
    if cached and now - cached['ts'] < 900: return cached['data']
    data = {
      'ibkr': ibkr_check(ticker, exchange),
      'saxo': saxo_check(ticker, exchange),
      'degiro': {'status':'unsupported','label':'Geen officiële DEGIRO API','route':None,'detail':'Niet tonen als exact koopbaar zonder officiële API.'},
      'trading212': {'status':'planned','label':'Trading 212 later','route':None,'detail':'Kan later via officiële instrument list/API.'}
    }
    BROKER_CACHE[cache_key] = {'ts':now, 'data':data}
    return data

def score_item(item):
    mcap, src, conf = live_market_cap(item)
    mcap_factor = max(0, min(1, (600_000_000 - min(mcap,600_000_000)) / 600_000_000))
    narrative = 1 if any(w.lower() in ' '.join(item['news']).lower() for w in ['defense','ai','quantum','uranium','space','battery','drone','clinical']) else 0.55
    early_signal = round(58 + 32*narrative + 10*mcap_factor, 1)
    hype_risk = round(8 + (0 if mcap < 300_000_000 else 18) + (18 if mcap > 1_000_000_000 else 0), 1)
    risk_score = round(42 + (18 if mcap < 75_000_000 else 8) + (14 if 'Biotech' in item['sector'] or 'Hydrogen' in item['sector'] else 0), 1)
    gem = round(max(0, min(99, early_signal + 12*mcap_factor - 0.42*hype_risk - 0.12*risk_score)), 1)
    return mcap, src, conf, gem, early_signal, hype_risk, risk_score

def explain(item, scores):
    mcap, src, conf, gem, early, hype, risk = scores
    cap_class = classify_mcap(mcap)
    name, ticker, sector = item['name'], item['ticker'], item['sector']
    company_short = f"{name} ({ticker}) is een {cap_class} binnen {sector}. De tool ziet dit als research-kandidaat omdat het bedrijf in een sector zit waar één contract, klinische mijlpaal of narratiefversnelling snel veel aandacht kan trekken."
    why = f"Aantrekkelijk door de combinatie van market cap {fmt_mcap(mcap)}, Early Signal {early}/100 en Hype Risk {hype}/100. In makkelijke taal: de tool zoekt naar kleine bedrijven waar al vroege signalen zijn, maar waar de prijs/hype nog niet extreem lijkt. Dat is precies de fase vóór een mogelijke pump, niet erna."
    catalyst = "Recente/verwachte signalen: " + '; '.join(item['news']) + ". Dit zijn geen koopadviezen, maar redenen om verder onderzoek te doen."
    risk_txt = f"Belangrijk risico: {sector}-microcaps kunnen extreem volatiel zijn. Check altijd cashpositie, dilution, omzetkwaliteit, schuld, liquiditeit en of nieuws echt materieel is. Market cap bron: {src}, confidence: {conf}."
    return company_short, why, catalyst, risk_txt

def send_ntfy(gem):
    try:
        title = f"🚨 New Gem: {gem['ticker']} {gem['gem_score']:.1f}"
        msg = f"{gem['ticker']} · {gem['name']}\nMCap: {fmt_mcap(gem['mcap_usd'])}\nWaarom: {gem['why_attractive'][:250]}\nRisico: {gem['risk_plain'][:180]}\nhttp://51.195.102.180:8791"
        requests.post(f'https://ntfy.sh/{NTFY_TOPIC}', data=msg.encode('utf-8'), headers={'Title':title, 'Priority':'default'}, timeout=5)
        return True
    except Exception as e:
        log(f'ntfy_error {e}')
        return False

def run_scan(manual=False):
    if state['running']: return {'ok':False,'message':'scan draait al'}
    state['running'] = True; state['error'] = None
    alerts = 0; count = 0
    try:
        con = db(); now = datetime.now(timezone.utc).isoformat()
        for item in UNIVERSE:
            scores = score_item(item)
            mcap, src, conf, gem, early, hype, risk = scores
            company_short, why, catalyst, risk_txt = explain(item, scores)
            brokers = broker_availability(item['ticker'], item['exchange'])
            existing = con.execute('SELECT alerted FROM gems WHERE ticker=?',(item['ticker'],)).fetchone()
            should_alert = (not existing or existing['alerted']==0) and gem >= 84 and hype <= 35
            if should_alert:
                alerts += 1
            con.execute('''INSERT INTO gems(ticker,name,sector,country,exchange,mcap_usd,mcap_source,mcap_confidence,gem_score,early_signal,hype_risk,risk_score,company_short,why_attractive,risk_plain,catalyst_plain,broker_json,news_json,first_seen,last_seen,alerted)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(ticker) DO UPDATE SET name=excluded.name,sector=excluded.sector,country=excluded.country,exchange=excluded.exchange,mcap_usd=excluded.mcap_usd,mcap_source=excluded.mcap_source,mcap_confidence=excluded.mcap_confidence,gem_score=excluded.gem_score,early_signal=excluded.early_signal,hype_risk=excluded.hype_risk,risk_score=excluded.risk_score,company_short=excluded.company_short,why_attractive=excluded.why_attractive,risk_plain=excluded.risk_plain,catalyst_plain=excluded.catalyst_plain,broker_json=excluded.broker_json,news_json=excluded.news_json,last_seen=excluded.last_seen,alerted=CASE WHEN gems.alerted=1 THEN 1 ELSE excluded.alerted END''',
              (item['ticker'],item['name'],item['sector'],item['country'],item['exchange'],mcap,src,conf,gem,early,hype,risk,company_short,why,risk_txt,catalyst,json.dumps(brokers),json.dumps(item['news']),now,now,1 if should_alert else 0))
            count += 1
        con.execute('INSERT INTO scan_runs(ts,count,alerts,note) VALUES(?,?,?,?)',(now,count,alerts,'manual' if manual else 'auto'))
        con.commit(); con.close()
        state['last_scan'] = now; state['last_alerts'] = alerts
        if alerts:
            con = db()
            for row in con.execute('SELECT * FROM gems WHERE alerted=1 ORDER BY gem_score DESC LIMIT 3').fetchall(): send_ntfy(dict(row))
            con.close()
        log(f'scan_complete count={count} alerts={alerts} manual={manual}')
        return {'ok':True,'count':count,'alerts':alerts}
    except Exception as e:
        state['error'] = str(e); log(f'scan_error {e}'); return {'ok':False,'error':str(e)}
    finally:
        state['running'] = False

def scheduler_loop():
    log(f'scheduler_started enabled={AUTO_SCAN_ENABLED} interval={SCAN_INTERVAL_MINUTES}')
    # run once shortly after start when db empty
    while True:
        try:
            if AUTO_SCAN_ENABLED:
                con = db(); n = con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; con.close()
                if n == 0: run_scan(False)
                time.sleep(SCAN_INTERVAL_MINUTES*60)
                run_scan(False)
            else:
                time.sleep(60)
        except Exception as e:
            log(f'scheduler_error {e}'); time.sleep(60)

@app.on_event('startup')
def startup():
    threading.Thread(target=scheduler_loop, daemon=True).start()

@app.get('/api/status')
def api_status():
    con = db(); n = con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; con.close()
    return {'version':APP_VERSION,'gems':n,'ntfy_topic':NTFY_TOPIC,'scan_interval_minutes':SCAN_INTERVAL_MINUTES,'auto_scan':AUTO_SCAN_ENABLED,**state}

@app.get('/api/gems')
def api_gems():
    con = db(); rows = [dict(r) for r in con.execute('SELECT * FROM gems ORDER BY gem_score DESC, early_signal DESC').fetchall()]; con.close()
    for r in rows:
        r['broker'] = json.loads(r.pop('broker_json') or '{}'); r['news'] = json.loads(r.pop('news_json') or '[]')
    return rows

@app.post('/api/scan')
def api_scan():
    return run_scan(manual=True)

@app.get('/', response_class=HTMLResponse)
def index():
    return HTML

HTML = r'''<!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Stijn-Tradifi-2026</title><style>
:root{--bg:#070b14;--card:#101827;--card2:#111d31;--text:#f4f7fb;--muted:#9aa8bd;--line:#263654;--gold:#ffd166;--green:#54e38e;--red:#ff647c;--blue:#86b6ff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top,#15223a,#070b14 45%);color:var(--text);font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif}.wrap{max-width:1120px;margin:0 auto;padding:28px 18px 60px}.hero{padding:26px;border:1px solid var(--line);border-radius:28px;background:linear-gradient(135deg,rgba(24,38,66,.95),rgba(9,14,25,.95));box-shadow:0 20px 70px rgba(0,0,0,.35)}h1{margin:0;font-size:clamp(34px,6vw,64px);letter-spacing:-.05em}.sub{color:var(--muted);font-size:18px;line-height:1.5}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0}.stat,.card{background:rgba(16,24,39,.9);border:1px solid var(--line);border-radius:24px;padding:20px}.stat b{font-size:28px}.actions{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}button{background:var(--gold);color:#101000;border:0;border-radius:16px;padding:14px 18px;font-weight:900;font-size:16px}.ghost{background:#18243a;color:var(--text);border:1px solid var(--line)}.list{display:grid;gap:18px}.gem{background:linear-gradient(180deg,rgba(17,29,49,.98),rgba(9,14,25,.98));border:1px solid var(--line);border-radius:28px;padding:24px}.top{display:flex;justify-content:space-between;gap:18px}.ticker{font-size:42px;font-weight:1000;letter-spacing:-.05em}.score{font-size:44px;font-weight:1000;color:var(--gold)}.meta{color:var(--muted);font-size:16px}.tag{display:inline-block;background:rgba(84,227,142,.13);color:var(--green);border:1px solid rgba(84,227,142,.35);border-radius:999px;padding:8px 12px;font-weight:800;margin:10px 0}.mcap{font-size:26px;font-weight:900}.source{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.12em;border:1px solid var(--line);border-radius:999px;padding:5px 9px;margin-left:8px}.barrow{margin:12px 0}.label{display:flex;justify-content:space-between;color:var(--muted);font-weight:700}.bar{height:12px;background:#060914;border-radius:99px;overflow:hidden;border:1px solid #0c1322}.fill{height:100%;background:linear-gradient(90deg,#6fa8ff,#ffd166)}.riskfill{background:linear-gradient(90deg,#b06cff,#ff647c)}.hypefill{background:linear-gradient(90deg,#ff647c,#ffd166)}.cols{display:grid;grid-template-columns:1.1fr .9fr;gap:16px;margin-top:16px}.explain p{font-size:17px;line-height:1.55;color:#dce6f5}.broker{display:grid;gap:8px}.brokerline{display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.08)}.ok{color:var(--green);font-weight:900}.warn{color:var(--gold)}.bad{color:var(--red)}.muted{color:var(--muted)}@media(max-width:780px){.grid{grid-template-columns:1fr 1fr}.cols{grid-template-columns:1fr}.ticker{font-size:34px}.score{font-size:38px}.wrap{padding:14px 10px 40px}.hero,.gem{border-radius:22px;padding:18px}}
</style></head><body><div class="wrap"><div class="hero"><h1>Stijn-Tradifi-2026</h1><div class="sub">Global Smallcap Gem Evidence Engine · zoekt vroeg, vóór de hype · v<span id="ver">...</span></div><div class="grid"><div class="stat"><b id="count">0</b><div class="meta">Gems in database</div></div><div class="stat"><b id="topic">...</b><div class="meta">ntfy topic</div></div><div class="stat"><b id="interval">...</b><div class="meta">Auto scan</div></div><div class="stat"><b id="last">...</b><div class="meta">Laatste scan</div></div></div><div class="actions"><button onclick="scan()">Nieuwe scan</button><button class="ghost" onclick="load()">Vernieuwen</button></div><div class="sub" id="status">Laden...</div></div><div class="card"><h2>Top Gems Ranking</h2><div class="sub">Hoogste score = vroege signalen + lage hype + bruikbare market cap. Broker-info toont live API-status voor IBKR/Saxo zodra je credentials gekoppeld zijn.</div></div><div class="list" id="list"></div></div><script>
function money(v){if(!v)return 'Onbekend'; if(v>=1e9)return '$'+(v/1e9).toFixed(2)+'B'; return '$'+(v/1e6).toFixed(1)+'M'}
function brokerStatus(b){let cls='muted'; if(b.status==='verified')cls='ok'; else if(['api_error','not_found'].includes(b.status))cls='bad'; else if(['not_configured','planned','unsupported'].includes(b.status))cls='warn'; return `<span class="${cls}">${b.label||b.status}${b.route?' · '+b.route:''}</span><small class="muted">${b.detail||''}</small>`}
function bar(label,val,type=''){return `<div class="barrow"><div class="label"><span>${label}</span><span>${val}</span></div><div class="bar"><div class="fill ${type}" style="width:${Math.max(0,Math.min(100,val))}%"></div></div></div>`}
async function load(){let s=await fetch('/api/status').then(r=>r.json()); document.getElementById('ver').textContent=s.version; document.getElementById('count').textContent=s.gems; document.getElementById('topic').textContent=s.ntfy_topic; document.getElementById('interval').textContent='elk '+s.scan_interval_minutes+' min'; document.getElementById('last').textContent=s.last_scan?new Date(s.last_scan).toLocaleTimeString():'nog geen'; document.getElementById('status').textContent=s.running?'Scan draait...':'running: nee · nieuwe alerts: '+(s.last_alerts||0); let gems=await fetch('/api/gems').then(r=>r.json()); render(gems)}
async function scan(){document.getElementById('status').textContent='Scan draait... gratis data/API checks kunnen even duren.'; await fetch('/api/scan',{method:'POST'}); await load()}
function render(gems){let root=document.getElementById('list'); if(!gems.length){root.innerHTML='<div class="card"><b>Nog geen scan.</b> Klik op Nieuwe scan.</div>';return} root.innerHTML=gems.map(g=>`<div class="gem"><div class="top"><div><div class="ticker">${g.ticker}</div><div class="meta">${g.name}<br>${g.country} · ${g.exchange}</div><h3>${g.sector}</h3><div class="mcap">${money(g.mcap_usd)} <span class="source">${g.mcap_source} · ${g.mcap_confidence}</span></div><span class="tag">${g.gem_score>=84?'Strong early gem candidate':'Watchlist candidate'}</span></div><div class="score">${g.gem_score.toFixed(1)}</div></div>${bar('Early Signal',g.early_signal)}${bar('Hype Risk',g.hype_risk,'hypefill')}${bar('Risk Score',g.risk_score,'riskfill')}<div class="cols"><div class="explain"><h3>Wat doet dit bedrijf?</h3><p>${g.company_short}</p><h3>Waarom aantrekkelijk?</h3><p>${g.why_attractive}</p><h3>Katalysator</h3><p>${g.catalyst_plain}</p><h3>Risico in makkelijke taal</h3><p>${g.risk_plain}</p></div><div><h3>Exacte brokerroute Nederland</h3><div class="broker"><div class="brokerline"><b>IBKR</b><div>${brokerStatus(g.broker.ibkr||{})}</div></div><div class="brokerline"><b>Saxo</b><div>${brokerStatus(g.broker.saxo||{})}</div></div><div class="brokerline"><b>DEGIRO</b><div>${brokerStatus(g.broker.degiro||{})}</div></div><div class="brokerline"><b>Trading 212</b><div>${brokerStatus(g.broker.trading212||{})}</div></div></div><h3>Nieuws/signalen</h3><ul>${(g.news||[]).map(n=>'<li>'+n+'</li>').join('')}</ul></div></div></div>`).join('')}
load(); setInterval(load,30000)
</script></body></html>'''
