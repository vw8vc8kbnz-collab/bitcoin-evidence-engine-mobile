# AlgoRoute v1.6.2 COMPOSE HOTFIX

Use the update commands from ChatGPT with this filename:
algoroute_v1_6_2_COMPOSE_HOTFIX.zip
