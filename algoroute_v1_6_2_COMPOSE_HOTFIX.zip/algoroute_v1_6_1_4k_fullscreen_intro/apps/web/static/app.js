function bootIntro(){
  const overlay=document.getElementById('startupIntro');
  const video=document.getElementById('startupVideo');
  const app=document.getElementById('app');
  const skip=document.getElementById('skipIntro');
  if(!overlay||!app) return;
  let closed=false;
  function closeIntro(){
    if(closed) return; closed=true;
    app.classList.remove('introPending'); app.classList.add('introReady');
    overlay.classList.add('hidden');
    try{ if(video) video.pause(); }catch(e){}
    setTimeout(()=>{ try{overlay.remove()}catch(e){} },900);
  }
  if(skip) skip.addEventListener('click', closeIntro);
  if(video){
    video.muted=true; video.playsInline=true;
    const playPromise=video.play();
    if(playPromise && playPromise.catch){playPromise.catch(()=>setTimeout(closeIntro,1100));}
    video.addEventListener('ended', closeIntro);
    video.addEventListener('error', ()=>setTimeout(closeIntro,700));
  }
  setTimeout(closeIntro, 9500);
}

const API = location.origin;
const state = {
  page:'planning', planningStep:1, map:null, mapState:null, routingStatus:null,
  fields:[], fieldCategories:[], detections:[], csvHeaders:[], csvRows:[], mapping:{}, templates:[], selectedTemplate:null,
  queue:null, optimizeResult:null, geocodeResult:null, error:null
};
const navGroups = [
  ['OPERATIONS',[['dashboard','Dashboard','⌂'],['planning','Planning','☷'],['routes','Routes','⌘'],['load','Load Optimization','▣'],['live','Live Kaart','◎']]],
  ['RESOURCES',[['vehicles','Wagenpark','▤'],['drivers','Chauffeurs','♙'],['orders','Orders','▦']]],
  ['MANAGEMENT',[['tracking','Klanttracking','⌾'],['reports','Rapportages','▥'],['settings','Instellingen','⚙']]]
];
function api(path, opts){return fetch(API+path, opts).then(async r=>{let j={};try{j=await r.json()}catch(e){}; if(!r.ok) throw {status:r.status,...j}; return j;});}
async function init(){
  try{state.mapState=await api('/api/map/state')}catch(e){}
  try{state.routingStatus=await api('/api/routing/status')}catch(e){}
  try{const f=await api('/api/import/fields'); state.fields=f.fields||[]; state.fieldCategories=f.categories||[]}catch(e){}
  try{state.templates=(await api('/api/import/templates')).templates||[]}catch(e){}
  try{state.queue=await api('/api/planning/queue')}catch(e){}
  render();
}
function setPage(p){state.page=p; render();}
function setStep(n){state.planningStep=n; render();}
function escapeHtml(s){return String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function shell(content){
  return `<div class="shell"><aside class="sidebar"><div class="brand brandOfficial"><img class="brandFullLogo" src="/assets/algoroute-logo-sidebar-white-lime.png" alt="AlgoRoute"/></div>${navGroups.map(([g,items])=>`<div class="sectionLabel">${g}</div>${items.map(([id,label,icon])=>`<div onclick="setPage('${id}')" class="navItem ${state.page===id?'active':''}"><span class="navIcon">${icon}</span><span>${label}</span></div>`).join('')}`).join('')}<div class="sideFooter"><div>◐ Donker sidebar</div><br><b>Stijn</b><div class="muted">Admin</div></div></aside><main class="main"><div class="topbar"><div class="menuBtn">☰</div><div class="search">⌕ Zoek order, route, bus, mapping of klant...</div><div class="topRight"><span class="sync">● Live sync actief</span><span>🔔</span><span>?</span><span class="avatar">S</span></div></div>${content}</main></div>`;
}
function kpis(){
  const q=state.queue?.summary||{};
  const routes=(state.mapState?.routes||[]).length;
  return `<div class="kpis"><div class="card kpi"><div class="kpiIcon">⌘</div><div><small>Actieve routes</small><br><b>${routes}</b><br><small>${routes?'live beschikbaar':'vult na optimizer'}</small></div></div><div class="card kpi"><div class="kpiIcon">☷</div><div><small>Orders in queue</small><br><b>${q.count||0}</b><br><small>${q.ready||0} ready</small></div></div><div class="card kpi"><div class="kpiIcon">↗</div><div><small>OSRM routing</small><br><b>${state.routingStatus?.available?'online':'—'}</b><br><small>${state.routingStatus?.available?'echte routes':'setup nodig'}</small></div></div><div class="card kpi"><div class="kpiIcon">▧</div><div><small>Load utilization</small><br><b>—</b><br><small>na load optimization</small></div></div></div>`;
}
function dashboard(){return shell(`<h1 class="pageTitle">Dashboard</h1><p class="subtitle">Operationele cockpit. Widgets vullen automatisch vanuit import, voertuigen, OSRM en optimizer.</p>${kpis()}<section class="layout"><div>${mapCard('Dashboard preview met echte kaartdata')}<div class="bottom"><div class="card panel"><h3>Routes vandaag</h3><div class="row"><span class="muted">${(state.mapState?.routes||[]).length||'Nog geen routes gegenereerd'}</span><span class="badge">routes</span></div></div><div class="card panel"><h3>Planning queue</h3><div class="row"><span class="muted">${state.queue?.summary?.count||0} orders</span><span class="badge green">ready</span></div></div><div class="card panel"><h3>Fleet status</h3><div class="row"><span class="muted">Voeg voertuigen toe</span><span class="badge">setup</span></div></div></div></div><div>${osrmPanel()}${rightInfo()}</div></section>`)}
function mapCard(sub='Echte Nederland-kaart', full=false){return `<div class="card mapCard ${full?'mapCanvasFull':''}"><div class="mapHeader"><button class="pill">Traffic</button><button class="pill active">Routes</button><button class="pill">Stops</button></div><div id="map" class="map"></div>${full?`<div class="roadLegend"><b>Route status</b><span class="legendLine"><i class="normal"></i>Normaal</span><span class="legendLine"><i class="delay"></i>Vertraging</span><span class="legendLine"><i class="jam"></i>File</span><span class="legendLine"><i class="ev"></i>EV route</span></div>`:''}${(!state.mapState || ((state.mapState.routes||[]).length===0 && (state.mapState.vehicles||[]).length===0))?`<div class="emptyMap"><b>Kaart is klaar voor echte data</b><br><span class="muted">Routes verschijnen na echte orders + optimalisatie.</span></div>`:''}</div>`}
function osrmPanel(){const s=state.routingStatus||{};return `<div class="card panel" style="margin-bottom:18px"><h3>OSRM status</h3><div class="row"><span><i class="statusDot ${s.available?'ok':'bad'}"></i> Routing engine</span><span class="badge ${s.available?'green':'orange'}">${s.available?'online':'niet actief'}</span></div><p class="muted">${escapeHtml(s.message||'OSRM status wordt geladen.')}</p><button class="btn accent" onclick="setPage('settings')">OSRM setup bekijken</button></div>`}
function rightInfo(){return `<div class="card panel"><h3>Product flow</h3><div class="row"><b>1. Import</b><span class="badge green">CSV/ERP</span></div><div class="row"><b>2. Mapping</b><span class="badge green">smart</span></div><div class="row"><b>3. Queue</b><span class="badge">ready</span></div><div class="row"><b>4. Optimize</b><span class="badge orange">OSRM</span></div><div class="row"><b>5. Publish</b><span class="badge">later</span></div></div>`}
function initMap(){
  if(!window.maplibregl) return; const el=document.getElementById('map'); if(!el) return; el.innerHTML='';
  const style={version:8,sources:{carto:{type:'raster',tiles:['https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png','https://b.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png','https://c.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png'],tileSize:256,attribution:'© OpenStreetMap © CARTO'}},layers:[{id:'carto',type:'raster',source:'carto'}]};
  const map=new maplibregl.Map({container:el,style,center:[5.2913,52.1326],zoom:7.05,attributionControl:true}); state.map=map; map.addControl(new maplibregl.NavigationControl({showCompass:false}),'bottom-right'); map.on('load',()=>{addCities(map); drawData(map);});
}
function addCities(map){[['Amsterdam',4.9041,52.3676],['Rotterdam',4.4777,51.9244],['Den Haag',4.3007,52.0705],['Utrecht',5.1214,52.0907],['Eindhoven',5.4697,51.4416],['Groningen',6.5665,53.2194],['Leeuwarden',5.7999,53.2012],['Zwolle',6.083,52.5168],['Arnhem',5.8987,51.9851],['Nijmegen',5.8528,51.8426],['Breda',4.7683,51.5719],['Tilburg',5.0913,51.5555]].forEach(([name,lng,lat])=>{let el=document.createElement('div');el.className='cityMarker';el.textContent=name;new maplibregl.Marker({element:el}).setLngLat([lng,lat]).addTo(map);});}
function drawData(map){const ms=state.mapState||{routes:[],vehicles:[]}; (ms.routes||[]).forEach((r,i)=>{const coords=r.geometry||r.coordinates||[]; if(!coords.length) return; map.addSource('route-'+i,{type:'geojson',data:{type:'Feature',geometry:{type:'LineString',coordinates:coords}}}); map.addLayer({id:'route-glow-'+i,type:'line',source:'route-'+i,paint:{'line-color':r.color||'#65a30d','line-width':12,'line-opacity':.20,'line-blur':3}}); map.addLayer({id:'route-'+i,type:'line',source:'route-'+i,paint:{'line-color':r.color||'#65a30d','line-width':5,'line-opacity':.95}});}); (ms.vehicles||[]).forEach(v=>{if(!v.longitude||!v.latitude)return; const el=document.createElement('div');el.className='vehicleMarker';el.textContent='🚚';new maplibregl.Marker({element:el}).setLngLat([v.longitude,v.latitude]).addTo(map);});}
function live(){return shell(`<section class="liveMapPage"><h1 class="pageTitle">Live Kaart</h1><p class="subtitle">Full-canvas execution map met OSRM-routes, traffic-segmenten, voertuigen en laadstatus.</p><div class="liveMapShell">${mapCard('Echte Nederland-kaart', true)}</div></section>`)}
function planning(){return shell(`<h1 class="pageTitle">Planning Queue</h1><p class="subtitle">Controleer leverdatum, tijdvensters, service/kostijd en capaciteit voordat AlgoRoute de optimizer start.</p><div class="tabs">${[1,2,3,4,5].map((n,i)=>`<button onclick="setStep(${n})" class="tab ${state.planningStep===n?'active':''}">${n} ${['Import','Mapping','Queue','Optimize','Publish'][i]}</button>`).join('')}</div>${planningStep()}`)}
function planningStep(){
  if(state.planningStep===1) return importStep();
  if(state.planningStep===2) return mappingStep();
  if(state.planningStep===3) return queueStep();
  if(state.planningStep===4) return optimizeStep();
  return publishStep();
}
function importStep(){return `<div class="workflowCard card"><h2>1. Import</h2><p class="muted">Upload CSV. Mapping gebeurt bewust pas in stap 2.</p><div class="uploadBox"><input id="csvFile" class="input" type="file" accept=".csv,.txt" onchange="handleCsvUpload(event)"><div class="muted">CSV wordt lokaal geparsed en daarna naar Smart Mapping gestuurd.</div></div><div class="moduleGrid"><div class="card panel"><h3>Recent bestand</h3>${state.csvHeaders.length?`<div class="notice greenNotice"><b>${state.csvRows.length}</b> regels gelezen · <b>${state.csvHeaders.length}</b> kolommen gevonden</div><button class="btn accent" onclick="setStep(2)">Door naar Mapping →</button>`:`<p class="muted">Nog geen bestand geüpload.</p>`}</div><div class="card panel"><h3>Integraties later</h3><p class="muted">Odoo, Exact, AFAS, WooCommerce, SFTP en Custom API komen via dezelfde normalisatielaag binnen.</p></div></div></div>`;}
function mappingStep(){return `<div class="workflowCard card"><h2>2. Mapping</h2><p class="muted">Mega slimme CSV-detectie: fuzzy matching, synoniemen, spelfouten, NL/EN en waardeherkenning.</p>${state.csvHeaders.length?mappingContent():`<div class="notice">Upload eerst een CSV in stap 1 Import.</div>`}</div>`;}
function mappingContent(){
  const required=['order_number','customer_name','postal_code','city','delivery_date'];
  const mapped=Object.values(state.mapping).filter(Boolean);
  const missing=required.filter(f=>!mapped.includes(f));
  return `<div class="mappingGridFull"><div><div class="mappingToolbar"><button class="btn accent" onclick="runSmartDetect()">Smart detect opnieuw</button><button class="btn" onclick="commitImport()">Importeer naar Queue</button><input id="templateName" class="input templateInput" placeholder="Template naam opslaan"></div><div class="table mappingTable"><div class="tableRow mapHead"><span>CSV kolom</span><span>Voorbeelden</span><span>Gekoppeld veld</span><span>Confidence</span></div>${state.csvHeaders.map(h=>mappingRow(h)).join('')}</div></div><div class="card panel fieldPicker"><h3>Smart Field Picker</h3><input id="fieldSearch" class="input" placeholder="Zoek veld: postcode, pallets, leverdatum..." oninput="renderFieldCatalog(this.value)"><div id="fieldCatalog" class="fieldCatalog">${fieldCatalogHtml('')}</div><div class="notice ${missing.length?'':'greenNotice'}"><b>${missing.length?'Ontbrekend':'Compleet'}</b><br>${missing.length?missing.map(labelForField).join(', '):'Alle verplichte velden zijn gemapt.'}</div></div></div>`;
}
function mappingRow(h){const det=(state.detections||[]).find(d=>d.column===h); const best=det?.best; const current=state.mapping[h] || best?.field_id || ''; if(!state.mapping[h] && best && best.score>=82) state.mapping[h]=best.field_id; const samples=(det?.samples||[]).slice(0,3).map(escapeHtml).join(' · '); return `<div class="tableRow"><b>${escapeHtml(h)}</b><span class="muted">${samples}</span><select onchange="state.mapping['${escapeHtml(h)}']=this.value; render()"><option value="">Niet mappen</option>${state.fields.map(f=>`<option value="${f.id}" ${current===f.id?'selected':''}>${f.label} · ${f.category}</option>`).join('')}</select><span class="conf ${best?.score<75?'warn':''}">${best?best.score+'%':'—'}</span></div>`;}
function fieldCatalogHtml(query){const q=(query||'').toLowerCase(); const fields=state.fields.filter(f=>!q || (f.label+' '+f.id+' '+f.category+' '+(f.aliases||[]).join(' ')).toLowerCase().includes(q)); const grouped={}; fields.forEach(f=>{(grouped[f.category]||(grouped[f.category]=[])).push(f)}); return Object.entries(grouped).map(([cat,fs])=>`<div class="fieldCat"><h4>${cat}</h4>${fs.map(f=>`<div class="fieldItem"><b>${f.label}</b><span class="badge">${f.type||'text'}</span></div>`).join('')}</div>`).join('');}
function renderFieldCatalog(q){const el=document.getElementById('fieldCatalog'); if(el) el.innerHTML=fieldCatalogHtml(q);}
function labelForField(id){const f=state.fields.find(x=>x.id===id); return f?f.label:id;}
function queueStep(){const orders=state.queue?.orders||[]; const geo=state.geocodeResult; const geocoded=orders.filter(o=>o.latitude&&o.longitude).length; return `<div class="workflowCard card"><h2>3. Queue</h2><p class="muted">Echte geïmporteerde orders verschijnen hier. Valideer adressen met PDOK/BAG voordat je optimaliseert.</p><div class="mappingToolbar"><button class="btn accent" onclick="geocodeQueue()">Adressen valideren via PDOK/BAG</button><button class="btn" onclick="setStep(4)">Door naar Optimize →</button><span class="badge ${geocoded?'green':'orange'}">${geocoded}/${orders.length||0} met GPS</span></div>${geo?`<div class="notice ${geo.unresolved?'':'greenNotice'}"><b>PDOK resultaat</b><br>${geo.updated} adressen gekoppeld · ${geo.unresolved} onopgelost · ${geo.total_checked} gecontroleerd</div>`:''}${orders.length?`<div class="table"><div class="tableRow head"><span>Order</span><span>Klant</span><span>Adres</span><span>Leverdatum</span><span>GPS</span><span>Status</span></div>${orders.map(o=>`<div class="tableRow"><b>${escapeHtml(o.order_number)}</b><span>${escapeHtml(o.customer_name)}</span><span class="muted">${escapeHtml((o.delivery_address||'')+' '+(o.postal_code||'')+' '+(o.city||''))}</span><span>${escapeHtml(o.delivery_date||'—')}</span><span class="badge ${o.latitude&&o.longitude?'green':'orange'}">${o.latitude&&o.longitude?'PDOK':'nodig'}</span><span class="badge ${o.status==='ready'?'green':'orange'}">${o.status}</span></div>`).join('')}</div>`:`<div class="notice">Planning Queue is leeg. Importeer orders of koppel een ERP.</div>`}</div>`;}
function optimizeStep(){return `<div class="workflowCard card"><h2>4. Optimize</h2><p class="muted">Optimizer V1: capaciteit + tijdvensters foundation + OSRM-route wanneer beschikbaar.</p>${osrmPanel()}<button class="btn accent" onclick="runOptimize()">Optimaliseer routes</button>${state.optimizeResult?`<pre>${escapeHtml(JSON.stringify(state.optimizeResult,null,2))}</pre>`:''}</div>`;}
function publishStep(){return `<div class="workflowCard card"><h2>5. Publish</h2><p class="muted">Routes publiceren naar chauffeur-app, klanttracking en live kaart.</p><div class="notice">Publish wordt actief zodra routes gegenereerd zijn.</div></div>`;}
function routes(){return shell(`<h1 class="pageTitle">Routes</h1><p class="subtitle">Gegenereerde routes verschijnen hier na optimalisatie.</p><div class="workflowCard card"><h2>Routes</h2><pre>${escapeHtml(JSON.stringify(state.mapState?.routes||[],null,2))}</pre></div>`)}
function simple(title,txt){return shell(`<h1 class="pageTitle">${title}</h1><p class="subtitle">${txt}</p><div class="workflowCard card"><h2>Module foundation</h2><p class="muted">Deze pagina is klaar voor echte data en forms. Geen dummydata.</p></div>`)}
function settings(){return shell(`<h1 class="pageTitle">Instellingen</h1><p class="subtitle">OSRM, integraties, depots, transport-units en API keys.</p><div class="moduleGrid"><div class="card panel"><h3>OSRM Nederland setup</h3><pre>cd /home/ubuntu/algoroute_latest/algoroute_v1_5_optimizer_full_mapping
sudo ./scripts/setup_osrm_nl.sh</pre></div><div>${osrmPanel()}</div></div>`)}
function render(){const pages={dashboard,live,planning,routes,vehicles:()=>simple('Wagenpark','Voertuigen, capaciteit, onderhoud en EV-profielen.'),drivers:()=>simple('Chauffeurs','Chauffeurs, beschikbaarheid en app-toegang.'),orders:()=>simple('Orders','Alle geïmporteerde en handmatige orders.'),load:()=>simple('Load Optimization','Pallets, rolcontainers, LIFO en later 2D/3D belading.'),tracking:()=>simple('Klanttracking','Trackinglinks en klantmeldingen.'),reports:()=>simple('Rapportages','Punctualiteit, routekwaliteit, load en EV.'),settings}; document.getElementById('app').innerHTML=(pages[state.page]||dashboard)(); setTimeout(initMap,50);}
function detectDelimiter(text){const first=text.split(/\r?\n/).slice(0,5).join('\n'); const candidates=[',',';','\t','|']; return candidates.map(d=>[d,(first.match(new RegExp('\\'+d,'g'))||[]).length]).sort((a,b)=>b[1]-a[1])[0][0];}
function parseCsv(text){const d=detectDelimiter(text); const rows=[]; let row=[], cell='', q=false; for(let i=0;i<text.length;i++){const c=text[i], n=text[i+1]; if(c==='"'&&q&&n==='"'){cell+='"';i++;} else if(c==='"'){q=!q;} else if(c===d&&!q){row.push(cell);cell='';} else if((c==='\n'||c==='\r')&&!q){ if(c==='\r'&&n==='\n') i++; row.push(cell); if(row.some(x=>String(x).trim()!=='')) rows.push(row); row=[]; cell=''; } else cell+=c; } if(cell||row.length){row.push(cell); rows.push(row);} const headers=(rows.shift()||[]).map(h=>h.trim()); return {headers, rows:rows.map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]||''])))};}
async function handleCsvUpload(e){const file=e.target.files[0]; if(!file) return; const text=await file.text(); const parsed=parseCsv(text); state.csvHeaders=parsed.headers; state.csvRows=parsed.rows; state.mapping={}; await runSmartDetect(false); state.planningStep=2; render();}
async function runSmartDetect(doRender=true){if(!state.csvHeaders.length)return; const res=await api('/api/import/detect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({headers:state.csvHeaders,rows:state.csvRows.slice(0,50)})}); state.detections=res.detections||[]; state.detections.forEach(d=>{if(d.best&&d.best.score>=82&&!state.mapping[d.column]) state.mapping[d.column]=d.best.field_id}); if(doRender) render();}
async function commitImport(){if(!state.csvRows.length)return alert('Geen CSV geladen'); const templateName=document.getElementById('templateName')?.value||''; const res=await api('/api/import/commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rows:state.csvRows,mapping:state.mapping,template_name:templateName})}); state.queue=await api('/api/planning/queue'); alert(`${res.orders_created} orders geïmporteerd (${res.ready} ready, ${res.incomplete} incomplete)`); state.planningStep=3; render();}

async function geocodeQueue(){
  state.geocodeResult=await api('/api/geocode/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({limit:500, overwrite:false})});
  state.queue=await api('/api/planning/queue');
  render();
}

async function runOptimize(){state.optimizeResult=await api('/api/planning/optimize',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})}); state.mapState=await api('/api/map/state'); render();}
window.setPage=setPage; window.setStep=setStep; window.state=state; window.handleCsvUpload=handleCsvUpload; window.runSmartDetect=runSmartDetect; window.commitImport=commitImport; window.runOptimize=runOptimize; window.geocodeQueue=geocodeQueue; window.renderFieldCatalog=renderFieldCatalog;
init(); bootIntro();
