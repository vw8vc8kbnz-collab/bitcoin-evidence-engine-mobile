# AlgoRoute v1.6.2 Compose Hotfix

Fixes missing docker-compose.yml from v1.6.1 while retaining PDOK/BAG geocoding, OSRM foundation, and the fullscreen 4K intro asset.
