RoomBudget v1.0.7 - 4K curated style photo tiles + stable fallbacks
Port default: 8907
AI provider default: mock
