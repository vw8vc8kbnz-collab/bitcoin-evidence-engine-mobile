# METOD/PAX FIX659R1

**Build marker:** `FIX659R1_ADAPTIVE_CNC_MOBILE_FIT`

This is a surgical viewer release on top of FIX659.

## What changes
- CNC holes/arcs keep their exact 1px line weight but automatically switch between dark anthracite and near-white based on the material pixels underneath.
- Mobile panel preview reserves room for dimension graphics so outer measurements stay inside the visible canvas.
- On mobile the actual panel size is shown on its own line and cannot disappear behind a truncated long template name.

## What does not change
Pricing, CSV truth, taxonomy, Admin filter overrides, optimizer, finalization, request/submit flow, security policy and the `:8790 -> 127.0.0.1:8792` infrastructure are unchanged.

Deploy with `INSTALL_FIX659R1_FROM_STAGE.sh`. The installer performs all regressions and production preflight before touching live files, then creates backups and retains rollback behavior.
