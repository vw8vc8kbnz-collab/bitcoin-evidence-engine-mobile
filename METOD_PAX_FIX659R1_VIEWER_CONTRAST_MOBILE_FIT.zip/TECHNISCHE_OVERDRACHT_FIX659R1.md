# Technische overdracht — FIX659R1_ADAPTIVE_CNC_MOBILE_FIT

## Baseline
FIX659_MATERIAL_SWATCH_VIEWER is the direct parent. This release changes only viewer rendering/layout plus build/preflight/deployment markers.

## Adaptive CNC contrast
Implementation: `app/toolA_material_swatch_renderer.js` exports `contrastStrokeAt(ctx,x,y,opts)`.

The function samples a small area from the already rendered canvas. Canvas coordinates are converted from CSS pixels to backing-store pixels using the canvas DPR ratio. It calculates relative luminance and selects the higher-contrast technical stroke:
- light background: `rgba(18,28,25,.90)`
- dark background: `rgba(247,250,248,.94)`
- controlled fallback: `rgba(64,177,113,.95)`

The boring/arc render block in `toolA.html` remains `ctx.lineWidth = 1` with the existing dashed technical style. There is deliberately no `shadowBlur`, halo, duplicate stroke or width increase.

## Mobile dimension-safe fit
Implementation: `app/toolA_view_math_helpers.js` exports `computePanelPreviewFit(opts)`.

Desktop values reproduce FIX659 exactly: 34px pad and 0.90 fit multiplier.

Mobile uses a fit box with explicit space for header/footer and dimension gutters. This means the panel is fitted *after* reserving the area used by the top/left dimension graphics. The panel/DXF preview bounds remain the geometry input; production dimensions are never changed.

Mobile title copy was separated:
1. template name (may ellipsize),
2. actual `width x total-height mm` on its own line,
3. view/boring explanation.

## Cache bust
- `toolA_view_math_helpers.js?v=659r1`
- `toolA_material_swatch_renderer.js?v=659r1`
- `decor_library.js?v=659r1`

## Regression protection
`tools/fix659r1_regression.py` proves among other things:
- current 597-record CSV stays valid;
- EUR 69.57 remains a gross/incl-VAT sheet price;
- all FIX658 taxonomy/Admin override contracts remain;
- material cover math remains non-repeating and aspect-correct;
- light material selects dark CNC stroke and dark material selects light stroke;
- hole line remains exactly 1px with no halo;
- mobile fit leaves dimension-safe margins;
- desktop fit math remains numerically identical to FIX659;
- submit/security/SSE/optimizer contracts remain.

## Protected files verified byte-identical to FIX659
- `pricing_helpers.py`
- `dxf_nesting_optimizer.py`
- `catalog_importer.py`
- `catalog_taxonomy.py`
- `server_helpers.py`
- `decor_library.js`
- `toolA_overview_fix655.js`
- `config/pricing_active.json`
- `material_library.json`

`server_py.py` differs from FIX659 only by the build marker.

## Deployment
Public contract remains:
- Tool A: `http://51.195.102.180:8790/`
- Admin: `http://51.195.102.180:8790/admin/`
- Nginx public `:8790`
- Python loopback `127.0.0.1:8792`

Do not combine this release with a TLS/URL migration.
