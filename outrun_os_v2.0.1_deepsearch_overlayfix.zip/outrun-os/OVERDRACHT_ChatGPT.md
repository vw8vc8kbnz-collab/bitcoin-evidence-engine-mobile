# OVERDRACHT — Outrun OS v2.0.1 Deep Search Stability

## Context
Gebaseerd op v2.0.0 Foundation. User zag in screen recording dat Deep Search binnen enkele seconden 80/80 en 100% aangaf, terwijl detailpagina 0 pagina's / 0 bewijs toonde. Ook sprong de detail-overlay/drawer steeds op iPhone.

## Fixes
1. Deep Search mag niet meer succesvol eindigen met 0 pagina's. Bij 0 fetched pages wordt een failed crawl_run opgeslagen en de job faalt zichtbaar met foutmelding.
2. Job engine fake't geen max_pages meer als eindstand. Voor deep_search blijft current/total gebaseerd op echte pipeline-progress.
3. Deep crawl zet aan het einde final progress op echte aantallen: `len(pages) / len(pages)` met bericht hoeveel pagina's/signalen zijn opgeslagen.
4. Frontend pollt jobs nog steeds live, maar re-rendert de drawer niet meer elke seconde tijdens een actieve job. Daardoor reset Safari scroll/viewport niet continu.
5. Drawer krijgt body scroll-lock en 100dvh, zodat iPhone Safari bottom/top bars minder layout jumps veroorzaken.

## Nog niet opgelost / vervolg
- Deep Search is nu technisch eerlijker, maar de inhoudelijke crawler moet nog verder uitgebreid worden met echte externe/social search, Google/news/reviews en bronkwaliteit.
- Company Master Database gebruikt nog fallback/generated data tenzij echte CSV/KvK/open-data import wordt geladen.
