# Outrun OS v2.0.1

Bugfix release voor Deep Search en iPhone overlay-stabiliteit.

- Deep Search met 0 pagina’s wordt nu FAILED, niet fake complete.
- Job progress toont echte gecrawlde pagina’s in plaats van 80/80 dummy.
- Drawer/overlay springt niet meer iedere seconde door job-polling.
- iPhone drawer gebruikt 100dvh + body scroll lock.
