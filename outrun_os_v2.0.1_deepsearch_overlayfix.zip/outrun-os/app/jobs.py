"""Simple persisted background jobs with live progress for iPhone dashboard.

Jobs are intentionally lightweight: one process, SQLite-backed status, thread per
manual action. This gives immediate UI feedback for long-running work without
adding Redis/Celery or another service on the VPS.
"""
from __future__ import annotations

import json
import threading
import time
import traceback
from typing import Callable, Any

from . import config, db


def init_jobs_table():
    with db.get_conn() as c:
        c.execute("""
        CREATE TABLE IF NOT EXISTS jobs(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tenant_id TEXT NOT NULL,
          kind TEXT NOT NULL,
          target_id INTEGER,
          status TEXT NOT NULL DEFAULT 'queued',
          title TEXT,
          message TEXT,
          current INTEGER DEFAULT 0,
          total INTEGER DEFAULT 0,
          percent REAL DEFAULT 0,
          eta_seconds INTEGER,
          started_at REAL,
          updated_at REAL,
          finished_at REAL,
          result_json TEXT,
          error TEXT
        )
        """)
        c.execute("CREATE INDEX IF NOT EXISTS idx_jobs_tenant_status ON jobs(tenant_id,status,updated_at)")


def create(kind: str, title: str, total: int = 0, target_id: int | None = None, message: str = "Wachtrij") -> int:
    init_jobs_table()
    now = time.time()
    with db.get_conn() as c:
        cur = c.execute("""
          INSERT INTO jobs(tenant_id,kind,target_id,status,title,message,current,total,percent,started_at,updated_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """, (config.TENANT, kind, target_id, 'queued', title, message, 0, int(total or 0), 0, None, now))
        return int(cur.lastrowid)


def update(job_id: int, *, status: str | None = None, message: str | None = None,
           current: int | None = None, total: int | None = None, result: dict | None = None,
           error: str | None = None, eta_seconds: int | None = None):
    now = time.time()
    with db.get_conn() as c:
        row = c.execute("SELECT * FROM jobs WHERE id=? AND tenant_id=?", (job_id, config.TENANT)).fetchone()
        if not row:
            return
        cur = int(row['current'] or 0) if current is None else int(current)
        tot = int(row['total'] or 0) if total is None else int(total or 0)
        pct = 0 if tot <= 0 else min(100, round((cur / tot) * 100, 1))
        finished_at = row['finished_at']
        started_at = row['started_at']
        if status == 'running' and not started_at:
            started_at = now
        if status in ('complete', 'failed'):
            finished_at = now
            pct = 100 if status == 'complete' else pct
        c.execute("""
          UPDATE jobs SET status=COALESCE(?,status), message=COALESCE(?,message), current=?, total=?, percent=?,
            eta_seconds=?, started_at=?, updated_at=?, finished_at=?, result_json=COALESCE(?,result_json), error=COALESCE(?,error)
          WHERE id=? AND tenant_id=?
        """, (status, message, cur, tot, pct, eta_seconds, started_at, now, finished_at,
              json.dumps(result, ensure_ascii=False) if result is not None else None,
              error, job_id, config.TENANT))


def _estimate_eta(started_at: float | None, current: int, total: int) -> int | None:
    if not started_at or current <= 0 or total <= 0 or current >= total:
        return None
    elapsed = max(0.1, time.time() - started_at)
    rate = current / elapsed
    return int(max(0, (total - current) / rate)) if rate > 0 else None


def progress(job_id: int, message: str, current: int, total: int):
    with db.get_conn() as c:
        row = c.execute("SELECT started_at FROM jobs WHERE id=? AND tenant_id=?", (job_id, config.TENANT)).fetchone()
    eta = _estimate_eta(row['started_at'] if row else None, int(current or 0), int(total or 0))
    update(job_id, status='running', message=message, current=current, total=total, eta_seconds=eta)


def get(job_id: int) -> dict | None:
    init_jobs_table()
    with db.get_conn() as c:
        row = c.execute("SELECT * FROM jobs WHERE id=? AND tenant_id=?", (job_id, config.TENANT)).fetchone()
    if not row:
        return None
    d = dict(row)
    for k in ('result_json',):
        try:
            d[k.replace('_json','')] = json.loads(d.get(k) or '{}')
        except Exception:
            d[k.replace('_json','')] = {}
    return d


def list_recent(limit: int = 10) -> list[dict]:
    init_jobs_table()
    with db.get_conn() as c:
        rows = c.execute("SELECT * FROM jobs WHERE tenant_id=? ORDER BY updated_at DESC LIMIT ?", (config.TENANT, limit)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d['result'] = json.loads(d.get('result_json') or '{}')
        except Exception:
            d['result'] = {}
        out.append(d)
    return out


def start(kind: str, title: str, fn: Callable[..., Any], *, total: int = 0, target_id: int | None = None, message: str = "Starten") -> int:
    job_id = create(kind, title, total=total, target_id=target_id, message=message)

    def runner():
        try:
            update(job_id, status='running', message=message, current=0, total=total)
            result = fn(job_id)
            # Preserve explicit final current/total if fn updated them.
            # Important for Deep Search: the configured max_pages is not the
            # amount actually crawled. Never fake 80/80 when only 3 pages were
            # found. Individual pipelines should set a final current=total when
            # they have a real completed count.
            row = get(job_id) or {}
            final_current = int(row.get('current') or 0)
            final_total = int(row.get('total') or 0)
            if final_total <= 0:
                final_total = int(total or final_current or 1)
            if final_current <= 0 and int(total or 0) > 0 and kind != 'deep_search':
                final_current = int(total or final_total)
            update(job_id, status='complete', message=row.get('message') or 'Klaar', current=final_current, total=final_total, result=result or {})
        except Exception as e:
            update(job_id, status='failed', message='Mislukt', error=str(e) + '\n' + traceback.format_exc()[-1500:])

    t = threading.Thread(target=runner, daemon=True)
    t.start()
    return job_id
