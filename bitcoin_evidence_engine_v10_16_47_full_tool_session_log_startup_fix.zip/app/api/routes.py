from __future__ import annotations
from fastapi import APIRouter, Response
import asyncio
import math
import json
import uuid
import csv
import io
import zipfile
import time
from app.db.database import db
from app.services.sync_service import SyncService
from app.services.data_foundation_service import DataFoundationService
from app.services.audit_service import AuditService
from app.services.forecast_service import ForecastService
from app.services.health_service import HealthService
from app.services.time_machine_service import TimeMachineService
from app.services.evidence_attribution_service import EvidenceAttributionService
from app.services.time_machine_learning_service import TimeMachineLearningService
from app.services.adaptive_learning_service import AdaptiveLearningService
from app.services.native_core_service import NativeCoreService
from app.services.historical_memory_service import HistoricalMemoryService
from app.services.seed_export_service import SeedExportService
from app.services.time_machine_export_service import TimeMachineExportService
from app.services.session_log_service import SessionLogService
from app.engine.twin_finder import HistoricalTwinFinder
from app.core.logger import log
from app.core.config import settings
from app.core.runtime_locks import sync_lock, tm_priority_event
from app.core.debug import append_jsonl
from pathlib import Path
from fastapi.responses import FileResponse


def _clean_for_json(obj):
    """FastAPI refuses NaN/Inf values. DuckDB/Pandas can return them when some
    evidence layers are still empty. Convert all non-finite floats to None so
    the dashboard never collapses into API error while sync is running.
    """
    if obj is None:
        return None
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, int) or isinstance(obj, bool) or isinstance(obj, str):
        return obj
    if isinstance(obj, dict):
        return {str(k): _clean_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean_for_json(v) for v in obj]
    try:
        # pandas Timestamp / numpy scalars / datetime objects
        if hasattr(obj, "isoformat"):
            return obj.isoformat()
        if hasattr(obj, "item"):
            return _clean_for_json(obj.item())
    except Exception:
        pass
    return str(obj)


def _safe_df(sql: str, params=None):
    try:
        return db.df(sql, params or []).to_dict('records')
    except Exception as exc:
        log.exception("Dashboard query failed: %s", exc)
        return []


def _safe_one(sql: str, params=None):
    try:
        return db.fetchone(sql, params or [])
    except Exception as exc:
        log.exception("Dashboard scalar query failed: %s", exc)
        return None

def _real_candle_range() -> tuple | None:
    """Authoritative candle count for UI/health.

    V10.16.15: the mobile dashboard may never rely on cached sync_state for
    Historical Memory. The source of truth is always raw_candles in the shared
    DuckDB database at /home/ubuntu/bitcoin_evidence_data.
    """
    return _safe_one("""
        SELECT MIN(open_time), MAX(open_time), COUNT(*)
        FROM raw_candles
        WHERE source='binance' AND symbol=? AND interval='1h'
    """, [settings.symbol])

def _authoritative_history_payload() -> dict:
    row = _real_candle_range()
    target = int(getattr(settings, 'historical_target_rows_1h', 70000))
    count = int(row[2] or 0) if row else 0
    min_ts = int(row[0]) if row and row[0] is not None else None
    max_ts = int(row[1]) if row and row[1] is not None else None
    raw_coverage = min(100.0, (count / target) * 100.0) if target else 0.0
    complete = bool(count >= target or (min_ts is not None and min_ts <= int(settings.historical_start_ms) + 2 * 3600000))
    coverage = 100.0 if complete else raw_coverage
    return {
        "symbol": settings.symbol,
        "interval": "1h",
        "stored_rows": count,
        "rows": count,
        "target_rows": target,
        "target_years": settings.historical_target_years,
        "min_ts": min_ts,
        "max_ts": max_ts,
        "coverage_pct": round(coverage, 2),
        "raw_coverage_pct": round(raw_coverage, 2),
        "remaining_rows": max(0, target - count),
        "complete": complete,
        "running": False,
        "loading_state": "complete" if complete else "backfill_required",
        "status_label": "Volledig geladen" if complete else "Aanvullen nodig",
        "ui_message": (
            f"Volledig geladen in gedeelde database · {count:,}/{target:,} · 100%"
            if complete else f"Aanvullen nodig · {count:,}/{target:,} · {raw_coverage:.2f}%"
        ),
        "shared_data_dir": str(settings.data_dir),
        "db_path": str(settings.db_path),
        "status_source": "authoritative_raw_candles",
    }


def _external_data_status_payload() -> dict:
    """Cheap, stable evidence-data status for mobile UI and exports.

    This must never call external APIs or heavy rebuilds. It only inspects the
    shared DuckDB warehouse so the phone app can always show what data is truly
    present right now.
    """
    metrics = [
        ("Binance Spot candles", "raw_candles", "binance", "BTCUSDT 1h OHLCV", "core_price"),
        ("Binance Futures funding", "raw_metric_points", "binance_futures", "funding_rate", "futures"),
        ("Binance Futures open interest", "raw_metric_points", "binance_futures", "open_interest_value", "futures"),
        ("Long/Short ratio", "raw_metric_points", "binance_futures", "long_short_ratio", "futures"),
        ("Top position L/S", "raw_metric_points", "binance_futures", "top_position_long_short_ratio", "futures"),
        ("Top account L/S", "raw_metric_points", "binance_futures", "top_account_long_short_ratio", "futures"),
        ("Taker buy/sell ratio", "raw_metric_points", "binance_futures", "taker_buy_sell_ratio", "orderflow"),
        ("Taker delta", "raw_metric_points", "binance_futures", "taker_delta_ratio", "orderflow"),
        ("Futures basis/premium", "raw_metric_points", "binance_futures", "futures_basis_premium_pct", "futures"),
        ("Composite orderbook", "raw_metric_points", "composite_orderbook", "orderbook_imbalance", "orderbook"),
        ("Fear & Greed", "raw_metric_points", "alternative_me", "fear_greed", "sentiment"),
        ("Coinbase premium", "raw_metric_points", "spot_composite", "spot_premium_coinbase_pct", "cross_exchange"),
        ("Kraken premium", "raw_metric_points", "spot_composite", "spot_premium_kraken_pct", "cross_exchange"),
        ("CoinMetrics MVRV", "raw_metric_points", "coinmetrics_community", "CapMVRVCur", "onchain"),
    ]
    rows = []
    for label, table, source, metric, group in metrics:
        try:
            if table == "raw_candles":
                r = _safe_one("SELECT COUNT(*), MIN(open_time), MAX(open_time) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
            else:
                r = _safe_one("SELECT COUNT(*), MIN(timestamp_ms), MAX(timestamp_ms) FROM raw_metric_points WHERE source=? AND metric=?", [source, metric])
            count = int(r[0] or 0) if r else 0
            min_ms = int(r[1]) if r and r[1] is not None else None
            max_ms = int(r[2]) if r and r[2] is not None else None
        except Exception:
            count, min_ms, max_ms = 0, None, None
        status = "active" if count >= 1000 else ("partial" if count > 0 else "missing")
        rows.append({"label": label, "source": source, "metric": metric, "group": group, "rows": count, "min_ms": min_ms, "max_ms": max_ms, "status": status})
    try:
        f = _safe_one("""
            SELECT COUNT(*),
                   SUM(CASE WHEN funding_rate IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN open_interest_value IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN long_short_ratio IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN taker_buy_sell_ratio IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN orderbook_imbalance IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN fear_greed IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN coinmetrics_mvrv IS NOT NULL THEN 1 ELSE 0 END)
            FROM features WHERE interval='1h'
        """)
        feature_summary = {
            "feature_rows": int(f[0] or 0) if f else 0,
            "funding_rate_rows": int(f[1] or 0) if f else 0,
            "open_interest_rows": int(f[2] or 0) if f else 0,
            "long_short_rows": int(f[3] or 0) if f else 0,
            "taker_rows": int(f[4] or 0) if f else 0,
            "orderbook_rows": int(f[5] or 0) if f else 0,
            "fear_greed_rows": int(f[6] or 0) if f else 0,
            "mvrv_rows": int(f[7] or 0) if f else 0,
        }
    except Exception:
        feature_summary = {}
    active = sum(1 for r in rows if r["status"] == "active")
    partial = sum(1 for r in rows if r["status"] == "partial")
    missing = sum(1 for r in rows if r["status"] == "missing")
    return {"rows": rows, "summary": {"active": active, "partial": partial, "missing": missing, "total": len(rows)}, "features": feature_summary}


def _model_status_payload() -> dict:
    """Cheap cockpit list: which models are active and whether they use real data.

    This is intentionally based on DB coverage, not marketing labels. A model is
    only 'real' when the underlying feature has non-null rows. Otherwise it is
    explicitly shown as proxy/missing.
    """
    ext = _external_data_status_payload()
    features = ext.get("features", {}) or {}
    def n(k):
        try: return int(features.get(k) or 0)
        except Exception: return 0
    rows = [
        {"id":"M_FAST_TWIN","name":"Historical Twin Similarity","group":"historical","status":"active","data_quality":"real","rows":_safe_one("SELECT COUNT(*) FROM raw_candles")[0] if _safe_one("SELECT COUNT(*) FROM raw_candles") else 0,"source":"Binance Spot OHLCV"},
        {"id":"M_MOMENTUM_STACK","name":"Momentum Stack","group":"price","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV derived returns"},
        {"id":"M_TREND_STRUCTURE","name":"MA Trend Structure","group":"price","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV derived MA50/MA200"},
        {"id":"M_RSI_CONTEXT","name":"RSI Context","group":"price","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV derived RSI"},
        {"id":"M_VOLUME_VOLATILITY","name":"Volume / Volatility","group":"price","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV volume/volatility"},
        {"id":"M_DRAWDOWN_REGIME","name":"Drawdown Regime","group":"regime","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV drawdown/regime"},
        {"id":"M_FUNDING_OI","name":"Funding + Open Interest","group":"futures","status":"active" if max(n("funding_rate_rows"), n("open_interest_rows")) >= 1000 else ("partial" if max(n("funding_rate_rows"), n("open_interest_rows")) > 0 else "proxy"),"data_quality":"real" if max(n("funding_rate_rows"), n("open_interest_rows")) >= 1000 else ("partial_real" if max(n("funding_rate_rows"), n("open_interest_rows")) > 0 else "proxy_from_ohlcv"),"rows":max(n("funding_rate_rows"), n("open_interest_rows")),"source":"Binance Futures"},
        {"id":"M_CROWDING","name":"Long/Short Crowding","group":"futures","status":"active" if n("long_short_rows") >= 1000 else ("partial" if n("long_short_rows") > 0 else "proxy"),"data_quality":"real" if n("long_short_rows") >= 1000 else ("partial_real" if n("long_short_rows") > 0 else "proxy_from_ohlcv"),"rows":n("long_short_rows"),"source":"Binance Futures Long/Short"},
        {"id":"M_TAKER_FLOW","name":"Taker Flow / CVD","group":"orderflow","status":"active" if n("taker_rows") >= 1000 else ("partial" if n("taker_rows") > 0 else "proxy"),"data_quality":"real" if n("taker_rows") >= 1000 else ("partial_real" if n("taker_rows") > 0 else "proxy_from_ohlcv"),"rows":n("taker_rows"),"source":"Binance Futures taker flow"},
        {"id":"M_ORDERBOOK_IMBALANCE","name":"Orderbook Imbalance","group":"orderflow","status":"live_only" if n("orderbook_rows") > 0 else "missing","data_quality":"live_only" if n("orderbook_rows") > 0 else "missing","rows":n("orderbook_rows"),"source":"Composite orderbook"},
        {"id":"M_SENTIMENT_FNG","name":"Fear & Greed","group":"sentiment","status":"active" if n("fear_greed_rows") >= 1000 else ("partial" if n("fear_greed_rows") > 0 else "missing"),"data_quality":"real" if n("fear_greed_rows") >= 1000 else ("partial_real" if n("fear_greed_rows") > 0 else "missing"),"rows":n("fear_greed_rows"),"source":"Alternative.me historical"},
        {"id":"M_ONCHAIN_MVRV","name":"On-chain MVRV","group":"onchain","status":"active" if n("mvrv_rows") else "missing","data_quality":"real" if n("mvrv_rows") else "missing","rows":n("mvrv_rows"),"source":"CoinMetrics / API key needed"},
    ]
    try:
        scores = _safe_df("SELECT model_id, horizon, total, hitrate, avg_score FROM model_scores ORDER BY total DESC LIMIT 200")
    except Exception:
        scores = []
    active = sum(1 for r in rows if r["status"] == "active")
    partial = sum(1 for r in rows if r["status"] == "partial")
    proxy = sum(1 for r in rows if r["status"] == "proxy")
    live_only = sum(1 for r in rows if r["status"] == "live_only")
    missing = sum(1 for r in rows if r["status"] == "missing")
    return {"rows": rows, "summary": {"active": active, "partial": partial, "proxy": proxy, "live_only": live_only, "missing": missing, "total": len(rows)}, "scores": scores}


def _parse_sync_progress_value(value: str | None) -> dict:
    """Parse sync_state progress strings like 'rows=123 pages=4 last_ts=...'."""
    out = {}
    if not value:
        return out
    try:
        for part in str(value).replace(',', ' ').split():
            if '=' in part:
                k, v = part.split('=', 1)
                try:
                    out[k] = int(float(v))
                except Exception:
                    out[k] = v
    except Exception:
        pass
    return out

def _count_metric(source: str, metric: str) -> int:
    r = _safe_one("SELECT COUNT(*) FROM raw_metric_points WHERE source=? AND metric=?", [source, metric])
    return int(r[0] or 0) if r else 0

def _sync_state_map() -> dict:
    rows = _safe_df("SELECT key, value, updated_at FROM sync_state")
    return {str(r.get('key')): r for r in rows}

def _backfill_jobs_map() -> dict:
    """Authoritative V10.16.29 external backfill progress.

    Keys are source:metric. This is what the mobile Data cockpit should trust
    for historical external data progress, because it contains real rows_added,
    cursor, ETA, stuck/provider-limit state and target granularity.
    """
    rows = _safe_df("""
        SELECT source, dataset, metric, status, granularity_ms, target_start_ms, target_end_ms,
               cursor_next_ms, rows_current, rows_target, coverage_pct, rows_added_last_batch,
               batches_done, pages_done, last_success_at, last_attempt_at, last_error, error_count,
               provider_limit_reached, stuck_since, eta_seconds, rows_per_minute, metadata, updated_at
        FROM backfill_jobs
        ORDER BY updated_at DESC
    """)
    return {f"{r.get('source')}:{r.get('metric')}": r for r in rows}


def _provider_status_from_job(rows: int, target: int, forced: str | None, job: dict | None) -> str:
    if forced:
        return forced
    if job:
        st = str(job.get('status') or '').strip().lower()
        if st in ('provider_limited', 'provider_limited_current', 'provider_blocked', 'rate_limited', 'stuck', 'error', 'complete', 'current', 'running', 'gap_repair_needed'):
            return st
    pct = min(100.0, float(rows) / max(1, int(target or 1)) * 100.0)
    return 'active' if pct >= 90 else ('partial' if rows > 0 else 'missing')

def _mobile_background_progress_payload() -> dict:
    """Single cheap progress endpoint for everything that can be loading in background.

    It never calls external providers and never rebuilds features. It only reads
    DuckDB counts + sync_state. This is what the phone UI should poll to avoid
    vague 'herladen' or long blank screens.
    """
    hist = _authoritative_history_payload()
    candle_rows = int(hist.get('rows') or hist.get('stored_rows') or 0)
    target_rows = int(hist.get('target_rows') or 70000)
    candle_pct = 100.0 if hist.get('complete') else (min(100.0, candle_rows / max(1, target_rows) * 100.0))
    native = NativeCoreService().status()
    tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id), MAX(created_at) FROM time_machine_tests")
    fs = _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots")
    ss = _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores")
    state = _sync_state_map()

    # Historical external warehouse coverage. V10.16.29: prefer authoritative
    # backfill_jobs rows over text-only sync_state strings. Falls back to raw DB
    # counts for sources that are not managed by a historical worker.
    expected_hourly = max(1, candle_rows)
    expected_funding = max(1, candle_rows // 8)
    jobs = _backfill_jobs_map()

    provider_defs = [
        ('Binance Spot candles', 'binance', 'raw_candles', candle_rows, target_rows, 'active' if candle_rows >= target_rows else 'partial', '1h', False),
        ('Funding', 'binance_futures', 'funding_rate', _count_metric('binance_futures','funding_rate'), expected_funding, None, '8h', True),
        ('Open Interest', 'binance_futures', 'open_interest_value', _count_metric('binance_futures','open_interest_value'), expected_hourly, None, '1h', True),
        ('Long/Short', 'binance_futures', 'long_short_ratio', _count_metric('binance_futures','long_short_ratio'), expected_hourly, None, '1h', True),
        ('Top Position L/S', 'binance_futures', 'top_position_long_short_ratio', _count_metric('binance_futures','top_position_long_short_ratio'), expected_hourly, None, '1h', True),
        ('Top Account L/S', 'binance_futures', 'top_account_long_short_ratio', _count_metric('binance_futures','top_account_long_short_ratio'), expected_hourly, None, '1h', True),
        ('Taker Flow', 'binance_futures', 'taker_buy_sell_ratio', _count_metric('binance_futures','taker_buy_sell_ratio'), expected_hourly, None, '1h', True),
        ('Coinbase Premium', 'spot_composite', 'spot_premium_coinbase_pct', _count_metric('spot_composite','spot_premium_coinbase_pct'), expected_hourly, None, '1h', False),
        ('Kraken Premium', 'spot_composite', 'spot_premium_kraken_pct', _count_metric('spot_composite','spot_premium_kraken_pct'), expected_hourly, None, '1h', False),
        ('Fear & Greed', 'alternative_me', 'fear_greed', _count_metric('alternative_me','fear_greed'), max(1, candle_rows // 24), None, '1d', False),
        ('Orderbook', 'composite_orderbook', 'orderbook_imbalance', _count_metric('composite_orderbook','orderbook_imbalance'), 1000, 'live_only', 'snapshot', False),
        ('MVRV / On-chain', 'coinmetrics_community', 'CapMVRVCur', _count_metric('coinmetrics_community','CapMVRVCur'), max(1, candle_rows // 24), 'api_key_needed', '1d', False),
    ]
    pdata=[]
    for label, source, metric, rows, target, forced, granularity, historical_worker in provider_defs:
        job = jobs.get(f'{source}:{metric}')
        if job:
            rows = int(job.get('rows_current') or rows or 0)
            target = int(job.get('rows_target') or target or 1)
        pct = min(100.0, float(rows) / max(1, int(target)) * 100.0)
        status = _provider_status_from_job(int(rows), int(target), forced, job)
        item = {
            'label': label, 'source': source, 'metric': metric, 'rows': int(rows), 'target_rows': int(target),
            'coverage_pct': round(pct, 2), 'status': status, 'granularity': granularity,
            'historical_worker': bool(historical_worker),
        }
        if job:
            item.update({
                'dataset': job.get('dataset'),
                'cursor_next_ms': job.get('cursor_next_ms'),
                'target_start_ms': job.get('target_start_ms'),
                'target_end_ms': job.get('target_end_ms'),
                'rows_added_last_batch': int(job.get('rows_added_last_batch') or 0),
                'batches_done': int(job.get('batches_done') or 0),
                'pages_done': int(job.get('pages_done') or 0),
                'last_success_at': job.get('last_success_at'),
                'last_attempt_at': job.get('last_attempt_at'),
                'last_error': job.get('last_error'),
                'provider_limit_reached': bool(job.get('provider_limit_reached')),
                'stuck_since': job.get('stuck_since'),
                'eta_seconds': job.get('eta_seconds'),
                'rows_per_minute': job.get('rows_per_minute'),
                'progress_source': 'backfill_jobs',
            })
        else:
            item['progress_source'] = 'raw_counts'
        pdata.append(item)
    external_pct = round(sum(p['coverage_pct'] for p in pdata if p['status'] not in ('api_key_needed','live_only')) / max(1, len([p for p in pdata if p['status'] not in ('api_key_needed','live_only')])), 2)

    # Use sync_state to show live background phase/rows. These are text markers,
    # not blockers.
    progress_rows = []
    for k, r in sorted(state.items()):
        if k.startswith('external_progress_') or k in ('external_evidence_backfill','external_evidence_backfill_progress','external_evidence_daemon','sync_phase','historical_memory','startup_sync_status','manual_sync_status','time_machine_current_job','coinmetrics_status'):
            progress_rows.append({'key': k, 'value': r.get('value'), 'updated_at': r.get('updated_at'), 'parsed': _parse_sync_progress_value(r.get('value'))})
    progress_rows = progress_rows[-60:]
    sync_phase = state.get('sync_phase', {}).get('value') if state else None
    tm_job_state = state.get('time_machine_current_job') or {}
    external_state = (state.get('external_evidence_backfill_progress') or state.get('external_evidence_backfill') or state.get('external_evidence_daemon') or {})

    boot_steps = [
        {'key':'ui','label':'Mobiele UI', 'status':'done', 'pct':100},
        {'key':'candles','label':'70k candles', 'status':'done' if candle_pct >= 100 else 'loading', 'pct':round(candle_pct,1), 'detail': f"{candle_rows:,}/{target_rows:,}"},
        {'key':'native','label':'Native core', 'status':'done' if native.get('available') else 'loading', 'pct':100 if native.get('available') else 40},
        {'key':'forecast','label':'Forecast cache', 'status':'loading' if bool(sync_lock.locked()) else 'done', 'pct':65 if bool(sync_lock.locked()) else 100, 'detail': sync_phase or 'idle'},
        {'key':'external','label':'Externe evidence', 'status':'done' if external_pct >= 75 else 'loading', 'pct':100 if external_pct >= 75 else external_pct, 'detail': (external_state.get('value') or 'warehouse vult op achtergrond') + f' · evidence {external_pct:.1f}%'},
    ]
    # V10.16.43: this is app-readiness, not raw evidence perfection. Do not make
    # the whole PWA look like it rebooted to 0/98% because Funding is repairing.
    overall = round(sum(float(x.get('pct') or 0) for x in boot_steps) / len(boot_steps), 1)
    return _clean_for_json({
        'ok': True,
        'engine_version': settings.engine_version,
        'overall_pct': overall,
        'sync_busy': bool(sync_lock.locked()),
        'phase': sync_phase or 'idle',
        'history': hist,
        'native': native,
        'time_machine': {
            'tests': int(tm_counts[0] or 0) if tm_counts else 0,
            'batches': int(tm_counts[1] or 0) if tm_counts else 0,
            'snapshots': int(fs[0] or 0) if fs else 0,
            'signals': int(ss[0] or 0) if ss else 0,
            'current_job': tm_job_state,
            'current_job_parsed': _parse_sync_progress_value(tm_job_state.get('value') if isinstance(tm_job_state, dict) else None),
            'persistent_status': _tm_persistent_status(None),
        },
        'boot_steps': boot_steps,
        'external': {'overall_pct': external_pct, 'providers': pdata, 'progress': progress_rows},
        'message': 'Instant boot gebruikt lokale DuckDB; externe data vult door op achtergrond.'
    })

router = APIRouter(prefix="/api")


@router.post("/session-log")
def session_log_event(payload: dict):
    try:
        event = str((payload or {}).get("event") or "frontend_event")
        data = dict((payload or {}).get("payload") or {})
        SessionLogService().append(event, data)
        return {"ok": True}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


@router.get("/session-log/txt")
def session_log_txt():
    try:
        text = SessionLogService().text(tail_lines=None)
        return Response(content=text, media_type="text/plain; charset=utf-8")
    except Exception as exc:
        return Response(content=f"session log error: {exc}\n", media_type="text/plain; charset=utf-8")





def _normalise_latest_forecast_rows(rows: list[dict]) -> list[dict]:
    """V10.16.47: make old and new forecast rows safe for mobile display.

    DB confidence is 0-100 and expected_move_pct is already a percent point.
    If an older row accidentally stored 0-100 probability, normalize it too.
    """
    out=[]
    for r in rows or []:
        x=dict(r)
        try:
            bull=float(x.get('bullish_probability') or 0.5)
            if bull>1.0:
                bull= bull/100.0
            bull=max(0.01,min(0.99,float(bull)))
            x['bullish_probability']=bull
            x['bearish_probability']=max(0.01,min(0.99,1.0-bull))
        except Exception:
            x['bullish_probability']=0.5; x['bearish_probability']=0.5
        try:
            conf=float(x.get('confidence') or 0)
            # If a broken export/UI ever wrote 4489, interpret as 44.89.
            while conf>1000:
                conf/=100.0
            if conf>100:
                conf=100.0
            x['confidence']=round(max(0.0,min(100.0,conf)),2)
        except Exception:
            x['confidence']=0
        try:
            move=float(x.get('expected_move_pct') or 0)
            # expected_move_pct must be percent points, not probability fraction.
            x['expected_move_pct']=round(max(-80.0,min(80.0,move)),6)
        except Exception:
            x['expected_move_pct']=0
        try:
            entry=float(x.get('entry_price') or x.get('start_price') or 0)
            target=float(x.get('target_price') or x.get('expected_price') or 0)
            inv=float(x.get('invalidation_price') or 0)
            if entry>0 and target>0:
                x['entry_price']=entry
                x['target_price']=target
                x['target_distance_usd']=round(target-entry, 2)
                x['target_distance_pct']=round((target-entry)/entry*100.0, 4)
            if entry>0 and inv>0:
                x['invalidation_distance_usd']=round(inv-entry, 2)
                x['invalidation_distance_pct']=round((inv-entry)/entry*100.0, 4)
        except Exception:
            pass
        out.append(x)
    return out

@router.get("/health")
def api_health():
    """Ultra-stable VPS/update health endpoint.

    V10.16.41: update.sh must never report a failed deploy while Uvicorn is
    actually running. This route therefore always returns a cheap 200 response
    first and wraps every warehouse/native detail in defensive try blocks. The
    richer mobile/dashboard endpoints still provide the deep status after boot.
    """
    payload = {
        "ok": True,
        "status": "ok",
        "engine_version": settings.engine_version,
        "data_dir": str(settings.data_dir),
        "db_path": str(settings.db_path),
        "startup_health": "ready",
    }
    try:
        candle_range = _real_candle_range()
        payload.update({
            "raw_candles": int(candle_range[2] or 0) if candle_range else 0,
            "raw_candles_min_ms": candle_range[0] if candle_range else None,
            "raw_candles_max_ms": candle_range[1] if candle_range else None,
        })
    except Exception as exc:
        payload.update({"raw_candles": 0, "health_warning": "candle_count_unavailable: " + str(exc)[:160]})
    try:
        tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id), MAX(created_at) FROM time_machine_tests")
        feature_counts = _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots")
        signal_counts = _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores")
        payload.update({
            "time_machine_tests": int(tm_counts[0] or 0) if tm_counts else 0,
            "time_machine_batches": int(tm_counts[1] or 0) if tm_counts else 0,
            "time_machine_feature_snapshots": int(feature_counts[0] or 0) if feature_counts else 0,
            "time_machine_signal_scores": int(signal_counts[0] or 0) if signal_counts else 0,
        })
    except Exception as exc:
        payload.update({"time_machine_tests": 0, "tm_health_warning": str(exc)[:160]})
    try:
        payload["native_core"] = NativeCoreService().status()
    except Exception as exc:
        payload["native_core"] = {"available": False, "error": str(exc)[:160]}
    try:
        payload["history"] = _authoritative_history_payload()
    except Exception as exc:
        payload["history"] = {"error": str(exc)[:160]}
    return _clean_for_json(payload)


@router.get("/startup-health")
def api_startup_health():
    """No-DB startup heartbeat for update scripts and Termius checks."""
    return {"ok": True, "status": "ok", "engine_version": settings.engine_version, "startup_health": "ready"}



@router.get("/mobile/quick")
def mobile_quick():
    """V10.16.23 first-paint heartbeat for iPhone/PWA.

    This endpoint intentionally avoids forecast, accuracy, evidence-status and
    wide queries. It must stay fast even while external evidence backfill or
    Random1000 is running.
    """
    candle_range = _real_candle_range()
    tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id) FROM time_machine_tests")
    feature_counts = _safe_one("SELECT COUNT(*) FROM time_machine_feature_snapshots")
    signal_counts = _safe_one("SELECT COUNT(*) FROM time_machine_signal_scores")
    adaptive_counts = _safe_one("SELECT COUNT(*) FROM adaptive_feature_weights")
    adaptive_model_counts = _safe_one("SELECT COUNT(*) FROM adaptive_model_weights")
    ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
    latest_candle = _safe_one("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
    price = ticker_price or latest_candle
    native_status = NativeCoreService().status()
    return _clean_for_json({
        "ok": True,
        "engine_version": settings.engine_version,
        "sync_busy": bool(sync_lock.locked()),
        "btc_price": float(price[0]) if price and price[0] is not None else None,
        "raw_candles": int(candle_range[2] or 0) if candle_range else 0,
        "raw_candles_min_ms": candle_range[0] if candle_range else None,
        "raw_candles_max_ms": candle_range[1] if candle_range else None,
        "target_rows": 70000,
        "native_available": bool(native_status.get("available")),
        "learning": {
            "time_machine_tests": int(tm_counts[0] or 0) if tm_counts else 0,
            "time_machine_batches": int(tm_counts[1] or 0) if tm_counts else 0,
            "feature_snapshots": int(feature_counts[0] or 0) if feature_counts else 0,
            "signal_events": int(signal_counts[0] or 0) if signal_counts else 0,
            "adaptive_feature_dimensions": int(adaptive_counts[0] or 0) if adaptive_counts else 0,
            "adaptive_model_dimensions": int(adaptive_model_counts[0] or 0) if adaptive_model_counts else 0,
        }
    })

@router.get("/mobile/status-fast")
def mobile_status_fast():
    """Ultra-stable mobile status endpoint.

    Used by the iPhone UI as the primary heartbeat. It only does cheap SQL
    counts and therefore should stay responsive while external evidence backfill,
    Random1000, or forecast work is running.
    """
    candle_range = _real_candle_range()
    tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id), MAX(created_at) FROM time_machine_tests")
    feature_counts = _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots")
    signal_counts = _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores")
    adaptive_counts = _safe_one("SELECT COUNT(*), MAX(updated_at) FROM adaptive_feature_weights")
    adaptive_model_counts = _safe_one("SELECT COUNT(*), MAX(updated_at) FROM adaptive_model_weights")
    ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
    latest_candle = _safe_one("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
    price = ticker_price or latest_candle
    latest_items = _normalise_latest_forecast_rows(_safe_df("""
        SELECT horizon, bullish_probability, bearish_probability, expected_move_pct,
               expected_price, invalidation_price, confidence, status, due_at_ms, contributions_json
        FROM forecast_items
        WHERE run_id=(SELECT run_id FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1)
        ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
    """))
    accuracy = _safe_df("""
        SELECT horizon, COUNT(*) AS total,
               SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS correct,
               AVG(CASE WHEN target_reached THEN 1.0 ELSE 0.0 END) AS hitrate,
               AVG(total_score) AS avg_score
        FROM time_machine_tests
        GROUP BY horizon
        ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
    """)
    return _clean_for_json({
        "ok": True,
        "engine_version": settings.engine_version,
        "api_status": "busy" if sync_lock.locked() else "ok",
        "sync_busy": bool(sync_lock.locked()),
        "btc_price": float(price[0]) if price and price[0] is not None else None,
        "history": _authoritative_history_payload(),
        "native": NativeCoreService().status(),
        "learning": {
            "time_machine_tests": int(tm_counts[0] or 0) if tm_counts else 0,
            "time_machine_batches": int(tm_counts[1] or 0) if tm_counts else 0,
            "latest_test_at": tm_counts[2] if tm_counts else None,
            "feature_snapshots": int(feature_counts[0] or 0) if feature_counts else 0,
            "latest_feature_snapshot_at": feature_counts[1] if feature_counts else None,
            "signal_events": int(signal_counts[0] or 0) if signal_counts else 0,
            "latest_signal_at": signal_counts[1] if signal_counts else None,
            "adaptive_feature_dimensions": int(adaptive_counts[0] or 0) if adaptive_counts else 0,
            "adaptive_model_dimensions": int(adaptive_model_counts[0] or 0) if adaptive_model_counts else 0,
            "latest_adaptive_at": (adaptive_counts[1] if adaptive_counts and adaptive_counts[1] else (adaptive_model_counts[1] if adaptive_model_counts else None)),
        },
        "candle_range": {"from_ms": candle_range[0] if candle_range else None, "to_ms": candle_range[1] if candle_range else None, "rows": int(candle_range[2] or 0) if candle_range else 0},
        "latest_items": latest_items,
        "accuracy": accuracy,
        # V10.16.21: keep this heartbeat ultra-light. Do not include external_data here;
        # those counts can be inspected through /api/evidence/data-sources and export ZIPs.
        "sync_state": _safe_df("SELECT key, value, updated_at FROM sync_state WHERE key IN ('historical_memory','sync_phase','startup_sync_status','manual_sync_status','external_evidence_backfill') ORDER BY updated_at DESC LIMIT 8"),
    })


@router.get("/mobile/background-progress")
def mobile_background_progress():
    return _mobile_background_progress_payload()


@router.get("/mobile/live-progress")
def mobile_live_progress():
    """V10.16.27 live progress cockpit for iPhone.

    One cheap endpoint for startup, external backfill and Time Machine progress.
    It is DB-only: no external API calls, no feature rebuilds, no locks.
    """
    payload = _mobile_background_progress_payload()
    try:
        external = payload.get('external', {}) or {}
        providers = external.get('providers', []) or []
        for p in providers:
            rows = int(p.get('rows') or 0)
            target = max(1, int(p.get('target_rows') or 1))
            remaining = max(0, target - rows)
            p['remaining_rows'] = remaining
            if p.get('status') == 'api_key_needed':
                p['eta_text'] = 'API-key nodig'
            elif rows <= 0:
                p['eta_text'] = 'wacht op eerste backfill'
            elif remaining <= 0:
                p['eta_text'] = 'volledig genoeg'
            else:
                p['eta_text'] = f'nog {remaining:,} rijen'.replace(',', '.')
        payload['external']['providers'] = providers
        payload['live_note'] = 'Deze percentages komen uit DuckDB-rijtellingen en worden live ververst; externe bronnen vullen op de achtergrond.'
    except Exception as exc:
        payload['live_progress_error'] = str(exc)
    return _clean_for_json(payload)

@router.get("/mobile/evidence-status")
def mobile_evidence_status():
    """Separate, non-critical evidence status. If this is slow or fails, the core app still loads."""
    try:
        return _clean_for_json({"ok": True, "external_data": _external_data_status_payload(), "model_status": _model_status_payload()})
    except Exception as exc:
        log.exception("Mobile evidence status failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc), "external_data": {"rows": [], "summary": {}, "features": {}}, "model_status": {"rows": [], "summary": {}}})

@router.get("/dashboard/status")
def dashboard_status():
    """Fast, lightweight dashboard status.

    This endpoint avoids heavy archive/model queries so the frontend can always
    keep price/sync/integrity visible even while the full dashboard is being
    refreshed or sync is active.
    """
    try:
        foundation = DataFoundationService()
        readiness = foundation.readiness()
        integrity = foundation.data_integrity(record_state=False)
        ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
        latest_candle = _safe_one("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
        latest_feature = _safe_df("""
            SELECT timestamp_ms, close, regime, data_completeness, funding_rate, open_interest_value,
                   open_interest_change_24h, long_short_ratio, taker_buy_sell_ratio, orderbook_imbalance,
                   orderbook_spread, taker_delta_ratio, futures_basis_premium_pct, top_position_long_short_ratio,
                   top_account_long_short_ratio, cross_exchange_spread_pct, spot_premium_kraken_pct,
                   spot_premium_coinbase_pct, coinmetrics_mvrv, fear_greed, drawdown_from_ath, cycle_progress,
                   volume_zscore, volume_ratio_24, range_pct, candle_body_pct
            FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
        """)
        sync_state = _safe_df("SELECT key, value, updated_at FROM sync_state")
        price = ticker_price or (latest_candle if latest_candle else None)
        return _clean_for_json({
            "api_status": "busy" if sync_lock.locked() else "ok",
            "btc_price": float(price[0]) if price and price[0] is not None else None,
            "latest_feature": latest_feature[0] if latest_feature else None,
            "sync_state": sync_state,
            "readiness": readiness,
            "data_integrity": integrity,
            "sync_busy": sync_lock.locked(),
            "history": _authoritative_history_payload(),
        })
    except Exception as exc:
        log.exception("Dashboard status failed: %s", exc)
        return _clean_for_json({"api_status":"error", "error":str(exc), "sync_state": _safe_df("SELECT key, value, updated_at FROM sync_state")})

@router.get("/dashboard")
def dashboard():
    try:
        # If a sync owns the pipeline, return a lightweight but useful payload.
        # Keep cached/visible price + sync state instead of forcing the frontend
        # into a red timeout/error state.
        if sync_lock.locked():
            status = dashboard_status()
            if isinstance(status, dict):
                status.setdefault("latest_items", [])
                status.setdefault("data_health", HealthService().list())
                status["message"] = "sync/forecast busy; lightweight status returned"
                return _clean_for_json(status)
        latest_run = _safe_one("SELECT run_id FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1")
        latest_items=[]
        if latest_run:
            latest_items = _normalise_latest_forecast_rows(_safe_df("""
                SELECT * FROM forecast_items WHERE run_id=?
                ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
            """, [latest_run[0]]))
        runs = _safe_df("SELECT * FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 25")
        archive = _safe_df("SELECT * FROM forecast_items ORDER BY run_id DESC, due_at_ms ASC LIMIT 150")
        acc = _safe_df("""
            SELECT horizon, COUNT(*) AS total, SUM(CASE WHEN direction_correct THEN 1 ELSE 0 END) AS correct,
                   AVG(CASE WHEN direction_correct THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(ABS(price_error_pct)) AS avg_abs_price_error
            FROM forecast_items WHERE status='resolved' GROUP BY horizon ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """)
        model_scores = _safe_df("SELECT * FROM model_scores ORDER BY hitrate DESC, total DESC LIMIT 50")
        ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
        price = ticker_price or _safe_one("SELECT close FROM raw_candles WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h' ORDER BY open_time DESC LIMIT 1")
        latest_feature = _safe_df("""
            SELECT timestamp_ms, close, regime, data_completeness, funding_rate, open_interest_value,
                   open_interest_change_24h, long_short_ratio, taker_buy_sell_ratio, orderbook_imbalance,
                   orderbook_spread, taker_delta_ratio, futures_basis_premium_pct, top_position_long_short_ratio,
                   top_account_long_short_ratio, cross_exchange_spread_pct, spot_premium_kraken_pct,
                   spot_premium_coinbase_pct, coinmetrics_mvrv, fear_greed, drawdown_from_ath, cycle_progress,
                   volume_zscore, volume_ratio_24, range_pct, candle_body_pct
            FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
        """)
        composite_orderbook = _safe_df("""
            SELECT timestamp_ms, value, metadata
            FROM raw_metric_points
            WHERE source='composite_orderbook' AND metric='orderbook_imbalance'
            ORDER BY timestamp_ms DESC LIMIT 1
        """)
        sync_state = _safe_df("SELECT key, value, updated_at FROM sync_state")
        foundation = DataFoundationService()
        readiness = foundation.readiness()
        integrity = foundation.data_integrity(record_state=False)
        result = {
            "btc_price": float(price[0]) if price and price[0] is not None else None,
            "latest_feature": latest_feature[0] if latest_feature else None,
            "latest_items": latest_items,
            "runs": runs,
            "archive": archive,
            "accuracy": acc,
            "model_scores": model_scores,
            "data_health": HealthService().list(),
            "composite_orderbook": composite_orderbook[0] if composite_orderbook else None,
            "sync_state": sync_state,
            "readiness": readiness,
            "data_integrity": integrity,
            "api_status": "ok",
        }
        return _clean_for_json(result)
    except Exception as exc:
        log.exception("Dashboard API hard failure: %s", exc)
        return _clean_for_json({
            "api_status":"error",
            "error":str(exc),
            "btc_price":None,
            "latest_items":[],
            "data_health":HealthService().list(),
            "sync_state":_safe_df("SELECT key, value, updated_at FROM sync_state"),
        })


@router.post("/sync/background")
async def sync_background():
    """Start Sync + Forecast in background and return immediately for mobile.

    V10.16.28: the iPhone browser must never wait on a long forecast/external
    provider request. This endpoint starts the exact same pipeline as /sync, but
    stores live state in sync_state so the UI can show percentage/progress.
    """
    job_id = str(uuid.uuid4())
    now_fn = __import__("app.core.time_utils", fromlist=["utc_now"]).utc_now
    if sync_lock.locked():
        return _clean_for_json({"ok": True, "queued": False, "status": "already_running", "job_id": job_id, "message": "Sync/Forecast draait al; live status blijft zichtbaar."})
    async def _runner():
        async with sync_lock:
            try:
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["manual_sync_status", f"running job={job_id} pct=5 phase=start", now_fn()])
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["sync_phase", "manual_forecast_background_start pct=5", now_fn()])
                result = await DataFoundationService().run_forecast_pipeline(source="manual_background")
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["manual_sync_status", f"complete job={job_id} pct=100 forecast_created={result.get('created')}", now_fn()])
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["sync_phase", "manual_forecast_complete pct=100", now_fn()])
                append_jsonl("sync_button_audit.jsonl", {"event":"api_sync_background_complete", "job_id":job_id, "result":result})
            except Exception as exc:
                log.exception("Background sync+forecast failed: %s", exc)
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["manual_sync_status", f"error job={job_id} pct=100 {str(exc)[:180]}", now_fn()])
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["sync_phase", "manual_forecast_error pct=100", now_fn()])
    asyncio.create_task(_runner())
    return _clean_for_json({"ok": True, "queued": True, "status": "started", "job_id": job_id, "message": "Sync + Forecast gestart op achtergrond. Volg de live voortgang op Home/Data."})

@router.post("/sync")
async def sync():
    log.info("Manual sync+forecast requested from dashboard")
    append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_entered"})
    now_fn = __import__("app.core.time_utils", fromlist=["utc_now"]).utc_now
    if sync_lock.locked():
        append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_rejected_busy"})
        return _clean_for_json({"created": False, "reason": "sync already running", "status": "busy"})
    async with sync_lock:
        try:
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["manual_sync_status", "syncing", now_fn()])
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_phase", "phase": "sync_forecast_fast_start"})
            result = await DataFoundationService().run_forecast_pipeline(source="manual")
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_phase", "phase": "data_foundation_done", "result": result})
            log.info("Manual Data Foundation sync completed. forecast_created=%s run=%s reason=%s", result.get("created"), result.get("run_id"), result.get("reason"))
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_completed", "forecast_created": result.get("created"), "run_id": result.get("run_id"), "reason": result.get("reason")})
            return _clean_for_json(result)
        except Exception as exc:
            log.exception("Manual sync+forecast failed: %s", exc)
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_failed", "error": str(exc)})
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["manual_sync_status", "error", now_fn()])
            return _clean_for_json({"created": False, "error": str(exc), "reason": str(exc)})

@router.post("/forecast")
def forecast():
    try:
        return _clean_for_json(ForecastService().create_run())
    except Exception as exc:
        log.exception("Manual forecast failed: %s", exc)
        return {"created": False, "reason": str(exc)}

@router.post("/audit")
def audit():
    return AuditService().audit_due_predictions()

@router.get("/data/readiness")
def data_readiness():
    return _clean_for_json(DataFoundationService().readiness())

@router.get("/data/integrity")
def data_integrity():
    return _clean_for_json(DataFoundationService().data_integrity())



@router.get("/native/status")
def native_status():
    return _clean_for_json(NativeCoreService().status())

@router.get("/time-machine/chart")
def time_machine_chart(timeframe: str = "1h", limit: int = 5000, start_ms: int | None = None, end_ms: int | None = None):
    return TimeMachineService().chart_points(timeframe=timeframe, limit=limit, start_ms=start_ms, end_ms=end_ms)

@router.post("/time-machine/resolve")
def time_machine_resolve(payload: dict):
    return TimeMachineService().resolve_click(int(payload.get("timestamp_ms")))

@router.post("/time-machine/run")
def time_machine_run(payload: dict):
    try:
        ts = int(payload.get("timestamp_ms"))
        log.info("Time Machine manual run requested timestamp_ms=%s", ts)
        result = TimeMachineService().run(ts, bool(payload.get("reveal", True)), persist=bool(payload.get("persist", True)), source="manual", hydrate_context=bool(payload.get("hydrate_context", False)))
        log.info("Time Machine manual run finished ok=%s items=%s", result.get("ok"), len(result.get("items", [])) if isinstance(result, dict) else "?")
        return _clean_for_json(result)
    except Exception as exc:
        tm_priority_event.clear()
        log.exception("Time Machine manual run failed: %s", exc)
        return _clean_for_json({"ok": False, "reason": str(exc), "items": []})




def _tm_job_upsert(job_id: str, **kw) -> None:
    """V10.16.35: persistent Random100/1000 job state.

    The old mobile UI used a local fake timer and a process-local dict. If Safari
    lost the request or the worker thread lived outside that dict, the card could
    stay at 72% forever. This table is now the source of truth.
    """
    try:
        from app.core.time_utils import utc_now
        now = utc_now()
        row = db.fetchone("SELECT job_id FROM time_machine_jobs WHERE job_id=?", [job_id])
        meta = kw.get('metadata')
        if meta is not None and not isinstance(meta, str):
            meta = json.dumps(meta, ensure_ascii=False)
        vals = {
            'batch_id': kw.get('batch_id'), 'status': kw.get('status'), 'phase': kw.get('phase'),
            'count': kw.get('count'), 'expected_tests': kw.get('expected_tests'), 'progress_pct': kw.get('progress_pct'),
            'tests_written': kw.get('tests_written'), 'snapshots_written': kw.get('snapshots_written'), 'signals_written': kw.get('signals_written'),
            'export_ready': kw.get('export_ready'), 'download_url': kw.get('download_url'), 'error': kw.get('error'),
            'started_at': kw.get('started_at'), 'updated_at': now, 'completed_at': kw.get('completed_at'), 'metadata': meta,
        }
        if row:
            sets=[]; params=[]
            for k,v in vals.items():
                if v is not None:
                    sets.append(f"{k}=?"); params.append(v)
            if sets:
                params.append(job_id)
                db.execute(f"UPDATE time_machine_jobs SET {', '.join(sets)} WHERE job_id=?", params)
        else:
            db.execute("""
                INSERT INTO time_machine_jobs(job_id,batch_id,status,phase,count,expected_tests,progress_pct,tests_written,snapshots_written,signals_written,export_ready,download_url,error,started_at,updated_at,completed_at,metadata)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, [job_id, vals['batch_id'], vals['status'], vals['phase'], vals['count'], vals['expected_tests'], vals['progress_pct'], vals['tests_written'] or 0, vals['snapshots_written'] or 0, vals['signals_written'] or 0, bool(vals['export_ready']) if vals['export_ready'] is not None else False, vals['download_url'], vals['error'], vals['started_at'] or now, now, vals['completed_at'], vals['metadata']])
    except Exception as exc:
        append_jsonl('time_machine_background_audit.jsonl', {'event':'tm_job_upsert_failed_v101635','job_id':job_id,'error':str(exc)})


def _tm_count_for_batch(table: str, batch_id: str | None) -> int:
    try:
        if batch_id:
            return int((db.fetchone(f"SELECT COUNT(*) FROM {table} WHERE batch_id=?", [batch_id]) or [0])[0] or 0)
        return int((db.fetchone(f"SELECT COUNT(*) FROM {table}") or [0])[0] or 0)
    except Exception:
        return 0


def _tm_job_latest_row(job_or_batch_id: str | None = None) -> dict | None:
    try:
        if job_or_batch_id:
            rows = _safe_df("""
                SELECT * FROM time_machine_jobs
                WHERE job_id=? OR batch_id=?
                ORDER BY updated_at DESC LIMIT 1
            """, [job_or_batch_id, job_or_batch_id])
        else:
            rows = _safe_df("SELECT * FROM time_machine_jobs ORDER BY updated_at DESC LIMIT 1")
        return rows[0] if rows else None
    except Exception:
        return None



def _tm_latest_batch_snapshot() -> dict | None:
    """V10.16.43: detect the real latest persisted Time Machine batch.

    If Safari closes or the process-local status is lost, the truth is the DB:
    time_machine_tests + snapshots + latest export pointer. This allows the UI
    to resume instead of falling back to a fake 0/35% progress card.
    """
    try:
        row = _safe_one("""
            SELECT batch_id, COUNT(*) AS tests, MAX(created_at) AS last_created
            FROM time_machine_tests
            WHERE batch_id IS NOT NULL
            GROUP BY batch_id
            ORDER BY MAX(created_at) DESC
            LIMIT 1
        """)
        if not row or not row[0]:
            return None
        batch_id = row[0]
        tests = int(row[1] or 0)
        snaps = _tm_count_for_batch('time_machine_feature_snapshots', batch_id)
        signals = _tm_count_for_batch('time_machine_signal_scores', None)
        export = TimeMachineExportService().latest_info()
        return {'batch_id': batch_id, 'tests': tests, 'snapshots': snaps, 'signals': signals, 'export': export, 'last_created': row[2]}
    except Exception as exc:
        append_jsonl('time_machine_background_audit.jsonl', {'event':'tm_latest_batch_snapshot_failed_v101643','error':str(exc)})
        return None


def _tm_repair_stale_job(row: dict | None) -> dict | None:
    """Repair jobs that stayed queued/running after app close/restart.

    Common failure mode seen on iPhone/PWA: the native run finishes and tables are
    written, but the browser poll or async final update is lost. Then the UI can
    remain stuck at 35/72%. This function reconciles the job table with actual
    persisted batch rows and latest export state before returning status.
    """
    if not row:
        return row
    try:
        status = str(row.get('status') or '').lower()
        if status in ('completed','error'):
            return row
        expected = int(row.get('expected_tests') or (int(row.get('count') or 0) * 7) or 0)
        batch_id = row.get('batch_id')
        snap = None
        if batch_id:
            snap = {'batch_id': batch_id, 'tests': _tm_count_for_batch('time_machine_tests', batch_id), 'snapshots': _tm_count_for_batch('time_machine_feature_snapshots', batch_id), 'signals': _tm_count_for_batch('time_machine_signal_scores', None), 'export': TimeMachineExportService().latest_info()}
        else:
            snap = _tm_latest_batch_snapshot()
        if expected and snap and int(snap.get('tests') or 0) >= expected and int(snap.get('snapshots') or 0) >= expected:
            export = snap.get('export') or {}
            download_url = export.get('download_url') if isinstance(export, dict) else None
            _tm_job_upsert(str(row.get('job_id')), batch_id=snap.get('batch_id'), status='completed', phase='export_ready', progress_pct=100, tests_written=int(snap.get('tests') or 0), snapshots_written=int(snap.get('snapshots') or 0), signals_written=int(snap.get('signals') or 0), export_ready=bool(download_url), download_url=download_url, completed_at=__import__('app.core.time_utils', fromlist=['utc_now']).utc_now(), metadata={'auto_repaired':'v10.16.43', 'reason':'persisted_batch_complete'})
            repaired = _tm_job_latest_row(str(row.get('job_id')))
            append_jsonl('time_machine_background_audit.jsonl', {'event':'tm_job_auto_repaired_complete_v101643','job_id':row.get('job_id'),'batch_id':snap.get('batch_id'),'tests':snap.get('tests'),'snapshots':snap.get('snapshots')})
            return repaired or row
        # If it is old and no rows are moving, label it as stalled but keep data intact.
        try:
            import datetime as _dt
            upd = row.get('updated_at')
            if upd:
                if isinstance(upd, str):
                    parsed = _dt.datetime.fromisoformat(upd.replace('Z','+00:00'))
                else:
                    parsed = upd
                age = (_dt.datetime.now(_dt.timezone.utc) - (parsed if parsed.tzinfo else parsed.replace(tzinfo=_dt.timezone.utc))).total_seconds()
                if age > 20*60:
                    _tm_job_upsert(str(row.get('job_id')), status='stalled', phase='stalled_no_progress', progress_pct=max(float(row.get('progress_pct') or 0), 35), error='Geen voortgang gedetecteerd; jobstatus bewaard. Start Random1000 opnieuw of maak debug export.')
                    repaired = _tm_job_latest_row(str(row.get('job_id')))
                    append_jsonl('time_machine_background_audit.jsonl', {'event':'tm_job_marked_stalled_v101643','job_id':row.get('job_id'),'age_seconds':age})
                    return repaired or row
        except Exception:
            pass
    except Exception as exc:
        append_jsonl('time_machine_background_audit.jsonl', {'event':'tm_job_repair_failed_v101643','error':str(exc), 'row': row})
    return row

def _tm_persistent_status(job_or_batch_id: str | None = None) -> dict | None:
    """Persistent Time Machine job status with DuckDB row counts.

    Accepts either our request job_id or the resulting batch_id. If no table row
    exists yet, it falls back to sync_state so old jobs do not leave the UI blind.
    """
    row = _tm_repair_stale_job(_tm_job_latest_row(job_or_batch_id))
    if row:
        batch_id = row.get('batch_id')
        tests = _tm_count_for_batch('time_machine_tests', batch_id)
        snaps = _tm_count_for_batch('time_machine_feature_snapshots', batch_id)
        signals = _tm_count_for_batch('time_machine_signal_scores', None)
        expected = int(row.get('expected_tests') or (int(row.get('count') or 0) * 7) or 0)
        pct = float(row.get('progress_pct') or 0)
        status = str(row.get('status') or 'running')
        phase = str(row.get('phase') or status)
        export_ready = bool(row.get('export_ready')) or (status in ('completed','export_ready') and bool(row.get('download_url')))
        if expected and tests >= expected and snaps >= expected:
            pct = 100.0
            if status not in ('completed','error'):
                status = 'completed'; phase = 'export_ready'; export_ready = True
        return _clean_for_json({
            'ok': status != 'error', 'job_id': row.get('job_id'), 'batch_id': batch_id,
            'status': status, 'phase': phase, 'progress_pct': pct,
            'count': int(row.get('count') or 0), 'expected_tests': expected,
            'tests_written': tests, 'snapshots_written': snaps, 'signals_written': signals,
            'export_ready': export_ready, 'download_url': row.get('download_url'), 'error': row.get('error'),
            'started_at': row.get('started_at'), 'updated_at': row.get('updated_at'), 'completed_at': row.get('completed_at'),
            'cumulative': {'tests': tests, 'feature_snapshots': snaps, 'signal_scores': signals},
            'source': 'time_machine_jobs',
        })
    try:
        st = _sync_state_map().get('time_machine_current_job') or {}
        parsed = _parse_sync_progress_value(st.get('value')) if isinstance(st, dict) else {}
        if parsed:
            return _clean_for_json({'ok': parsed.get('ok') != 'False', 'status': 'complete' if 'complete' in str(st.get('value')) else 'running', 'phase': parsed.get('phase') or 'sync_state', 'progress_pct': int(parsed.get('pct') or 0), 'job_id': parsed.get('job'), 'batch_id': parsed.get('batch_id'), 'count': int(parsed.get('count') or 0), 'expected_tests': int(parsed.get('count') or 0)*7, 'current_job': st, 'source':'sync_state_fallback'})
    except Exception:
        pass
    return None

@router.post("/time-machine/random-tests/background")
async def time_machine_random_tests_background(payload: dict):
    """Start Random100/1000 with persistent job truth.

    V10.16.35 fixes the 72% hang: the API creates a time_machine_jobs row before
    the native core starts and every poll can read that row from DuckDB, even if
    Safari drops the original request or the process-local memory is empty.
    """
    count = max(1, min(int((payload or {}).get("count", 100)), 1000))
    job_id = str(uuid.uuid4())
    expected = count * 7
    now_fn = __import__("app.core.time_utils", fromlist=["utc_now"]).utc_now
    _tm_job_upsert(job_id, status='queued', phase='queued', count=count, expected_tests=expected, progress_pct=1, tests_written=0, snapshots_written=0, signals_written=0, export_ready=False)
    SessionLogService().append('tm_random_queued', {'job_id': job_id, 'count': count, 'expected_tests': expected})
    db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["time_machine_current_job", f"running job={job_id} count={count} pct=1 phase=queued", now_fn()])

    async def _runner():
        try:
            import time as _time
            _tm_started_ms = int(_time.time()*1000)
            _tm_job_upsert(job_id, status='running', phase='native_core', progress_pct=8)
            SessionLogService().append('tm_random_native_start', {'job_id': job_id, 'count': count})
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["time_machine_current_job", f"running job={job_id} count={count} pct=8 phase=native_core", now_fn()])
            result = await asyncio.to_thread(TimeMachineService().random_tests, count)
            _tm_elapsed_ms = int(_time.time()*1000) - _tm_started_ms
            batch_id = result.get("batch_id") if isinstance(result, dict) else None
            ok = bool(result.get("ok")) if isinstance(result, dict) else False
            tests = _tm_count_for_batch('time_machine_tests', batch_id)
            snaps = _tm_count_for_batch('time_machine_feature_snapshots', batch_id)
            signals = _tm_count_for_batch('time_machine_signal_scores', None)
            download_url = result.get('download_url') or ((result.get('export') or {}).get('download_url') if isinstance(result, dict) else None)
            # V10.16.47: TimeMachineService.write_random_batch already rebuilds
            # adaptive learning during export. Running it again here made Random1000
            # feel much slower and sometimes kept the UI in a mid-progress phase.
            adaptive_result = {'status':'already_rebuilt_during_export', 'version':'v10.16.46'}
            if ok:
                phase = 'export_ready' if download_url else 'warehouse_written'
                _tm_job_upsert(job_id, batch_id=batch_id, status='completed', phase=phase, progress_pct=100, tests_written=tests, snapshots_written=snaps, signals_written=signals, export_ready=bool(download_url), download_url=download_url, completed_at=now_fn(), metadata={'result_mode': result.get('mode') if isinstance(result, dict) else None, 'adaptive_learning': adaptive_result, 'duration_ms': _tm_elapsed_ms})
                SessionLogService().append('tm_random_completed', {'job_id': job_id, 'batch_id': batch_id, 'count': count, 'tests_written': tests, 'snapshots_written': snaps, 'signals_written': signals, 'download_url': download_url, 'duration_ms': _tm_elapsed_ms})
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["time_machine_current_job", f"complete job={job_id} batch_id={batch_id or ''} count={count} pct=100 ok=True", now_fn()])
            else:
                reason = (result or {}).get('reason') if isinstance(result, dict) else 'unknown'
                _tm_job_upsert(job_id, batch_id=batch_id, status='error', phase='error', progress_pct=100, tests_written=tests, snapshots_written=snaps, signals_written=signals, error=str(reason)[:500], completed_at=now_fn())
                SessionLogService().append('tm_random_error', {'job_id': job_id, 'batch_id': batch_id, 'count': count, 'error': str(reason)[:500]})
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["time_machine_current_job", f"error job={job_id} count={count} pct=100 {str(reason)[:180]}", now_fn()])
            append_jsonl("time_machine_background_audit.jsonl", {"event":"tm_random_background_done_v101635", "job_id":job_id, "count":count, "batch_id":batch_id, "ok":ok, "tests":tests, "snapshots":snaps, "signals":signals, "download_url":download_url})
        except Exception as exc:
            tm_priority_event.clear()
            log.exception("Background Time Machine random failed: %s", exc)
            _tm_job_upsert(job_id, status='error', phase='exception', progress_pct=100, error=str(exc)[:500], completed_at=now_fn())
            SessionLogService().append('tm_random_exception', {'job_id': job_id, 'count': count, 'error': str(exc)[:500]})
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["time_machine_current_job", f"error job={job_id} count={count} pct=100 {str(exc)[:180]}", now_fn()])
    asyncio.create_task(_runner())
    return _clean_for_json({"ok": True, "queued": True, "status": "started", "job_id": job_id, "batch_id": job_id, "count": count, "expected_tests": expected, "message": f"Random{count} gestart op achtergrond. Voortgang loopt live mee."})

@router.post("/time-machine/random-tests")
def time_machine_random_tests(payload: dict):
    try:
        return _clean_for_json(TimeMachineService().random_tests(int(payload.get("count", 100))))
    except Exception as exc:
        tm_priority_event.clear()
        log.exception("Time Machine random tests failed: %s", exc)
        return _clean_for_json({"ok": False, "reason": str(exc), "summary": {}, "native_status": NativeCoreService().status()})

@router.get("/time-machine/random-status")
def time_machine_random_status(batch_id: str | None = None, job_id: str | None = None):
    key = job_id or batch_id
    persistent = _tm_persistent_status(key)
    local = TimeMachineService().random_batch_status(batch_id if batch_id and batch_id != job_id else None)
    if persistent:
        # Merge process-local details if available, but persistent DB state wins.
        if isinstance(local, dict) and local.get('status') not in (None, 'none', 'unknown'):
            persistent.setdefault('local_job', local)
        return _clean_for_json(persistent)
    return _clean_for_json(local)



@router.get("/time-machine/export/latest")
def time_machine_export_latest():
    return _clean_for_json(TimeMachineExportService().latest_info())

@router.get("/time-machine/export/list")
def time_machine_export_list(limit: int = 25):
    return _clean_for_json(TimeMachineExportService().list_exports(limit=limit))

@router.post("/time-machine/reset")
def time_machine_reset(payload: dict | None = None):
    payload = payload or {}
    delete_exports = bool(payload.get("delete_exports", False))
    try:
        tm_priority_event.clear()
    except Exception:
        pass
    return _clean_for_json(TimeMachineExportService().reset_warehouse(delete_exports=delete_exports, reset_learning=bool(payload.get("reset_learning", False))))

@router.get("/time-machine/export/download")
def time_machine_export_download(batch_id: str | None = None):
    SessionLogService().append('tm_export_download_requested', {'batch_id': batch_id})
    path = TimeMachineExportService().export_path(batch_id)
    if not path or not path.exists():
        return _clean_for_json({"ok": False, "reason": "Nog geen Time Machine random export gevonden. Draai eerst Random100 of Random1000."})
    return FileResponse(str(path), media_type="application/zip", filename=path.name)

@router.get("/time-machine/stats")
def time_machine_stats():
    return TimeMachineService().stats()


@router.get("/debug/snapshot")
def debug_snapshot():
    """Human-readable debug state for support/log exports."""
    try:
        candle_range = _safe_one("SELECT MIN(open_time), MAX(open_time), COUNT(*) FROM raw_candles WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h'")
        metric_counts = _safe_df("SELECT source, metric, COUNT(*) AS rows, MAX(timestamp_ms) AS last_ts FROM raw_metric_points GROUP BY source, metric ORDER BY source, metric")
        feature_range = _safe_one("SELECT MIN(timestamp_ms), MAX(timestamp_ms), COUNT(*) FROM features WHERE interval='1h'")
        latest_tm = _safe_df("SELECT horizon, COUNT(*) AS tests, SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS wins FROM time_machine_tests GROUP BY horizon ORDER BY horizon")
        return _clean_for_json({
            "engine_version": settings.engine_version,
            "db_path": str(settings.db_path),
            "candle_range": candle_range,
            "feature_range": feature_range,
            "metric_counts": metric_counts,
            "time_machine_scoreboard": latest_tm,
            "time_machine_learning_snapshots": _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots"),
            "time_machine_learning_signals": _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores"),
            "data_health": HealthService().list(),
            "sync_state": _safe_df("SELECT key, value, updated_at FROM sync_state"),
        })
    except Exception as exc:
        log.exception("Debug snapshot failed: %s", exc)
        return {"error": str(exc)}


def _df_to_csv_bytes(sql: str, params=None) -> bytes:
    """Export a DuckDB query to CSV bytes without crashing if table/column is absent."""
    try:
        df = db.df(sql, params or [])
        return df.to_csv(index=False).encode('utf-8')
    except Exception as exc:
        return ("error\n" + str(exc).replace('\n', ' ') + "\n").encode('utf-8')


def _write_json_to_zip(zf: zipfile.ZipFile, name: str, payload):
    zf.writestr(name, json.dumps(_clean_for_json(payload), ensure_ascii=False, indent=2, default=str).encode('utf-8'))


def _safe_table_exists(table: str) -> bool:
    try:
        r = db.fetchone("SELECT COUNT(*) FROM information_schema.tables WHERE table_name=?", [table])
        return bool(r and int(r[0] or 0) > 0)
    except Exception:
        try:
            db.fetchone(f"SELECT 1 FROM {table} LIMIT 1")
            return True
        except Exception:
            return False


def _debug_export_zip_path() -> Path:
    """Create one full diagnostic ZIP for Stijn to send back instead of screenshots.

    This is intentionally DB-only + log-tail only. It does not call external APIs,
    does not run forecast/backfill, and does not delete or mutate the warehouse.
    """
    ts = time.strftime('%Y%m%d_%H%M%S')
    out_dir = settings.data_dir / 'debug_exports'
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f'bee_debug_export_{settings.engine_version}_{ts}.zip'

    live_progress = None
    evidence_status = None
    try:
        live_progress = _mobile_background_progress_payload()
    except Exception as exc:
        live_progress = {"ok": False, "error": str(exc)}
    try:
        evidence_status = {"external_data": _external_data_status_payload(), "model_status": _model_status_payload()}
    except Exception as exc:
        evidence_status = {"ok": False, "error": str(exc)}

    snapshot = {
        "created_at": ts,
        "engine_version": settings.engine_version,
        "data_dir": str(settings.data_dir),
        "db_path": str(settings.db_path),
        "symbol": settings.symbol,
        "sync_busy": bool(sync_lock.locked()),
        "history": _authoritative_history_payload(),
        "native_core": NativeCoreService().status(),
        "live_progress": live_progress,
        "evidence_status": evidence_status,
    }

    with zipfile.ZipFile(out_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        _write_json_to_zip(zf, '00_README.json', {
            "purpose": "Debug export voor Bitcoin Evidence Engine: stuur deze ZIP terug in de chat i.p.v. screenshots.",
            "contains": [
                "mobile_live_progress_snapshot.json: exact wat Home/Data progress ziet",
                "mobile_evidence_status_snapshot.json: Data/Model cockpit bronpayload",
                "sync_state.csv, time_machine_jobs.csv en backfill_jobs.csv: waarheid achter progress",
                "metric_counts.csv: alle raw_metric_points per source/metric",
                "features_coverage.csv/latest_features.csv: echte feature-vulling",
                "recent samples per belangrijke metric",
                "adaptive_learning_status.json + adaptive_feature_weights/model_weights: echte learning output",
                "server_log_tail.txt indien beschikbaar",
            ],
            "important": "Deze export roept geen externe APIs aan en wijzigt geen data. Alleen lezen uit DuckDB + logs.",
            "version": settings.engine_version,
        })
        _write_json_to_zip(zf, 'mobile_live_progress_snapshot.json', live_progress)
        _write_json_to_zip(zf, 'mobile_evidence_status_snapshot.json', evidence_status)
        _write_json_to_zip(zf, 'debug_snapshot_summary.json', snapshot)

        # Core tables and status.
        zf.writestr('sync_state.csv', _df_to_csv_bytes("SELECT * FROM sync_state ORDER BY updated_at DESC"))
        zf.writestr('backfill_jobs.csv', _df_to_csv_bytes("SELECT * FROM backfill_jobs ORDER BY updated_at DESC"))
        zf.writestr('time_machine_jobs.csv', _df_to_csv_bytes("SELECT * FROM time_machine_jobs ORDER BY updated_at DESC LIMIT 100"))
        zf.writestr('metric_counts.csv', _df_to_csv_bytes("""
            SELECT source, metric, COUNT(*) AS rows, MIN(timestamp_ms) AS min_ts, MAX(timestamp_ms) AS max_ts
            FROM raw_metric_points
            GROUP BY source, metric
            ORDER BY source, metric
        """))
        zf.writestr('candle_range.csv', _df_to_csv_bytes("""
            SELECT source, symbol, interval, COUNT(*) AS rows, MIN(open_time) AS min_open_time, MAX(open_time) AS max_open_time,
                   MIN(close) AS min_close, MAX(close) AS max_close
            FROM raw_candles
            GROUP BY source, symbol, interval
            ORDER BY source, symbol, interval
        """))
        zf.writestr('features_coverage.csv', _df_to_csv_bytes("""
            SELECT interval, COUNT(*) AS feature_rows,
              SUM(CASE WHEN funding_rate IS NOT NULL THEN 1 ELSE 0 END) AS funding_rate_rows,
              SUM(CASE WHEN open_interest_value IS NOT NULL THEN 1 ELSE 0 END) AS open_interest_rows,
              SUM(CASE WHEN long_short_ratio IS NOT NULL THEN 1 ELSE 0 END) AS long_short_rows,
              SUM(CASE WHEN taker_buy_sell_ratio IS NOT NULL THEN 1 ELSE 0 END) AS taker_rows,
              SUM(CASE WHEN orderbook_imbalance IS NOT NULL THEN 1 ELSE 0 END) AS orderbook_rows,
              SUM(CASE WHEN fear_greed IS NOT NULL THEN 1 ELSE 0 END) AS fear_greed_rows,
              SUM(CASE WHEN spot_premium_coinbase_pct IS NOT NULL THEN 1 ELSE 0 END) AS coinbase_premium_rows,
              SUM(CASE WHEN spot_premium_kraken_pct IS NOT NULL THEN 1 ELSE 0 END) AS kraken_premium_rows,
              SUM(CASE WHEN coinmetrics_mvrv IS NOT NULL THEN 1 ELSE 0 END) AS mvrv_rows,
              MIN(timestamp_ms) AS min_ts, MAX(timestamp_ms) AS max_ts
            FROM features
            GROUP BY interval
            ORDER BY interval
        """))
        zf.writestr('latest_features_250.csv', _df_to_csv_bytes("SELECT * FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 250"))
        zf.writestr('forecast_runs_recent.csv', _df_to_csv_bytes("SELECT * FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 50"))
        zf.writestr('forecast_items_recent.csv', _df_to_csv_bytes("SELECT * FROM forecast_items ORDER BY run_id DESC, due_at_ms ASC LIMIT 500"))
        zf.writestr('model_scores.csv', _df_to_csv_bytes("SELECT * FROM model_scores ORDER BY total DESC, hitrate DESC LIMIT 500"))
        try:
            _write_json_to_zip(zf, 'adaptive_learning_status.json', AdaptiveLearningService().status())
        except Exception as exc:
            _write_json_to_zip(zf, 'adaptive_learning_status_error.json', {'error': str(exc)})
        zf.writestr('adaptive_feature_weights.csv', _df_to_csv_bytes("SELECT * FROM adaptive_feature_weights ORDER BY sample DESC, quality DESC"))
        zf.writestr('adaptive_model_weights.csv', _df_to_csv_bytes("SELECT * FROM adaptive_model_weights ORDER BY horizon, quality DESC, sample DESC"))
        zf.writestr('adaptive_regime_weights.csv', _df_to_csv_bytes("SELECT * FROM adaptive_regime_weights ORDER BY horizon, quality DESC, sample DESC"))
        zf.writestr('adaptive_feature_pair_weights.csv', _df_to_csv_bytes("SELECT * FROM adaptive_feature_pair_weights ORDER BY quality DESC, edge DESC, sample DESC"))
        zf.writestr('adaptive_learning_runs.csv', _df_to_csv_bytes("SELECT * FROM adaptive_learning_runs ORDER BY created_at DESC LIMIT 50"))
        zf.writestr('time_machine_batches.csv', _df_to_csv_bytes("SELECT * FROM time_machine_batches ORDER BY created_at DESC LIMIT 50"))
        zf.writestr('time_machine_tests_recent.csv', _df_to_csv_bytes("SELECT * FROM time_machine_tests ORDER BY created_at DESC LIMIT 1000"))
        zf.writestr('time_machine_scoreboard.csv', _df_to_csv_bytes("""
            SELECT horizon, COUNT(*) AS tests,
                   SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS wins,
                   SUM(CASE WHEN partial_reached THEN 1 ELSE 0 END) AS partials,
                   SUM(CASE WHEN invalidated THEN 1 ELSE 0 END) AS invalidated,
                   AVG(CASE WHEN direction_correct THEN 1.0 ELSE 0.0 END) AS direction_accuracy,
                   AVG(total_score) AS avg_score
            FROM time_machine_tests
            GROUP BY horizon
            ORDER BY horizon
        """))
        zf.writestr('time_machine_signal_scores.csv', _df_to_csv_bytes("SELECT * FROM time_machine_signal_scores ORDER BY last_seen_at DESC LIMIT 2000"))
        zf.writestr('time_machine_feature_snapshots_recent.csv', _df_to_csv_bytes("SELECT * FROM time_machine_feature_snapshots ORDER BY created_at DESC LIMIT 1000"))

        # Recent raw samples for the exact problematic datasets.
        sample_defs = [
            ('binance_futures','funding_rate'), ('binance_futures','open_interest_value'),
            ('binance_futures','open_interest_contracts'), ('binance_futures','long_short_ratio'),
            ('binance_futures','top_account_long_short_ratio'), ('binance_futures','top_position_long_short_ratio'),
            ('binance_futures','taker_buy_sell_ratio'), ('binance_futures','taker_delta_ratio'),
            ('spot_composite','spot_premium_coinbase_pct'), ('spot_composite','spot_premium_kraken_pct'),
            ('composite_orderbook','orderbook_imbalance'), ('alternative_me','fear_greed'),
            ('coinmetrics_community','CapMVRVCur'),
        ]
        for source, metric in sample_defs:
            safe_name = f"samples/{source}__{metric}.csv".replace('/', '_')
            zf.writestr(safe_name, _df_to_csv_bytes("""
                SELECT * FROM raw_metric_points
                WHERE source=? AND metric=?
                ORDER BY timestamp_ms DESC
                LIMIT 300
            """, [source, metric]))

        # Schema inventory, useful if migration did not run correctly.
        zf.writestr('schema_tables.csv', _df_to_csv_bytes("SELECT table_name FROM information_schema.tables WHERE table_schema='main' ORDER BY table_name"))
        table_rows = []
        try:
            tables = db.df("SELECT table_name FROM information_schema.tables WHERE table_schema='main' ORDER BY table_name").to_dict('records')
            for t in tables:
                name = str(t.get('table_name'))
                try:
                    cnt = db.fetchone(f"SELECT COUNT(*) FROM {name}")
                    table_rows.append({"table": name, "rows": int(cnt[0] or 0) if cnt else 0})
                    zf.writestr(f'schema/{name}_columns.csv', _df_to_csv_bytes(f"PRAGMA table_info('{name}')"))
                except Exception as exc:
                    table_rows.append({"table": name, "error": str(exc)})
        except Exception as exc:
            table_rows.append({"error": str(exc)})
        _write_json_to_zip(zf, 'table_row_counts.json', table_rows)

        # Full frontend/backend session timing log for Random1000/performance audits.
        try:
            zf.writestr('session_export_log.txt', SessionLogService().text(tail_lines=None).encode('utf-8'))
        except Exception as exc:
            zf.writestr('session_export_log_error.txt', str(exc).encode('utf-8'))

        # Log tails. Works on VPS if logs/server.log exists in deploy dir.
        for rel in ('logs/server.log', 'logs/update.log'):
            try:
                lp = settings.base_dir / rel
                if lp.exists():
                    data = lp.read_text(encoding='utf-8', errors='replace').splitlines()[-1500:]
                    zf.writestr(rel.replace('/', '_') + '_tail.txt', '\n'.join(data).encode('utf-8'))
            except Exception as exc:
                zf.writestr(rel.replace('/', '_') + '_error.txt', str(exc).encode('utf-8'))
    return out_path


@router.get("/debug/export/download")
def debug_export_download():
    try:
        path = _debug_export_zip_path()
        return FileResponse(str(path), media_type="application/zip", filename=path.name)
    except Exception as exc:
        log.exception("Debug export ZIP failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})


@router.post("/debug/export/create")
def debug_export_create():
    try:
        path = _debug_export_zip_path()
        return _clean_for_json({"ok": True, "path": str(path), "download_url": "/api/debug/export/download", "filename": path.name})
    except Exception as exc:
        log.exception("Debug export ZIP failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})


@router.post("/debug/frontend-event")
def frontend_event(payload: dict):
    """Small frontend diagnostics endpoint used by the Time Machine chart.
    It makes click/drag/pointer problems visible in exported logs without
    disturbing the UI if logging fails.
    """
    try:
        from app.core.debug import append_jsonl
        append_jsonl("frontend_audit.jsonl", {"event": "frontend", **(payload or {})})
        return {"ok": True}
    except Exception as exc:
        log.warning("Frontend debug event failed: %s", exc)
        return {"ok": False, "reason": str(exc)}


@router.get("/evidence-attribution")
def evidence_attribution(min_total: int = 3):
    try:
        return _clean_for_json(EvidenceAttributionService().leaderboard(min_total=min_total))
    except Exception as exc:
        log.exception("Evidence attribution endpoint failed: %s", exc)
        return _clean_for_json({"top": [], "by_horizon": [], "weak": [], "error": str(exc)})



@router.post("/evidence/backfill")
async def evidence_backfill(passes: int = 8):
    """Start/fill external evidence layers without deleting candles or TM tests.

    V10.16.19: this is the manual button/API for deeper market context:
    futures funding/OI/long-short/taker/top-trader, Fear & Greed history,
    CoinMetrics community metrics, orderbook/flow and cross-exchange premium.
    """
    try:
        if sync_lock.locked():
            return _clean_for_json({"ok": False, "status": "busy", "reason": "sync already running"})
        async with sync_lock:
            result = await SyncService().sync_external_evidence_deep_fill(passes=max(1, min(int(passes), 48)))
            return _clean_for_json({"ok": result.get("status") == "ok", **result})
    except Exception as exc:
        log.exception("External evidence backfill failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.get("/evidence/data-sources")
def evidence_data_sources():
    """Show exactly which data layers are actually present.

    This is intentionally DB-based, not marketing text: if a field has 0 rows or
    0 non-null feature values, it is not treated as active evidence.
    """
    metric_counts = _safe_df("""
        SELECT source, metric, COUNT(*) AS rows, MIN(timestamp_ms) AS min_ts, MAX(timestamp_ms) AS max_ts
        FROM raw_metric_points
        GROUP BY source, metric
        ORDER BY source, metric
    """)
    feature_cols = [
        'fear_greed','funding_rate','open_interest_value','open_interest_change_24h',
        'long_short_ratio','taker_buy_sell_ratio','orderbook_imbalance','taker_delta_ratio',
        'futures_basis_premium_pct','top_position_long_short_ratio','top_account_long_short_ratio',
        'cross_exchange_spread_pct','spot_premium_kraken_pct','spot_premium_coinbase_pct',
        'coinmetrics_mvrv','realized_cap_usd','market_cap_usd'
    ]
    feature_coverage = {}
    total = _safe_one("SELECT COUNT(*) FROM features WHERE interval='1h'")
    total_n = int(total[0] or 0) if total else 0
    for col in feature_cols:
        row = _safe_one(f"SELECT COUNT(*) FROM features WHERE interval='1h' AND \"{col}\" IS NOT NULL")
        n = int(row[0] or 0) if row else 0
        feature_coverage[col] = {"non_null_rows": n, "feature_rows": total_n, "coverage_pct": round((n/total_n*100),2) if total_n else 0}
    model_scores = _safe_df("SELECT * FROM model_scores ORDER BY horizon, total DESC")
    active_layers = {k:v for k,v in feature_coverage.items() if v.get("non_null_rows",0) > 0}
    missing_layers = {k:v for k,v in feature_coverage.items() if v.get("non_null_rows",0) == 0}
    progress = _safe_df("""
        SELECT key, value, updated_at
        FROM sync_state
        WHERE key LIKE 'external_progress_%' OR key IN ('external_evidence_backfill','external_evidence_daemon','coinmetrics_status')
        ORDER BY updated_at DESC
        LIMIT 80
    """)
    return _clean_for_json({
        "ok": True,
        "engine_version": settings.engine_version,
        "source_of_truth": "raw_metric_points + non-null feature coverage",
        "currently_core_data": "Binance BTCUSDT 1h OHLCV in raw_candles",
        "external_backfill_endpoint": "/api/evidence/backfill?passes=8",
        "metric_counts": metric_counts,
        "feature_coverage": feature_coverage,
        "active_external_layers": active_layers,
        "missing_external_layers": missing_layers,
        "external_progress": progress,
        "model_scores": model_scores,
        "important_note": "Missing external fields are exported as missing and receive zero model weight; they do not fake confidence.",
    })

@router.get("/evidence/model-status")
def evidence_model_status():
    return _clean_for_json({"ok": True, "model_status": _model_status_payload()})

@router.get("/time-machine/learning")
def time_machine_learning(min_total: int = 5):
    try:
        return _clean_for_json(TimeMachineLearningService().leaderboard(min_total=min_total))
    except Exception as exc:
        log.exception("Time Machine learning endpoint failed: %s", exc)
        return _clean_for_json({"top": [], "by_horizon": [], "weak": [], "coverage": [], "error": str(exc)})


@router.get("/adaptive-learning/status")
def adaptive_learning_status():
    try:
        return _clean_for_json(AdaptiveLearningService().status())
    except Exception as exc:
        log.exception("Adaptive learning status failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})


@router.post("/adaptive-learning/rebuild")
def adaptive_learning_rebuild():
    try:
        return _clean_for_json(AdaptiveLearningService().rebuild(min_total=20))
    except Exception as exc:
        log.exception("Adaptive learning rebuild failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})


@router.get("/historical-memory/status")
def historical_memory_status():
    try:
        # V10.15.3: this endpoint must be extremely light. Do NOT rebuild/write
        # adaptive weights on every UI poll; that can block behind DuckDB while
        # history is inserting chunks and caused 6000ms frontend timeouts.
        svc = HistoricalMemoryService()
        weights = {}
        try:
            from app.core.config import settings as _settings
            import json as _json
            p = _settings.base_dir / "logs" / "adaptive_feature_weights.json"
            if p.exists():
                weights = _json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            weights = {}
        return _clean_for_json({"ok": True, "history": _authoritative_history_payload(), "service_status": svc.history_status(), "adaptive_weights": weights})
    except Exception as exc:
        log.exception("Historical memory status failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/historical-memory/backfill")
async def historical_memory_backfill(mode: str = "daemon"):
    try:
        svc = HistoricalMemoryService()
        if str(mode).lower() in ("pass", "single", "once"):
            return _clean_for_json(await svc.ensure_eight_year_history_background())
        # V10.15.1: manual button may never block until 70k is complete.
        # It only checks/restarts the same auto-completion daemon and returns immediately.
        asyncio.create_task(svc.ensure_eight_year_history_daemon())
        return _clean_for_json({"ok": True, "queued": True, "message": "Historical Memory auto-completion daemon is running/queued", "status": svc.history_status()})
    except Exception as exc:
        log.exception("Historical memory backfill failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/historical-memory/daemon")
async def historical_memory_daemon():
    try:
        svc = HistoricalMemoryService()
        asyncio.create_task(svc.ensure_eight_year_history_daemon())
        return _clean_for_json({"ok": True, "queued": True, "message": "Historical Memory auto-completion daemon is running/queued", "status": svc.history_status()})
    except Exception as exc:
        log.exception("Historical memory daemon failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/adaptive-weights/rebuild")
def adaptive_weights_rebuild():
    try:
        return _clean_for_json(HistoricalMemoryService().adaptive_weights())
    except Exception as exc:
        log.exception("Adaptive weights rebuild failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.get("/logs/tail")
def logs_tail(lines: int = 300):
    path = settings.base_dir / "logs" / "bee_runtime.log"
    if not path.exists():
        return {"path": str(path), "lines": []}
    data = path.read_text(encoding="utf-8", errors="replace").splitlines()
    return {"path": str(path), "lines": data[-max(1, min(lines, 2000)):]}


@router.get("/seed-export/status")
def seed_export_status():
    try:
        svc = SeedExportService()
        return _clean_for_json({"ok": True, "latest_export": svc.latest_export_info(), "manifest_preview": svc.manifest()})
    except Exception as exc:
        log.exception("Seed export status failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/seed-export/create")
def seed_export_create():
    try:
        return _clean_for_json(SeedExportService().export_seed_zip())
    except Exception as exc:
        log.exception("Seed export create failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.get("/seed-export/download")
def seed_export_download():
    svc = SeedExportService()
    info = svc.latest_export_info()
    path = Path(info.get("path", ""))
    if not path.exists():
        result = svc.export_seed_zip()
        path = Path(result["path"])
    return FileResponse(str(path), media_type="application/zip", filename=path.name)

@router.get("/mobile/summary")
def mobile_summary():
    """iPhone-first lightweight payload.

    Designed for cloud/PWA use: never runs heavy forecast rebuilds and avoids
    wide archive queries so mobile Safari stays responsive while the backend is
    loading history or learning data.
    """
    try:
        # V10.16.20: do NOT call dashboard_status() here. That route can be
        # slow while external evidence is filling. Mobile summary must remain
        # stable and should only use cheap DB queries.
        hist = _authoritative_history_payload()
        native = NativeCoreService().status()
        ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
        latest_candle = _safe_one("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
        price = ticker_price or latest_candle
        sync_state = _safe_df("SELECT key, value, updated_at FROM sync_state")
        dash = {"api_status": "busy" if sync_lock.locked() else "ok", "sync_busy": bool(sync_lock.locked()), "btc_price": float(price[0]) if price and price[0] is not None else None, "latest_feature": None, "sync_state": sync_state}
        latest_items = _normalise_latest_forecast_rows(_safe_df("""
            SELECT horizon, bullish_probability, bearish_probability, expected_move_pct,
                   expected_price, invalidation_price, confidence, status, due_at_ms, contributions_json
            FROM forecast_items
            WHERE run_id=(SELECT run_id FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1)
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """))
        accuracy = _safe_df("""
            SELECT horizon, COUNT(*) AS total,
                   SUM(CASE WHEN direction_correct THEN 1 ELSE 0 END) AS correct,
                   AVG(CASE WHEN direction_correct THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(total_score) AS avg_score
            FROM time_machine_tests
            GROUP BY horizon
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """)
        tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id), MAX(created_at) FROM time_machine_tests")
        feature_snapshots = _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots")
        signals = _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores")
        candle_range = _real_candle_range()
        return _clean_for_json({
            "ok": True,
            "engine_version": settings.engine_version,
            "api_status": dash.get("api_status") if isinstance(dash, dict) else "ok",
            "sync_busy": bool(dash.get("sync_busy")) if isinstance(dash, dict) else False,
            "btc_price": dash.get("btc_price") if isinstance(dash, dict) else None,
            "latest_feature": dash.get("latest_feature") if isinstance(dash, dict) else None,
            "sync_state": dash.get("sync_state") if isinstance(dash, dict) else [],
            "history": hist,
            "native": native,
            "latest_items": latest_items,
            "accuracy": accuracy,
            "learning": {
                "time_machine_tests": int(tm_counts[0] or 0) if tm_counts else 0,
                "time_machine_batches": int(tm_counts[1] or 0) if tm_counts else 0,
                "latest_test_at": tm_counts[2] if tm_counts else None,
                "feature_snapshots": int(feature_snapshots[0] or 0) if feature_snapshots else 0,
                "latest_feature_snapshot_at": feature_snapshots[1] if feature_snapshots else None,
                "signal_events": int(signals[0] or 0) if signals else 0,
                "latest_signal_at": signals[1] if signals else None,
            },
            "candle_range": {
                "from_ms": candle_range[0] if candle_range else None,
                "to_ms": candle_range[1] if candle_range else None,
                "rows": int(candle_range[2] or 0) if candle_range else 0,
            },
            "external_data": _external_data_status_payload(),
        })
    except Exception as exc:
        log.exception("Mobile summary failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc), "engine_version": settings.engine_version})


@router.get("/time-machine/visual-summary")
def time_machine_visual_summary(batch_id: str | None = None):
    """V10.16.39 mobile visual Time Machine dashboard.

    Gives Stijn direct insight in the last Random1000/Random100 result without
    opening CSV exports: per-horizon win/partial/fail, best regimes, top evidence
    signals, learned feature/model/regime weights and export readiness.
    """
    try:
        if not batch_id:
            row = _safe_one("SELECT batch_id FROM time_machine_tests WHERE batch_id IS NOT NULL GROUP BY batch_id ORDER BY MAX(created_at) DESC LIMIT 1")
            batch_id = row[0] if row else None
        params = [batch_id] if batch_id else []
        where = "WHERE batch_id=?" if batch_id else ""
        horizon_rows = _safe_df(f"""
            SELECT horizon,
                   COUNT(*) AS total,
                   SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS wins,
                   SUM(CASE WHEN (NOT target_reached) AND total_score >= 55 THEN 1 ELSE 0 END) AS partials,
                   SUM(CASE WHEN target_reached OR total_score >= 55 THEN 0 ELSE 1 END) AS fails,
                   AVG(CASE WHEN target_reached THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(CASE WHEN target_reached OR total_score >= 55 THEN 1.0 ELSE 0.0 END) AS hitrate_with_partial,
                   AVG(total_score) AS avg_score,
                   AVG(ABS(COALESCE(price_error_pct, target_gap_pct, 0))) AS avg_error,
                   AVG(COALESCE(expected_move_pct, 0)) AS avg_expected_move,
                   AVG(COALESCE(actual_move_pct, 0)) AS avg_actual_move
            FROM time_machine_tests
            {where}
            GROUP BY horizon
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """, params)
        total = sum(int(r.get('total') or 0) for r in horizon_rows)
        wins = sum(int(r.get('wins') or 0) for r in horizon_rows)
        partials = sum(int(r.get('partials') or 0) for r in horizon_rows)
        fails = sum(int(r.get('fails') or 0) for r in horizon_rows)
        regime_rows = _safe_df(f"""
            SELECT COALESCE(regime, 'unknown') AS regime, horizon,
                   COUNT(*) AS sample,
                   AVG(CASE WHEN target_reached THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(CASE WHEN target_reached OR partial_reached OR total_score >= 55 THEN 1.0 ELSE 0.0 END) AS hitrate_with_partial,
                   AVG(total_score) AS avg_score
            FROM time_machine_feature_snapshots
            {where}
            GROUP BY regime, horizon
            HAVING COUNT(*) >= 5
            ORDER BY hitrate_with_partial DESC, sample DESC
            LIMIT 40
        """, params)
        top_signals = _safe_df("""
            SELECT signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
                   hitrate, hitrate_with_partial, avg_score
            FROM time_machine_signal_scores
            WHERE total >= 20 AND signal_key NOT LIKE '%:unknown%'
            ORDER BY hitrate_with_partial DESC, total DESC, avg_score DESC
            LIMIT 30
        """)
        weak_signals = _safe_df("""
            SELECT signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
                   hitrate, hitrate_with_partial, avg_score
            FROM time_machine_signal_scores
            WHERE total >= 20 AND signal_key NOT LIKE '%:unknown%'
            ORDER BY hitrate_with_partial ASC, total DESC
            LIMIT 20
        """)
        feature_weights = _safe_df("SELECT * FROM adaptive_feature_weights ORDER BY sample DESC, quality DESC LIMIT 40")
        model_weights = _safe_df("SELECT * FROM adaptive_model_weights ORDER BY horizon, quality DESC, sample DESC LIMIT 60")
        regime_weights = _safe_df("SELECT * FROM adaptive_regime_weights ORDER BY horizon, quality DESC, sample DESC LIMIT 60")
        pair_weights = _safe_df("SELECT * FROM adaptive_feature_pair_weights ORDER BY quality DESC, edge DESC, sample DESC LIMIT 80")
        export_info = TimeMachineExportService().latest_info()
        return _clean_for_json({
            "ok": True,
            "engine_version": settings.engine_version,
            "batch_id": batch_id,
            "summary": {
                "total": total,
                "wins": wins,
                "partials": partials,
                "fails": fails,
                "hitrate": (wins / total) if total else None,
                "hitrate_with_partial": ((wins + partials) / total) if total else None,
            },
            "horizons": horizon_rows,
            "regimes": regime_rows,
            "top_signals": top_signals,
            "weak_signals": weak_signals,
            "feature_weights": feature_weights,
            "model_weights": model_weights,
            "regime_weights": regime_weights,
            "pair_weights": pair_weights,
            "export": export_info,
        })
    except Exception as exc:
        log.exception("Time Machine visual summary failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc), "engine_version": settings.engine_version})


@router.get("/historical-twins/latest")
def historical_twins_latest(horizon: str = "24h", top_n: int = 12):
    """V10.16.47: visible historical twins for the mobile app.

    This is the human-facing version of the Time Machine evidence: show the best
    historical matches for the current market state, including what happened
    after those moments. It does not make up new predictions; it exposes the
    same similarity layer used by the forecast engine.
    """
    try:
        if horizon not in ("1h", "4h", "8h", "24h", "7d", "30d", "90d"):
            horizon = "24h"
        top_n = max(3, min(int(top_n), 30))
        res = HistoricalTwinFinder().find(horizon=horizon, top_n=max(80, top_n * 8))
        matches = (res.get("matches") or [])[:top_n]
        out = []
        for m in matches:
            ts = int(m.get("timestamp_ms") or 0)
            out.append({
                "timestamp_ms": ts,
                "date": __import__("datetime").datetime.datetime.utcfromtimestamp(ts/1000).strftime("%Y-%m-%d %H:%M UTC") if ts else None,
                "close": m.get("close"),
                "future_move_pct": m.get("future_move_pct"),
                "distance": m.get("distance"),
                "similarity_pct": max(0.0, min(100.0, 100.0 - float(m.get("distance") or 0.0) * 8.5)),
            })
        return _clean_for_json({
            "ok": True,
            "engine_version": settings.engine_version,
            "horizon": horizon,
            "evidence_count": int(res.get("evidence_count") or 0),
            "bullish_probability": res.get("bullish_probability"),
            "expected_move_pct": res.get("expected_move_pct"),
            "avg_move_pct": res.get("avg_move_pct"),
            "worst_move_pct": res.get("worst_move_pct"),
            "best_move_pct": res.get("best_move_pct"),
            "matches": out,
            "note": "Historical twins are nearest past market states from the feature warehouse; future_move_pct is what BTC actually did after that historical moment.",
        })
    except Exception as exc:
        log.exception("Historical twins endpoint failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc), "engine_version": settings.engine_version})

@router.post("/forecast/ensure")
async def forecast_ensure():
    """Create a fresh visible forecast if the Forecast tab is empty/stale.

    This is intentionally background-friendly: the mobile UI can call it once
    after boot so Forecast never stays blank forever.
    """
    try:
        latest = _safe_one("SELECT COUNT(*), MAX(created_at_ms) FROM forecast_items")
        now_ms = int(time.time() * 1000)
        has_recent = bool(latest and int(latest[0] or 0) >= 7 and latest[1] and now_ms - int(latest[1]) < 15 * 60 * 1000)
        if has_recent:
            return _clean_for_json({"ok": True, "created": False, "reason": "recent_forecast_exists"})
        if sync_lock.locked():
            return _clean_for_json({"ok": True, "created": False, "queued": False, "reason": "sync_busy"})
        async def _runner():
            try:
                async with sync_lock:
                    db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["auto_forecast", "running visual forecast ensure", __import__("app.core.time_utils", fromlist=["utc_now"]).utc_now()])
                    res = await DataFoundationService().run_forecast_pipeline(source="auto_visual_forecast")
                    db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["auto_forecast", f"complete created={res.get('created')} run={res.get('run_id')}", __import__("app.core.time_utils", fromlist=["utc_now"]).utc_now()])
            except Exception as exc:
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["auto_forecast", "error: "+str(exc)[:250], __import__("app.core.time_utils", fromlist=["utc_now"]).utc_now()])
                log.exception("Auto forecast ensure failed: %s", exc)
        asyncio.create_task(_runner())
        return _clean_for_json({"ok": True, "created": False, "queued": True, "reason": "forecast_build_started"})
    except Exception as exc:
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.get("/mobile/chart")
def mobile_chart(limit: int = 360):
    return TimeMachineService().chart_points(timeframe="1h", limit=max(50, min(int(limit), 1000)))
