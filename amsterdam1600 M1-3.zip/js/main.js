// M0 entrypoint. Bewust lichtgewicht op page load (Safari-regel):
// wereldgeneratie + sprites zijn milliseconden-werk, de zwaardere
// overzichtskaart wordt pas ná de eerste frame gebouwd.
import { GRID, START_ZOOM, TYPE_NAMES, OBJ, OBJ_NAMES } from './config.js';
import { generateWorld, tileAt } from './world.js';
import { buildSprites, buildObjectSprites } from './tiles.js';
import { Camera } from './camera.js';
import { Renderer } from './renderer.js';
import { attachInput } from './input.js';

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d', { alpha: false });

const fpsEl = document.getElementById('fps');
const zoomEl = document.getElementById('zoomlvl');
const tileEl = document.getElementById('hud-tile');

const { tiles: world, objects } = generateWorld();
const tileset = buildSprites();
const objectSprites = buildObjectSprites();
const camera = new Camera(window.innerWidth, window.innerHeight, START_ZOOM);
const renderer = new Renderer(ctx, world, objects, tileset, objectSprites);

let dpr = 1;
function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = window.innerWidth;
  const h = window.innerHeight;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.width = w + 'px';
  canvas.style.height = h + 'px';
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  camera.resize(w, h);
}
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 120));
resize();

attachInput(canvas, camera, {
  onChange: () => {},
  onTap: (px, py) => {
    const [tx, ty] = camera.tileAtScreen(px, py);
    const t = tileAt(world, tx, ty);
    if (t === -1) {
      renderer.selected = null;
      tileEl.classList.add('hidden');
      return;
    }
    renderer.selected = [tx, ty];
    const o = objects[ty * GRID + tx];
    const label = o !== OBJ.NONE ? `${OBJ_NAMES[o]} · ${TYPE_NAMES[t]}` : TYPE_NAMES[t];
    tileEl.innerHTML =
      `<span class="tile-coord">${tx}, ${ty}</span> &nbsp;·&nbsp; ${label}`;
    tileEl.classList.remove('hidden');
  },
});

// FPS-meter (bewijs voor de M0-eis: 256×256 @ 60 fps)
let frames = 0;
let lastFpsT = performance.now();

function loop(tMs) {
  renderer.draw(camera, tMs);

  frames++;
  const now = performance.now();
  if (now - lastFpsT >= 500) {
    const fps = Math.round((frames * 1000) / (now - lastFpsT));
    fpsEl.textContent = `${fps} fps · ${renderer.drawnTiles} tegels`;
    zoomEl.textContent = `zoom ${camera.zoom.toFixed(2)}`;
    frames = 0;
    lastFpsT = now;
  }
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

// Overzichtskaart pas ná de eerste zichtbare frame bouwen: de gebruiker
// ziet direct beeld, de eenmalige bouwkosten vallen buiten de startpad.
setTimeout(() => renderer.buildOverview(), 60);
