# Outrun IQ v8.5.8 — AI Listing Writer & SEO Engine

- Nieuwe AI Listing Writer toegevoegd aan de product-uploadflow.
- Na vision + pricing genereert Outrun nu automatisch originele Nederlandse productbeschrijvingen.
- Bekend merk/model: AI schrijft een eigen parafrase op basis van productkennis, conditie en marktdata; fabrikant/webshopteksten worden niet letterlijk gekopieerd.
- Onbekend product: AI schrijft veilig op basis van fotoanalyse, categorie, conditie, accessoires en prijscontext.
- Drie beschrijvingslengtes in de flow: kort, normaal en uitgebreid.
- Natuurlijke Google/SEO-zoekwoorden toegevoegd zonder keyword stuffing.
- Automatische SEO-title, meta description, keywords en alt-teksten voor productpagina’s.
- Productpagina toont nu een nette beschrijvingskaart voor buyers.
- Structured data gebruikt nu de AI SEO metadata waar beschikbaar.
- Server-safe: copy wordt alleen compact opgeslagen, geen externe HTML, geen ruwe webtekst, geen extra foto-opslag.
