# Outrun IQ v8.5.8

Flat safe deploy build voor `/var/www/outrun-iq-v5`.

Deze versie voegt de AI Listing Writer & SEO Engine toe. Bij nieuwe productuploads maakt Outrun automatisch een originele productbeschrijving, SEO metadata, zoekwoorden en alt-teksten. De AI kopieert geen fabrikantsteksten letterlijk maar schrijft nieuwe teksten op basis van vision, pricing, conditie, merk/model en marktcontext.

Deployment blijft gelijk aan eerdere FLAT-SAFE builds: `.env`, `data`, `runtime_uploads`, `public/uploads`, `node_modules` en `.next` moeten op de server behouden blijven.
