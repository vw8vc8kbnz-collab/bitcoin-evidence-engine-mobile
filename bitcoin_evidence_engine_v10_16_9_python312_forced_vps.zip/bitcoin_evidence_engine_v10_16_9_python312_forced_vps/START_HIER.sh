#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "=============================================="
echo "Bitcoin Evidence Engine v10.16.9"
echo "Eenvoudige VPS start/herstart"
echo "=============================================="

choose_python() {
  # Deze app gebruikt bewust Python 3.12/3.11, niet Python 3.14.
  # Python 3.14 is te nieuw voor sommige binary wheels zoals pydantic-core.
  for py in python3.12 python3.11 python3.10; do
    if command -v "$py" >/dev/null 2>&1; then
      echo "$py"
      return 0
    fi
  done
  echo ""
  return 1
}

ensure_python() {
  PY_BIN="$(choose_python || true)"
  if [ -z "${PY_BIN:-}" ]; then
    echo "Python 3.12/3.11 ontbreekt. Probeer Python 3.12 te installeren via apt..."
    sudo apt-get update
    sudo apt-get install -y python3.12 python3.12-venv python3.12-dev python3-pip || true
    PY_BIN="$(choose_python || true)"
  fi
  if [ -z "${PY_BIN:-}" ]; then
    echo "❌ Kan geen geschikte Python vinden. Nodig: python3.12 of python3.11."
    echo "Huidige python3 is: $(python3 --version 2>/dev/null || echo onbekend)"
    echo "Installeer op Ubuntu bij voorkeur: sudo apt-get install -y python3.12 python3.12-venv python3.12-dev"
    exit 1
  fi
  echo "Gekozen Python: $($PY_BIN --version) ($PY_BIN)"
}

ensure_python

pkill -f "uvicorn app.main:app" >/dev/null 2>&1 || true
sleep 1

if [ -d .venv ]; then
  VENV_VER="$(.venv/bin/python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null || echo unknown)"
  if [ "$VENV_VER" = "3.14" ] || [ "$VENV_VER" = "unknown" ]; then
    echo "Oude/verkeerde virtualenv verwijderen: Python $VENV_VER"
    rm -rf .venv
  fi
fi

if [ ! -d .venv ]; then
  echo "Virtualenv maken met $PY_BIN..."
  "$PY_BIN" -m venv .venv
fi

. .venv/bin/activate
python -m pip install --upgrade 'pip<26' wheel setuptools

echo "Python packages installeren vanuit requirements.txt..."
python -m pip install --only-binary=:all: -r requirements.txt

if [ -f build_native_core_linux.sh ]; then
  echo "Native core bouwen/controleren..."
  bash build_native_core_linux.sh || echo "Native build gaf waarschuwing; app start alsnog als binary al aanwezig is."
fi

mkdir -p "$HOME/bitcoin_evidence_data" logs

echo "Server starten op poort 8787..."
nohup .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8787 --proxy-headers > server.log 2>&1 &

sleep 3
if curl -fsS http://127.0.0.1:8787/api/health >/dev/null 2>&1; then
  echo ""
  echo "✅ ONLINE: http://51.195.102.180:8787"
  echo "Log: $(pwd)/server.log"
else
  echo ""
  echo "❌ Server startte niet goed. Laatste logregels:"
  tail -80 server.log || true
  exit 1
fi
