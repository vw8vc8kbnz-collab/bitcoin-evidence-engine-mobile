# Outrun IQ v9.1.0 — Secure Platform Core

Outrun IQ is een publieke, trust-first outletmarketplace met een afzonderlijke partner- en adminomgeving. De applicatie helpt professionele verkopers om retour-, showroom-, B-stock- en restvoorraad product-per-product te herkennen, controleren, publiceren en verkopen.

Versie 9.1.0 is een funderingsrelease. Deze release voegt bewust geen groot commercieel kunstje toe, maar sluit concrete privacy- en autorisatielekken, maakt media werkelijk privé, herstelt menselijke bevestiging als bron van waarheid, vergrendelt onvoltooide finance/promoteflows en vereenvoudigt de belangrijkste buyer- en partnerroutes.

## Belangrijkste garanties van v9.1.0

- Publieke listing- en sellerdata gebruiken expliciete allowlist-DTO's.
- Drafts, reviewlistings en uitverkochte listings zijn niet via een directe publieke ID opvraagbaar.
- De normale productpagina, intercepted modal, checkout, orders en Vinder gebruiken geen intern listingrecord.
- Interne uploads vereisen ownership; publieke en private media hebben afzonderlijk cache- en toegangsbeleid.
- Nieuwe uploads worden server-side gedecodeerd, geroteerd, begrensd, opnieuw als WebP gecodeerd en zonder EXIF opgeslagen.
- Admin-PIN en testloginroutes zijn verwijderd.
- Registratie- en resetcodes worden cryptografisch gegenereerd, gehasht opgeslagen en nooit gelogd.
- AI-confidence kan geen model, prijs, conditie of publicatie zelfstandig bevestigen.
- Ordercreatie is idempotent via een client-command-ID.
- Promote en echte betalingen zijn hard pilot-locked, ongeacht toevallige VPS-variabelen.
- Productviews, ordersweeps en campagnesweeps schrijven niet meer tijdens iedere paginalaad.
- Securityheaders, same-origincontrole en centrale rolguards zijn toegevoegd.
- De buyerhomepage is eenvoudiger, deterministisch en doet geen live generatieve AI-call.

## Productstatus

Deze release is een **beveiligde pilotbasis**, geen production-ready geldplatform.

Nog bewust niet afgerond:

- PostgreSQL en transactionele persistence;
- echte Stripe Connect-, payout-, refund- en reconciliationflows;
- volledig versioned Product Intelligence Record;
- Resolver 3.0 met catalogus en evidencegraph;
- volledige vervanging van de historische globale CSS;
- distributed rate limiting;
- live iPhone-, VPS- en provider-E2E in deze lokale releaseomgeving.

## Techniek

- Next.js 15.5.20
- React / React DOM 19.2.7
- TypeScript 5.7.3
- Sharp 0.34.3
- Next App Router
- JSON-persistence met fail-closed, copy-on-write en last-good backup als tijdelijke migratiebasis

## Lokale installatie

```bash
npm ci --no-audit --no-fund
cp .env.example .env
npm run dev
```

Productiestart:

```bash
npm run build
npm start
```

## Releasegate

```bash
npm run release:verify
```

Deze opdracht voert uit:

1. broncode- en versiecontracten;
2. koude volledige Next.js-productiebuild;
3. ESLint;
4. TypeScript;
5. unit-, security- en invarianttests;
6. production dependency-audit.

## Opslag

Standaard:

```text
DATA_DIR=<project>/data
DB_FILE=<DATA_DIR>/db.json
UPLOAD_DIR=<DATA_DIR>/uploads
```

De store maakt uitsluitend een lege database bij `ENOENT`. Een bestaand corrupt of onleesbaar bestand laat de applicatie hard falen; het wordt niet stil vervangen. Writes gebruiken een tijdelijke file, `fsync`, een last-good backup en een atomische rename.

Dit is nog geen vervanging voor PostgreSQL. Start PM2 met één applicatie-instance.

## Media

Nieuwe partneruploads:

- maximaal 5 bestanden per request;
- maximaal 8 MB per bestand;
- maximaal 30 MB totaal;
- maximaal 40 miljoen inputpixels;
- maximale outputmaat 2400 × 2400;
- JPEG, PNG, WebP en HEIC wanneer de gebruikte Sharp-build dit kan decoderen;
- uniforme WebP-output;
- private visibility als standaard;
- alleen expliciet gekozen listingfoto's worden publiek.

## Onderhoudsjob

Automatische ordertransities, campagnesweeps en gebufferde productviews lopen niet meer in paginarenders. Roep periodiek aan:

```bash
curl -fsS -X POST \
  -H "Authorization: Bearer $CRON_SECRET" \
  https://outruniq.nl/api/internal/maintenance
```

Configureer dit via een server-side scheduler of systemd timer. Zet `CRON_SECRET` niet in publieke clientcode.

## Finance en Promote

`COMMERCE_LIVE_READY` staat in de broncode hard op `false`. Daardoor blijven payment capture, payouts en campagnebudgetmutaties geblokkeerd, zelfs wanneer Stripe- of liveflags per ongeluk in `.env` staan.

De bestaande order-, reserve- en ledgerweergaven zijn pilotsimulaties. Buyer- en partnercopy benoemt dit expliciet.

## Environment

Gebruik `.env.example` als bron. Belangrijk:

```text
ADMIN_EMAIL=
RESEND_API_KEY=
MAIL_FROM=
CRON_SECRET=
PAYMENT_LIVE_ENABLED=false
STRIPE_LIVE_MODE=false
NEXT_PUBLIC_FLOW_RECORDER_ENABLED=false
```

Mail is verplicht voor registratie en wachtwoordherstel. Bij een ontbrekende of falende mailprovider worden codes niet naar logs geschreven.

## Release-invariant

Iedere toekomstige Outrun IQ-release moet drie deliverables bevatten:

1. een flat ZIP met `package.json` in de root;
2. een bijgewerkte mega-overdracht;
3. een exacte Termius-updateopdracht waarvan de Raw GitHub-URL exact overeenkomt met de ZIP-bestandsnaam.
