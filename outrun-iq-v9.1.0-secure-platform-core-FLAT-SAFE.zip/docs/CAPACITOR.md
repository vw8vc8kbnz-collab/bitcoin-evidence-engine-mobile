# Outrun IQ — native appverpakking (latere fase)

De primaire productfocus van v9.1.0 is een veilige responsive webapp/PWA. Een Capacitor-schil is bewust geen onderdeel van deze release.

Een native iOS/Android-traject mag pas starten wanneer:

- buyer-, partner- en accountflows live op echte toestellen zijn getest;
- privacy- en mediaflows zijn goedgekeurd;
- push betrouwbaar werkt;
- app-specifieke native meerwaarde duidelijk is;
- reviewaccounts en supportproces bestaan;
- commerceclaims overeenkomen met de werkelijk actieve betaalmodus.

De bestaande `capacitor.config.ts` is alleen voorbereidende configuratie. Voeg geen native dependencies toe aan de productiebuild voordat een afzonderlijke native releasetrack is gestart.
