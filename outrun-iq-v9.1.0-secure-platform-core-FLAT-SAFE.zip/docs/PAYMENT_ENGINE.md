# Outrun IQ Payment Engine — pilotcontract v9.1.0

## Status

De paymentarchitectuur is provider-onafhankelijk voorbereid, maar **niet live**. `test` is de enige toegestane operationele modus in v9.1.0.

```text
Marketplace command
        ↓
Order / reservation state machine (nog verder te bouwen)
        ↓
Payment Engine
        ↓
Provider Adapter
        ↓
Stripe Connect of latere provider
```

## Bestaande afspraken

- bedragen in centen;
- AI mag alleen adviseren;
- ledger is append-only;
- idempotency is verplicht;
- providerdata is leidend voor echt geld;
- UI mag niet rechtstreeks met een provider praten;
- een readpad mag geen geldmutatie veroorzaken.

## Harde v9.1.0-lock

`lib/version.ts` bevat:

```ts
COMMERCE_LIVE_READY = false
```

Payment capture, payout en betaald Promote moeten deze lock controleren. Environmentvariabelen kunnen de lock niet overrulen.

## Nog te bouwen vóór livegang

- PostgreSQL-transacties;
- reservering met TTL;
- payment intent lifecycle;
- signaturevalidatie;
- webhookeventstore;
- retry/replay;
- refunds en disputes;
- payout/KYC;
- dagelijkse reconciliation;
- operationele financeconsole;
- incidentrespons.
