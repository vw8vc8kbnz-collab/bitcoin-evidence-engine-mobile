"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

const inp: React.CSSProperties = {
  width: "100%", border: "1px solid var(--line)", borderRadius: 13, padding: "13px 14px",
  font: "inherit", fontSize: 14, background: "var(--card)", outline: "none", color: "var(--txt)",
};

export function AuthFlow({ next = "/", initialAccountType = "persoonlijk" }: { next?: string; initialAccountType?: "persoonlijk" | "zakelijk" }) {
  const [mode, setMode] = useState<"login" | "register" | "reset">("register");
  const [step, setStep] = useState(1);
  const [acctType, setAcctType] = useState<"persoonlijk" | "zakelijk">(initialAccountType);
  const [f, setF] = useState({ email: "", code: "", name: "", password: "", companyName: "", kvk: "", city: "" });
  const [busy, setBusy] = useState(false);
  const [terms, setTerms] = useState(false);
  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");
  const router = useRouter();
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  async function api(path: string, body: object) {
    setBusy(true); setErr("");
    const r = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (!r.ok) { setErr(j.error || "Er ging iets mis"); return null; }
    return j;
  }

  function done(j: { role?: string; partner?: boolean; partnerPending?: boolean }) {
    const dest = j.role === "admin" ? "/beheer"
      : j.partner ? "/partner"
      : j.partnerPending ? "/word-partner"                     // zakelijk in behandeling
      : mode === "login" && acctType === "zakelijk" ? "/account"     // persoonlijk account blijft persoonlijk; geen upgradepad
      : next;
    router.replace(dest);
    router.refresh();
  }

  async function startRegister() {
    const j = await api("/api/auth/register-start", { email: f.email });
    if (j) { setStep(2); setInfo("We hebben een 6-cijferige code naar je e-mail gestuurd."); }
  }
  async function verifyRegister() {
    const j = await api("/api/auth/register-verify", {
      email: f.email, code: f.code, name: f.name, password: f.password,
      accountType: acctType,
      ...(acctType === "zakelijk" ? { companyName: f.companyName, kvk: f.kvk, city: f.city, termsAccepted: terms } : {}),
    });
    if (j) done(j);
  }
  async function login() {
    const j = await api("/api/auth/login", { email: f.email, password: f.password, accountType: acctType });
    if (j) done(j);
  }

  async function resetRequest() {
    const j = await api("/api/auth/reset-request", { email: f.email });
    if (j) setStep(2);
  }
  async function resetVerify() {
    const j = await api("/api/auth/reset-verify", { email: f.email, code: f.code, password: f.password });
    if (j) { setMode("login"); setStep(1); setErr(""); setF({ ...f, code: "", password: "" }); }
  }

  return (
    <div className="authcard">
      <div className="seg" style={{ margin: "0 0 18px" }}>
        <button className={mode === "register" ? "on" : ""} onClick={() => { setMode("register"); setStep(1); setErr(""); }}>Account aanmaken</button>
        <button className={mode === "login" ? "on" : ""} onClick={() => { setMode("login"); setErr(""); }}>Inloggen</button>
      </div>



      {mode === "register" && step === 1 && (
        <>
          <label className="alabel">SOORT ACCOUNT</label>
          <div className="typerow">
            <button className={`typebtn${acctType === "persoonlijk" ? " on" : ""}`} onClick={() => setAcctType("persoonlijk")}>
              <b>Persoonlijk</b><span>deals ontdekken en kopen</span>
            </button>
            <button className={`typebtn${acctType === "zakelijk" ? " on" : ""}`} onClick={() => setAcctType("zakelijk")}>
              <b>Zakelijk</b><span>verkopen als Outrun IQ Partner</span>
            </button>
          </div>
          <label className="alabel">E-MAILADRES</label>
          <input style={inp} type="email" value={f.email} onChange={set("email")} placeholder={acctType === "zakelijk" ? "naam@bedrijf.nl" : "naam@voorbeeld.nl"} autoComplete="email"
            onKeyDown={e => e.key === "Enter" && f.email && startRegister()} />
          <button className="btn pri abtn" onClick={startRegister} disabled={busy || !f.email}>
            {busy ? "Bezig…" : "Stuur verificatiecode"}
          </button>
        </>
      )}

      {mode === "register" && step === 2 && (
        <>
          {info && <p className="note" style={{ margin: "0 0 12px" }}>{info} <button className="alink" onClick={() => setStep(1)}>Ander adres</button></p>}
          <label className="alabel">VERIFICATIECODE</label>
          <input style={{ ...inp, fontFamily: "var(--mono)", letterSpacing: 4, textAlign: "center" }} inputMode="numeric" maxLength={6}
            value={f.code} onChange={set("code")} placeholder="000000" />
          <label className="alabel">JE NAAM</label>
          <input style={inp} value={f.name} onChange={set("name")} placeholder="Voornaam" autoComplete="given-name" />
          <label className="alabel">WACHTWOORD (MIN. 8 TEKENS)</label>
          <input style={inp} type="password" value={f.password} onChange={set("password")} autoComplete="new-password" />
          {acctType === "zakelijk" && (
            <>
              <label className="alabel">BEDRIJFSNAAM</label>
              <input style={inp} value={f.companyName} onChange={set("companyName")} placeholder="Expert Outlet Rotterdam B.V." />
              <label className="alabel">KVK-NUMMER</label>
              <input style={inp} inputMode="numeric" maxLength={8} value={f.kvk}
                onChange={e => setF({ ...f, kvk: e.target.value.replace(/\D/g, "") })} placeholder="12345678" />
              {f.kvk.length > 0 && f.kvk.length < 8 && (
                <p style={{ fontSize: 11, color: "var(--amber-deep)", margin: "6px 2px 0", fontFamily: "var(--mono)" }}>
                  {f.kvk.length}/8 cijfers — nog {8 - f.kvk.length} te gaan
                </p>
              )}
              <label className="alabel">PLAATS</label>
              <input style={inp} value={f.city} onChange={set("city")} placeholder="Rotterdam" />
              <label className="lcheck">
                <input type="checkbox" checked={terms} onChange={e => setTerms(e.target.checked)} />
                <span>Ik ga namens dit bedrijf akkoord met de <Link href="/juridisch/partnervoorwaarden" target="_blank">Partnervoorwaarden</Link> en heb de <Link href="/juridisch/privacy" target="_blank">Privacyverklaring</Link> gelezen.</span>
              </label>
              <p className="note" style={{ margin: "12px 0 0" }}>Je zakelijke aanvraag wordt na registratie beoordeeld voordat je kunt verkopen. Kopen kan met een persoonlijk account.</p>
            </>
          )}
          <button className="btn pri abtn" onClick={verifyRegister}
            disabled={busy || f.code.length !== 6 || !f.name || f.password.length < 8
              || (acctType === "zakelijk" && (!f.companyName || f.kvk.length !== 8 || !f.city || !terms))}>
            {busy ? "Bezig…" : acctType === "zakelijk" ? "Maak zakelijk account" : "Maak account"}
          </button>
        </>
      )}

      {mode === "reset" && step === 1 && (
        <>
          <label className="alabel">E-MAILADRES VAN JE ACCOUNT</label>
          <input style={inp} type="email" value={f.email} onChange={set("email")} autoComplete="email"
            onKeyDown={e => e.key === "Enter" && resetRequest()} />
          <button className="btn pri abtn" onClick={resetRequest} disabled={busy || !f.email.includes("@")}>
            {busy ? "Bezig…" : "Stuur herstelcode"}
          </button>
          <button className="alink" onClick={() => { setMode("login"); setStep(1); }}>← Terug naar inloggen</button>
        </>
      )}
      {mode === "reset" && step === 2 && (
        <>
          <label className="alabel">HERSTELCODE (6 CIJFERS)</label>
          <input style={inp} inputMode="numeric" maxLength={6} value={f.code} onChange={set("code")} />
          <label className="alabel">NIEUW WACHTWOORD (MIN. 8 TEKENS)</label>
          <input style={inp} type="password" value={f.password} onChange={set("password")} autoComplete="new-password"
            onKeyDown={e => e.key === "Enter" && resetVerify()} />
          <button className="btn pri abtn" onClick={resetVerify} disabled={busy || f.code.length !== 6 || f.password.length < 8}>
            {busy ? "Bezig…" : "Stel nieuw wachtwoord in"}
          </button>
          <p className="note" style={{ margin: "10px 0 0" }}>Na het instellen ben je overal uitgelogd en log je in met je nieuwe wachtwoord.</p>
        </>
      )}
      {mode === "login" && (
        <>
          <label className="alabel">INLOGGEN ALS</label>
          <div className="typerow">
            <button className={`typebtn${acctType === "persoonlijk" ? " on" : ""}`} onClick={() => setAcctType("persoonlijk")}>
              <b>Persoonlijk</b><span>naar de shop</span>
            </button>
            <button className={`typebtn${acctType === "zakelijk" ? " on" : ""}`} onClick={() => setAcctType("zakelijk")}>
              <b>Zakelijk</b><span>naar de Partner Hub</span>
            </button>
          </div>
          <label className="alabel">E-MAILADRES</label>
          <input style={inp} type="email" value={f.email} onChange={set("email")} autoComplete="email" />
          <label className="alabel">WACHTWOORD</label>
          <input style={inp} type="password" value={f.password} onChange={set("password")} autoComplete="current-password"
            onKeyDown={e => e.key === "Enter" && login()} />
          <button className="btn pri abtn" onClick={login} disabled={busy || !f.email || !f.password}>
            {busy ? "Bezig…" : "Log in"}
          </button>
          <button className="alink" onClick={() => { setMode("reset"); setStep(1); setErr(""); }}>Wachtwoord vergeten?</button>
        </>
      )}

      {err && <p className="note" style={{ color: "var(--amber-deep)", marginTop: 12 }}>{err}</p>}
      <p className="note" style={{ marginTop: 14 }}>Door een account te maken ga je akkoord met de <Link href="/juridisch/gebruiksvoorwaarden" target="_blank">Gebruiksvoorwaarden</Link> en <Link href="/juridisch/privacy" target="_blank">Privacyverklaring</Link>. De code wordt gemaild; in testfase zonder mailkey staat hij in de serverlog.</p>
    </div>
  );
}
