"use client";
/**
 * OUTRUN IQ — SplashIntro v1
 * Vector-scherpe logo-intro als React-component (vervangt de MP4-splash).
 * - Zelfde choreografie als de video: ring tekent → marker breekt uit →
 *   letters tekenen → slogan. Standaard 2.6s (SPEED aanpasbaar).
 * - Toont 1× per sessie. Skip-knop. prefers-reduced-motion → direct klaar.
 *
 * Integratie (app/layout.tsx):
 *   import { SplashIntro } from "@/components/SplashIntro";
 *   ...
 *   <body>
 *     <SplashIntro />
 *     <header className="hdr">...
 */
import { useEffect, useRef, useState } from "react";

const SPEED = 4.2 / 2.6; // choreografie van 4.2s gecomprimeerd naar 2.6s
const DUR = 4.2;

/* ---- geometrie (identiek aan het logopakket) ---- */
const O =
  "M42,10 L52,10 A22,22 0 0 1 74,32 L74,68 A22,22 0 0 1 52,90 L32,90 A22,22 0 0 1 10,68 L10,32 A22,22 0 0 1 32,10 L42,10";
const LETTERS: Record<string, [number, string[]]> = {
  O: [84, [O]],
  U: [84, ["M10,10 L10,63 A32,32 0 0 0 74,63 L74,10"]],
  T: [76, ["M2,10 L74,10", "M38,10 L38,90"]],
  R: [78, ["M10,90 L10,10 L40,10 A26,26 0 0 1 40,62 L10,62", "M40,62 L68,90"]],
  N: [84, ["M10,90 L10,10 L74,90 L74,10"]],
  I: [20, ["M10,10 L10,90"]],
  Q: [84, [O, "M54,70 L80,96"]],
};
const TRACK = 16;
const WORD = "OUTRUN IQ";
const IQ_FROM = 6;

function layout() {
  const segs: { d: string; x: number; letter: number }[] = [];
  let x = 0, li = 0;
  for (const ch of WORD) {
    if (ch === " ") { x += 42; continue; }
    const [w, paths] = LETTERS[ch];
    for (const d of paths) segs.push({ d, x, letter: li });
    x += w + TRACK; li++;
  }
  return { segs, width: x - TRACK };
}
const { segs, width: WORD_W } = layout();

const R = 60, ESC = (-45 * Math.PI) / 180, HG = (40 * Math.PI) / 180;
const a1 = ESC + HG, a2 = ESC - HG + 2 * Math.PI;
const RING_D = `M${(R * Math.cos(a1)).toFixed(2)},${(R * Math.sin(a1)).toFixed(2)} A${R},${R} 0 1 1 ${(R * Math.cos(a2)).toFixed(2)},${(R * Math.sin(a2)).toFixed(2)}`;
const DOT_F = [96 * Math.cos(ESC), 96 * Math.sin(ESC)];
const DOT_S = [66 * Math.cos(ESC), 66 * Math.sin(ESC)];

/* ---- easing ---- */
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const P = (t: number, a: number, b: number) => clamp((t - a) / (b - a), 0, 1);
const outCubic = (p: number) => 1 - Math.pow(1 - p, 3);
const inOutQuint = (p: number) => (p < 0.5 ? 16 * p ** 5 : 1 - Math.pow(-2 * p + 2, 5) / 2);
const outBack = (p: number) => { const c = 1.9; return 1 + (c + 1) * (p - 1) ** 3 + c * (p - 1) ** 2; };

export function SplashIntro() {
  const [show, setShow] = useState(false);
  const [fading, setFading] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const doneRef = useRef(false);

  useEffect(() => {
    if (sessionStorage.getItem("oiq-intro-seen")) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      sessionStorage.setItem("oiq-intro-seen", "1");
      return;
    }
    setShow(true);
  }, []);

  useEffect(() => {
    if (!show) return;
    const root = rootRef.current!;
    const q = <T extends Element>(s: string) => root.querySelector(s) as T;
    const ring = q<SVGPathElement>("#oiq-ring");
    const ringG = q<SVGGElement>("#oiq-ringG");
    const markG = q<SVGGElement>("#oiq-markG");
    const dot = q<SVGCircleElement>("#oiq-dot");
    const wordG = q<SVGGElement>("#oiq-word");
    const slogan = q<HTMLDivElement>("#oiq-slogan");
    const RL = ring.getTotalLength();
    ring.style.strokeDasharray = `${RL}`;
    const letters = Array.from(root.querySelectorAll<SVGPathElement>(".oiq-l")).map(p => {
      const L = p.getTotalLength();
      p.style.strokeDasharray = `${L}`;
      p.style.strokeDashoffset = `${L}`;
      return { p, L, letter: Number(p.dataset.letter) };
    });

    const MARK_CX = -(232 + 76 + WORD_W) / 2 + 96;
    const WORD_X = MARK_CX - 96 + 232 + 76;

    const seek = (t: number) => {
      const rp = outCubic(P(t, 0.25, 1.15));
      ring.style.strokeDashoffset = `${RL * (1 - rp)}`;
      ringG.setAttribute("transform", `rotate(${-42 * (1 - rp)})`);

      const dp = P(t, 1.02, 1.5), db = outBack(dp);
      const dx = DOT_S[0] + (DOT_F[0] - DOT_S[0]) * db;
      const dy = DOT_S[1] + (DOT_F[1] - DOT_S[1]) * db;
      dot.setAttribute("cx", `${dx}`); dot.setAttribute("cy", `${dy}`);
      dot.setAttribute("r", `${17 * clamp(db, 0, 1.15)}`);
      dot.setAttribute("opacity", `${clamp(dp * 8, 0, 1)}`);

      const mp = inOutQuint(P(t, 1.5, 2.2));
      const msc = 1.35 + (1 - 1.35) * mp;
      markG.setAttribute("transform", `translate(${MARK_CX * mp},${8 * mp}) scale(${msc})`);

      for (const it of letters) {
        const s = 1.62 + it.letter * 0.085;
        it.p.style.strokeDashoffset = `${it.L * (1 - outCubic(P(t, s, s + 0.42)))}`;
      }
      wordG.setAttribute("opacity", `${P(t, 1.55, 1.7)}`);
      wordG.setAttribute("transform", `translate(${WORD_X},-50)`);

      const sp = outCubic(P(t, 2.6, 3.25));
      slogan.style.opacity = `${sp}`;
      slogan.style.letterSpacing = `${0.62 - 0.3 * sp}em`;
      slogan.style.transform = `translateY(${(1 - sp) * 14}px)`;
    };

    let raf = 0;
    const t0 = performance.now();
    const loop = (now: number) => {
      const t = ((now - t0) / 1000) * SPEED;
      seek(Math.min(t, DUR));
      if (t >= DUR + 0.5) { finish(); return; }
      raf = requestAnimationFrame(loop);
    };
    const finish = () => {
      if (doneRef.current) return;
      doneRef.current = true;
      sessionStorage.setItem("oiq-intro-seen", "1");
      setFading(true);
      setTimeout(() => setShow(false), 380);
    };
    (root as HTMLDivElement & { __finish?: () => void }).__finish = finish;
    seek(0);
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [show]);

  if (!show) return null;

  const skip = () => (rootRef.current as (HTMLDivElement & { __finish?: () => void }) | null)?.__finish?.();

  return (
    <div
      ref={rootRef}
      role="presentation"
      className="splashIntroRoot"
      style={{
        position: "fixed", inset: 0, zIndex: 100,
        background: "radial-gradient(120% 160% at 50% 40%, #0F5459 0%, #12161B 55%, #0B0F13 100%)",
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        opacity: fading ? 0 : 1, transition: "opacity .38s ease",
      }}
    >
      <svg viewBox={`${-(232 + 76 + WORD_W) / 2 - 140} -260 ${232 + 76 + WORD_W + 280} 520`}
        style={{ width: "min(78vw, 720px)", overflow: "visible" }} aria-label="Outrun IQ">
        <g id="oiq-markG">
          <g id="oiq-ringG">
            <path id="oiq-ring" d={RING_D} fill="none" stroke="#35A9AC"
              strokeWidth="22" strokeLinecap="round" />
          </g>
          <circle id="oiq-dot" r="0" fill="#E9A13B" />
        </g>
        <g id="oiq-word" opacity="0">
          {segs.map((s, i) => (
            <path key={i} className="oiq-l" data-letter={s.letter} d={s.d}
              transform={`translate(${s.x},0)`} fill="none" strokeWidth="20"
              stroke={s.letter >= IQ_FROM ? "#35A9AC" : "#FFFFFF"}
              strokeLinecap="round" strokeLinejoin="round" />
          ))}
        </g>
      </svg>
      <div id="oiq-slogan" style={{
        marginTop: "5vh", opacity: 0, color: "#A8B7B8",
        fontFamily: "'Schibsted Grotesk',sans-serif", fontWeight: 400,
        fontSize: "clamp(12px,1.7vw,17px)", textTransform: "uppercase", whiteSpace: "nowrap",
      }}>
        Move inventory smarter<span style={{ color: "#E9A13B", fontWeight: 600 }}>.</span>
      </div>
      <button onClick={skip} aria-label="Intro overslaan" style={{
        position: "absolute", right: 20, bottom: "max(24px, env(safe-area-inset-bottom))",
        color: "#8B96A0", border: "1px solid #2C3540", borderRadius: 99,
        padding: "9px 18px", fontSize: 13, background: "rgba(18,22,27,.4)",
      }}>
        Skip intro
      </button>
    </div>
  );
}
