/* eslint-disable @next/next/no-img-element -- upload-URLs kunnen privé en cookiegebonden zijn; Next Image proxy zou de gebruikerssessie niet meenemen. */
import Link from "next/link";
import { eur } from "@/lib/data";
import type { PublicListing } from "@/lib/public-listing";
import { EvidenceStrip } from "./EvidenceStrip";
import { BidBox } from "./BidBox";
import { SaveButton } from "./SaveButton";
import { Stars } from "./Reviews";

export function ListingBody({l,sellerName,sellerLogo,myBid,savedOn,rating}:{l:PublicListing;sellerName:string;sellerLogo?:string;myBid?:{id:string;amount:number;counterAmount?:number;status:string}|null;savedOn?:boolean;rating?:{avg:number;count:number}|null}){
  const disc=l.newPrice>l.price&&l.newPrice>0?Math.round((1-l.price/l.newPrice)*100):0;const stockLabel=l.stock>1?`${l.stock} beschikbaar`:"Laatste stuk";const live=process.env.PAYMENT_LIVE_ENABLED==="true";
  return <div className="lsheet trustListingSheet"><div className="grab"/><div className="lhero"><div className="lhmeta"><span>ZAKELIJKE OUTLETDEAL</span><span>{stockLabel}</span></div><div className="listingTitleRow"><div><small>{l.brand||l.category}</small><h1>{l.title}</h1></div><SaveButton id={l.id} initialOn={savedOn}/></div><div className="lchips">{disc>0&&<span>−{disc}% t.o.v. opgegeven nieuwprijs</span>}<span>Conditie {l.conditionScore}/10</span><span>{l.pickupCity}</span></div></div>
    <div className="selrow premium"><span className="av">{sellerLogo?<img src={sellerLogo} alt={`${sellerName} logo`} style={{width:"100%",height:"100%",objectFit:"cover",borderRadius:"inherit"}}/>:sellerName.slice(0,2).toUpperCase()}</span><span><b>{sellerName}{rating?<>&nbsp;· <Stars n={rating.avg} size={11}/> <small>{rating.avg}</small></>:null}</b><span>Zakelijk account goedgekeurd voor verkoop</span></span><Link href={`/store/${l.sellerSlug}`} className="go">Bekijk aanbieder →</Link></div>
    <section className="conditionDecisionCard"><span>CONDITIE</span><h2>{l.condition||"Conditie niet omschreven"}</h2>{l.defect&&<p><b>Bekend aandachtspunt:</b> {l.defect}</p>}<small>Controleer altijd alle foto's en productinformatie vóór je bestelt.</small></section>
    <div className="pricecard premium trustPriceCard"><h4>INDICATIEVE PRIJSCONTEXT</h4><div className="l1"><b>{eur(l.price)}{l.perUnit&&"/st"}</b>{l.newPrice>l.price&&<s>opgegeven nieuwprijs {eur(l.newPrice)}</s>}{disc>0&&<span className="d">−{disc}%</span>}</div><EvidenceStrip l={l} labels={false}/><p className="src">Prijsankers zijn hulpmiddelen en geen garantie voor marktwaarde. De aanbieder bepaalt de uiteindelijke prijs.</p></div>
    {l.listingCopy?.description&&<div className="listingDescriptionCard"><h2>Beschrijving</h2><p>{l.listingCopy.description}</p>{l.listingCopy.bullets?.length?<div className="listingDescriptionBullets">{l.listingCopy.bullets.slice(0,4).map((b,i)=><span key={`${b}-${i}`}>✓ {b}</span>)}</div>:null}</div>}
    <div className="fulfilmentCard"><span><b>Levering</b><small>{l.delivery}{l.deliveryPrice>0?` · ${eur(l.deliveryPrice)}`:""}</small></span><span><b>Afhalen</b><small>{l.pickupCity}</small></span><span><b>Voorraad</b><small>{stockLabel}</small></span></div>
    <div className="trustgrid honestTrustGrid"><span><b>Conditie zichtbaar</b><small>foto's, beschrijving en bekende gebreken</small></span><span><b>Zakelijke aanbieder</b><small>bedrijfsgegevens zijn bij Outrun bekend</small></span><span><b>Orderondersteuning</b><small>vragen en problemen blijven bij de order</small></span></div>
    <div className="cta2 stickybuy"><Link href={`/checkout/${l.id}`} className="btn pri">{live?"Bestellen":"Testorder"} — {eur(l.price)}</Link><Link href={`/store/${l.sellerSlug}`} className="btn sec">Aanbieder bekijken</Link></div><BidBox listingId={l.id} price={l.price} minimumBid={l.minimumBid} myBid={myBid??null}/>{!live&&<p className="note" style={{margin:"12px 4px 0"}}>Pilotmodus: er wordt nog niets afgeschreven. Deze flow test bestelling, communicatie en levering.</p>}
  </div>
}
