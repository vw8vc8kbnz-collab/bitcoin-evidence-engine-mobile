"use client";
import { usePathname } from "next/navigation";
import { useEffect } from "react";

export function ThemeColorSync() {
  const pathname = usePathname();
  useEffect(() => {
    const isDark = pathname?.startsWith("/partner") || pathname?.startsWith("/beheer");
    const surface = isDark ? "#071015" : "#EEF5F0";
    // iOS PWA status bars are safest when the browser chrome/theme-color stays dark.
    // The page surface itself is still set separately below.
    const color = "#071015";
    let meta = document.querySelector('meta[name="theme-color"]') as HTMLMetaElement | null;
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "theme-color";
      document.head.appendChild(meta);
    }
    meta.content = color;
    document.documentElement.style.backgroundColor = color;
    document.body.style.backgroundColor = surface;
    document.documentElement.dataset.oiqSurface = isDark ? "dark" : "buyer";
  }, [pathname]);
  return null;
}
