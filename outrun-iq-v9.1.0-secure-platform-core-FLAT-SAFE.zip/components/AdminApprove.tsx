"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export function AdminApprove({ userId, label }: { userId: string; label: string }) {
  const [busy,setBusy]=useState(false); const [err,setErr]=useState(""); const router=useRouter();
  async function act(approve:boolean){ setBusy(true); setErr(""); const r=await fetch("/api/admin/approve",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId,approve})}); setBusy(false); if(r.ok)router.refresh(); else setErr((await r.json().catch(()=>({}))).error||"Mislukt"); }
  return <div className="scan" style={{marginTop:12}}><div className="r" style={{display:"block"}}>{label}</div><div className="r" style={{gap:8}}><button className="go" disabled={busy} onClick={()=>act(true)}>KEUR GOED →</button><button className="go" disabled={busy} onClick={()=>act(false)}>WIJS AF</button></div>{err&&<div className="r" style={{color:"var(--amber)"}}>{err}</div>}</div>;
}
