"use client";
/* eslint-disable @next/next/no-img-element -- upload-URLs kunnen privé en cookiegebonden zijn; Next Image proxy zou de gebruikerssessie niet meenemen. */
import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Seller } from "@/lib/types";

const inp: React.CSSProperties = {
  width: "100%", background: "none", border: "1px solid #2A3540", borderRadius: 11,
  padding: "11px 12px", color: "#fff", font: "inherit", fontSize: 13, outline: "none",
};
const grid2: React.CSSProperties = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 };

export function StorefrontEditor({ seller }:{ seller: Seller }) {
  const [f, setF] = useState({
    companyName: seller.name ?? "", kvk: seller.kvk ?? "", vatNumber: seller.vatNumber ?? "",
    contactPerson: seller.contactPerson ?? "", businessEmail: seller.businessEmail ?? seller.support?.email ?? "", businessPhone: seller.businessPhone ?? seller.support?.phone ?? "",
    about: seller.about ?? "", street: seller.address?.street ?? "", postcode: seller.address?.postcode ?? "", city: seller.address?.city ?? "",
    supEmail: seller.support?.email ?? "", supPhone: seller.support?.phone ?? "", supReturns: seller.support?.returnsInfo ?? "",
    deliveryOptions: (seller.deliveryOptions || []).join(", "), shippingCost: seller.shippingCost != null ? String(seller.shippingCost) : "",
    bankStatus: seller.payout?.bankStatus ?? "missing", ibanMasked: seller.payout?.ibanMasked ?? "",
  });
  const [logoUrl, setLogoUrl] = useState(seller.logo ?? "");
  const [bannerUrl, setBannerUrl] = useState(seller.banner ?? "");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const router = useRouter();
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });

  async function upload(file: File | undefined, kind: "logo" | "banner") {
    if (!file) return;
    setBusy(true); setMsg("");
    const fd = new FormData();
    fd.append("photos", file);
    const r = await fetch("/api/partner/upload", { method: "POST", body: fd });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.urls?.[0]) (kind === "logo" ? setLogoUrl : setBannerUrl)(j.urls[0]);
    else setMsg(j.error || "Upload mislukt");
  }

  async function save() {
    setBusy(true); setMsg("");
    const body: Record<string, unknown> = {
      logoUrl, bannerUrl, about: f.about, companyName: f.companyName, kvk: f.kvk, vatNumber: f.vatNumber,
      contactPerson: f.contactPerson, businessEmail: f.businessEmail, businessPhone: f.businessPhone,
      deliveryOptions: f.deliveryOptions.split(",").map(x => x.trim()).filter(Boolean).slice(0, 6),
      shippingCost: f.shippingCost === "" ? undefined : Number(f.shippingCost),
      payout: { bankStatus: f.bankStatus, ibanMasked: f.ibanMasked },
    };
    if (f.street || f.postcode || f.city) body.address = { street: f.street, postcode: f.postcode, city: f.city };
    if (f.supEmail) body.support = { email: f.supEmail, phone: f.supPhone, returnsInfo: f.supReturns };
    const r = await fetch("/api/partner/profile", {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setMsg("Partnerprofiel opgeslagen ✓"); router.refresh(); }
    else setMsg(j.error || "Opslaan mislukt");
  }

  return (
    <div className="dgroup" style={{ marginTop: 14, padding: "14px 16px", display: "block" }}>
      <label className="alabel" style={{ color: "#5F6873" }}>BEDRIJFSGEGEVENS</label>
      <input style={{ ...inp, marginBottom: 8 }} value={f.companyName} onChange={set("companyName")} placeholder="Bedrijfsnaam" />
      <div style={grid2}><input style={inp} value={f.kvk} onChange={set("kvk")} placeholder="KvK" /><input style={inp} value={f.vatNumber} onChange={set("vatNumber")} placeholder="BTW-nummer" /></div>
      <div style={{ ...grid2, marginTop: 8 }}><input style={inp} value={f.contactPerson} onChange={set("contactPerson")} placeholder="Contactpersoon" /><input style={inp} value={f.businessPhone} onChange={set("businessPhone")} placeholder="Telefoon" /></div>
      <input style={{ ...inp, marginTop: 8 }} type="email" value={f.businessEmail} onChange={set("businessEmail")} placeholder="Zakelijk e-mailadres" />

      <label className="alabel" style={{ color: "#5F6873" }}>LOGO & BANNER</label>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <span className="av" style={{ width: 52, height: 52, flex: "none", overflow: "hidden" }}>
          {logoUrl ? <img src={logoUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : "LO"}
        </span>
        <label className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)", cursor: "pointer" }}>
          {logoUrl ? "LOGO VERVANGEN →" : "LOGO UPLOADEN →"}<input type="file" accept="image/*" hidden onChange={e => upload(e.target.files?.[0], "logo")} />
        </label>
      </div>
      <div style={{ height: 74, borderRadius: 12, overflow: "hidden", background: "#1A222B", display: "grid", placeItems: "center", position: "relative", marginTop: 10 }}>
        {bannerUrl ? <img src={bannerUrl} alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} /> : <span style={{ fontFamily: "var(--mono)", fontSize: 10, color: "#5F6873" }}>NOG GEEN BANNER</span>}
      </div>
      <label className="go" style={{ display: "inline-block", marginTop: 8, fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)", cursor: "pointer" }}>
        {bannerUrl ? "BANNER VERVANGEN →" : "BANNER UPLOADEN →"}<input type="file" accept="image/*" hidden onChange={e => upload(e.target.files?.[0], "banner")} />
      </label>

      <label className="alabel" style={{ color: "#5F6873" }}>STOREPROFIEL</label>
      <textarea rows={3} maxLength={420} value={f.about} onChange={set("about")} placeholder="Bijv.: Officieel dealer sinds 2004. Outlet uit eigen showroom en retourstromen." style={{ ...inp, resize: "vertical" }} />
      <label className="alabel" style={{ color: "#5F6873" }}>AFHAAL- / MAGAZIJNADRES</label>
      <input style={{ ...inp, marginBottom: 8 }} value={f.street} onChange={set("street")} placeholder="Straat + nummer" />
      <div style={grid2}><input style={inp} value={f.postcode} onChange={set("postcode")} placeholder="1234 AB" /><input style={inp} value={f.city} onChange={set("city")} placeholder="Plaats" /></div>
      <label className="alabel" style={{ color: "#5F6873" }}>LEVERING & RETOUR</label>
      <input style={{ ...inp, marginBottom: 8 }} value={f.deliveryOptions} onChange={set("deliveryOptions")} placeholder="Ophalen, bezorgen, pallettransport" />
      <input style={{ ...inp, marginBottom: 8 }} type="number" min={0} value={f.shippingCost} onChange={set("shippingCost")} placeholder="Standaard verzendkosten €" />
      <input style={{ ...inp, marginBottom: 8 }} type="email" value={f.supEmail} onChange={set("supEmail")} placeholder="Klantenservice e-mail" />
      <input style={{ ...inp, marginBottom: 8 }} value={f.supPhone} onChange={set("supPhone")} placeholder="Klantenservice telefoon" />
      <input style={inp} value={f.supReturns} onChange={set("supReturns")} placeholder="Retourvoorwaarden / instructies" />

      <label className="alabel" style={{ color: "#5F6873" }}>PAYOUT STATUS</label>
      <div style={grid2}>
        <select style={{ ...inp, appearance: "none" }} value={f.bankStatus} onChange={set("bankStatus")}><option value="missing">Bank ontbreekt</option><option value="pending">In controle</option><option value="verified">Geverifieerd</option></select>
        <input style={inp} value={f.ibanMasked} onChange={set("ibanMasked")} placeholder="IBAN masked: NL••1234" />
      </div>
      <p className="note" style={{ marginTop: 10 }}>Stripe Connect blijft nog preview/teststatus. Deze velden maken de onboarding-flow alvast compleet zonder live geld te verplaatsen.</p>
      <button className="btn pri" style={{ width: "100%", marginTop: 14, border: 0 }} onClick={save} disabled={busy}>{busy ? "Bezig…" : "Partnerprofiel opslaan"}</button>
      {msg && <p className="note" style={{ margin: "10px 0 0", color: msg.includes("✓") ? "var(--petrol-glow)" : "var(--amber)" }}>{msg}</p>}
    </div>
  );
}
