export function EvidenceStrip({ l, light = false, labels = true }:{
  l: { price: number; newPrice: number }; light?: boolean; labels?: boolean;
}) {
  const reference = l.newPrice > 0 ? l.newPrice : l.price;
  const p = Math.min(96, Math.max(4, Math.round((l.price / Math.max(1, reference)) * 100)));
  return (
    <div aria-label={`Prijspositie: vraagprijs €${l.price}, opgegeven nieuwprijs €${reference}`}>
      <div className={`ev ${light ? "lt" : ""}`} style={{ ["--p" as string]: `${p}%` }} role="img"><i /><u /></div>
      {labels && <div className="evl"><span>VRAAGPRIJS €{l.price}</span><span>REFERENTIE</span><span>NIEUW €{reference}</span></div>}
    </div>
  );
}
