"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { eur } from "@/lib/types";

type MyBid = { id: string; amount: number; counterAmount?: number; status: string } | null;

/** Bieden op een listing met een transparante, server-bepaalde indicatieve ondergrens. */
export function BidBox({ listingId, price, minimumBid, myBid }:{
  listingId: string; price: number; minimumBid: number; myBid: MyBid;
}) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();
  const n = Math.round(Number(amount)) || 0;
  const indication = n <= 0 ? null
    : n >= price ? { t: "Dit is de vraagprijs — koop dan direct", c: "var(--txt2)" }
    : n >= Math.max(minimumBid, price * 0.9) ? { t: "Dicht bij de vraagprijs", c: "var(--petrol)" }
    : n >= minimumBid ? { t: "Binnen de indicatieve biedruimte", c: "var(--amber-deep)" }
    : { t: `Onder de indicatieve ondergrens van ${eur(minimumBid)}`, c: "var(--amber-deep)" };

  async function submit() {
    setBusy(true); setErr("");
    const r = await fetch("/api/bids", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ listingId, amount: n, message: msg || undefined }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setOpen(false); router.refresh(); }
    else setErr(j.error || "Bieden mislukt");
  }
  async function act(action: "accept-counter" | "withdraw") {
    if (!myBid) return;
    setBusy(true);
    await fetch(`/api/bids/${myBid.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action }),
    });
    setBusy(false);
    router.refresh();
  }

  if (myBid) {
    return (
      <div className="authcard" style={{ margin: "14px 0 0", padding: 16 }}>
        <div className="slabel" style={{ margin: "0 0 8px" }}>
          JOUW BOD · {myBid.status === "accepted" ? "GEACCEPTEERD" : myBid.status === "countered" ? "TEGENBOD ONTVANGEN" : "IN AFWACHTING"}
        </div>
        <p style={{ margin: 0, fontSize: 14 }}>
          <b className="mono" style={{ fontSize: 18 }}>{eur(myBid.amount)}</b>
          {myBid.status === "countered" && myBid.counterAmount && (
            <> — partner stelt <b className="mono" style={{ fontSize: 18, color: "var(--petrol)" }}>{eur(myBid.counterAmount)}</b> voor</>
          )}
        </p>
        {myBid.status === "accepted" && (
          <Link href={`/checkout/${listingId}?bid=${myBid.id}`} className="btn pri" style={{ display: "block", textAlign: "center", marginTop: 12 }}>
            Afrekenen voor {eur(myBid.amount)}
          </Link>
        )}
        <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
          {myBid.status === "countered" && (
            <button className="btn pri" style={{ flex: 1 }} disabled={busy} onClick={() => act("accept-counter")}>
              Accepteer {eur(myBid.counterAmount ?? 0)}
            </button>
          )}
          <button className="btn sec" style={{ flex: myBid.status === "countered" ? "none" : 1, padding: "0 18px" }} disabled={busy} onClick={() => act("withdraw")}>
            Trek bod in
          </button>
        </div>
      </div>
    );
  }

  if (!open) {
    return (
      <div className="bidStandalone">
        <button className="btn sec" onClick={() => setOpen(true)}>
          Doe een bod
        </button>
      </div>
    );
  }
  return (
    <div className="authcard" style={{ margin: "14px 0 0", padding: 16 }}>
      <label className="alabel" style={{ marginTop: 0 }}>JOUW BOD (VRAAGPRIJS {eur(price)})</label>
      <input
        type="number" inputMode="numeric" min={1} max={price - 1} value={amount}
        onChange={e => setAmount(e.target.value)} placeholder={String(Math.round(price * 0.9))}
        style={{ width: "100%", border: "1px solid var(--line)", borderRadius: 13, padding: "12px 14px", font: "inherit", fontSize: 16, background: "var(--card)", outline: "none", color: "var(--txt)" }}
      />
      {indication && <p className="note" style={{ margin: "8px 0 0", color: indication.c, fontWeight: 700 }}>{indication.t}</p>}
      <label className="alabel">BERICHT (OPTIONEEL)</label>
      <input
        value={msg} onChange={e => setMsg(e.target.value)} maxLength={200}
        placeholder="Bijv.: kan ik hem dit weekend ophalen?"
        style={{ width: "100%", border: "1px solid var(--line)", borderRadius: 13, padding: "12px 14px", font: "inherit", fontSize: 13.5, background: "var(--card)", outline: "none", color: "var(--txt)" }}
      />
      <p className="note" style={{ margin: "8px 0 0" }}>De aanbieder ontvangt je bod en kan accepteren, afwijzen of een tegenbod doen. Deel geen gevoelige contact- of betaalgegevens in je bericht.</p>
      {err && <p className="note" style={{ color: "var(--amber-deep)", margin: "8px 0 0" }}>{err}</p>}
      <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
        <button className="btn pri" style={{ flex: 1 }} disabled={busy || n <= 0 || n >= price} onClick={submit}>
          {busy ? "Bezig…" : n > 0 ? `Bied ${eur(n)}` : "Bied"}
        </button>
        <button className="btn sec" style={{ flex: "none", padding: "0 18px" }} onClick={() => setOpen(false)}>Annuleer</button>
      </div>
    </div>
  );
}
