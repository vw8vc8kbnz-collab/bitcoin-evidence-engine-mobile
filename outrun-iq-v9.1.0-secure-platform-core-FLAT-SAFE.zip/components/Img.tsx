"use client";
/* eslint-disable @next/next/no-img-element -- upload-URLs kunnen privé en cookiegebonden zijn; Next Image proxy zou de gebruikerssessie niet meenemen. */
import { useState } from "react";
import { Illu, type IlluKind } from "./icons";

/** Productfoto met illustratie-fallback. Zonder src (nog geen foto's) → alleen illustratie. */
export function Img({ src, fallback, className = "", dark = false, children }:{
  src?: string; fallback: IlluKind; className?: string; dark?: boolean; children?: React.ReactNode;
}) {
  const [ok, setOk] = useState(true);
  return (
    <span className={`imw ${dark ? "dk" : ""} ${className}`}>
      {src && ok && <img src={src} alt="" loading="lazy" onError={() => setOk(false)} />}
      <span className="fall"><Illu kind={fallback} /></span>
      {children}
    </span>
  );
}
