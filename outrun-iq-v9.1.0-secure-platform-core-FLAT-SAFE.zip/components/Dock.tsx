"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { Mark } from "./icons";
import { BrandLockup } from "./Brand";

const I = {
  home: <path d="M4 11l8-7 8 7v9h-6v-6h-4v6H4z" />,
  search: <><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></>,
  bell: <><path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5h-15S6 14 6 10z" /><path d="M10.5 19a1.8 1.8 0 003 0" /></>,
  rocket: <><path d="M12 3c3 1 5 4 5 8l3 3-4 1-1 4-3-3c-4 0-7-2-8-5 3-1 6-4 8-8z" /><path d="M8 16l-3 3" /></>,
  saved: <path d="M6 3h12v18l-6-4-6 4z" />,
  user: <><circle cx="12" cy="8.5" r="3.5" /><path d="M5 19c1.2-3 4-4.5 7-4.5s5.8 1.5 7 4.5" /></>,
  grid: <><rect x="4" y="4" width="7" height="7" rx="1.5" /><rect x="13" y="4" width="7" height="7" rx="1.5" /><rect x="4" y="13" width="7" height="7" rx="1.5" /><rect x="13" y="13" width="7" height="7" rx="1.5" /></>,
  list: <path d="M4 6h16M4 12h16M4 18h10" />,
  orders: <path d="M5 4h14v16l-3-2-2 2-2-2-2 2-2-2-3 2z" />,
  money: <><path d="M4 17l5-5 4 3 7-8" /><path d="M15 7h5v5" /></>,
  store: <><rect x="4" y="4" width="16" height="16" rx="3" /><path d="M4 10h16M10 10v10" /></>,
};
function useActive(href:string, exact:boolean){const path=usePathname();return exact?path===href:path.startsWith(href)}
function Tab({href,icon,label,exact=false}:{href:string;icon:keyof typeof I;label:string;exact?:boolean}){const on=useActive(href,exact);const router=useRouter();useEffect(()=>{router.prefetch(href)},[href,router]);return <Link href={href} prefetch className={`t${on?" on":""}`}><svg viewBox="0 0 24 24">{I[icon]}</svg>{label}</Link>}

export function BuyerDock({isBuyer=false}:{isBuyer?:boolean}){
  const login=(next:string)=>`/welkom?type=persoonlijk&next=${encodeURIComponent(next)}`;
  return <nav className="dock buyerDockV91" aria-label="Koper-navigatie">
    <Tab href="/" icon="home" label="HOME" exact />
    <Tab href="/zoeken" icon="search" label="ZOEKEN" />
    <Tab href={isBuyer?"/bewaard":login("/bewaard")} icon="saved" label="BEWAARD" />
    <Tab href={isBuyer?"/meldingen":login("/meldingen")} icon="bell" label="ALERTS" />
    <Tab href={isBuyer?"/account":login("/account")} icon="user" label="ACCOUNT" />
  </nav>
}
export function SellerDock(){return <nav className="dock dk" aria-label="Partner-navigatie"><Tab href="/partner" icon="grid" label="DASH" exact/><Tab href="/partner/voorraad" icon="list" label="VOORRAAD"/><Link href="/partner/nieuw" prefetch className="plus" aria-label="Nieuw product"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></Link><Tab href="/partner/orders" icon="orders" label="ORDERS"/><Tab href="/partner/geld" icon="money" label="GELD"/></nav>}
function NavLink({href,label,exact=false}:{href:string;label:string;exact?:boolean}){const on=useActive(href,exact);return <Link href={href} className={`nl${on?" on":""}`}>{label}</Link>}
export function TopNav({isBuyer=false}:{isLoggedIn?:boolean;isPartner?:boolean;isBuyer?:boolean}){const accountHref=isBuyer?"/account":"/welkom?type=persoonlijk&next=/account";return <header className="topnav" aria-label="Hoofdnavigatie"><BrandLockup/><nav className="links"><NavLink href="/" label="Ontdek" exact/><NavLink href="/zoeken" label="Zoeken"/><NavLink href="/word-partner" label="Verkopen"/>{isBuyer&&<NavLink href="/bewaard" label="Bewaard"/>}{isBuyer&&<NavLink href="/account" label="Account"/>}</nav><span className="sp"/><Link href={accountHref} className="sellcta">{isBuyer?"Mijn Outrun":"Inloggen"}</Link></header>}
function SideLink({href,icon,label,exact=false}:{href:string;icon:keyof typeof I;label:string;exact?:boolean}){const on=useActive(href,exact);return <Link href={href} className={`sl${on?" on":""}`}><svg viewBox="0 0 24 24">{I[icon]}</svg>{label}</Link>}
export function SellerSide(){return <aside className="sidenav" aria-label="Partner-navigatie"><Link href="/partner" className="lock" style={{color:"#fff"}}><Mark size={26} glow/>PARTNER <b style={{color:"var(--petrol-glow)"}}>HUB</b></Link><nav><SideLink href="/partner" icon="grid" label="Dashboard" exact/><SideLink href="/partner/voorraad" icon="list" label="Voorraad"/><SideLink href="/partner/orders" icon="orders" label="Orders"/><SideLink href="/partner/geld" icon="money" label="Geld & uitbetalingen"/><SideLink href="/partner/storefront" icon="store" label="Storefront"/><SideLink href="/partner/account" icon="user" label="Account"/></nav><Link href="/partner/nieuw" className="sellcta side">+ Nieuw product</Link><Link href="/" className="sl back2buy">← Naar de shop</Link></aside>}
