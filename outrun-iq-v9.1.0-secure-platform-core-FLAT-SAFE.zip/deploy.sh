#!/usr/bin/env bash
# Outrun IQ v9.1.0 — veilige herbouw van een reeds bijgewerkte VPS-map.
# De ZIP-download/rsync gebeurt via de exacte Termius-opdracht uit de releaseoverdracht.
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/outrun-iq-v5}"
cd "$APP_DIR"

test -f package.json
test -f package-lock.json
test -f .env

echo ">>> Dependencies installeren vanuit lockfile"
npm ci --no-audit --no-fund

echo ">>> Releasecontract, koude build, lint, types en tests"
NEXT_TELEMETRY_DISABLED=1 npm run verify

echo ">>> PM2 herstart"
pm2 restart outrun-iq --update-env
pm2 status
pm2 logs outrun-iq --lines 100 --nostream

echo ">>> Publieke healthcheck"
curl -fsS https://outruniq.nl/api/health
echo
