import { promises as fs } from "fs";
import path from "path";
import type { DB } from "./types";

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "db.json");
const BACKUP_FILE = path.join(DATA_DIR, "db.last-good.json");

const EMPTY: DB = { users: [], sessions: [], codes: [], saved: [], notifications: [], sellers: [], listings: [], outletBatches: [], processingJobs: [], orders: [], bids: [], pushSubs: [], reviews: [], auditLog: [], flowEvents: [], mediaAssets: [], aiDecisions: [], promotionCampaigns: [], walletLedger: [], traffic: {}, counters: { order: 0 } };

type G = typeof globalThis & { __oiqDb?: DB; __oiqLock?: Promise<void> };
const g = globalThis as G;

function normalize(raw: unknown): DB {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new Error("db.json heeft geen geldig objectformaat");
  const v = raw as Partial<DB>;
  const db = { ...structuredClone(EMPTY), ...v } as DB;
  const arrays: (keyof DB)[] = ["users","sessions","codes","saved","notifications","sellers","listings","outletBatches","processingJobs","orders","bids","pushSubs","reviews","auditLog","flowEvents","mediaAssets","aiDecisions","promotionCampaigns","walletLedger"];
  for (const key of arrays) if (!Array.isArray(db[key])) throw new Error(`db.json veld ${String(key)} is ongeldig`);
  if (!db.counters || typeof db.counters.order !== "number") db.counters = { order: 0 };
  if (!db.traffic || typeof db.traffic !== "object" || Array.isArray(db.traffic)) db.traffic = {};
  return db;
}

async function load(): Promise<DB> {
  if (g.__oiqDb) return g.__oiqDb;
  try {
    const raw = await fs.readFile(DB_FILE, "utf8");
    g.__oiqDb = normalize(JSON.parse(raw));
  } catch (error: any) {
    if (error?.code === "ENOENT") {
      g.__oiqDb = structuredClone(EMPTY);
    } else {
      console.error("[store] DATABASE LOAD FAILED — fail closed", error);
      throw new Error("Database kon niet veilig worden geladen. Geen lege database aangemaakt.");
    }
  }
  return g.__oiqDb!;
}

async function persist(db: DB) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const tmp = DB_FILE + `.tmp-${process.pid}`;
  const body = JSON.stringify(db, null, 2);
  await fs.writeFile(tmp, body, { encoding: "utf8", mode: 0o600 });
  const handle = await fs.open(tmp, "r");
  try { await handle.sync(); } finally { await handle.close(); }
  try { await fs.copyFile(DB_FILE, BACKUP_FILE); } catch (error: any) { if (error?.code !== "ENOENT") throw error; }
  await fs.rename(tmp, DB_FILE);
}

/** Serialiseert writes en commit uitsluitend een volledig geslaagde clone. */
export async function mutate<T>(fn: (db: DB) => T | Promise<T>): Promise<T> {
  const prev = g.__oiqLock ?? Promise.resolve();
  let release!: () => void;
  g.__oiqLock = new Promise<void>(r => (release = r));
  await prev;
  try {
    const current = await load();
    const draft = structuredClone(current);
    const out = await fn(draft);
    await persist(draft);
    g.__oiqDb = draft;
    return structuredClone(out);
  } finally {
    release();
  }
}

export async function read(): Promise<DB> {
  return structuredClone(await load());
}

export const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
export const LEGACY_UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");
