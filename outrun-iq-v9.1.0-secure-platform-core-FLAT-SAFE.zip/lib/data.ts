import crypto from "crypto";
import { read, mutate } from "./store";
import { COMMISSION, slugify } from "./types";
import type { DB, Listing, Order, OrderStatus, Seller, User, Notification, SavedItem, Address, Bid, PromotionCampaign, PromotionCreative, WalletLedgerEntry, WalletSummary, LearningEvent } from "./types";
import { sendWebPush } from "./push";
import { audit } from "./audit";
import { toPublicListing, toPublicListings, type PublicListing } from "./public-listing";
import { toPublicSeller, type PublicSeller } from "./public-seller";
import { inferTaxonomy } from "./taxonomy";
export { eur } from "./types";
export type { Listing, Order, Seller, OrderStatus, User };
export type { PublicListing };


const cents = (n: number) => Math.round((Number.isFinite(n) ? n : 0) * 100);
const eurosFromCents = (n: number) => Math.round(n) / 100;
const walletAccount = (sellerSlug: string) => `partner:${sellerSlug}:wallet`;
const reserveAccount = (sellerSlug: string) => `partner:${sellerSlug}:campaign_reserved`;
const escrowAccount = (orderId: string) => `escrow:${orderId}`;
const promoteRevenueAccount = "outrun:promote_revenue";
const commissionRevenueAccount = "outrun:commission_revenue";
const deliveryRevenueAccount = "outrun:delivery_revenue";
const customerFundsAccount = "external:customer_funds";

function hashLedger(prevHash: string | undefined, e: Omit<WalletLedgerEntry, "hash">) {
  return crypto.createHash("sha256").update(JSON.stringify({ ...e, prevHash: prevHash ?? "GENESIS" })).digest("hex");
}

function appendLedger(db: DB, input: Omit<WalletLedgerEntry, "id" | "at" | "currency" | "prevHash" | "hash">): WalletLedgerEntry {
  db.walletLedger ??= [];
  const existing = db.walletLedger.find(x => x.idempotencyKey === input.idempotencyKey);
  if (existing) return existing;
  const prev = db.walletLedger.at(-1)?.hash;
  const rec: Omit<WalletLedgerEntry, "hash"> = {
    id: crypto.randomUUID?.() ?? Math.random().toString(36).slice(2, 12),
    at: new Date().toISOString(),
    currency: "EUR",
    prevHash: prev,
    ...input,
  };
  const full: WalletLedgerEntry = { ...rec, hash: hashLedger(prev, rec) };
  db.walletLedger.push(full);
  return full;
}

function accountBalanceCents(db: DB, account: string) {
  db.walletLedger ??= [];
  return db.walletLedger.reduce((sum, e) => sum + (e.creditAccount === account ? e.amountCents : 0) - (e.debitAccount === account ? e.amountCents : 0), 0);
}


function ledgerAccountBalances(db: DB) {
  db.walletLedger ??= [];
  const balances: Record<string, number> = {};
  for (const e of db.walletLedger) {
    balances[e.debitAccount] = (balances[e.debitAccount] ?? 0) - e.amountCents;
    balances[e.creditAccount] = (balances[e.creditAccount] ?? 0) + e.amountCents;
  }
  return balances;
}

function verifyLedgerChain(db: DB) {
  db.walletLedger ??= [];
  const issues: string[] = [];
  let prev: string | undefined;
  const seen = new Set<string>();
  db.walletLedger.forEach((entry, index) => {
    if (seen.has(entry.idempotencyKey)) issues.push(`Dubbele idempotencyKey: ${entry.idempotencyKey}`);
    seen.add(entry.idempotencyKey);
    if ((entry.prevHash ?? undefined) !== prev) issues.push(`Hash-chain breuk op regel ${index + 1}`);
    const { hash, ...withoutHash } = entry;
    const expected = hashLedger(prev, withoutHash);
    if (hash !== expected) issues.push(`Hash mismatch op regel ${index + 1} (${entry.id})`);
    if (!Number.isFinite(entry.amountCents) || entry.amountCents <= 0) issues.push(`Ongeldig bedrag op regel ${index + 1}`);
    if (entry.debitAccount === entry.creditAccount) issues.push(`Debet en credit gelijk op regel ${index + 1}`);
    prev = entry.hash;
  });
  return { ok: issues.length === 0, issues };
}


/* ============ AI LEARNING FOUNDATION (v8.5.6) ============
   Bewust compact: geen ruwe klikstream, geen foto's, geen grote payloads.
   Alleen geaggregeerde signalen in db.json met harde caps zodat de VPS niet volloopt. */
const LEARNING_PRODUCT_CAP = Math.max(250, Math.min(5000, Number(process.env.LEARNING_PRODUCT_CAP) || 2000));
const LEARNING_DAILY_CAP = Math.max(30, Math.min(730, Number(process.env.LEARNING_DAILY_CAP) || 400));

function learningKey(l: Partial<Listing>) {
  const brand = (l.brand || "").trim().toLowerCase();
  const model = (l.visionMetadata?.model || "").trim().toLowerCase();
  const title = (l.title || "").trim().toLowerCase();
  const base = [brand, model].filter(Boolean).join(" ") || title.split(/\s+/).slice(0, 5).join(" ") || "unknown";
  return `${l.category || "unknown"}:${slugify(base) || "unknown"}`;
}

function ensureLearning(db: DB) {
  const now = new Date().toISOString();
  db.learning ??= {
    version: 1,
    updatedAt: now,
    totals: { listingsLearned: 0, productKeys: 0, views: 0, saves: 0, bids: 0, orders: 0, soldValue: 0 },
    products: [],
    daily: [],
  };
  db.learning.products ??= [];
  db.learning.daily ??= [];
  db.learning.totals ??= { listingsLearned: 0, productKeys: 0, views: 0, saves: 0, bids: 0, orders: 0, soldValue: 0 };
  db.learning.updatedAt = now;
  return db.learning;
}

function dayBucket(db: DB) {
  const st = ensureLearning(db);
  const date = new Date().toISOString().slice(0, 10);
  let d = st.daily.find(x => x.date === date);
  if (!d) {
    d = { date, listingsPublished: 0, views: 0, saves: 0, bids: 0, orders: 0, soldValue: 0 };
    st.daily.push(d);
    st.daily.sort((a, b) => a.date.localeCompare(b.date));
    if (st.daily.length > LEARNING_DAILY_CAP) st.daily.splice(0, st.daily.length - LEARNING_DAILY_CAP);
  }
  return d;
}

function productBucket(db: DB, l: Listing) {
  const st = ensureLearning(db);
  const key = learningKey(l);
  let p = st.products.find(x => x.key === key);
  if (!p) {
    p = {
      key,
      brand: l.brand,
      model: l.visionMetadata?.model,
      category: l.category,
      samples: 0,
      activeListings: 0,
      soldSamples: 0,
      avgListPrice: 0,
      avgSoldPrice: 0,
      minListPrice: 0,
      maxListPrice: 0,
      totalViews: 0,
      totalSaves: 0,
      totalBids: 0,
      totalOrders: 0,
      avgAiConfidence: 0,
      lastSeenAt: new Date().toISOString(),
    };
    st.products.push(p);
    if (st.products.length > LEARNING_PRODUCT_CAP) {
      st.products.sort((a, b) => (b.totalOrders * 20 + b.totalBids * 5 + b.totalSaves * 3 + b.totalViews + b.samples * 10) - (a.totalOrders * 20 + a.totalBids * 5 + a.totalSaves * 3 + a.totalViews + a.samples * 10));
      st.products.splice(LEARNING_PRODUCT_CAP);
    }
  }
  p.brand ||= l.brand;
  p.model ||= l.visionMetadata?.model;
  p.category = l.category;
  p.lastSeenAt = new Date().toISOString();
  st.totals.productKeys = st.products.length;
  return p;
}

function avgPush(current: number, countBefore: number, value: number) {
  return Math.round(((current * countBefore) + value) / Math.max(1, countBefore + 1));
}

function learnListingPublished(db: DB, l: Listing) {
  const st = ensureLearning(db), d = dayBucket(db), p = productBucket(db, l);
  queueCommerceEvent(db, { type: "listing_published", listingId: l.id, sellerSlug: l.sellerSlug, value: l.price, meta: { category: l.category, confidence: l.confidence || 0 } });
  queueCommerceEvent(db, { type: "listing_seo", listingId: l.id, sellerSlug: l.sellerSlug, value: l.price, meta: { title: l.title.slice(0, 80), category: l.category } });
  p.avgListPrice = avgPush(p.avgListPrice, p.samples, l.price);
  p.minListPrice = p.minListPrice ? Math.min(p.minListPrice, l.price) : l.price;
  p.maxListPrice = Math.max(p.maxListPrice, l.price);
  p.avgAiConfidence = avgPush(p.avgAiConfidence, p.samples, l.confidence || l.visionMetadata?.confidence || 0);
  p.samples++;
  p.activeListings++;
  d.listingsPublished++;
  st.totals.listingsLearned++;
  st.totals.productKeys = st.products.length;
}

function learnView(db: DB, l: Listing) {
  const st = ensureLearning(db), d = dayBucket(db), p = productBucket(db, l);
  queueCommerceEvent(db, { type: "listing_view", listingId: l.id, sellerSlug: l.sellerSlug, value: 1 });
  p.totalViews++; d.views++; st.totals.views++;
}
function learnSave(db: DB, l: Listing) {
  const st = ensureLearning(db), d = dayBucket(db), p = productBucket(db, l);
  queueCommerceEvent(db, { type: "listing_save", listingId: l.id, sellerSlug: l.sellerSlug, value: 1 });
  p.totalSaves++; d.saves++; st.totals.saves++;
}
function learnBid(db: DB, l: Listing) {
  const st = ensureLearning(db), d = dayBucket(db), p = productBucket(db, l);
  queueCommerceEvent(db, { type: "bid_created", listingId: l.id, sellerSlug: l.sellerSlug, value: 1 });
  p.totalBids++; d.bids++; st.totals.bids++;
}
function learnOrder(db: DB, l: Listing, o: Order) {
  const st = ensureLearning(db), d = dayBucket(db), p = productBucket(db, l);
  queueCommerceEvent(db, { type: "order_created", listingId: l.id, sellerSlug: l.sellerSlug, userId: o.buyerId, value: o.itemPrice });
  p.avgSoldPrice = avgPush(p.avgSoldPrice, p.soldSamples, o.itemPrice);
  p.soldSamples++;
  p.totalOrders++;
  p.activeListings = Math.max(0, p.activeListings - 1);
  d.orders++; d.soldValue += o.itemPrice;
  st.totals.orders++; st.totals.soldValue += o.itemPrice;
}


/* ============ AI COMMERCE BRAIN (v8.5.7) ============
   Server-safe event queue: Outrun bewaart korte events capped en verwerkt ze
   direct tot aggregaten. Geen ruwe clickstream, geen foto's, geen grote bodies. */
const COMMERCE_EVENT_CAP = Math.max(100, Math.min(5000, Number(process.env.COMMERCE_EVENT_CAP) || 750));

function ensureCommerceBrain(db: DB) {
  const now = new Date().toISOString();
  db.commerceBrain ??= {
    version: 1,
    updatedAt: now,
    queue: [],
    processed: 0,
    dropped: 0,
    seo: { productPagesPrepared: 0, structuredDataReady: 0 },
  };
  db.commerceBrain.queue ??= [];
  db.commerceBrain.seo ??= { productPagesPrepared: 0, structuredDataReady: 0 };
  db.commerceBrain.updatedAt = now;
  return db.commerceBrain;
}

function queueCommerceEvent(db: DB, input: Omit<LearningEvent, "id" | "at">) {
  const brain = ensureCommerceBrain(db);
  const ev: LearningEvent = {
    id: crypto.randomUUID?.() ?? Math.random().toString(36).slice(2, 12),
    at: new Date().toISOString(),
    ...input,
  };
  brain.queue.push(ev);
  if (brain.queue.length > COMMERCE_EVENT_CAP) {
    const drop = brain.queue.length - COMMERCE_EVENT_CAP;
    brain.queue.splice(0, drop);
    brain.dropped += drop;
  }
  // Process compactly and immediately so the queue remains a safety buffer, not a growing log.
  processCommerceBrain(db, 40);
  return ev;
}

function processCommerceBrain(db: DB, max = 100) {
  const brain = ensureCommerceBrain(db);
  const batch = brain.queue.splice(0, Math.max(1, Math.min(max, brain.queue.length)));
  for (const ev of batch) {
    const l = ev.listingId ? db.listings.find(x => x.id === ev.listingId) : undefined;
    if (l && ev.type === "listing_seo") {
      brain.seo.productPagesPrepared++;
      brain.seo.structuredDataReady++;
      brain.seo.lastPreparedAt = ev.at;
    }
    brain.processed++;
  }
  brain.lastProcessedAt = batch.length ? new Date().toISOString() : brain.lastProcessedAt;
}

function listingSeoTitle(l: PublicListing) {
  return [l.brand, l.title].filter(Boolean).join(" ").replace(/\s+/g, " ").slice(0, 90);
}

export function buildListingStructuredData(l: PublicListing, seller?: Pick<PublicSeller, "name">) {
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    name: listingSeoTitle(l),
    brand: l.brand ? { "@type": "Brand", name: l.brand } : undefined,
    description: l.listingCopy?.shortDescription || l.listingCopy?.description || `${l.title}. ${l.condition || "Zakelijke outletdeal"}.`,
    image: l.photos?.map(src => src.startsWith("http") ? src : `https://outruniq.nl${src}`).slice(0, 5),
    category: l.category,
    sku: l.id,
    offers: {
      "@type": "Offer",
      priceCurrency: "EUR",
      price: l.price,
      availability: l.stock > 0 && (l.status === "published" || l.status === "active") ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      itemCondition: "https://schema.org/UsedCondition",
      seller: seller ? { "@type": "Organization", name: seller.name } : undefined,
      url: `https://outruniq.nl/listing/${l.id}`,
    },
  };
}

export function commerceAdviceForListing(l: Listing) {
  const tips: string[] = [];
  const discountPct = l.newPrice > 0 ? Math.round((1 - l.price / l.newPrice) * 100) : 0;
  if ((l.photos?.length ?? 0) < 3) tips.push("Voeg 2 extra foto's toe: voorkant, detail en eventuele schade.");
  if (!l.brand || !l.visionMetadata?.model) tips.push("Bevestig merk/model voor betere vindbaarheid en prijsdata.");
  if (discountPct < 15) tips.push("Korting lijkt laag; test een scherpere prijs of leg de conditie beter uit.");
  if ((l.confidence || 0) < 75) tips.push("AI-confidence is middelmatig: controleer titel, categorie en prijsadvies.");
  if (!tips.length) tips.push("Listing is publiceerbaar: goede prijs, voldoende data en SEO-velden staan klaar.");
  return { score: Math.max(45, Math.min(96, 58 + discountPct + (l.photos?.length ?? 0) * 4 + (l.brand ? 8 : 0) + (l.visionMetadata?.model ? 8 : 0))), tips: tips.slice(0, 3) };
}

export async function getCommerceBrainReport() {
  const db = await read();
  const brain = db.commerceBrain ?? { version: 1 as const, updatedAt: new Date().toISOString(), queue: [], processed: 0, dropped: 0, seo: { productPagesPrepared: 0, structuredDataReady: 0 } };
  const live = db.listings.filter(l => l.status === "published" || l.status === "active");
  const seoReady = live.filter(l => l.photos?.length && l.price > 0 && l.title && l.category).length;
  const withBrandModel = live.filter(l => l.brand && l.visionMetadata?.model).length;
  const advice = live.slice(0, 20).map(l => ({ id: l.id, title: l.title, ...commerceAdviceForListing(l) })).sort((a,b)=>a.score-b.score).slice(0,8);
  return {
    ...brain,
    caps: { queue: COMMERCE_EVENT_CAP },
    liveListings: live.length,
    seoReady,
    withBrandModel,
    advice,
  };
}

export async function getLearningReport() {
  const db = await read();
  const st = db.learning ?? { version: 1 as const, updatedAt: new Date().toISOString(), totals: { listingsLearned: 0, productKeys: 0, views: 0, saves: 0, bids: 0, orders: 0, soldValue: 0 }, products: [], daily: [] };
  const topProducts = [...(st.products ?? [])]
    .sort((a, b) => (b.totalOrders * 30 + b.totalBids * 8 + b.totalSaves * 4 + b.totalViews) - (a.totalOrders * 30 + a.totalBids * 8 + a.totalSaves * 4 + a.totalViews))
    .slice(0, 20);
  const fastMovers = [...(st.products ?? [])]
    .filter(p => p.soldSamples > 0)
    .sort((a, b) => b.soldSamples - a.soldSamples || b.totalViews - a.totalViews)
    .slice(0, 12);
  const last30 = [...(st.daily ?? [])].slice(-30);
  return { ...st, topProducts, fastMovers, last30, caps: { products: LEARNING_PRODUCT_CAP, daily: LEARNING_DAILY_CAP } };
}


function ensureOrderEscrowFunding(db: DB, o: Order) {
  appendLedger(db, {
    sellerSlug: o.sellerSlug,
    type: "order_escrow",
    debitAccount: customerFundsAccount,
    creditAccount: escrowAccount(o.id),
    amountCents: cents(o.totalPaid),
    entityType: "order",
    entityId: o.id,
    idempotencyKey: `order_escrow:${o.id}`,
    note: `Klantbetaling in escrow: ${o.itemTitle}`,
  });
}

function releaseOrderFunds(db: DB, o: Order, source = "order-flow") {
  const alreadyReleased = (db.walletLedger ?? []).some(e => e.idempotencyKey === `order_payout:${o.id}`);
  ensureOrderEscrowFunding(db, o);
  appendLedger(db, {
    sellerSlug: o.sellerSlug,
    type: "order_payout",
    debitAccount: escrowAccount(o.id),
    creditAccount: walletAccount(o.sellerSlug),
    amountCents: cents(o.sellerNet),
    entityType: "order",
    entityId: o.id,
    idempotencyKey: `order_payout:${o.id}`,
    note: `Netto uitbetaling ${o.itemTitle}`,
  });
  appendLedger(db, {
    sellerSlug: o.sellerSlug,
    type: "order_commission",
    debitAccount: escrowAccount(o.id),
    creditAccount: commissionRevenueAccount,
    amountCents: cents(o.commission),
    entityType: "order",
    entityId: o.id,
    idempotencyKey: `order_commission:${o.id}`,
    note: `Outrun commissie ${o.itemTitle}`,
  });
  if (cents(o.deliveryPrice) > 0) appendLedger(db, {
    sellerSlug: o.sellerSlug,
    type: "order_delivery",
    debitAccount: escrowAccount(o.id),
    creditAccount: deliveryRevenueAccount,
    amountCents: cents(o.deliveryPrice),
    entityType: "order",
    entityId: o.id,
    idempotencyKey: `order_delivery:${o.id}`,
    note: `Bezorgkosten ${o.itemTitle}`,
  });
  if (!alreadyReleased) audit(db, { actor: { type: "system", label: source }, action: "finance.release", entity: "order", entityId: o.id, summary: `${o.id}: escrow vrijgegeven naar wallet/commissie`, meta: { sellerSlug: o.sellerSlug, sellerNet: o.sellerNet, commission: o.commission, deliveryPrice: o.deliveryPrice } });
}

function refundOrderEscrow(db: DB, o: Order, reason = "Order geannuleerd") {
  ensureOrderEscrowFunding(db, o);
  appendLedger(db, {
    sellerSlug: o.sellerSlug,
    type: "order_refund",
    debitAccount: escrowAccount(o.id),
    creditAccount: customerFundsAccount,
    amountCents: cents(o.totalPaid),
    entityType: "order",
    entityId: o.id,
    idempotencyKey: `order_refund:${o.id}`,
    note: reason.slice(0, 180),
  });
}

function reconcileFinanceLedger(db: DB) {
  for (const o of db.orders) {
    ensureOrderEscrowFunding(db, o);
    if (o.status === "paid_out") releaseOrderFunds(db, o, "finance-reconcile");
    if (o.status === "cancelled") refundOrderEscrow(db, o, "Legacy/order annulering gereconcilieerd");
  }
}

function walletSummaryFromDb(db: DB, sellerSlug: string): WalletSummary {
  const wa = walletAccount(sellerSlug), ra = reserveAccount(sellerSlug);
  const entries = (db.walletLedger ?? []).filter(e => e.sellerSlug === sellerSlug);
  const lifetimeInCents = entries.filter(e => e.creditAccount === wa).reduce((s, e) => s + e.amountCents, 0);
  const lifetimeOutCents = entries.filter(e => e.debitAccount === wa).reduce((s, e) => s + e.amountCents, 0);
  return {
    sellerSlug,
    availableCents: accountBalanceCents(db, wa),
    reservedCents: accountBalanceCents(db, ra),
    lifetimeInCents,
    lifetimeOutCents,
  };
}

export async function getPartnerWallet(sellerSlug: string): Promise<{ summary: WalletSummary; ledger: WalletLedgerEntry[] }> {
  const db = await read();
  const summary = walletSummaryFromDb(db, sellerSlug);
  return { summary, ledger: (db.walletLedger ?? []).filter(e => e.sellerSlug === sellerSlug).sort((a, b) => b.at.localeCompare(a.at)).slice(0, 120) };
}

function reserveCampaignBudget(db: DB, sellerSlug: string, campaignId: string, amountCents: number): { ok: true } | { error: string } {
  const summary = walletSummaryFromDb(db, sellerSlug);
  if (summary.availableCents < amountCents) return { error: `Walletsaldo onvoldoende. Beschikbaar €${eurosFromCents(summary.availableCents).toLocaleString("nl-NL")}, nodig €${eurosFromCents(amountCents).toLocaleString("nl-NL")}.` };
  appendLedger(db, {
    sellerSlug,
    type: "campaign_reserve",
    debitAccount: walletAccount(sellerSlug),
    creditAccount: reserveAccount(sellerSlug),
    amountCents,
    entityType: "campaign",
    entityId: campaignId,
    idempotencyKey: `campaign_reserve:${campaignId}`,
    note: "Budget gereserveerd voor AI-campagne",
  });
  return { ok: true as const };
}

function settleCampaignStop(db: DB, c: PromotionCampaign, reason?: string) {
  const sellerSlug = c.sellerSlug;
  const reserved = Math.max(0, Math.round(c.reservedCents ?? 0));
  const spent = Math.min(reserved, Math.max(c.spentCents ?? cents(c.spent || 0), 0));
  const refund = Math.max(0, reserved - spent);
  if (spent > 0) {
    appendLedger(db, {
      sellerSlug, type: "campaign_spend", debitAccount: reserveAccount(sellerSlug), creditAccount: promoteRevenueAccount,
      amountCents: spent, entityType: "campaign", entityId: c.id, idempotencyKey: `campaign_spend:${c.id}`,
      note: "Verbruikt promotiebudget",
    });
  }
  if (refund > 0) {
    appendLedger(db, {
      sellerSlug, type: "campaign_refund", debitAccount: reserveAccount(sellerSlug), creditAccount: walletAccount(sellerSlug),
      amountCents: refund, entityType: "campaign", entityId: c.id, idempotencyKey: `campaign_refund:${c.id}`,
      note: "Ongebruikt campagnebudget terug naar wallet",
    });
  }
  c.status = "stopped";
  c.stoppedAt = new Date().toISOString();
  c.stopReason = (reason || "Gestopt door partner").slice(0, 140);
  c.refundedCents = refund;
  c.spentCents = spent;
  c.spent = eurosFromCents(spent);
  return { campaign: c, refundedCents: refund, spentCents: spent };
}

function pushNote(db: DB, userId: string, type: Notification["type"], title: string, body: string, href: string) {
  db.notifications.push({
    id: Math.random().toString(36).slice(2, 10), userId, type, title, body, href,
    read: false, at: new Date().toISOString(),
  });
  // Web Push naar alle apparaten van deze user (fire-and-forget; faalt stil zonder keys)
  sendWebPush(db.pushSubs.filter(x => x.userId === userId), { title, body, href });
}

export async function getNotifications(userId: string) {
  const db = await read();
  return db.notifications.filter(n => n.userId === userId)
    .sort((a, b) => b.at.localeCompare(a.at)).slice(0, 60);
}

export async function unreadCount(userId: string) {
  const db = await read();
  return db.notifications.filter(n => n.userId === userId && !n.read).length;
}

export async function markNotificationsRead(userId: string) {
  return mutate(db => { db.notifications.forEach(n => { if (n.userId === userId) n.read = true; }); });
}

export async function getSaved(userId: string): Promise<{ item: SavedItem; listing: Listing }[]> {
  const db = await read();
  return db.saved.filter(s => s.userId === userId)
    .map(item => ({ item, listing: db.listings.find(l => l.id === item.listingId)! }))
    .filter(x => x.listing);
}

export async function toggleSaved(userId: string, listingId: string): Promise<boolean> {
  return mutate(db => {
    const i = db.saved.findIndex(s => s.userId === userId && s.listingId === listingId);
    if (i >= 0) { db.saved.splice(i, 1); return false; }
    const l = db.listings.find(x => x.id === listingId);
    db.saved.push({ userId, listingId, savedAtPrice: l?.price ?? 0, at: new Date().toISOString() });
    if (l) learnSave(db, l);
    return true;
  });
}

export async function getActiveListings(): Promise<Listing[]> {
  const db = await read();
  return db.listings
    .filter(l => (l.status === "published" || l.status === "active") && l.stock > 0)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

/** Normaliseer voor zoeken: lowercase, diacrieten weg, alleen alfanumeriek+spatie. */
function normalizeSearch(s: string): string {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
/** Levenshtein met vroege afbreek (voor korte zoekwoorden — typo-tolerantie). */
function editDistance(a: string, b: string, max: number): number {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  const prev = new Array(b.length + 1);
  const cur = new Array(b.length + 1);
  for (let j = 0; j <= b.length; j++) prev[j] = j;
  for (let i = 1; i <= a.length; i++) {
    cur[0] = i; let rowMin = cur[0];
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      rowMin = Math.min(rowMin, cur[j]);
    }
    if (rowMin > max) return max + 1;
    for (let j = 0; j <= b.length; j++) prev[j] = cur[j];
  }
  return prev[b.length];
}
/** Fuzzy zoeken: exacte substring wint, maar typefouten ("wasmachien",
 *  "samsklung") vinden alsnog resultaten via token-gebaseerde edit-distance. */
export async function searchListings(q: string): Promise<Listing[]> {
  const all = await getActiveListings();
  if (!q || !q.trim()) return all;
  const nq = normalizeSearch(q);
  if (!nq) return all;
  const queryTokens = nq.split(" ").filter(Boolean);

  const scored = all.map((l) => {
    const hay = normalizeSearch([l.title, l.brand, l.condition, l.category, l.sellerSlug].filter(Boolean).join(" "));
    const hayTokens = hay.split(" ").filter(Boolean);
    let score = 0;
    if (hay.includes(nq)) score += 1000;                       // volledige substring = sterkste
    for (const qt of queryTokens) {
      if (qt.length < 2) continue;
      if (hayTokens.includes(qt)) { score += 100; continue; }  // exacte token-match
      if (hay.includes(qt)) { score += 60; continue; }         // deel-substring
      // typo-tolerantie: beste fuzzy match tegen elk hooitoken
      const tol = qt.length <= 4 ? 1 : qt.length <= 7 ? 2 : 3;
      let best = tol + 1;
      for (const ht of hayTokens) {
        if (Math.abs(ht.length - qt.length) > tol) continue;
        const d = editDistance(qt, ht, tol);
        if (d < best) best = d;
        if (best === 1) break;
      }
      if (best <= tol) score += Math.max(20, 55 - best * 15);  // dichter = hoger
    }
    return { l, score };
  }).filter((x) => x.score > 0);

  scored.sort((a, b) => b.score - a.score);
  return scored.map((x) => x.l);
}

export async function getListing(id: string): Promise<Listing | undefined> {
  const db = await read();
  return db.listings.find(l => l.id === id);
}

export async function getPublicListing(id: string): Promise<PublicListing | undefined> {
  const db = await read();
  const l = db.listings.find(item => item.id === id);
  return l && isListingPublished(l) ? toPublicListing(l) : undefined;
}

export type PublicListingContext = {
  listing: PublicListing;
  seller?: PublicSeller;
  rating: { avg: number; count: number } | null;
  myBid: { id: string; amount: number; counterAmount?: number; status: string } | null;
  savedOn: boolean;
};

/** Eén buyer-veilige databasequery voor detail/modal; voorkomt losse reads en interne props. */
export async function getPublicListingContext(id: string, buyerId?: string): Promise<PublicListingContext | undefined> {
  const db = await read();
  const internal = db.listings.find(item => item.id === id);
  if (!internal || !isListingPublished(internal)) return undefined;
  const seller = db.sellers.find(item => item.slug === internal.sellerSlug);
  const reviews = db.reviews.filter(item => item.sellerSlug === internal.sellerSlug);
  const rating = ratingOf(reviews);
  const bid = buyerId ? db.bids.find(item => item.listingId === id && item.buyerId === buyerId) : undefined;
  const savedOn = !!buyerId && db.saved.some(item => item.userId === buyerId && item.listingId === id);
  return {
    listing: toPublicListing(internal),
    seller: seller ? toPublicSeller(seller) : undefined,
    rating,
    myBid: bid ? { id: bid.id, amount: bid.amount, counterAmount: bid.counterAmount, status: bid.status } : null,
    savedOn,
  };
}

export async function getSeller(slug: string): Promise<Seller | undefined> {
  const db = await read();
  return db.sellers.find(s => s.slug === slug);
}

export async function getSellerStats(slug: string) {
  const db = await read();
  const listings = db.listings.filter(l => l.sellerSlug === slug);
  const orders = db.orders.filter(o => o.sellerSlug === slug);
  const paidOut = orders.filter(o => o.status === "paid_out");
  const inEscrow = orders.filter(o => !["paid_out", "cancelled"].includes(o.status));
  const d30 = Date.now() - 30 * 864e5;
  const rev30 = paidOut.filter(o => +new Date(o.createdAt) > d30)
    .reduce((s, o) => s + o.sellerNet, 0);
  const daily = Array.from({ length: 30 }, (_, i) => {
    const day = new Date(Date.now() - (29 - i) * 864e5).toISOString().slice(0, 10);
    return paidOut.filter(o => o.createdAt.slice(0, 10) === day)
      .reduce((s, o) => s + o.sellerNet, 0);
  });
  const sold = db.listings.filter(l => l.sellerSlug === slug && l.status === "sold").length;
  return {
    listings, orders,
    activeCount: listings.filter(l => l.status === "published" || l.status === "active").length,
    rev30,
    inEscrowSum: inEscrow.reduce((s, o) => s + o.sellerNet, 0),
    paidOut30: rev30,
    commission30: paidOut.filter(o => +new Date(o.createdAt) > d30).reduce((s, o) => s + o.commission, 0),
    sellThrough: listings.length ? Math.round((sold / listings.length) * 1000) / 10 : 0,
    daily,
  };
}


export function isListingPublished(l: Pick<Listing, "status" | "stock">) {
  return (l.status === "published" || l.status === "active") && l.stock > 0;
}


export function publicListing(l: Listing): PublicListing {
  return toPublicListing(l);
}

export function publicListings(items: Listing[]): PublicListing[] {
  return toPublicListings(items);
}

export function getListingReviewChecklist(l: Listing) {
  return {
    title: Boolean(l.title?.trim()),
    price: Boolean(l.price > 0 && l.newPrice > 0 && l.price < l.newPrice),
    category: Boolean(l.category),
    photo: Boolean((l.photos || []).length >= 1),
    modelConfirmed: Boolean(l.confirmations?.identity),
    pricingConfirmed: Boolean(l.confirmations?.pricing),
    conditionConfirmed: Boolean(l.confirmations?.condition),
    publicationConfirmed: Boolean(l.confirmations?.publication),
    description: Boolean(l.listingCopy?.description || l.listingCopy?.shortDescription),
    seo: Boolean(l.seo?.title && l.seo?.metaDescription),
    updatedAt: new Date().toISOString(),
  };
}

export function reviewChecklistReady(c: ReturnType<typeof getListingReviewChecklist>) {
  return c.title && c.price && c.category && c.photo && c.modelConfirmed && c.pricingConfirmed && c.conditionConfirmed && c.publicationConfirmed && c.description && c.seo;
}

/** Eén test-seller-profiel voor de gate-fase; wordt aangemaakt/bijgewerkt in de nieuw-flow. */
export async function upsertSeller(input: { name: string; city: string; kvk?: string }): Promise<Seller> {
  return mutate(db => {
    const slug = slugify(input.name);
    let s = db.sellers.find(x => x.slug === slug);
    if (!s) {
      s = { slug, name: input.name, city: input.city, kvk: input.kvk, createdAt: new Date().toISOString() };
      db.sellers.push(s);
    } else { s.city = input.city; if (input.kvk) s.kvk = input.kvk; }
    return s;
  });
}

export async function createListing(l: Omit<Listing, "id" | "createdAt" | "views" | "status" | "reviewChecklist">): Promise<Listing> {
  return mutate(db => {
    let id = slugify(l.title) || "listing";
    while (db.listings.some(x => x.id === id)) id += "-" + Math.random().toString(36).slice(2, 5);
    const taxonomy = inferTaxonomy(l.title, l.category);
    const base: Listing = { ...l, id, taxonomyGroupId: l.taxonomyGroupId || taxonomy.groupId, subcategoryId: l.subcategoryId || taxonomy.subcategoryId, taxonomyVersion: 2, status: "needs_review", views: 0, createdAt: new Date().toISOString() };
    const checklist = getListingReviewChecklist(base);
    const rec: Listing = { ...base, reviewChecklist: checklist, status: reviewChecklistReady(checklist) ? "published" : "needs_review" };
    db.listings.push(rec);
    db.mediaAssets ??= [];
    for (const asset of db.mediaAssets) {
      if (rec.photos.includes(asset.url) && asset.ownerSellerSlug === rec.sellerSlug) {
        asset.visibility = rec.status === "published" || rec.status === "active" ? "public" : "private";
        asset.listingId = rec.id;
        asset.publishedAt = asset.visibility === "public" ? new Date().toISOString() : undefined;
      }
      if ((rec.internalPhotos || []).includes(asset.url) && asset.ownerSellerSlug === rec.sellerSlug) { asset.visibility = "private"; asset.listingId = rec.id; }
    }
    learnListingPublished(db, rec);
    audit(db, { actor: { type: "partner", label: rec.sellerSlug }, action: "listing.create", entity: "listing", entityId: rec.id, summary: `${rec.title} aangemaakt (${rec.status})`, meta: { sellerSlug: rec.sellerSlug, price: rec.price, stock: rec.stock } });
    return rec;
  });
}

export async function setListingStatus(id: string, status: Listing["status"]) {
  return mutate(db => {
    const l = db.listings.find(x => x.id === id);
    if (l) {
      const from = l.status;
      l.status = status;
      audit(db, { actor: { type: "partner", label: l.sellerSlug }, action: "listing.status", entity: "listing", entityId: id, summary: `${l.title}: ${from} → ${status}`, meta: { from, to: status, sellerSlug: l.sellerSlug } });
    }
    return l;
  });
}

type ViewBufferGlobal = typeof globalThis & { __oiqListingViews?: Map<string, number> };
const viewGlobal = globalThis as ViewBufferGlobal;

/** Views worden in-memory gebufferd en door de onderhoudsjob in één DB-write verwerkt. */
export function bumpViews(id: string) {
  viewGlobal.__oiqListingViews ??= new Map<string, number>();
  viewGlobal.__oiqListingViews.set(id, (viewGlobal.__oiqListingViews.get(id) ?? 0) + 1);
}

export async function flushBufferedViews() {
  const buffer = viewGlobal.__oiqListingViews;
  if (!buffer?.size) return 0;
  const snapshot = new Map(buffer);
  buffer.clear();
  try {
    return await mutate(db => {
      let total = 0;
      for (const [id, count] of snapshot) {
        const l = db.listings.find(x => x.id === id);
        if (!l) continue;
        l.views += count;
        for (let i = 0; i < Math.min(count, 100); i++) learnView(db, l);
        total += count;
      }
      return total;
    });
  } catch (error) {
    for (const [id, count] of snapshot) buffer.set(id, (buffer.get(id) ?? 0) + count);
    throw error;
  }
}

export async function createOrder(buyerId: string, listingId: string, deliveryChoice: "bezorgen" | "ophalen", address?: Address, bidId?: string, clientRequestId?: string): Promise<Order | { error: string }> {
  return mutate(db => {
    const requestKey = String(clientRequestId ?? "").trim().slice(0, 100);
    if (requestKey) {
      const existing = db.orders.find(order => order.buyerId === buyerId && order.clientRequestId === requestKey);
      if (existing) return existing;
    }
    const l = db.listings.find(x => x.id === listingId);
    if (!l || (l.status !== "published" && l.status !== "active") || l.stock < 1) return { error: "Listing niet beschikbaar" };
    const self = db.users.find(x => x.id === buyerId);
    if (!self || self.role !== "consument" || self.partnerProfile) {
      return { error: "Kopen kan alleen met een persoonlijk kopersaccount" };
    }
    if (self.partnerSlug === l.sellerSlug) return { error: "Je kunt je eigen listing niet kopen" };
    let itemPrice = l.price;
    if (bidId) {
      const bid = db.bids.find(b => b.id === bidId);
      if (!bid || bid.buyerId !== buyerId || bid.listingId !== l.id || bid.status !== "accepted") {
        return { error: "Dit bod is niet (meer) geldig" };
      }
      itemPrice = bid.amount;
      bid.status = "used";
    }
    const deliveryPrice = deliveryChoice === "bezorgen" ? l.deliveryPrice : 0;
    const itemPriceCents = cents(itemPrice);
    const deliveryPriceCents = cents(deliveryPrice);
    const commissionCents = Math.round(itemPriceCents * COMMISSION);
    const commission = eurosFromCents(commissionCents);
    db.counters.order++;
    const id = `OIQ-${new Date().getFullYear()}-${String(db.counters.order).padStart(4, "0")}`;
    const now = new Date().toISOString();
    const o: Order = {
      id, buyerId, listingId, sellerSlug: l.sellerSlug, itemTitle: l.title,
      partnerRef: l.partnerRef,
      deliveryAddress: deliveryChoice === "bezorgen" ? address : undefined,
      pickupCode: deliveryChoice === "ophalen"
        ? Array.from({ length: 6 }, () => { const alphabet = "ACDEFHJKLMNPRTVWXY23456789"; return alphabet[crypto.randomInt(alphabet.length)]; }).join("")
        : undefined,
      itemPrice, deliveryChoice, deliveryPrice, bidId, clientRequestId: requestKey || undefined,
      totalPaid: eurosFromCents(itemPriceCents + deliveryPriceCents), commission, sellerNet: eurosFromCents(itemPriceCents - commissionCents),
      status: "paid",
      events: [{ status: "paid", at: now, note: "Testmodus — geen echte betaling. Geld zou nu in escrow staan." }],
      createdAt: now,
    };
    db.orders.push(o);
    ensureOrderEscrowFunding(db, o);
    learnOrder(db, l, o);
    l.stock--; if (l.stock === 0) l.status = "sold";
    const partner = db.users.find(u => u.partnerSlug === l.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Nieuwe order", `${l.title} · ${id}`, "/partner/orders");
    audit(db, { actor: self, action: "order.create", entity: "order", entityId: id, summary: `${l.title} gekocht voor €${o.totalPaid}`, meta: { listingId, sellerSlug: l.sellerSlug, itemPrice, deliveryPrice, bidId: bidId ?? null } });
    return o;
  });
}

export async function getOrder(id: string): Promise<Order | undefined> {
  const db = await read();
  return db.orders.find(o => o.id === id);
}

export async function disputeOrder(id: string, buyerId: string, category: string, text: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === id);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    if (["paid_out", "cancelled", "disputed"].includes(o.status)) return { error: "Deze order kan niet (meer) betwist worden" };
    o.dispute = { category, text, at: new Date().toISOString() };
    o.status = "disputed";
    o.events.push({ status: "disputed", at: new Date().toISOString(), note: `${category}: ${text.slice(0, 80)}` });
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Probleem gemeld op order", `${o.itemTitle} · ${o.id} · ${category}`, "/partner/orders");
    pushNote(db, o.buyerId, "order", "Je melding is ontvangen", `${o.id} is bevroren; uitbetaling geblokkeerd tot afhandeling.`, `/order/${o.id}`);
    audit(db, { actor: db.users.find(u => u.id === buyerId), action: "dispute.open", entity: "dispute", entityId: o.id, summary: `${category}: ${text.slice(0, 120)}`, meta: { orderId: o.id, sellerSlug: o.sellerSlug } });
    return { ok: true };
  });
}

/** Beheer: dispute afhandelen. release = alsnog uitbetalen; cancel = annuleren + voorraad terug. */
export async function resolveDispute(id: string, action: "release" | "cancel") {
  return mutate(db => {
    const o = db.orders.find(x => x.id === id);
    if (!o || o.status !== "disputed") return { error: "Geen openstaande dispute" };
    const now = new Date().toISOString();
    if (action === "cancel") {
      o.status = "cancelled";
      o.events.push({ status: "cancelled", at: now, note: "Geannuleerd na dispute (beheer)." });
      const l = db.listings.find(x => x.id === o.listingId);
      if (l) { l.stock++; if (l.status === "sold") l.status = "active"; }
      refundOrderEscrow(db, o, "Dispute toegewezen: bedrag terug naar koper");
      pushNote(db, o.buyerId, "order", "Order geannuleerd", `${o.id} — je melding is afgehandeld.`, `/order/${o.id}`);
    } else {
      o.status = "paid_out";
      o.events.push({ status: "paid_out", at: now, note: "Dispute afgewezen — uitbetaling vrijgegeven (beheer)." });
      releaseOrderFunds(db, o, "dispute-release");
      pushNote(db, o.buyerId, "order", "Melding afgehandeld", `${o.id} — de uitbetaling is vrijgegeven.`, `/order/${o.id}`);
    }
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, action === "cancel" ? "order" : "payout",
      action === "cancel" ? "Order geannuleerd na dispute" : "Uitbetaling vrijgegeven na dispute",
      `${o.itemTitle} · ${o.id}`, "/partner/orders");
    audit(db, { actor: { type: "admin", label: "beheer" }, action: `dispute.${action}`, entity: "dispute", entityId: o.id, summary: action === "cancel" ? `Dispute toegewezen: ${o.id} geannuleerd` : `Dispute afgewezen: ${o.id} uitbetaald`, meta: { orderId: o.id, sellerSlug: o.sellerSlug } });
    return { ok: true };
  });
}

export function paidOutAt(o: Order): string | undefined {
  return o.events.find(e => e.status === "paid_out")?.at;
}

export async function requestReturn(orderId: string, buyerId: string, reason: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    if (!["delivered", "paid_out"].includes(o.status)) {
      return { error: "Retour kan vanaf het moment van levering" };
    }
    if (o.returnRequest) return { error: "Er loopt al een retouraanvraag" };
    if (o.status === "paid_out") {
      const paidAt = paidOutAt(o);
      if (!paidAt || Date.now() - +new Date(paidAt) > RETURN_WINDOW_DAYS * 864e5) {
        return { error: `De retourtermijn van ${RETURN_WINDOW_DAYS} dagen is verstreken` };
      }
    }
    const now = new Date();
    o.returnRequest = {
      reason, at: now.toISOString(),
      deadlineAt: new Date(+now + RETURN_RESPONSE_DAYS * 864e5).toISOString(),
      status: "requested",
    };
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Retouraanvraag ontvangen",
      `${o.itemTitle} · ${o.id} — reageer binnen ${RETURN_RESPONSE_DAYS} dagen met instructies.`, "/partner/orders");
    pushNote(db, buyerId, "order", "Retouraanvraag verstuurd",
      `${o.id} — de partner reageert binnen ${RETURN_RESPONSE_DAYS} dagen met instructies.${o.status !== "paid_out" ? " De uitbetaling is gepauzeerd zolang je aanvraag loopt." : ""}`, `/order/${o.id}`);
    audit(db, { actor: db.users.find(u => u.id === buyerId), action: "return.request", entity: "return", entityId: o.id, summary: `${o.id}: ${reason.slice(0, 120)}`, meta: { status: o.status, sellerSlug: o.sellerSlug } });
    return { ok: true };
  });
}

export async function respondReturn(orderId: string, partnerSlug: string, instructions: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.sellerSlug !== partnerSlug) return { error: "Niet jouw order" };
    if (!o.returnRequest || !["requested", "escalated"].includes(o.returnRequest.status)) {
      return { error: "Geen openstaande retouraanvraag" };
    }
    o.returnRequest.status = "responded";
    o.returnRequest.instructions = instructions;
    o.returnRequest.respondedAt = new Date().toISOString();
    pushNote(db, o.buyerId, "order", "Retourinstructies ontvangen", `${o.id} — bekijk hoe je kunt retourneren.`, `/order/${o.id}`);
    audit(db, { actor: { type: "partner", label: partnerSlug }, action: "return.respond", entity: "return", entityId: o.id, summary: `${o.id}: partner gaf retourinstructies`, meta: { sellerSlug: partnerSlug } });
    return { ok: true };
  });
}

export async function completeReturn(orderId: string, partnerSlug: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.sellerSlug !== partnerSlug) return { error: "Niet jouw order" };
    if (o.returnRequest?.status !== "responded") return { error: "Retour is nog niet in behandeling" };
    o.returnRequest.status = "completed";
    o.returnRequest.completedAt = new Date().toISOString();
    if (o.status !== "paid_out") {
      // geld stond nog vast: terugstorten uit escrow, order annuleren, voorraad terug
      o.status = "cancelled";
      o.events.push({ status: "cancelled", at: new Date().toISOString(), note: "Retour afgerond vóór uitbetaling — bedrag (testmodus) uit escrow terugbetaald aan koper." });
      const l = db.listings.find(x => x.id === o.listingId);
      if (l) { l.stock++; if (l.status === "sold") l.status = "active"; }
      refundOrderEscrow(db, o, "Retour afgerond vóór uitbetaling");
      pushNote(db, o.buyerId, "order", "Retour afgerond — geld terug",
        `${o.id} — het bedrag is (testmodus) uit escrow aan je terugbetaald.`, `/order/${o.id}`);
    } else {
      pushNote(db, o.buyerId, "order", "Retour afgerond",
        `${o.id} — de partner bevestigde ontvangst; terugbetaling volgt conform de Retourvoorwaarden (testmodus: gesimuleerd).`, `/order/${o.id}`);
    }
    audit(db, { actor: { type: "partner", label: partnerSlug }, action: "return.complete", entity: "return", entityId: o.id, summary: `${o.id}: retour afgerond`, meta: { finalOrderStatus: o.status, sellerSlug: partnerSlug } });
    return { ok: true };
  });
}

/** Klant escaleert naar Outrun IQ — kan pas ná de reactietermijn zonder partnerreactie. */
export async function escalateReturn(orderId: string, buyerId: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    const r = o.returnRequest;
    if (!r || r.status !== "requested") return { error: "Escaleren kan alleen bij een onbeantwoorde aanvraag" };
    if (Date.now() < +new Date(r.deadlineAt)) return { error: "De partner heeft nog tijd om te reageren" };
    r.status = "escalated";
    pushNote(db, buyerId, "order", "Geëscaleerd naar Outrun IQ", `${o.id} — wij nemen het over en spreken de partner aan.`, `/order/${o.id}`);
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "systeem", "Retour geëscaleerd — actie vereist",
      `${o.id}: geen reactie binnen de termijn. Dit telt mee voor je partnerstatus.`, "/partner/orders");
    audit(db, { actor: db.users.find(u => u.id === buyerId), action: "return.escalate", entity: "return", entityId: o.id, summary: `${o.id}: retour geëscaleerd naar beheer`, meta: { sellerSlug: o.sellerSlug } });
    return { ok: true };
  });
}

/** Waterdichte autorelease: 'delivered' + RELEASE_DAYS zonder bevestiging/dispute -> paid_out.
 *  Lazy sweep (geen cron): aanroepen op order-lezende pagina's; schrijft alleen bij echte releases. */
export async function sweepOrders() {
  await sweepCampaigns();
  await mutate(db => { reconcileFinanceLedger(db); return true; });
  const db = await read();
  const due = db.orders.filter(o => {
    if (o.status !== "delivered") return false;
    if (o.returnRequest && o.returnRequest.status !== "completed") return false;  // open retour = escrow bevroren
    const trusted = db.sellers.find(x => x.slug === o.sellerSlug)?.trusted;
    const cutoff = Date.now() - releaseDaysFor(trusted) * 864e5;
    return +new Date(o.events.find(e => e.status === "delivered")?.at ?? o.createdAt) < cutoff;
  });
  if (due.length === 0) return 0;
  return mutate(d => {
    let n = 0;
    for (const ref of due) {
      const o = d.orders.find(x => x.id === ref.id);
      if (!o || o.status !== "delivered" || (o.returnRequest && o.returnRequest.status !== "completed")) continue;
      o.status = "paid_out";
      const now = new Date().toISOString();
      o.events.push({ status: "delivered_buyer_confirmed", at: now, note: `Automatisch: ${releaseDaysFor(d.sellers.find(x => x.slug === o.sellerSlug)?.trusted)} dagen zonder melding.` });
      o.events.push({ status: "paid_out", at: now, note: "Automatische uitbetaling na bevestigingstermijn." });
      pushNote(d, o.buyerId, "order", "Order automatisch afgerond", `${o.id} — geen melding binnen ${releaseDaysFor(d.sellers.find(x => x.slug === o.sellerSlug)?.trusted)} dagen.`, `/order/${o.id}`);
      const partner = d.users.find(u => u.partnerSlug === o.sellerSlug);
      if (partner) pushNote(d, partner.id, "payout", "Uitbetaling vrijgegeven", `${o.itemTitle} · netto €${o.sellerNet}`, "/partner/geld");
      releaseOrderFunds(d, o, "sweepOrders");
      audit(d, { actor: { type: "system", label: "sweepOrders" }, action: "order.autorelease", entity: "order", entityId: o.id, summary: `${o.id}: automatisch uitbetaald na escrowtermijn`, meta: { sellerSlug: o.sellerSlug, sellerNet: o.sellerNet } });
      n++;
    }
    return n;
  });
}

const FLOW: OrderStatus[] = ["paid", "confirmed", "delivery_planned", "delivered", "delivered_buyer_confirmed", "paid_out"];
export const RELEASE_DAYS = Math.max(1, Number(process.env.ESCROW_RELEASE_DAYS) || 7);          // bewezen partners
export const RELEASE_DAYS_NEW = Math.max(RELEASE_DAYS, Number(process.env.ESCROW_RELEASE_DAYS_NEW) || 14); // nieuwe partners
export const releaseDaysFor = (trusted?: boolean) => (trusted ? RELEASE_DAYS : RELEASE_DAYS_NEW);
export const RETURN_WINDOW_DAYS = Math.max(1, Number(process.env.RETURN_WINDOW_DAYS) || 14);
export const RETURN_RESPONSE_DAYS = Math.max(1, Number(process.env.RETURN_RESPONSE_DAYS) || 3);

export async function advanceOrder(id: string, to: OrderStatus, note?: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === id);
    if (!o) return { error: "Order niet gevonden" };
    if (o.status === "disputed") return { error: "Order is bevroren wegens een gemeld probleem" };
    const from = FLOW.indexOf(o.status), toI = FLOW.indexOf(to);
    if (toI !== from + 1) return { error: `Ongeldige overgang ${o.status} → ${to}` };
    o.status = to;
    o.events.push({ status: to, at: new Date().toISOString(), note });
    audit(db, { actor: { type: "system", label: "order-flow" }, action: "order.advance", entity: "order", entityId: o.id, summary: `${o.id}: ${FLOW[from]} → ${to}`, meta: { from: FLOW[from], to, sellerSlug: o.sellerSlug } });
    const labels: Record<string, string> = {
      confirmed: "Partner heeft je bestelling bevestigd",
      delivery_planned: "Levering wordt gepland",
      delivered: "Gemarkeerd als geleverd — bevestig ontvangst of meld een probleem binnen de bevestigingstermijn",
    };
    if (labels[to]) pushNote(db, o.buyerId, "order", labels[to], `${o.itemTitle} · ${o.id}`, `/order/${o.id}`);
    if (to === "delivered_buyer_confirmed") {
      o.status = "paid_out";
      o.events.push({ status: "paid_out", at: new Date().toISOString(), note: "Automatische uitbetaling (testmodus)." });
      const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
      if (partner) pushNote(db, partner.id, "payout", "Uitbetaling vrijgegeven", `${o.itemTitle} · netto €${o.sellerNet}`, "/partner/geld");
      releaseOrderFunds(db, o, "buyer-confirm");
      audit(db, { actor: { type: "system", label: "buyer-confirm" }, action: "order.paid_out", entity: "order", entityId: o.id, summary: `${o.id}: uitbetaling vrijgegeven`, meta: { sellerSlug: o.sellerSlug, sellerNet: o.sellerNet } });
    }
    return o;
  });
}

/* ============ BIEDEN (v6.7) ============ */
const MASK_PATTERNS = [
  /[\w.+-]+@[\w-]+\.[\w.]+/gi,
  /(?:\+31|0031|0)\s?6[\s-]?\d{2}[\s-]?\d{2}[\s-]?\d{2}[\s-]?\d{2}/g,
  /\b\d{10,}\b/g,
  /https?:\/\/\S+|www\.\S+/gi,
  /\b(whatsapp|whats app|telegram|signal)\b/gi,
];
/** Anti-omzeiling: contactgegevens in vrije tekst afschermen. */
export function maskContact(t: string) {
  let out = t;
  for (const rx of MASK_PATTERNS) out = out.replace(rx, "[afgeschermd]");
  return out;
}

export async function placeBid(buyerId: string, listingId: string, amount: number, message?: string) {
  return mutate(db => {
    const l = db.listings.find(x => x.id === listingId);
    if (!l || (l.status !== "published" && l.status !== "active") || l.stock < 1) return { error: "Listing niet beschikbaar" };
    const me = db.users.find(x => x.id === buyerId);
    if (!me || me.role !== "consument" || me.partnerProfile) {
      return { error: "Bieden kan alleen met een persoonlijk kopersaccount" };
    }
    if (me.partnerSlug === l.sellerSlug) return { error: "Je kunt niet op je eigen listing bieden" };
    if (!(amount > 0 && amount < l.price)) return { error: "Een bod ligt boven \u20ac0 en onder de vraagprijs" };
    if (db.bids.some(b => b.buyerId === buyerId && b.listingId === listingId && ["open", "countered", "accepted"].includes(b.status))) {
      return { error: "Je hebt al een lopend bod op deze listing" };
    }
    const bid: Bid = {
      id: Math.random().toString(36).slice(2, 10),
      listingId, buyerId, sellerSlug: l.sellerSlug,
      amount: Math.round(amount),
      message: message ? maskContact(message).slice(0, 200) : undefined,
      status: "open", at: new Date().toISOString(),
    };
    db.bids.push(bid);
    learnBid(db, l);
    const partner = db.users.find(u => u.partnerSlug === l.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Nieuw bod ontvangen",
      `\u20ac${bid.amount} op ${l.title} (vraagprijs \u20ac${l.price})`, "/partner/orders");
    audit(db, { actor: me, action: "bid.place", entity: "bid", entityId: bid.id, summary: `€${bid.amount} op ${l.title}`, meta: { listingId, sellerSlug: l.sellerSlug } });
    return { ok: true };
  });
}

export async function respondBid(partnerSlug: string, bidId: string, action: "accept" | "reject" | "counter", counterAmount?: number) {
  return mutate(db => {
    const b = db.bids.find(x => x.id === bidId);
    if (!b || b.sellerSlug !== partnerSlug) return { error: "Niet jouw bod" };
    if (!["open", "countered"].includes(b.status)) return { error: "Dit bod is al afgehandeld" };
    const l = db.listings.find(x => x.id === b.listingId);
    b.respondedAt = new Date().toISOString();
    if (action === "accept") {
      b.status = "accepted";
      pushNote(db, b.buyerId, "order", "Je bod is geaccepteerd",
        `\u20ac${b.amount} voor ${l?.title ?? "het product"} \u2014 rond je aankoop af via de listing.`, `/listing/${b.listingId}`);
    } else if (action === "reject") {
      b.status = "rejected";
      pushNote(db, b.buyerId, "order", "Je bod is afgewezen", `\u20ac${b.amount} op ${l?.title ?? "het product"}`, `/listing/${b.listingId}`);
    } else {
      if (!(counterAmount && counterAmount > b.amount && l && counterAmount < l.price)) {
        return { error: "Tegenbod moet tussen het bod en de vraagprijs liggen" };
      }
      b.status = "countered";
      b.counterAmount = Math.round(counterAmount);
      pushNote(db, b.buyerId, "order", "Tegenbod ontvangen",
        `Partner stelt \u20ac${b.counterAmount} voor op ${l?.title ?? "het product"}.`, `/listing/${b.listingId}`);
    }
    audit(db, { actor: { type: "partner", label: partnerSlug }, action: `bid.${action}`, entity: "bid", entityId: b.id, summary: `${action} op bod €${b.amount}`, meta: { listingId: b.listingId, buyerId: b.buyerId, counterAmount: b.counterAmount ?? null } });
    return { ok: true };
  });
}

export async function buyerBidAction(buyerId: string, bidId: string, action: "accept-counter" | "withdraw") {
  return mutate(db => {
    const b = db.bids.find(x => x.id === bidId);
    if (!b || b.buyerId !== buyerId) return { error: "Niet jouw bod" };
    if (action === "withdraw") {
      if (!["open", "countered", "accepted"].includes(b.status)) return { error: "Bod is al afgehandeld" };
      b.status = "withdrawn";
      audit(db, { actor: db.users.find(u => u.id === buyerId), action: "bid.withdraw", entity: "bid", entityId: b.id, summary: `Bod ingetrokken`, meta: { listingId: b.listingId, sellerSlug: b.sellerSlug } });
      return { ok: true };
    }
    if (b.status !== "countered" || !b.counterAmount) return { error: "Er ligt geen tegenbod" };
    b.amount = b.counterAmount;
    b.status = "accepted";
    const partner = db.users.find(u => u.partnerSlug === b.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Tegenbod geaccepteerd",
      `Koper gaat akkoord met \u20ac${b.amount}.`, "/partner/orders");
    pushNote(db, buyerId, "order", "Deal! Rond je aankoop af",
      `\u20ac${b.amount} \u2014 reken af via de listing.`, `/listing/${b.listingId}`);
    audit(db, { actor: db.users.find(u => u.id === buyerId), action: "bid.accept_counter", entity: "bid", entityId: b.id, summary: `Tegenbod geaccepteerd: €${b.amount}`, meta: { listingId: b.listingId, sellerSlug: b.sellerSlug } });
    return { ok: true };
  });
}

export async function getMyBid(listingId: string, buyerId: string) {
  const db = await read();
  return db.bids.find(b => b.listingId === listingId && b.buyerId === buyerId
    && ["open", "countered", "accepted"].includes(b.status)) ?? null;
}

/* ============ BEZORGMOMENT (v6.7) ============ */
export async function proposeSlots(partnerSlug: string, orderId: string, slots: string[]) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.sellerSlug !== partnerSlug) return { error: "Niet jouw order" };
    if (o.status !== "confirmed") return { error: "Momenten voorstellen kan na je bevestiging" };
    const valid = slots.map(x => new Date(x)).filter(d => !isNaN(+d) && +d > Date.now()).slice(0, 3);
    if (valid.length === 0) return { error: "Geef minimaal \u00e9\u00e9n moment in de toekomst" };
    o.deliverySlots = valid.map(d => ({ at: d.toISOString() }));
    o.status = "delivery_planned";
    o.events.push({ status: "delivery_planned", at: new Date().toISOString(), note: `${valid.length} moment(en) voorgesteld` });
    pushNote(db, o.buyerId, "order", "Kies je bezorgmoment",
      `De partner stelt ${valid.length} moment(en) voor \u2014 kies wat jou uitkomt.`, `/order/${o.id}`);
    audit(db, { actor: { type: "partner", label: partnerSlug }, action: "order.propose_slots", entity: "order", entityId: o.id, summary: `${valid.length} bezorgmoment(en) voorgesteld`, meta: { sellerSlug: partnerSlug } });
    return { ok: true };
  });
}

export async function chooseSlot(buyerId: string, orderId: string, at: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    if (!o.deliverySlots?.some(x => x.at === at)) return { error: "Ongeldig moment" };
    o.chosenSlotAt = at;
    const label = new Date(at).toLocaleString("nl-NL", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
    o.events.push({ status: o.status, at: new Date().toISOString(), note: `Bezorgmoment gekozen: ${label}` });
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Bezorgmoment gekozen", `${o.id} \u00b7 ${label}`, `/partner/orders/${o.id}`);
    audit(db, { actor: db.users.find(u => u.id === buyerId), action: "order.choose_slot", entity: "order", entityId: o.id, summary: `Bezorgmoment gekozen: ${label}`, meta: { sellerSlug: o.sellerSlug } });
    return { ok: true };
  });
}

/* ============ ORDER-CHAT (v6.7) ============ */
export async function addOrderMessage(userId: string, orderId: string, text: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o) return { error: "Order niet gevonden" };
    const me = db.users.find(u => u.id === userId);
    const isBuyer = o.buyerId === userId;
    const isPartner = !!me?.partnerSlug && me.partnerSlug === o.sellerSlug;
    if (!isBuyer && !isPartner) return { error: "Geen toegang tot deze order" };
    if (o.status === "cancelled") return { error: "Deze order is gesloten" };
    (o.messages ??= []).push({ from: isBuyer ? "buyer" : "partner", text: text.slice(0, 500), at: new Date().toISOString() });
    if (o.messages.length > 200) o.messages = o.messages.slice(-200);
    if (isBuyer) {
      const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
      if (partner) pushNote(db, partner.id, "order", "Nieuw bericht van koper", `${o.id}: "${text.slice(0, 60)}"`, `/partner/orders/${o.id}`);
    } else {
      pushNote(db, o.buyerId, "order", "Nieuw bericht van de partner", `${o.id}: "${text.slice(0, 60)}"`, `/order/${o.id}`);
    }
    audit(db, { actor: me, action: "order.chat", entity: "order", entityId: o.id, summary: `${isBuyer ? "koper" : "partner"}: ${text.slice(0, 120)}`, meta: { sellerSlug: o.sellerSlug, from: isBuyer ? "buyer" : "partner" } });
    return { ok: true };
  });
}

/** Orders van één koper (v7.0 — voor personalisatie en account). */
export async function getMyOrders(userId: string) {
  const db = await read();
  return db.orders.filter(o => o.buyerId === userId);
}

/* ============ REVIEWS — alleen afgeronde pilotorders ============ */
export async function addReview(orderId: string, buyerId: string, rating: number, text?: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    if (o.status !== "paid_out") return { error: "Review kan na afronding van de order" };
    if (o.returnRequest && o.returnRequest.status !== "completed") {
      return { error: "Rond eerst je retouraanvraag af" };
    }
    if (db.reviews.some(r => r.orderId === orderId)) return { error: "Je hebt deze aankoop al beoordeeld" };
    const r = Math.round(rating);
    if (!(r >= 1 && r <= 5)) return { error: "Beoordeling: 1 t/m 5 sterren" };
    const buyer = db.users.find(u => u.id === buyerId);
    db.reviews.push({
      id: Math.random().toString(36).slice(2, 10),
      orderId, listingId: o.listingId, sellerSlug: o.sellerSlug, buyerId,
      buyerName: (buyer?.name ?? "Koper").split(" ")[0],
      rating: r as 1 | 2 | 3 | 4 | 5,
      text: text?.trim().slice(0, 600) || undefined,
      at: new Date().toISOString(),
    });
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", `Nieuwe review: ${"★".repeat(r)}`,
      `${o.itemTitle}${text ? ` — "${text.trim().slice(0, 60)}"` : ""}`, "/partner/storefront");
    audit(db, { actor: buyer, action: "review.create", entity: "review", entityId: orderId, summary: `${r} sterren voor ${o.itemTitle}`, meta: { sellerSlug: o.sellerSlug, listingId: o.listingId } });
    return { ok: true };
  });
}

export async function replyReview(reviewId: string, partnerSlug: string, text: string) {
  return mutate(db => {
    const r = db.reviews.find(x => x.id === reviewId);
    if (!r || r.sellerSlug !== partnerSlug) return { error: "Niet jouw review" };
    if (r.reply) return { error: "Je hebt al gereageerd" };
    r.reply = { text: text.trim().slice(0, 400), at: new Date().toISOString() };
    pushNote(db, r.buyerId, "order", "De partner reageerde op je review", `"${r.reply.text.slice(0, 60)}"`, `/store/${partnerSlug}`);
    audit(db, { actor: { type: "partner", label: partnerSlug }, action: "review.reply", entity: "review", entityId: reviewId, summary: `Partnerreactie op review`, meta: { sellerSlug: partnerSlug } });
    return { ok: true };
  });
}

export async function getSellerReviews(slug: string) {
  const db = await read();
  return db.reviews.filter(r => r.sellerSlug === slug).sort((a, b) => b.at.localeCompare(a.at));
}

export function ratingOf(reviews: { rating: number }[]) {
  if (reviews.length === 0) return null;
  return { avg: Math.round((reviews.reduce((s, r) => s + r.rating, 0) / reviews.length) * 10) / 10, count: reviews.length };
}



export async function getFinanceAuditReport() {
  const db = await read();
  const chain = verifyLedgerChain(db);
  const balances = ledgerAccountBalances(db);
  const issues: string[] = [...chain.issues];
  const ledgerZeroSumCents = Object.values(balances).reduce((a, b) => a + b, 0);
  if (ledgerZeroSumCents !== 0) issues.push(`Grootboek niet nul-som: ${ledgerZeroSumCents} cent`);
  for (const o of db.orders) {
    const bal = balances[escrowAccount(o.id)] ?? 0;
    const expected = ["paid_out", "cancelled"].includes(o.status) ? 0 : cents(o.totalPaid);
    if (bal !== expected) issues.push(`Escrow mismatch ${o.id}: saldo ${bal} cent, verwacht ${expected} cent`);
    if (bal < 0) issues.push(`Negatieve escrow voor ${o.id}: ${bal} cent`);
  }
  const sellers = db.sellers.map(s => s.slug);
  for (const slug of sellers) {
    const wallet = balances[walletAccount(slug)] ?? 0;
    const reserved = balances[reserveAccount(slug)] ?? 0;
    if (wallet < 0) issues.push(`Negatief walletsaldo voor ${slug}: ${wallet} cent`);
    if (reserved < 0) issues.push(`Negatieve campagne-reserve voor ${slug}: ${reserved} cent`);
  }
  for (const c of db.promotionCampaigns ?? []) {
    const expectedReserved = c.reservedCents ?? 0;
    const spent = c.spentCents ?? cents(c.spent || 0);
    const refunded = c.refundedCents ?? 0;
    if (["active", "paused"].includes(c.status) && expectedReserved <= 0) issues.push(`Actieve campagne zonder gereserveerd budget: ${c.id}`);
    if (["stopped", "ended"].includes(c.status) && Math.max(0, expectedReserved - spent - refunded) > 1) issues.push(`Afgesloten campagne niet volledig verrekend: ${c.id}`);
    if (spent > expectedReserved) issues.push(`Campagne heeft meer spend dan reserve: ${c.id}`);
  }
  const escrowOrders = db.orders.filter(o => !["paid_out", "cancelled"].includes(o.status));
  const escrowOpenCents = escrowOrders.reduce((sum, o) => sum + cents(o.totalPaid), 0);
  const walletTotalCents = sellers.reduce((sum, slug) => sum + Math.max(0, balances[walletAccount(slug)] ?? 0), 0);
  const reservedTotalCents = sellers.reduce((sum, slug) => sum + Math.max(0, balances[reserveAccount(slug)] ?? 0), 0);
  return {
    ok: issues.length === 0,
    mode: process.env.PAYMENT_LIVE_ENABLED === "true" ? "live_requested" : "preview",
    issues,
    totals: {
      ledgerEntries: db.walletLedger?.length ?? 0,
      sellers: sellers.length,
      escrowOpenCents,
      walletTotalCents,
      reservedTotalCents,
      ledgerZeroSumCents,
      activeCampaigns: (db.promotionCampaigns ?? []).filter(c => c.status === "active").length,
      pausedCampaigns: (db.promotionCampaigns ?? []).filter(c => c.status === "paused").length,
    },
    rules: [
      "AI mag adviseren maar nooit zelfstandig campagnebudget reserveren, uitbetalen of refunden.",
      "Saldo wordt nooit handmatig overschreven; alleen append-only ledgerregels zijn toegestaan.",
      "Campagnes reserveren budget vooraf en restbudget komt via campaign_refund terug.",
      "Echte live finance vereist provider-reconciliatie en PAYMENT_LIVE_ENABLED=true.",
    ],
  };
}

export async function sweepCampaigns() {
  return mutate(db => {
    db.promotionCampaigns ??= [];
    let n = 0;
    const now = Date.now();
    for (const c of db.promotionCampaigns) {
      if (!["active", "paused"].includes(c.status)) continue;
      if (!c.endsAt || +new Date(c.endsAt) > now) continue;
      const settled = settleCampaignStop(db, c, "Campagne automatisch afgesloten na einddatum");
      c.status = "ended";
      audit(db, { actor: { type: "system", label: "sweepCampaigns" }, action: "promotion.ended", entity: "promotion", entityId: c.id, summary: `Campagne automatisch afgesloten · refund €${eurosFromCents(settled.refundedCents).toLocaleString("nl-NL")}`, meta: { sellerSlug: c.sellerSlug, refundedCents: settled.refundedCents, spentCents: settled.spentCents } });
      n++;
    }
    return n;
  });
}

export async function recordPromotionSpendPrepared(sellerSlug: string, campaignId: string, amountCents: number, reason = "Voorbereide spend-engine") {
  return mutate(db => {
    const c = (db.promotionCampaigns ?? []).find(x => x.id === campaignId && x.sellerSlug === sellerSlug);
    if (!c) return { error: "Campagne niet gevonden" };
    if (c.status !== "active") return { error: "Campagne is niet actief" };
    const reserveBal = accountBalanceCents(db, reserveAccount(sellerSlug));
    const amount = Math.max(0, Math.min(Math.round(amountCents), reserveBal));
    if (amount <= 0) return { error: "Geen reserve beschikbaar" };
    const tx = appendLedger(db, {
      sellerSlug,
      type: "campaign_spend",
      debitAccount: reserveAccount(sellerSlug),
      creditAccount: promoteRevenueAccount,
      amountCents: amount,
      entityType: "campaign",
      entityId: campaignId,
      idempotencyKey: `campaign_spend_event:${campaignId}:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`,
      note: reason.slice(0, 180),
    });
    c.spentCents = (c.spentCents ?? 0) + amount;
    c.spent = eurosFromCents(c.spentCents);
    return { ok: true, transaction: tx, wallet: walletSummaryFromDb(db, sellerSlug) };
  });
}

export async function getPromotionCampaigns(sellerSlug?: string): Promise<PromotionCampaign[]> {
  const db = await read();
  const all = db.promotionCampaigns ?? [];
  return (sellerSlug ? all.filter(c => c.sellerSlug === sellerSlug) : all)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function createPromotionCampaign(input: {
  sellerSlug: string;
  kind: PromotionCampaign["kind"];
  listingId?: string;
  listingIds?: string[];
  category?: Listing["category"];
  name: string;
  objective: PromotionCampaign["objective"];
  budgetDaily: number;
  days: number;
  creativeVariants?: PromotionCreative[];
  selectedVariantId?: string;
  requestId?: string;
  initiatedBy?: "partner" | "ai" | "system";
}): Promise<PromotionCampaign | { error: string }> {
  return mutate(db => {
    if (input.initiatedBy === "ai") return { error: "AI mag geen campagnebudget reserveren. Partnerbevestiging is verplicht." };
    db.promotionCampaigns ??= [];
    reconcileFinanceLedger(db);
    const idempotencyKey = input.requestId ? `campaign_create:${input.sellerSlug}:${input.requestId}` : undefined;
    if (idempotencyKey) { const existing = db.promotionCampaigns.find(c => c.idempotencyKey === idempotencyKey); if (existing) return existing; }
    const seller = db.sellers.find(s => s.slug === input.sellerSlug);
    if (!seller) return { error: "Partner niet gevonden" };
    const requestedListingIds = Array.from(new Set((input.listingIds?.length ? input.listingIds : (input.listingId ? [input.listingId] : [])).filter(Boolean)));
    if (input.kind === "listing") {
      if (!requestedListingIds.length) return { error: "Kies minimaal één product" };
      const validIds = new Set(db.listings.filter(l => l.sellerSlug === input.sellerSlug).map(l => l.id));
      if (requestedListingIds.some(id => !validIds.has(id))) return { error: "Eén of meer producten niet gevonden" };
    }
    if (input.kind === "category" && !input.category) return { error: "Categorie ontbreekt" };
    const now = new Date();
    const ends = new Date(+now + Math.max(1, Math.min(30, input.days)) * 864e5);
    const campaignId = Math.random().toString(36).slice(2, 10);
    const reservedCents = cents(Math.max(3, Math.min(100, Math.round(input.budgetDaily))) * Math.max(1, Math.min(30, input.days)));
    const reserved = reserveCampaignBudget(db, input.sellerSlug, campaignId, reservedCents);
    if ("error" in reserved) return { error: reserved.error };
    const c: PromotionCampaign = {
      id: campaignId,
      idempotencyKey,
      sellerSlug: input.sellerSlug,
      kind: input.kind,
      listingId: input.kind === "listing" ? requestedListingIds[0] : undefined,
      listingIds: input.kind === "listing" ? requestedListingIds.slice(0, 20) : undefined,
      category: input.kind === "category" ? input.category : undefined,
      name: input.name.slice(0, 80),
      objective: input.objective,
      budgetDaily: Math.max(3, Math.min(100, Math.round(input.budgetDaily))),
      status: "active",
      startsAt: now.toISOString(),
      endsAt: ends.toISOString(),
      spent: 0,
      reservedCents,
      spentCents: 0,
      refundedCents: 0,
      impressions: 0,
      clicks: 0,
      selectedVariantId: input.selectedVariantId || input.creativeVariants?.[0]?.id,
      creativeVariants: input.creativeVariants ?? [],
      creativeFatigue: 0,
      placements: ["home_discovery", "home_spotlight", "category", "search", "ai_vinder"],
      createdAt: now.toISOString(),
    };
    db.promotionCampaigns.push(c);
    audit(db, { actor: { type: "partner", label: input.sellerSlug }, action: "promotion.create", entity: "promotion", entityId: c.id, summary: `${c.name} gestart voor €${c.budgetDaily}/dag`, meta: { reservedCents } });
    return c;
  });
}

export async function setPromotionCampaignStatus(sellerSlug: string, id: string, status: PromotionCampaign["status"], reason?: string) {
  return mutate(db => {
    const c = (db.promotionCampaigns ?? []).find(x => x.id === id && x.sellerSlug === sellerSlug);
    if (!c) return { error: "Campagne niet gevonden" };
    if (c.status === "stopped" || c.status === "ended") return { error: "Deze campagne is al afgesloten" };
    if (status === "stopped" || status === "ended") {
      const settled = settleCampaignStop(db, c, reason);
      audit(db, { actor: { type: "partner", label: sellerSlug }, action: "promotion.stop", entity: "promotion", entityId: id, summary: `Campagne gestopt · refund €${eurosFromCents(settled.refundedCents).toLocaleString("nl-NL")}`, meta: { refundedCents: settled.refundedCents, spentCents: settled.spentCents, reason: reason ?? null } });
      return settled;
    }
    c.status = status;
    audit(db, { actor: { type: "partner", label: sellerSlug }, action: `promotion.${status}`, entity: "promotion", entityId: id, summary: `Campagne ${status}` });
    return { campaign: c, wallet: walletSummaryFromDb(db, sellerSlug) };
  });
}
