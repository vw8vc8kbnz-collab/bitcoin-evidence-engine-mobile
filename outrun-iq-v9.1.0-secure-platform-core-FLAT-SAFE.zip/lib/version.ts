export const APP_VERSION = "9.1.0";
export const RELEASE_NAME = "Secure Platform Core";
/** Hard release gate: v9.1.0 verwerkt onder geen enkele configuratie echt geld. */
export const COMMERCE_LIVE_READY = false;
