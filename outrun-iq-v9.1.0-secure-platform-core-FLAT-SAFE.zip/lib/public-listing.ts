import type { Listing } from "./types";

export type PublicListingCopy = {
  title?: string;
  shortDescription?: string;
  description?: string;
  longDescription?: string;
  bullets?: string[];
};

export type PublicListing = {
  id: string;
  sellerSlug: string;
  title: string;
  brand?: string;
  category: Listing["category"];
  taxonomyGroupId?: string;
  subcategoryId?: string;
  taxonomyVersion?: number;
  condition: string;
  conditionScore: number;
  defect?: string;
  photos: string[];
  listingCopy?: PublicListingCopy;
  fallback: Listing["fallback"];
  stock: number;
  perUnit: boolean;
  newPrice: number;
  price: number;
  minimumBid: number;
  delivery: string;
  deliveryPrice: number;
  pickupCity: string;
  status: Listing["status"];
  createdAt: string;
  views: number;
};

/**
 * Buyer-facing allowlist. Nieuwe interne Listing-velden worden hierdoor nooit
 * automatisch publiek. Wijzig dit contract uitsluitend na privacyreview.
 */
export function toPublicListing(l: Listing): PublicListing {
  const minimumBid = Math.max(1, Math.min(Math.max(1, l.price - 1), Math.round(l.fast || l.price * 0.8)));
  return {
    id: l.id,
    sellerSlug: l.sellerSlug,
    title: l.title,
    brand: l.brand,
    category: l.category,
    taxonomyGroupId: l.taxonomyGroupId,
    subcategoryId: l.subcategoryId,
    taxonomyVersion: l.taxonomyVersion,
    condition: l.condition,
    conditionScore: l.conditionScore,
    defect: l.defect,
    photos: [...(l.photos || [])].slice(0, 5),
    listingCopy: l.listingCopy ? {
      title: l.listingCopy.title,
      shortDescription: l.listingCopy.shortDescription,
      description: l.listingCopy.description,
      longDescription: l.listingCopy.longDescription,
      bullets: l.listingCopy.bullets ? [...l.listingCopy.bullets].slice(0, 5) : undefined,
    } : undefined,
    fallback: l.fallback,
    stock: l.stock,
    perUnit: l.perUnit,
    newPrice: l.newPrice,
    price: l.price,
    minimumBid,
    delivery: l.delivery,
    deliveryPrice: l.deliveryPrice,
    pickupCity: l.pickupCity,
    status: l.status,
    createdAt: l.createdAt,
    views: l.views,
  };
}

export function toPublicListings(items: Listing[]): PublicListing[] {
  return items.map(toPublicListing);
}

export const FORBIDDEN_PUBLIC_LISTING_KEYS = [
  "partnerRef", "internalPhotos", "visionMetadata", "seo", "reviewChecklist", "confirmations", "priceLog",
  "fast", "premium", "expectedDays", "confidence", "comps", "aiSource"
] as const;
