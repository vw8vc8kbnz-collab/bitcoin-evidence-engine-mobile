export type OriginContext = {
  origin: string | null;
  secFetchSite: string | null;
  host: string | null;
  forwardedHost: string | null;
  forwardedProto: string | null;
};

/** Proxy-aware same-origin check for mutating browser requests. */
export function isTrustedMutationOrigin(ctx: OriginContext): boolean {
  if (ctx.secFetchSite === "cross-site") return false;
  if (!ctx.origin) return true; // server-to-server/native clients are still protected by auth + route validation
  try {
    const url = new URL(ctx.origin);
    const expectedHost = (ctx.forwardedHost || ctx.host || "").split(",")[0].trim().toLowerCase();
    if (!expectedHost || url.host.toLowerCase() !== expectedHost) return false;
    const forwardedProto = (ctx.forwardedProto || "").split(",")[0].trim().toLowerCase();
    if (forwardedProto && url.protocol !== `${forwardedProto}:`) return false;
    return true;
  } catch {
    return false;
  }
}

/** Stabiele, begrensde sleutel voor auth-rate-limits achter de vertrouwde reverse proxy. */
export function requestClientKey(headers: Pick<Headers, "get">): string {
  const real = headers.get("x-real-ip")?.trim();
  const forwarded = headers.get("x-forwarded-for")?.split(",").at(-1)?.trim();
  const raw = real || forwarded || "unknown";
  return raw.replace(/[^A-Za-z0-9:._-]/g, "").slice(0, 80) || "unknown";
}
