import type { Listing } from "./types";

export type TaxonomyParent = Listing["category"];
export type TaxonomyItem = {
  id: string;
  label: string;
  parent: TaxonomyParent;
  keywords: string[];
  popular?: boolean;
};
export type TaxonomyGroup = {
  id: string;
  title: string;
  parent: TaxonomyParent;
  icon: string;
  items: TaxonomyItem[];
};

const make = (parent: TaxonomyParent, labels: string[], popular: string[] = []): TaxonomyItem[] =>
  labels.map((label) => ({
    id: label.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, ""),
    label,
    parent,
    keywords: label.toLowerCase().split(/\s+|\//g).filter(Boolean),
    popular: popular.includes(label),
  }));

export const TAXONOMY: TaxonomyGroup[] = [
  {
    id: "witgoed",
    title: "Witgoed",
    parent: "witgoed",
    icon: "◉",
    items: make("witgoed", [
      "Wasmachines", "Drogers", "Was-droogcombinaties", "Koelkasten", "Vriezers", "Koel-vriescombinaties", "Vaatwassers", "Ovens", "Magnetrons", "Kookplaten", "Afzuigkappen", "Airco's", "Stofzuigers", "Robotstofzuigers", "Reinigers"
    ], ["Wasmachines", "Drogers", "Koelkasten", "Vaatwassers"]),
  },
  {
    id: "elektronica",
    title: "Elektronica",
    parent: "overig",
    icon: "▣",
    items: make("overig", [
      "TV's", "Soundbars", "Speakers", "Koptelefoons", "Oordopjes", "Smartphones", "Tablets", "Laptops", "Desktop PC's", "Monitoren", "Printers", "Camera's", "Smart home", "Netwerk", "Gaming consoles", "Controllers", "Racing wheels", "VR brillen"
    ], ["TV's", "Koptelefoons", "Laptops", "Gaming consoles"]),
  },
  {
    id: "meubels",
    title: "Meubels & wonen",
    parent: "meubels",
    icon: "▱",
    items: make("meubels", [
      "Banken", "Hoekbanken", "Stoelen", "Fauteuils", "Eettafels", "Salontafels", "Kasten", "Dressoirs", "Bedden", "Matrassen", "Bureaus", "Bureaustoelen", "Verlichting", "Vloerkleden", "Decoratie", "Kinderkamer"
    ], ["Banken", "Hoekbanken", "Stoelen", "Kasten"]),
  },
  {
    id: "keuken",
    title: "Keuken",
    parent: "keukens",
    icon: "▤",
    items: make("keukens", [
      "Keukenblokken", "Keukenfronten", "Werkbladen", "Spoelbakken", "Kranen", "Koffiemachines", "Espressomachines", "Blenders", "Airfryers", "Pannen", "Servies", "Bestek", "Keukenaccessoires", "Inbouwapparatuur"
    ], ["Koffiemachines", "Keukenfronten", "Werkbladen", "Airfryers"]),
  },
  {
    id: "tuin",
    title: "Tuin & buiten",
    parent: "tuin",
    icon: "✦",
    items: make("tuin", [
      "Tuinsets", "Loungesets", "Tuintafels", "Tuinstoelen", "Parasols", "BBQ", "Buitenkeukens", "Tuinmachines", "Hogedrukreinigers", "Zwembaden", "Terrasverwarming", "Buitenverlichting", "Schuttingen", "Plantenbakken"
    ], ["Tuinsets", "Loungesets", "BBQ", "Tuinmachines"]),
  },
  {
    id: "gereedschap",
    title: "Gereedschap & klus",
    parent: "overig",
    icon: "＋",
    items: make("overig", [
      "Boormachines", "Schroefmachines", "Zaagmachines", "Schuurmachines", "Accu gereedschap", "Handgereedschap", "Ladders", "Werkbanken", "Compressoren", "Lasapparaten", "Meetgereedschap", "Bouwmaterialen"
    ], ["Boormachines", "Accu gereedschap", "Zaagmachines"]),
  },
  {
    id: "sport",
    title: "Sport & hobby",
    parent: "overig",
    icon: "◎",
    items: make("overig", [
      "Fitnessapparatuur", "Fietsen", "E-bikes", "Steps", "Kamperen", "Wintersport", "Watersport", "Muziekinstrumenten", "Hobby", "Speelgoed", "Bordspellen"
    ], ["Fietsen", "Fitnessapparatuur", "E-bikes"]),
  },
  {
    id: "auto",
    title: "Auto & mobiliteit",
    parent: "overig",
    icon: "◇",
    items: make("overig", [
      "Auto-accessoires", "Motoraccessoires", "Banden", "Velgen", "Dakkoffers", "Fietsendragers", "Dashcams", "Navigatie", "EV laders", "Scooters", "Onderdelen"
    ], ["Auto-accessoires", "Banden", "EV laders"]),
  },
];

export const POPULAR_TAXONOMY_ITEMS = TAXONOMY.flatMap((g) => g.items.filter((i) => i.popular)).slice(0, 18);

export function parentLabel(parent?: string) {
  if (parent === "witgoed") return "Witgoed";
  if (parent === "meubels") return "Meubels";
  if (parent === "keukens") return "Keuken";
  if (parent === "tuin") return "Tuin";
  if (parent === "overig") return "Overig";
  return "Alle categorieën";
}

export function taxonomyItemById(id?: string) {
  if (!id) return undefined;
  return TAXONOMY.flatMap((g) => g.items).find((i) => i.id === id);
}


export const TAXONOMY_VERSION = 2;

export function inferTaxonomy(title: string, parent?: Listing["category"]) {
  const hay = title.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const candidates = TAXONOMY
    .filter(g => !parent || g.parent === parent)
    .flatMap(g => g.items.map(item => ({ groupId: g.id, item, score: [item.label, ...item.keywords].reduce((n, term) => n + (hay.includes(term.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")) ? term.length : 0), 0) })))
    .sort((a,b) => b.score - a.score);
  const best = candidates[0];
  const fallbackGroup = TAXONOMY.find(g => g.parent === parent) ?? TAXONOMY.find(g => g.id === "elektronica");
  return { groupId: best?.score ? best.groupId : fallbackGroup?.id, subcategoryId: best?.score ? best.item.id : undefined };
}

export function listingMatchesTaxonomy(l: Pick<Listing, "title" | "category" | "taxonomyGroupId" | "subcategoryId">, subcategoryId?: string) {
  if (!subcategoryId) return true;
  if (l.subcategoryId === subcategoryId) return true;
  const item = taxonomyItemById(subcategoryId);
  if (!item || item.parent !== l.category) return false;
  const hay = l.title.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  return [item.label, ...item.keywords].some(term => hay.includes(term.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")));
}
