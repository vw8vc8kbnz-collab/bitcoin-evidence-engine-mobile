import type { Seller } from "./types";

export type PublicSeller = {
  slug: string;
  name: string;
  city: string;
  logo?: string;
  banner?: string;
  about?: string;
};

/** Publieke seller-allowlist: nooit KvK, btw, e-mail, bank- of adresdata meesturen. */
export function toPublicSeller(seller: Seller): PublicSeller {
  return {
    slug: seller.slug,
    name: seller.name,
    city: seller.city,
    logo: seller.logo,
    banner: seller.banner,
    about: seller.about,
  };
}
