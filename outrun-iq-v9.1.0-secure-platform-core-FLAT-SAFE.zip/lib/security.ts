import { createHash, randomBytes, randomInt, timingSafeEqual } from "node:crypto";
import type { VerifyCode } from "./types";

export type VerificationPurpose = "register" | "reset";

export function createOneTimeCode(email: string, purpose: VerificationPurpose, ttlMinutes = 15): { code: string; record: VerifyCode } {
  const code = String(randomInt(100000, 1000000));
  const salt = randomBytes(24).toString("hex");
  const codeHash = hashCode(email, purpose, code, salt);
  return {
    code,
    record: {
      email: email.trim().toLowerCase(), purpose, codeHash, salt,
      expiresAt: new Date(Date.now() + ttlMinutes * 60_000).toISOString(), tries: 0,
    },
  };
}

export function verifyOneTimeCode(record: VerifyCode, email: string, purpose: VerificationPurpose, code: string): boolean {
  if ((record.purpose ?? purpose) !== purpose) return false;
  if (record.codeHash && record.salt) {
    const expected = Buffer.from(record.codeHash, "hex");
    const actual = Buffer.from(hashCode(email, purpose, code, record.salt), "hex");
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  }
  // Eenmalige compatibiliteit met bestaande records; nieuwe records bewaren nooit plaintext.
  return typeof record.code === "string" && record.code === code;
}

function hashCode(email: string, purpose: VerificationPurpose, code: string, salt: string): string {
  return createHash("sha256").update(`${email.trim().toLowerCase()}|${purpose}|${salt}|${code}`).digest("hex");
}

export function isProduction() {
  return process.env.NODE_ENV === "production";
}
