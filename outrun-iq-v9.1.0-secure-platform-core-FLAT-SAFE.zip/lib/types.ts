export type Address = { name?: string; street: string; postcode: string; city: string };

export type Seller = {
  slug: string;
  name: string;
  city: string;
  kvk?: string;
  vatNumber?: string;
  contactPerson?: string;
  businessEmail?: string;
  businessPhone?: string;
  deliveryOptions?: string[];
  shippingCost?: number;
  payout?: { bankStatus?: "missing" | "pending" | "verified"; ibanMasked?: string };
  stripeConnect?: { status?: "not_started" | "pending" | "restricted" | "active"; accountId?: string; lastSyncAt?: string };
  logo?: string;          // /uploads/… — partnerlogo (vierkant, icon)
  banner?: string;        // /uploads/… — brede storefront-banner
  support?: { email: string; phone?: string; returnsInfo?: string };  // klantenservice — verplicht vóór publiceren
  about?: string;         // korte "over ons" op de storefront
  address?: Address;      // afhaal-/magazijnadres
  trusted?: boolean;      // bewezen partner: kortere escrow-termijn (bol-model)
  createdAt: string;
  payment?: { provider?: "stripe" | "mollie" | "adyen" | "mangopay" | "test"; providerAccountId?: string; onboardingStatus?: "not_started" | "pending" | "complete"; payoutsEnabled?: boolean };
};

export type ListingStatus = "draft" | "ai_processing" | "needs_review" | "ready_to_publish" | "published" | "reserved" | "sold" | "archived" | "active" | "paused";

export type ListingConfirmation = {
  status: "user_confirmed" | "unknown_confirmed";
  byUserId: string;
  at: string;
};

export type Listing = {
  id: string;                 // url-slug
  sellerSlug: string;
  title: string;
  brand?: string;
  partnerRef?: string;        // vrije referentie/SKU van de partner
  category: "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
  taxonomyGroupId?: string;
  subcategoryId?: string;
  taxonomyVersion?: number;
  condition: string;          // vrije tekst, ·-separator
  conditionScore: number;     // 1–10
  defect?: string;            // bv. "Gebrek: kras zijkant — foto 3"
  photos: string[];           // /uploads/… buyer-facing foto's (max 5; label/serienummer alleen als nodig)
  internalPhotos?: string[];  // /uploads/… AI/OCR-only foto's, niet standaard zichtbaar voor buyers
  visionMetadata?: {
    model?: string;
    seriesCandidates?: string[];
    modelCandidates?: string[];
    articleNumber?: string;
    serialMasked?: string;
    ocrText?: string;
    confidence?: number;
    needsExtraPhotos?: string[];
    photoRoles?: { index: number; role: string; buyerFacing: boolean; reason?: string }[];
  };
  listingCopy?: {
    title?: string;
    shortDescription?: string;
    description?: string;
    longDescription?: string;
    bullets?: string[];
    sourceMode?: "known_product_paraphrase" | "vision_generated" | "safe_fallback";
    confidence?: number;
    warnings?: string[];
  };
  seo?: {
    title?: string;
    metaDescription?: string;
    keywords?: string[];
    altTexts?: string[];
  };
  fallback: "washer" | "sofa" | "chair" | "tv" | "dryer";
  stock: number;
  perUnit: boolean;
  newPrice: number;           // nieuwprijs/adviesprijs — anker voor AI én evidence strip (= MARKT)
  price: number;              // gekozen verkoopprijs (OUTLET-positie)
  fast: number;
  premium: number;
  expectedDays: number;
  confidence: number;         // 0–100
  comps: number;              // 0 = onbekend → UI toont "—"
  aiSource: "deepseek" | "heuristiek";
  delivery: string;
  deliveryPrice: number;
  pickupCity: string;
  priceLog?: { at: string; from: number; to: number }[];
  status: ListingStatus;
  reviewChecklist?: { title: boolean; price: boolean; category: boolean; photo: boolean; modelConfirmed: boolean; pricingConfirmed: boolean; conditionConfirmed: boolean; publicationConfirmed: boolean; description: boolean; seo: boolean; updatedAt: string; };
  confirmations?: {
    identity?: ListingConfirmation;
    pricing?: ListingConfirmation;
    condition?: ListingConfirmation;
    publication?: ListingConfirmation;
  };
  createdAt: string;
  views: number;
};


export type OutletBatchStatus = "draft" | "uploading" | "ai_grouping" | "review" | "ready_to_process" | "processing" | "ready_to_publish" | "archived";
export type OutletPartyType = "retouren" | "b-stock" | "showroom" | "restpartij" | "faillissement" | "overig";
export type OutletPhotoRole = "main" | "detail" | "label" | "damage" | "accessory" | "packaging" | "unknown";
export type OutletPhoto = {
  id: string;
  url: string;
  filename?: string;
  hash?: string;
  suggestedGroupId?: string;
  confirmedGroupId?: string;
  role: OutletPhotoRole;
  publicAllowed: boolean;
  confidence: number;
  needsReview?: boolean;
  createdAt: string;
};
export type OutletProductGroup = {
  id: string;
  batchId: string;
  reference: string;
  title?: string;
  brand?: string;
  model?: string;
  status: "draft" | "needs_review" | "ready_for_ai" | "ai_processing" | "ready_to_publish" | "published" | "error";
  photoIds: string[];
  mainPhotoId?: string;
  aiConfidence: number;
  aiNotes?: string[];
  missingPhotos?: string[];
  listingId?: string;
  updatedAt: string;
};
export type ProcessingJob = {
  id: string;
  batchId: string;
  groupId?: string;
  sellerSlug: string;
  type: "photo_grouping" | "listing_ai";
  status: "waiting" | "running" | "done" | "error";
  attempts: number;
  maxAttempts: number;
  error?: string;
  createdAt: string;
  startedAt?: string;
  finishedAt?: string;
};
export type OutletBatch = {
  id: string;
  sellerSlug: string;
  reference: string;
  supplier?: string;
  partyType: OutletPartyType;
  warehouseLocation?: string;
  estimatedProducts?: number;
  notes?: string;
  status: OutletBatchStatus;
  photos: OutletPhoto[];
  groups: OutletProductGroup[];
  jobs: ProcessingJob[];
  createdAt: string;
  updatedAt: string;
};

export type OrderStatus =
  | "paid" | "confirmed" | "delivery_planned" | "delivered"
  | "delivered_buyer_confirmed" | "paid_out" | "disputed" | "cancelled";

export type Order = {
  id: string;                 // OIQ-{jaar}-{0000}
  buyerId: string;
  listingId: string;
  sellerSlug: string;
  itemTitle: string;          // snapshot
  partnerRef?: string;        // snapshot van Listing.partnerRef (magazijnreferentie)
  itemPrice: number;
  deliveryChoice: "bezorgen" | "ophalen";
  deliveryPrice: number;
  deliveryAddress?: Address;  // verplicht bij bezorgen
  pickupCode?: string;        // 6 tekens, alleen bij ophalen — klant toont, partner verifieert
  dispute?: { category: string; text: string; at: string };
  paymentRef?: string;        // M4: Stripe PaymentIntent-id (nu ongebruikt, testmodus)
  deliveryRef?: string;       // Brenger-boekingsreferentie (nu ongebruikt, handmatig)
  bidId?: string;             // order voortgekomen uit geaccepteerd bod
  clientRequestId?: string;   // idempotency key vanuit checkout
  deliverySlots?: { at: string }[];   // door partner voorgestelde bezorgmomenten
  chosenSlotAt?: string;              // door koper gekozen moment
  messages?: { from: "buyer" | "partner"; text: string; at: string }[];  // order-chat
  returnRequest?: {
    reason: string; at: string;
    deadlineAt: string;              // partner moet vóór dit moment reageren
    status: "requested" | "responded" | "escalated" | "completed";
    instructions?: string; respondedAt?: string; completedAt?: string;
  };
  totalPaid: number;
  commission: number;         // 10% van itemPrice
  sellerNet: number;
  status: OrderStatus;
  events: { status: OrderStatus; at: string; note?: string }[];
  createdAt: string;
};

export type Role = "consument" | "partner" | "admin";

export type PartnerProfile = {
  companyName: string;
  kvk: string;
  city: string;
  status: "pending" | "approved" | "rejected";
  termsAcceptedAt?: string;
  appliedAt: string;
  decidedAt?: string;
};

export type User = {
  id: string;
  email: string;            // lowercase
  name: string;
  passHash: string;         // scrypt, hex
  salt: string;             // hex
  role: Role;
  partnerProfile?: PartnerProfile;
  partnerSlug?: string;     // gezet bij goedkeuring; koppelt aan Seller-record
  createdAt: string;
};

export type Session = {
  tokenHash: string;        // sha256 van het cookie-token
  userId: string;
  expiresAt: string;
};

export type MediaAsset = {
  id: string;
  ownerSellerSlug: string;
  url: string;
  filename: string;
  visibility: "private" | "public";
  purpose: "listing" | "logo" | "banner" | "unknown";
  mimeType: string;
  sizeBytes: number;
  width?: number;
  height?: number;
  sha256: string;
  listingId?: string;
  createdAt: string;
  publishedAt?: string;
};

export type VerifyCode = {
  email: string;
  purpose?: "register" | "reset";
  code?: string;             // legacy-only; nieuwe records bewaren uitsluitend codeHash
  codeHash?: string;
  salt?: string;
  expiresAt: string;
  tries: number;
};

export type SavedItem = {
  userId: string;
  listingId: string;
  savedAtPrice: number;
  at: string;
};

export type PromotionCreative = {
  id: string;
  title: string;
  subtitle: string;
  cta: string;
  style: "premium_dark" | "clean_light" | "product_grid" | "collection" | "urgent";
  badge?: string;
  predictedCtr: number;
  confidence: number;
  reason: string;
};

export type PromotionCampaign = {
  id: string;
  idempotencyKey?: string;
  sellerSlug: string;
  kind: "listing" | "seller" | "category";
  listingId?: string;
  listingIds?: string[];
  category?: Listing["category"];
  name: string;
  objective: "views" | "chats" | "sell_faster" | "brand";
  budgetDaily: number;
  status: "draft" | "active" | "paused" | "ended" | "stopped";
  startsAt: string;
  endsAt?: string;
  spent: number;                 // euro legacy/display
  reservedCents?: number;        // totaal gereserveerd budget
  spentCents?: number;           // werkelijk verbruikt
  refundedCents?: number;        // terug naar wallet bij stop
  stoppedAt?: string;
  stopReason?: string;
  impressions: number;
  clicks: number;
  selectedVariantId?: string;
  creativeVariants?: PromotionCreative[];
  creativeFatigue?: number;
  placements?: ("home_discovery" | "home_spotlight" | "category" | "search" | "ai_vinder")[];
  createdAt: string;
};

export type WalletLedgerEntry = {
  id: string;
  at: string;
  sellerSlug: string;
  type: "order_escrow" | "order_payout" | "order_commission" | "order_delivery" | "order_refund" | "campaign_reserve" | "campaign_spend" | "campaign_refund" | "withdrawal_request" | "provider_payout" | "provider_sync" | "adjustment";
  debitAccount: string;
  creditAccount: string;
  amountCents: number;
  currency: "EUR";
  entityType?: "order" | "campaign" | "wallet" | "system";
  entityId?: string;
  idempotencyKey: string;
  note?: string;
  prevHash?: string;
  hash: string;
};

export type WalletSummary = {
  sellerSlug: string;
  availableCents: number;
  reservedCents: number;
  lifetimeInCents: number;
  lifetimeOutCents: number;
};

export type AiDecision = {
  id: string;
  at: string;
  agent: "discovery" | "ranking" | "home_builder" | "promotion" | "deal_quality" | "partner_coach" | "ai_router";
  provider: "rules" | "openai" | "deepseek" | "hybrid" | "fallback";
  userId?: string;
  role?: Role;
  context: string;
  subjectType: "listing" | "seller" | "campaign" | "home" | "inventory" | "search" | "system";
  subjectId?: string;
  score?: number;
  confidence: number;
  reason: string;
  features?: Record<string, string | number | boolean | null | undefined>;
};

export type Notification = {
  id: string;
  userId: string;
  type: "order" | "payout" | "prijs" | "systeem";
  title: string;
  body: string;
  href: string;
  read: boolean;
  at: string;
};

export type Bid = {
  id: string;
  listingId: string;
  buyerId: string;
  sellerSlug: string;
  amount: number;              // huidig geldend bedrag (bij tegenbod-acceptatie = counterAmount)
  message?: string;            // contactgegevens worden gemaskeerd (anti-omzeiling)
  counterAmount?: number;
  status: "open" | "countered" | "accepted" | "rejected" | "withdrawn" | "used";
  at: string;
  respondedAt?: string;
};

export type Review = {
  id: string;
  orderId: string;             // 1 review per afgeronde orderflow
  listingId: string;
  sellerSlug: string;
  buyerId: string;
  buyerName: string;           // snapshot (voornaam), blijft na account-verwijdering leesbaar
  rating: 1 | 2 | 3 | 4 | 5;
  text?: string;
  at: string;
  reply?: { text: string; at: string };   // partnerreactie
};


export type LearningProductAggregate = {
  key: string;
  brand?: string;
  model?: string;
  category: Listing["category"] | "unknown";
  samples: number;
  activeListings: number;
  soldSamples: number;
  avgListPrice: number;
  avgSoldPrice: number;
  minListPrice: number;
  maxListPrice: number;
  totalViews: number;
  totalSaves: number;
  totalBids: number;
  totalOrders: number;
  avgAiConfidence: number;
  lastSeenAt: string;
};

export type LearningDailyAggregate = {
  date: string;
  listingsPublished: number;
  views: number;
  saves: number;
  bids: number;
  orders: number;
  soldValue: number;
};

export type LearningState = {
  version: 1;
  updatedAt: string;
  totals: {
    listingsLearned: number;
    productKeys: number;
    views: number;
    saves: number;
    bids: number;
    orders: number;
    soldValue: number;
  };
  products: LearningProductAggregate[];
  daily: LearningDailyAggregate[];
};


export type LearningEvent = {
  id: string;
  at: string;
  type: "listing_published" | "listing_view" | "listing_save" | "bid_created" | "order_created" | "price_changed" | "listing_seo";
  listingId?: string;
  sellerSlug?: string;
  userId?: string;
  value?: number;
  meta?: Record<string, string | number | boolean | null | undefined>;
};

export type CommerceBrainState = {
  version: 1;
  updatedAt: string;
  queue: LearningEvent[];
  processed: number;
  dropped: number;
  lastProcessedAt?: string;
  seo: {
    productPagesPrepared: number;
    structuredDataReady: number;
    lastPreparedAt?: string;
  };
};

export type AuditEvent = {
  id: string;
  at: string;
  actorType: "buyer" | "partner" | "admin" | "system";
  actorId?: string;
  actorLabel?: string;
  action: string;
  entity: "auth" | "listing" | "order" | "bid" | "return" | "dispute" | "review" | "partner" | "admin" | "wallet" | "promotion" | "system";
  entityId?: string;
  summary: string;
  meta?: Record<string, string | number | boolean | null | undefined>;
};

export type PushSub = {
  userId: string;
  endpoint: string;
  keys: { p256dh: string; auth: string };
  at: string;
};

export type FlowEvent = {
  id: string;
  sessionId: string;
  at: string;
  userId?: string;
  role?: Role;
  path: string;
  type: "start" | "stop" | "route" | "click" | "submit" | "error" | "snapshot" | "api" | "visibility";
  label?: string;
  target?: string;
  text?: string;
  x?: number;
  y?: number;
  scrollY?: number;
  viewport?: { w: number; h: number; dpr?: number };
  ua?: string;
  html?: string;
  meta?: Record<string, string | number | boolean | null | undefined>;
};

export type DB = {
  users: User[];
  sessions: Session[];
  codes: VerifyCode[];
  saved: SavedItem[];
  notifications: Notification[];
  sellers: Seller[];        // interne naam; UI zegt "partner"
  listings: Listing[];
  outletBatches?: OutletBatch[];
  processingJobs?: ProcessingJob[];
  orders: Order[];
  bids: Bid[];
  pushSubs: PushSub[];
  reviews: Review[];
  auditLog: AuditEvent[];
  flowEvents: FlowEvent[];
  mediaAssets?: MediaAsset[];
  aiDecisions: AiDecision[];
  promotionCampaigns: PromotionCampaign[];
  walletLedger: WalletLedgerEntry[];
  traffic: Record<string, { views: number; visitors: number }>;  // per dag (YYYY-MM-DD)
  learning?: LearningState;       // compacte AI-learning aggregates; bewust gecapt zodat de server niet volloopt
  commerceBrain?: CommerceBrainState; // compacte event queue + SEO/AI-commerce status; capped voor VPS
  counters: { order: number };
};

export const eur = (n: number) => "€" + Math.round(n).toLocaleString("nl-NL");
export const COMMISSION = 0.10;

export const slugify = (s: string) =>
  s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
   .replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 60);

export const FALLBACK_BY_CATEGORY: Record<Listing["category"], Listing["fallback"]> = {
  witgoed: "washer", meubels: "sofa", keukens: "dryer", tuin: "chair", overig: "tv",
};
