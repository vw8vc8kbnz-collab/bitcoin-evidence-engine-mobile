import { createHash, randomBytes, randomUUID } from "node:crypto";
import path from "node:path";
import sharp from "sharp";
import { read } from "./store";
import type { DB, MediaAsset } from "./types";

const TYPES: Record<string, { ext: string; mime: string }> = {
  "image/jpeg": { ext: ".jpg", mime: "image/jpeg" },
  "image/png": { ext: ".png", mime: "image/png" },
  "image/webp": { ext: ".webp", mime: "image/webp" },
  "image/heic": { ext: ".heic", mime: "image/heic" },
  "image/heif": { ext: ".heic", mime: "image/heic" },
};

export function validatedImageType(buffer: Buffer, declared: string) {
  const cfg = TYPES[declared];
  if (!cfg) return null;
  const jpeg = buffer.length > 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  const png = buffer.length > 8 && buffer.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  const webp = buffer.length > 12 && buffer.subarray(0,4).toString("ascii") === "RIFF" && buffer.subarray(8,12).toString("ascii") === "WEBP";
  const box = buffer.length > 12 ? buffer.subarray(4,12).toString("ascii") : "";
  const heic = box.startsWith("ftyp") && /heic|heix|hevc|hevx|mif1|msf1/.test(buffer.subarray(8,32).toString("ascii"));
  const valid = cfg.ext === ".jpg" ? jpeg : cfg.ext === ".png" ? png : cfg.ext === ".webp" ? webp : heic;
  return valid ? cfg : null;
}

export type ProcessedUpload = { buffer: Buffer; mimeType: "image/webp"; width: number; height: number };

/** Decodeert echt beeldmateriaal, begrenst pixels/resolutie en verwijdert metadata via re-encoding. */
export async function processUploadedImage(buffer: Buffer, declaredMime: string): Promise<ProcessedUpload> {
  if (!validatedImageType(buffer, declaredMime)) throw new Error("Bestandsinhoud komt niet overeen met een toegestaan beeldformaat");
  const pipeline = sharp(buffer, { failOn: "error", limitInputPixels: 40_000_000, sequentialRead: true });
  const result = await pipeline
    .rotate()
    .resize({ width: 2400, height: 2400, fit: "inside", withoutEnlargement: true })
    .webp({ quality: 86, effort: 4, smartSubsample: true })
    .toBuffer({ resolveWithObject: true });
  const width = result.info.width || 0;
  const height = result.info.height || 0;
  if (!width || !height || width * height > 40_000_000) throw new Error("Afbeeldingsafmetingen zijn ongeldig");
  return { buffer: result.data, mimeType: "image/webp", width, height };
}

export function makeMediaAsset(ownerSellerSlug: string, buffer: Buffer, mimeType: string, dimensions?: { width: number; height: number }): MediaAsset {
  const cfg = TYPES[mimeType];
  if (!cfg) throw new Error("unsupported media type");
  const filename = `${Date.now()}-${randomBytes(18).toString("hex")}${cfg.ext}`;
  return {
    id: randomUUID(), ownerSellerSlug, url: `/uploads/${filename}`, filename,
    visibility: "private", purpose: "listing", mimeType: cfg.mime,
    sizeBytes: buffer.length, width: dimensions?.width, height: dimensions?.height,
    sha256: createHash("sha256").update(buffer).digest("hex"),
    createdAt: new Date().toISOString(),
  };
}

export function normalizeUploadUrl(value: unknown): string | null {
  const s = String(value ?? "");
  if (!s.startsWith("/uploads/")) return null;
  const name = path.basename(s.slice("/uploads/".length));
  if (!name || s !== `/uploads/${name}`) return null;
  return s;
}

export async function partnerOwnsMedia(sellerSlug: string, urls: string[]): Promise<boolean> {
  const db = await read();
  return urls.every(url => {
    const asset = (db.mediaAssets ?? []).find(a => a.url === url);
    if (asset) return asset.ownerSellerSlug === sellerSlug;
    // Legacycompatibiliteit: alleen media die al bij dezelfde seller in een listing staat.
    return db.listings.some(l => l.sellerSlug === sellerSlug && [...(l.photos || []), ...(l.internalPhotos || [])].includes(url));
  });
}

export function mediaAccess(db: DB, url: string) {
  const asset = (db.mediaAssets ?? []).find(a => a.url === url);
  if (asset) return { visibility: asset.visibility, ownerSellerSlug: asset.ownerSellerSlug, asset };
  const publicListing = db.listings.find(l => (l.status === "published" || l.status === "active") && (l.photos || []).includes(url));
  if (publicListing) return { visibility: "public" as const, ownerSellerSlug: publicListing.sellerSlug };
  const privateListing = db.listings.find(l => [...(l.internalPhotos || []), ...(l.photos || [])].includes(url));
  if (privateListing) return { visibility: "private" as const, ownerSellerSlug: privateListing.sellerSlug };
  const seller = db.sellers.find(s => s.logo === url || s.banner === url);
  if (seller) return { visibility: "public" as const, ownerSellerSlug: seller.slug };
  return null;
}
