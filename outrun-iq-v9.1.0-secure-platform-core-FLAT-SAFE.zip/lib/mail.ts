function maskRecipient(to: string) {
  const [name, domain] = to.split("@");
  return domain ? `${name.slice(0, 2)}•••@${domain}` : "•••";
}

/** Verstuurt mail zonder ooit codes of body in logs te schrijven. */
export async function sendMail(to: string, subject: string, body: string): Promise<boolean> {
  const key = process.env.RESEND_API_KEY;
  if (!key) {
    console.error(`[mail] provider ontbreekt voor ${maskRecipient(to)} · ${subject}`);
    if (process.env.NODE_ENV === "production") return false;
    return false;
  }
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 10_000);
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST", signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        from: process.env.MAIL_FROM || "Outrun IQ <onboarding@resend.dev>",
        to: [to], subject, text: body,
        html: `<div style="font-family:system-ui,sans-serif;max-width:480px;margin:0 auto;padding:24px"><p style="font-size:15px;font-weight:800;color:#0E4B46">OUTRUN IQ</p><p style="font-size:14px;line-height:1.6;color:#333">${body.replace(/[<&]/g, c => c === "<" ? "&lt;" : "&amp;")}</p><p style="font-size:11px;color:#777">Vraag je dit niet zelf aan? Negeer deze mail.</p></div>`,
      }),
    });
    clearTimeout(timer);
    if (res.ok) return true;
    console.error(`[mail] provider weigerde ${maskRecipient(to)} · status=${res.status}`);
    return false;
  } catch (error) {
    console.error(`[mail] verzendfout voor ${maskRecipient(to)}`, error instanceof Error ? error.message : "unknown");
    return false;
  }
}
