import { getFinanceAuditReport, getPartnerWallet } from "./data";
import { COMMERCE_LIVE_READY } from "./version";

export type PaymentProviderName = "test" | "stripe" | "mollie" | "adyen" | "mangopay";
export type PaymentCapability =
  | "checkout"
  | "escrow"
  | "connect_onboarding"
  | "balance"
  | "payouts"
  | "refunds"
  | "campaign_funding";

export type ProviderStatus = {
  provider: PaymentProviderName;
  mode: "test" | "live";
  configured: boolean;
  capabilities: PaymentCapability[];
  missing: string[];
  label: string;
  note: string;
};

export type FinanceProviderSnapshot = {
  sellerSlug: string;
  provider: PaymentProviderName;
  providerLabel: string;
  mode: "test" | "live";
  configured: boolean;
  availableCents: number;
  reservedCents: number;
  providerBalanceCents?: number;
  providerPendingCents?: number;
  payoutEnabled: boolean;
  campaignFundingEnabled: boolean;
  onboardingRequired: boolean;
  note: string;
};

export type CheckoutIntentInput = { orderId: string; amountCents: number; currency?: "EUR"; sellerSlug: string };
export type CheckoutIntent = { provider: PaymentProviderName; mode: "test" | "live"; redirectUrl?: string; paymentRef?: string; status: "test_paid" | "requires_redirect" | "not_configured" };
export type PayoutRequestInput = { sellerSlug: string; amountCents: number; idempotencyKey: string };
export type PayoutRequestResult = { ok: boolean; provider: PaymentProviderName; status: "queued" | "requires_provider" | "test_queued"; message: string };

const has = (name: string) => Boolean(process.env[name] && String(process.env[name]).trim());
const envTrue = (name: string) => ["1", "true", "yes", "live"].includes(String(process.env[name] || "").toLowerCase());

export function activePaymentProvider(): PaymentProviderName {
  const raw = String(process.env.PAYMENT_PROVIDER || "").toLowerCase();
  if (["stripe", "mollie", "adyen", "mangopay"].includes(raw)) return raw as PaymentProviderName;
  if (has("STRIPE_SECRET_KEY")) return "stripe";
  return "test";
}

export function paymentsMode(): "test" | "stripe" {
  // Backwards-compatible helper for bestaande checkout UI.
  return COMMERCE_LIVE_READY && activePaymentProvider() === "stripe" && has("STRIPE_SECRET_KEY") ? "stripe" : "test";
}

export function getPaymentProviderStatus(provider: PaymentProviderName = activePaymentProvider()): ProviderStatus {
  if (provider === "stripe") {
    const missing = [
      has("STRIPE_SECRET_KEY") ? "" : "STRIPE_SECRET_KEY",
      has("STRIPE_WEBHOOK_SECRET") ? "" : "STRIPE_WEBHOOK_SECRET",
    ].filter(Boolean);
    return {
      provider,
      mode: envTrue("STRIPE_LIVE_MODE") ? "live" : "test",
      configured: missing.length === 0,
      capabilities: ["checkout", "escrow", "connect_onboarding", "balance", "payouts", "refunds", "campaign_funding"],
      missing,
      label: "Stripe Connect",
      note: missing.length ? "Stripe-adapter staat klaar, maar mist nog configuratie." : (COMMERCE_LIVE_READY && envTrue("PAYMENT_LIVE_ENABLED") ? "Stripe Connect is live vrijgegeven." : "Providerconfiguratie kan worden voorbereid, maar v9.1.0 blijft hard in pilotmodus."),
    };
  }
  if (provider === "test") {
    return {
      provider,
      mode: "test",
      configured: true,
      capabilities: ["checkout", "escrow", "balance", "campaign_funding"],
      missing: [],
      label: "Outrun Test Provider",
      note: "Testmodus: geen echt geld. De Payment Engine gebruikt wel dezelfde wallet/finance-interface.",
    };
  }
  return {
    provider,
    mode: "test",
    configured: false,
    capabilities: [],
    missing: [`${provider.toUpperCase()}_CONFIG`],
    label: provider[0].toUpperCase() + provider.slice(1),
    note: "Provider-adapter is bewust voorbereid, maar nog niet actief. De app blijft provider-onafhankelijk.",
  };
}

export async function getFinanceSnapshot(sellerSlug: string): Promise<FinanceProviderSnapshot> {
  const status = getPaymentProviderStatus();
  const wallet = await getPartnerWallet(sellerSlug);
  return {
    sellerSlug,
    provider: status.provider,
    providerLabel: status.label,
    mode: status.mode,
    configured: status.configured,
    availableCents: wallet.summary.availableCents,
    reservedCents: wallet.summary.reservedCents,
    providerBalanceCents: undefined,
    providerPendingCents: undefined,
    payoutEnabled: COMMERCE_LIVE_READY && status.provider === "stripe" && status.configured && status.mode === "live" && envTrue("PAYMENT_LIVE_ENABLED"),
    campaignFundingEnabled: status.provider === "test",
    onboardingRequired: status.provider === "stripe" && !status.configured,
    note: status.mode === "live" && !envTrue("PAYMENT_LIVE_ENABLED") ? `${status.note} Live geldverplaatsing is nog geblokkeerd door Outrun safety mode.` : status.note,
  };
}

export async function createCheckoutIntent(input: CheckoutIntentInput): Promise<CheckoutIntent> {
  const status = getPaymentProviderStatus();
  if (status.provider === "test") {
    return { provider: "test", mode: "test", paymentRef: `test:${input.orderId}`, status: "test_paid" };
  }
  if (COMMERCE_LIVE_READY && status.provider === "stripe" && status.configured) {
    return { provider: "stripe", mode: status.mode, status: "requires_redirect" };
  }
  return { provider: status.provider, mode: status.mode, status: "not_configured" };
}

export async function requestProviderPayout(_input: PayoutRequestInput): Promise<PayoutRequestResult> {
  const status = getPaymentProviderStatus();
  if (status.provider === "test") return { ok: true, provider: "test", status: "test_queued", message: "Testuitbetaling aangemaakt. Geen echt geld verplaatst." };
  if (COMMERCE_LIVE_READY && status.provider === "stripe" && status.configured) return { ok: true, provider: "stripe", status: "queued", message: "Uitbetaling wordt via Stripe Connect verwerkt." };
  return { ok: false, provider: status.provider, status: "requires_provider", message: "Betaalprovider is nog niet volledig geconfigureerd." };
}


export function financeSafetyMode() {
  const status = getPaymentProviderStatus();
  const liveUnlocked = COMMERCE_LIVE_READY && status.provider === "stripe" && status.configured && status.mode === "live" && envTrue("PAYMENT_LIVE_ENABLED");
  return {
    liveUnlocked,
    label: liveUnlocked ? "LIVE FINANCE" : "FINANCE PREVIEW",
    severity: liveUnlocked ? "ok" : "warning",
    message: liveUnlocked
      ? "Provider is live vrijgegeven. Blijf reconciliatie en auditchecks monitoren."
      : "v9.1.0 is hard vergrendeld in pilotmodus. Geen configuratie kan echt geld, payouts of campagnebudget verplaatsen.",
    aiCanMoveMoney: false,
  } as const;
}

export async function paymentAdminStatus() {
  return { status: getPaymentProviderStatus(), safety: financeSafetyMode(), audit: await getFinanceAuditReport(), architecture: PAYMENT_ARCHITECTURE };
}

export const PAYMENT_ARCHITECTURE = {
  principle: "Outrun praat met Payment Engine, nooit direct met Stripe in UI/business logic.",
  layers: ["Wallet Engine", "Payment Engine", "Provider Adapter", "Stripe/Mollie/Adyen/Mangopay"],
  security: [
    "AI mag adviseren maar nooit geld verplaatsen.",
    "Wallet is een grootboek bovenop provider-saldo, geen eigen bank.",
    "Campagnes reserveren budget en restbudget wordt via ledger teruggeboekt.",
    "Provider kan later gewisseld worden zonder Home/Promote/Finance UI te herschrijven.",
  ],
} as const;
