import { Mark } from "@/components/icons";

export const metadata = { title: "Offline — Outrun IQ" };

export default function Offline() {
  return (
    <div className="app">
      <main className="page narrow" style={{ textAlign: "center", paddingTop: 90 }}>
        <span style={{ opacity: .5, display: "inline-block" }}><Mark size={44} /></span>
        <h1 className="h1big" style={{ marginTop: 16 }}>Even geen verbinding</h1>
        <p className="note">Outrun IQ heeft internet nodig om actuele listings, bestellingen en berichten te laden. Controleer je verbinding en probeer opnieuw.</p>
      </main>
    </div>
  );
}
