import Link from "next/link";
import { notFound } from "next/navigation";
import { getPublicListingContext, bumpViews, buildListingStructuredData } from "@/lib/data";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { ListingBody } from "@/components/ListingBody";
import { Gallery } from "@/components/Gallery";

export const dynamic = "force-dynamic";

export default async function ListingPage({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getUser();
  const context = await getPublicListingContext(id, isPersonalBuyer(user) ? user!.id : undefined);
  if (!context) notFound();
  const { listing: l, seller, rating, myBid, savedOn } = context;
  bumpViews(id);
  return (
    <main className="page lpg" style={{ paddingBottom: 0 }}>
      <div className="media">
        <Gallery photos={l.photos} fallback={l.fallback} defect={l.defect} title={l.title} />
        <Link href="/" className="back2" aria-label="Terug"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg></Link>
      </div>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(buildListingStructuredData(l, seller)) }} />
      <ListingBody l={l} sellerName={seller?.name ?? l.sellerSlug} sellerLogo={seller?.logo} myBid={myBid} savedOn={savedOn} rating={rating} />
    </main>
  );
}
