import { notFound } from "next/navigation";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { getPublicListingContext, bumpViews, buildListingStructuredData } from "@/lib/data";
import { BottomSheet } from "@/components/BottomSheet";
import { ListingBody } from "@/components/ListingBody";
import { Gallery } from "@/components/Gallery";

export const dynamic = "force-dynamic";

export default async function ListingModal({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getUser();
  const context = await getPublicListingContext(id, isPersonalBuyer(user) ? user!.id : undefined);
  if (!context) notFound();
  const { listing: l, seller, rating, myBid, savedOn } = context;
  bumpViews(id);
  return (
    <BottomSheet title={l.title}>
      <div className="media nativeMedia"><Gallery photos={l.photos} fallback={l.fallback} defect={l.defect} title={l.title} /></div>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(buildListingStructuredData(l, seller)) }} />
      <ListingBody l={l} sellerName={seller?.name ?? l.sellerSlug} sellerLogo={seller?.logo} myBid={myBid} savedOn={savedOn} rating={rating} />
    </BottomSheet>
  );
}
