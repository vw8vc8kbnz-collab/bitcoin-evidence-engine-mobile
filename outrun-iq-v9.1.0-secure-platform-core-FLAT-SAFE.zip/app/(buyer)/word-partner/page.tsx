import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { BusinessAccountLink } from "@/components/BusinessAccountLink";
import { Check } from "@/components/icons";

export const dynamic = "force-dynamic";

function PartnerPromise() {
  return (
    <>
      <p className="note" style={{ marginTop: 4 }}>
        Verkoop overstock, showroommodellen en retouren via een apart zakelijk account — met
        slim prijsadvies, een eigen storefront en een overzichtelijke orderflow. Alleen voor goedgekeurde zakelijke accounts.
      </p>
      <div className="group" style={{ marginTop: 6 }}>
        <div className="li"><span className="icb"><Check /></span><b>10% commissie, verder niets<small>geen abonnement in de pilotfase</small></b></div>
        <div className="li"><span className="icb"><Check /></span><b>AI prijst je voorraad<small>fast / outlet / premium met verwachte verkooptijd</small></b></div>
        <div className="li"><span className="icb"><Check /></span><b>Orderflow in één omgeving<small>betalingen blijven uitgeschakeld zolang de pilotmodus actief is</small></b></div>
      </div>
    </>
  );
}

export default async function WordPartner() {
  const user = await getUser();
  if (user && isApprovedPartner(user)) redirect("/partner");
  const status = user?.partnerProfile?.status;

  return (
    <main className="page narrow">
      <h1 className="h1big" style={{ marginTop: 20 }}>Outrun IQ Partner</h1>
      <PartnerPromise />

      {!user && (
        <div className="group" style={{ marginTop: 18 }}>
          <div className="li" style={{ display: "block" }}>
            <b>Maak een zakelijk account aan<small>partneraanvragen lopen alleen via een apart zakelijk account met bedrijfsgegevens en KvK-check.</small></b>
            <Link href="/welkom?type=zakelijk&next=/partner" className="btn pri" style={{ display: "block", textAlign: "center", marginTop: 14 }}>
              Zakelijk account aanmaken
            </Link>
          </div>
        </div>
      )}

      {user && !status && (
        <div className="group" style={{ marginTop: 18 }}>
          <div className="li" style={{ display: "block" }}>
            <b>Je bent ingelogd met een persoonlijk kopersaccount<small>om de werelden schoon te houden kan dit account niet worden omgezet naar partner. Maak hiervoor een apart zakelijk account aan.</small></b>
            <BusinessAccountLink className="btn pri" />
            <Link href="/account" className="btn sec" style={{ display: "block", textAlign: "center", marginTop: 10 }}>Terug naar account</Link>
          </div>
        </div>
      )}

      {user && status === "pending" && (
        <>
          <div className="group" style={{ marginTop: 18 }}>
            <div className="li">
              <b>Aanvraag in behandeling<small>{user.partnerProfile!.companyName} · KvK {user.partnerProfile!.kvk}</small></b>
              <span className="flag hot">IN BEHANDELING</span>
            </div>
          </div>
          <p className="note">We verifiëren je bedrijfsgegevens. Je krijgt een melding zodra je partneraccount actief is.</p>
          <Link href="/" className="btn sec" style={{ display: "block", textAlign: "center", marginTop: 14 }}>Terug naar de shop</Link>
        </>
      )}

      {user && status === "rejected" && (
        <div className="group" style={{ marginTop: 18 }}>
          <div className="li" style={{ display: "block" }}>
            <b>Aanvraag afgewezen<small>neem contact op met Outrun IQ als je denkt dat dit niet klopt. Maak geen nieuwe aanvraag met hetzelfde kopersaccount.</small></b>
            <BusinessAccountLink className="btn pri">Nieuw zakelijk account aanmaken</BusinessAccountLink>
          </div>
        </div>
      )}
    </main>
  );
}
