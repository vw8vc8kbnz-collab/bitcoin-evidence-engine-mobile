import Link from "next/link";
import { eur, getActiveListings, publicListings, unreadCount } from "@/lib/data";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { Img } from "@/components/Img";
import { BrandLockup } from "@/components/Brand";
import { Empty } from "@/components/Empty";
import type { PublicListing } from "@/lib/public-listing";

export const dynamic = "force-dynamic";
const discount=(l:PublicListing)=>l.newPrice>l.price&&l.newPrice>0?Math.max(0,Math.round((1-l.price/l.newPrice)*100)):0;
function unique(items:PublicListing[],count:number){const seen=new Set<string>();return items.filter(x=>!seen.has(x.id)&&seen.add(x.id)).slice(0,count)}
function DealCard({l,badge}:{l:PublicListing;badge?:string}){const d=discount(l);return <Link href={`/listing/${l.id}`} className="trustDealCard"><div className="trustDealMedia"><Img src={l.photos[0]} fallback={l.fallback}/>{badge&&<span>{badge}</span>}</div><div className="trustDealCopy"><small>{l.brand||l.pickupCity}</small><b>{l.title}</b><p>{l.condition||`Conditie ${l.conditionScore}/10`}</p><footer><strong>{eur(l.price)}{l.perUnit&&"/st"}</strong>{d>0&&<em>−{d}%</em>}</footer></div></Link>}
function Rail({title,items,href,badge}:{title:string;items:PublicListing[];href:string;badge?:string}){if(!items.length)return null;return <section className="trustRail"><header><h2>{title}</h2><Link href={href}>Bekijk alles →</Link></header><div>{items.map(l=><DealCard key={l.id} l={l} badge={badge}/>)}</div></section>}

export default async function Home(){
  const user=await getUser();const buyer=isPersonalBuyer(user);const unread=buyer?await unreadCount(user!.id):0;
  const all=publicListings(await getActiveListings());
  const newest=unique([...all].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)),8);
  const deals=unique([...all].filter(l=>discount(l)>0).sort((a,b)=>discount(b)-discount(a)),8);
  const popular=unique([...all].sort((a,b)=>b.views-a.views),8);
  const last=unique([...all].filter(l=>l.stock<=2).sort((a,b)=>a.stock-b.stock),8);
  const sellerCount=new Set(all.map(l=>l.sellerSlug)).size;
  return <main className="page trustHomePage">
    <header className="hd trustHomeHeader"><BrandLockup/><span className="sp"/>{buyer?<Link href="/meldingen" className="icbtn" aria-label="Meldingen"><svg viewBox="0 0 24 24"><path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5h-15S6 14 6 10z"/><path d="M10.5 19a1.8 1.8 0 003 0"/></svg>{unread>0&&<span className="bub">{unread>9?"9+":unread}</span>}</Link>:<Link href="/welkom?type=persoonlijk" className="homeLoginLink">Inloggen</Link>}</header>
    <section className="trustHero"><span className="trustEyebrow">PROFESSIONELE OUTLETVOORRAAD</span><h1>Goede producten verdienen een tweede verkoopkans.</h1><p>Bekijk retour-, showroom- en B-stockdeals van zakelijke aanbieders. Conditie, gebreken en levering staan direct bij het product.</p><form action="/zoeken" className="trustSearch"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg><input name="q" placeholder="Zoek product, merk of categorie" autoComplete="off"/><button>Zoeken</button></form><div className="trustHeroLinks"><Link href="/zoeken">Bekijk alle deals</Link><Link href="/vinder">Beschrijf wat je zoekt</Link></div></section>
    <section className="trustPromise" aria-label="Waarom Outrun IQ"><span><b>{all.length}</b><small>live deals</small></span><span><b>{sellerCount}</b><small>zakelijke aanbieders</small></span><span><b>Helder</b><small>conditie en gebreken</small></span></section>
    {!all.length?<Empty title="Nog geen live deals" text="Zodra partners hun gecontroleerde outletvoorraad publiceren, verschijnt die hier." cta="Word partner" href="/word-partner"/>:<>
      <Rail title="Nieuw binnen" items={newest} href="/zoeken?sort=nieuw"/>
      <Rail title="Scherpe prijsverschillen" items={deals} href="/zoeken?sort=korting"/>
      <Rail title="Veel bekeken" items={popular} href="/zoeken?sort=populair"/>
      <Rail title="Laatste stuks" items={last} href="/zoeken?sort=snel" badge="LAATSTE"/>
      <section className="trustFinderCta"><span>Gerichter zoeken</span><h2>Omschrijf het product dat je nodig hebt.</h2><p>Outrun vergelijkt je wens met de actuele voorraad en toont alleen bruikbare matches. De uiteindelijke keuze blijft altijd aan jou.</p><Link href="/vinder">Start beschrijvend zoeken →</Link></section>
      <section className="partnerTrustCta"><div><span>VOOR BEDRIJVEN</span><h2>Van stilstaande voorraad naar een professionele outletlisting.</h2><p>Voeg één product per keer toe. Outrun helpt met structureren, maar jij controleert product, conditie en prijs vóór publicatie.</p></div><Link href="/word-partner">Ontdek verkopen via Outrun →</Link></section>
    </>}
  </main>
}
