import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import { UPLOAD_DIR, LEGACY_UPLOAD_DIR, read } from "@/lib/store";
import { getUser, isAdmin, isApprovedPartner } from "@/lib/auth";
import { mediaAccess } from "@/lib/media";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MIME: Record<string, string> = { ".jpg":"image/jpeg", ".jpeg":"image/jpeg", ".png":"image/png", ".webp":"image/webp", ".heic":"image/heic" };

export async function GET(_req: Request, ctx: { params: Promise<{ name: string }> }) {
  const { name } = await ctx.params;
  const safe = path.basename(name);
  if (safe !== name) return new NextResponse("Niet gevonden", { status: 404 });
  const type = MIME[path.extname(safe).toLowerCase()];
  if (!type) return new NextResponse("Niet gevonden", { status: 404 });
  const url = `/uploads/${safe}`;
  const db = await read();
  const access = mediaAccess(db, url);
  if (!access) return new NextResponse("Niet gevonden", { status: 404 });
  if (access.visibility !== "public") {
    const user = await getUser();
    const allowed = isAdmin(user) || (isApprovedPartner(user) && user?.partnerSlug === access.ownerSellerSlug);
    if (!allowed) return new NextResponse("Niet gevonden", { status: 404 });
  }
  for (const dir of [UPLOAD_DIR, LEGACY_UPLOAD_DIR]) {
    try {
      const buf = await fs.readFile(path.join(dir, safe));
      return new NextResponse(new Uint8Array(buf), {
        headers: {
          "Content-Type": type,
          "X-Content-Type-Options": "nosniff",
          "Cache-Control": access.visibility === "public" ? "public, max-age=86400, stale-while-revalidate=604800" : "private, no-store, max-age=0",
        },
      });
    } catch { /* fallback */ }
  }
  return new NextResponse("Niet gevonden", { status: 404 });
}
