import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { Mark } from "@/components/icons";

export const dynamic = "force-dynamic";

export default async function Promoten() {
  const db = await read();
  const user = await getUser();
  const campaigns = (db.promotionCampaigns ?? [])
    .filter(c => c.sellerSlug === user?.partnerSlug)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  return (
    <main className="page partnerScreen promoteScreen promoteAIPage">
      <header className="hd">
        <Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />Outrun <b>Promote</b></Link>
        <span className="sp" />
        <span className="mini" style={{ color: "#8B96A0" }}>VOORBEREIDING</span>
      </header>

      <section className="partnerHero promoteHero promoteHeroAI">
        <span className="eyebrow">BEWUST NOG NIET LIVE</span>
        <h1>Promotie volgt pas wanneer meten en betalen betrouwbaar zijn.</h1>
        <p>Outrun IQ reserveert in v9.1.0 geen echt of gesimuleerd budget en start geen campagnes. Eerst moeten attributie, gesponsorde labels, rankingregels en de betaalinfrastructuur aantoonbaar kloppen.</p>
      </section>

      <section className="walletCorePanel">
        <span className="eyebrow">RELEASEGATE</span>
        <h2>Wat vóór activatie gereed moet zijn</h2>
        <div className="coachAdviceList">
          <article><b>Betalingen en grootboek</b><span>Providerwebhooks, idempotency, refunds en dagelijkse reconciliatie.</span></article>
          <article><b>Eerlijke zichtbaarheid</b><span>Gesponsorde resultaten worden duidelijk gelabeld en mogen organische relevantie niet verdringen.</span></article>
          <article><b>Meetbare attributie</b><span>Views, kliks, saves en orders moeten zonder opgeblazen voorspellingen herleidbaar zijn.</span></article>
          <article><b>Budgetcontrole</b><span>De partner bevestigt iedere campagne; AI mag adviseren maar nooit zelfstandig geld bewegen.</span></article>
        </div>
      </section>

      {campaigns.length > 0 && <section className="walletSafetyCard walletSafety44">
        <span>OUDE TESTRECORDS · ALLEEN LEZEN</span>
        <p>Er staan {campaigns.length} campagne{campaigns.length === 1 ? "" : "s"} uit eerdere pilotversies in de database. Ze worden in v9.1.0 niet uitgevoerd en reserveren geen budget.</p>
      </section>}

      <section className="promoteHow">
        <article><b>1. Eerst waarheid</b><span>Alleen echte gebeurtenissen tellen mee.</span></article>
        <article><b>2. Dan controle</b><span>Partner kiest doel, limiet en looptijd.</span></article>
        <article><b>3. Pas dan groei</b><span>AI optimaliseert binnen vaste, uitlegbare grenzen.</span></article>
      </section>

      <Link href="/partner" className="btn pri" style={{ margin: "20px 16px" }}>Terug naar vandaag</Link>
    </main>
  );
}
