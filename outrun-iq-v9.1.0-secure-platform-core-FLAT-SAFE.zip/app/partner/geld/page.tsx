import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { getPartnerWallet } from "@/lib/data";
import { financeSafetyMode, getPaymentProviderStatus } from "@/lib/payments";
import { Mark } from "@/components/icons";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";

const money = (cents: number) => {
  const n = Math.round(cents || 0);
  const sign = n < 0 ? "- " : "";
  return sign + new Intl.NumberFormat("nl-NL", { style: "currency", currency: "EUR", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Math.abs(n) / 100);
};
const day = (iso: string) => new Date(iso).toLocaleDateString("nl-NL", { day: "numeric", month: "short" });
const time = (iso: string) => new Date(iso).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const statusLabel = (s: string) => s.replaceAll("_", " ").toUpperCase();

function ActionLink({ href, icon, label }:{ href:string; icon:string; label:string }) {
  return <Link className="walletAction" href={href}><span>{icon}</span><b>{label}</b></Link>;
}

export default async function Geld() {
  const db = await read();
  const user = await getUser();
  const sellerSlug = user?.partnerSlug;
  const orders = db.orders.filter(o => o.sellerSlug === sellerSlug).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const wallet = sellerSlug ? await getPartnerWallet(sellerSlug) : null;
  const provider = getPaymentProviderStatus();
  const safety = financeSafetyMode();

  const available = wallet?.summary.availableCents ?? 0;
  const reserved = wallet?.summary.reservedCents ?? 0;
  const escrowOrders = orders.filter(o => !["paid_out", "cancelled"].includes(o.status));
  const escrowCents = escrowOrders.reduce((s, o) => s + Math.round(o.sellerNet * 100), 0);
  const paid30Cents = orders.filter(o => o.status === "paid_out" && Date.now() - +new Date(o.createdAt) < 30 * 864e5).reduce((s, o) => s + Math.round(o.sellerNet * 100), 0);
  const commission30Cents = orders.filter(o => Date.now() - +new Date(o.createdAt) < 30 * 864e5).reduce((s, o) => s + Math.round(o.commission * 100), 0);
  const todayInCents = wallet?.ledger.filter(tx => tx.at.slice(0,10) === new Date().toISOString().slice(0,10) && tx.creditAccount.includes(":wallet")).reduce((s, tx) => s + tx.amountCents, 0) ?? 0;
  const todayOutCents = wallet?.ledger.filter(tx => tx.at.slice(0,10) === new Date().toISOString().slice(0,10) && tx.debitAccount.includes(":wallet")).reduce((s, tx) => s + tx.amountCents, 0) ?? 0;
  const expectedReleaseCents = escrowCents;

  const ledger = wallet?.ledger ?? [];
  const ledgerPreview = ledger.slice(0, 5);
  const latestOrders = escrowOrders.slice(0, 3);
  const totalTracked = Math.max(1, Math.abs(available) + Math.abs(reserved) + Math.abs(escrowCents) + Math.abs(paid30Cents));
  const escrowPct = Math.round((Math.abs(escrowCents) / totalTracked) * 100);
  const reservedPct = Math.round((Math.abs(reserved) / totalTracked) * 100);
  const availablePct = Math.round((Math.abs(available) / totalTracked) * 100);

  return (
    <main className="page partnerScreen realWalletScreen walletV844">
      <header className="walletTopbar walletTopbar44">
        <Link href="/partner" className="walletMenu" aria-label="Dashboard"><Mark glow /></Link>
        <div><h1>Financiële simulatie</h1><span><i /> Pilot vergrendeld · {provider.label}</span></div>
        <Link href="/meldingen" className="walletBell" aria-label="Meldingen"><svg viewBox="0 0 24 24"><path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5h-15S6 14 6 10z"/><path d="M10.5 19a1.8 1.8 0 003 0"/></svg></Link>
      </header>

      {!sellerSlug && <Empty title="Geen partnerwallet" text="Je partneraccount is nodig om je wallet te openen." />}

      {sellerSlug && (
        <>
          <section className="walletHero44">
            <div className="walletHeroTop"><span>Gesimuleerd saldo</span><b>EUR</b></div>
            <strong>{money(available)}</strong>
            <p className="walletGreenDot"><i /> Geen echt geld</p>
            <div className="walletMiniStats">
              <div><small>Vandaag gesimuleerd in</small><b className="pos">+ {money(todayInCents)}</b></div>
              <div><small>Vandaag gesimuleerd uit</small><b>- {money(todayOutCents)}</b></div>
              <div><small>Testreservering</small><b>{money(expectedReleaseCents)}</b></div>
            </div>
            <div className="walletGraph" aria-hidden="true"><span/><span/><span/><span/><span/><span/><span/></div>
            <div className="walletButtons walletButtons44">
              <Link aria-disabled={!safety.liveUnlocked} href={safety.liveUnlocked ? "#uitbetaling" : "#finance-preview"}>Uitbetaling geblokkeerd ↗</Link>
              <Link href="/partner/promoten">Promoot producten ↗</Link>
            </div>
          </section>

          <section className="walletInsight44">
            <span>FINANCIËLE PILOT</span>
            <p>{money(escrowCents)} is uitsluitend een testsimulatie op basis van open testorders. Er wordt niets vastgehouden of uitbetaald.</p>
            <Link href="#cashflow">Meer inzichten</Link>
          </section>

          <section className="walletMetricStrip walletMetric44" id="cashflow">
            <Link href="#escrow"><span className="micon lock">▣</span><small>Test gereserveerd</small><b>{money(escrowCents)}</b><em>{escrowOrders.length} orders</em></Link>
            <Link href="/partner/promoten"><span className="micon bookmark">⌑</span><small>Gereserveerd</small><b>{money(reserved)}</b><em>Campagnes</em></Link>
            <Link href="#uitbetaling"><span className="micon up">↥</span><small>Test afgerond</small><b>{money(paid30Cents)}</b><em>30 dagen</em></Link>
            <Link href="#grootboek"><span className="micon fee">%</span><small>Commissie open</small><b>{money(commission30Cents)}</b><em>30 dagen</em></Link>
          </section>

          <section className="walletQuickActions walletQuick44">
            <h2>Snelle acties</h2>
            <div>
              <ActionLink href="#finance-preview" icon="↥" label="Pilotstatus" />
              <ActionLink href="#transacties" icon="☷" label="Transacties" />
              <ActionLink href="/partner/orders" icon="▤" label="Orders" />
              <ActionLink href="/partner/promoten" icon="◇" label="Campagnes" />
              <ActionLink href="#grootboek" icon="□" label="Grootboek" />
            </div>
          </section>

          <section id="transacties" className="walletTransactions walletTx44">
            <div className="walletSectionHead"><h2>Recente transacties</h2><Link href="#grootboek">Alles bekijken</Link></div>
            <nav className="walletFilters" aria-label="Transactiefilters"><a href="#transacties">Alle</a><a href="#escrow">Testreserveringen</a><a href="#uitbetaling">Afgeronde tests</a><Link href="/partner/promoten">Promotie</Link></nav>
            {ledgerPreview.length === 0 && <p className="walletMuted">Nog geen transacties. Nieuwe orders, refunds, commissies en uitbetalingen komen hier als walletregels te staan.</p>}
            {ledgerPreview.map(tx => {
              const incoming = tx.creditAccount.includes(":wallet") || tx.creditAccount.includes(":escrow");
              const tag = tx.type.replaceAll("_", " ").toUpperCase();
              return <Link href={`#tx-${tx.id}`} key={tx.id} className="walletTx">
                <span className={`txIcon ${incoming ? "in" : "out"}`}>{incoming ? "↓" : "−"}</span>
                <b>{tx.note ?? tx.type}<small>{time(tx.at)} · {tx.type}</small></b>
                <em>{tag}</em>
                <strong>{incoming ? "+ " : "- "}{money(tx.amountCents)}</strong>
              </Link>;
            })}
          </section>

          <section className="walletDonutPanel walletDonut44">
            <div className="walletDonut" style={{ background: `conic-gradient(#23d0b3 0 ${escrowPct}%, #f1a632 ${escrowPct}% ${escrowPct + reservedPct}%, #3698ff ${escrowPct + reservedPct}% ${escrowPct + reservedPct + availablePct}%, rgba(255,255,255,.08) ${escrowPct + reservedPct + availablePct}% 100%)` }}><span>Totaal<br/><b>{money(escrowCents)}</b></span></div>
            <div className="walletLegend">
              <a href="#escrow"><i className="a"/>Test gereserveerd <b>{money(escrowCents)}</b></a>
              <Link href="/partner/promoten"><i className="b"/>Gereserveerd <b>{money(reserved)}</b></Link>
              <a href="#transacties"><i className="c"/>Beschikbaar <b>{money(available)}</b></a>
              <a href="#uitbetaling"><i className="d"/>Test afgerond 30d <b>{money(paid30Cents)}</b></a>
            </div>
          </section>

          {latestOrders.length > 0 && <section id="escrow" className="walletOrdersCompact walletOrders44">
            <div className="walletSectionHead"><h2>Openstaande testorders</h2><Link href="/partner/orders">Bekijk orders</Link></div>
            {latestOrders.map(o => <Link href={`/partner/orders/${o.id}`} key={o.id} className="walletOrderLine"><b>{o.itemTitle}<small>{o.id} · {day(o.createdAt)} · {statusLabel(o.status)}</small></b><span>TEST GERESERVEERD</span><strong>{money(Math.round(o.sellerNet * 100))}</strong></Link>)}
          </section>}

          <section id="finance-preview" className="walletSafetyCard walletSafety44">
            <span>{safety.label}</span>
            <p>{safety.message}</p>
            <small>AI mag adviseren, maar nooit zelfstandig geld verplaatsen. In v9.1.0 zijn betalingen, reserveringen en uitbetalingen hard vergrendeld.</small>
          </section>

          <details id="grootboek" className="walletLedgerMini walletLedger44">
            <summary><div><h2>Financieel grootboek</h2><span>Append-only</span></div><b>Open</b></summary>
            {ledger.slice(0, 14).map(tx => <article id={`tx-${tx.id}`} key={tx.id} className="walletTx compact"><span className="txIcon ledger">•</span><b>{tx.note ?? tx.type}<small>{time(tx.at)} · {tx.type}</small></b><strong>{money(tx.amountCents)}</strong></article>)}
          </details>
        </>
      )}
    </main>
  );
}
