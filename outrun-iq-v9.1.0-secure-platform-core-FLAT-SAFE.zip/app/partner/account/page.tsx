import Link from "next/link";
import { getUser } from "@/lib/auth";
import { read } from "@/lib/store";
import { AccountSwitchActions } from "@/components/AccountSwitchActions";

export const dynamic = "force-dynamic";

export default async function PartnerAccountPage() {
  const user = await getUser();
  const db = await read();
  const seller = db.sellers.find(x => x.slug === user?.partnerSlug);

  return (
    <main className="page partnerScreen partnerAccountPage">
      <header className="hd">
        <Link href="/partner" className="back" style={{ color: "#fff" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Dash
        </Link>
        <span className="sp" />
        <span className="mini" style={{ color: "#8B96A0" }}>ACCOUNT</span>
      </header>

      <section className="accountHero partnerAccountHero">
        <span className="eyebrow">ZAKELIJK ACCOUNT</span>
        <h1>Account & sessie</h1>
        <p>Je zakelijke Partner Hub blijft gescheiden van je particuliere kopersaccount. Log uit om daarna als particulier of met een ander zakelijk account in te loggen.</p>
      </section>

      <div className="prof accountProfile partnerProfileCard">
        <span className="av2">{(seller?.name || user?.name || "OI").slice(0, 2).toUpperCase()}</span>
        <span>
          <b>{seller?.name || user?.name}</b>
          <span>{user?.email} · {seller?.city || user?.partnerProfile?.city || "Partner Hub"}</span>
        </span>
        <span className="badge">✓ ZAKELIJK</span>
      </div>

      <div className="slabel">SNEL WISSELEN</div>
      <div className="group settingsGroup partnerSessionGroup">
        <div className="li" style={{ display: "block" }}>
          <b>Van zakelijk naar particulier<small>Je zakelijke sessie wordt veilig beëindigd. Daarna kies je op het inlogscherm Persoonlijk.</small></b>
          <AccountSwitchActions variant="dark" />
        </div>
      </div>

      <div className="slabel">PARTNER HUB</div>
      <div className="group settingsGroup">
        <Link href="/partner/storefront" className="li"><b>Storefront beheren<small>logo, banner, support en bedrijfsprofiel</small></b><span className="go">OPEN →</span></Link>
        <Link href="/partner/geld" className="li"><b>Wallet bekijken<small>financiële testsimulatie en grootboek</small></b><span className="go">OPEN →</span></Link>
        <Link href="/" className="li"><b>Naar de shop<small>bekijk Outrun als koper zonder van account te wisselen</small></b><span className="go">OPEN →</span></Link>
      </div>
    </main>
  );
}
