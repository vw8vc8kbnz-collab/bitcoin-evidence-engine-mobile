import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { eur } from "@/lib/types";
import { Mark } from "@/components/icons";
import { Img } from "@/components/Img";
import { OrderAction } from "@/components/OrderActions";
import { ReturnPartnerActions } from "@/components/ReturnPartnerActions";
import { BidPartnerActions } from "@/components/BidPartnerActions";
import { SlotProposer } from "@/components/SlotProposer";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";

export default async function Orders() {
  const db = await read();
  const user = await getUser();
  const orders = db.orders.filter(o => o.sellerSlug === user?.partnerSlug).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const action = orders.filter(o => ["paid", "confirmed", "delivery_planned"].includes(o.status));
  const rest = orders.filter(o => !action.includes(o));
  const listing = (id: string) => db.listings.find(l => l.id === id);

  return (
    <main className="page partnerScreen ordersScreen">
      <header className="hd">
        <Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />Orders</Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>{orders.length} TOTAAL</span>
      </header>
      {orders.length === 0 && (
        <Empty title="Nog geen orders" text="Zodra een koper een testorder plaatst, verschijnt hij hier met de vereiste actie bovenaan." />
      )}
      {(() => { const bids = db.bids.filter(b => b.sellerSlug === user!.partnerSlug && ["open", "countered"].includes(b.status)); return bids.length > 0 && (
        <>
          <div className="dsec"><h2>Biedingen</h2><span>{bids.length}</span></div>
          {bids.map(b => { const l = listing(b.listingId); return (
            <div key={b.id}>
              <div className="orow">
                <Img src={l?.photos[0]} fallback={l?.fallback ?? "tv"} dark />
                <span><b>€{b.amount} op {l?.title ?? b.listingId}</b>
                  <span>VRAAGPRIJS €{l?.price ?? "?"}{b.status === "countered" ? ` · JOUW TEGENBOD €${b.counterAmount}` : ""}{b.message ? ` · "${b.message.slice(0, 50)}"` : ""}</span></span>
              </div>
              {b.status === "open" && l && <BidPartnerActions bidId={b.id} amount={b.amount} price={l.price} />}
            </div>
          ); })}
        </>
      ); })()}
      {(() => { const returns = orders.filter(o => o.returnRequest && ["requested", "escalated", "responded"].includes(o.returnRequest.status)); return returns.length > 0 && (
        <>
          <div className="dsec"><h2>Retouraanvragen</h2><span>{returns.length}</span></div>
          {returns.map(o => (
            <div key={"r" + o.id}>
              <div className="orow">
                <Img src={listing(o.listingId)?.photos[0]} fallback={listing(o.listingId)?.fallback ?? "tv"} dark />
                <span><b>{o.itemTitle}{o.partnerRef ? ` · ${o.partnerRef}` : ""}</b>
                  <span>{o.id} · {o.returnRequest!.status === "escalated" ? "⚠ GEËSCALEERD — REAGEER NU" : o.returnRequest!.status === "responded" ? "WACHT OP RETOURZENDING" : "REAGEER VÓÓR " + new Date(o.returnRequest!.deadlineAt).toLocaleDateString("nl-NL", { day: "numeric", month: "short" }).toUpperCase()} · "{o.returnRequest!.reason.slice(0, 60)}"</span></span>
              </div>
              <ReturnPartnerActions orderId={o.id} status={o.returnRequest!.status} />
            </div>
          ))}
        </>
      ); })()}
      {action.length > 0 && <div className="dsec"><h2>Actie nodig</h2><span>{action.length}</span></div>}
      <div className="partnerOrderList">
      {action.map(o => (
        <article key={o.id} className="partnerItem partnerOrderCard actionNeeded">
          <div className="partnerItemMain">
            <Img src={listing(o.listingId)?.photos[0]} fallback={listing(o.listingId)?.fallback ?? "tv"} dark />
            <Link href={`/partner/orders/${o.id}`} className="partnerItemText"><b>{o.itemTitle}{o.partnerRef ? ` · ${o.partnerRef}` : ""}</b>
              <span>{o.id} · chat actief · {o.deliveryChoice === "bezorgen" && o.deliveryAddress
                ? `${o.deliveryAddress.city}`
                : `afhaal · code ${o.pickupCode ?? "—"}`} · {eur(o.sellerNet)} netto</span></Link>
          </div>
          <div className="partnerActionSlot">
          {o.status === "paid"
            ? <OrderAction id={o.id} to="confirmed" label="BEVESTIG" />
            : o.status === "confirmed"
              ? <SlotProposer orderId={o.id} />
              : <OrderAction id={o.id} to="delivered" label="GELEVERD" />}
          </div>
        </article>
      ))}
      </div>
      {rest.length > 0 && <div className="dsec"><h2>Onderweg &amp; afgerond</h2></div>}
      {rest.map(o => (
        <article key={o.id} className="partnerItem partnerOrderCard">
          <div className="partnerItemMain">
            <Img src={listing(o.listingId)?.photos[0]} fallback={listing(o.listingId)?.fallback ?? "tv"} dark />
            <span className="partnerItemText"><b>{o.itemTitle}{o.partnerRef ? ` · ${o.partnerRef}` : ""}</b>
              <span>{o.id} · {o.status === "delivered" ? "wacht op koper" : o.status === "disputed" ? `dispute · ${o.dispute?.category ?? ""}` : o.status.replaceAll("_", " ").toLowerCase()}</span></span>
            <span className="partnerAmount">{eur(o.sellerNet)}<i className="esc" style={o.status === "paid_out" ? { color: "#4CBE8B" } : undefined}>{o.status === "paid_out" ? "TEST AFGEROND" : "TEST GERESERVEERD"}</i></span>
          </div>
        </article>
      ))}
    </main>
  );
}
