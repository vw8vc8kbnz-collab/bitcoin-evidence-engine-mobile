import "./globals.css";
import "./platform.css";
import type { Metadata, Viewport } from "next";
import { PwaRegister } from "@/components/PwaRegister";
import { Track } from "@/components/Track";
import { FlowRecorder } from "@/components/FlowRecorder";
import { ThemeColorSync } from "@/components/ThemeColorSync";

export const metadata: Metadata = {
  title: "Outrun IQ — Move inventory smarter.",
  description: "Professionele outletdeals van bedrijven, met transparante conditie en prijscontext.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, statusBarStyle: "black", title: "Outrun IQ" },
  icons: {
    icon: [{ url: "/icons/icon-192.png", sizes: "192x192" }, { url: "/icons/icon-512.png", sizes: "512x512" }],
    apple: "/icons/apple-touch-icon.png",
  },
};
export const viewport: Viewport = { themeColor: "#EEF5F0", width: "device-width", initialScale: 1, viewportFit: "cover" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="nl">
      <head>
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black" />
        <meta name="theme-color" content="#EEF5F0" />
      </head>
      <body><ThemeColorSync /><PwaRegister /><Track />{process.env.NEXT_PUBLIC_FLOW_RECORDER_ENABLED === "true" ? <FlowRecorder /> : null}{children}</body>
    </html>
  );
}
