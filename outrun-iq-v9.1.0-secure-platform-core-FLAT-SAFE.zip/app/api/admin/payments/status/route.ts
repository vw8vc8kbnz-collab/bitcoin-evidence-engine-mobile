import { NextResponse } from "next/server";
import { getUser, isAdmin } from "@/lib/auth";
import { paymentAdminStatus } from "@/lib/payments";

export const runtime = "nodejs";

export async function GET(_req: Request) {
  const user = await getUser();
  if (!isAdmin(user)) {
    return NextResponse.json({ error: "Alleen beheer" }, { status: 403 });
  }
  return NextResponse.json(await paymentAdminStatus());
}
