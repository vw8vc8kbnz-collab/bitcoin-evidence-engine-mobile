import { NextResponse, type NextRequest } from "next/server";
import { read } from "@/lib/store";
import { getUser, isAdmin } from "@/lib/auth";
import type { FlowEvent } from "@/lib/types";
export const runtime = "nodejs";

function maskSensitive(input?: unknown) {
  let s = String(input ?? "");
  s = s.replace(/([?&](?:pin|token|code|secret|key|session|auth|password)=)[^&#\s]+/gi, "$1•••");
  s = s.replace(/\b[A-Z0-9._%+-]+@([A-Z0-9.-]+\.[A-Z]{2,})\b/gi, "•••@$1");
  s = s.replace(/\b(?:sk|pk|rk|whsec|ntfy|ds)-[A-Za-z0-9_\-]{8,}\b/g, "•••KEY•••");
  s = s.replace(/\b\d{4}\s?[A-Z]{2}\b/gi, "••••••");
  s = s.replace(/\b(?:\d[ -]*?){13,19}\b/g, "••••CARD••••");
  return s;
}
const esc = (s: unknown) => maskSensitive(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c] as string));
function sanitizeEvent(e: FlowEvent): FlowEvent {
  return {
    ...e,
    path: maskSensitive(e.path),
    label: e.label ? maskSensitive(e.label) : undefined,
    target: e.target ? maskSensitive(e.target) : undefined,
    text: e.text ? maskSensitive(e.text) : undefined,
    html: e.html ? maskSensitive(e.html) : undefined,
    meta: e.meta ? Object.fromEntries(Object.entries(e.meta).map(([k, v]) => [maskSensitive(k), typeof v === "string" ? maskSensitive(v) : v])) : undefined,
  };
}
function jsonl(events: FlowEvent[]) { return events.map(e => JSON.stringify(sanitizeEvent(e))).join("\n") + (events.length ? "\n" : ""); }
function replayHtml(rawEvents: FlowEvent[]) {
  const events = rawEvents.map(sanitizeEvent);
  const sessions = [...new Set(events.map(e => e.sessionId))];
  const first = events.find(e => e.type === "snapshot" && e.html)?.html || "<main style='padding:24px;font-family:sans-serif'>Geen snapshots gevonden. Download JSONL voor click/API-log.</main>";
  return `<!doctype html><html lang="nl"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>Outrun Flow Replay</title><style>body{margin:0;background:#0b1114;color:#f8f8f3;font-family:system-ui,-apple-system,sans-serif}.bar{position:sticky;top:0;z-index:3;background:#10191d;padding:14px 16px;border-bottom:1px solid #273238;display:flex;gap:12px;align-items:center;flex-wrap:wrap}button,select{border:1px solid #344247;background:#172328;color:#fff;border-radius:12px;padding:10px 12px;font-weight:700}.wrap{display:grid;grid-template-columns:1fr 380px;gap:0;height:calc(100vh - 66px)}iframe{width:100%;height:100%;border:0;background:#f3f1eb}.side{overflow:auto;border-left:1px solid #273238;background:#0e171b}.ev{padding:10px 12px;border-bottom:1px solid #202c31;cursor:pointer}.ev:hover{background:#172328}.t{color:#f1a632;font-size:11px;font-weight:800;letter-spacing:.08em}.m{font-size:13px;color:#cbd3d8;word-break:break-word}.dot{display:inline-block;width:8px;height:8px;border-radius:99px;background:#2dd4bf;margin-right:6px}.api{background:#152026}@media(max-width:900px){.wrap{grid-template-columns:1fr}.side{height:42vh;border-left:0;border-top:1px solid #273238}}</style></head><body><div class="bar"><b>Outrun Flow Replay</b><span>${events.length} events · ${sessions.length} sessie(s) · masked</span><select id="session">${sessions.map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join("")}</select><button id="prev">Vorige snapshot</button><button id="next">Volgende snapshot</button></div><div class="wrap"><iframe id="frame" sandbox="allow-same-origin"></iframe><div class="side" id="events"></div></div><script>const all=${JSON.stringify(events).replace(/<\//g,"<\\/")};const frame=document.getElementById('frame');const side=document.getElementById('events');const sel=document.getElementById('session');let snaps=[],idx=0;function renderList(){const sid=sel.value;const evs=all.filter(e=>e.sessionId===sid);snaps=evs.filter(e=>e.type==='snapshot'&&e.html);idx=Math.max(0,Math.min(idx,snaps.length-1));side.innerHTML=evs.map((e,i)=>'<div class="ev '+(e.type==='api'?'api':'')+'" data-i="'+i+'"><div class="t"><span class="dot"></span>'+new Date(e.at).toLocaleString('nl-NL')+' · '+e.type.toUpperCase()+' · '+(e.role||'')+'</div><div class="m"><b>'+esc(e.path||'')+'</b><br/>'+(esc(e.label||e.text||e.target||''))+'</div></div>').join('');side.querySelectorAll('.ev').forEach((el,i)=>el.onclick=()=>{const e=evs[i];if(e.type==='snapshot'&&e.html){frame.srcdoc=e.html;}else{const prev=evs.slice(0,i).reverse().find(x=>x.type==='snapshot'&&x.html);if(prev)frame.srcdoc=prev.html;}});frame.srcdoc=snaps[idx]?.html||${JSON.stringify(first)};}document.getElementById('prev').onclick=()=>{idx=Math.max(0,idx-1);frame.srcdoc=snaps[idx]?.html||''};document.getElementById('next').onclick=()=>{idx=Math.min(snaps.length-1,idx+1);frame.srcdoc=snaps[idx]?.html||''};sel.onchange=()=>{idx=0;renderList()};renderList();function esc(s){return String(s??'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]))}</script></body></html>`;
}

export async function GET(req: NextRequest) {
  const me = await getUser();
  if (!isAdmin(me)) return NextResponse.json({ error: "Geen toegang" }, { status: 403 });
  const format = req.nextUrl.searchParams.get("format") || "jsonl";
  const db = await read();
  const events = [...(db.flowEvents ?? [])].sort((a, b) => a.at.localeCompare(b.at));
  if (format === "html") {
    return new NextResponse(replayHtml(events), { headers: { "Content-Type": "text/html; charset=utf-8", "Content-Disposition": `attachment; filename="outrun-flow-${new Date().toISOString()}.html"` } });
  }
  return new NextResponse(jsonl(events), { headers: { "Content-Type": "application/x-ndjson; charset=utf-8", "Content-Disposition": `attachment; filename="outrun-flow-${new Date().toISOString()}.jsonl.ndjson"` } });
}
