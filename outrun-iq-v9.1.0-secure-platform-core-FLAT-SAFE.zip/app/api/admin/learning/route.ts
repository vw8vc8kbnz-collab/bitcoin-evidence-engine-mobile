import { NextRequest, NextResponse } from "next/server";
import { getUser, isAdmin } from "@/lib/auth";
import { getLearningReport } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest) {
  const me = await getUser();
  if (!isAdmin(me)) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const report = await getLearningReport();
  return NextResponse.json(report);
}
