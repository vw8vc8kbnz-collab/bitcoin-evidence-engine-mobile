import { NextResponse, type NextRequest } from "next/server";
import { getUser, isAdmin } from "@/lib/auth";
import { mutate } from "@/lib/store";
import { slugify } from "@/lib/types";
import { audit } from "@/lib/audit";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const user = await getUser();
  if (!isAdmin(user)) return NextResponse.json({ error: "Geen toegang" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const out = await mutate(db => {
    const u = db.users.find(x => x.id === String(b.userId));
    if (!u?.partnerProfile) return { error: "Aanvraag niet gevonden" };
    if (b.approve === false) {
      u.partnerProfile.status = "rejected";
      u.partnerProfile.decidedAt = new Date().toISOString();
      audit(db, { actor: { type: "admin", id: user!.id, label: user!.email }, action: "partner.reject", entity: "partner", entityId: u.id, summary: `${u.partnerProfile.companyName} afgewezen`, meta: { email: u.email } });
      return { ok: true };
    }
    u.partnerProfile.status = "approved";
    u.partnerProfile.decidedAt = new Date().toISOString();
    u.role = "partner";
    let slug = slugify(u.partnerProfile.companyName) || "partner";
    while (db.sellers.some(s => s.slug === slug) && !db.users.some(x => x.id === u.id && x.partnerSlug === slug)) {
      slug += "-" + Math.random().toString(36).slice(2, 4);
    }
    u.partnerSlug = slug;
    if (!db.sellers.some(s => s.slug === slug)) {
      db.sellers.push({ slug, name: u.partnerProfile.companyName, city: u.partnerProfile.city, kvk: u.partnerProfile.kvk, createdAt: new Date().toISOString() });
    }
    db.notifications.push({
      id: Math.random().toString(36).slice(2, 10), userId: u.id, type: "systeem",
      title: "Partneraccount goedgekeurd", body: "Welkom bij Outrun IQ Partner. Je kunt nu listings plaatsen.",
      href: "/partner", read: false, at: new Date().toISOString(),
    });
    audit(db, { actor: { type: "admin", id: user!.id, label: user!.email }, action: "partner.approve", entity: "partner", entityId: u.id, summary: `${u.partnerProfile.companyName} goedgekeurd`, meta: { email: u.email, slug } });
    return { ok: true };
  });
  return "error" in out ? NextResponse.json(out, { status: 404 }) : NextResponse.json(out);
}
