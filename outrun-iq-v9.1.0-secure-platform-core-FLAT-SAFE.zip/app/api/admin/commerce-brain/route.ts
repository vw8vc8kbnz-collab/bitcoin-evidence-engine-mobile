import { NextRequest, NextResponse } from "next/server";
import { getUser, isAdmin } from "@/lib/auth";
import { getCommerceBrainReport } from "@/lib/data";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest) {
  const u = await getUser();
  if (!isAdmin(u)) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  return NextResponse.json(await getCommerceBrainReport());
}
