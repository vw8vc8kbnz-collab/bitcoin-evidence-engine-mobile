import { NextResponse, type NextRequest } from "next/server";
import { getUser, isAdmin } from "@/lib/auth";
import { resolveDispute } from "@/lib/data";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const user = await getUser();
  if (!isAdmin(user)) return NextResponse.json({ error: "Geen toegang" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const out = await resolveDispute(String(b.orderId), b.action === "cancel" ? "cancel" : "release");
  return "error" in out ? NextResponse.json(out, { status: 404 }) : NextResponse.json(out);
}
