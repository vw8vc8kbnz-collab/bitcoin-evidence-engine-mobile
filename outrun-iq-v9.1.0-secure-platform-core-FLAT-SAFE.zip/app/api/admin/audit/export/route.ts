import { NextResponse, type NextRequest } from "next/server";
import { read } from "@/lib/store";
import { getUser, isAdmin } from "@/lib/auth";
import { auditToCsv, auditToJsonl } from "@/lib/audit";
export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const me = await getUser();
  if (!isAdmin(me)) {
    return NextResponse.json({ error: "Geen toegang" }, { status: 401 });
  }
  const format = req.nextUrl.searchParams.get("format") === "csv" ? "csv" : "jsonl";
  const db = await read();
  const events = [...(db.auditLog ?? [])].sort((a, b) => a.at.localeCompare(b.at));
  const body = format === "csv" ? auditToCsv(events) : auditToJsonl(events);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  return new NextResponse(body, {
    status: 200,
    headers: {
      "Content-Type": format === "csv" ? "text/csv; charset=utf-8" : "application/x-ndjson; charset=utf-8",
      "Content-Disposition": `attachment; filename="outrun-iq-auditlog-${stamp}.${format === "csv" ? "csv" : "jsonl"}"`,
      "Cache-Control": "no-store",
    },
  });
}
