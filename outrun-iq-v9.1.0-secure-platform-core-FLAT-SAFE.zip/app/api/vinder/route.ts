import { NextResponse, type NextRequest } from "next/server";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { rankListingsForBuyer } from "@/lib/ai/brain";
import type { Listing } from "@/lib/types";
import { publicListings } from "@/lib/data";
export const runtime = "nodejs";

/** Prijsplafond uit de prompt: "max €600", "onder de 600", "tot 600 euro". */
function extractMaxPrice(p: string): number | undefined {
  const m = p.toLowerCase().match(/(?:max(?:imaal)?|onder(?: de)?|tot|<)\s*€?\s*(\d{2,5})/);
  return m ? Number(m[1]) : undefined;
}

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  if (!isPersonalBuyer(u)) return NextResponse.json({ error: "Alleen persoonlijke kopersaccounts" }, { status: 403 });
  const { prompt } = await req.json().catch(() => ({}));
  const q = String(prompt ?? "").trim();
  if (q.length < 3) return NextResponse.json({ error: "Beschrijf wat je zoekt (min. 3 tekens)" }, { status: 400 });

  const maxPrice = extractMaxPrice(q);
  const all = (await rankListingsForBuyer({ user: u, query: q, maxPrice, limit: 60 })).ranked.map(x => x.listing);
  if (all.length === 0) {
    return NextResponse.json({ listings: [], interpretation: maxPrice ? `Niets live onder €${maxPrice}.` : "Er staat nu niets live dat kan matchen.", source: "eenvoudig" });
  }

  const key = process.env.DEEPSEEK_API_KEY;
  if (key) {
    try {
      const catalog = all.slice(0, 60).map(l => ({
        id: l.id, titel: l.title, merk: l.brand ?? "", categorie: l.category,
        conditie: `${l.condition} (${l.conditionScore}/10)`, prijs: l.price, nieuwprijs: l.newPrice,
      }));
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 15_000);
      const res = await fetch(process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com/chat/completions", {
        method: "POST", signal: ctl.signal,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({
          model: process.env.DEEPSEEK_MODEL || "deepseek-chat",
          temperature: 0.1, response_format: { type: "json_object" },
          messages: [
            { role: "system", content: `Je bent de zoek-AI van een Nederlandse outlet-marketplace. Je krijgt een klantwens en de VOLLEDIGE live catalogus. Kies UITSLUITEND items die echt bij de wens passen — een half-passende categorie is GEEN match. Liever 0 resultaten dan ruis. Antwoord alleen JSON:
{"matches":[{"id":"","score":0}],"interpretation":""}
Regels: alleen id's uit de catalogus; score 0-100 = hoe goed dit item de wens vervult; neem alleen score >= 55 op; max 10; sorteer aflopend. "interpretation" = één NL-zin die samenvat wat je zocht en waarom deze matches (of waarom niets past).` },
            { role: "user", content: JSON.stringify({ wens: q.slice(0, 300), catalogus: catalog }) },
          ],
        }),
      });
      clearTimeout(t);
      if (res.ok) {
        const data = await res.json();
        const p = JSON.parse(String(data?.choices?.[0]?.message?.content ?? "{}").replace(/```json|```/g, ""));
        const ids: string[] = Array.isArray(p.matches)
          ? p.matches.filter((m: { score?: number }) => Number(m?.score) >= 55)
              .map((m: { id?: string }) => String(m?.id)).filter(Boolean)
          : [];
        const byId = new Map(all.map(l => [l.id, l]));
        const listings = ids.map(id => byId.get(id)).filter((l): l is Listing => !!l).slice(0, 10);
        return NextResponse.json({
          listings: publicListings(listings),
          interpretation: String(p.interpretation ?? "").slice(0, 200) || (listings.length ? "Beste matches op je wens." : "Geen sterke match in het huidige aanbod."),
          maxPrice,
        });
      }
      console.error("[ai-vinder] provider-status:", res.status);
    } catch (e) { console.error("[ai-vinder] fout:", e); }
  }

  const ranked = await rankListingsForBuyer({ user: u, query: q, maxPrice, limit: 10 });
  return NextResponse.json({
    listings: publicListings(ranked.ranked.map(x => x.listing)),
    scores: ranked.ranked.map(x => ({ id: x.listing.id, reason: x.ai.reason })),
    interpretation: ranked.ranked.length ? "Deze producten sluiten het best aan op je beschrijving en budget binnen de huidige live voorraad." : "Geen sterke match in het huidige aanbod.",
    maxPrice,
  });
}
