import { NextResponse } from "next/server";
import { APP_VERSION, RELEASE_NAME, COMMERCE_LIVE_READY } from "@/lib/version";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET() {
  return NextResponse.json({ ok: true, service: "outrun-iq", version: APP_VERSION, release: RELEASE_NAME, paymentMode: COMMERCE_LIVE_READY ? "live-capable" : "pilot-locked" }, { headers: { "Cache-Control": "no-store" } });
}
