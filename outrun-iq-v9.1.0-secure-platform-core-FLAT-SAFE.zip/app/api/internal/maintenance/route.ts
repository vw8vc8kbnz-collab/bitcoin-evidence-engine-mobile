import { NextResponse, type NextRequest } from "next/server";
import { flushBufferedViews, sweepCampaigns, sweepOrders } from "@/lib/data";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function authorized(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  return Boolean(secret && req.headers.get("authorization") === `Bearer ${secret}`);
}

export async function POST(req: NextRequest) {
  if (!authorized(req)) return NextResponse.json({ error: "Niet gevonden" }, { status: 404 });
  const [views, orders, campaigns] = await Promise.all([
    flushBufferedViews(),
    sweepOrders(),
    sweepCampaigns(),
  ]);
  return NextResponse.json({ ok: true, viewsFlushed: views, ordersAdvanced: orders, campaignsClosed: campaigns, at: new Date().toISOString() }, { headers: { "Cache-Control": "no-store" } });
}
