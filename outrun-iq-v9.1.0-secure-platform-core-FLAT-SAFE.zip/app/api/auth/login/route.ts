import { NextResponse, type NextRequest } from "next/server";
import { read } from "@/lib/store";
import { verifyPassword, createSession, SESSION_COOKIE, rateLimit, isApprovedPartner, sessionCookieOptions } from "@/lib/auth";
import { requestClientKey } from "@/lib/request-security";
import { scryptSync } from "node:crypto";
export const runtime = "nodejs";
const DUMMY_SALT = "8d86ea2a68804924ac159aa8405cc260";
const DUMMY_HASH = scryptSync("__outrun_invalid__", DUMMY_SALT, 64).toString("hex");

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const e = String(b.email ?? "").trim().toLowerCase();
  const pass = String(b.password ?? "");
  if (!rateLimit(`login:${requestClientKey(req.headers)}:${e}`, 8, 10 * 60_000)) {
    return NextResponse.json({ error: "Te veel pogingen. Wacht 10 minuten." }, { status: 429 });
  }
  if (b.accountType !== "zakelijk" && b.accountType !== "persoonlijk") {
    return NextResponse.json({ error: "Kies eerst of je persoonlijk of zakelijk wilt inloggen. Ververs de app als je deze melding blijft zien." }, { status: 400 });
  }
  const requested = b.accountType === "zakelijk" ? "zakelijk" : "persoonlijk";
  const db = await read();
  const candidates = db.users.filter(x => x.email === e);
  const adminMail = (process.env.ADMIN_EMAIL ?? "").trim().toLowerCase();

  // Gesloten werelden: dezelfde mail kan in oude testdata meerdere accounts hebben.
  // Zakelijk mag nooit naar admin of consument vallen.
  // Persoonlijk kiest eerst consument; admin-login mag alleen als ADMIN_EMAIL matcht.
  const u = requested === "zakelijk"
    ? candidates.find(x => x.role === "partner")
    : (candidates.find(x => x.role === "consument")
        ?? candidates.find(x => x.role === "admin" && x.email === adminMail));

  const passwordOk = verifyPassword(pass, u?.salt ?? DUMMY_SALT, u?.passHash ?? DUMMY_HASH);
  if (!u || !passwordOk) {
    return NextResponse.json({ error: "Inloggegevens onjuist voor het gekozen accounttype" }, { status: 401 });
  }

  const { token, expires } = await createSession(u.id);
  const res = NextResponse.json({ ok: true, role: u.role, partner: isApprovedPartner(u), partnerPending: u.partnerProfile?.status === "pending", name: u.name });
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expires));
  return res;
}
