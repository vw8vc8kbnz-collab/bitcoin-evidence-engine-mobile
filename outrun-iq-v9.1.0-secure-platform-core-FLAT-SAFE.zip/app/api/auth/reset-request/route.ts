import { NextResponse, type NextRequest } from "next/server";
import { mutate, read } from "@/lib/store";
import { rateLimit } from "@/lib/auth";
import { sendMail } from "@/lib/mail";
import { createOneTimeCode } from "@/lib/security";
import { requestClientKey } from "@/lib/request-security";
export const runtime = "nodejs";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export async function POST(req: NextRequest) {
  const { email } = await req.json().catch(() => ({}));
  const e = String(email ?? "").trim().toLowerCase();
  if (!EMAIL_RE.test(e)) return NextResponse.json({ error: "Ongeldig e-mailadres" }, { status: 400 });
  if (!rateLimit(`reset:${requestClientKey(req.headers)}:${e}`, 4, 10 * 60_000)) return NextResponse.json({ error: "Te veel pogingen. Probeer het later opnieuw." }, { status: 429 });
  const db = await read();
  if (db.users.some(u => u.email === e)) {
    const { code, record } = createOneTimeCode(e, "reset");
    await mutate(d => { d.codes = d.codes.filter(c => !(c.email === e && c.purpose === "reset") && new Date(c.expiresAt) > new Date()); d.codes.push(record); });
    const sent = await sendMail(e, "Wachtwoord herstellen — Outrun IQ", `Herstelcode: ${code} (15 minuten geldig)`);
    if (!sent) await mutate(d => { d.codes = d.codes.filter(c => !(c.email === e && c.codeHash === record.codeHash)); });
  }
  return NextResponse.json({ ok: true });
}
