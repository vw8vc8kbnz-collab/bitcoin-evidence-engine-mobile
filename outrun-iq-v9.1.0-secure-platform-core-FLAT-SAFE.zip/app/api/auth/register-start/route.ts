import { NextResponse, type NextRequest } from "next/server";
import { mutate, read } from "@/lib/store";
import { rateLimit } from "@/lib/auth";
import { sendMail } from "@/lib/mail";
import { createOneTimeCode } from "@/lib/security";
import { requestClientKey } from "@/lib/request-security";
export const runtime = "nodejs";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export async function POST(req: NextRequest) {
  const { email } = await req.json().catch(() => ({}));
  const e = String(email ?? "").trim().toLowerCase();
  if (!EMAIL_RE.test(e)) return NextResponse.json({ error: "Ongeldig e-mailadres" }, { status: 400 });
  if (!rateLimit(`code:${requestClientKey(req.headers)}:${e}`, 4, 10 * 60_000)) return NextResponse.json({ error: "Te veel pogingen. Probeer het later opnieuw." }, { status: 429 });
  const db = await read();
  if (db.users.some(u => u.email === e)) {
    await sendMail(e, "Er bestaat al een Outrun IQ-account", "Er is geprobeerd opnieuw te registreren met dit e-mailadres. Log in of gebruik wachtwoord herstellen als jij dit was.");
    return NextResponse.json({ ok: true });
  }
  const { code, record } = createOneTimeCode(e, "register");
  await mutate(d => { d.codes = d.codes.filter(c => !(c.email === e && (c.purpose ?? "register") === "register") && new Date(c.expiresAt) > new Date()); d.codes.push(record); });
  const sent = await sendMail(e, "Je Outrun IQ verificatiecode", `Code: ${code} (15 minuten geldig)`);
  if (!sent) {
    await mutate(d => { d.codes = d.codes.filter(c => c !== record && !(c.email === e && c.codeHash === record.codeHash)); });
    return NextResponse.json({ error: "De verificatiemail kon niet veilig worden verstuurd. Probeer het later opnieuw." }, { status: 503 });
  }
  return NextResponse.json({ ok: true });
}
