import { NextResponse, type NextRequest } from "next/server";
import { getUser, verifyPassword, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth";
import { randomBytes } from "node:crypto";
import { mutate } from "@/lib/store";
export const runtime = "nodejs";

/** AVG: account verwijderen. Persoonsgegevens geanonimiseerd; orders blijven
 *  (fiscale bewaarplicht) maar zijn niet meer tot de persoon herleidbaar via het account. */
export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const out = await mutate(db => {
    const me = db.users.find(x => x.id === u.id);
    if (!me) return { error: "Account niet gevonden" };
    if (!verifyPassword(String(b.password ?? ""), me.salt, me.passHash)) {
      return { error: "Wachtwoord onjuist" };
    }
    if (me.partnerSlug && db.listings.some(l => l.sellerSlug === me.partnerSlug && (l.status === "published" || l.status === "active"))) {
      return { error: "Zet eerst je actieve listings uit (Voorraad) voordat je je account verwijdert" };
    }
    if (db.orders.some(o => (o.buyerId === me.id || o.sellerSlug === me.partnerSlug)
        && !["paid_out", "cancelled"].includes(o.status))) {
      return { error: "Er lopen nog orders — rond die eerst af" };
    }
    me.email = `verwijderd-${me.id}@account.invalid`;
    me.name = "Verwijderd account";
    const junk = randomBytes(32).toString("hex");
    me.salt = junk; me.passHash = junk;
    me.partnerProfile = undefined;
    db.sessions = db.sessions.filter(s => s.userId !== me.id);
    db.saved = db.saved.filter(s => s.userId !== me.id);
    db.notifications = db.notifications.filter(n => n.userId !== me.id);
    return { ok: true };
  });
  if ("error" in out) return NextResponse.json(out, { status: 400 });
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, "", { ...sessionCookieOptions(new Date(0)), maxAge: 0 });
  return res;
}
