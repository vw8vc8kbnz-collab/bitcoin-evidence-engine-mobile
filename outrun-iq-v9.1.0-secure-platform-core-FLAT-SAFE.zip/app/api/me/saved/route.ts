import { NextResponse, type NextRequest } from "next/server";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { toggleSaved, getSaved } from "@/lib/data";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  if (!isPersonalBuyer(u)) return NextResponse.json({ error: "Alleen persoonlijke kopersaccounts" }, { status: 403 });
  const saved = await getSaved(u.id);
  return NextResponse.json({ ids: saved.map(s => s.item.listingId) });
}

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  if (!isPersonalBuyer(u)) return NextResponse.json({ error: "Alleen persoonlijke kopersaccounts" }, { status: 403 });
  const { listingId, listingIds } = await req.json().catch(() => ({}));
  if (Array.isArray(listingIds)) { // migratie vanuit localStorage
    const existing = new Set((await getSaved(u.id)).map(s => s.item.listingId));
    for (const id0 of listingIds.slice(0, 50)) { const id = String(id0); if (!existing.has(id)) await toggleSaved(u.id, id); }
    return NextResponse.json({ ok: true });
  }
  if (!listingId) return NextResponse.json({ error: "listingId verplicht" }, { status: 400 });
  const on = await toggleSaved(u.id, String(listingId));
  return NextResponse.json({ on });
}
