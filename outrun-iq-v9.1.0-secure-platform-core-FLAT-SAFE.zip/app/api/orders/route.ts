import { NextResponse, type NextRequest } from "next/server";
import { createOrder } from "@/lib/data";
import { getUser, isPersonalBuyer } from "@/lib/auth";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in om te bestellen" }, { status: 401 });
  if (!isPersonalBuyer(u)) return NextResponse.json({ error: "Alleen persoonlijke kopersaccounts" }, { status: 403 });
  const b = await req.json().catch(() => null);
  if (!b?.listingId) return NextResponse.json({ error: "listingId verplicht" }, { status: 400 });
  const choice = b.delivery === "ophalen" ? "ophalen" : "bezorgen";
  let address;
  if (choice === "bezorgen") {
    const a = b.address ?? {};
    const name = String(a.name ?? "").trim().slice(0, 60);
    const street = String(a.street ?? "").trim().slice(0, 80);
    const postcode = String(a.postcode ?? "").toUpperCase().replace(/\s+/g, " ").trim();
    const city = String(a.city ?? "").trim().slice(0, 40);
    if (street.length < 3 || !/^\d{4}\s?[A-Z]{2}$/.test(postcode) || city.length < 2) {
      return NextResponse.json({ error: "Vul een geldig bezorgadres in (straat + nr, postcode 1234 AB, plaats)" }, { status: 400 });
    }
    address = { name: name || undefined, street, postcode, city };
  }
  const requestId = String(b.requestId ?? "").trim();
  if (!/^[A-Za-z0-9:_-]{12,100}$/.test(requestId)) return NextResponse.json({ error: "Ongeldige checkout-opdracht" }, { status: 400 });
  const out = await createOrder(u.id, String(b.listingId), choice, address, b.bidId ? String(b.bidId) : undefined, requestId);
  if ("error" in out) return NextResponse.json(out, { status: 409 });
  return NextResponse.json({ id: out.id });
}
