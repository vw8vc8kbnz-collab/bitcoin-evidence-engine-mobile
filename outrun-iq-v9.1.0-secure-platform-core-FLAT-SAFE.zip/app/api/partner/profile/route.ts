import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { mutate } from "@/lib/store";
export const runtime = "nodejs";

const clean = (v: unknown, max: number) => String(v ?? "").trim().slice(0, max);

export async function PATCH(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const out = await mutate(db => {
    const s = db.sellers.find(x => x.slug === u!.partnerSlug);
    if (!s) return { error: "Storefront niet gevonden" };

    const companyName = clean(b.companyName, 80);
    if (companyName.length >= 2) s.name = companyName;
    const kvk = clean(b.kvk, 20); if (kvk) s.kvk = kvk;
    const vat = clean(b.vatNumber, 32); if (vat) s.vatNumber = vat;
    s.contactPerson = clean(b.contactPerson, 60) || undefined;
    const businessEmail = clean(b.businessEmail, 90).toLowerCase();
    if (businessEmail) {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(businessEmail)) return { error: "Vul een geldig zakelijk e-mailadres in" };
      s.businessEmail = businessEmail;
    }
    s.businessPhone = clean(b.businessPhone, 24) || undefined;

    const setStorefrontMedia = (field: "logo" | "banner", value: unknown) => {
      if (typeof value !== "string") return null;
      const next = value.trim();
      const previous = field === "logo" ? s.logo : s.banner;
      if (!next) {
        if (field === "logo") s.logo = undefined; else s.banner = undefined;
        const old = (db.mediaAssets ?? []).find(a => a.url === previous && a.ownerSellerSlug === s.slug);
        if (old && !db.listings.some(l => [...(l.photos || []), ...(l.internalPhotos || [])].includes(old.url))) old.visibility = "private";
        return null;
      }
      if (!/^\/uploads\/[A-Za-z0-9._-]+$/.test(next)) return { error: "Ongeldige upload-URL" };
      const asset = (db.mediaAssets ?? []).find(a => a.url === next);
      const legacyOwned = previous === next || db.listings.some(l => l.sellerSlug === s.slug && [...(l.photos || []), ...(l.internalPhotos || [])].includes(next));
      if ((!asset || asset.ownerSellerSlug !== s.slug) && !legacyOwned) return { error: "Deze upload hoort niet bij jouw partneraccount" };
      if (asset) {
        asset.visibility = "public";
        asset.purpose = field;
        asset.publishedAt = new Date().toISOString();
      }
      if (field === "logo") s.logo = next; else s.banner = next;
      return null;
    };
    const logoError = setStorefrontMedia("logo", b.logoUrl); if (logoError) return logoError;
    const bannerError = setStorefrontMedia("banner", b.bannerUrl); if (bannerError) return bannerError;
    if (typeof b.about === "string") s.about = b.about.trim().slice(0, 420) || undefined;

    if (Array.isArray(b.deliveryOptions)) s.deliveryOptions = b.deliveryOptions.map((x: unknown) => clean(x, 32)).filter(Boolean).slice(0, 6);
    if (b.shippingCost !== undefined && b.shippingCost !== "") s.shippingCost = Math.max(0, Math.round(Number(b.shippingCost) || 0));

    if (b.payout && typeof b.payout === "object") {
      const status = ["missing", "pending", "verified"].includes(String(b.payout.bankStatus)) ? String(b.payout.bankStatus) as "missing" | "pending" | "verified" : "missing";
      s.payout = { bankStatus: status, ibanMasked: clean(b.payout.ibanMasked, 24) || undefined };
    }
    s.stripeConnect ??= { status: "not_started" };

    if (b.support) {
      const email = String(b.support.email ?? "").trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return { error: "Vul een geldig klantenservice-e-mailadres in" };
      s.support = { email, phone: clean(b.support.phone, 24) || undefined, returnsInfo: clean(b.support.returnsInfo, 420) || undefined };
    }
    if (b.address) {
      const street = clean(b.address.street, 80);
      const postcode = String(b.address.postcode ?? "").toUpperCase().replace(/\s+/g, " ").trim();
      const city = clean(b.address.city, 40);
      if (street.length < 3 || !/^\d{4}\s?[A-Z]{2}$/.test(postcode) || city.length < 2) return { error: "Vul een geldig afhaaladres in (straat + nr, postcode 1234 AB, plaats)" };
      s.address = { street, postcode, city };
      s.city = city;
    }
    return { ok: true, logo: s.logo ?? null, onboarding: { company: !!s.name, kvk: !!s.kvk, vat: !!s.vatNumber, contact: !!(s.contactPerson && s.businessEmail), support: !!s.support?.email, address: !!s.address, payout: s.payout?.bankStatus ?? "missing", stripe: s.stripeConnect?.status ?? "not_started" } };
  });
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}
