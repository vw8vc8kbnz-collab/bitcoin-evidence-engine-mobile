import { NextResponse } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { getPromotionCampaigns } from "@/lib/data";
export const runtime = "nodejs";

export async function GET() {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen partners" }, { status: 403 });
  return NextResponse.json({
    mode: "locked",
    reason: "Promote wordt pas geactiveerd na betrouwbare betalingen, attributie en sponsored-disclosure.",
    campaigns: await getPromotionCampaigns(u.partnerSlug),
  });
}

export async function POST() {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen partners" }, { status: 403 });
  return NextResponse.json({
    error: "Promote is in v9.1.0 bewust vergrendeld. Er wordt geen budget gereserveerd en er start geen campagne.",
    code: "PROMOTE_PILOT_LOCKED",
  }, { status: 423 });
}
