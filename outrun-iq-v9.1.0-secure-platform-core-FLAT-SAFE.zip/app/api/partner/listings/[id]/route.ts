import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { mutate } from "@/lib/store";
import { getListingReviewChecklist, reviewChecklistReady } from "@/lib/data";
import { audit } from "@/lib/audit";
export const runtime = "nodejs";

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUser();
  if (!isApprovedPartner(user) || !user?.partnerSlug) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const { id } = await ctx.params; const body = await req.json().catch(() => ({}));
  const out = await mutate(db => {
    const l = db.listings.find(x => x.id === id);
    if (!l || l.sellerSlug !== user.partnerSlug) return { error: "Niet jouw listing" };
    if (body.action === "pause" && ["published","active"].includes(l.status)) { const from=l.status; l.status="archived"; audit(db,{actor:{type:"partner",id:user.id,label:user.email},action:"listing.pause",entity:"listing",entityId:id,summary:`${l.title}: ${from} → archived`}); return {ok:true}; }
    if (body.action === "activate") {
      l.reviewChecklist = getListingReviewChecklist(l);
      if (!reviewChecklistReady(l.reviewChecklist)) return { error: "Listing mist verplichte menselijke bevestigingen of content" };
      const from=l.status; l.status=l.stock>0?"published":"sold";
      if (l.status === "published") for (const asset of db.mediaAssets ?? []) if (asset.ownerSellerSlug === l.sellerSlug && l.photos.includes(asset.url)) { asset.visibility="public"; asset.listingId=l.id; asset.publishedAt=new Date().toISOString(); }
      audit(db,{actor:{type:"partner",id:user.id,label:user.email},action:"listing.activate",entity:"listing",entityId:id,summary:`${l.title}: ${from} → ${l.status}`}); return {ok:true};
    }
    if (body.action === "price") {
      const p=Math.round(Number(body.price)); if(!(p>0&&p<l.newPrice))return{error:"Prijs moet > 0 en onder de nieuwprijs blijven"};
      const from=l.price;(l.priceLog??=[]).push({at:new Date().toISOString(),from,to:p});l.price=p;l.confirmations={...(l.confirmations||{}),pricing:{status:"user_confirmed",byUserId:user.id,at:new Date().toISOString()}};l.reviewChecklist=getListingReviewChecklist(l);audit(db,{actor:{type:"partner",id:user.id,label:user.email},action:"listing.price",entity:"listing",entityId:id,summary:`${l.title}: prijs ${from} → ${p}`});return{ok:true};
    }
    return { error: "Onbekende actie" };
  });
  return "error" in out ? NextResponse.json(out,{status:400}) : NextResponse.json(out);
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user=await getUser(); if(!isApprovedPartner(user)||!user?.partnerSlug)return NextResponse.json({error:"Alleen voor goedgekeurde partners"},{status:403});
  const {id}=await ctx.params; const out=await mutate(db=>{const l=db.listings.find(x=>x.id===id);if(!l||l.sellerSlug!==user.partnerSlug)return{error:"Niet jouw listing"};const from=l.status;l.status="archived";l.stock=0;audit(db,{actor:{type:"partner",id:user.id,label:user.email},action:"listing.archive",entity:"listing",entityId:id,summary:`${l.title}: ${from} → archived`});return{ok:true};});
  return "error" in out?NextResponse.json(out,{status:404}):NextResponse.json(out);
}
