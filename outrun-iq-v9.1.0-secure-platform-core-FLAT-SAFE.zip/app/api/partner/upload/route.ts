import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { promises as fs } from "fs";
import path from "path";
import { UPLOAD_DIR, mutate } from "@/lib/store";
import { makeMediaAsset, processUploadedImage } from "@/lib/media";
export const runtime = "nodejs";

const MAX = 8 * 1024 * 1024;
const MAX_TOTAL = 30 * 1024 * 1024;
const MAX_PHOTOS_PER_PRODUCT = 5;

export async function POST(req: NextRequest) {
  const user = await getUser();
  if (!isApprovedPartner(user) || !user?.partnerSlug) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const form = await req.formData();
  const files = form.getAll("photos").filter((f): f is File => f instanceof File);
  if (!files.length) return NextResponse.json({ error: "Geen bestanden" }, { status: 400 });
  if (files.length > MAX_PHOTOS_PER_PRODUCT) return NextResponse.json({ error: `Maximaal ${MAX_PHOTOS_PER_PRODUCT} foto's per product` }, { status: 400 });
  if (files.reduce((sum, file) => sum + file.size, 0) > MAX_TOTAL) return NextResponse.json({ error: "Totale upload is groter dan 30MB" }, { status: 413 });

  const prepared: { buffer: Buffer; asset: ReturnType<typeof makeMediaAsset> }[] = [];
  for (const file of files) {
    if (file.size > MAX) return NextResponse.json({ error: "Foto groter dan 8MB" }, { status: 413 });
    const original = Buffer.from(await file.arrayBuffer());
    try {
      const processed = await processUploadedImage(original, file.type);
      prepared.push({
        buffer: processed.buffer,
        asset: makeMediaAsset(user.partnerSlug, processed.buffer, processed.mimeType, { width: processed.width, height: processed.height }),
      });
    } catch (error) {
      console.warn("[upload] image rejected", error instanceof Error ? error.message : error);
      return NextResponse.json({ error: "Deze foto kon niet veilig worden verwerkt. Gebruik een normale JPEG, PNG, WebP of HEIC-foto." }, { status: 415 });
    }
  }

  await fs.mkdir(UPLOAD_DIR, { recursive: true, mode: 0o700 });
  const written: string[] = [];
  try {
    for (const { buffer, asset } of prepared) {
      const target = path.join(UPLOAD_DIR, asset.filename);
      await fs.writeFile(target, buffer, { mode: 0o600, flag: "wx" });
      written.push(target);
    }
    const assets = prepared.map(x => x.asset);
    await mutate(db => { db.mediaAssets ??= []; db.mediaAssets.push(...assets); });
    return NextResponse.json({ urls: assets.map(a => a.url), assets: assets.map(a => ({ id: a.id, url: a.url, visibility: a.visibility })) });
  } catch (error) {
    await Promise.all(written.map(file => fs.unlink(file).catch(() => undefined)));
    console.error("[upload] atomic upload failed", error);
    return NextResponse.json({ error: "Upload kon niet veilig worden opgeslagen" }, { status: 500 });
  }
}
