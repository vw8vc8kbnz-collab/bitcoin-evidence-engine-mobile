import { NextResponse, type NextRequest } from "next/server";
import { isTrustedMutationOrigin } from "@/lib/request-security";

const AUTH_PREFIXES = ["/account","/bewaard","/meldingen","/checkout","/order","/partner","/api/me","/api/orders","/api/bids","/api/partner","/api/push"];
const MUTATING = new Set(["POST","PUT","PATCH","DELETE"]);

function matches(pathname: string, prefixes: string[]) {
  return prefixes.some(p => pathname === p || pathname.startsWith(`${p}/`));
}

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const hasSession = Boolean(req.cookies.get("oiq_sessie")?.value);

  // Browsermutaties moeten same-origin zijn. Stripe is een server-to-server webhook.
  if (pathname.startsWith("/api/") && pathname !== "/api/stripe/webhook" && MUTATING.has(req.method)) {
    const trusted = isTrustedMutationOrigin({
      secFetchSite: req.headers.get("sec-fetch-site"),
      origin: req.headers.get("origin"),
      host: req.headers.get("host"),
      forwardedHost: req.headers.get("x-forwarded-host"),
      forwardedProto: req.headers.get("x-forwarded-proto"),
    });
    if (!trusted) return NextResponse.json({ error: "Ongeldige request-origin" }, { status: 403 });
  }

  if ((pathname.startsWith("/beheer") || pathname.startsWith("/api/admin")) && !hasSession) {
    if (pathname.startsWith("/api/")) return NextResponse.json({ error: "Log in" }, { status: 401 });
    const url = req.nextUrl.clone(); url.pathname = "/welkom"; url.searchParams.set("next", pathname); return NextResponse.redirect(url);
  }
  if (matches(pathname, AUTH_PREFIXES) && !hasSession) {
    if (pathname.startsWith("/api/")) return NextResponse.json({ error: "Log in" }, { status: 401 });
    const url = req.nextUrl.clone(); url.pathname = "/welkom"; url.searchParams.set("next", pathname); return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
