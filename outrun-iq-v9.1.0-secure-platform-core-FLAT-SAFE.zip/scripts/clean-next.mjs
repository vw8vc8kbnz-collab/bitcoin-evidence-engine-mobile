import { rmSync } from "node:fs";
import { join } from "node:path";

const output = join(process.cwd(), ".next");
rmSync(output, { recursive: true, force: true });
console.log("Schone Next-buildoutput voorbereid.");
