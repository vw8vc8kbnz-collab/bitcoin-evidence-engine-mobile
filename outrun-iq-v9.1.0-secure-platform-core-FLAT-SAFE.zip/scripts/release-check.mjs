import { readFileSync, existsSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";

const root = process.cwd();
const read = (p) => readFileSync(join(root, p), "utf8");
const fail = (message) => { console.error(`RELEASE CHECK FAILED: ${message}`); process.exitCode = 1; };
const walk = (dir) => {
  const abs = join(root, dir);
  if (!existsSync(abs)) return [];
  return readdirSync(abs).flatMap(name => {
    const file = join(abs, name);
    return statSync(file).isDirectory() ? walk(relative(root, file)) : [relative(root, file)];
  });
};
const sourceFiles = [...walk("app"), ...walk("components"), ...walk("lib")].filter(f => /\.(ts|tsx|mjs)$/.test(f));
const pkg = JSON.parse(read("package.json"));
const version = read("VERSION.txt").trim();
const versionSource = read("lib/version.ts");

if (pkg.version !== version) fail(`package.json ${pkg.version} != VERSION.txt ${version}`);
if (!versionSource.includes(`APP_VERSION = "${version}"`)) fail("lib/version.ts loopt niet gelijk met VERSION.txt");
if (!versionSource.includes("COMMERCE_LIVE_READY = false")) fail("commerce moet in deze release hard vergrendeld zijn");
if (existsSync(join(root, "app/api/auth/dummy-login")) || existsSync(join(root, "app/api/auth/test-login"))) fail("testloginroute aanwezig");

const forbiddenNeedles = ["ADMIN_PIN", "DUMMY_LOGIN_ENABLED", "NEXT_PUBLIC_DUMMY_LOGIN_ENABLED", "TEST_MODE_ENABLED", "NEXT_PUBLIC_TEST_MODE_ENABLED"];
for (const file of [...sourceFiles, ".env.example"]) {
  const body = read(file);
  for (const needle of forbiddenNeedles) if (body.includes(needle)) fail(`${needle} aanwezig in ${file}`);
}

const publicProjection = read("lib/public-listing.ts");
if (/return\s*{\s*\.\.\.\s*l\b/s.test(publicProjection)) fail("publieke listingprojectie gebruikt object spread");
for (const key of ["partnerRef","internalPhotos","visionMetadata","seo","reviewChecklist","confirmations","priceLog","confidence","comps","aiSource"]) {
  if (!publicProjection.includes(`"${key}"`)) fail(`verboden public key ${key} ontbreekt in contracttestlijst`);
}

for (const page of ["app/(buyer)/listing/[id]/page.tsx", "app/(buyer)/@modal/(.)listing/[id]/page.tsx"]) {
  const body = read(page);
  if (!body.includes("getPublicListingContext")) fail(`${page} gebruikt niet de publieke contextquery`);
  if (body.includes("getListing(")) fail(`${page} gebruikt intern listingrecord`);
}
for (const page of ["app/(buyer)/checkout/[id]/page.tsx", "app/(buyer)/order/[id]/page.tsx"]) {
  if (read(page).includes("getListing(")) fail(`${page} gebruikt intern listingrecord`);
}

if (!read("app/api/partner/promote/route.ts").includes("PROMOTE_PILOT_LOCKED")) fail("Promote API is niet hard vergrendeld");
if (/homeBrain|buildHome/.test(read("app/(buyer)/page.tsx"))) fail("homepage roept AI-homebrain aan");
for (const file of ["app/(buyer)/order/[id]/page.tsx", "app/partner/orders/page.tsx", "app/partner/page.tsx", "app/beheer/page.tsx"]) {
  if (read(file).includes("sweepOrders(")) fail(`${file} start sweep tijdens paginalaad`);
}

for (const [dir, guard] of [["app/api/admin", "isAdmin("], ["app/api/partner", "isApprovedPartner("], ["app/api/me", "isPersonalBuyer("]]) {
  for (const file of walk(dir).filter(f => f.endsWith("route.ts"))) if (!read(file).includes(guard)) fail(`${file} mist ${guard}`);
}

if (!pkg.scripts?.lint || !pkg.scripts?.typecheck || !pkg.scripts?.test || !pkg.scripts?.build) fail("release scripts ontbreken");
if (!pkg.dependencies?.sharp) fail("server-side media sanitization dependency ontbreekt");
if (!existsSync(join(root, "next.config.mjs")) || !existsSync(join(root, "package-lock.json"))) fail("build- of lockbestand ontbreekt");
if (!pkg.scripts?.build?.includes("clean-next.mjs") || !existsSync(join(root, "scripts/clean-next.mjs"))) fail("reproduceerbare clean-buildstap ontbreekt");

if (!process.exitCode) console.log(`Releasecontract OK — Outrun IQ ${version}`);
