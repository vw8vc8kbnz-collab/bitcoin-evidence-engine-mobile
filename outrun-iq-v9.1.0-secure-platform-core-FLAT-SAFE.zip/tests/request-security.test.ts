import test from "node:test";
import assert from "node:assert/strict";
import { isTrustedMutationOrigin } from "../lib/request-security";

test("reverse proxy origin wordt correct vertrouwd", () => {
  assert.equal(isTrustedMutationOrigin({
    origin: "https://outruniq.nl", secFetchSite: "same-origin",
    host: "127.0.0.1:8795", forwardedHost: "outruniq.nl", forwardedProto: "https",
  }), true);
});

test("cross-site en host mismatch worden geblokkeerd", () => {
  assert.equal(isTrustedMutationOrigin({ origin: "https://evil.example", secFetchSite: "cross-site", host: "outruniq.nl", forwardedHost: null, forwardedProto: "https" }), false);
  assert.equal(isTrustedMutationOrigin({ origin: "https://evil.example", secFetchSite: null, host: "outruniq.nl", forwardedHost: null, forwardedProto: "https" }), false);
});

import { requestClientKey } from "../lib/request-security";

test("rate-limit sleutel gebruikt vertrouwde proxyheaders en normaliseert invoer", () => {
  const headers = new Headers({ "x-real-ip": "203.0.113.8<script>", "x-forwarded-for": "1.1.1.1, 10.0.0.2" });
  assert.equal(requestClientKey(headers), "203.0.113.8script");
  const forwarded = new Headers({ "x-forwarded-for": "1.1.1.1, 198.51.100.9" });
  assert.equal(requestClientKey(forwarded), "198.51.100.9");
});
