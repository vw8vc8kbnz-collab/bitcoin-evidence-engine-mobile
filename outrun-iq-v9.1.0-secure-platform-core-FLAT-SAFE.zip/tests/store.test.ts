import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

const root = process.cwd();
function run(code: string, dataDir: string) {
  return spawnSync(process.execPath, ["--import", "tsx", "--input-type=module", "-e", code], {
    cwd: root,
    env: { ...process.env, DATA_DIR: dataDir },
    encoding: "utf8",
  });
}

test("corrupte database faalt gesloten en wordt niet overschreven", () => {
  const dir = mkdtempSync(path.join(tmpdir(), "oiq-corrupt-"));
  try {
    mkdirSync(dir, { recursive: true });
    const db = path.join(dir, "db.json");
    writeFileSync(db, "{kapot", "utf8");
    const result = run(`const { read } = (await import('./lib/store.ts')).default; await read();`, dir);
    assert.notEqual(result.status, 0);
    assert.equal(readFileSync(db, "utf8"), "{kapot");
    assert.match(result.stderr, /Database kon niet veilig worden geladen/);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test("mislukte mutatie verandert geheugen noch disk", () => {
  const dir = mkdtempSync(path.join(tmpdir(), "oiq-rollback-"));
  try {
    const result = run(`
      const { mutate, read } = (await import('./lib/store.ts')).default;
      await mutate(db => { db.counters.order = 1; });
      try { await mutate(db => { db.counters.order = 99; throw new Error('stop'); }); } catch {}
      const current = await read();
      if (current.counters.order !== 1) throw new Error('rollback mislukt: '+current.counters.order);
    `, dir);
    assert.equal(result.status, 0, result.stderr || result.stdout);
    const saved = JSON.parse(readFileSync(path.join(dir, "db.json"), "utf8"));
    assert.equal(saved.counters.order, 1);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
