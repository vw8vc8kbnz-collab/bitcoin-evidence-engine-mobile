import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

test("checkout retry maakt geen dubbele order of voorraadmutatie", () => {
  const dir = mkdtempSync(path.join(tmpdir(), "oiq-order-"));
  try {
    const code = `
      const { mutate, read } = (await import('./lib/store.ts')).default;
      const { createOrder } = (await import('./lib/data.ts')).default;
      await mutate(db => {
        db.users.push({ id:'buyer', email:'buyer@example.com', name:'Buyer', salt:'x', passHash:'x', role:'consument', createdAt:new Date().toISOString() });
        db.listings.push({ id:'listing', sellerSlug:'seller', title:'Testproduct', category:'overig', condition:'Retour', conditionScore:8, photos:['/uploads/x.webp'], fallback:'tv', stock:2, perUnit:false, newPrice:200, price:100, delivery:'Ophalen', deliveryPrice:0, pickupCity:'Utrecht', status:'published', createdAt:new Date().toISOString(), views:0 });
      });
      const a = await createOrder('buyer','listing','ophalen',undefined,undefined,'checkout-command-123');
      const b = await createOrder('buyer','listing','ophalen',undefined,undefined,'checkout-command-123');
      const db = await read();
      if ('error' in a || 'error' in b) throw new Error('order error');
      if (a.id !== b.id || db.orders.length !== 1 || db.listings[0].stock !== 1) throw new Error(JSON.stringify({a,b,orders:db.orders.length,stock:db.listings[0].stock}));
    `;
    const result = spawnSync(process.execPath, ["--import", "tsx", "--input-type=module", "-e", code], {
      cwd: process.cwd(), env: { ...process.env, DATA_DIR: dir }, encoding: "utf8",
    });
    assert.equal(result.status, 0, result.stderr || result.stdout);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
