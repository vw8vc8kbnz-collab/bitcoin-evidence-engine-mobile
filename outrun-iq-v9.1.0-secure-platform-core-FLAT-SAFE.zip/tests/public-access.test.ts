import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

test("draft en uitverkochte listing zijn nooit publiek op directe ID", () => {
  const dir = mkdtempSync(path.join(tmpdir(), "oiq-public-"));
  try {
    const code = `
      const { mutate } = (await import('./lib/store.ts')).default;
      const { getPublicListing } = (await import('./lib/data.ts')).default;
      const base = { sellerSlug:'seller', title:'Product', category:'overig', condition:'Retour', conditionScore:8, photos:['/uploads/x.webp'], fallback:'tv', perUnit:false, newPrice:200, price:100, delivery:'Ophalen', deliveryPrice:0, pickupCity:'Utrecht', createdAt:new Date().toISOString(), views:0 };
      await mutate(db => db.listings.push(
        { ...base, id:'draft', stock:1, status:'needs_review' },
        { ...base, id:'soldout', stock:0, status:'published' },
        { ...base, id:'live', stock:1, status:'published' }
      ));
      if (await getPublicListing('draft')) throw new Error('draft lekt');
      if (await getPublicListing('soldout')) throw new Error('uitverkocht lekt');
      if (!(await getPublicListing('live'))) throw new Error('live ontbreekt');
    `;
    const result = spawnSync(process.execPath, ["--import", "tsx", "--input-type=module", "-e", code], {
      cwd: process.cwd(), env: { ...process.env, DATA_DIR: dir }, encoding: "utf8",
    });
    assert.equal(result.status, 0, result.stderr || result.stdout);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
