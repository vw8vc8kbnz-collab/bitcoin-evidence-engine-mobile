import test from "node:test";
import assert from "node:assert/strict";
import { toPublicListing, FORBIDDEN_PUBLIC_LISTING_KEYS } from "../lib/public-listing";
import type { Listing } from "../lib/types";

const listing: Listing = {
  id:"x",sellerSlug:"seller",title:"Product",brand:"Merk",partnerRef:"SECRET",category:"overig",condition:"Retour",conditionScore:8,defect:"kras",
  photos:["/uploads/public.jpg"],internalPhotos:["/uploads/private.jpg"],visionMetadata:{model:"M1",articleNumber:"A1",serialMasked:"***1",ocrText:"secret",confidence:80,modelCandidates:["M2"]},
  listingCopy:{description:"Omschrijving",warnings:["internal"],sourceMode:"vision_generated",confidence:88},seo:{title:"SEO",metaDescription:"Meta"},fallback:"tv",stock:1,perUnit:false,newPrice:200,price:120,fast:100,premium:130,expectedDays:7,confidence:75,comps:4,aiSource:"heuristiek",delivery:"Ophalen",deliveryPrice:0,pickupCity:"Utrecht",priceLog:[{at:new Date().toISOString(),from:130,to:120}],status:"published",reviewChecklist:{title:true,price:true,category:true,photo:true,modelConfirmed:true,pricingConfirmed:true,conditionConfirmed:true,publicationConfirmed:true,description:true,seo:true,updatedAt:new Date().toISOString()},confirmations:{identity:{status:"user_confirmed",byUserId:"u",at:new Date().toISOString()}},createdAt:new Date().toISOString(),views:2,
};

test("publieke listing is een expliciete allowlist", () => {
  const out = toPublicListing(listing) as Record<string, unknown>;
  for (const key of FORBIDDEN_PUBLIC_LISTING_KEYS) assert.equal(key in out, false, `${key} mag niet publiek zijn`);
  assert.deepEqual(out.photos, ["/uploads/public.jpg"]);
  assert.equal((out.listingCopy as Record<string, unknown>).warnings, undefined);
  assert.equal((out.listingCopy as Record<string, unknown>).sourceMode, undefined);
  assert.equal((out.listingCopy as Record<string, unknown>).confidence, undefined);
  assert.equal(out.minimumBid, 100);
});

test("onbekende toekomstige interne velden lekken niet door de allowlist", () => {
  const internal = { ...listing, futureSecret: "NOOIT PUBLIEK" } as Listing & { futureSecret: string };
  const out = toPublicListing(internal) as Record<string, unknown>;
  assert.equal("futureSecret" in out, false);
});
