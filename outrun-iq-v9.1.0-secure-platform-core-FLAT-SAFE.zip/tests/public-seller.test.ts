import test from "node:test";
import assert from "node:assert/strict";
import { toPublicSeller } from "../lib/public-seller";
import type { Seller } from "../lib/types";

test("publieke seller bevat geen KvK, contact-, adres- of bankdata", () => {
  const seller: Seller = {
    slug: "seller", name: "Seller BV", city: "Utrecht", createdAt: new Date().toISOString(), kvk: "12345678", vatNumber: "NLSECRET",
    businessEmail: "secret@example.com", businessPhone: "0612345678", contactPerson: "Privé Persoon",
    logo: "/uploads/logo.webp", banner: "/uploads/banner.webp", about: "Outlet",
    support: { email: "support@example.com", phone: "0611111111", returnsInfo: "Geheim adres" },
    address: { street: "Privéstraat 1", postcode: "1234 AB", city: "Utrecht" },
    payout: { bankStatus: "verified", ibanMasked: "NL00***" },
  };
  const out = toPublicSeller(seller) as Record<string, unknown>;
  assert.deepEqual(Object.keys(out).sort(), ["about", "banner", "city", "logo", "name", "slug"].sort());
  for (const key of ["kvk","vatNumber","businessEmail","businessPhone","contactPerson","support","address","payout"]) assert.equal(key in out, false);
});
