import test from "node:test";
import assert from "node:assert/strict";
import { normalizeUploadUrl, validatedImageType } from "../lib/media";

test("uploadtype vereist overeenkomstige magic bytes", () => {
  const jpeg = Buffer.from([0xff, 0xd8, 0xff, 0xdb, 0, 1]);
  assert.equal(validatedImageType(jpeg, "image/jpeg")?.ext, ".jpg");
  assert.equal(validatedImageType(jpeg, "image/png"), null);
  assert.equal(validatedImageType(Buffer.from("geen afbeelding"), "image/jpeg"), null);
});

test("upload-URL voorkomt path traversal", () => {
  assert.equal(normalizeUploadUrl("/uploads/photo.jpg"), "/uploads/photo.jpg");
  assert.equal(normalizeUploadUrl("/uploads/../db.json"), null);
  assert.equal(normalizeUploadUrl("https://evil.example/photo.jpg"), null);
});

import sharp from "sharp";
import { processUploadedImage } from "../lib/media";

test("upload wordt begrensd en metadata-vrij als WebP opgeslagen", async () => {
  const input = await sharp({ create: { width: 3200, height: 1800, channels: 3, background: "#ffffff" } })
    .withMetadata({ exif: { IFD0: { Artist: "privé metadata" } } })
    .jpeg()
    .toBuffer();
  const out = await processUploadedImage(input, "image/jpeg");
  const meta = await sharp(out.buffer).metadata();
  assert.equal(out.mimeType, "image/webp");
  assert.equal(meta.format, "webp");
  assert.ok((meta.width ?? 0) <= 2400);
  assert.ok((meta.height ?? 0) <= 2400);
  assert.equal(meta.exif, undefined);
});
