import test from "node:test"; import assert from "node:assert/strict";
import { createOneTimeCode, verifyOneTimeCode } from "../lib/security";

test("OTP wordt uitsluitend gehasht opgeslagen",()=>{const {code,record}=createOneTimeCode("User@Example.com","register");assert.equal(record.code,undefined);assert.ok(record.codeHash);assert.ok(record.salt);assert.equal(verifyOneTimeCode(record,"user@example.com","register",code),true);assert.equal(verifyOneTimeCode(record,"user@example.com","reset",code),false);assert.equal(verifyOneTimeCode(record,"user@example.com","register","000000"),false);});
