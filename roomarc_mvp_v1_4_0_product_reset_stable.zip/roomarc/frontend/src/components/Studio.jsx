import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Camera, Check, ChevronRight, Home, ImagePlus, Layers, Plus, Send, Sparkles, SplitSquareHorizontal } from 'lucide-react';
import { motion } from 'framer-motion';
import { DEFAULT_COVER, DEFAULT_ROOM } from '../data/fallback';
import { TopBar, EmptyState } from './Layout';

const PHASES = ['Startpunt', 'Vloer gelegd', 'Muren afgerond', 'Meubels geplaatst', 'Gestyled', 'Voor/na'];
const CAPTION_IDEAS = [
  'Vandaag is deze kamer zichtbaar een stap verder gekomen.',
  'De sfeer begint nu echt te kloppen in deze ruimte.',
  'Nieuwe materialen en details maken de kamer warmer.',
  'Deze fase laat goed zien hoe de ruimte verandert.',
];

function flattenRooms(data) {
  const homes = Array.isArray(data?.homes) ? data.homes : [];
  return homes.flatMap((home) => (Array.isArray(home.rooms) ? home.rooms : []).map((room) => ({ ...room, home })));
}

function ProjectProgress({ room }) {
  const count = Math.max(1, Math.min(6, Number(room?.updates || 1)));
  return <div className="project-progress">{Array.from({ length: 6 }).map((_, i) => <span key={i} className={i < count ? 'active' : ''} />)}</div>;
}

function ProjectCard({ room, onClick }) {
  const image = room?.latest_update?.media_url || room?.cover_url || DEFAULT_ROOM;
  return (
    <motion.button className="studio-project-pro" whileTap={{ scale: 0.985 }} onClick={onClick}>
      <img src={image} alt={room?.name || 'Kamer'} />
      <div className="studio-project-pro__body">
        <small>{room?.home?.title || 'Jouw huis'}</small>
        <strong>{room?.name || 'Nieuwe kamer'}</strong>
        <span>{room?.latest_phase || 'Startpunt'} · {room?.updates || 0} updates</span>
        <ProjectProgress room={room} />
      </div>
      <ChevronRight size={18} />
    </motion.button>
  );
}

function StudioHome({ auth, setMode, preselectRoom }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let active = true;
    auth.req('/api/me/homes')
      .then((payload) => { if (active) setData(payload || { homes: [], stats: {} }); })
      .catch(() => { if (active) setData({ homes: [], stats: {} }); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [auth]);
  const rooms = useMemo(() => flattenRooms(data), [data]);
  const stats = data?.stats || { homes: 0, rooms: 0, updates: 0 };
  const primaryRoom = rooms[0];
  return (
    <main className="screen studio-pro-screen">
      <TopBar title="Studio" subtitle="Werk aan je huisprofiel" />
      <section className="studio-command-card">
        <div>
          <small>Vandaag verder bouwen</small>
          <h1>Laat één kamer groeien.</h1>
          <p>Plaats een update op een bestaande kamer-tijdlijn. Dit is de motor van Roomarc.</p>
        </div>
        <button className="studio-main-action" onClick={() => { if (primaryRoom) preselectRoom(primaryRoom); setMode('update'); }}>
          <Plus size={22} /> Kamerupdate plaatsen
        </button>
      </section>

      <section className="studio-stats-strip" aria-label="Jouw Roomarc cijfers">
        <div><strong>{stats.homes || 0}</strong><span>huizen</span></div>
        <div><strong>{stats.rooms || rooms.length}</strong><span>kamers</span></div>
        <div><strong>{stats.updates || 0}</strong><span>updates</span></div>
      </section>

      <section className="studio-section">
        <div className="section-title"><span>Verder werken aan</span><small>{loading ? 'laden...' : `${rooms.length} kamers`}</small></div>
        <div className="studio-project-stack">
          {rooms.slice(0, 8).map((room) => <ProjectCard key={room.id} room={room} onClick={() => { preselectRoom(room); setMode('update'); }} />)}
          {!loading && !rooms.length ? <EmptyState title="Nog geen eigen kamers" text="Maak eerst een huisprofiel of kamer. Daarna wordt Studio jouw projectoverzicht." /> : null}
        </div>
      </section>

      <section className="studio-section">
        <div className="section-title"><span>Snelle tools</span><small>maak nieuw</small></div>
        <div className="studio-tools-pro">
          <button onClick={() => setMode('room')}><Layers size={20} /><strong>Nieuwe kamer</strong><span>Start een ruimte</span></button>
          <button onClick={() => setMode('homeProfile')}><Home size={20} /><strong>Huisprofiel</strong><span>Maak portfolio</span></button>
          <button onClick={() => setMode('before')}><SplitSquareHorizontal size={20} /><strong>Voor/na</strong><span>Transformatie</span></button>
          <button onClick={() => setMode('update')}><Sparkles size={20} /><strong>Snelle update</strong><span>Direct posten</span></button>
        </div>
      </section>
    </main>
  );
}

function ComposerHeader({ title, subtitle, onBack, kicker }) {
  return (
    <header className="composer-pro-header">
      <button onClick={onBack}><ArrowLeft size={18} /> Studio</button>
      <small>{kicker}</small>
      <h1>{title}</h1>
      <p>{subtitle}</p>
    </header>
  );
}

function UpdateComposer({ auth, onBack, onPosted, selectedRoom }) {
  const [homes, setHomes] = useState([]);
  const [homeId, setHomeId] = useState(selectedRoom?.home?.id || '');
  const [roomId, setRoomId] = useState(selectedRoom?.id || '');
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [phase, setPhase] = useState(selectedRoom?.latest_phase || '');
  const [caption, setCaption] = useState('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');

  useEffect(() => {
    let active = true;
    auth.req('/api/homes')
      .then((data) => {
        if (!active) return;
        const list = Array.isArray(data) ? data : [];
        setHomes(list);
        if (!homeId && list[0]) setHomeId(list[0].id);
      })
      .catch(() => { if (active) setHomes([]); });
    return () => { active = false; };
  }, [auth]);

  const rooms = useMemo(() => {
    const home = homes.find((item) => item.id === homeId);
    return Array.isArray(home?.rooms) ? home.rooms : [];
  }, [homes, homeId]);
  useEffect(() => { if (!roomId && rooms[0]) setRoomId(rooms[0].id); }, [rooms, roomId]);

  const selectedHome = homes.find((item) => item.id === homeId) || selectedRoom?.home;
  const selectedRoomLocal = rooms.find((item) => item.id === roomId) || selectedRoom;
  const ready = Boolean(file && roomId && phase && caption.trim());

  function pickFile(event) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  }

  async function submit() {
    if (!ready) { setStatus('Voeg een foto, kamer, fase en korte tekst toe.'); return; }
    setBusy(true);
    setStatus('Publiceren...');
    try {
      const form = new FormData();
      form.append('file', file);
      const uploaded = await auth.req('/api/media/upload', { method: 'POST', body: form });
      await auth.req(`/api/rooms/${roomId}/updates`, { method: 'POST', body: JSON.stringify({ media_url: uploaded.url, caption, phase_label: phase }) });
      setStatus('Geplaatst. Je kamer leeft weer een stap verder.');
      setTimeout(() => onPosted?.(), 650);
    } catch (error) {
      setStatus(`Upload mislukt: ${error.message}`);
    } finally { setBusy(false); }
  }

  return (
    <main className="screen composer-pro-screen">
      <ComposerHeader onBack={onBack} kicker="Kamerupdate" title="Nieuwe fase" subtitle="Foto eerst. Daarna kies je kamer, fase en verhaal." />
      <label className={`media-first-stage ${preview ? 'has-preview' : ''}`}>
        <input type="file" accept="image/*" onChange={pickFile} />
        {preview ? <img src={preview} alt="Preview" /> : <div><ImagePlus size={38} /><strong>Kies je beste kamerfoto</strong><span>De foto wordt de basis van je update.</span></div>}
      </label>
      <section className="composer-panel-pro">
        <div className="field-grid-pro">
          <label><small>Huis</small><select value={homeId} onChange={(e) => { setHomeId(e.target.value); setRoomId(''); }}>{homes.map((home) => <option value={home.id} key={home.id}>{home.title}</option>)}</select></label>
          <label><small>Kamer</small><select value={roomId} onChange={(e) => setRoomId(e.target.value)}>{rooms.map((room) => <option value={room.id} key={room.id}>{room.name}</option>)}</select></label>
        </div>
        <div className="phase-pro"><small>Fase</small><div>{PHASES.map((item) => <button key={item} className={phase === item ? 'active' : ''} onClick={() => setPhase(item)}>{item}</button>)}</div></div>
        <label className="caption-pro"><small>Wat is er veranderd?</small><textarea value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Bijv. De vloer ligt erin en de kamer voelt direct warmer." /></label>
        <div className="caption-ideas-pro">{CAPTION_IDEAS.map((idea) => <button key={idea} onClick={() => setCaption(idea)}>{idea}</button>)}</div>
        <article className="post-preview-pro">
          {preview ? <img src={preview} alt="Preview" /> : <div className="post-preview-empty"><Camera size={20} /></div>}
          <div><small>{selectedHome?.title || 'Jouw huis'} · {selectedRoomLocal?.name || 'Kamer'}</small><strong>{phase || 'Nieuwe fase'}</strong><p>{caption || 'Schrijf kort wat er veranderd is.'}</p></div>
        </article>
        {status ? <p className="status-message">{status}</p> : null}
        <button className="publish-pro" disabled={busy} onClick={submit}><Send size={18} /> {ready ? 'Publiceer naar tijdlijn' : 'Maak update compleet'}</button>
      </section>
    </main>
  );
}

function RoomComposer({ auth, onBack }) {
  const [homes, setHomes] = useState([]); const [homeId, setHomeId] = useState(''); const [name, setName] = useState(''); const [type, setType] = useState(''); const [status, setStatus] = useState('');
  useEffect(() => { let active = true; auth.req('/api/homes').then((data) => { if (!active) return; const list = Array.isArray(data) ? data : []; setHomes(list); if (list[0]) setHomeId(list[0].id); }).catch(() => { if (active) setHomes([]); }); return () => { active = false; }; }, [auth]);
  async function submit() { if (!homeId || !name.trim()) { setStatus('Kies een huis en geef de kamer een naam.'); return; } try { await auth.req(`/api/homes/${homeId}/rooms`, { method: 'POST', body: JSON.stringify({ name, room_type: type, cover_url: DEFAULT_ROOM }) }); setStatus('Kamer aangemaakt. Plaats nu de eerste update.'); setName(''); setType(''); } catch (error) { setStatus(`Mislukt: ${error.message}`); } }
  return <main className="screen composer-pro-screen"><ComposerHeader onBack={onBack} kicker="Nieuwe ruimte" title="Nieuwe kamer" subtitle="Maak een ruimte die mensen apart kunnen volgen." /><section className="composer-panel-pro"><label><small>Kamernaam</small><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Bijv. Woonkamer" /></label><label><small>Kamertype</small><input value={type} onChange={(e) => setType(e.target.value)} placeholder="Keuken, slaapkamer, badkamer..." /></label><label><small>Hoort bij huis</small><select value={homeId} onChange={(e) => setHomeId(e.target.value)}>{homes.map((home) => <option value={home.id} key={home.id}>{home.title}</option>)}</select></label>{status ? <p className="status-message">{status}</p> : null}<button className="publish-pro" onClick={submit}><Check size={18} /> Maak kamer</button></section></main>;
}

function HomeComposer({ auth, onBack }) {
  const [title, setTitle] = useState(''); const [description, setDescription] = useState(''); const [style, setStyle] = useState(''); const [status, setStatus] = useState('');
  async function submit() { if (!title.trim()) { setStatus('Geef je huisprofiel een naam.'); return; } try { await auth.req('/api/homes', { method: 'POST', body: JSON.stringify({ title, description, style_text: style, cover_url: DEFAULT_COVER }) }); setStatus('Huisprofiel aangemaakt. Voeg nu je eerste kamer toe.'); setTitle(''); setDescription(''); setStyle(''); } catch (error) { setStatus(`Mislukt: ${error.message}`); } }
  return <main className="screen composer-pro-screen"><ComposerHeader onBack={onBack} kicker="Huisprofiel" title="Bouw je profiel" subtitle="Je huis wordt de etalage van al je kamers." /><section className="composer-panel-pro"><label><small>Naam</small><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Bijv. Villa Rutte" /></label><label><small>Stijl</small><input value={style} onChange={(e) => setStyle(e.target.value)} placeholder="Japandi, hotel chique, Scandinavisch..." /></label><label><small>Bio</small><textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Vertel kort wat voor huis of project dit is." /></label>{status ? <p className="status-message">{status}</p> : null}<button className="publish-pro" onClick={submit}><Check size={18} /> Maak huisprofiel</button></section></main>;
}

function BeforeAfter({ onBack }) {
  return <main className="screen composer-pro-screen"><ComposerHeader onBack={onBack} kicker="Voor/na" title="Transformatie" subtitle="Deze feature wordt de visuele vergelijking tussen twee fases." /><section className="composer-panel-pro"><div className="before-after-placeholder"><span>Voor</span><i /><span>Na</span></div><p className="muted-copy">Binnenkort: sleepbare slider gekoppeld aan je kamer-tijdlijn.</p><button className="publish-pro" onClick={onBack}>Terug naar Studio</button></section></main>;
}

export function Studio({ auth, onPosted }) {
  const [mode, setMode] = useState('home');
  const [selectedRoom, setSelectedRoom] = useState(null);
  function goHome() { setMode('home'); setSelectedRoom(null); }
  if (mode === 'update') return <UpdateComposer auth={auth} selectedRoom={selectedRoom} onBack={goHome} onPosted={onPosted} />;
  if (mode === 'room') return <RoomComposer auth={auth} onBack={goHome} />;
  if (mode === 'homeProfile') return <HomeComposer auth={auth} onBack={goHome} />;
  if (mode === 'before') return <BeforeAfter onBack={goHome} />;
  return <StudioHome auth={auth} setMode={setMode} preselectRoom={setSelectedRoom} />;
}
