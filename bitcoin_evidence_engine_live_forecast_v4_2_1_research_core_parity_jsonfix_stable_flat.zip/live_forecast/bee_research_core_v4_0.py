#!/usr/bin/env python3
"""
Bitcoin Evidence Engine v4.2.0 research core parity module.

This module is the single decision source used by both:
- live forecast loop
- golden tests

No live script may re-score or reimplement these formulas.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, List, Optional
import math

VERSION = "v4.2.1_research_core_parity_no_circular"

def _f(x, default=None):
    try:
        if x is None: return default
        v=float(x)
        if math.isnan(v) or math.isinf(v): return default
        return v
    except Exception:
        return default

def _tier(prob: float) -> str:
    if prob >= 0.74: return "elite"
    if prob >= 0.66: return "strong"
    if prob >= 0.62: return "push"
    return "none"

def _base_decision(name:str, applies:bool, prob:Optional[float], horizon:str, reasons:List[str], row:Dict[str,Any], extra:Dict[str,Any]=None) -> Dict[str,Any]:
    prob = None if prob is None else round(float(prob), 6)
    tier = "none" if prob is None else _tier(prob)
    action = "LONG" if applies and tier != "none" else "NO_TRADE"
    entry = _f(row.get("close"), 0.0) or 0.0
    # Indicative monitoring levels only. The validated exit policy is wide trailing paper.
    target = entry * 1.18 if action == "LONG" else None
    stop = entry * 0.90 if action == "LONG" else None
    d = {
        "specialist": name if action=="LONG" else "none",
        "model": name,
        "action": action,
        "decision": action,
        "applies": bool(applies),
        "prob": prob,
        "tier": tier,
        "horizon": horizon if action=="LONG" else "none",
        "entry_price": round(entry,2) if entry else None,
        "take_profit": round(target,2) if target else None,
        "stop_loss": round(stop,2) if stop else None,
        "exit_policy": "wide_trailing_paper",
        "levels_label": "indicative_monitoring_levels_not_fixed_exit",
        "reason": "; ".join(reasons),
        "reasons": reasons,
        "research_core_version": VERSION
    }
    if extra: d.update(extra)
    return d

def cycle_debug(row:Dict[str,Any]) -> Dict[str,Any]:
    """
    v4.0-compatible CycleReversal decision.

    Gate from audit: fear_greed < 25 AND 4h momentum > 0.
    Probability from audit: 0.62 base + fear distance*0.12 + 0.04 drawdown<-30 + 0.02 risk_on.
    """
    fg=_f(row.get("fear_greed"))
    mom4=_f(row.get("mom_4h"), _f(row.get("return_4")))
    dd=_f(row.get("drawdown_from_ath"))
    risk_on=bool(row.get("risk_on", False))
    spx=_f(row.get("spx_ret_1w_calc"))
    if spx is not None and spx > 0:
        risk_on=True
    reasons=[]
    if fg is None: reasons.append("NO_FEAR_GREED")
    if mom4 is None: reasons.append("NO_MOM_4H")
    applies = (fg is not None and fg < 25 and mom4 is not None and mom4 > 0)
    if applies:
        fear_bonus = max(0.0, min(1.0, (25.0 - fg)/25.0)) * 0.12
        prob = 0.62 + fear_bonus
        if dd is not None and dd < -30: prob += 0.04
        if risk_on: prob += 0.02
        prob = min(0.88, max(0.62, prob))
        reasons.append(f"CYCLE_GATE_OK fear_greed={fg:.2f}<25 mom_4h={mom4:.6f}>0")
        reasons.append(f"CORE_PROB=0.62+fear_bonus({fear_bonus:.4f})+dd_bonus({0.04 if (dd is not None and dd < -30) else 0})+risk_bonus({0.02 if risk_on else 0})")
    else:
        prob = None
        reasons.append(f"CYCLE_GATE_FAIL fear_greed={fg} mom_4h={mom4}")
    return _base_decision("cycle_reversal", applies, prob, "30d", reasons, row, {
        "cycle_prob_raw": None if prob is None else round(prob,6),
        "gate": "fear_greed<25 AND mom_4h>0",
    })

def elite_reversal_debug(row:Dict[str,Any]) -> Dict[str,Any]:
    """
    Elite reversal live core. Conservative high-quality panic/recovery family.
    Uses the same row inputs and returns a real engine output, no proxy labels.
    """
    fg=_f(row.get("fear_greed"))
    dd=_f(row.get("drawdown_from_ath"))
    rsi=_f(row.get("rsi_14"))
    mom4=_f(row.get("mom_4h"), _f(row.get("return_4")))
    funding=_f(row.get("funding_rate"), 0.0) or 0.0
    coinbase=_f(row.get("coinbase_premium_pct"))
    reasons=[]
    applies = (
        fg is not None and fg <= 18 and
        dd is not None and dd <= -30 and
        rsi is not None and rsi <= 38 and
        mom4 is not None and mom4 > -0.02
    )
    if applies:
        prob=0.66
        prob += max(0.0, min(0.08, (18-fg)/18*0.08))
        prob += 0.04 if dd <= -40 else 0.02
        prob += 0.03 if rsi <= 30 else 0.01
        if funding < 0: prob += 0.02
        if coinbase is not None and coinbase > 0: prob += 0.01
        prob=min(0.90, prob)
        reasons.append(f"ELITE_REVERSAL_OK fg={fg:.2f} dd={dd:.2f} rsi={rsi:.2f} mom4={mom4:.6f}")
    else:
        prob=None
        reasons.append(f"ELITE_REVERSAL_FAIL fg={fg} dd={dd} rsi={rsi} mom4={mom4}")
    return _base_decision("elite_reversal", applies, prob, "30d", reasons, row, {"gate":"fg<=18 AND dd<=-30 AND rsi<=38 AND mom4>-0.02"})

def reversal_debug(row:Dict[str,Any]) -> Dict[str,Any]:
    """
    ReversalAlpha family. Broader than Elite, stricter than generic fear.
    """
    fg=_f(row.get("fear_greed"))
    dd=_f(row.get("drawdown_from_ath"))
    rsi=_f(row.get("rsi_14"))
    mom24=_f(row.get("return_24"))
    reasons=[]
    applies = (
        fg is not None and fg < 30 and
        dd is not None and dd < -20 and
        rsi is not None and rsi < 50 and
        mom24 is not None and mom24 > -0.03
    )
    if applies:
        prob=0.60
        prob += max(0.0, min(0.07, (30-fg)/30*0.07))
        if dd < -35: prob += 0.03
        if rsi < 40: prob += 0.02
        if mom24 > 0: prob += 0.02
        prob=min(0.82, prob)
        reasons.append(f"REVERSAL_OK fg={fg:.2f} dd={dd:.2f} rsi={rsi:.2f} ret24={mom24:.6f}")
    else:
        prob=None
        reasons.append(f"REVERSAL_FAIL fg={fg} dd={dd} rsi={rsi} ret24={mom24}")
    return _base_decision("reversal", applies, prob, "30d", reasons, row, {"gate":"fg<30 AND dd<-20 AND rsi<50 AND return_24>-0.03"})

def decide_all(row:Dict[str,Any], active_models:List[str]=None) -> Dict[str,Any]:
    active_models = active_models or ["cycle_reversal","elite_reversal","reversal"]
    outputs=[]
    if "cycle_reversal" in active_models: outputs.append(cycle_debug(row))
    if "elite_reversal" in active_models: outputs.append(elite_reversal_debug(row))
    if "reversal" in active_models: outputs.append(reversal_debug(row))
    longs=[o for o in outputs if o.get("action")=="LONG"]
    # priority: elite tier/prob first; then known engine priority
    priority={"elite_reversal":3,"cycle_reversal":2,"reversal":1}
    if longs:
        selected=sorted(longs, key=lambda o: (o.get("prob") or 0, priority.get(o.get("model"),0)), reverse=True)[0]
        # IMPORTANT: copy the selected output before adding all_engine_outputs.
        # Otherwise selected is also inside outputs and JSON serialization sees a circular reference.
        best=dict(selected)
    else:
        best=_base_decision("none", False, None, "none", ["NO_ACTIVE_MODEL_SIGNAL"], row)
    best["all_engine_outputs"]=[dict(o) for o in outputs]
    best["active_models"] = list(active_models)
    return best
