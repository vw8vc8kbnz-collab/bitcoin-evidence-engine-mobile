Use the update block from ChatGPT for v1.7.2.
