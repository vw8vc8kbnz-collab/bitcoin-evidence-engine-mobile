# v8.5.7 — AI Commerce Brain & Visibility Engine

- Nieuwe server-safe AI Commerce Brain toegevoegd.
- Compacte event queue met harde cap (`COMMERCE_EVENT_CAP`, default 750).
- Events worden samengevat, niet als ruwe klikstream bewaard.
- Geen extra foto-opslag, geen zware payloads, geen groeiende logbestanden.
- Listing-events, views, saves, bids en orders krijgen commerce-brain signalen.
- Structured Data toegevoegd op productpagina's voor Google/AI zichtbaarheid.
- Sitemap en robots toegevoegd voor outruniq.nl.
- Admin dashboard toont Commerce Brain status, SEO-ready producten, queue cap en adviespunten.
- Nieuwe admin endpoint: `/api/admin/commerce-brain`.
