# Outrun IQ v8.5.7 — AI Commerce Brain & Visibility Engine

Deze versie bouwt verder op v8.5.6 en zet de fundering neer voor zelflerende commerce-AI én vindbaarheid in Google/AI search.

Belangrijk:
- AI-events zijn server-safe en capped.
- Outrun bewaart geen ruwe clickstream en kopieert geen foto's.
- Productpagina's krijgen schema.org Product/Offer structured data.
- Sitemap staat op `/sitemap.xml`, robots op `/robots.txt`.
- Admin kan de status zien via `/beheer` en `/api/admin/commerce-brain`.

Environment caps:
- `COMMERCE_EVENT_CAP` default 750, toegestaan 100–5000.
- `LEARNING_PRODUCT_CAP` en `LEARNING_DAILY_CAP` blijven uit v8.5.6 bestaan.
