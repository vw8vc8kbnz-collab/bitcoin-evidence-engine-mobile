# AlgoRoute v1.0 — Premium Light Workspace

## Wat is nieuw
- Nieuwe visuele richting verwerkt als echte software, geen mockup.
- Donkere linker sidebar behouden.
- Hoofdworkspace omgezet naar soft warm grey/light SaaS-stijl.
- Blauw grotendeels vervangen door premium routekleuren: groen, oranje, rood en paars.
- Logo-vorm behouden; accentkleur aangepast naar de nieuwe huisstijl.
- MapLibre gebruikt nu een lichtere, gedetailleerdere NL basemap.
- Routes, stops en busmarkers zijn beter leesbaar op de kaart.
- Traffic-segmenten zijn visueel voorbereid voor oranje/rood op specifieke routedelen.

## Nog placeholder
- Echte routes volgen nog niet exact wegen via OSRM/provider.
- Nog geen live GPS.
- Nog geen CSV import mapping.
- Nog geen echte database persistence voor alle modules.

## Testpunten
- Dashboard openen.
- Live Kaart openen.
- Klik routes/voertuigen.
- Check kaartleesbaarheid, kleuren, sidebar en rechter detailpaneel.
