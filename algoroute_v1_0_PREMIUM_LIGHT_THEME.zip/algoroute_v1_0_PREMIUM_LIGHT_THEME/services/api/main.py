from datetime import datetime, timezone
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="AlgoRoute API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

VEHICLES = [
    {"id":"veh-01","name":"Bus 01","driver":"Milan","plate":"V-123-AB","status":"on_time","speed":62,"eta":"16:12","stops_done":3,"stops_total":8,"load":"5/6 pallets","progress":58,"lng":4.9041,"lat":52.3676,"heading":35},
    {"id":"veh-02","name":"Bus 02","driver":"Pieter","plate":"V-456-CD","status":"delay","speed":48,"eta":"15:44","stops_done":5,"stops_total":10,"load":"7/8 RC","progress":72,"lng":4.4777,"lat":51.9244,"heading":70},
    {"id":"veh-03","name":"Bus 03","driver":"Sanne","plate":"V-789-EF","status":"on_time","speed":54,"eta":"17:05","stops_done":2,"stops_total":9,"load":"4/6 pallets","progress":33,"lng":5.1214,"lat":52.0907,"heading":-20},
    {"id":"veh-04","name":"Bus 04","driver":"Jeroen","plate":"V-321-GH","status":"critical","speed":0,"eta":"18:22","stops_done":1,"stops_total":7,"load":"vol","progress":18,"lng":5.4697,"lat":51.4416,"heading":0},
]

ROUTES = [
    {"id":"route-01","vehicle_id":"veh-01","name":"Noord-Holland Premium","km":184,"duration":"6u 12m","risk":"low","color":"#5baa32","coordinates":[[4.9041,52.3676],[4.821,52.363],[4.735,52.377],[4.6462,52.3874],[4.665,52.474],[4.703,52.555],[4.7486,52.6324],[4.865,52.655],[5.059,52.642],[5.022,52.551],[4.953,52.448],[4.872,52.337]],"stops":[
        {"seq":1,"city":"Amsterdam","eta":"08:42","status":"done","lng":4.9041,"lat":52.3676},
        {"seq":2,"city":"Haarlem","eta":"09:30","status":"done","lng":4.6462,"lat":52.3874},
        {"seq":3,"city":"Alkmaar","eta":"11:15","status":"current","lng":4.7486,"lat":52.6324},
        {"seq":4,"city":"Hoorn","eta":"12:05","status":"planned","lng":5.059, "lat":52.642},
        {"seq":5,"city":"Amsterdam-Zuid","eta":"14:20","status":"planned","lng":4.872,"lat":52.337}
    ]},
    {"id":"route-02","vehicle_id":"veh-02","name":"Rotterdam / Den Haag","km":211,"duration":"7u 05m","risk":"medium","color":"#8a3ffc","coordinates":[[4.4777,51.9244],[4.392,51.965],[4.3571,52.0116],[4.3007,52.0705],[4.365,52.038],[4.4792,51.9225],[4.636,52.014],[4.780,52.166],[4.8952,52.3702]],"stops":[
        {"seq":1,"city":"Rotterdam","eta":"09:10","status":"done","lng":4.4777,"lat":51.9244},
        {"seq":2,"city":"Den Haag","eta":"10:40","status":"current","lng":4.3007,"lat":52.0705},
        {"seq":3,"city":"Delft","eta":"12:10","status":"planned","lng":4.3571,"lat":52.0116}
    ]},
    {"id":"route-03","vehicle_id":"veh-04","name":"Brabant EV Route","km":268,"duration":"8u 02m","risk":"high","color":"#f97316","coordinates":[[5.4697,51.4416],[5.394,51.516],[5.3037,51.6905],[5.206,51.660],[5.0913,51.5555],[5.015,51.702],[4.982,51.890],[4.8952,52.3702]],"stops":[
        {"seq":1,"city":"Eindhoven","eta":"10:05","status":"done","lng":5.4697,"lat":51.4416},
        {"seq":2,"city":"Tilburg","eta":"12:35","status":"current","lng":5.0913,"lat":51.5555},
        {"seq":3,"city":"Den Bosch","eta":"14:05","status":"planned","lng":5.3037,"lat":51.6905}
    ]},
]

EVENTS = [
    {"id":"e1","title":"A16 vertraging +18 min","route":"Rotterdam / Den Haag","type":"traffic","severity":"medium"},
    {"id":"e2","title":"Bus 04 volledig beladen","route":"Brabant EV Route","type":"load","severity":"critical"},
    {"id":"e3","title":"3 stops binnen belofte-window","route":"Noord-Holland Premium","type":"promise","severity":"ok"},
    {"id":"e4","title":"EV-range marge laag: 22% batterij","route":"Brabant EV Route","type":"ev","severity":"critical"},
]

@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": "1.0.0", "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/map/state")
def map_state():
    return {"center": [5.2913, 52.1326], "zoom": 6.8, "vehicles": VEHICLES, "routes": ROUTES, "events": EVENTS, "traffic_segments": [
        {"id":"traffic-a16","status":"orange","label":"A16 +18 min","coordinates":[[4.392,51.965],[4.3571,52.0116],[4.3007,52.0705]]},
        {"id":"traffic-a2","status":"red","label":"A2 incident","coordinates":[[5.015,51.702],[4.982,51.890],[4.8952,52.3702]]}
    ]}

@app.get("/api/vehicles")
def vehicles():
    return VEHICLES

@app.get("/api/routes")
def routes():
    return ROUTES
