# Outrun IQ V1.1 Real App VPS Ready

Static SPA + standard Python server. No FastAPI, no pip install required.

Run:

```bash
HOST=0.0.0.0 PORT=8795 python3 server.py
```

Health:

```bash
curl -s http://127.0.0.1:8795/api/health
```
