#!/usr/bin/env python3
import os, json, mimetypes
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

HOST = os.environ.get('HOST', '0.0.0.0')
PORT = int(os.environ.get('PORT', '8795'))
ROOT = Path(__file__).resolve().parent / 'static'

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        # SPA fallback
        clean = path.split('?', 1)[0].split('#', 1)[0]
        if clean in ('', '/') or clean.startswith('/app'):
            return str(ROOT / 'index.html')
        p = (ROOT / clean.lstrip('/')).resolve()
        try:
            p.relative_to(ROOT)
        except Exception:
            return str(ROOT / 'index.html')
        if p.exists():
            return str(p)
        return str(ROOT / 'index.html')
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, max-age=0')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'SAMEORIGIN')
        super().end_headers()
    def do_GET(self):
        if self.path.startswith('/api/health'):
            body = json.dumps({'ok': True, 'app': 'Outrun IQ', 'version': 'v1.1-real-app'}).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        return super().do_GET()

if __name__ == '__main__':
    os.chdir(str(ROOT))
    print(f'Outrun IQ v1.1-real-app running on http://{HOST}:{PORT}')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
