(function(root){
  'use strict';
  if(root.__TOOLA_GRAIN_STUDIO_RENDERER__) return;
  root.__TOOLA_GRAIN_STUDIO_RENDERER__='FIX660_GRAIN_STUDIO_RENDERER';

  const loadingTemplates=new Set();
  let lastHit=[];
  let renderRaf=0;
  let observedContainer=null;
  let ro=null;

  function n(v,d=0){const x=Number(v);return Number.isFinite(x)?x:d;}
  function escText(v){return String(v==null?'':v);}
  function stateObj(){try{return root.state||null;}catch(_){return null;}}
  function selectedGroup(){
    const s=stateObj(); if(!s||!s.grain) return null;
    const id=String(s.grain.selectedGroupId||'');
    return (s.grain.groups||[]).find(g=>String(g&&g.id||'')===id)||null;
  }
  function entry(ref){try{return typeof root.getGrainEntryByRef==='function'?root.getGrainEntryByRef(ref):null;}catch(_){return null;}}
  function totalHeight(e){return Math.max(1,n(e&&e.baseHeightMm)+Math.max(0,n(e&&e.extTop))+Math.max(0,n(e&&e.extBot)));}
  function fmtMm(v){const x=n(v);return Math.abs(x-Math.round(x))<.01?String(Math.round(x)):x.toFixed(1).replace('.',',');}
  function groupDims(g){
    const panels=(g&&g.items||[]).map(ref=>{const e=entry(ref);return e?{ref:String(ref),entry:e,widthMm:n(e.widthMm),heightMm:totalHeight(e)}:null;}).filter(Boolean);
    const M=root.ToolAGrainStudioMath;
    const summary=M?M.summarizePanels(panels):{count:panels.length,widthMm:panels[0]?.widthMm||0,totalHeightMm:panels.reduce((s,p)=>s+p.heightMm,0),validSameWidth:panels.every(p=>Math.abs(p.widthMm-(panels[0]?.widthMm||0))<.001)};
    return {panels,summary};
  }
  function templateFor(e){
    try{
      const s=stateObj(), raw=e&&e.raw||{};
      const id=String(raw.templateId||'').trim();
      if(!id) return null;
      const t=s&&s.templates&&typeof s.templates.get==='function'?s.templates.get(id):null;
      if(!t && typeof root.ensureTemplateLoadedById==='function' && !loadingTemplates.has(id)){
        loadingTemplates.add(id);
        Promise.resolve(root.ensureTemplateLoadedById(id)).catch(()=>{}).finally(()=>{loadingTemplates.delete(id);schedule();});
      }
      return t||null;
    }catch(_){return null;}
  }
  function panelIsDoor(raw,t){
    const type=String(raw&&raw.type||raw&&raw.panelType||'').toLowerCase();
    const label=String(raw&&raw.label||raw&&raw.baseLabel||'').toLowerCase();
    return type==='deur'||type==='pax_deur'||type.includes('door')||label.includes('deur')||label.includes('door')||!!(t&&t.supportsHinge)||String(t&&t.kind||'')==='Hoekkast';
  }
  function mirrorPanel(raw,t){
    if(!panelIsDoor(raw,t)) return false;
    const h=String(raw&&raw.hinge||raw&&raw.hingeSide||'').toLowerCase();
    return h==='right'||h.includes('rechts');
  }
  function roundRect(ctx,x,y,w,h,r){
    ctx.beginPath();
    if(typeof ctx.roundRect==='function'){ctx.roundRect(x,y,w,h,r);return;}
    const rr=Math.min(r,w/2,h/2);ctx.moveTo(x+rr,y);ctx.arcTo(x+w,y,x+w,y+h,rr);ctx.arcTo(x+w,y+h,x,y+h,rr);ctx.arcTo(x,y+h,x,y,rr);ctx.arcTo(x,y,x+w,y,rr);ctx.closePath();
  }
  function cncStroke(ctx,x,y){
    try{
      if(root.ToolAMaterialSwatchRenderer&&typeof root.ToolAMaterialSwatchRenderer.contrastStrokeAt==='function'){
        return root.ToolAMaterialSwatchRenderer.contrastStrokeAt(ctx,x,y,{dark:'rgba(18,28,25,.90)',light:'rgba(247,250,248,.94)',fallback:'rgba(64,177,113,.95)',sampleRadius:2});
      }
    }catch(_){ }
    return 'rgba(64,177,113,.95)';
  }
  function drawPanelCnc(ctx,p,e,scale){
    const raw=e&&e.raw||{}, t=templateFor(e); if(!t) return;
    const holes=Array.isArray(t.holes)?t.holes:[];
    const arcs=Array.isArray(t.holeArcs)?t.holeArcs:[];
    if(!holes.length&&!arcs.length) return;
    const baseW=Math.max(1,n(e.widthMm));
    const baseH=Math.max(1,n(e.baseHeightMm));
    const extTop=Math.max(0,n(e.extTop));
    const outlineMinX=Number.isFinite(n(t?.outline?.minX,NaN))?n(t.outline.minX):0;
    const outlineMinY=Number.isFinite(n(t?.outline?.minY,NaN))?n(t.outline.minY):0;
    const mirror=mirrorPanel(raw,t);
    const X=x=>p.x+(mirror?(baseW-x):x)*scale;
    const Y=y=>p.y+(extTop+baseH-y)*scale;
    ctx.save();
    roundRect(ctx,p.x,p.y,p.w,p.h,Math.min(5,Math.max(1,p.w*.015)));ctx.clip();
    ctx.setLineDash([4,4]);ctx.lineWidth=1;
    for(const h0 of holes){
      const lx=n(h0&&h0.x)-outlineMinX, ly=n(h0&&h0.y)-outlineMinY, r=Math.max(0,n(h0&&h0.r)); if(!(r>0)) continue;
      const px=X(lx),py=Y(ly);ctx.strokeStyle=cncStroke(ctx,px,py);ctx.beginPath();ctx.arc(px,py,r*scale,0,Math.PI*2);ctx.stroke();
    }
    for(const a0 of arcs){
      const lx=n(a0&&a0.x)-outlineMinX,ly=n(a0&&a0.y)-outlineMinY,r=Math.max(0,n(a0&&a0.r));if(!(r>0))continue;
      let s=n(a0&&a0.startDeg)*Math.PI/180,eang=n(a0&&a0.endDeg)*Math.PI/180;
      if(mirror){const ms=Math.PI-s,me=Math.PI-eang;s=me;eang=ms;}
      const px=X(lx),py=Y(ly);ctx.strokeStyle=cncStroke(ctx,px,py);ctx.beginPath();ctx.arc(px,py,r*scale,s,eang,false);ctx.stroke();
    }
    ctx.restore();
  }
  function drawArrow(ctx,x,y0,y1){
    ctx.save();ctx.strokeStyle='rgba(55,176,107,.88)';ctx.fillStyle='rgba(55,176,107,.95)';ctx.lineWidth=1.6;ctx.setLineDash([]);
    ctx.beginPath();ctx.moveTo(x,y1);ctx.lineTo(x,y0+8);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y0);ctx.lineTo(x-5,y0+9);ctx.lineTo(x+5,y0+9);ctx.closePath();ctx.fill();
    ctx.font='800 9px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('NERF',x,y1+12);ctx.restore();
  }
  function drawEmpty(container,msg){
    container.innerHTML='';const d=document.createElement('div');d.className='fix660GrainPreviewEmpty';d.textContent=msg;container.appendChild(d);lastHit=[];
  }
  function canvasSize(container){
    const r=container.getBoundingClientRect();
    const w=Math.max(260,Math.floor(r.width||container.clientWidth||420));
    const h=Math.max(300,Math.floor(r.height||container.clientHeight||520));
    return {w,h};
  }
  function fitConfig(w,h,panelCount){
    const mobile=!!(root.matchMedia&&root.matchMedia('(max-width:700px)').matches);
    return {containerWidth:w,containerHeight:h,padLeft:mobile?54:64,padRight:mobile?86:118,padTop:mobile?64:70,padBottom:mobile?54:62,gapPx:1};
  }
  function layoutDimensionLabels(items,top,bottom,minGap=13){
    const out=(items||[]).map(x=>Object.assign({},x,{labelY:x.targetY})).sort((a,b)=>a.targetY-b.targetY);
    if(!out.length) return out;
    out[0].labelY=Math.max(top,out[0].labelY);
    for(let i=1;i<out.length;i++) out[i].labelY=Math.max(out[i].targetY,out[i-1].labelY+minGap);
    if(out[out.length-1].labelY>bottom){
      out[out.length-1].labelY=bottom;
      for(let i=out.length-2;i>=0;i--) out[i].labelY=Math.min(out[i].labelY,out[i+1].labelY-minGap);
      if(out[0].labelY<top){
        const shift=top-out[0].labelY;for(const x of out)x.labelY+=shift;
      }
    }
    return out;
  }
  function render(container){
    container=container||document.getElementById('grainPreview');if(!container)return;
    observedContainer=container;
    const g=selectedGroup();
    if(!g||!(g.items||[]).length){drawEmpty(container,'Selecteer een nerf-set met minimaal 2 panelen om de preview te bekijken.');updateSummary(g);return;}
    const gd=groupDims(g), panels=gd.panels,summary=gd.summary;updateSummary(g,summary);
    if(!summary.validSameWidth){drawEmpty(container,'Deze nerf-set bevat verschillende werkelijke breedtes. Corrigeer de groep voordat je verdergaat.');return;}
    if(panels.length<1){drawEmpty(container,'Geen panelen beschikbaar voor preview.');return;}
    const size=canvasSize(container), dpr=Math.max(1,Math.min(2,n(root.devicePixelRatio,1)));
    container.innerHTML='';
    const canvas=document.createElement('canvas');canvas.className='fix660GrainCanvas';canvas.width=Math.round(size.w*dpr);canvas.height=Math.round(size.h*dpr);canvas.style.width=size.w+'px';canvas.style.height=size.h+'px';container.appendChild(canvas);
    const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,size.w,size.h);
    const bg=ctx.createLinearGradient(0,0,0,size.h);bg.addColorStop(0,'#202827');bg.addColorStop(1,'#17201f');ctx.fillStyle=bg;ctx.fillRect(0,0,size.w,size.h);
    const fit=(root.ToolAGrainStudioMath&&root.ToolAGrainStudioMath.computeVerticalGroupFit)?root.ToolAGrainStudioMath.computeVerticalGroupFit(Object.assign(fitConfig(size.w,size.h,panels.length),{panels})):null;
    if(!fit||!fit.ok){drawEmpty(container,'De groep kan niet correct worden geschaald.');return;}
    const selectedRef=String(root.__fix660SelectedGrainRef||'');lastHit=[];const dimensionLabels=[];

    // Group title + exact dimensions. Width is the invariant for a grain group.
    ctx.save();ctx.textAlign='left';ctx.textBaseline='top';ctx.fillStyle='rgba(238,245,241,.96)';ctx.font='800 13px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif';ctx.fillText(`Nerfgroep ${escText(g.id||'')}`,18,14);
    ctx.fillStyle='rgba(196,213,205,.84)';ctx.font='600 10.5px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif';ctx.fillText(`${fmtMm(summary.widthMm)} mm breed · ${panels.length} ${panels.length===1?'paneel':'panelen'} · ${fmtMm(summary.totalHeightMm)} mm totaal`,18,34);ctx.restore();

    const railX=Math.max(20,fit.bounds.x-22);drawArrow(ctx,railX,fit.bounds.y,fit.bounds.y+fit.bounds.h);

    fit.placements.forEach((p,index)=>{
      const model=panels[index],e=model.entry,raw=e.raw||{};
      // Actual material, one non-repeating swatch per physical panel.
      try{
        if(root.ToolAMaterialSwatchRenderer){
          root.ToolAMaterialSwatchRenderer.drawCanvasMaterial(ctx,p,{materialKey:String(e.materialKey||g.materialKey||''),panel:raw||{localGrainAxis:'V'},radius:3,onReady:schedule});
        }else{ctx.fillStyle='#c5b18e';ctx.fillRect(p.x,p.y,p.w,p.h);}
      }catch(_){ctx.fillStyle='#c5b18e';ctx.fillRect(p.x,p.y,p.w,p.h);}

      // Extension zones remain visible but do not change the real proportions.
      const extTop=Math.max(0,n(e.extTop)),extBot=Math.max(0,n(e.extBot));
      ctx.save();ctx.fillStyle='rgba(45,181,111,.18)';
      if(extTop>0)ctx.fillRect(p.x,p.y,p.w,extTop*fit.scale);
      if(extBot>0)ctx.fillRect(p.x,p.y+p.h-extBot*fit.scale,p.w,extBot*fit.scale);
      ctx.restore();

      drawPanelCnc(ctx,p,e,fit.scale);

      ctx.save();ctx.setLineDash([]);ctx.lineWidth=selectedRef===model.ref?2:1;ctx.strokeStyle=selectedRef===model.ref?'rgba(109,163,225,.98)':'rgba(235,243,239,.50)';ctx.strokeRect(p.x+.5,p.y+.5,Math.max(0,p.w-1),Math.max(0,p.h-1));ctx.restore();

      // Order badge stays outside the material surface, so even a 97mm drawer remains true-scale.
      ctx.save();ctx.fillStyle=selectedRef===model.ref?'rgba(91,132,183,.98)':'rgba(245,248,246,.94)';ctx.beginPath();ctx.arc(railX,p.y+p.h/2,10,0,Math.PI*2);ctx.fill();ctx.fillStyle=selectedRef===model.ref?'#fff':'#24342e';ctx.font='800 9.5px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(String(index+1),railX,p.y+p.h/2+.2);ctx.restore();

      // Exact dimensions are laid out in a separate right rail after all panels are drawn.
      // This keeps tiny drawer-front labels readable without ever inflating the physical panel height.
      dimensionLabels.push({text:`${fmtMm(model.widthMm)} × ${fmtMm(model.heightMm)} mm`,targetY:p.y+p.h/2,x0:p.x+p.w,xText:p.x+p.w+10});
      lastHit.push({ref:model.ref,x:p.x,y:p.y,w:p.w,h:p.h});
    });

    const laidOutDims=layoutDimensionLabels(dimensionLabels,fit.bounds.y+5,fit.bounds.y+fit.bounds.h-5,13);
    ctx.save();ctx.font='700 9.5px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif';ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillStyle='rgba(224,235,229,.90)';ctx.strokeStyle='rgba(224,235,229,.35)';ctx.lineWidth=1;ctx.setLineDash([]);
    for(const d of laidOutDims){
      if(Math.abs(d.labelY-d.targetY)>2){ctx.beginPath();ctx.moveTo(d.x0+3,d.targetY);ctx.lineTo(d.xText-3,d.labelY);ctx.stroke();}
      ctx.fillText(d.text,d.xText,d.labelY);
    }
    ctx.restore();

    canvas.addEventListener('click',function(ev){
      const r=canvas.getBoundingClientRect(),x=ev.clientX-r.left,y=ev.clientY-r.top;
      const hit=lastHit.find(h=>x>=h.x&&x<=h.x+h.w&&y>=h.y&&y<=h.y+h.h);if(!hit)return;
      root.__fix660SelectedGrainRef=hit.ref;schedule();
      try{if(root.ToolAGrainStudioMobile&&typeof root.ToolAGrainStudioMobile.focusRef==='function')root.ToolAGrainStudioMobile.focusRef(hit.ref);}catch(_){ }
    });
    container.dataset.fix660Rendered='1';
  }
  function updateSummary(g,summary){
    const el=document.getElementById('fix649PreviewSummary');if(!el)return;
    if(!g){el.textContent='Selecteer een nerf-set om de preview te bekijken.';return;}
    if(!summary)summary=groupDims(g).summary;
    if(!summary||!summary.count){el.textContent=`Nerfgroep ${g.id||''} · nog geen panelen`;return;}
    el.textContent=`Nerfgroep ${g.id||''} · ${summary.count} ${summary.count===1?'paneel':'panelen'} · ${fmtMm(summary.widthMm)} mm breed · ${fmtMm(summary.totalHeightMm)} mm totaal`;
  }
  function schedule(){cancelAnimationFrame(renderRaf);renderRaf=requestAnimationFrame(()=>{renderRaf=0;render(observedContainer||document.getElementById('grainPreview'));});}
  function observe(){
    const c=document.getElementById('grainPreview');if(!c)return;observedContainer=c;
    if(root.ResizeObserver){try{ro&&ro.disconnect();ro=new ResizeObserver(()=>schedule());ro.observe(c);}catch(_){ }}
  }
  function install(){
    observe();
    // Replace the old equal-height DOM-block preview globally. Input/data flow remains untouched.
    root.drawGrainPreview=function(){schedule();};
    schedule();
  }
  root.ToolAGrainStudioRenderer=Object.freeze({BUILD:'FIX660_GRAIN_STUDIO_RENDERER',render,schedule,groupDims,selectedGroup});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
})(window);
