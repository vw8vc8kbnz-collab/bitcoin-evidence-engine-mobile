(function(){
  'use strict';
  if(window.__FIX649_GRAIN_MOBILE_SCALE__) return;
  window.__FIX649_GRAIN_MOBILE_SCALE__='FIX660_GRAIN_STUDIO';
  window.__TOOLA_GRAIN_PREVIEW_BUILD='FIX660_GRAIN_STUDIO';

  function mobile(){return !!(window.matchMedia&&window.matchMedia('(max-width:700px)').matches);}
  function esc(v){return typeof _esc==='function'?_esc(v):String(v==null?'':v).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];});}
  function selectedMaterialKey(){try{return grainOverlaySelectedMaterialKey();}catch(_){return '';}}
  function widthMm(e){return Math.round(Number(e&&e.widthMm||0)*1000)/1000;}
  function heightMm(e){return Math.max(1,Number(e&&e.baseHeightMm||0)+Math.max(0,Number(e&&e.extTop||0))+Math.max(0,Number(e&&e.extBot||0)));}
  function sameWidth(a,b){try{return window.ToolAGrainStudioMath?window.ToolAGrainStudioMath.sameWidthMm(a,b):Math.abs(Number(a)-Number(b))<=.001;}catch(_){return Math.abs(Number(a)-Number(b))<=.001;}}
  function fmt(v){var x=Number(v||0);return Math.abs(x-Math.round(x))<.01?String(Math.round(x)):x.toFixed(1).replace('.',',');}
  function groupWidthMm(g){
    var w=Math.round(Number(g&&g.widthMm||0)*1000)/1000;
    if(!w&&g&&Array.isArray(g.items)&&g.items.length){var e=getGrainEntryByRef(g.items[0]);w=widthMm(e);if(w){g.widthMm=w;g.widthCm=w/10;}}
    return w;
  }
  function groupTotalHeight(g){return (g&&g.items||[]).reduce(function(sum,ref){var e=getGrainEntryByRef(ref);return sum+(e?heightMm(e):0);},0);}
  function openWidthStore(){
    var key=String(selectedMaterialKey()||'default');window.__fix660OpenWidths=window.__fix660OpenWidths||{};window.__fix660OpenWidths[key]=window.__fix660OpenWidths[key]||{};return window.__fix660OpenWidths[key];
  }
  function refreshAll(){
    try{syncGroupOrders();}catch(_){ }
    try{rebuildGrainWidthOptions();}catch(_){ }
    try{rebuildGrainEligible();}catch(_){ }
    try{rebuildGrainGroups();}catch(_){ }
    try{renderCart();}catch(_){ }
    try{syncPanelDockChrome();}catch(_){ }
    try{renderExtraPanels();}catch(_){ }
    try{syncChecksFromSelect();}catch(_){ }
    try{drawExtraPreview();}catch(_){ }
    try{drawGrainPreview();}catch(_){ }
    try{setGrainMsg('');}catch(_){ }
  }
  function targetGroup(){
    try{
      ensureStateShape();syncSelectedGrainGroupForMaterial();var id=String(state&&state.grain&&state.grain.selectedGroupId||''),mk=selectedMaterialKey();
      var g=(state.grain.groups||[]).find(function(x){return String(x&&x.id||'')===id&&String(x&&x.materialKey||'')===String(mk||'');});
      if(!g)g=(state.grain.groups||[]).find(function(x){return String(x&&x.materialKey||'')===String(mk||'');})||null;
      if(!g){newGroup();id=String(state.grain.selectedGroupId||'');g=(state.grain.groups||[]).find(function(x){return String(x&&x.id||'')===id;})||null;}
      return g;
    }catch(_){return null;}
  }
  function addMany(refs,requested){
    try{
      var g=targetGroup();if(!g)return;
      var entries=(refs||[]).map(function(ref){return getGrainEntryByRef(ref);}).filter(Boolean).filter(function(e){return !e.grainGroupId;});if(!entries.length)return;
      var count=requested==='all'?entries.length:Math.max(1,Math.min(entries.length,Number(requested)||1));var added=0,gw=groupWidthMm(g);
      for(var i=0;i<entries.length&&added<count;i++){
        var e=entries[i],w=widthMm(e);if(!isGrainCapable(e.raw))continue;
        if(gw&&!sameWidth(gw,w)){try{setGrainMsg('Dit paneel heeft niet exact dezelfde werkelijke breedte als de actieve nerf-set. Maak hiervoor een nieuwe nerf-set.');}catch(_){ }break;}
        if(!gw){gw=w;g.widthMm=w;g.widthCm=w/10;}
        var ref=String(e.ref||'');if(!ref||g.items.map(String).indexOf(ref)!==-1)continue;g.items.push(ref);added++;
      }
      if(added){state.grain.selectedGroupId=g.id;syncGroupOrders();refreshAll();}
    }catch(_){ }
  }

  var originalEligible=typeof rebuildGrainEligible==='function'?rebuildGrainEligible:null;
  var originalGroups=typeof rebuildGrainGroups==='function'?rebuildGrainGroups:null;
  var originalPreview=typeof drawGrainPreview==='function'?drawGrainPreview:null;

  function renderMobileEligible(){
    if(!grainEligible||!grainEligibleCount)return;grainEligible.innerHTML='';var eligible=getGrainEligibleEntries();grainEligibleCount.textContent=String(eligible.length);if(grainIncludeExtraToggle)grainIncludeExtraToggle.checked=!!grainExtrasEnabled();
    if(!eligible.length){var empty=document.createElement('div');empty.className='help';empty.textContent='Geen panelen beschikbaar. Zet nerfrichting aan en voeg minimaal twee panelen met exact dezelfde werkelijke breedte toe.';grainEligible.appendChild(empty);return;}
    var byWidth=new Map();eligible.forEach(function(e){var w=widthMm(e);if(!byWidth.has(w))byWidth.set(w,[]);byWidth.get(w).push(e);});
    var widths=Array.from(byWidth.keys()).sort(function(a,b){return a-b;}),fw=grainWidthSel?grainWidthSel.value:'all';if(fw&&fw!=='all')widths=widths.filter(function(w){return sameWidth(w,Number(fw));});
    var store=openWidthStore();if(widths.length&&!widths.some(function(w){return store[String(w)];}))store[String(widths[0])]=true;
    widths.forEach(function(w){
      var entries=byWidth.get(w)||[],availableCount=entries.filter(function(e){return !e.grainGroupId;}).length,wrap=document.createElement('section');wrap.className='fix649WidthAccordion'+(store[String(w)]?' is-open':'');
      var head=document.createElement('button');head.type='button';head.className='fix649WidthHeader';head.setAttribute('aria-expanded',store[String(w)]?'true':'false');head.innerHTML='<strong>'+esc(fmt(w))+' mm breed</strong><span class="fix649WidthCount">'+availableCount+'/'+entries.length+'</span><span class="fix649Chevron">⌄</span>';
      var body=document.createElement('div');body.className='fix649WidthBody';head.addEventListener('click',function(){store[String(w)]=!store[String(w)];wrap.classList.toggle('is-open',!!store[String(w)]);head.setAttribute('aria-expanded',store[String(w)]?'true':'false');});wrap.appendChild(head);wrap.appendChild(body);
      [{key:'cart',title:'METOD panelen'},{key:'extra',title:'Overige panelen'}].forEach(function(sec){
        var secEntries=entries.filter(function(e){return e.kind===sec.key;});if(!secEntries.length)return;var label=document.createElement('div');label.className='fix649SectionLabel';label.textContent=sec.title;body.appendChild(label);
        var displayGroups=_groupGrainDisplayEntries(secEntries).sort(function(a,b){return String(a&&a.rep&&a.rep.label||'').localeCompare(String(b&&b.rep&&b.rep.label||''));});
        displayGroups.forEach(function(group){
          var rep=group.rep,total=Math.max(1,group.items.length),available=group.items.filter(function(x){return !x.grainGroupId;}),row=document.createElement('div');row.className='fix649PanelRow';
          var main=document.createElement('div');main.className='fix649PanelMain';main.innerHTML='<div class="fix649PanelName">'+esc(rep.label)+'</div><div class="fix649PanelMeta">'+esc(fmt(widthMm(rep)))+' × '+esc(fmt(heightMm(rep)))+' mm'+esc(grainDoorDirectionLabel(rep.raw))+esc(grainExtLabel(rep.raw))+(rep.kind==='extra'?' · overig':'')+'</div><div class="fix649PanelAvailability">'+available.length+' van '+total+' beschikbaar</div>';
          var actions=document.createElement('div');actions.className='fix649AddActions';[['+1',1,true],['+5',5,false],['Alles','all',false]].forEach(function(spec){var btn=document.createElement('button');btn.type='button';btn.className='fix649AddBtn'+(spec[2]?' is-primary':'');btn.textContent=spec[0];btn.disabled=!available.length;btn.addEventListener('click',function(ev){ev.stopPropagation();addMany(available.map(function(x){return x.ref;}),spec[1]);});actions.appendChild(btn);});
          row.appendChild(main);row.appendChild(actions);body.appendChild(row);
        });
      });grainEligible.appendChild(wrap);
    });
  }

  function makeMini(e){
    var box=document.createElement('div');box.className='fix660PanelMiniBox';var shape=document.createElement('div');shape.className='fix660PanelMiniShape';var w=Math.max(1,widthMm(e)),h=Math.max(1,heightMm(e)),mw=28,mh=34,sc=Math.min(mw/w,mh/h);shape.style.width=Math.max(4,w*sc)+'px';shape.style.height=Math.max(3,h*sc)+'px';box.appendChild(shape);return box;
  }
  function groupSummary(g){var w=groupWidthMm(g),h=groupTotalHeight(g);return (w?fmt(w)+' mm breed':'breedte nog niet bepaald')+' · '+g.items.length+' '+(g.items.length===1?'paneel':'panelen')+(h?' · '+fmt(h)+' mm totaal':'');}
  function updateOrderBadges(body){body.querySelectorAll('.fix660GroupItem').forEach(function(el,i){var b=el.querySelector('.fix660OrderBadge');if(b)b.textContent=String(i+1);var m=el.querySelector('.fix660Position');if(m)m.textContent='positie '+(i+1)+'/'+body.querySelectorAll('.fix660GroupItem').length;});}
  function bindTouchReorder(handle,item,body,g){
    var active=false,startY=0,moved=false;
    function finish(ev){if(!active)return;active=false;try{handle.releasePointerCapture(ev.pointerId);}catch(_){ }item.classList.remove('is-dragging');document.body.classList.remove('fix660GrainReordering');if(moved){var refs=Array.from(body.querySelectorAll('.fix660GroupItem')).map(function(el){return String(el.dataset.ref||'');}).filter(Boolean);g.items=refs;syncGroupOrders();refreshAll();}moved=false;}
    handle.addEventListener('pointerdown',function(ev){if(ev.button!=null&&ev.button!==0)return;active=true;moved=false;startY=ev.clientY;try{handle.setPointerCapture(ev.pointerId);}catch(_){ }item.classList.add('is-dragging');document.body.classList.add('fix660GrainReordering');ev.preventDefault();});
    handle.addEventListener('pointermove',function(ev){if(!active)return;if(Math.abs(ev.clientY-startY)>5)moved=true;var target=document.elementFromPoint(ev.clientX,ev.clientY);target=target&&target.closest&&target.closest('.fix660GroupItem');if(!target||target===item||target.parentElement!==body)return;var r=target.getBoundingClientRect();if(ev.clientY<r.top+r.height/2)body.insertBefore(item,target);else body.insertBefore(item,target.nextSibling);updateOrderBadges(body);});
    handle.addEventListener('pointerup',finish);handle.addEventListener('pointercancel',finish);
  }
  function renderMobileGroups(){
    if(!grainGroups)return;grainGroups.innerHTML='';var mk=selectedMaterialKey(),list=(state.grain.groups||[]).filter(function(g){return !mk||String(g.materialKey||'')===String(mk);});syncSelectedGrainGroupForMaterial();
    if(!list.length){var no=document.createElement('div');no.className='help';no.textContent='Nog geen nerf-sets. Maak een set en voeg panelen toe.';grainGroups.appendChild(no);drawGrainPreview();return;}
    list.forEach(function(g){
      var selected=String(state.grain.selectedGroupId||'')===String(g.id||''),wrap=document.createElement('section');wrap.className='fix649GroupAccordion'+(selected?' is-selected':'');wrap.dataset.groupId=g.id;
      var header=document.createElement('div');header.className='fix649GroupHeader',select=document.createElement('button');select.type='button';select.className='fix649GroupSelect';select.innerHTML='<span class="fix649GroupTitle">Nerfgroep '+esc(g.id)+'</span><span class="fix649GroupMeta">'+esc(groupSummary(g))+'</span>';
      var count=document.createElement('span');count.className='fix649WidthCount';count.textContent=String(g.items.length),del=document.createElement('button');del.type='button';del.className='fix649GroupDelete';del.title='Verwijder nerf-set';del.setAttribute('aria-label','Verwijder nerf-set');del.textContent='×';header.appendChild(select);header.appendChild(count);header.appendChild(del);wrap.appendChild(header);
      var body=document.createElement('div');body.className='fix649GroupBody fix660GroupBody';var hint=document.createElement('div');hint.className='fix649GroupHint';hint.textContent='Sleep aan de greep om de volgorde te wijzigen. De preview gebruikt de echte paneelverhoudingen.';body.appendChild(hint);
      if(!g.items.length){var empty=document.createElement('div');empty.className='fix649GroupEmpty';empty.textContent='Nog geen panelen in deze nerf-set.';body.appendChild(empty);}else{
        g.items.forEach(function(ref,order){var e=getGrainEntryByRef(ref);if(!e)return;var item=document.createElement('div');item.className='fix660GroupItem'+(String(window.__fix660SelectedGrainRef||'')===String(ref)?' is-selected':'');item.dataset.ref=String(ref);item.dataset.groupId=String(g.id);
          var badge=document.createElement('div');badge.className='fix660OrderBadge';badge.textContent=String(order+1);item.appendChild(badge);item.appendChild(makeMini(e));
          var main=document.createElement('button');main.type='button';main.className='fix660GroupItemMain';main.innerHTML='<span class="fix649GroupItemName">'+esc(e.label)+'</span><span class="fix649GroupItemMeta">'+esc(fmt(widthMm(e)))+' × '+esc(fmt(heightMm(e)))+' mm'+esc(grainDoorDirectionLabel(e.raw))+esc(grainExtLabel(e.raw))+(e.kind==='extra'?' · overig':'')+' · <span class="fix660Position">positie '+(order+1)+'/'+g.items.length+'</span></span>';main.addEventListener('click',function(){window.__fix660SelectedGrainRef=String(ref);rebuildGrainGroups();drawGrainPreview();});item.appendChild(main);
          var drag=document.createElement('button');drag.type='button';drag.className='fix660DragHandle';drag.setAttribute('aria-label','Sleep om volgorde te wijzigen');drag.title='Sleep om volgorde te wijzigen';drag.innerHTML='<span></span><span></span><span></span>';item.appendChild(drag);
          var rm=document.createElement('button');rm.type='button';rm.className='fix660RemoveBtn';rm.setAttribute('aria-label','Verwijder uit nerf-set');rm.title='Verwijder uit nerf-set';rm.textContent='×';rm.addEventListener('click',function(ev){ev.stopPropagation();removeFromGroup(g.id,ref);});item.appendChild(rm);body.appendChild(item);bindTouchReorder(drag,item,body,g);
        });
      }
      wrap.appendChild(body);select.addEventListener('click',function(){state.grain.selectedGroupId=g.id;rebuildGrainGroups();drawGrainPreview();});del.addEventListener('click',function(ev){ev.stopPropagation();state.grain.groups=state.grain.groups.filter(function(x){return x.id!==g.id;});if(state.grain.selectedGroupId===g.id)state.grain.selectedGroupId=state.grain.groups[0]&&state.grain.groups[0].id||null;refreshAll();});grainGroups.appendChild(wrap);
    });
  }

  rebuildGrainEligible=function(){if(mobile())return renderMobileEligible();return originalEligible&&originalEligible();};
  rebuildGrainGroups=function(){if(mobile())return renderMobileGroups();return originalGroups&&originalGroups();};
  drawGrainPreview=function(){var out=originalPreview&&originalPreview();syncPreviewSummary();return out;};

  function syncPreviewSummary(){
    var summary=document.getElementById('fix649PreviewSummary');if(!summary)return;try{var g=(state.grain.groups||[]).find(function(x){return String(x.id||'')===String(state.grain.selectedGroupId||'');});summary.textContent=g?('Nerfgroep '+g.id+' · '+groupSummary(g)):'Selecteer een nerf-set om de preview te bekijken.';}catch(_){summary.textContent='Selecteer een nerf-set om de preview te bekijken.';}
  }

  var drawer=null,drawerHandle=null,drawerArrow=null,mobileActions=null,dragging=false,dragStartY=0,dragStartOffset=0,suppressClick=false;
  function drawerTravel(){if(!drawer)return 0;return Math.max(0,drawer.getBoundingClientRect().height-88);}
  function drawerExpanded(){return !!(drawer&&drawer.classList.contains('fix660DrawerOpen'));}
  function applyDrawerTransform(offset){if(!drawer)return;drawer.style.transform='translateY('+Math.max(0,Math.min(drawerTravel(),offset))+'px)';}
  function setDrawer(open,instant){if(!drawer)return;drawer.classList.toggle('fix660DrawerOpen',!!open);drawer.classList.toggle('fix660DrawerPeek',!open);drawer.style.removeProperty('transform');if(drawerArrow)drawerArrow.textContent=open?'⌄':'⌃';drawer.setAttribute('aria-expanded',open?'true':'false');window.__fix660GrainDrawerOpen=!!open;if(open){try{drawGrainPreview();}catch(_){ }if(!instant)setTimeout(function(){try{drawGrainPreview();}catch(_){ }},220);}}
  function buildMobileActions(){
    if(!mobile()||mobileActions)return;var modal=document.querySelector('#grainOverlay .modal');if(!modal)return;mobileActions=document.createElement('div');mobileActions.className='fix660MobileActions';var cancel=document.createElement('button');cancel.type='button';cancel.className='btn';cancel.textContent='Annuleren';cancel.addEventListener('click',function(){var b=document.getElementById('grainCancelBtn');if(b)b.click();});var apply=document.createElement('button');apply.type='button';apply.className='btn btnPrimary';apply.textContent='Toepassen';apply.addEventListener('click',function(){var b=document.getElementById('grainApplyBtn');if(b)b.click();});mobileActions.appendChild(cancel);mobileActions.appendChild(apply);modal.appendChild(mobileActions);
  }
  function initDrawer(){
    if(!mobile())return;drawer=document.querySelector('#grainOverlay .grainPreviewCard');if(!drawer)return;drawer.classList.add('fix660PreviewDrawer');
    var oldToggle=document.getElementById('fix649PreviewToggle');if(oldToggle)oldToggle.hidden=true;
    if(!drawer.querySelector('.fix660DrawerHandle')){drawerHandle=document.createElement('button');drawerHandle.type='button';drawerHandle.className='fix660DrawerHandle';drawerHandle.setAttribute('aria-label','Open of sluit nerf-preview');drawerHandle.innerHTML='<span class="fix660DrawerGrip"></span><span class="fix660DrawerHandleText">Preview</span><span class="fix660DrawerArrow">⌃</span>';drawer.insertBefore(drawerHandle,drawer.firstChild);drawerArrow=drawerHandle.querySelector('.fix660DrawerArrow');
      drawerHandle.addEventListener('click',function(ev){if(suppressClick){suppressClick=false;return;}ev.preventDefault();setDrawer(!drawerExpanded());});
      drawerHandle.addEventListener('pointerdown',function(ev){if(ev.button!=null&&ev.button!==0)return;dragging=true;suppressClick=false;dragStartY=ev.clientY;dragStartOffset=drawerExpanded()?0:drawerTravel();drawer.classList.add('fix660DrawerDragging');try{drawerHandle.setPointerCapture(ev.pointerId);}catch(_){ }ev.preventDefault();});
      drawerHandle.addEventListener('pointermove',function(ev){if(!dragging)return;var dy=ev.clientY-dragStartY;if(Math.abs(dy)>5)suppressClick=true;applyDrawerTransform(dragStartOffset+dy);});
      function finish(ev){if(!dragging)return;dragging=false;drawer.classList.remove('fix660DrawerDragging');try{drawerHandle.releasePointerCapture(ev.pointerId);}catch(_){ }var dy=ev.clientY-dragStartY,travel=drawerTravel(),cur=Math.max(0,Math.min(travel,dragStartOffset+dy));setDrawer(cur<travel*.48,true);}
      drawerHandle.addEventListener('pointerup',finish);drawerHandle.addEventListener('pointercancel',finish);
    }else{drawerHandle=drawer.querySelector('.fix660DrawerHandle');drawerArrow=drawerHandle.querySelector('.fix660DrawerArrow');}
    buildMobileActions();setDrawer(!!window.__fix660GrainDrawerOpen,true);syncPreviewSummary();
  }
  function teardownDrawer(){if(drawer){drawer.classList.remove('fix660PreviewDrawer','fix660DrawerOpen','fix660DrawerPeek','fix660DrawerDragging');drawer.style.removeProperty('transform');}if(mobileActions){mobileActions.remove();mobileActions=null;}drawer=null;drawerHandle=null;drawerArrow=null;}
  function focusRef(ref){
    window.__fix660SelectedGrainRef=String(ref||'');try{rebuildGrainGroups();}catch(_){ }try{drawGrainPreview();}catch(_){ }
    setTimeout(function(){try{var el=document.querySelector('#grainGroups .fix660GroupItem[data-ref="'+CSS.escape(String(ref||''))+'"]');if(el)el.scrollIntoView({behavior:'smooth',block:'center'});}catch(_){ }},20);
  }
  function rerenderOnViewport(){try{if(mobile())initDrawer();else teardownDrawer();if(document.getElementById('grainOverlay')&&document.getElementById('grainOverlay').style.display!=='none'){rebuildGrainEligible();rebuildGrainGroups();drawGrainPreview();}}catch(_){} }
  function start(){if(mobile())initDrawer();try{var mq=window.matchMedia('(max-width:700px)');if(mq.addEventListener)mq.addEventListener('change',rerenderOnViewport);else if(mq.addListener)mq.addListener(rerenderOnViewport);}catch(_){}}
  window.ToolAGrainStudioMobile={BUILD:'FIX660_GRAIN_STUDIO_MOBILE',focusRef,openPreview:function(){if(mobile()){initDrawer();setDrawer(true);}},closePreview:function(){if(mobile())setDrawer(false);}};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
