# v7.3.7 — Login role separation fix

- Zakelijk inloggen kiest nu expliciet alleen een partneraccount.
- Persoonlijk inloggen valt niet meer door naar partneraccounts.
- ADMIN_EMAIL promoveert accounts niet meer automatisch bij login; beheer blijft via bestaand admin-account of beheer-PIN.
- Fix voor edgecase waarin zakelijke login met hetzelfde e-mailadres als beheer/admin ineens in `/beheer` terecht kon komen.
- Oude/cached loginforms zonder accountType worden nu geweigerd in plaats van naar de verkeerde rol te vallen.
- Role audit waarschuwt expliciet als ADMIN_EMAIL op een zakelijk/partneraccount staat.

# v7.3.6 — Fullscreen Listing UX

- Listing overlay is nu een bijna fullscreen native-style sheet.
- Toegevoegd: topbar met Terug en sluiten.
- Omlaag slepen sluit de product-sheet.
- Gallery groter en productcontent scrollt intern.
- Sticky koop/bod CTA onderin de sheet.

# v7.3.5 — Workstream A1/A3: role audit + gesloten werelden

- Accountpagina toont Partner Hub alleen nog bij echte approved partneraccounts met actieve partnerSlug + seller-record.
- Zakelijke registratie maakt nu direct een zakelijk `partner` account in pending-status, geen persoonlijk account met partnerflags.
- Partneraanvraag-API blokkeert persoonlijke accounts harder; alleen zakelijke accounts mogen partnerstatus dragen.
- `isApprovedPartner()` accepteert geen admin meer als partner; admin blijft in Beheer, partner blijft in Partner Hub.
- Login-redirect stuurt admin naar `/beheer`, approved partners naar `/partner`, pending zakelijke accounts naar `/word-partner`.
- Beheer heeft een nieuwe Role audit-sectie voor dubbele emails, koperaccounts met partnerflags, missende slugs en ontbrekende seller-records.

# v7.3.4 — Workstream A2/A4: auditlog + notificaties

- Toegevoegd: centrale auditlog (`db.auditLog`) voor order, bod, chat, retour, dispute, review, listing en partner/admin-acties.
- Toegevoegd: beheer-download voor auditlogs als JSONL en CSV via `/api/admin/audit/export`.
- Beheerpagina toont nu recente audit-events + downloadknoppen.
- Auditlog capped op laatste 5000 events, zodat JSON-store niet onnodig groeit.
- Notificatieflows blijven via bestaande push/in-app laag lopen; belangrijke acties worden nu daarnaast traceerbaar gelogd.
- Service-worker cacheversie verhoogd.


## v7.3.3 — Workstream A1/A3: gesloten buyer/partner werelden

- Persoonlijke kopersaccounts kunnen niet meer worden omgezet naar partneraccount via `/word-partner`.
- Partneraanvraag verloopt nu via een apart zakelijk account (`/welkom?type=zakelijk&next=/partner`).
- Backend `/api/partner-aanvraag` weigert conversie van buyer-only accounts.
- Checkout en biedingen zijn geblokkeerd voor zakelijke/pending/partner/admin accounts; alleen persoonlijke kopersaccounts mogen kopen/bieden.
- Partner order PATCH is aangescherpt: alleen eigen orders, open retour blokkeert acties, bevestigen alleen vanaf `paid`, geleverd melden alleen vanaf `delivery_planned`.
- Kleine autorelease-copy fix: 7/14 dagen volgt nu trusted/new partner-logica.

# v7.3.2 — Workstream B: zichtbare fixes

- Hero/fototegel op homepage weer netjes binnen schermbreedte op mobiel.
- Listing action grid aangescherpt: “Koop veilig”, “Partner bekijken” en “Doe een bod” strakker uitgelijnd.
- Partner-dashboard krijgt nu rechtsboven ook een meldingenbel met unread badge, zodat chat/order/bod-notificaties intern zichtbaar zijn naast iOS push.
- Service-worker cacheversie verhoogd naar `oiq-v4`.

# v5.1.0 — Lege, testbare marketplace
- Alle demo-listings, nepfoto's (Unsplash), nepcijfers en nep-sellers verwijderd.
- JSON-datastore (`lib/store.ts`, `lib/types.ts`, `lib/data.ts` als accessor-laag).
- AI Model Abstraction Layer (`lib/ai/`): DeepSeek-provider + heuristische fallback; bron zichtbaar in UI.
- Seller-flow /seller/nieuw volledig functioneel: upload → gegevens → AI-analyse → strategie/eigen prijs → publiceren.
- Foto-upload API (`/api/seller/upload`), pricing API, listings API, orders API (+ koper-bevestiging).
- Orders: statusmachine + commissie/escrow-berekening; seller-acties op /seller/orders; Geld-pagina uit ledger.
- PIN-gate (middleware) op /seller/* en /api/seller/*; loginpagina.
- Bewaard via localStorage (testfase, geen accounts); SaveButton op listing.
- Empty states op alle pagina's (Masterplan: launch-stage homepage).
- Evidence strip her-verankerd op nieuwprijs (FAST · OUTLET · NIEUW) — geen verzonnen "markt".
- Fixes: `.foot` boven de dock, sparkline uit echte dagomzet.

# v5.0.0 — v5 UI-shell (12 schermen, demo-data)

# v5.2.0 — Desktop + verankering VPS-fixes
- Volledige desktop-layout (≥1024px), zelfde designsysteem: koper krijgt sticky topnav
  (logo · Ontdek/Zoeken/Bewaard/Account · zoekbalk · amber "+ Verkopen"), brede grids
  (rail 4-5 kolommen, resultaten 2 kolommen, hover-lift), feature card 380px,
  listingpagina in 2 kolommen met sticky media; listing-overlay wordt gecentreerde modal.
- Seller Hub op desktop: fintech-sidebar (Dashboard/Voorraad/Orders/Geld/Storefront,
  "+ Nieuw product", terug-naar-shop), content max 960px. Mobiel blijft pixel-identiek (docks).
- Mobiele headers (.hd) verborgen op desktop; navigatie loopt via topnav/sidebar.
- DeepSeek-adapter definitief: robuuste getal-parser (€/strings/NL-notatie),
  auto-reparatie bij omgedraaide fast/outlet/premium (sorteren i.p.v. afkeuren),
  aangescherpte prompt, ruwe modeloutput naar logs bij afkeuring.
- Workflow: npm install i.p.v. npm ci (geen lockfile in zip); pm2-fallback in updateregel.

# v6.0.0 — Twee Werelden: accounts, rollen, Partner
- Echte accounts: e-mail + verificatiecode + wachtwoord (scrypt, node:crypto), httpOnly-sessies
  (30 dagen, server-side intrekbaar), rate-limiting op login/codes. Testfase: codes in serverlog.
- /welkom: professionele entree (petrol-hero + trustpunten + registratie/login), splash → welkom.
- REQUIRE_AUTH=hard|soft (default hard): pilot met verplicht account, gastmodus als schakelaar.
- Hernoeming: seller → Partner. Routes /partner/*, "Outrun IQ Partner", consumenten zonder label.
- Harde wereldscheiding: partnerwereld server-side rol-gated (goedgekeurde partners); consumenten-
  dock-plus is nu de ✦ AI Vinder (beschrijf wat je zoekt → DeepSeek vertaalt naar zoektermen →
  matches uit het live aanbod); partner-ingang alleen via "Word partner" in Account/welkom.
- Partner-onboarding: aanvraag (bedrijfsnaam/KvK/plaats) → status in behandeling → goedkeuring
  via /beheer?pin=ADMIN_PIN → storefront + partnerrol; SELLER_PIN vervallen.
- Alles account-gebonden: bewaard (server-side + localStorage-migratie, prijsdaling-badge),
  bestellingen (eigendomscontrole), checkout vereist login, partnerpagina's tonen alleen eigen
  listings/orders/geld, nieuw-product-flow gebruikt het partnerprofiel (bedrijfsvelden weg).
- Notificatiecentrum: orderevents naar klant én partner, bel met badge op home, /meldingen.
- LET OP: datamodel gewijzigd — wis data/db.json op de VPS voor een schone start.

# v6.1.0 — Vision: foto vult de listing
- Nieuwe vision-taakroute in de AI-laag (lib/ai/vision.ts, OpenAI-compatibel beeldformaat;
  default DeepSeek-endpoint, overschrijfbaar via VISION_MODEL/VISION_BASE_URL/VISION_API_KEY).
- Na de eerste foto-upload herkent de AI automatisch titel, merk, categorie, conditie (+score),
  zichtbaar gebrek en een geschatte nieuwprijs, en vult stap 2 vooraf in — eigen invoer wordt
  nooit overschreven; alles blijft aanpasbaar. Nette fallback als de provider geen beelden kan.
- KvK-veld toont nu een live cijferteller (8 vereist) in de partneraanvraag.

# v6.2.0 — Registratie-split + drie kritieke fixes
- Registratie kent nu twee accounttypes op /welkom: Persoonlijk of Zakelijk (Outrun IQ
  Partner). Zakelijk registreert bedrijfsnaam + KvK + plaats direct mee → partnerstatus
  "in behandeling" vanaf minuut één; na registratie/login landt een pending zakelijk
  account op de statuspagina, een goedgekeurde partner in de Partner Hub. Eén loginformulier
  voor beide types (rol bepaalt de landing).
- FIX foto's onzichtbaar: runtime-uploads verhuisd van public/uploads naar DATA_DIR/uploads
  en geserveerd via nieuwe route GET /uploads/[name] (Next serveert in productie geen
  bestanden die ná de build in public/ belanden). Legacy-locatie blijft leesbaar als fallback.
- FIX mobiele overlay stond rechts: sheet-centrering via left/right+margin i.p.v.
  translateX (de drag-transform overschreef de centrering); desktop-modal ongewijzigd.
- FIX "Koop nu" deed niets vanuit de overlay: @modal-catch-all toegevoegd zodat het
  parallel-slot sluit bij navigatie naar elke niet-geïntercepte route (Next houdt anders
  de laatste slot-inhoud vast over de nieuwe pagina heen).

# v6.3.0 — Ready-to-go: juridisch fundament + drie structurele fixes + connectielaag
- FIX overlay-scroll (kritiek): BottomSheet herbouwd op hoogte-model — de sheet animeert
  zijn hoogte i.p.v. te verschuiven, waardoor de inhoud (incl. "Koop nu") ALTIJD bereikbaar
  is; snap-points 55/92%, iOS-scroll (touch-action/overflow-scrolling), scrim-tik sluit.
- AI Vinder is nu echte AI: het model beoordeelt de volledige live catalogus per klantwens
  (alleen score ≥ 55, liever 0 dan ruis), met NL-interpretatiezin en prijsplafond-parsing
  ("max €600"); fallback = gescoorde trefwoordmatch met drempel — geeft nooit meer alles terug.
- Login kent nu ook de keuze Persoonlijk/Zakelijk (bepaalt de landing: shop, Partner Hub
  of partnerstatus/upgradepad).
- Juridisch fundament: /juridisch met Partnervoorwaarden (12 artikelen: bemiddelaarsrol,
  verificatie, informatieplicht, AI-disclaimer, escrow, 10% commissie, consumentenrecht,
  anti-omzeiling, aansprakelijkheid, IE/verwerking, beëindiging, NL recht), Gebruiksvoor-
  waarden, Privacyverklaring (AVG incl. expliciete AI-verwerking: productdata → DeepSeek,
  foto's → OpenAI; bewaartermijnen; rechten) en Cookieverklaring (alleen functioneel, geen
  banner vereist). Akkoord-checkbox verplicht bij zakelijke registratie én partneraanvraag,
  server-side afgedwongen en vastgelegd (partnerProfile.termsAcceptedAt); voorwaarden-links
  op welkom, account (Juridisch-groep) en in de checkout.
- Listing-beheer voor partners: pauzeren/activeren, prijs wijzigen (met priceLog, guards
  onder nieuwprijs, fast/premium schuiven mee) en verwijderen met bevestigingstik —
  via PATCH/DELETE /api/partner/listings/[id], eigendomsgecontroleerd.
- Fotogalerij met swipe (scroll-snap) en live teller op listingpagina én overlay.
- Zoeken: werkende sortering (Nieuwste/Prijs/Korting) via URL; dode filter-chips verwijderd.
- Nette 404-pagina in de app-shell.

# v6.4.0 — Doordacht & vertrouwd: fulfilment, escrow-autorelease, disputes, branding
- Waterdichte escrow-tijdlijn: nieuwe orderstatus "delivered" (partner markeert GELEVERD)
  → klant heeft ESCROW_RELEASE_DAYS (default 7) om te bevestigen of een probleem te melden
  → daarna automatische vrijgave via lazy sweep (geen cron; draait op orderlezende pagina's,
  schrijft alleen bij echte releases, met events + notificaties beide kanten). Deadline
  expliciet zichtbaar op de orderpagina. Dispute bevriest alles onmiddellijk.
- Dispute-flow: klant meldt probleem (categorie + toelichting) → order bevroren, uitbetaling
  en partner-acties geblokkeerd → beheer handelt af: VRIJGEVEN of ANNULEREN (voorraad terug),
  met notificaties. /beheer toont open disputes.
- Fulfilment doordacht: bezorgadres verplicht en gevalideerd bij bezorgen (postcode-check),
  opgeslagen op de order en zichtbaar voor de partner; ophalen krijgt het afhaal-/magazijn-
  adres van de partner plus een persoonlijke 6-teken AFHAALCODE (klant toont, magazijn
  verifieert). Partner-orderregels tonen adres of AFHAAL+code en de magazijnreferentie.
- Referentie/SKU per listing (optioneel veld in de flow), gesnapshot op orders en zichtbaar
  in orders én geld — voor partners met grote magazijnen.
- Partner-branding: logo-upload + "over jullie" (280 tekens) + afhaaladres via de nieuwe
  storefront-editor; logo verschijnt bij listings, op de storefront en in de partner-preview.
- Juridische pagina's hebben nu een echte terugweg (Terug-knop + "Terug naar de app").
- Visuele naloop: consistente kopmarges, voorraad-rijen met acties netjes gegroepeerd,
  avatar-uitlijning, kleine spacing-fixes.
- Bezorg-integratie (Brenger) bewust als latere adapter-module; het adres-/slotfundament
  ligt er nu voor.

# v6.5.0 — Retouren waterdicht + partnerservice + scans
- Volledig retoursysteem ná afronding: klant vraagt retour aan binnen RETURN_WINDOW_DAYS
  (14) met reden → partner MOET binnen RETURN_RESPONSE_DAYS (3) reageren met instructies
  (deadline zichtbaar) → geen reactie = klant escaleert naar Outrun IQ (partner krijgt
  systeemwaarschuwing "telt mee voor je partnerstatus", beheer handelt af) → partner
  markeert "retour ontvangen" = afgerond. Notificaties op elke stap; alles in de app zodat
  termijnen vastliggen.
- Juridisch: nieuwe Retourvoorwaarden (retouren lopen via de partner; platform bemiddelt
  maar is geen partij en niet betalingsplichtig; escalatie-mechanisme; terugbetaling en
  kostenverdeling wettelijk correct; uitzonderingen) + Partnervoorwaarden artikel 13
  (reactie-SLA, uitbetalingen opschorten als drukmiddel, schorsing, kostenverhaal).
- Klantenservice verplicht: partner vult service-e-mail (+telefoon/retourinfo) in via de
  storefront-editor; publiceren is GEBLOKKEERD zonder deze gegevens; klant ziet ze bij
  zijn retouraanvraag.
- Scan-fixes: partner kan zijn eigen listing niet meer kopen (server-side guard); mobiele
  partner-header zei nog "SELLER HUB" (JSX-variant gemist) → PARTNER HUB; storefront was
  op mobiel ONBEREIKBAAR → header-icoon + dashboard-kaart "Maak je storefront af" zolang
  logo of klantenservice ontbreekt.
- Juridische pagina's: mobiele uitlijning gefixt (padding).
- Vision: "Herken opnieuw"-knop na een mislukte fotoherkenning.

# v6.6.0 — Escrow-slimheid: retour bevriest geld, terugstorten uit escrow, risicogestuurde vrijgave
- Retour aanvragen kan nu al vanaf status "geleverd" (niet pas na afronding). Een open
  retouraanvraag PAUZEERT de escrow-autorelease: het geld blijft bij Outrun IQ staan
  zolang de aanvraag loopt (zichtbaar gemeld aan de koper).
- Wordt een retour afgerond terwijl de uitbetaling nog niet is gedaan, dan gaat het bedrag
  (testmodus) rechtstreeks uit escrow terug naar de koper, wordt de order geannuleerd en
  de voorraad teruggeboekt — het bedrijf heeft het geld dan nooit gehad.
- Risicogestuurde vrijgave (bol-model): nieuwe partners ESCROW_RELEASE_DAYS_NEW (14),
  bewezen partners ESCROW_RELEASE_DAYS (7). Toggle "MARKEER VERTROUWD" per partner op
  /beheer; de orderpagina en sweep rekenen automatisch met de juiste termijn.
- Juridisch aangescherpt: verrekeningsbeding in Partnervoorwaarden art. 13 (terugbetalingen
  en kosten verrekenbaar met toekomstige uitbetalingen), retourtransport zwart-wit in de
  Retourvoorwaarden (spijt = klant betaalt; defect/afwijkend/verkeerd = partner regelt of
  vergoedt, bij grote artikelen haalt de partner op), en de escrow-pauze bij retour vóór
  uitbetaling expliciet vastgelegd.

# v6.7.0 — De handel-module + cruciale app-basics
- BIEDEN: koper doet een bod op elke actieve listing (onder de vraagprijs, één lopend bod
  per listing) met optioneel bericht — contactgegevens in het bericht worden automatisch
  afgeschermd (anti-omzeiling: mail, 06-nummers, links, whatsapp/telegram). Live
  acceptatie-indicatie op basis van het AI-prijsbewijs (≥ fast = grote kans). Partner ziet
  biedingen bovenaan Orders: ACCEPTEER / TEGENBOD (moet tussen bod en vraagprijs) / WIJS AF.
  Koper kan een tegenbod accepteren of zijn bod intrekken. Geaccepteerd bod → afrekenen
  tegen de bodprijs via een beveiligde checkout-link (bod wordt gevalideerd en verbruikt;
  commissie rekent over de bodprijs).
- BEZORGMOMENT: "Plan levering" is nu een echte afstemming — partner stelt max. 3 momenten
  voor (datetime, alleen toekomst), koper kiest op de orderpagina, beide kanten zien het
  gekozen moment en krijgen notificaties.
- ORDER-CHAT: koper en partner chatten per order (orderpagina resp. nieuw partner-
  orderdetail /partner/orders/[id], bereikbaar via de orderregel). Berichten cap 500
  tekens / laatste 200 bewaard; notificatie naar de andere kant.
- WACHTWOORD VERGETEN: volledige herstel-flow op /welkom (e-mail → herstelcode via
  mail-adapter → nieuw wachtwoord; alle sessies vervallen; geen account-enumeratie;
  rate-limited).
- ACCOUNT VERWIJDEREN (AVG): gevarenzone op Account — wachtwoordbevestiging, blokkade bij
  actieve listings of lopende orders, daarna definitieve anonimisering (e-mail/naam/hash),
  alle sessies/bewaard/notificaties gewist; orders blijven geanonimiseerd bewaard
  (fiscale plicht).
- Listingtekst "Bieden komt in de volgende release" verwijderd — het is er nu.

# v6.8.0 — PWA-laag + echte mail (Resend-adapter)
- PWA: manifest (naam, standalone, portrait, merkkleuren), gegenereerde app-iconen
  (192/512 + maskable + apple-touch-icon, petrol/paper/amber-merkstijl), service worker
  (network-first navigaties met offline-fallbackpagina; stale-while-revalidate voor
  statische assets; /api en /uploads bewust NOOIT gecachet), /offline-pagina, iOS-metatags
  (standalone, statusbalk, titel). Registratie faalt stil op http — volledige PWA-ervaring
  activeert automatisch zodra domein+TLS live is; "Zet op beginscherm" op iOS werkt nu al
  met eigen icoon.
- Mail: lib/mail.ts is nu een echte Resend-adapter met log-fallback — met RESEND_API_KEY
  gezet gaan verificatie- en herstelcodes per mail (nette HTML-template), zonder key of
  bij een verzendfout belanden ze zoals voorheen in de serverlog (codes gaan nooit
  verloren). Env: RESEND_API_KEY + MAIL_FROM (geverifieerd domein bij Resend).

# v6.9.0 — Pushmeldingen (Web Push) + Capacitor-fundament
- Elke bestaande notificatie (bod, tegenbod, order, bezorgmoment, chat, retour, uitbetaling,
  dispute) gaat nu óók als echte pushmelding naar geïnstalleerde PWA's — iOS 16.4+
  (via beginscherm) en Android. Adapterpatroon: zonder VAPID-keys stilletjes uit; dode
  subscriptions worden automatisch opgeruimd (404/410); max 5 apparaten per account;
  tikken op een melding opent direct de juiste pagina.
- Nieuw: PushToggle op Account (permission via gebruikersactie — iOS-eis), API
  GET/POST/DELETE /api/push, db.pushSubs (zelf-migrerend), service worker v2 met
  push- en klik-handlers. Dependency: web-push.
- Capacitor-fundament voor de store-apps: capacitor.config.ts (nl.outruniq.app, remote
  server outruniq.nl) + docs/CAPACITOR.md met het volledige draaiboek incl. Apple-
  reviewrisico's en de FCM-uitbreidingsroute van de push-adapter.

# v7.0.0 — Missiecontrole: het beheer-dashboard + polijstronde
- BEHEER-DASHBOARD (/beheer, desktopbreed, partner-OS-stijl): 12 kernstatistieken —
  live bezoekers (< 5 min), bezoekers/weergaven vandaag en 7 dagen, consumenten- en
  partneraantallen, live listings, open orders, geld in escrow, GMV, gerealiseerde
  commissie, open biedingen en issues (hot-markering bij actie nodig). Secties:
  partneraanvragen, disputes, geëscaleerde retouren (bestaande actiecomponenten),
  partnertabel met trust-toggle en INZAGE-link, laatste orders.
- PARTNER-INZAGE (/beheer/partner/[slug]) — meekijken bij problemen: volledig profiel
  (KvK, voorwaarden-akkoord-timestamp, escrowtermijn, klantenservice, afhaaladres met
  ⚠ bij ontbrekend), alle listings (status/prijzen/voorraad/views/herprijzingen), alle
  orders met kopergegevens, event-tijdlijn, dispute-/retourdetails en het laatste
  chatbericht, plus biedingenhistorie.
- Bezoekersmeting: anonieme first-party beacon (random id-cookie, geen derden — past
  binnen de cookieverklaring), per dag views+unieke bezoekers met lazy flush naar de db,
  live-teller in-memory.
- Admin-rol: ADMIN_EMAIL in .env wordt bij inloggen automatisch beheerder; /beheer en
  inzage werken op sessie (pin blijft als fallback en voor destructieve acties).
- Polijstronde: bewaren werkt nu ook in de overlay (bewaarknop naast de titel op beide
  weergaven); e-mailplaceholder volgt het accounttype (persoonlijk ≠ naam@bedrijf.nl);
  partnerlogo op de storefront-kaarten strak op maat; NIEUW: brede banner-upload voor
  partners (storefront-editor) getoond met donkere gradient op de partner-preview én de
  publieke storepagina; home-hero is nu een swipebare "VOOR JOU"-slider (top 5,
  gepersonaliseerd op categorieën uit bewaard+orders, met dots).

# v7.1.0 — Reviews op geverifieerde aankopen + Stripe/Brenger voorbereid
- REVIEWS: alleen na afgeronde order (paid_out, geen open retour), één per aankoop,
  1-5 sterren + tekst (600), kopersnaam-snapshot. Koper beoordeelt op de orderpagina;
  publieke storepagina toont ★-gemiddelde in de banner + reviewlijst met
  "GEVERIFIEERD"-label; partner ziet reviews op zijn storefront en kan één publieke
  reactie plaatsen (met notificatie naar de koper); listing-overlay toont ★ bij de
  partnernaam; beheer-inzage toont alle reviews per partner.
- STRIPE VOORBEREID (M4): lib/payments.ts adapter (testmodus zonder key) met het
  volledige gedocumenteerde activeringsplan (Checkout Sessions → webhook →
  Connect-transfers → refunds/verrekening), webhook-skelet op /api/stripe/webhook,
  Order.paymentRef, env-placeholders (uitgecommentarieerd).
- BRENGER VOORBEREID: lib/delivery.ts adapter (modus "manual" nu) met het
  gedocumenteerde inhaakpunt (quote op afhaal+bezorgadres, boeking → Order.deliveryRef,
  statuswebhook vervangt handmatig GELEVERD), env-placeholder.

# v7.2.0 — UX-uitlijnronde
- Orderpagina volgt nu overal de 16px-kantlijnconventie: "Meld probleem"-knop en
  disputekaart, retour-knoppen en -kaarten, het reviewformulier en de order-chat
  (berichten + invoerveld) stonden tegen de schermrand — allemaal op de kantlijn
  gezet (knoppen: calc(100% − 32px) + marge; kaarten: zijmarge 16px).
- ChatSection kreeg een inset-prop: de koper-orderpagina geeft die mee; het
  partner-orderdetail (waar de chat al in een gepadde kaart zit) blijft ongewijzigd.
- Volledige visuele sweep over alle componenten op ditzelfde patroon: alle overige
  volle-breedte-elementen bleken al correct binnen gepadde containers te leven.

# v7.3.0 — Workstream B: premium buyer UX foundation

- Homepage uitgebreid met koperbescherming/trust-belofte en sterkere premium marketplace-positionering.
- Listingpagina opgewaardeerd met deal-header, trust-chips, premium partnerregel en duidelijke escrow/support-belofte.
- Checkout verbeterd met 3-staps trust-flow en overzichtelijke order-samenvatting.
- Orderpagina verbeterd met escrow-statushero, financiële samenvatting en reviewprompt.
- Geen datamodel- of orderflow-wijzigingen; alleen UX/frontend polish op v7.2-basis.
