#!/usr/bin/env python3
import argparse, csv, json, math, os, zipfile
from datetime import datetime
from pathlib import Path
import numpy as np
import pandas as pd
try:
    import yfinance as yf
except Exception:
    yf = None

VERSION='v1.0.8'
DATA=Path('data'); EXPORTS=Path('exports')
DATA.mkdir(exist_ok=True); EXPORTS.mkdir(exist_ok=True)

NARRATIVE_THEMES={
 'AI':['AI','BBAI','SOUN','PLTR','NVDA','AMD','SMCI','PATH','SERV','GFAI'],
 'quantum':['IONQ','RGTI','QBTS','QUBT','ARQQ'],
 'space':['RKLB','ASTS','LUNR','SPCE'],
 'robotics':['BB','TER','ISRG','SYM','SERV','PATH'],
 'crypto':['COIN','MARA','RIOT','CLSK','HUT','BTBT'],
 'ev_air':['TSLA','RIVN','LCID','ACHR','JOBY'],
 'nuclear_energy':['SMR','OKLO','CEG','NNE'],
 'fintech_growth':['HOOD','UPST','SOFI','AFRM']
}
CATALYST_WORDS={
 'bullish':['ai','robot','contract','partnership','nvidia','guidance','beat','approved','approval','defense','launch','deal','wins','raises','record revenue'],
 'bearish':['offering','dilution','lawsuit','downgrade','bankruptcy','investigation','misses','cuts guidance','reverse split','delisting']
}

def pct(x):
    try: return round(float(x)*100,2)
    except Exception: return 0.0

def safe(v, default=0.0):
    try:
        if pd.isna(v): return default
        return float(v)
    except Exception: return default

def themes_for(t):
    t=t.upper(); out=[]
    for theme, arr in NARRATIVE_THEMES.items():
        if t in arr: out.append(theme)
    return ','.join(out) if out else 'general'

def fetch(ticker, period):
    if yf is None: return pd.DataFrame()
    df=yf.download(ticker, period=period, interval='1d', auto_adjust=True, progress=False, threads=False)
    if df is None or df.empty: return pd.DataFrame()
    if isinstance(df.columns, pd.MultiIndex): df.columns=[c[0] for c in df.columns]
    df=df.reset_index()
    df.columns=[str(c).lower() for c in df.columns]
    if 'date' not in df.columns and 'datetime' in df.columns: df.rename(columns={'datetime':'date'}, inplace=True)
    need={'date','open','high','low','close','volume'}
    if not need.issubset(set(df.columns)): return pd.DataFrame()
    df=df.dropna(subset=['close']).copy()
    df['ticker']=ticker.upper()
    return df

def add_indicators(df):
    df=df.copy()
    c=df['close']; v=df['volume'].replace(0,np.nan)
    df['ret1']=c.pct_change()
    df['ret5']=c.pct_change(5)
    df['ret10']=c.pct_change(10)
    df['ma10']=c.rolling(10).mean(); df['ma20']=c.rolling(20).mean(); df['ma50']=c.rolling(50).mean()
    df['vol20']=v.rolling(20).mean(); df['relvol']=v/df['vol20']
    hi20=df['high'].rolling(20).max().shift(1); hi55=df['high'].rolling(55).max().shift(1)
    df['hi20_prev']=hi20; df['hi55_prev']=hi55
    low14=df['low'].rolling(14).min(); high14=df['high'].rolling(14).max()
    df['range14']=(high14-low14)/c
    delta=c.diff(); gain=delta.clip(lower=0).rolling(14).mean(); loss=(-delta.clip(upper=0)).rolling(14).mean()
    rs=gain/loss.replace(0,np.nan); df['rsi']=100-(100/(1+rs))
    prev=c.shift(1)
    tr=pd.concat([(df['high']-df['low']).abs(),(df['high']-prev).abs(),(df['low']-prev).abs()],axis=1).max(axis=1)
    df['atr14']=tr.rolling(14).mean(); df['atr_pct']=df['atr14']/c
    return df

def signal(row, prev, engine):
    if engine=='breakout_continuation':
        return row.close>safe(row.hi20_prev,9e99) and row.relvol>=1.4 and row.close>row.ma20 and row.ret5>0.03
    if engine=='gap_and_go':
        gap=(row.open/safe(prev.close,row.open)-1) if prev is not None else 0
        intraday=(row.close/row.open-1) if row.open else 0
        return gap>=0.035 and intraday>=0.005 and row.relvol>=1.5
    if engine=='pullback_reclaim':
        was_pullback = prev is not None and prev.close < prev.ma10 and prev.close > prev.ma50
        return was_pullback and row.close>row.ma10 and row.close>row.ma20 and row.relvol>=1.1
    if engine=='squeeze_ignition':
        return row.ret1>=0.08 and row.relvol>=2.5 and row.close>row.ma20
    if engine=='momentum_continuation_legacy':
        return row.close>row.ma20 and row.close>row.ma50 and row.ret10>0.08 and row.relvol>=1.2
    return False

def trade_return(df, i, hold, exit_mode):
    entry=safe(df.loc[i,'close'])
    if entry<=0: return None
    end=min(i+hold,len(df)-1)
    if end<=i: return None
    path=df.iloc[i+1:end+1].copy()
    if path.empty: return None
    fee_slip=0.003
    if exit_mode=='fixed':
        out=safe(path.iloc[-1]['close'])
    elif exit_mode=='trail_8':
        high=entry; out=safe(path.iloc[-1]['close'])
        for _,r in path.iterrows():
            high=max(high,safe(r['high'],high))
            if safe(r['low'],high) <= high*0.92:
                out=high*0.92; break
    elif exit_mode=='trail_12':
        high=entry; out=safe(path.iloc[-1]['close'])
        for _,r in path.iterrows():
            high=max(high,safe(r['high'],high))
            if safe(r['low'],high) <= high*0.88:
                out=high*0.88; break
    elif exit_mode=='tp18_sl8':
        out=safe(path.iloc[-1]['close'])
        for _,r in path.iterrows():
            if safe(r['low']) <= entry*0.92: out=entry*0.92; break
            if safe(r['high']) >= entry*1.18: out=entry*1.18; break
    else:
        out=safe(path.iloc[-1]['close'])
    return (out/entry-1)-fee_slip

def evidence_score(trades, winrate, avgret):
    n=len(trades)
    sample=min(1,n/40)
    score=(max(0,avgret)*230)+(max(0,winrate-0.5)*120)+(sample*25)
    if n<15: score*=0.25
    elif n<25: score*=0.65
    return round(max(0,min(100,score)),2)

def run(tickers, period):
    engines=['breakout_continuation','gap_and_go','pullback_reclaim','squeeze_ignition','momentum_continuation_legacy']
    holds=[3,5,10,20]
    exits=['fixed','trail_8','trail_12','tp18_sl8']
    rows=[]; trade_rows=[]
    for t in tickers:
        raw=fetch(t,period)
        if raw.empty: continue
        df=add_indicators(raw).dropna().reset_index(drop=True)
        theme=themes_for(t)
        for engine in engines:
            idxs=[]
            for i in range(55,len(df)-21):
                prev=df.iloc[i-1] if i>0 else None
                if signal(df.iloc[i], prev, engine): idxs.append(i)
            for hold in holds:
                for exit_mode in exits:
                    returns=[]
                    for i in idxs:
                        r=trade_return(df,i,hold,exit_mode)
                        if r is not None:
                            returns.append(r)
                            trade_rows.append({'ticker':t.upper(),'theme':theme,'engine':engine,'hold_days':hold,'exit_mode':exit_mode,'entry_date':str(df.loc[i,'date'])[:10],'entry_close':round(safe(df.loc[i,'close']),4),'return_pct':pct(r)})
                    if not returns: continue
                    n=len(returns); wr=sum(1 for x in returns if x>0)/n; avg=sum(returns)/n
                    score=evidence_score(returns,wr,avg)
                    fake=1 if n<15 else 0
                    good=1 if n>=20 and wr>=0.55 and avg>0.02 and score>=40 else 0
                    elite=1 if n>=30 and wr>=0.60 and avg>0.04 and score>=55 else 0
                    rows.append({'ticker':t.upper(),'theme':theme,'engine':engine,'hold_days':hold,'exit_mode':exit_mode,'trades':n,'winrate_pct':pct(wr),'avg_return_pct':pct(avg),'median_return_pct':pct(float(np.median(returns))),'best_return_pct':pct(max(returns)),'worst_return_pct':pct(min(returns)),'evidence_score':score,'fake_alpha_warning':fake,'usable':1 if n>=15 and fake==0 else 0,'good_candidate':good,'elite':elite,'rank_reason':('ELITE' if elite else 'GOOD' if good else 'USABLE' if n>=15 else 'SMALL_SAMPLE')})
    summary=pd.DataFrame(rows)
    trades=pd.DataFrame(trade_rows)
    if summary.empty:
        summary=pd.DataFrame(columns=['ticker','theme','engine','hold_days','exit_mode','trades','winrate_pct','avg_return_pct','evidence_score','fake_alpha_warning','usable','good_candidate','elite'])
    summary=summary.sort_values(['elite','good_candidate','evidence_score','trades'], ascending=[False,False,False,False])
    version=VERSION.replace('.','_')
    summary.to_csv(EXPORTS/f'see_summary_{version}.csv',index=False)
    trades.to_csv(EXPORTS/f'see_trades_{version}.csv',index=False)
    usable=summary[summary['usable']==1]; elite=summary[summary['elite']==1]
    usable.to_csv(EXPORTS/f'see_usable_{version}.csv',index=False); elite.to_csv(EXPORTS/f'see_elite_{version}.csv',index=False)
    if not summary.empty:
        by_ticker=summary.groupby(['ticker','theme'],as_index=False).agg(rows=('ticker','count'),trades=('trades','sum'),elite=('elite','sum'),good=('good_candidate','sum'),avg_score=('evidence_score','mean')).sort_values(['elite','good','avg_score'],ascending=False)
        by_setup=summary.groupby(['engine','exit_mode','hold_days'],as_index=False).agg(rows=('engine','count'),trades=('trades','sum'),elite=('elite','sum'),good=('good_candidate','sum'),avg_score=('evidence_score','mean')).sort_values(['elite','good','avg_score'],ascending=False)
    else:
        by_ticker=pd.DataFrame(); by_setup=pd.DataFrame()
    by_ticker.to_csv(EXPORTS/f'see_by_ticker_{version}.csv',index=False); by_setup.to_csv(EXPORTS/f'see_by_setup_{version}.csv',index=False)
    meta={'version':VERSION,'generated_at':datetime.utcnow().isoformat()+'Z','tickers':tickers,'period':period,'summary_rows':int(len(summary)),'trades':int(len(trades)),'elite':int(summary.get('elite',pd.Series(dtype=int)).sum() if not summary.empty else 0),'good':int(summary.get('good_candidate',pd.Series(dtype=int)).sum() if not summary.empty else 0)}
    (EXPORTS/'meta.json').write_text(json.dumps(meta,indent=2))
    with zipfile.ZipFile(EXPORTS/'see_audit_export_v1_0_8.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in EXPORTS.glob('see_*_v1_0_8.csv'): z.write(f,f.name)
        z.write(EXPORTS/'meta.json','meta.json')
    print(json.dumps(meta,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--tickers',required=True); ap.add_argument('--period',default='2y')
    a=ap.parse_args(); tickers=[x.strip().upper() for x in a.tickers.split(',') if x.strip()]
    run(tickers,a.period)
