#!/usr/bin/env python3
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import json, html, os, mimetypes, zipfile, io
import pandas as pd

VERSION='v1.0.8'
PORT=int(os.environ.get('SEE_PORT','8798'))
ROOT=Path(__file__).resolve().parent
EXPORTS=ROOT/'exports'

STYLE='''
body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#f5f7fb;color:#111827;margin:0;padding:22px}a{color:#111827;text-decoration:none}.wrap{max-width:1180px;margin:auto}.card{background:white;border-radius:24px;padding:22px;margin:14px 0;box-shadow:0 10px 28px rgba(15,23,42,.08)}h1{font-size:34px;margin:8px 0}h2{margin:0 0 12px}.badge{display:inline-block;border-radius:999px;padding:7px 12px;background:#0f172a;color:white;font-weight:800;font-size:12px}.tabs a{display:inline-block;padding:10px 13px;background:#fff;border-radius:999px;margin:4px;box-shadow:0 6px 16px rgba(15,23,42,.06);font-weight:700}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}.metric{background:#f8fafc;border-radius:18px;padding:16px}.big{font-size:30px;font-weight:900}.muted{color:#64748b}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:10px;border-bottom:1px solid #e5e7eb;text-align:left}th{font-size:11px;text-transform:uppercase;color:#64748b}.pill{border-radius:999px;padding:5px 9px;font-weight:800;font-size:11px}.elite{background:#dcfce7;color:#166534}.good{background:#dbeafe;color:#1d4ed8}.warn{background:#fee2e2;color:#991b1b}.usable{background:#fef3c7;color:#92400e}.btn{display:inline-block;background:#111827;color:white;border-radius:14px;padding:12px 16px;font-weight:800;margin:4px}
'''

def read_csv(name):
    p=EXPORTS/name
    if not p.exists(): return pd.DataFrame()
    try: return pd.read_csv(p)
    except Exception: return pd.DataFrame()

def latest(pattern):
    fs=sorted(EXPORTS.glob(pattern), key=lambda p:p.stat().st_mtime, reverse=True)
    return fs[0].name if fs else None

def page(title, body):
    return f'<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>{html.escape(title)}</title><style>{STYLE}</style></head><body><div class="wrap"><div class="card"><span class="badge">Stock Evidence Engine {VERSION}</span><h1>Momentum Lab</h1><div class="tabs"><a href="/">Overview</a><a href="/elite">Elite</a><a href="/usable">Usable</a><a href="/momentum-lab">Momentum Lab</a><a href="/portfolio">Portfolio</a><a href="/exports/all.zip">Download audit ZIP</a></div></div>{body}</div></body></html>'

def table(df, cols, limit=80):
    if df.empty: return '<p class="muted">Geen data. Draai eerst run_backtest.sh.</p>'
    df=df.head(limit)
    h='<table><thead><tr>'+''.join(f'<th>{html.escape(c)}</th>' for c in cols if c in df.columns)+'</tr></thead><tbody>'
    for _,r in df.iterrows():
        h+='<tr>'
        for c in cols:
            if c not in df.columns: continue
            v=r[c]
            if c=='rank_reason':
                cls='elite' if str(v)=='ELITE' else 'good' if str(v)=='GOOD' else 'usable' if str(v)=='USABLE' else 'warn'
                h+=f'<td><span class="pill {cls}">{html.escape(str(v))}</span></td>'
            else:
                h+=f'<td>{html.escape(str(v))}</td>'
        h+='</tr>'
    return h+'</tbody></table>'

def dashboard(kind='overview'):
    sname=latest('see_summary_v1_0_8.csv') or latest('see_summary_*.csv')
    df=read_csv(sname) if sname else pd.DataFrame()
    meta={}
    if (EXPORTS/'meta.json').exists():
        try: meta=json.loads((EXPORTS/'meta.json').read_text())
        except Exception: pass
    rows=len(df); trades=int(df['trades'].sum()) if not df.empty and 'trades' in df else 0
    elite=int(df['elite'].sum()) if not df.empty and 'elite' in df else 0
    good=int(df['good_candidate'].sum()) if not df.empty and 'good_candidate' in df else 0
    body=f'''<div class="grid"><div class="metric"><div class="big">{rows}</div><div class="muted">summary rows</div></div><div class="metric"><div class="big">{trades}</div><div class="muted">historical trades</div></div><div class="metric"><div class="big">{elite}</div><div class="muted">elite setups</div></div><div class="metric"><div class="big">{good}</div><div class="muted">good setups</div></div></div>'''
    cols=['ticker','theme','engine','hold_days','exit_mode','trades','winrate_pct','avg_return_pct','evidence_score','rank_reason']
    if kind=='elite':
        d=df[df.get('elite',0)==1] if not df.empty else df; title='Elite setups'
    elif kind=='usable':
        d=df[df.get('usable',0)==1] if not df.empty else df; title='Usable setups'
    elif kind=='momentum':
        d=read_csv(latest('see_by_setup_*.csv') or 'x'); title='Momentum Lab by engine'; cols=['engine','exit_mode','hold_days','rows','trades','elite','good','avg_score']
    elif kind=='portfolio':
        d=df[(df.get('elite',0)==1)|(df.get('good_candidate',0)==1)] if not df.empty else df; title='Portfolio-ready candidates'
        body+='<div class="card"><h2>Portfolio Simulator Placeholder</h2><p class="muted">Volgende release simuleert capital, max positions, risk per trade en monthly equity curve. Deze tab toont nu alleen tradable candidates.</p></div>'
    else:
        d=df; title='Top ranked research rows'
    body+=f'<div class="card"><h2>{title}</h2>{table(d,cols)}</div>'
    return page('Stock Evidence Engine',body)

class H(BaseHTTPRequestHandler):
    def send_bytes(self,data,ctype='text/html; charset=utf-8',code=200):
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(data))); self.end_headers();
        if self.command!='HEAD': self.wfile.write(data)
    def do_HEAD(self): self.do_GET()
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/health': return self.send_bytes(json.dumps({'ok':True,'version':VERSION}).encode(),'application/json')
        if path=='/exports/all.zip':
            z=EXPORTS/'see_audit_export_v1_0_8.zip'
            if not z.exists():
                return self.send_bytes(b'export zip not found; run backtest first', 'text/plain', 404)
            return self.send_bytes(z.read_bytes(),'application/zip')
        if path=='/elite': data=dashboard('elite').encode()
        elif path=='/usable': data=dashboard('usable').encode()
        elif path=='/momentum-lab': data=dashboard('momentum').encode()
        elif path=='/portfolio': data=dashboard('portfolio').encode()
        else: data=dashboard('overview').encode()
        return self.send_bytes(data)

if __name__=='__main__':
    print(f'Stock Evidence Engine {VERSION} on :{PORT}')
    HTTPServer(('0.0.0.0',PORT),H).serve_forever()
