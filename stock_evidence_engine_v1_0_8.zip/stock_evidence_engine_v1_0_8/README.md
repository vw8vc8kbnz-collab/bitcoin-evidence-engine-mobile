# Stock Evidence Engine v1.0.8 — Momentum Lab

Clean VPS build based on the stable v1.0.5/v1.0.7 baseline.

## Runtime
- Dashboard runtime: `/usr/bin/python3 /home/ubuntu/stock_evidence_latest/server.py`
- Port: `8798`
- No FastAPI/Uvicorn dashboard runtime.

## New in v1.0.8
- Pivot to high-beta momentum research.
- Expanded default universe.
- Momentum split into 5 engines:
  - breakout_continuation
  - gap_and_go
  - pullback_reclaim
  - squeeze_ignition
  - momentum_continuation_legacy
- Exit lab:
  - fixed hold
  - trail_8
  - trail_12
  - tp18_sl8
- Better audit exports in one ZIP: `/exports/all.zip`
- Dashboard tabs: Overview, Elite, Usable, Momentum Lab, Portfolio.

## Commands

```bash
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA" "2y"
```
