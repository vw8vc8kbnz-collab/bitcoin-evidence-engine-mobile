# Stock Evidence Engine — Masterplan v1.0.8

This release starts the transition from a general stock scanner to a high-beta momentum alpha research lab.

## Research principle
Do not build live alerts before validated alpha. Every new setup must be backtested with exits, trade counts, fake-alpha filtering and exportable audit data.

## Current hypothesis
The first validated edge appears to be narrative/high-beta momentum continuation. v1.0.8 splits that broad hypothesis into sub-engines and compares exit styles.

## Next versions
- v1.0.9: lightweight news/catalyst keyword reader.
- v1.1.0: portfolio simulator with capital, max positions, risk per trade and monthly equity curve.
- v1.1.x: ntfy live signals only for validated elite setups.
