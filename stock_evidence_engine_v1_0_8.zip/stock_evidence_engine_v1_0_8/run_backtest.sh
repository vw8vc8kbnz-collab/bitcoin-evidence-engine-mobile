#!/usr/bin/env bash
set -euo pipefail
TICKERS="${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN}"
PERIOD="${2:-2y}"
cd /home/ubuntu/stock_evidence_latest
./venv/bin/python see_backtest.py --tickers "$TICKERS" --period "$PERIOD"
