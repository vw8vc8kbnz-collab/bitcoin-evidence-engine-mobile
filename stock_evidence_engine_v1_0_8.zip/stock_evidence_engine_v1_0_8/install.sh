#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/home/ubuntu/stock_evidence_latest"
PORT="8798"
cd "$APP_DIR"
mkdir -p data exports logs
chown -R ubuntu:ubuntu "$APP_DIR" || true
python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip
./venv/bin/python -m pip install -r requirements.txt
cat | sudo tee /etc/systemd/system/stock-evidence-dashboard.service >/dev/null <<SERVICE
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/python3 $APP_DIR/server.py
Restart=always
RestartSec=5
Environment=SEE_PORT=$PORT

[Install]
WantedBy=multi-user.target
SERVICE
sudo systemctl daemon-reload
sudo systemctl enable stock-evidence-dashboard.service
sudo systemctl restart stock-evidence-dashboard.service
