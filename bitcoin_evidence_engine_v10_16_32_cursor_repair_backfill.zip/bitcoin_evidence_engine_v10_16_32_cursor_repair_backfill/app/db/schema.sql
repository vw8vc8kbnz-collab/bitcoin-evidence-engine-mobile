CREATE SEQUENCE IF NOT EXISTS seq_forecast_runs START 1;

CREATE TABLE IF NOT EXISTS raw_candles (
    source TEXT NOT NULL,
    symbol TEXT NOT NULL,
    interval TEXT NOT NULL,
    open_time BIGINT NOT NULL,
    close_time BIGINT,
    open DOUBLE,
    high DOUBLE,
    low DOUBLE,
    close DOUBLE,
    volume DOUBLE,
    quote_volume DOUBLE,
    trades BIGINT,
    synced_at TIMESTAMP,
    PRIMARY KEY(source, symbol, interval, open_time)
);

CREATE TABLE IF NOT EXISTS raw_metric_points (
    source TEXT NOT NULL,
    metric TEXT NOT NULL,
    timestamp_ms BIGINT NOT NULL,
    value DOUBLE,
    metadata JSON,
    synced_at TIMESTAMP,
    PRIMARY KEY(source, metric, timestamp_ms)
);

CREATE TABLE IF NOT EXISTS data_health (
    source TEXT PRIMARY KEY,
    status TEXT,
    last_success_at TIMESTAMP,
    last_error_at TIMESTAMP,
    last_error TEXT,
    rows_added BIGINT DEFAULT 0,
    detail JSON
);

CREATE TABLE IF NOT EXISTS features (
    interval TEXT NOT NULL,
    timestamp_ms BIGINT NOT NULL,
    close DOUBLE,
    return_1 DOUBLE,
    return_4 DOUBLE,
    return_24 DOUBLE,
    ma_20 DOUBLE,
    ma_50 DOUBLE,
    ma_200 DOUBLE,
    rsi_14 DOUBLE,
    volatility_24 DOUBLE,
    volume_zscore DOUBLE,
    volume_ratio_24 DOUBLE,
    range_pct DOUBLE,
    candle_body_pct DOUBLE,
    drawdown_from_ath DOUBLE,
    days_since_halving DOUBLE,
    cycle_progress DOUBLE,
    fear_greed DOUBLE,
    funding_rate DOUBLE,
    open_interest_value DOUBLE,
    open_interest_change_24h DOUBLE,
    long_short_ratio DOUBLE,
    taker_buy_sell_ratio DOUBLE,
    orderbook_imbalance DOUBLE,
    orderbook_spread DOUBLE,
    taker_delta_ratio DOUBLE,
    futures_basis_premium_pct DOUBLE,
    top_position_long_short_ratio DOUBLE,
    top_account_long_short_ratio DOUBLE,
    cross_exchange_spread_pct DOUBLE,
    spot_premium_kraken_pct DOUBLE,
    spot_premium_coinbase_pct DOUBLE,
    coinmetrics_mvrv DOUBLE,
    realized_cap_usd DOUBLE,
    market_cap_usd DOUBLE,
    regime TEXT,
    data_completeness DOUBLE,
    state_json JSON,
    PRIMARY KEY(interval, timestamp_ms)
);

CREATE TABLE IF NOT EXISTS forecast_runs (
    run_id BIGINT PRIMARY KEY,
    created_at TIMESTAMP NOT NULL,
    created_at_ms BIGINT NOT NULL,
    start_price DOUBLE NOT NULL,
    data_points BIGINT DEFAULT 0,
    status TEXT DEFAULT 'open',
    engine_version TEXT DEFAULT 'v6.0-composite-evidence',
    notes TEXT
);

CREATE TABLE IF NOT EXISTS forecast_items (
    item_id TEXT PRIMARY KEY,
    run_id BIGINT NOT NULL,
    horizon TEXT NOT NULL,
    due_at TIMESTAMP NOT NULL,
    due_at_ms BIGINT NOT NULL,
    start_price DOUBLE NOT NULL,
    bullish_probability DOUBLE,
    bearish_probability DOUBLE,
    expected_move_pct DOUBLE,
    expected_price DOUBLE,
    invalidation_price DOUBLE,
    invalidation_distance_pct DOUBLE,
    bullish_range_low DOUBLE,
    bullish_range_high DOUBLE,
    bearish_risk_low DOUBLE,
    bearish_risk_high DOUBLE,
    confidence DOUBLE,
    evidence_count BIGINT,
    contributions_json JSON,
    status TEXT DEFAULT 'open',
    actual_price DOUBLE,
    actual_high DOUBLE,
    actual_low DOUBLE,
    actual_move_pct DOUBLE,
    direction_correct BOOLEAN,
    target_touched BOOLEAN,
    target_reached BOOLEAN,
    invalidated BOOLEAN,
    invalidation_gap_pct DOUBLE,
    target_gap_pct DOUBLE,
    price_error_pct DOUBLE,
    resolved_at TIMESTAMP,
    FOREIGN KEY(run_id) REFERENCES forecast_runs(run_id)
);

CREATE TABLE IF NOT EXISTS model_scores (
    model_id TEXT NOT NULL,
    horizon TEXT NOT NULL,
    total BIGINT DEFAULT 0,
    correct BIGINT DEFAULT 0,
    hitrate DOUBLE DEFAULT 0.5,
    avg_price_error_pct DOUBLE DEFAULT 0,
    updated_at TIMESTAMP,
    PRIMARY KEY(model_id, horizon)
);

CREATE TABLE IF NOT EXISTS sync_state (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TIMESTAMP
);


CREATE TABLE IF NOT EXISTS evidence_snapshots (
    snapshot_id TEXT PRIMARY KEY,
    created_at TIMESTAMP NOT NULL,
    timestamp_ms BIGINT NOT NULL,
    horizon TEXT NOT NULL,
    regime TEXT,
    data_completeness DOUBLE,
    bullish_probability DOUBLE,
    expected_move_pct DOUBLE,
    confidence DOUBLE,
    evidence_json JSON
);


CREATE TABLE IF NOT EXISTS time_machine_tests (
    test_item_id TEXT PRIMARY KEY,
    batch_id TEXT,
    source TEXT DEFAULT 'manual',
    created_at TIMESTAMP NOT NULL,
    cutoff_ms BIGINT NOT NULL,
    cutoff_iso TEXT,
    horizon TEXT NOT NULL,
    start_price DOUBLE,
    bullish_probability DOUBLE,
    bearish_probability DOUBLE,
    expected_move_pct DOUBLE,
    expected_price DOUBLE,
    confidence DOUBLE,
    actual_price DOUBLE,
    actual_high DOUBLE,
    actual_low DOUBLE,
    actual_move_pct DOUBLE,
    direction_correct BOOLEAN,
    target_touched BOOLEAN,
    target_reached BOOLEAN,
    invalidation_price DOUBLE,
    invalidated BOOLEAN,
    invalidation_gap_pct DOUBLE,
    target_gap_pct DOUBLE,
    price_error_pct DOUBLE,
    total_score DOUBLE,
    model_contributions_json JSON
);

-- V9.7 Evidence Attribution Engine
-- Stores which signals/model conditions were present when a Time Machine test
-- was won/lost. This lets the app learn which evidence actually helps per horizon.
CREATE TABLE IF NOT EXISTS evidence_attribution_stats (
    signal_key TEXT NOT NULL,
    signal_label TEXT,
    signal_type TEXT,
    horizon TEXT NOT NULL,
    total BIGINT DEFAULT 0,
    wins BIGINT DEFAULT 0,
    losses BIGINT DEFAULT 0,
    hitrate DOUBLE DEFAULT 0.0,
    avg_target_gap_pct DOUBLE DEFAULT 0.0,
    avg_score DOUBLE DEFAULT 0.0,
    last_seen_at TIMESTAMP,
    PRIMARY KEY(signal_key, horizon)
);

CREATE TABLE IF NOT EXISTS evidence_attribution_events (
    event_id TEXT PRIMARY KEY,
    batch_id TEXT,
    created_at TIMESTAMP NOT NULL,
    cutoff_ms BIGINT,
    horizon TEXT NOT NULL,
    signal_key TEXT NOT NULL,
    signal_label TEXT,
    signal_type TEXT,
    target_reached BOOLEAN,
    target_gap_pct DOUBLE,
    total_score DOUBLE,
    metadata JSON
);


-- V10.5 Time Machine Learning Warehouse
-- Stores the full feature context behind every Time Machine outcome so random
-- batches become a reusable training/evidence dataset instead of only UI tests.
CREATE TABLE IF NOT EXISTS time_machine_feature_snapshots (
    snapshot_id TEXT PRIMARY KEY,
    batch_id TEXT,
    source TEXT,
    created_at TIMESTAMP NOT NULL,
    cutoff_ms BIGINT NOT NULL,
    cutoff_iso TEXT,
    horizon TEXT NOT NULL,
    start_price DOUBLE,
    regime TEXT,
    data_completeness DOUBLE,
    feature_json JSON,
    price_context_json JSON,
    provider_context_json JSON,
    model_context_json JSON,
    outcome_tier TEXT,
    target_reached BOOLEAN,
    partial_reached BOOLEAN,
    invalidated BOOLEAN,
    direction_correct BOOLEAN,
    total_score DOUBLE,
    target_gap_pct DOUBLE,
    price_error_pct DOUBLE
);

CREATE TABLE IF NOT EXISTS time_machine_signal_scores (
    signal_key TEXT NOT NULL,
    signal_label TEXT,
    signal_type TEXT,
    horizon TEXT NOT NULL,
    regime TEXT NOT NULL DEFAULT 'unknown',
    total BIGINT DEFAULT 0,
    wins BIGINT DEFAULT 0,
    partials BIGINT DEFAULT 0,
    fails BIGINT DEFAULT 0,
    hitrate DOUBLE DEFAULT 0.0,
    hitrate_with_partial DOUBLE DEFAULT 0.0,
    avg_score DOUBLE DEFAULT 0.0,
    avg_target_gap_pct DOUBLE DEFAULT 0.0,
    last_seen_at TIMESTAMP,
    PRIMARY KEY(signal_key, horizon, regime)
);

-- V10.14 Historical Memory + Adaptive Weights
CREATE TABLE IF NOT EXISTS adaptive_feature_weights (
    dimension TEXT PRIMARY KEY,
    weight DOUBLE NOT NULL,
    quality DOUBLE DEFAULT 0.5,
    sample BIGINT DEFAULT 0,
    matched_signals BIGINT DEFAULT 0,
    updated_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS historical_memory_runs (
    run_id TEXT PRIMARY KEY,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    rows_added BIGINT DEFAULT 0,
    chunks BIGINT DEFAULT 0,
    stored_rows BIGINT DEFAULT 0,
    coverage_pct DOUBLE DEFAULT 0.0,
    status TEXT,
    detail JSON
);

-- V10.16.29 Honest External Backfill Jobs
-- Authoritative progress table for external historical evidence backfills.
-- Progress shown in the mobile Data cockpit must be based on this table + real
-- raw_metric_points row counts, not text-only sync_state strings.
CREATE TABLE IF NOT EXISTS backfill_jobs (
    source TEXT NOT NULL,
    dataset TEXT NOT NULL,
    metric TEXT NOT NULL,
    status TEXT DEFAULT 'queued',
    granularity_ms BIGINT,
    target_start_ms BIGINT,
    target_end_ms BIGINT,
    cursor_next_ms BIGINT,
    rows_current BIGINT DEFAULT 0,
    rows_target BIGINT DEFAULT 0,
    coverage_pct DOUBLE DEFAULT 0,
    rows_added_last_batch BIGINT DEFAULT 0,
    batches_done BIGINT DEFAULT 0,
    pages_done BIGINT DEFAULT 0,
    last_success_at TIMESTAMP,
    last_attempt_at TIMESTAMP,
    last_error TEXT,
    error_count BIGINT DEFAULT 0,
    rate_limit_until TIMESTAMP,
    provider_limit_reached BOOLEAN DEFAULT FALSE,
    stuck_since TIMESTAMP,
    eta_seconds DOUBLE,
    rows_per_minute DOUBLE,
    metadata JSON,
    updated_at TIMESTAMP,
    PRIMARY KEY(source, dataset, metric)
);
