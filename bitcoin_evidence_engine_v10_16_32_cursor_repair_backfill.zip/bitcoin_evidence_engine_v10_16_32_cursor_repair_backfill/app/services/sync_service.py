from __future__ import annotations
from datetime import datetime, timezone, timedelta
import json
import asyncio
from app.db.database import db
from app.core.config import settings
from app.core.time_utils import utc_now, interval_ms
from app.providers.binance import BinanceProvider
from app.providers.fear_greed import FearGreedProvider
from app.providers.coingecko import CoinGeckoProvider
from app.providers.coinmetrics import CoinMetricsProvider
from app.providers.binance_futures import BinanceFuturesProvider
from app.providers.composite_orderbook import CompositeOrderBookProvider
from app.services.health_service import HealthService
from app.core.logger import log
from app.core.debug import append_jsonl, write_json

class SyncService:
    def __init__(self):
        self.health = HealthService()
        self.binance = BinanceProvider()
        self.fear_greed = FearGreedProvider()
        self.coingecko = CoinGeckoProvider()
        self.coinmetrics = CoinMetricsProvider()
        self.futures = BinanceFuturesProvider()
        self.composite_orderbook = CompositeOrderBookProvider()
        try:
            from app.providers.coinbase import CoinbaseProvider
            self.coinbase = CoinbaseProvider()
            from app.providers.kraken import KrakenProvider
            self.kraken = KrakenProvider()
        except Exception:
            self.coinbase = None
            self.kraken = None

    def _log_result(self, result: dict) -> dict:
        source = result.get("source", "unknown")
        status = result.get("status", "?")
        rows = result.get("rows", 0)
        detail = {k:v for k,v in result.items() if k not in ("source","status","rows","error")}
        if status == "ok":
            log.info("SYNC OK source=%s rows=%s detail=%s", source, rows, detail)
        else:
            log.warning("SYNC %s source=%s rows=%s error=%s detail=%s", status.upper(), source, rows, result.get("error"), detail)
        append_jsonl('sync_audit.jsonl', {"event":"sync_result", "source":source, "status":status, "rows":rows, "error":result.get("error"), "detail":detail})
        try:
            write_json('last_data_health_snapshot.json', {"providers": self.health.list()})
        except Exception:
            pass
        return result


    async def sync_minimal_live(self) -> dict:
        """Ultra-safe startup sync for the visible dashboard.

        This path intentionally fetches only the minimum data needed to make the
        app useful immediately: recent Binance 1h candles, Binance ticker, and a
        small optional spot consensus. It does not call futures/orderbook/flow
        providers, because those optional layers can be slow or blocked and must
        never keep the UI empty. Manual Sync + Forecast can still run the broader
        sync later.
        """
        log.info("Minimal live sync phase: candles_and_ticker_only")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'minimal_live_candles', utc_now()])
        results = []
        # Run critical calls sequentially so we know exactly where a failure happens.
        r = await self._safe_call('binance_recent', self.sync_binance_candles(), 10.0, False)
        results.append(self._log_result(r))
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'minimal_live_ticker', utc_now()])
        for name, coro, timeout in [
            ('binance_ticker', self.sync_binance_ticker(), 5.0),
            ('kraken_ticker', self.sync_kraken_ticker_metric(), 4.0),
            ('coinbase_ticker', self.sync_coinbase_ticker_metric(), 4.0),
        ]:
            r = await self._safe_call(name, coro, timeout, True)
            results.append(self._log_result(r))
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'minimal_live_spot_composite', utc_now()])
        r = await self._safe_call('spot_composite', self.sync_spot_composite_metrics(), 4.0, True)
        results.append(self._log_result(r))
        # Mark heavy layers as deferred, not failed.
        for src in ['coingecko','alternative_me','binance_futures','binance_orderbook','composite_orderbook','binance_spot_flow','binance_futures_flow']:
            self.health.skipped(src, 'deferred during startup minimal sync for fast visible data', {})
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'minimal_live_done', utc_now()])
        write_json('last_minimal_live_sync_results.json', {"mode": "minimal_live", "results": results})
        return {"results": results, "mode": "minimal_live"}

    async def sync_all(self) -> dict:
        # V6.4 priority order: first make the dashboard useful NOW, then continue
        # the heavy historical Time Machine backfill. This prevents the app from
        # looking empty while old 2017 data is still downloading.
        log.info("Sync phase: recent_market_data")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'recent_market_data', utc_now()])
        results=[]
        results.append(self._log_result(await self.sync_binance_candles()))
        results.append(self._log_result(await self.sync_binance_ticker()))
        results.append(self._log_result(await self.sync_kraken_ticker_metric()))
        results.append(self._log_result(await self.sync_coinbase_ticker_metric()))
        results.append(self._log_result(await self.sync_spot_composite_metrics()))
        results.append(self._log_result(await self.sync_fear_greed()))
        results.append(self._log_result(await self.sync_coingecko_price_metric()))

        log.info("Sync phase: orderflow_futures_onchain")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'orderflow_futures_onchain', utc_now()])
        results.append(self._log_result(await self.sync_composite_orderbooks()))
        results.append(self._log_result(await self.sync_binance_orderbook_snapshot()))
        results.append(self._log_result(await self.sync_binance_futures_layer()))
        results.append(self._log_result(await self.sync_binance_spot_tradeflow()))
        results.append(self._log_result(await self.sync_binance_futures_tradeflow()))
        results.append(self._log_result(await self.sync_coinmetrics_metrics()))

        log.info("Sync phase: historical_backfill")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'historical_backfill', utc_now()])
        results.append(self._log_result(await self.sync_binance_deep_history()))
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'idle', utc_now()])
        log.info("Sync phase: idle")
        return {"results": results}

    async def _safe_call(self, name: str, coro, timeout: float = 5.0, optional: bool = False):
        try:
            return await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError:
            msg = f"{'optional/' if optional else ''}provider timed out after {timeout}s"
            if optional:
                # V10.16.23: optional-but-important evidence is not considered permanently skipped.
                # A timeout means queued_for_retry; the background daemon will retry from checkpoints.
                self.health.skipped(name, msg + ' - queued_for_retry', {'retryable': True})
                return {"source": name, "status": "retry_queued", "rows": 0, "warning": "timeout", "retryable": True}
            self.health.error(name, TimeoutError(msg))
            return {"source": name, "status": "error", "rows": 0, "error": msg}
        except Exception as exc:
            if optional:
                text = str(exc)
                permanent = ('403' in text or 'Forbidden' in text) and 'coinmetrics' in name.lower()
                status = 'disabled' if permanent else 'retry_queued'
                detail = {'retryable': not permanent, 'permanent': permanent}
                self.health.skipped(name, f"optional provider unavailable: {text}", detail)
                return {"source": name, "status": status, "rows": 0, "warning": text, **detail}
            self.health.error(name, exc)
            return {"source": name, "status": "error", "rows": 0, "error": str(exc)}

    async def sync_startup_fast(self) -> dict:
        """V10.2 startup path: only critical sources, no slow optional orderbook/flow.

        Goal: the app must fill the dashboard quickly and reliably. Optional
        providers are allowed to be skipped/deferred instead of making the first
        screen look frozen or empty. Manual Sync + Forecast can still collect
        more evidence.
        """
        log.info("Startup stability sync phase: critical_market_data")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'startup_critical_market', utc_now()])
        tasks = [
            self._safe_call('binance_recent', self.sync_binance_candles(), 7.0, False),
            self._safe_call('kraken_ticker', self.sync_kraken_ticker_metric(), 4.0, True),
            self._safe_call('coinbase_ticker', self.sync_coinbase_ticker_metric(), 4.0, True),
            self._safe_call('coingecko', self.sync_coingecko_price_metric(), 5.0, True),
            self._safe_call('binance_futures', self.sync_binance_futures_layer(), 8.0, True),
        ]
        raw_results = await asyncio.gather(*tasks)
        raw_results.append(await self._safe_call('spot_composite', self.sync_spot_composite_metrics(), 3.0, True))
        # Mark intentionally deferred sources so Data Health is honest, but not alarming.
        for src in ['alternative_me','binance_ticker','binance_orderbook','composite_orderbook','binance_spot_flow','binance_futures_flow']:
            self.health.skipped(src, 'deferred during startup for stable app launch', {})
            raw_results.append({"source": src, "status": "skipped", "rows": 0, "warning": "deferred_startup"})
        results=[self._log_result(r) for r in raw_results]
        write_json('last_fast_sync_results.json', {"mode": "startup_fast", "results": results})
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'idle', utc_now()])
        return {"results": results}

    async def sync_forecast_fast(self) -> dict:
        """V10.2 manual fast path.

        Critical data is fetched first and optional slow providers are capped hard.
        This keeps Sync + Forecast reliable: a slow orderbook/flow provider must
        never leave the dashboard empty or block forecast creation.
        """
        log.info("Fast sync phase: critical_then_optional_capped")
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'critical_market_data', utc_now()])

        critical = [
            self._safe_call('binance_recent', self.sync_binance_candles(), 7.0, False),
            self._safe_call('binance_ticker', self.sync_binance_ticker(), 3.0, True),
            self._safe_call('kraken_ticker', self.sync_kraken_ticker_metric(), 4.0, True),
            self._safe_call('coinbase_ticker', self.sync_coinbase_ticker_metric(), 4.0, True),
            self._safe_call('coingecko', self.sync_coingecko_price_metric(), 5.0, True),
            self._safe_call('binance_futures', self.sync_binance_futures_layer(), 8.0, True),
        ]
        raw_results = await asyncio.gather(*critical)
        raw_results.append(await self._safe_call('spot_composite', self.sync_spot_composite_metrics(), 3.0, True))

        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'optional_evidence_capped', utc_now()])
        optional = [
            self._safe_call('alternative_me', self.sync_fear_greed(), 2.5, True),
            self._safe_call('binance_orderbook', self.sync_binance_orderbook_snapshot(), 2.5, True),
            self._safe_call('composite_orderbook', self.sync_composite_orderbooks(), 3.5, True),
            self._safe_call('binance_spot_flow', self.sync_binance_spot_tradeflow(), 2.5, True),
            self._safe_call('binance_futures_flow', self.sync_binance_futures_tradeflow(), 2.5, True),
            self._safe_call('fear_greed_history', self.sync_fear_greed_history(), 10.0, True),
            self._safe_call('coinmetrics_history', self.sync_coinmetrics_metrics(days=3000), 18.0, True),
            self._safe_call('futures_history_incremental', self.sync_binance_futures_history_incremental(max_chunks=6), 25.0, True),
        ]
        raw_results.extend(await asyncio.gather(*optional))
        results=[self._log_result(r) for r in raw_results]
        write_json('last_fast_sync_results.json', {"mode": "manual_fast", "results": results})
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'idle', utc_now()])
        return {"results": results}


    async def _store_flow_snapshot(self, source: str, flow: dict) -> dict:
        ts = int(flow.get('timestamp_ms') or int(utc_now().timestamp()*1000))
        rows = [
            (source, 'buy_notional_recent', ts, float(flow.get('buy_notional') or 0), json.dumps({'trade_count': flow.get('trade_count')}), utc_now()),
            (source, 'sell_notional_recent', ts, float(flow.get('sell_notional') or 0), json.dumps({'trade_count': flow.get('trade_count')}), utc_now()),
            (source, 'trade_delta_ratio_recent', ts, float(flow.get('delta_ratio') or 0), json.dumps({'method': 'aggTrades buyer-maker proxy'}), utc_now()),
            (source, 'buy_sell_ratio_recent', ts, float(flow.get('buy_sell_ratio') or 0), json.dumps({'method': 'aggTrades buyer-maker proxy'}), utc_now()),
            (source, 'large_buy_notional_recent', ts, float(flow.get('large_buy_notional') or 0), json.dumps({'threshold': 'spot 250k / futures 500k'}), utc_now()),
            (source, 'large_sell_notional_recent', ts, float(flow.get('large_sell_notional') or 0), json.dumps({'threshold': 'spot 250k / futures 500k'}), utc_now()),
            (source, 'large_trade_imbalance_recent', ts, float(flow.get('large_trade_imbalance') or 0), json.dumps({'method': 'large aggTrade imbalance'}), utc_now()),
            (source, 'largest_trade_notional_recent', ts, float(flow.get('largest_trade_notional') or 0), json.dumps({}), utc_now()),
        ]
        db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
        self.health.success(source, len(rows), {'delta_ratio': flow.get('delta_ratio'), 'large_imbalance': flow.get('large_trade_imbalance'), 'trade_count': flow.get('trade_count')})
        return {"source": source, "status": "ok", "rows": len(rows), "delta_ratio": flow.get('delta_ratio'), "large_imbalance": flow.get('large_trade_imbalance')}

    async def sync_binance_spot_tradeflow(self) -> dict:
        source = 'binance_spot_flow'
        try:
            flow = await self.binance.fetch_recent_agg_trade_flow(settings.symbol, limit=1000)
            return await self._store_flow_snapshot(source, flow)
        except Exception as e:
            self.health.skipped(source, f"optional spot flow unavailable: {e}", {})
            return {"source": source, "status": "skipped", "rows": 0, "warning": str(e)}

    async def sync_binance_futures_tradeflow(self) -> dict:
        source = 'binance_futures_flow'
        try:
            flow = await self.futures.fetch_recent_agg_trade_flow(settings.futures_symbol, limit=1000)
            return await self._store_flow_snapshot(source, flow)
        except Exception as e:
            self.health.skipped(source, f"optional futures flow unavailable: {e}", {})
            return {"source": source, "status": "skipped", "rows": 0, "warning": str(e)}

    async def sync_kraken_ticker_metric(self) -> dict:
        source='kraken_ticker'
        try:
            from app.providers.kraken import KrakenProvider
            x = await KrakenProvider().fetch_btc_usd_ticker()
            ts = int(utc_now().timestamp()*1000)
            rows=[
                (source, 'btc_last_price', ts, float(x.get('price') or 0), json.dumps({'pair':'XBTUSD','volume':x.get('volume')}), utc_now()),
                (source, 'btc_24h_volume', ts, float(x.get('volume') or 0), json.dumps({'pair':'XBTUSD'}), utc_now()),
            ]
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'price': x.get('price')})
            return {"source":source,"status":"ok","rows":len(rows),"price":x.get('price')}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_coinbase_ticker_metric(self) -> dict:
        source='coinbase_ticker'
        try:
            from app.providers.coinbase import CoinbaseProvider
            x = await CoinbaseProvider().fetch_btc_usd_ticker()
            ts = int(utc_now().timestamp()*1000)
            rows=[
                (source, 'btc_last_price', ts, float(x.get('price') or 0), json.dumps({'pair':'BTC-USD','volume':x.get('volume'), 'trade_id':x.get('trade_id')}), utc_now()),
                (source, 'btc_24h_volume', ts, float(x.get('volume') or 0), json.dumps({'pair':'BTC-USD'}), utc_now()),
            ]
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'price': x.get('price')})
            return {"source":source,"status":"ok","rows":len(rows),"price":x.get('price')}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}



    async def sync_spot_composite_metrics(self) -> dict:
        """Composite spot consensus from Binance, Kraken and Coinbase.

        This does not show separate exchange forecasts to the user; it stores a
        single data-quality/evidence layer: cross-exchange spread and spot
        premiums. A wide spread means lower confidence; Kraken/Coinbase premium
        versus Binance can indicate real spot demand or local liquidity stress.
        """
        source = 'spot_composite'
        try:
            now = utc_now()
            ts = int(now.timestamp()*1000)
            def latest(src):
                r = db.fetchone("""
                    SELECT value FROM raw_metric_points
                    WHERE source=? AND metric='btc_last_price'
                    ORDER BY timestamp_ms DESC LIMIT 1
                """, [src])
                return float(r[0]) if r and r[0] is not None else None
            b = latest('binance_ticker')
            k = latest('kraken_ticker')
            c = latest('coinbase_ticker')
            prices = [x for x in (b,k,c) if x and x > 0]
            if len(prices) < 2:
                self.health.skipped(source, 'need at least two spot sources', {'binance': b, 'kraken': k, 'coinbase': c})
                return {"source": source, "status": "skipped", "rows": 0, "warning": "need at least two spot sources"}
            mid = sum(prices) / len(prices)
            spread_pct = ((max(prices) - min(prices)) / mid) * 100 if mid else 0.0
            kraken_premium = ((k / b - 1) * 100) if b and k else None
            coinbase_premium = ((c / b - 1) * 100) if b and c else None
            rows = [
                (source, 'spot_consensus_price', ts, mid, json.dumps({'binance': b, 'kraken': k, 'coinbase': c}), now),
                (source, 'cross_exchange_spread_pct', ts, spread_pct, json.dumps({'prices': prices}), now),
            ]
            if kraken_premium is not None:
                rows.append((source, 'spot_premium_kraken_pct', ts, kraken_premium, json.dumps({'vs':'binance'}), now))
            if coinbase_premium is not None:
                rows.append((source, 'spot_premium_coinbase_pct', ts, coinbase_premium, json.dumps({'vs':'binance'}), now))
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'spread_pct': spread_pct, 'sources': len(prices)})
            return {"source": source, "status": "ok", "rows": len(rows), "spread_pct": spread_pct, "sources": len(prices)}
        except Exception as e:
            self.health.error(source, e)
            return {"source": source, "status": "error", "error": str(e)}

    async def sync_binance_ticker(self) -> dict:
        """Fast live ticker used by the top BTC price card.

        Candles/history can be delayed during deep backfill. This metric gives
        the dashboard a current price as soon as the API responds.
        """
        source='binance_ticker'
        try:
            x = await self.binance.fetch_ticker(settings.symbol)
            ts = int(utc_now().timestamp()*1000)
            rows = [
                (source, 'btc_last_price', ts, float(x.get('price') or 0), json.dumps({'symbol':settings.symbol, 'change_pct': x.get('change_pct'), 'volume': x.get('volume')}), utc_now()),
                (source, 'btc_24h_change_pct', ts, float(x.get('change_pct') or 0), json.dumps({'symbol':settings.symbol}), utc_now()),
                (source, 'btc_24h_volume', ts, float(x.get('volume') or 0), json.dumps({'symbol':settings.symbol}), utc_now()),
            ]
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'price': x.get('price'), 'change_pct': x.get('change_pct')})
            return {"source":source,"status":"ok","rows":len(rows),"price":x.get('price')}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_binance_deep_history(self) -> dict:
        """Backfill older hourly BTC candles backwards from the earliest stored candle.

        V10.15.1 Auto Historical Memory hardening:
        - Uses longer timeouts for 1000-candle historical chunks than for live UI calls.
        - Retries transient Binance/network failures per chunk instead of ending the daemon pass.
        - Records exact start/end window and local min/max so stalls are visible in Data Health/logs.
        - Keeps paging backwards from MIN(open_time), because the recent/live sync owns the newest candles.
        """
        source='binance_history_1h'
        try:
            first = db.fetchone("SELECT MIN(open_time) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
            total = 0
            chunks = 0
            now=utc_now()
            end_ms = int(first[0]) - 1 if first and first[0] else int(utc_now().timestamp()*1000)
            requested_start_end = end_ms
            last_error = None
            while chunks < int(settings.backfill_max_chunks_per_sync) and end_ms > int(settings.historical_start_ms):
                rows = None
                for attempt in range(1, int(settings.binance_backfill_retries) + 1):
                    try:
                        rows = await self.binance.fetch_klines(
                            settings.symbol,
                            '1h',
                            None,
                            int(settings.backfill_chunk_limit),
                            end_ms=end_ms,
                            timeout_seconds=float(settings.binance_backfill_timeout_seconds),
                        )
                        last_error = None
                        break
                    except Exception as exc:
                        last_error = str(exc)
                        append_jsonl('sync_audit.jsonl', {
                            'event': 'binance_history_retry_v10150',
                            'attempt': attempt,
                            'max_attempts': int(settings.binance_backfill_retries),
                            'end_ms': end_ms,
                            'error': last_error,
                        })
                        if attempt < int(settings.binance_backfill_retries):
                            await asyncio.sleep(float(settings.binance_backfill_retry_pause_seconds) * attempt)
                if rows is None:
                    raise RuntimeError(f"Binance historical backfill failed after retries at end_ms={end_ms}: {last_error}")

                # Binance can return a partly older-than-target chunk near the start.
                # Keep only the configured 8Y window but still consider this a normal terminal condition.
                rows = sorted([r for r in rows if int(r['open_time']) >= int(settings.historical_start_ms)], key=lambda r: int(r['open_time']))
                if not rows:
                    break
                payload=[(r['source'],r['symbol'],r['interval'],r['open_time'],r['close_time'],r['open'],r['high'],r['low'],r['close'],r['volume'],r['quote_volume'],r['trades'],now) for r in rows]
                db.executemany("""
                    INSERT OR REPLACE INTO raw_candles VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, payload)
                total += len(payload)
                chunks += 1
                oldest = min(int(r['open_time']) for r in rows)
                newest = max(int(r['open_time']) for r in rows)
                append_jsonl('sync_audit.jsonl', {
                    'event': 'binance_history_chunk_v10150',
                    'rows': len(payload),
                    'oldest': oldest,
                    'newest': newest,
                    'next_end_ms': oldest - 1,
                })
                new_end = oldest - 1
                if new_end >= end_ms:
                    break
                end_ms = new_end
                if len(rows) < int(settings.backfill_chunk_limit):
                    break
            rng = db.fetchone("SELECT MIN(open_time), MAX(open_time), COUNT(*) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
            detail = {
                "symbol": settings.symbol,
                "interval":"1h",
                "chunks": chunks,
                "stored_rows": int(rng[2] or 0) if rng else 0,
                "min_open_time": int(rng[0]) if rng and rng[0] is not None else None,
                "max_open_time": int(rng[1]) if rng and rng[1] is not None else None,
                "requested_start_end_ms": requested_start_end,
                "next_end_ms": end_ms,
            }
            self.health.success(source, total, detail)
            return {"source":source,"status":"ok","rows":total,"chunks":chunks, **detail}
        except Exception as e:
            self.health.error(source, e)
            append_jsonl('sync_audit.jsonl', {'event':'binance_history_error_v10150', 'error':str(e)})
            return {"source":source,"status":"error","rows":0,"chunks":0,"error":str(e)}

    async def sync_binance_candles(self) -> dict:
        """Always fetch the most recent candles.

        Deep backfill can take multiple app starts to fill 2017→now. If this
        function continued from the current MAX(open_time), the dashboard could
        show an old historical candle until the full backfill completed. For the
        live dashboard/forecast we always insert the latest public Binance window.
        The historical backfill remains responsible for filling older gaps.
        """
        source='binance_recent'
        try:
            rows = await self.binance.fetch_klines(settings.symbol, '1h', None, settings.bootstrap_candles_limit)
            now=utc_now()
            payload=[(r['source'],r['symbol'],r['interval'],r['open_time'],r['close_time'],r['open'],r['high'],r['low'],r['close'],r['volume'],r['quote_volume'],r['trades'],now) for r in rows]
            if payload:
                db.executemany("""
                    INSERT OR REPLACE INTO raw_candles VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, payload)
            self.health.success(source, len(payload), {"symbol": settings.symbol, "interval":"1h"})
            return {"source":source,"status":"ok","rows":len(payload)}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_fear_greed(self) -> dict:
        source='alternative_me'
        try:
            x = await self.fear_greed.fetch_latest()
            if not x:
                self.health.success(source, 0, {"empty": True})
                return {"source":source,"status":"empty","rows":0}
            db.execute("""
                INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)
            """, [source, 'fear_greed', x['timestamp_ms'], x['value'], json.dumps({"classification": x.get('classification')}), utc_now()])
            self.health.success(source, 1, {"classification": x.get('classification')})
            return {"source":source,"status":"ok","rows":1}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_coingecko_price_metric(self) -> dict:
        source='coingecko'
        try:
            rows = await self.coingecko.fetch_market_chart(days=30)
            payload=[(source, 'btc_price_usd', r['timestamp_ms'], r['value'], json.dumps({}), utc_now()) for r in rows]
            if payload:
                db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
            self.health.success(source, len(payload), {"metric":"btc_price_usd"})
            return {"source":source,"status":"ok","rows":len(payload)}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}




    async def sync_composite_orderbooks(self) -> dict:
        source='composite_orderbook'
        try:
            x = await self.composite_orderbook.fetch_all()
            if x.get('status') != 'ok':
                raise RuntimeError('; '.join([e.get('exchange','?')+': '+e.get('error','') for e in x.get('errors', [])]) or 'no orderbook sources returned')
            ts = int(utc_now().timestamp()*1000)
            rows = [
                (source, 'orderbook_imbalance', ts, float(x.get('composite_imbalance') or 0.5), json.dumps(x), utc_now()),
                (source, 'orderbook_spread', ts, float(x.get('composite_spread') or 0), json.dumps({'exchange_count':x.get('exchange_count')}), utc_now()),
                (source, 'orderbook_exchange_count', ts, float(x.get('exchange_count') or 0), json.dumps({'errors':x.get('errors', [])}), utc_now()),
                (source, 'orderbook_bid_notional_1pct', ts, float(x.get('bid_notional_1pct') or 0), json.dumps({'unit':'USD notional'}), utc_now()),
                (source, 'orderbook_ask_notional_1pct', ts, float(x.get('ask_notional_1pct') or 0), json.dumps({'unit':'USD notional'}), utc_now()),
            ]
            for key, band in (x.get('bands') or {}).items():
                clean = key.replace('.', '_')
                rows.append((source, f'orderbook_imbalance_{clean}', ts, float(band.get('imbalance') or 0.5), json.dumps(band), utc_now()))
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'exchange_count': x.get('exchange_count'), 'warnings': x.get('errors', [])[:3], 'imbalance': x.get('composite_imbalance')})
            return {"source":source,"status":"ok","rows":len(rows),"exchange_count":x.get('exchange_count'),"warnings":x.get('errors', [])[:3]}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_binance_orderbook_snapshot(self) -> dict:
        source='binance_orderbook'
        try:
            x = await self.binance.fetch_orderbook(settings.symbol, limit=500)
            ts = int(utc_now().timestamp()*1000)
            rows = [
                ('binance', 'orderbook_imbalance', ts, float(x.get('imbalance') or 0.5), json.dumps({'limit':500}), utc_now()),
                ('binance', 'orderbook_spread', ts, float(x.get('spread') or 0), json.dumps({'bid_notional':x.get('bid_notional'), 'ask_notional':x.get('ask_notional')}), utc_now()),
            ]
            db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", rows)
            self.health.success(source, len(rows), {'imbalance': x.get('imbalance'), 'spread': x.get('spread')})
            return {"source":source,"status":"ok","rows":len(rows)}
        except Exception as e:
            self.health.error(source, e)
            return {"source":source,"status":"error","error":str(e)}

    async def sync_binance_futures_layer(self) -> dict:
        source='binance_futures'
        total = 0
        detail = {}
        errors = []
        def store_rows(name: str, rows: list[dict]):
            nonlocal total
            payload=[(source, r['metric'], int(r['timestamp_ms']), float(r['value']), json.dumps({'feed': name}), utc_now()) for r in (rows or []) if r.get('value') is not None]
            if payload:
                db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
            total += len(payload)
            detail[name] = len(payload)

        async def call(name, coro):
            try:
                rows = await coro
                return name, rows, None
            except Exception as e:
                return name, [], str(e)

        try:
            last_funding = db.fetchone("SELECT MAX(timestamp_ms) FROM raw_metric_points WHERE source=? AND metric='funding_rate'", [source])
            start_ms = int(last_funding[0]) + 1 if last_funding and last_funding[0] else None
            import asyncio
            tasks = [
                call('funding_rate', self.futures.fetch_funding_rate(settings.futures_symbol, start_ms=start_ms, limit=1000)),
                call('open_interest', self.futures.fetch_open_interest_hist(settings.futures_symbol, period='1h', limit=500)),
                call('long_short', self.futures.fetch_global_long_short_ratio(settings.futures_symbol, period='1h', limit=500)),
                call('taker_ratio', self.futures.fetch_taker_long_short_ratio(settings.futures_symbol, period='1h', limit=500)),
                call('premium_index', self.futures.fetch_premium_index(settings.futures_symbol)),
                call('current_open_interest', self.futures.fetch_open_interest_current(settings.futures_symbol)),
                call('top_position_ratio', self.futures.fetch_top_long_short_position_ratio(settings.futures_symbol, period='1h', limit=500)),
                call('top_account_ratio', self.futures.fetch_top_long_short_account_ratio(settings.futures_symbol, period='1h', limit=500)),
            ]
            for name, rows, err in await asyncio.gather(*tasks):
                if err:
                    errors.append(f'{name}: {err}')
                    detail[name] = 0
                else:
                    store_rows(name, rows)
            detail['liquidations_recent'] = 'skipped_optional'
        except Exception as e:
            errors.append(f'futures_layer: {e}')

        if total > 0:
            self.health.success(source, total, {**detail, 'warnings': errors[:6]})
            return {"source":source,"status":"ok","rows":total,"detail":detail,"warnings":errors[:6]}
        err = '; '.join(errors) if errors else 'no futures rows'
        self.health.skipped(source, f"optional futures layer unavailable: {err}", detail)
        return {"source":source,"status":"skipped","rows":0,"warning":err,"detail":detail}

    async def sync_fear_greed_history(self) -> dict:
        source='alternative_me'
        try:
            rows = await self.fear_greed.fetch_history(limit=0)
            payload=[(source, 'fear_greed', int(r['timestamp_ms']), float(r['value']), json.dumps({'classification': r.get('classification'), 'history': True}), utc_now()) for r in rows]
            if payload:
                db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
            self.health.success(source, len(payload), {'mode':'full_history_fng'})
            return {"source":source,"status":"ok","rows":len(payload),"mode":"full_history_fng"}
        except Exception as e:
            self.health.skipped(source, f"optional Fear & Greed history unavailable: {e}", {})
            return {"source":source,"status":"skipped","rows":0,"warning":str(e)}


    # ---------------------------------------------------------------------
    # V10.16.29 Honest historical backfill accounting
    # ---------------------------------------------------------------------
    def _metric_count_range(self, source: str, metric: str) -> tuple[int, int | None, int | None]:
        row = db.fetchone(
            "SELECT COUNT(*), MIN(timestamp_ms), MAX(timestamp_ms) FROM raw_metric_points WHERE source=? AND metric=?",
            [source, metric],
        )
        if not row:
            return 0, None, None
        return int(row[0] or 0), (int(row[1]) if row[1] is not None else None), (int(row[2]) if row[2] is not None else None)

    def _estimate_rows_per_minute(self, rows_added: int, started_at: datetime) -> float | None:
        try:
            seconds = max(0.001, (utc_now() - started_at).total_seconds())
            return float(rows_added) / seconds * 60.0
        except Exception:
            return None

    def _target_rows_for_range(self, start_ms: int, end_ms: int, granularity_ms: int) -> int:
        try:
            return max(1, int((int(end_ms) - int(start_ms)) // max(1, int(granularity_ms))) + 1)
        except Exception:
            return 1



    def _external_effective_start_ms(self, metric: str, requested_start_ms: int, now_ms: int, granularity_ms: int) -> tuple[int, bool, str]:
        """Return the honest target start for a public external feed.

        Critical v10.16.32 audit conclusion:
        Several Binance /futures/data endpoints do not provide eight years of
        public history. Earlier builds showed an eight-year target, filled only
        the latest +/- 500 rows, advanced cursor_next_ms to NOW, and then marked
        the feed as current. That made the daemon skip forever at 1%.

        Funding is kept as real historical evidence. The OI / L-S / taker / top
        trader feeds are treated as public-provider-limited unless explicitly
        overridden. They still remain valuable recent evidence, but they must not
        pretend to be eight-year Time Machine evidence.
        """
        metric = str(metric or '')
        requested_start_ms = int(requested_start_ms)
        now_ms = int(now_ms)
        if metric == 'funding_rate':
            return requested_start_ms, False, 'binance_funding_historical'
        # Public Binance futures/data market-stat endpoints are practically a
        # recent-window source. Use 31 days so a 30d endpoint can fill with some
        # tolerance around boundaries. This can be overridden on the VPS only if
        # the user later adds a paid/provider warehouse with deeper history.
        if metric in {
            'open_interest_value', 'open_interest_contracts', 'long_short_ratio',
            'taker_buy_sell_ratio', 'top_position_long_short_ratio',
            'top_account_long_short_ratio',
        }:
            if str(getattr(settings, 'binance_futures_full_history_override', '') or '').lower() in ('1', 'true', 'yes'):
                return requested_start_ms, False, 'override_full_history'
            provider_start = max(requested_start_ms, now_ms - 31 * 24 * 3600000)
            # Align to granularity to avoid drifting cursors.
            provider_start = int(provider_start // max(1, int(granularity_ms)) * max(1, int(granularity_ms)))
            return provider_start, True, 'binance_public_recent_window_31d'
        return requested_start_ms, False, 'full_target_requested'

    def _repair_external_cursor(
        self,
        *,
        source: str,
        dataset: str,
        metric: str,
        target_start_ms: int,
        target_end_ms: int,
        granularity_ms: int,
        rows_current: int,
        rows_target: int,
        raw_min_ts: int | None,
        raw_max_ts: int | None,
        preferred_cursor_ms: int | None,
        reason_context: str,
    ) -> tuple[int, bool, str]:
        """Repair the exact cursor bug seen on VPS.

        Bad state from Termius:
          rows_current ~= 507, rows_target ~= 59535, cursor_next_ms ~= now,
          status=current, rows_added_last_batch=0.

        That means the old incremental logic filled only recent rows, then moved
        the cursor to the end. If coverage is not complete, a cursor near target
        end is invalid and must go back to the target start so the daemon can
        fill old missing history instead of skipping forever.
        """
        step = max(1, int(granularity_ms or 1))
        target_start_ms = int(target_start_ms)
        target_end_ms = int(target_end_ms)
        rows_current = int(rows_current or 0)
        rows_target = max(1, int(rows_target or 1))
        coverage = rows_current / rows_target
        cursor = None
        try:
            cursor = int(preferred_cursor_ms) if preferred_cursor_ms is not None else None
        except Exception:
            cursor = None
        near_end = cursor is not None and cursor >= target_end_ms - step
        raw_starts_late = raw_min_ts is not None and int(raw_min_ts) > target_start_ms + (step * 2)
        raw_ends_near_now = raw_max_ts is not None and int(raw_max_ts) >= target_end_ms - (step * 48)
        low_coverage = coverage < 0.98

        if rows_current <= 0:
            return target_start_ms, True, f'{reason_context}:empty_start_at_target_start'
        if low_coverage and (near_end or (raw_starts_late and raw_ends_near_now)):
            append_jsonl('backfill_cursor_repair.jsonl', {
                'event': 'cursor_repaired_v101632', 'source': source, 'dataset': dataset,
                'metric': metric, 'old_cursor_next_ms': cursor, 'new_cursor_next_ms': target_start_ms,
                'rows_current': rows_current, 'rows_target': rows_target,
                'raw_min_ts': raw_min_ts, 'raw_max_ts': raw_max_ts,
                'target_start_ms': target_start_ms, 'target_end_ms': target_end_ms,
                'reason': reason_context,
            })
            return target_start_ms, True, f'{reason_context}:cursor_was_at_end_with_low_coverage'
        if cursor is None:
            # Do NOT use raw MAX when coverage is incomplete: that is the old bug.
            if low_coverage:
                return target_start_ms, True, f'{reason_context}:no_job_cursor_low_coverage_start_at_target'
            if raw_max_ts is not None:
                return int(raw_max_ts) + step, False, f'{reason_context}:incremental_after_raw_max'
            return target_start_ms, True, f'{reason_context}:no_cursor_start_at_target'
        if cursor < target_start_ms:
            return target_start_ms, True, f'{reason_context}:cursor_before_target_clamped'
        return cursor, False, f'{reason_context}:cursor_ok'

    def _read_backfill_job(self, source: str, dataset: str, metric: str) -> dict:
        rows = db.df(
            """
            SELECT * FROM backfill_jobs
            WHERE source=? AND dataset=? AND metric=?
            LIMIT 1
            """,
            [source, dataset, metric],
        ).to_dict('records')
        return rows[0] if rows else {}

    def _upsert_backfill_job(
        self,
        *,
        source: str,
        dataset: str,
        metric: str,
        status: str,
        granularity_ms: int,
        target_start_ms: int,
        target_end_ms: int,
        cursor_next_ms: int | None,
        rows_current: int,
        rows_target: int,
        rows_added_last_batch: int,
        batch_started_at: datetime | None,
        last_error: str | None = None,
        provider_limit_reached: bool = False,
        metadata: dict | None = None,
    ) -> None:
        existing = self._read_backfill_job(source, dataset, metric)
        old_rows = int(existing.get('rows_current') or 0) if existing else 0
        old_batches = int(existing.get('batches_done') or 0) if existing else 0
        old_pages = int(existing.get('pages_done') or 0) if existing else 0
        old_errors = int(existing.get('error_count') or 0) if existing else 0
        old_rpm = existing.get('rows_per_minute') if existing else None
        rows_current = int(rows_current or 0)
        rows_target = max(1, int(rows_target or 1))
        coverage = min(100.0, (rows_current / rows_target) * 100.0)
        rows_added_last_batch = int(rows_added_last_batch or 0)
        rows_per_minute = self._estimate_rows_per_minute(rows_added_last_batch, batch_started_at) if batch_started_at else None
        if rows_per_minute is None or rows_per_minute <= 0:
            try:
                rows_per_minute = float(old_rpm) if old_rpm is not None else None
            except Exception:
                rows_per_minute = None
        remaining = max(0, rows_target - rows_current)
        eta_seconds = (remaining / rows_per_minute * 60.0) if rows_per_minute and rows_per_minute > 0 and remaining > 0 else None
        no_growth = rows_current <= old_rows and status in ('running', 'provider_limited', 'stuck')
        stuck_since = existing.get('stuck_since') if existing else None
        if no_growth and rows_added_last_batch <= 0 and rows_current < rows_target:
            stuck_since = stuck_since or utc_now()
            if status == 'running':
                status = 'stuck'
        elif rows_added_last_batch > 0:
            stuck_since = None
        last_success_at = utc_now() if rows_added_last_batch > 0 or status in ('complete', 'current', 'provider_limited_current') else existing.get('last_success_at') if existing else None
        error_count = old_errors + (1 if last_error else 0)
        db.execute(
            """
            INSERT OR REPLACE INTO backfill_jobs
            (source, dataset, metric, status, granularity_ms, target_start_ms, target_end_ms,
             cursor_next_ms, rows_current, rows_target, coverage_pct, rows_added_last_batch,
             batches_done, pages_done, last_success_at, last_attempt_at, last_error, error_count,
             rate_limit_until, provider_limit_reached, stuck_since, eta_seconds, rows_per_minute,
             metadata, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?::JSON, ?)
            """,
            [
                source, dataset, metric, status, int(granularity_ms), int(target_start_ms), int(target_end_ms),
                int(cursor_next_ms) if cursor_next_ms is not None else None, rows_current, rows_target, float(coverage), rows_added_last_batch,
                old_batches + 1, old_pages + 1, last_success_at, utc_now(), last_error, error_count,
                None, bool(provider_limit_reached), stuck_since, eta_seconds, rows_per_minute,
                json.dumps(metadata or {}, default=str), utc_now(),
            ],
        )
        append_jsonl('backfill_jobs_audit.jsonl', {
            'event': 'backfill_job_update_v101629', 'source': source, 'dataset': dataset, 'metric': metric,
            'status': status, 'rows_current': rows_current, 'rows_target': rows_target,
            'rows_added_last_batch': rows_added_last_batch, 'cursor_next_ms': cursor_next_ms,
            'provider_limit_reached': provider_limit_reached, 'last_error': last_error,
        })

    async def sync_binance_futures_history_incremental(self, max_chunks: int = 10) -> dict:
        """V10.16.29 honest, resumable Binance Futures historical backfill.

        This version is no longer just text progress in sync_state. Every feed is
        tracked in backfill_jobs with a durable cursor, real row counts,
        rows_added_last_batch, status, provider-limit/stuck state and ETA data.
        The mobile Data cockpit reads these job rows directly.
        """
        source = 'binance_futures'
        dataset = 'binance_usdm_public_history'
        metric_feeds = [
            ('funding_rate', lambda st, en: self.futures.fetch_funding_rate(settings.futures_symbol, start_ms=st, limit=1000), 8 * 3600000, 1000),
            ('open_interest_value', lambda st, en: self.futures.fetch_open_interest_hist(settings.futures_symbol, period='1h', start_ms=st, end_ms=en, limit=500), 3600000, 500),
            ('long_short_ratio', lambda st, en: self.futures.fetch_global_long_short_ratio(settings.futures_symbol, period='1h', start_ms=st, end_ms=en, limit=500), 3600000, 500),
            ('taker_buy_sell_ratio', lambda st, en: self.futures.fetch_taker_long_short_ratio(settings.futures_symbol, period='1h', start_ms=st, end_ms=en, limit=500), 3600000, 500),
            ('top_position_long_short_ratio', lambda st, en: self.futures.fetch_top_long_short_position_ratio(settings.futures_symbol, period='1h', start_ms=st, end_ms=en, limit=500), 3600000, 500),
            ('top_account_long_short_ratio', lambda st, en: self.futures.fetch_top_long_short_account_ratio(settings.futures_symbol, period='1h', start_ms=st, end_ms=en, limit=500), 3600000, 500),
        ]
        now_ms = int(utc_now().timestamp() * 1000)
        # BTCUSDT USD-M futures history starts later than spot. Do not show fake
        # 2017 targets for futures feeds that could not exist yet.
        start_floor = max(int(getattr(settings, 'external_history_target_start_ms', settings.historical_start_ms)), 1567296000000)
        pages = max(1, min(int(max_chunks or 1), int(getattr(settings, 'external_history_pages_per_daemon_pass', 6))))
        total_added = 0
        detail: dict = {}
        errors: list[str] = []

        async def one(feed: str, fn, step_ms: int, limit: int) -> None:
            nonlocal total_added
            batch_started = utc_now()
            before_count, min_existing_ts, max_existing_ts = self._metric_count_range(source, feed)
            effective_start_ms, provider_limited_target, target_reason = self._external_effective_start_ms(feed, start_floor, now_ms, step_ms)
            rows_target = self._target_rows_for_range(effective_start_ms, now_ms, step_ms)
            existing_job = self._read_backfill_job(source, dataset, feed)
            cursor_from_job = existing_job.get('cursor_next_ms') if existing_job else None
            try:
                cursor_from_job = int(cursor_from_job) if cursor_from_job is not None else None
            except Exception:
                cursor_from_job = None
            st, cursor_repaired, cursor_reason = self._repair_external_cursor(
                source=source, dataset=dataset, metric=feed,
                target_start_ms=effective_start_ms, target_end_ms=now_ms, granularity_ms=step_ms,
                rows_current=before_count, rows_target=rows_target,
                raw_min_ts=min_existing_ts, raw_max_ts=max_existing_ts,
                preferred_cursor_ms=cursor_from_job, reason_context=target_reason,
            )
            self._upsert_backfill_job(
                source=source, dataset=dataset, metric=feed, status='running', granularity_ms=step_ms,
                target_start_ms=effective_start_ms, target_end_ms=now_ms, cursor_next_ms=st,
                rows_current=before_count, rows_target=rows_target, rows_added_last_batch=0,
                batch_started_at=batch_started, provider_limit_reached=provider_limited_target,
                metadata={'phase': 'attempt_started', 'pages_budget': pages, 'limit': limit, 'target_reason': target_reason, 'cursor_repaired': cursor_repaired, 'cursor_reason': cursor_reason},
            )
            page_count = 0
            last_status = 'running'
            last_error = None
            provider_limit_reached = False
            cursor_next = st
            try:
                for _ in range(pages):
                    if cursor_next >= now_ms - step_ms:
                        last_status = 'current'
                        break
                    en = min(now_ms, cursor_next + int(step_ms) * int(limit))
                    rows = await fn(cursor_next, en)
                    payload = []
                    max_ts_seen = cursor_next
                    feed_metric_seen = False
                    for r in (rows or []):
                        if r.get('value') is None:
                            continue
                        ts = int(r['timestamp_ms'])
                        max_ts_seen = max(max_ts_seen, ts)
                        if str(r.get('metric')) == feed:
                            feed_metric_seen = True
                        payload.append((
                            source,
                            str(r.get('metric') or feed),
                            ts,
                            float(r['value']),
                            json.dumps({'feed': feed, 'historical_warehouse': True, 'v': '10.16.29', 'cursor_from_ms': cursor_next, 'cursor_to_ms': en}),
                            utc_now(),
                        ))
                    if payload:
                        db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
                    page_count += 1
                    # Detect provider-limited/no-progress honestly. Some futures/data
                    # endpoints simply do not return old history for the requested range.
                    if not payload or max_ts_seen <= cursor_next or (feed != 'funding_rate' and not feed_metric_seen):
                        provider_limit_reached = True
                        last_status = 'provider_limited'
                        break
                    cursor_next = max_ts_seen + step_ms
                    await asyncio.sleep(float(getattr(settings, 'external_backfill_pause_seconds', 0.25)))
                after_count, _mn, after_max_ts = self._metric_count_range(source, feed)
                rows_added = max(0, int(after_count) - int(before_count))
                total_added += rows_added
                rows_target = self._target_rows_for_range(effective_start_ms, now_ms, step_ms)
                if provider_limited_target and after_count >= rows_target * 0.90:
                    last_status = 'provider_limited_current'
                    provider_limit_reached = True
                elif after_count >= rows_target * 0.98 or last_status == 'current':
                    last_status = 'complete' if after_count >= rows_target * 0.98 else ('provider_limited_current' if provider_limited_target else 'current')
                    provider_limit_reached = bool(provider_limited_target and after_count < self._target_rows_for_range(start_floor, now_ms, step_ms) * 0.98)
                elif rows_added <= 0 and provider_limit_reached:
                    last_status = 'provider_limited'
                elif rows_added <= 0:
                    last_status = 'stuck'
                self._upsert_backfill_job(
                    source=source, dataset=dataset, metric=feed, status=last_status, granularity_ms=step_ms,
                    target_start_ms=effective_start_ms, target_end_ms=now_ms, cursor_next_ms=cursor_next,
                    rows_current=after_count, rows_target=rows_target, rows_added_last_batch=rows_added,
                    batch_started_at=batch_started, last_error=last_error, provider_limit_reached=provider_limit_reached,
                    metadata={'pages_this_pass': page_count, 'last_seen_ts': after_max_ts, 'pages_budget': pages, 'limit': limit, 'target_reason': target_reason, 'effective_start_ms': effective_start_ms},
                )
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", [
                    f'external_progress_{feed}',
                    f'status={last_status} rows_current={after_count} rows_target={rows_target} rows_added_last_batch={rows_added} pages={page_count} cursor_next_ms={cursor_next}',
                    utc_now(),
                ])
                detail[feed] = {'rows_current': after_count, 'rows_target': rows_target, 'rows_added_last_batch': rows_added, 'pages': page_count, 'status': last_status, 'cursor_next_ms': cursor_next, 'provider_limit_reached': provider_limit_reached}
            except Exception as e:
                last_error = str(e)[:300]
                errors.append(f'{feed}: {last_error}')
                after_count, _mn, after_max_ts = self._metric_count_range(source, feed)
                text = last_error.lower()
                if '429' in text or 'rate limit' in text or 'too many requests' in text:
                    status = 'rate_limited'
                elif '403' in text or 'forbidden' in text:
                    status = 'provider_blocked'
                    provider_limit_reached = True
                else:
                    status = 'error'
                self._upsert_backfill_job(
                    source=source, dataset=dataset, metric=feed, status=status, granularity_ms=step_ms,
                    target_start_ms=effective_start_ms, target_end_ms=now_ms, cursor_next_ms=cursor_next,
                    rows_current=after_count, rows_target=rows_target, rows_added_last_batch=0,
                    batch_started_at=batch_started, last_error=last_error, provider_limit_reached=provider_limit_reached,
                    metadata={'pages_this_pass': page_count, 'last_seen_ts': after_max_ts},
                )
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", [
                    f'external_progress_{feed}',
                    f'status={status} rows_current={after_count} rows_target={rows_target} rows_added_last_batch=0 pages={page_count} cursor_next_ms={cursor_next} error={last_error}',
                    utc_now(),
                ])
                detail[feed] = {'rows_current': after_count, 'rows_target': rows_target, 'rows_added_last_batch': 0, 'pages': page_count, 'status': status, 'error': last_error, 'cursor_next_ms': cursor_next}

        await asyncio.gather(*[one(feed, fn, step, lim) for feed, fn, step, lim in metric_feeds])
        status = 'ok' if total_added > 0 else 'skipped'
        if total_added > 0:
            self.health.success(source, total_added, {'history_warehouse': detail, 'warnings': errors[:6], 'progress_table': 'backfill_jobs'})
        else:
            self.health.skipped(source, 'no new futures history rows this pass; see backfill_jobs for provider_limit/stuck/error state', {'detail': detail, 'warnings': errors[:6]})
        return {"source": source, "status": status, "rows": total_added, "detail": detail, "warnings": errors[:6], "progress_table": "backfill_jobs"}

    async def sync_cross_exchange_history_incremental(self, max_pages: int | None = None) -> dict:
        """Build persistent historical Coinbase/Kraken premium layers.

        This fills raw_metric_points with Coinbase/Kraken BTC-USD hourly closes
        and spot premiums versus the existing Binance 1h candle warehouse. It is
        resumable: every run continues from the last stored timestamp per source.
        """
        max_pages = int(max_pages if max_pages is not None else getattr(settings, 'external_history_pages_per_daemon_pass', 6))
        max_pages = max(1, min(max_pages, 24))
        start_floor=int(getattr(settings, 'external_history_target_start_ms', settings.historical_start_ms))
        now_ms=int(utc_now().timestamp()*1000)
        total=0; errors=[]; detail={}

        async def process_coinbase():
            nonlocal total
            if not self.coinbase:
                detail['coinbase']='provider_missing'; return
            rows_added=0; pages=0; batch_started=utc_now()
            before_premium, pm_min, pm_max = self._metric_count_range('spot_composite', 'spot_premium_coinbase_pct')
            coinbase_target = self._target_rows_for_range(start_floor, now_ms, 3600000)
            existing_job = self._read_backfill_job('spot_composite', 'cross_exchange_history', 'spot_premium_coinbase_pct')
            cursor_from_job = existing_job.get('cursor_next_ms') if existing_job else None
            try:
                cursor_from_job = int(cursor_from_job) if cursor_from_job is not None else None
            except Exception:
                cursor_from_job = None
            st, cursor_repaired, cursor_reason = self._repair_external_cursor(
                source='spot_composite', dataset='cross_exchange_history', metric='spot_premium_coinbase_pct',
                target_start_ms=start_floor, target_end_ms=now_ms, granularity_ms=3600000,
                rows_current=before_premium, rows_target=coinbase_target,
                raw_min_ts=pm_min, raw_max_ts=pm_max, preferred_cursor_ms=cursor_from_job,
                reason_context='coinbase_cross_exchange_premium',
            )
            self._upsert_backfill_job(source='spot_composite', dataset='cross_exchange_history', metric='spot_premium_coinbase_pct', status='running', granularity_ms=3600000, target_start_ms=start_floor, target_end_ms=now_ms, cursor_next_ms=st, rows_current=before_premium, rows_target=coinbase_target, rows_added_last_batch=0, batch_started_at=batch_started, metadata={'provider':'coinbase','phase':'attempt_started','cursor_repaired':cursor_repaired,'cursor_reason':cursor_reason})
            for _ in range(max_pages):
                if st>=now_ms-3600000: break
                en=min(now_ms, st + 299*3600000)
                try:
                    rows=await self.coinbase.fetch_btc_usd_candles(st,en,granularity=3600)
                except Exception as e:
                    errors.append('coinbase_history: '+str(e)); break
                payload=[]; premium=[]; max_ts=st
                for r in rows or []:
                    ts=int(r['timestamp_ms']); max_ts=max(max_ts, ts)
                    close=float(r['close']); vol=float(r.get('volume') or 0)
                    payload.append(('coinbase_history','btc_close',ts,close,json.dumps({'historical_warehouse':True,'v':'10.16.25'}),utc_now()))
                    payload.append(('coinbase_history','btc_volume',ts,vol,json.dumps({'historical_warehouse':True,'v':'10.16.25'}),utc_now()))
                    b=db.fetchone("SELECT close FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' AND open_time=?", [settings.symbol, ts])
                    if b and b[0]:
                        prem=(close/float(b[0])-1.0)*100.0
                        premium.append(('spot_composite','spot_premium_coinbase_pct',ts,prem,json.dumps({'from':'coinbase_history','vs':'binance','historical_warehouse':True}),utc_now()))
                if payload: db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
                if premium: db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", premium)
                added=len(payload)+len(premium); total+=added; rows_added+=added; pages+=1
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['external_progress_coinbase_history', f'rows={rows_added} pages={pages} last_ts={max_ts}', utc_now()])
                if not rows or max_ts<=st: break
                st=max_ts+3600000
                await asyncio.sleep(float(getattr(settings, 'external_backfill_pause_seconds', 0.25)))
            after_premium, _pm_min2, pm_max2 = self._metric_count_range('spot_composite', 'spot_premium_coinbase_pct')
            coinbase_added = max(0, int(after_premium) - int(before_premium))
            if after_premium >= coinbase_target * 0.98:
                cb_status = 'complete'
            elif st >= now_ms-3600000 and after_premium < coinbase_target * 0.98:
                cb_status = 'gap_repair_needed'
                st = start_floor
            else:
                cb_status = 'running' if coinbase_added > 0 else 'stuck'
            self._upsert_backfill_job(source='spot_composite', dataset='cross_exchange_history', metric='spot_premium_coinbase_pct', status=cb_status, granularity_ms=3600000, target_start_ms=start_floor, target_end_ms=now_ms, cursor_next_ms=st, rows_current=after_premium, rows_target=coinbase_target, rows_added_last_batch=coinbase_added, batch_started_at=batch_started, metadata={'provider':'coinbase','pages_this_pass':pages,'last_seen_ts':pm_max2})
            detail['coinbase_history']={'rows':rows_added,'pages':pages,'premium_rows_added':coinbase_added,'status':cb_status}

        async def process_kraken():
            nonlocal total
            if not getattr(self, 'kraken', None):
                detail['kraken']='provider_missing'; return
            rows_added=0; pages=0; batch_started=utc_now()
            before_premium, pm_min, pm_max = self._metric_count_range('spot_composite', 'spot_premium_kraken_pct')
            kraken_target = self._target_rows_for_range(start_floor, now_ms, 3600000)
            existing_job = self._read_backfill_job('spot_composite', 'cross_exchange_history', 'spot_premium_kraken_pct')
            cursor_from_job = existing_job.get('cursor_next_ms') if existing_job else None
            try:
                cursor_from_job = int(cursor_from_job) if cursor_from_job is not None else None
            except Exception:
                cursor_from_job = None
            st, cursor_repaired, cursor_reason = self._repair_external_cursor(
                source='spot_composite', dataset='cross_exchange_history', metric='spot_premium_kraken_pct',
                target_start_ms=start_floor, target_end_ms=now_ms, granularity_ms=3600000,
                rows_current=before_premium, rows_target=kraken_target,
                raw_min_ts=pm_min, raw_max_ts=pm_max, preferred_cursor_ms=cursor_from_job,
                reason_context='kraken_cross_exchange_premium',
            )
            self._upsert_backfill_job(source='spot_composite', dataset='cross_exchange_history', metric='spot_premium_kraken_pct', status='running', granularity_ms=3600000, target_start_ms=start_floor, target_end_ms=now_ms, cursor_next_ms=st, rows_current=before_premium, rows_target=kraken_target, rows_added_last_batch=0, batch_started_at=batch_started, metadata={'provider':'kraken','phase':'attempt_started','cursor_repaired':cursor_repaired,'cursor_reason':cursor_reason})
            for _ in range(max_pages):
                if st>=now_ms-3600000: break
                try:
                    rows=await self.kraken.fetch_btc_usd_ohlc(st, interval=60)
                except Exception as e:
                    errors.append('kraken_history: '+str(e)); break
                payload=[]; premium=[]; max_ts=st
                # keep at most one API page worth of new rows per loop; Kraken returns many rows.
                for r in (rows or [])[:720]:
                    ts=int(r['timestamp_ms']);
                    if ts < st: continue
                    max_ts=max(max_ts, ts); close=float(r['close']); vol=float(r.get('volume') or 0)
                    payload.append(('kraken_history','btc_close',ts,close,json.dumps({'historical_warehouse':True,'v':'10.16.25'}),utc_now()))
                    payload.append(('kraken_history','btc_volume',ts,vol,json.dumps({'historical_warehouse':True,'v':'10.16.25'}),utc_now()))
                    b=db.fetchone("SELECT close FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' AND open_time=?", [settings.symbol, ts])
                    if b and b[0]:
                        prem=(close/float(b[0])-1.0)*100.0
                        premium.append(('spot_composite','spot_premium_kraken_pct',ts,prem,json.dumps({'from':'kraken_history','vs':'binance','historical_warehouse':True}),utc_now()))
                if payload: db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
                if premium: db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", premium)
                added=len(payload)+len(premium); total+=added; rows_added+=added; pages+=1
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['external_progress_kraken_history', f'rows={rows_added} pages={pages} last_ts={max_ts}', utc_now()])
                if not rows or max_ts<=st: break
                st=max_ts+3600000
                await asyncio.sleep(float(getattr(settings, 'external_backfill_pause_seconds', 0.25)))
            after_premium, _pm_min2, pm_max2 = self._metric_count_range('spot_composite', 'spot_premium_kraken_pct')
            kraken_added = max(0, int(after_premium) - int(before_premium))
            if after_premium >= kraken_target * 0.98:
                kr_status = 'complete'
            elif st >= now_ms-3600000 and after_premium < kraken_target * 0.98:
                kr_status = 'gap_repair_needed'
                st = start_floor
            else:
                kr_status = 'running' if kraken_added > 0 else 'stuck'
            self._upsert_backfill_job(source='spot_composite', dataset='cross_exchange_history', metric='spot_premium_kraken_pct', status=kr_status, granularity_ms=3600000, target_start_ms=start_floor, target_end_ms=now_ms, cursor_next_ms=st, rows_current=after_premium, rows_target=kraken_target, rows_added_last_batch=kraken_added, batch_started_at=batch_started, metadata={'provider':'kraken','pages_this_pass':pages,'last_seen_ts':pm_max2})
            detail['kraken_history']={'rows':rows_added,'pages':pages,'premium_rows_added':kraken_added,'status':kr_status}

        await asyncio.gather(process_coinbase(), process_kraken())
        # Composite cross-exchange spread where both premiums exist at the same timestamp.
        try:
            db.execute("""
                INSERT OR REPLACE INTO raw_metric_points
                SELECT 'spot_composite' AS source,
                       'cross_exchange_spread_pct' AS metric,
                       c.timestamp_ms,
                       ABS(c.value-k.value) AS value,
                       '{"from":"coinbase_kraken_history","historical_warehouse":true}'::JSON AS metadata,
                       ? AS synced_at
                FROM raw_metric_points c
                JOIN raw_metric_points k ON c.timestamp_ms=k.timestamp_ms
                WHERE c.source='spot_composite' AND c.metric='spot_premium_coinbase_pct'
                  AND k.source='spot_composite' AND k.metric='spot_premium_kraken_pct'
            """, [utc_now()])
        except Exception as e:
            errors.append('cross_exchange_spread: '+str(e))
        if total>0:
            self.health.success('cross_exchange_history', total, {'detail':detail,'warnings':errors[:4]})
            return {'source':'cross_exchange_history','status':'ok','rows':total,'detail':detail,'warnings':errors[:4]}
        self.health.skipped('cross_exchange_history', 'no cross-exchange history rows this pass', {'detail':detail,'warnings':errors[:4]})
        return {'source':'cross_exchange_history','status':'skipped','rows':0,'detail':detail,'warning':'; '.join(errors[:4])}

    async def sync_external_evidence_deep_fill(self, passes: int | None = None, max_feeds: int | None = None) -> dict:
        """V10.16.19 persistent external-evidence backfill.

        This is the first real multi-source evidence filler. It keeps candles in
        the shared database untouched and progressively fills the historical
        auxiliary layers that Time Machine models need:
        - Binance Futures funding, open interest, long/short, taker ratio, top trader ratios
        - Alternative.me Fear & Greed full history
        - CoinMetrics community on-chain metrics when available
        - current/recent orderbook, spot/futures trade-flow and cross-exchange premium

        It is intentionally resumable. Each pass adds bounded chunks from the
        last timestamp already stored in raw_metric_points, so running it again
        continues instead of starting over.
        """
        passes = int(passes if passes is not None else getattr(settings, 'external_backfill_passes_per_sync', 8))
        max_feeds = int(max_feeds if max_feeds is not None else getattr(settings, 'external_backfill_max_feeds', 6))
        pause = float(getattr(settings, 'external_backfill_pause_seconds', 0.25))
        started = utc_now()
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['external_evidence_backfill', 'running', started])
        db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'external_evidence_deep_fill', started])
        results=[]
        total_rows=0
        try:
            # First run broad daily/current layers. They are important, but never allowed
            # to block Forecast/UI. Each failed call is logged as retry_queued unless it is a
            # known permission issue (e.g. CoinMetrics community 403 without API key).
            provider_jobs = [
                ('fear_greed_history', self.sync_fear_greed_history(), 12.0),
                ('spot_composite', self.sync_spot_composite_metrics(), 4.0),
                ('composite_orderbook', self.sync_composite_orderbooks(), 5.0),
                ('binance_spot_flow', self.sync_binance_spot_tradeflow(), 4.0),
                ('binance_futures_flow', self.sync_binance_futures_tradeflow(), 4.0),
                ('binance_futures_live', self.sync_binance_futures_layer(), 10.0),
                ('cross_exchange_history', self.sync_cross_exchange_history_incremental(max_pages=max(1, min(4, max_feeds))), 18.0),
            ]
            if getattr(settings, 'coinmetrics_enabled', False) and getattr(settings, 'coinmetrics_api_key', ''):
                provider_jobs.append(('coinmetrics_history', self.sync_coinmetrics_metrics(days=3300), 18.0))
            else:
                disabled = {'source':'coinmetrics_history','status':'disabled','rows':0,'warning':'CoinMetrics disabled: set BEE_COINMETRICS_ENABLED=1 and BEE_COINMETRICS_API_KEY to enable real on-chain MVRV'}
                results.append(self._log_result(disabled))
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['coinmetrics_status', 'disabled_missing_api_key', utc_now()])

            for name, coro, timeout in provider_jobs:
                r = await self._safe_call(name, coro, timeout, True)
                results.append(self._log_result(r))
                total_rows += int(r.get('rows') or 0)

            # Then progress futures + cross-exchange history. Binance/Coinbase/Kraken endpoints are page-limited;
            # repeated daemon passes are the honest way to fill years of evidence without blocking the UI.
            for i in range(max(1, min(passes, 12))):
                r = await self._safe_call(
                    f'futures_history_pass_{i+1}',
                    self.sync_binance_futures_history_incremental(max_chunks=max_feeds),
                    55.0,
                    True,
                )
                results.append(self._log_result(r))
                total_rows += int(r.get('rows') or 0)
                r2 = await self._safe_call(
                    f'cross_exchange_history_pass_{i+1}',
                    self.sync_cross_exchange_history_incremental(max_pages=max(1, min(3, max_feeds))),
                    35.0,
                    True,
                )
                results.append(self._log_result(r2))
                total_rows += int(r2.get('rows') or 0)
                db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['external_evidence_backfill_progress', f'pass {i+1}/{passes} rows={total_rows}', utc_now()])
                await asyncio.sleep(max(0.0, pause))

            rebuilt = 0
            try:
                from app.engine.feature_engine import FeatureEngine
                rebuilt = FeatureEngine().rebuild()
                append_jsonl('sync_audit.jsonl', {'event':'external_evidence_features_rebuilt_v101619', 'rows':rebuilt})
            except Exception as exc:
                append_jsonl('sync_audit.jsonl', {'event':'external_evidence_features_rebuild_failed_v101619', 'error':str(exc)})

            # compact coverage summary for UI/debug/export
            coverage = {}
            for source, metric in [
                ('alternative_me','fear_greed'),
                ('binance_futures','funding_rate'),
                ('binance_futures','open_interest_value'),
                ('binance_futures','long_short_ratio'),
                ('binance_futures','taker_buy_sell_ratio'),
                ('binance_futures','top_position_long_short_ratio'),
                ('binance_futures','top_account_long_short_ratio'),
                ('coinmetrics_community','CapMVRVCur'),
                ('spot_composite','cross_exchange_spread_pct'),
                ('spot_composite','spot_premium_coinbase_pct'),
                ('spot_composite','spot_premium_kraken_pct'),
                ('coinbase_history','btc_close'),
                ('kraken_history','btc_close'),
                ('composite_orderbook','orderbook_imbalance'),
            ]:
                row = db.fetchone("SELECT COUNT(*), MIN(timestamp_ms), MAX(timestamp_ms) FROM raw_metric_points WHERE source=? AND metric=?", [source, metric])
                coverage[f'{source}:{metric}'] = {'rows': int(row[0] or 0) if row else 0, 'min_ts': row[1] if row else None, 'max_ts': row[2] if row else None}
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['external_evidence_backfill', f'completed rows={total_rows} features={rebuilt}', utc_now()])
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'idle', utc_now()])
            self.health.success('external_evidence_backfill', total_rows, {'passes': passes, 'features_rebuilt': rebuilt, 'coverage': coverage})
            return {'source':'external_evidence_backfill','status':'ok','rows':total_rows,'passes':passes,'features_rebuilt':rebuilt,'coverage':coverage,'results':results}
        except Exception as exc:
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['external_evidence_backfill', 'error: '+str(exc)[:300], utc_now()])
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ['sync_phase', 'idle', utc_now()])
            self.health.error('external_evidence_backfill', exc)
            append_jsonl('sync_audit.jsonl', {'event':'external_evidence_backfill_failed_v101619','error':str(exc)})
            return {'source':'external_evidence_backfill','status':'error','rows':total_rows,'error':str(exc),'results':results}

    async def external_evidence_daemon_once(self) -> dict:
        """One bounded external evidence pass for the background daemon.

        Important design rule: this function improves the local evidence warehouse
        but must never be awaited by Forecast or by mobile page boot. It retries
        timeout-prone providers from persistent raw_metric_points checkpoints.
        """
        if not getattr(settings, 'external_backfill_enabled', True):
            return {'source':'external_evidence_daemon','status':'disabled','rows':0}
        return await self.sync_external_evidence_deep_fill(
            passes=max(1, min(3, int(getattr(settings, 'external_backfill_passes_per_sync', 3)))),
            max_feeds=max(1, min(6, int(getattr(settings, 'external_backfill_max_feeds', 6))))
        )

    async def sync_coinmetrics_metrics(self, days: int = 3000) -> dict:
        source='coinmetrics_community'
        metrics=['PriceUSD','CapMrktCurUSD','CapRealUSD','CapMVRVCur']
        try:
            rows = await self.coinmetrics.fetch_asset_metrics(metrics, days=days)
            payload=[(source, r['metric'], r['timestamp_ms'], r['value'], json.dumps({}), utc_now()) for r in rows]
            if payload:
                db.executemany("INSERT OR REPLACE INTO raw_metric_points VALUES (?, ?, ?, ?, ?, ?)", payload)
            self.health.success(source, len(payload), {"metrics": metrics})
            return {"source":source,"status":"ok","rows":len(payload)}
        except Exception as e:
            # Current free/community access can be blocked depending on network/API policy.
            # Keep this explicit but non-fatal: the engine continues using price,
            # sentiment, orderbook and futures data. A paid/on-chain API key layer
            # can be added later without changing the feature engine.
            self.health.skipped(source, f"optional on-chain endpoint unavailable: {e}", {"metrics": metrics})
            return {"source":source,"status":"skipped","rows":0,"warning":str(e)}
