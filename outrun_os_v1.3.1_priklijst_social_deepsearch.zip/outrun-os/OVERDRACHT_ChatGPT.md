# Overdracht — Outrun OS v1.3.1 Priklijst + Social Deep Search

## Context

Outrun OS is de standalone acquisition intelligence tool voor Outrun IQ. Het doel is niet massaal automatisch mailen, maar goedkoop bedrijven verzamelen, vervolgens handmatig kiezen welke bedrijven een diep onderzoek verdienen, en daarna pas AI gebruiken voor mailkwaliteit.

## Belangrijkste ontwerpbeslissing

De gebruiker wil niet dat de tool 24/7 scant en API-kosten maakt. De juiste workflow is:

1. Priklijst/discovery vult een lijst met potentiële bedrijven.
2. De gebruiker filtert op sector, grootte en status.
3. De gebruiker kiest handmatig per bedrijf: Deep Search.
4. Deep Search verzamelt bewijs van website en gevonden socialprofielen zonder betaalde LLM.
5. AI wordt pas gebruikt voor eerste mail, follow-up of echte reply-analyse.

## Nieuwe functies in v1.3.1

### 1. Priklijst-logica

Dashboard noemt discovery nu “Priklijst”. Bedrijven worden eerst verzameld en blijven goedkoop in de lijst staan. Er is een knop “＋ priklijst aanvullen”.

### 2. Handmatige Deep Search

Deep Search blijft per lead handmatig. De knop staat in de lead-detail. De crawl gebruikt geen DeepSeek/OpenAI.

### 3. Social media discovery

Tijdens deep search worden externe links naar Instagram, Facebook, LinkedIn, TikTok, YouTube, X/Twitter vanaf de bedrijfswebsite herkend en opgeslagen. Er wordt geprobeerd enkele publieke socialprofielpagina’s op te halen, maar als social platforms blokkeren is dat geen fout: de profiel-URL blijft als bewijsdoel opgeslagen.

### 4. Groottefilter

Leads krijgen size_bucket:

- klein: 1–10 medewerkers
- middel: 11–50
- groot: 51–250
- enterprise: 250+
- onbekend

De UI heeft filters voor deze groepen. Zo kan de gebruiker klein beginnen, maar grotere bedrijven blijven vindbaar en gegroepeerd.

### 5. UX-fixes

- Categoriechips overlappen niet meer op iPhone.
- Filters gebruiken flex-wrap in plaats van rommelige horizontale container.
- Lead-detail heeft een duidelijke terugknop “← Terug naar priklijst”.
- Actieknoppen wrappen netjes op mobiel.

### 6. Evidence output

Deep crawl schrijft evidence rows weg met source `deep crawl` en `social deep crawl`. Hierdoor kan de detailpagina tonen welke bron bij welk signaal hoort. Afwezigheid wordt nooit als feit behandeld; `not_found` betekent alleen “niet gevonden in deze crawl”.

## Wat nog niet af is

- Echte KvK API-integratie is nog niet live; huidige basis gebruikt seed/demo-data. De architectuur heeft wel KvK, size en source velden.
- Social media deep search is voorlopig publieke fetch/discovery, geen betaalde API of login.
- Mailkwaliteit moet in volgende build verbeterd worden met volledige Outrun IQ-uitleg, officiële branding, Stijn Rutte-signature en strictere evidence-based prompts.
- AI mag in volgende build alleen op expliciete user action of echte reply/follow-up timing draaien.

## Termius / VPS

ZIP uploaden naar GitHub root van `vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile` en dan de exacte raw URL in de update-regel gebruiken. Nooit placeholder-URL meesturen.

Bestandsnaam van deze build:
`outrun_os_v1.3.1_priklijst_social_deepsearch.zip`
