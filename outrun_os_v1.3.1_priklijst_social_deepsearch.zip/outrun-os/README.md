# Outrun OS v1.3.1 — Priklijst + Social Deep Search

Standalone acquisition cockpit voor Outrun IQ.

## Nieuw in v1.3.1

- Priklijst-aanpak: bedrijven verzamelen blijft goedkoop; deep search gebeurt alleen handmatig per lead.
- Geen automatische AI-kosten: worker staat standaard uit, deep search gebruikt geen DeepSeek/OpenAI.
- Deep search zoekt nu naast de website ook gevonden social-media profielen vanaf de bedrijfswebsite.
- Groottefilter toegevoegd: klein, middel, groot, enterprise en onbekend.
- Grotere bedrijven blijven vindbaar, maar staan apart filterbaar.
- UX-fix voor overlappende categoriechips op iPhone.
- Lead-detail heeft nu een duidelijke terugknop: “← Terug naar priklijst”.
- Deep crawl schrijft crawl-derived evidence weg met bron-URL’s.

## Belangrijk kostenprincipe

Outrun OS mag niet 24/7 dure API’s gebruiken. De standaardmodus is:

1. Discovery/priklijst: goedkoop, geen AI.
2. Deep search: alleen na jouw klik, website/social fetches, geen LLM.
3. Mail schrijven: pas na jouw actie, gebruikt AI.
4. Follow-up/reply: pas bij echte timing of reactie.

## Start lokaal

```bash
python3 -m venv .venv
./.venv/bin/pip install -r requirements.txt
./.venv/bin/python run.py
```

Open: `http://127.0.0.1:8700/`

## VPS

Service blijft `outrun-os` en poort blijft standaard `8700`.
