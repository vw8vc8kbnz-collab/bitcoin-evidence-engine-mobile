"""
FastAPI surface. Read endpoints for the dashboard, action endpoints for approval,
and manual pipeline triggers (handy in test mode). The frontend is a single
static file served from /.

Note: there is deliberately NO endpoint to disable test mode. Going live is an
env-var + restart, never a browser click.
"""
import os
import time
import json
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import db, config, worker
from .pipeline import discovery, scan, scoring, outreach, replies, followup, deep_crawl
from .services import mailer

app = FastAPI(title="Outrun OS", version="1.0")

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "web")


@app.on_event("startup")
def _startup():
    db.init_db()
    worker.start()


@app.on_event("shutdown")
def _shutdown():
    worker.stop()


# ---------- config / stats ----------
@app.get("/api/config")
def get_config():
    return config.status_summary()


@app.get("/api/stats")
def get_stats():
    with db.get_conn() as c:
        def n(q, *a):
            return c.execute(q, a).fetchone()[0]
        discovered = n("SELECT COUNT(*) FROM companies WHERE tenant_id=?", config.TENANT)
        scanned = n("SELECT COUNT(*) FROM companies WHERE tenant_id=? AND stage NOT IN('discovered')", config.TENANT)
        scored = n("SELECT COUNT(*) FROM scores WHERE tenant_id=?", config.TENANT)
        queue = n("SELECT COUNT(*) FROM drafts WHERE tenant_id=? AND status='awaiting'", config.TENANT)
        crawled = n("SELECT COUNT(DISTINCT company_id) FROM crawl_runs WHERE tenant_id=?", config.TENANT)
        today = time.time() - 86400
        disc_today = n("SELECT COUNT(*) FROM companies WHERE tenant_id=? AND created_at>=?", config.TENANT, today)
    return {"discovered": discovered, "scanned": scanned, "scored": scored,
            "queue": queue, "deep_crawled": crawled, "discovered_today": disc_today}


# ---------- leads ----------
def _size_bucket(size):
    try:
        n = int(size or 0)
    except Exception:
        return "onbekend"
    if n <= 0:
        return "onbekend"
    if n <= 10:
        return "klein"
    if n <= 50:
        return "middel"
    if n <= 250:
        return "groot"
    return "enterprise"


def _lead_summary(company):
    s = scoring.latest_score(company["id"])
    draft = outreach.latest_draft(company["id"])
    with db.get_conn() as c:
        reply = c.execute("SELECT intent FROM replies WHERE company_id=? AND tenant_id=? ORDER BY created_at DESC LIMIT 1",
                          (company["id"], config.TENANT)).fetchone()
    status = _derive_status(company, draft, reply)
    with db.get_conn() as c:
        cr = c.execute("SELECT pages_crawled FROM crawl_runs WHERE company_id=? AND tenant_id=? ORDER BY created_at DESC LIMIT 1",
                       (company["id"], config.TENANT)).fetchone()
    return {
        "id": company["id"], "name": company["name"], "kvk": company["kvk"],
        "city": company["city"], "sector": company["sector"], "stage": company["stage"],
        "size": company.get("size"), "size_bucket": _size_bucket(company.get("size")),
        "fit": s["fit"] if s else None,
        "timing": s["timing"] if s else None,
        "priority": s["priority"] if s else None,
        "confidence": s["confidence"] if s else None,
        "status": status,
        "reply_intent": reply["intent"] if reply else None,
        "days": _days_since_signal(company["id"]),
        "crawl_pages": cr["pages_crawled"] if cr else None,
        "deep_searched": bool(cr),
    }


def _days_since_signal(company_id):
    with db.get_conn() as c:
        r = c.execute("SELECT MAX(observed_at) m FROM evidence WHERE company_id=? AND tenant_id=? AND axis='timing'",
                      (company_id, config.TENANT)).fetchone()
    if not r or not r["m"]:
        return None
    return int((time.time() - r["m"]) / 86400)


def _derive_status(company, draft, reply):
    if reply:
        return {"HOT": "REPLIED_HOT", "WARM": "REPLIED_WARM"}.get(reply["intent"], "REPLIED_WARM")
    if company["stage"] == "contacted":
        return "CONTACTED"
    if company["stage"] == "nurture":
        return "NURTURE"
    if draft and draft["status"] == "awaiting":
        return "AWAITING_APPROVAL"
    if draft and draft["status"] == "approved":
        return "CONTACTED"
    if company["stage"] == "scored":
        return "SCORED"
    if company["stage"] == "scanned":
        return "SCANNED"
    return "NEW"


@app.get("/api/leads")
def list_leads():
    with db.get_conn() as c:
        rows = c.execute("SELECT * FROM companies WHERE tenant_id=? ORDER BY created_at DESC", (config.TENANT,)).fetchall()
    leads = [_lead_summary(dict(r)) for r in rows]
    # sort by combined score desc, unscored last
    leads.sort(key=lambda l: ((l["fit"] or 0) + (l["timing"] or 0)), reverse=True)
    return {"leads": leads, "config": config.status_summary()}


@app.get("/api/lead/{cid}")
def get_lead(cid: int):
    with db.get_conn() as c:
        row = c.execute("SELECT * FROM companies WHERE id=? AND tenant_id=?", (cid, config.TENANT)).fetchone()
        if not row:
            raise HTTPException(404, "onbekende lead")
        evidence = [dict(e) for e in c.execute(
            "SELECT axis,label,detail,source,source_url,observed_at FROM evidence WHERE company_id=? AND tenant_id=? ORDER BY observed_at",
            (cid, config.TENANT)).fetchall()]
        events = [dict(e) for e in c.execute(
            "SELECT kind,payload_json,created_at FROM events WHERE company_id=? AND tenant_id=? ORDER BY created_at DESC LIMIT 30",
            (cid, config.TENANT)).fetchall()]
    company = dict(row)
    s = scoring.latest_score(cid)
    draft = outreach.latest_draft(cid)
    if s and s.get("deepseek_json"):
        try:
            s["deepseek"] = json.loads(s["deepseek_json"])
        except Exception:
            s["deepseek"] = None
    if s and s.get("gpt_json"):
        try:
            s["gpt"] = json.loads(s["gpt_json"])
        except Exception:
            s["gpt"] = None
    crawl = deep_crawl.latest_crawl(cid)
    return {"company": company, "score": s, "evidence": evidence, "draft": draft,
            "events": events, "crawl": crawl, "summary": _lead_summary(company)}


# ---------- actions ----------
class DraftEdit(BaseModel):
    subject: str | None = None
    body: str | None = None


@app.post("/api/lead/{cid}/approve")
def approve(cid: int, edit: DraftEdit | None = None):
    draft = outreach.latest_draft(cid)
    if not draft:
        raise HTTPException(400, "geen concept om goed te keuren")
    subject = (edit.subject if edit and edit.subject else draft["subject"])
    body = (edit.body if edit and edit.body else draft["body"])
    with db.get_conn() as c:
        c.execute("UPDATE drafts SET status='approved', subject=?, body=?, decided_at=? WHERE id=?",
                  (subject, body, time.time(), draft["id"]))
        c.execute("UPDATE companies SET stage='contacted' WHERE id=?", (cid,))
    result = mailer.send(cid, subject, body)          # test mode -> outbox
    followup.schedule(cid)
    return {"ok": True, "delivery": result, "test_mode": config.TEST_MODE}


@app.post("/api/lead/{cid}/reject")
def reject(cid: int):
    draft = outreach.latest_draft(cid)
    if draft:
        with db.get_conn() as c:
            c.execute("UPDATE drafts SET status='rejected', decided_at=? WHERE id=?", (time.time(), draft["id"]))
            c.execute("UPDATE companies SET stage='nurture' WHERE id=?", (cid,))
    return {"ok": True}


@app.post("/api/lead/{cid}/regenerate")
def regenerate(cid: int):
    return outreach.generate_draft(cid) or {"ok": False}




class CrawlRequest(BaseModel):
    max_pages: int | None = None
    max_depth: int | None = None


@app.post("/api/lead/{cid}/deep-crawl")
def run_deep_crawl(cid: int, req: CrawlRequest | None = None):
    try:
        res = deep_crawl.deep_crawl_company(
            cid,
            max_pages=req.max_pages if req else None,
            max_depth=req.max_depth if req else None,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not res:
        raise HTTPException(404, "onbekende lead")
    return {"ok": True, **res}


@app.get("/api/lead/{cid}/deep-crawl")
def get_deep_crawl(cid: int):
    res = deep_crawl.latest_crawl(cid)
    if not res:
        return {"ok": False, "crawl": None}
    return {"ok": True, "crawl": res}


# ---------- outbox / replies (test loop visibility) ----------
@app.get("/api/outbox")
def outbox():
    with db.get_conn() as c:
        rows = c.execute("""SELECT m.*, c.name FROM messages m JOIN companies c ON c.id=m.company_id
                            WHERE m.tenant_id=? AND m.direction='out' ORDER BY m.created_at DESC LIMIT 100""",
                         (config.TENANT,)).fetchall()
    return {"messages": [dict(r) for r in rows]}


@app.post("/api/lead/{cid}/simulate-reply")
def simulate_reply(cid: int):
    if not config.TEST_MODE:
        raise HTTPException(400, "alleen in testmodus")
    res = replies.synthesize_reply(cid)
    if res and res["intent"] != "NO":
        followup.cancel_for(cid)
    return {"ok": True, "reply": res}


# ---------- manual pipeline triggers ----------
@app.post("/api/pipeline/discover")
def trigger_discover():
    return {"added": discovery.run_discovery()}


@app.post("/api/pipeline/tick")
def trigger_tick():
    return {"did": worker.tick()}


# ---------- static frontend ----------
@app.get("/")
def index():
    return FileResponse(
        os.path.join(WEB_DIR, "index.html"),
        headers={"Cache-Control": "no-store, no-cache, must-revalidate", "Pragma": "no-cache"},
    )


if os.path.isdir(WEB_DIR):
    app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")
