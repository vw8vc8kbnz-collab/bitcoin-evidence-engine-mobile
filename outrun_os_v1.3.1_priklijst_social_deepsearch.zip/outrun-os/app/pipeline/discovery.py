"""
MODULE 1 - Discovery Engine.

Finds candidate companies. Dedup is on KvK number (canonical key) so the same
firm found via multiple sources becomes one record.

Sources are pluggable:
  - TEST source: seeds realistic Dutch outlet candidates (default, no keys).
  - SEARCH source: a real search API (SerpAPI-compatible) on signal queries
    ("outlet", "op=op", "showroommodellen", "restpartij"). Off unless you set
    SERPAPI_KEY. Deliberately NOT scraping LinkedIn (ban + legal risk).
"""
import time
from .. import db, config
from ..services.seed import SEED_COMPANIES

SIGNAL_QUERIES = [
    "outlet", "op=op", "showroommodellen uitverkoop", "b-keuze",
    "overstock", "restpartij", "retouren", "clearance",
]


def _insert_company(c, comp, source):
    cur = c.execute(
        "SELECT id FROM companies WHERE tenant_id=? AND kvk=?",
        (config.TENANT, comp.get("kvk")),
    )
    row = cur.fetchone()
    if row:
        return row["id"], False   # dedup hit
    cur = c.execute(
        """INSERT INTO companies(tenant_id, kvk, name, city, sector, website, size, source, stage, created_at)
           VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (config.TENANT, comp.get("kvk"), comp["name"], comp.get("city"), comp.get("sector"),
         comp.get("website"), comp.get("size"), source, "discovered", time.time()),
    )
    return cur.lastrowid, True


def discover_test(limit=3):
    """Pull a few not-yet-known seed companies into the pipeline."""
    added = []
    with db.get_conn() as c:
        existing = {r["kvk"] for r in c.execute(
            "SELECT kvk FROM companies WHERE tenant_id=?", (config.TENANT,))}
        for comp in SEED_COMPANIES:
            if comp["kvk"] in existing:
                continue
            cid, is_new = _insert_company(c, comp, "test-seed")
            if is_new:
                added.append({"id": cid, "name": comp["name"]})
            if len(added) >= limit:
                break
    for a in added:
        db.log_event(a["id"], "discovered", {"name": a["name"], "source": "test-seed"})
    return added


def discover_search():
    """Real discovery via a search API. Returns [] unless SERPAPI_KEY is set."""
    if not config.SERPAPI_KEY:
        return []
    # Interface stub: wire SerpAPI/Bing here, run SIGNAL_QUERIES, parse business
    # results, resolve KvK via the KvK API, then _insert_company(...).
    # Kept intentionally empty so live discovery is an explicit, deliberate step.
    return []


def run_discovery():
    if config.TEST_MODE:
        return discover_test()
    return discover_search()
