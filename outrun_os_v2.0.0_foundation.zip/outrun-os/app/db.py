"""
SQLite persistence. WAL mode, one connection per operation (safe with WAL and
a single-worker uvicorn). Multi-tenant from day one via tenant_id on every row,
so the tool can serve other companies later without a rewrite.
"""
import sqlite3
import json
import time
from contextlib import contextmanager
from . import config


def _connect():
    conn = sqlite3.connect(config.DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.execute("PRAGMA busy_timeout=5000;")
    return conn


@contextmanager
def get_conn():
    conn = _connect()
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS companies(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id TEXT NOT NULL,
  kvk TEXT,
  name TEXT NOT NULL,
  city TEXT,
  sector TEXT,
  website TEXT,
  size INTEGER,
  source TEXT,
  active_status TEXT DEFAULT 'unknown', -- unknown|active|inactive|low_confidence
  relevance_status TEXT DEFAULT 'unreviewed', -- unreviewed|candidate|irrelevant
  company_type TEXT DEFAULT 'unknown', -- small|medium|large|enterprise|unknown
  last_basic_check REAL,
  stage TEXT DEFAULT 'discovered',   -- discovered|deep_crawled|scanned|scored|drafted|contacted|replied|nurture
  created_at REAL,
  UNIQUE(tenant_id, kvk)
);


CREATE TABLE IF NOT EXISTS crawl_runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tenant_id TEXT NOT NULL,
  start_url TEXT,
  status TEXT,
  pages_crawled INTEGER DEFAULT 0,
  summary_json TEXT,
  created_at REAL
);

CREATE TABLE IF NOT EXISTS crawl_pages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tenant_id TEXT NOT NULL,
  run_id INTEGER REFERENCES crawl_runs(id) ON DELETE CASCADE,
  url TEXT,
  title TEXT,
  page_type TEXT,
  status_code INTEGER,
  signals_json TEXT,
  text_excerpt TEXT,
  content_hash TEXT,
  fetched_at REAL
);

CREATE TABLE IF NOT EXISTS scans(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tenant_id TEXT NOT NULL,
  features_json TEXT,
  summary TEXT,
  created_at REAL
);

CREATE TABLE IF NOT EXISTS evidence(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tenant_id TEXT NOT NULL,
  axis TEXT,                 -- fit|timing
  label TEXT,
  detail TEXT,
  source TEXT,
  source_url TEXT,
  observed_at REAL
);

CREATE TABLE IF NOT EXISTS scores(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tenant_id TEXT NOT NULL,
  fit INTEGER,
  timing_base INTEGER,           -- timing at observation time
  timing_observed_at REAL,       -- used to decay timing over time
  priority TEXT,
  confidence TEXT,               -- aligned|review|flag
  deepseek_json TEXT,
  gpt_json TEXT,
  created_at REAL
);

CREATE TABLE IF NOT EXISTS drafts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tenant_id TEXT NOT NULL,
  subject TEXT,
  body TEXT,
  status TEXT DEFAULT 'awaiting',  -- awaiting|approved|rejected|edited
  verifier_json TEXT,
  created_at REAL,
  decided_at REAL
);

CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tenant_id TEXT NOT NULL,
  direction TEXT,               -- out|in
  channel TEXT DEFAULT 'email',
  subject TEXT,
  body TEXT,
  status TEXT,                  -- outbox|sent|received
  is_synthetic INTEGER DEFAULT 0,
  created_at REAL
);

CREATE TABLE IF NOT EXISTS replies(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  message_id INTEGER,
  tenant_id TEXT NOT NULL,
  body TEXT,
  intent TEXT,                  -- HOT|WARM|QUESTION|NOT_NOW|NO
  summary TEXT,
  is_synthetic INTEGER DEFAULT 0,
  created_at REAL
);

CREATE TABLE IF NOT EXISTS followups(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tenant_id TEXT NOT NULL,
  step INTEGER,                 -- 1,2,3 => day 4/10/21
  due_at REAL,
  status TEXT DEFAULT 'scheduled',  -- scheduled|done|cancelled
  created_at REAL
);

CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id TEXT NOT NULL,
  company_id INTEGER,
  kind TEXT,
  payload_json TEXT,
  created_at REAL
);


CREATE TABLE IF NOT EXISTS jobs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  target_id INTEGER,
  status TEXT NOT NULL DEFAULT 'queued',
  title TEXT,
  message TEXT,
  current INTEGER DEFAULT 0,
  total INTEGER DEFAULT 0,
  percent REAL DEFAULT 0,
  eta_seconds INTEGER,
  started_at REAL,
  updated_at REAL,
  finished_at REAL,
  result_json TEXT,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_jobs_tenant_status ON jobs(tenant_id,status,updated_at);

CREATE INDEX IF NOT EXISTS idx_companies_tenant ON companies(tenant_id, stage);
CREATE INDEX IF NOT EXISTS idx_scores_company ON scores(company_id);
CREATE INDEX IF NOT EXISTS idx_evidence_company ON evidence(company_id);
CREATE INDEX IF NOT EXISTS idx_crawl_runs_company ON crawl_runs(company_id);
CREATE INDEX IF NOT EXISTS idx_crawl_pages_company ON crawl_pages(company_id);
"""



def _ensure_column(conn, table, column, ddl):
    cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
    if column not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")


def init_db():
    with get_conn() as c:
        c.executescript(SCHEMA)
        # Safe migrations for existing VPS databases. These keep the local
        # company/KvK master across ZIP updates.
        _ensure_column(c, "companies", "active_status", "active_status TEXT DEFAULT 'unknown'")
        _ensure_column(c, "companies", "relevance_status", "relevance_status TEXT DEFAULT 'unreviewed'")
        _ensure_column(c, "companies", "company_type", "company_type TEXT DEFAULT 'unknown'")
        _ensure_column(c, "companies", "last_basic_check", "last_basic_check REAL")


def log_event(company_id, kind, payload=None):
    with get_conn() as c:
        c.execute(
            "INSERT INTO events(tenant_id, company_id, kind, payload_json, created_at) VALUES(?,?,?,?,?)",
            (config.TENANT, company_id, kind, json.dumps(payload or {}), time.time()),
        )


def rows_to_dicts(rows):
    return [dict(r) for r in rows]
