"""
MODULE 3+4 - AI Brain + Lead Scoring (two axes).

FIT (structural, stable) and TIMING (event-driven, decays over time).

Dual-LLM, the smart way (not ensemble-on-everything):
  1. DeepSeek scores everything (cheap analyst) -> fit, timing, reasons.
  2. For Priority-A leads only, GPT second-guesses the score (expensive judge).
     agreement  -> confidence "aligned" (trust the pipeline)
     disagreement -> confidence "review" (escalate to the founder)

Confidence-as-disagreement: where the two models diverge is exactly where a
human should look. That is a free uncertainty signal, not extra noise.
"""
import time
import json
import math
from .. import db, config
from ..llm.base import LLMTask
from ..llm import router

FIT_THRESHOLD = 78
TIMING_THRESHOLD = 75


def timing_now(base, observed_at):
    """Decay timing with a half-life. A hot signal cools if not acted on."""
    if base is None or observed_at is None:
        return base or 0
    days = max(0.0, (time.time() - observed_at) / 86400.0)
    decayed = base * (0.5 ** (days / config.TIMING_HALFLIFE_DAYS))
    return int(max(0, min(base, round(decayed))))


def _priority(fit, timing):
    if fit >= FIT_THRESHOLD and timing >= TIMING_THRESHOLD:
        return "A"
    if (fit + timing) / 2 >= 62:
        return "B"
    return "C"


def _load_evidence(company_id):
    with db.get_conn() as c:
        rows = c.execute("SELECT axis,label,detail,source,observed_at FROM evidence WHERE company_id=? AND tenant_id=?",
                         (company_id, config.TENANT)).fetchall()
    return [dict(r) for r in rows]


def score_company(company_id):
    with db.get_conn() as c:
        row = c.execute("SELECT * FROM companies WHERE id=? AND tenant_id=?",
                        (company_id, config.TENANT)).fetchone()
        if not row:
            return None
        company = dict(row)
    evidence = _load_evidence(company_id)

    ev_text = "\n".join(f"- [{e['axis']}] {e['label']}: {e['detail']} (bron: {e['source']})" for e in evidence)

    # 1) DeepSeek scores (cheap analyst)
    ds_task = LLMTask(
        name="score",
        system=("Je bent een acquisitie-analist voor een outletmarktplaats. Scoor het bedrijf op twee assen: "
                "FIT (0-100, structureel: past assortiment/prijstier/rest-stroom) en TIMING (0-100, hoe vers en "
                "sterk het huidige uitverkoop-/voorraadsignaal is). Baseer je uitsluitend op het gegeven bewijs. "
                "Antwoord in JSON: {fit:int, timing:int, fit_reasons:[..], timing_reasons:[..], priority_reason:str}."),
        user=f"Bedrijf: {company['name']} ({company.get('sector')}, {company.get('city')}).\nBewijs:\n{ev_text}",
        prefer_cheap=True,
    )
    ds = router.run(ds_task)
    dsj = ds.get("json") or {}
    fit = int(dsj.get("fit", 65))
    timing = int(dsj.get("timing", 55))
    priority = _priority(fit, timing)

    # 2) GPT verifies the score, but only for the expensive A decisions
    confidence = "aligned"
    gptj = None
    if priority == "A":
        vt = LLMTask(
            name="verify_score",
            system=("Je bent een senior reviewer. Een junior model gaf deze fit/timing-score op basis van het bewijs. "
                    "Ben je het eens? Let vooral op of het timingsignaal echt vers is. "
                    "JSON: {agree:bool, adjusted_fit:int|null, adjusted_timing:int|null, note:str}."),
            user=f"Bewijs:\n{ev_text}\n\nScore junior: fit={fit}, timing={timing}.\nRationale: {json.dumps(dsj, ensure_ascii=False)}",
            prefer_quality=True, prefer_cheap=False,
        )
        gv = router.run(vt)
        gptj = gv.get("json") or {}
        if gptj.get("agree") is False:
            confidence = "review"
            if isinstance(gptj.get("adjusted_timing"), int):
                timing = gptj["adjusted_timing"]
                priority = _priority(fit, timing)
    elif len([e for e in evidence if e["axis"] == "fit"]) <= 1:
        confidence = "flag"   # thin evidence -> low confidence

    now = time.time()
    with db.get_conn() as c:
        c.execute("""INSERT INTO scores(company_id, tenant_id, fit, timing_base, timing_observed_at,
                     priority, confidence, deepseek_json, gpt_json, created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",
                  (company_id, config.TENANT, fit, timing, now, priority, confidence,
                   json.dumps(dsj, ensure_ascii=False),
                   json.dumps(gptj, ensure_ascii=False) if gptj is not None else None, now))
        c.execute("UPDATE companies SET stage='scored' WHERE id=?", (company_id,))
    db.log_event(company_id, "scored", {"fit": fit, "timing": timing, "priority": priority, "confidence": confidence,
                                        "deepseek": ds.get("provider"), "gpt": (gptj is not None)})
    return {"fit": fit, "timing": timing, "priority": priority, "confidence": confidence}


def latest_score(company_id):
    with db.get_conn() as c:
        r = c.execute("SELECT * FROM scores WHERE company_id=? AND tenant_id=? ORDER BY created_at DESC LIMIT 1",
                      (company_id, config.TENANT)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["timing"] = timing_now(d["timing_base"], d["timing_observed_at"])
    d["priority"] = _priority(d["fit"], d["timing"])
    return d
