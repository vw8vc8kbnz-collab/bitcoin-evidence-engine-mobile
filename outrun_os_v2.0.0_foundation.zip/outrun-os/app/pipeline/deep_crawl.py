"""
Outrun OS Evidence Engine - Step 1: Deep Crawl.

Cost principle: this module uses ZERO paid AI/API calls. It only fetches the
company website, follows same-domain links, extracts hard evidence signals, and
stores raw page metadata locally. Later steps can use this stored crawl as input
for evidence extraction and outreach, without repeatedly spending API budget.

Truth-first principle: this module stores observations as observations. It does
not claim that a company has overstock, returns, showroom stock, or no outlet
unless a scanned page gives evidence for it. Missing evidence is stored as
"not_found" in the crawl report, never as a business fact in outreach.
"""
from __future__ import annotations

import hashlib
import html
import json
import re
import time
from dataclasses import dataclass
from html.parser import HTMLParser
from typing import Iterable
from urllib.parse import urljoin, urlparse, urldefrag

import httpx

from .. import config, db

SIGNAL_PATTERNS = {
    "sale": [r"\bsale\b", r"aanbieding", r"korting", r"actieprijs", r"uitverkoop", r"leegverkoop", r"clearance", r"op\s*=\s*op", r"op is op"],
    "outlet": [r"\boutlet\b", r"magazijnoutlet", r"warehouse outlet"],
    "showroom": [r"showroommodel", r"showroom modellen", r"showroom\s*sale", r"ex[-\s]?showroom"],
    "returns_bstock": [r"retour", r"b[-\s]?keuze", r"tweede\s*kans", r"lichte\s*schade", r"transportschade", r"refurbished"],
    "restpartij": [r"restpartij", r"restvoorraad", r"overstock", r"partijverkoop", r"uitlopende\s*serie", r"einde\s*serie"],
    "contact": [r"contact", r"klantenservice", r"over ons", r"vestiging", r"showroom"],
}

PRIORITY_PATH_HINTS = (
    "sale", "outlet", "aanbied", "korting", "actie", "op-op", "opisop",
    "showroom", "retour", "b-keuze", "tweede-kans", "restpartij", "restvoorraad",
    "clearance", "magazijn", "uitverkoop", "leegverkoop", "contact", "over-ons",
    "faq", "klantenservice", "sitemap"
)

SKIP_EXT = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".pdf", ".zip", ".rar", ".mp4", ".mov", ".avi", ".css", ".js", ".ico", ".woff", ".woff2", ".ttf")

SOCIAL_DOMAINS = {
    "instagram.com": "Instagram",
    "facebook.com": "Facebook",
    "linkedin.com": "LinkedIn",
    "tiktok.com": "TikTok",
    "youtube.com": "YouTube",
    "x.com": "X",
    "twitter.com": "X",
}


class _PageParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title_parts: list[str] = []
        self.text_parts: list[str] = []
        self.links: list[str] = []
        self.meta_desc = ""
        self._tag_stack: list[str] = []
        self._ignore = False

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        self._tag_stack.append(tag)
        if tag in {"script", "style", "noscript", "svg"}:
            self._ignore = True
        attrs_d = {k.lower(): (v or "") for k, v in attrs}
        if tag == "a" and attrs_d.get("href"):
            self.links.append(attrs_d["href"])
        if tag == "meta":
            name = attrs_d.get("name", "").lower()
            prop = attrs_d.get("property", "").lower()
            if name == "description" or prop == "og:description":
                self.meta_desc = attrs_d.get("content", "")[:500]

    def handle_endtag(self, tag):
        tag = tag.lower()
        if self._tag_stack:
            try:
                self._tag_stack.pop()
            except Exception:
                pass
        if tag in {"script", "style", "noscript", "svg"}:
            self._ignore = False

    def handle_data(self, data):
        if self._ignore:
            return
        data = " ".join((data or "").split())
        if not data:
            return
        if self._tag_stack and self._tag_stack[-1] == "title":
            self.title_parts.append(data)
        else:
            self.text_parts.append(data)


def _normalise_url(raw: str) -> str:
    raw = (raw or "").strip()
    if not raw:
        return ""
    if not raw.startswith(("http://", "https://")):
        raw = "https://" + raw
    raw, _ = urldefrag(raw)
    return raw.rstrip("/")


def _same_domain(url: str, root_host: str) -> bool:
    host = urlparse(url).netloc.lower().removeprefix("www.")
    root = root_host.lower().removeprefix("www.")
    return host == root or host.endswith("." + root)


def _clean_text(t: str, limit: int = 5000) -> str:
    t = html.unescape(t or "")
    t = re.sub(r"\s+", " ", t).strip()
    return t[:limit]


def _extract_page(url: str, raw_html: str) -> dict:
    p = _PageParser()
    try:
        p.feed(raw_html or "")
    except Exception:
        pass
    title = _clean_text(" ".join(p.title_parts), 250)
    text = _clean_text(" ".join(p.text_parts), 8000)
    meta_desc = _clean_text(p.meta_desc, 500)
    lower = (title + " " + meta_desc + " " + text).lower()
    signals = {}
    for bucket, patterns in SIGNAL_PATTERNS.items():
        hits = []
        for pat in patterns:
            if re.search(pat, lower, flags=re.I):
                hits.append(pat)
        if hits:
            signals[bucket] = hits[:8]
    discounts = sorted(set(re.findall(r"(?:-|tot\s*)?\b([1-9][0-9])\s*%", lower)))[:12]
    prices = re.findall(r"€\s?\d+[\d\.,]*", text)[:25]
    return {
        "url": url,
        "title": title,
        "meta_description": meta_desc,
        "text_excerpt": text[:1600],
        "text_length": len(text),
        "links": p.links[:300],
        "signals": signals,
        "discount_percentages": discounts,
        "price_examples": prices,
        "content_hash": hashlib.sha256((title + meta_desc + text[:5000]).encode("utf-8", "ignore")).hexdigest(),
    }


def _score_url_for_queue(url: str) -> int:
    path = (urlparse(url).path or "").lower()
    score = 0
    for h in PRIORITY_PATH_HINTS:
        if h in path:
            score += 20
    depth = len([p for p in path.split("/") if p])
    score -= depth * 2
    return score


def _social_platform(url: str) -> str | None:
    host = urlparse(url).netloc.lower().removeprefix("www.")
    for domain, name in SOCIAL_DOMAINS.items():
        if host == domain or host.endswith("." + domain):
            return name
    return None


def _normalise_external_url(base_url: str, href: str) -> str | None:
    href = (href or "").strip()
    if not href or href.startswith(("mailto:", "tel:", "javascript:", "#")):
        return None
    u = urljoin(base_url, href)
    u, _ = urldefrag(u)
    parsed = urlparse(u)
    if parsed.scheme not in {"http", "https"}:
        return None
    if parsed.path.lower().endswith(SKIP_EXT):
        return None
    return u.rstrip("/")


def _safe_link(base_url: str, href: str, root_host: str) -> str | None:
    href = (href or "").strip()
    if not href or href.startswith(("mailto:", "tel:", "javascript:", "#")):
        return None
    u = urljoin(base_url, href)
    u, _ = urldefrag(u)
    parsed = urlparse(u)
    if parsed.scheme not in {"http", "https"}:
        return None
    if not _same_domain(u, root_host):
        return None
    if parsed.path.lower().endswith(SKIP_EXT):
        return None
    return u.rstrip("/")


def _page_type(url: str, signals: dict) -> str:
    path = (urlparse(url).path or "/").lower()
    blob = path + " " + " ".join(signals.keys())
    if any(x in blob for x in ["outlet", "clearance"]):
        return "outlet"
    if any(x in blob for x in ["sale", "aanbied", "korting", "actie", "uitverkoop", "op-op"]):
        return "sale"
    if any(x in blob for x in ["showroom", "ex-showroom"]):
        return "showroom"
    if any(x in blob for x in ["retour", "b-keuze", "tweede-kans", "refurbished"]):
        return "returns_bstock"
    if any(x in blob for x in ["contact", "over-ons", "klantenservice", "faq"]):
        return "company_info"
    if path in ("", "/"):
        return "homepage"
    return "other"


def _summarise(pages: list[dict]) -> dict:
    buckets = {k: 0 for k in ["sale", "outlet", "showroom", "returns_bstock", "restpartij", "contact"]}
    page_types = {}
    strongest_pages = []
    discounts = set()
    for p in pages:
        sig = p.get("signals") or {}
        for k in buckets:
            if k in sig:
                buckets[k] += 1
        pt = p.get("page_type") or "other"
        page_types[pt] = page_types.get(pt, 0) + 1
        for d in p.get("discount_percentages") or []:
            discounts.add(int(d))
        strength = len(sig) * 10 + len(p.get("discount_percentages") or [])
        if strength:
            strongest_pages.append({"url": p["url"], "title": p.get("title"), "page_type": pt, "signals": list(sig.keys()), "strength": strength})
    strongest_pages.sort(key=lambda x: x["strength"], reverse=True)
    social_profiles = []
    seen_social = set()
    for p in pages:
        for item in p.get("social_profiles") or []:
            key = (item.get("platform"), item.get("url"))
            if key in seen_social:
                continue
            seen_social.add(key)
            social_profiles.append(item)
    return {
        "pages_crawled": len(pages),
        "signal_page_counts": buckets,
        "page_type_counts": page_types,
        "discounts_found": sorted(discounts),
        "strongest_pages": strongest_pages[:12],
        "social_profiles": social_profiles[:20],
        "social_profiles_found": len(social_profiles),
        "not_found": [k for k, v in buckets.items() if v == 0],
        "truth_policy": "Alleen gevonden pagina's/signalen zijn bewijs. not_found betekent: niet gevonden in deze crawl, niet dat het absoluut niet bestaat.",
    }


def deep_crawl_company(company_id: int, max_pages: int | None = None, max_depth: int | None = None, progress_callback=None) -> dict | None:
    max_pages = max_pages or int(getattr(config, "CRAWL_MAX_PAGES", 80))
    max_depth = max_depth or int(getattr(config, "CRAWL_MAX_DEPTH", 2))
    with db.get_conn() as c:
        row = c.execute("SELECT * FROM companies WHERE id=? AND tenant_id=?", (company_id, config.TENANT)).fetchone()
        if not row:
            return None
        company = dict(row)
    start_url = _normalise_url(company.get("website") or "")
    if not start_url:
        raise ValueError("Lead heeft geen website")
    root_host = urlparse(start_url).netloc
    now = time.time()
    pages: list[dict] = []
    errors = []
    social_profiles: dict[str, dict] = {}
    queue: list[tuple[int, str]] = [(0, start_url)]
    seen = set()
    headers = {"User-Agent": "OutrunOS-EvidenceBot/1.3 (+truth-first-partner-research; contact=partnerships@outruniq.nl)"}
    if progress_callback:
        progress_callback(0, max_pages, "Deep search start: website openen")
    with httpx.Client(timeout=18, follow_redirects=True, headers=headers) as client:
        while queue and len(pages) < max_pages:
            queue.sort(key=lambda x: _score_url_for_queue(x[1]), reverse=True)
            depth, url = queue.pop(0)
            if url in seen or depth > max_depth:
                continue
            seen.add(url)
            try:
                r = client.get(url)
                ctype = r.headers.get("content-type", "").lower()
                if r.status_code >= 400 or "text/html" not in ctype:
                    errors.append({"url": url, "status": r.status_code, "content_type": ctype[:80]})
                    continue
                page = _extract_page(str(r.url).rstrip("/"), r.text)
                # Discover official social profiles from website links. We do not claim
                # anything from social media yet; we only store the profile links as
                # evidence targets for a manual deep search.
                page_social = []
                for href in page.get("links", []):
                    ext = _normalise_external_url(page["url"], href)
                    platform = _social_platform(ext or "") if ext else None
                    if platform and ext:
                        social_profiles.setdefault(ext, {"platform": platform, "url": ext, "found_on": page["url"]})
                        page_social.append({"platform": platform, "url": ext, "found_on": page["url"]})
                page["social_profiles"] = page_social[:20]
                page["status_code"] = r.status_code
                page["page_type"] = _page_type(page["url"], page.get("signals") or {})
                page["depth"] = depth
                pages.append(page)
                if progress_callback:
                    progress_callback(len(pages), max_pages, f"Websitepagina {len(pages)} / {max_pages}: {page.get('page_type') or 'pagina'}")
                for href in page.get("links", []):
                    nxt = _safe_link(page["url"], href, root_host)
                    if nxt and nxt not in seen and len(seen) + len(queue) < max_pages * 5:
                        queue.append((depth + 1, nxt))
            except Exception as e:
                errors.append({"url": url, "error": str(e)[:300]})
    # Optional, still manual only: fetch a few discovered social profile pages without AI.
    # Many social sites block bots; failures are stored as crawl errors.
    social_fetch_limit = max(0, int(getattr(config, "CRAWL_SOCIAL_MAX_PAGES", 3)))
    social_items = list(social_profiles.values())[:social_fetch_limit]
    social_total = max_pages + len(social_items)
    for idx, item in enumerate(social_items):
        try:
            with httpx.Client(timeout=12, follow_redirects=True, headers=headers) as social_client:
                r = social_client.get(item["url"])
                ctype = r.headers.get("content-type", "").lower()
                if r.status_code < 400 and "text/html" in ctype:
                    sp = _extract_page(str(r.url).rstrip("/"), r.text)
                    sp["status_code"] = r.status_code
                    sp["page_type"] = "social_profile"
                    sp["depth"] = 0
                    sp["social_profiles"] = [item]
                    pages.append(sp)
                    if progress_callback:
                        progress_callback(min(social_total, max_pages + idx + 1), social_total, f"Social check {idx + 1} / {len(social_items)}: {item.get('platform')}")
                else:
                    errors.append({"url": item["url"], "status": r.status_code, "content_type": ctype[:80], "kind": "social"})
        except Exception as e:
            errors.append({"url": item["url"], "error": str(e)[:300], "kind": "social"})

    # Ensure discovered social profiles are represented in the summary even if
    # the social page itself could not be fetched.
    if social_profiles and pages:
        pages[0].setdefault("social_profiles", [])
        existing = {(x.get("platform"), x.get("url")) for x in pages[0]["social_profiles"]}
        for item in social_profiles.values():
            if (item.get("platform"), item.get("url")) not in existing:
                pages[0]["social_profiles"].append(item)

    if progress_callback:
        progress_callback(len(pages), max(len(pages), max_pages), "Bewijs samenvatten en lokaal opslaan")
    summary = _summarise(pages)
    summary["errors"] = errors[:20]
    summary["start_url"] = start_url
    summary["max_pages"] = max_pages
    summary["max_depth"] = max_depth
    with db.get_conn() as c:
        cur = c.execute("""INSERT INTO crawl_runs(company_id, tenant_id, start_url, status, pages_crawled, summary_json, created_at)
                           VALUES(?,?,?,?,?,?,?)""",
                        (company_id, config.TENANT, start_url, "complete", len(pages), json.dumps(summary, ensure_ascii=False), now))
        run_id = cur.lastrowid
        c.execute("DELETE FROM crawl_pages WHERE company_id=? AND tenant_id=?", (company_id, config.TENANT))
        for p in pages:
            c.execute("""INSERT INTO crawl_pages(company_id, tenant_id, run_id, url, title, page_type, status_code, signals_json,
                         text_excerpt, content_hash, fetched_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                      (company_id, config.TENANT, run_id, p["url"], p.get("title"), p.get("page_type"), p.get("status_code"),
                       json.dumps(p.get("signals") or {}, ensure_ascii=False), p.get("text_excerpt"), p.get("content_hash"), now))
        # Store crawl-derived evidence, without AI and without turning absence into facts.
        c.execute("DELETE FROM evidence WHERE company_id=? AND tenant_id=? AND source IN ('deep crawl','social deep crawl')", (company_id, config.TENANT))
        for sp in summary.get("strongest_pages", [])[:10]:
            label = "Signaalpagina gevonden"
            sigs = sp.get("signals") or []
            if sigs:
                label = ", ".join(sigs[:3]).capitalize() + " gevonden"
            axis = "timing" if any(x in sigs for x in ["sale", "restpartij", "showroom", "returns_bstock"]) else "fit"
            detail = f"{sp.get('page_type','pagina')} · {sp.get('title') or 'zonder titel'}"
            c.execute("""INSERT INTO evidence(company_id, tenant_id, axis, label, detail, source, source_url, observed_at)
                         VALUES(?,?,?,?,?,?,?,?)""",
                      (company_id, config.TENANT, axis, label, detail, "deep crawl", sp.get("url"), now))
        for item in summary.get("social_profiles", [])[:8]:
            c.execute("""INSERT INTO evidence(company_id, tenant_id, axis, label, detail, source, source_url, observed_at)
                         VALUES(?,?,?,?,?,?,?,?)""",
                      (company_id, config.TENANT, "fit", f"{item.get('platform')} profiel gevonden",
                       f"Social profiel gevonden via websitepagina: {item.get('found_on')}", "social deep crawl", item.get("url"), now))

        c.execute("UPDATE companies SET stage=CASE WHEN stage='discovered' THEN 'deep_crawled' ELSE stage END WHERE id=?", (company_id,))
    db.log_event(company_id, "deep_crawl_complete", {"run_id": run_id, "pages": len(pages), "signals": summary["signal_page_counts"]})
    return {"run_id": run_id, "company_id": company_id, "summary": summary, "pages": [{k: p.get(k) for k in ["url", "title", "page_type", "signals", "discount_percentages"]} for p in pages[:50]]}


def latest_crawl(company_id: int) -> dict | None:
    with db.get_conn() as c:
        run = c.execute("SELECT * FROM crawl_runs WHERE company_id=? AND tenant_id=? ORDER BY created_at DESC LIMIT 1", (company_id, config.TENANT)).fetchone()
        if not run:
            return None
        pages = c.execute("SELECT url,title,page_type,status_code,signals_json,fetched_at FROM crawl_pages WHERE company_id=? AND tenant_id=? ORDER BY id LIMIT 200", (company_id, config.TENANT)).fetchall()
    d = dict(run)
    try:
        d["summary"] = json.loads(d.get("summary_json") or "{}")
    except Exception:
        d["summary"] = {}
    d["pages"] = []
    for p in pages:
        pd = dict(p)
        try:
            pd["signals"] = json.loads(pd.get("signals_json") or "{}")
        except Exception:
            pd["signals"] = {}
        d["pages"].append(pd)
    return d
