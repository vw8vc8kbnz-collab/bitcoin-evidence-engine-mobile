"""
MODULE 7 - Smart Follow-up.

After an approved outreach is queued, schedule follow-ups at day 4 / 10 / 21.
Cancelled automatically once the company replies.
"""
import time
from .. import db, config

STEPS = {1: 4, 2: 10, 3: 21}   # step -> days after contact


def schedule(company_id):
    now = time.time()
    with db.get_conn() as c:
        for step, days in STEPS.items():
            c.execute("""INSERT INTO followups(company_id, tenant_id, step, due_at, status, created_at)
                         VALUES(?,?,?,?,?,?)""",
                      (company_id, config.TENANT, step, now + days * 86400, "scheduled", now))
    db.log_event(company_id, "followups_scheduled", {"steps": list(STEPS.keys())})


def cancel_for(company_id):
    with db.get_conn() as c:
        c.execute("UPDATE followups SET status='cancelled' WHERE company_id=? AND tenant_id=? AND status='scheduled'",
                  (company_id, config.TENANT))


def due_followups():
    now = time.time()
    with db.get_conn() as c:
        rows = c.execute("""SELECT * FROM followups WHERE tenant_id=? AND status='scheduled' AND due_at<=?""",
                         (config.TENANT, now)).fetchall()
    return [dict(r) for r in rows]
