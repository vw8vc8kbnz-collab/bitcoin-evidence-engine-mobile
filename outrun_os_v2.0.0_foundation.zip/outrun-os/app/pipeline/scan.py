"""
MODULE 2 - Company Intelligence / Deep Scan.

Structured-first, then LLM (same idea as the MixLink architecture): pull the
site, extract HARD features with heuristics into JSON, and only then let a model
interpret. The model receives a structured measurement, not raw HTML soup.

In TEST MODE the "fetch" is synthesised from the seed signals so the loop runs
offline. In live mode it would httpx-fetch the site and (optionally) send a
screenshot to GPT vision.
"""
import time
import json
from .. import db, config
from ..services.seed import SEED_COMPANIES

SEED_BY_KVK = {s["kvk"]: s for s in SEED_COMPANIES}

# heuristic signal -> (axis, label, detail template)
SIGNAL_MAP = {
    "outlet-sectie": ("fit", "Outlet-sectie actief", "Vaste outlet-pagina met afgeprijsde artikelen."),
    "showroom-uitverkoop": ("timing", "Showroommodellen uitverkoop", "Homepage-banner over leegverkoop showroom."),
    "340 sale-items": ("timing", "Groot aantal sale-items", "Aantal afgeprijsde SKU's fors gestegen t.o.v. vorige scan."),
    "restpartijen": ("fit", "Restpartijen-sectie", "Aparte sectie voor rest- en showroomvoorraad."),
    "op=op campagne": ("timing", "'OP=OP' campagne live", "Actieve op=op-campagne gedetecteerd."),
    "showroommodellen": ("fit", "Showroommodellen doorlopend", "Verkoopt structureel ex-showroommodellen."),
    "einde-seizoen leegverkoop": ("timing", "Einde-seizoen leegverkoop", "Seizoensgebonden leegverkoop actief."),
    "50% korting": ("timing", "Brede korting actief", "Site-brede korting van ~50%."),
    "b-keuze": ("fit", "B-keuze assortiment", "Structurele B-keuze / tweede-kans categorie."),
    "retouren": ("fit", "Retourstroom", "Verkoopt retour-/transportschade-artikelen."),
    "showroom-rotatie": ("fit", "Showroom-rotatie", "Wisselt collecties periodiek, oude modellen afgeprijsd."),
    "sale groeit": ("timing", "Sale-sectie groeit", "Aantal afgeprijsde items stijgend."),
    "refurbished": ("fit", "Refurbished assortiment", "Voornamelijk refurbished, hoger prijstier."),
    "restpartijen laminaat": ("fit", "Restpartijen vloeren", "Partij-verkoop van uitlopende dessins."),
    "outlet-vestiging": ("fit", "Fysieke outlet-vestiging", "Aparte outletlocatie."),
    "modellen moeten weg": ("timing", "'Modellen moeten weg'", "Campagne om oude collectie te ruimen."),
    "projectrestanten": ("fit", "Projectrestanten", "Verkoopt overgebleven projectmeubilair."),
    "verse restpartij": ("timing", "Verse restpartij binnen", "'Nieuwe partij binnen \u2014 moet snel weg'."),
    "warehouse-outlet": ("fit", "Warehouse-outlet model", "Ex-showroom vanuit magazijn."),
    "magazijn-leegverkoop": ("timing", "Magazijn-leegverkoop", "'Magazijn moet leeg voor nieuwe collectie'."),
    "overstock-rotatie": ("fit", "Overstock-rotatie", "Structureel hoog aantal afgeprijsde SKU's."),
    "uitlopende serie": ("timing", "Uitlopende serie", "Uitlopende serie afgeprijsd."),
    "partij restvoorraad": ("fit", "Partij restvoorraad", "Verkoopt restvoorraad per partij."),
    "partij restvoorraad ": ("fit", "Partij restvoorraad", "Verkoopt restvoorraad per partij."),
}


def _fetch_features_test(company):
    seed = SEED_BY_KVK.get(company["kvk"], {})
    signals = seed.get("signals", [])
    features = {
        "has_outlet": any("outlet" in s or "rest" in s for s in signals),
        "sale_signal": any(s in SIGNAL_MAP and SIGNAL_MAP[s][0] == "timing" for s in signals),
        "signal_count": len(signals),
        "raw_signals": signals,
        "kvk_verified": True,
    }
    return features


def scan_company(company_id):
    with db.get_conn() as c:
        row = c.execute("SELECT * FROM companies WHERE id=? AND tenant_id=?",
                        (company_id, config.TENANT)).fetchone()
        if not row:
            return None
        company = dict(row)

    if config.TEST_MODE:
        features = _fetch_features_test(company)
    else:
        features = _fetch_features_live(company)

    now = time.time()
    with db.get_conn() as c:
        c.execute("INSERT INTO scans(company_id, tenant_id, features_json, summary, created_at) VALUES(?,?,?,?,?)",
                  (company_id, config.TENANT, json.dumps(features),
                   f"{features['signal_count']} signalen; outlet={features['has_outlet']}", now))
        # write evidence rows from heuristic signals (structured-first)
        c.execute("DELETE FROM evidence WHERE company_id=? AND tenant_id=?", (company_id, config.TENANT))
        for s in features.get("raw_signals", []):
            axis, label, detail = SIGNAL_MAP.get(s, ("fit", s.capitalize(), "Signaal gedetecteerd."))
            c.execute("""INSERT INTO evidence(company_id, tenant_id, axis, label, detail, source, source_url, observed_at)
                         VALUES(?,?,?,?,?,?,?,?)""",
                      (company_id, config.TENANT, axis, label, detail, "crawl",
                       company.get("website"), now))
        # always add the KvK evidence
        c.execute("""INSERT INTO evidence(company_id, tenant_id, axis, label, detail, source, source_url, observed_at)
                     VALUES(?,?,?,?,?,?,?,?)""",
                  (company_id, config.TENANT, "fit", "KvK geverifieerd",
                   f"Actieve inschrijving, {company.get('size','?')} medewerkers.", "KvK API", None, now))
        c.execute("UPDATE companies SET stage='scanned' WHERE id=?", (company_id,))
    db.log_event(company_id, "scanned", {"features": features})
    return features


def _fetch_features_live(company):
    """Live fetch + heuristic extraction. Runs only outside test mode."""
    import re
    import httpx
    url = company.get("website") or ""
    if url and not url.startswith("http"):
        url = "https://" + url
    html = ""
    try:
        with httpx.Client(timeout=20, follow_redirects=True,
                          headers={"User-Agent": "OutrunOS/1.0 (+partner-discovery)"}) as client:
            html = client.get(url).text.lower()
    except Exception:
        html = ""
    signals = []
    if "outlet" in html:
        signals.append("outlet-sectie")
    if "op=op" in html or "op is op" in html:
        signals.append("op=op campagne")
    if "showroom" in html:
        signals.append("showroommodellen")
    if re.search(r"\b(uitverkoop|leegverkoop|clearance)\b", html):
        signals.append("showroom-uitverkoop")
    if re.search(r"\b(b-keuze|tweede kans|retour)\b", html):
        signals.append("b-keuze")
    return {
        "has_outlet": "outlet" in html,
        "sale_signal": bool(signals),
        "signal_count": len(signals),
        "raw_signals": signals,
        "kvk_verified": bool(company.get("kvk")),
    }
