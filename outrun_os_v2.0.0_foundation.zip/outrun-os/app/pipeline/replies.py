"""
MODULE 8 - Reply Brain (+ synthetic replies for the test loop).

Reply Brain classifies inbound replies: HOT / WARM / QUESTION / NOT_NOW / NO.
On HOT it flags for immediate founder attention.

Synthetic replies: so you can test the WHOLE loop dry (mail -> reply ->
classification -> follow-up -> CRM status), a model generates a simulated
company reply with a persona. Only ever used in test mode.
"""
import time
from .. import db, config
from ..llm.base import LLMTask
from ..llm import router


def classify_reply(company_id, message_id, body):
    t = LLMTask(
        name="classify_reply",
        system=("Classificeer een inkomende reactie op koude outreach. Intents: HOT (concrete interesse/vraag om te "
                "starten), WARM (mild positief), QUESTION (vraag), NOT_NOW (later), NO (afwijzing). "
                "JSON: {intent:str, summary:str}."),
        user=body,
        prefer_cheap=True,
    )
    r = router.run(t)
    j = r.get("json") or {"intent": "WARM", "summary": ""}
    intent = j.get("intent", "WARM")
    now = time.time()
    with db.get_conn() as c:
        c.execute("""INSERT INTO replies(company_id, message_id, tenant_id, body, intent, summary, is_synthetic, created_at)
                     VALUES(?,?,?,?,?,?,?,?)""",
                  (company_id, message_id, config.TENANT, body, intent, j.get("summary", ""),
                   1 if config.TEST_MODE else 0, now))
        c.execute("UPDATE companies SET stage='replied' WHERE id=?", (company_id,))
    db.log_event(company_id, "reply_classified", {"intent": intent, "hot": intent == "HOT"})
    return {"intent": intent, "summary": j.get("summary", "")}


def synthesize_reply(company_id):
    """Generate a fake company reply and run it through the reply brain. Test mode only."""
    if not config.TEST_MODE:
        return None
    with db.get_conn() as c:
        comp = c.execute("SELECT * FROM companies WHERE id=? AND tenant_id=?",
                         (company_id, config.TENANT)).fetchone()
        msg = c.execute("""SELECT * FROM messages WHERE company_id=? AND tenant_id=? AND direction='out'
                           ORDER BY created_at DESC LIMIT 1""", (company_id, config.TENANT)).fetchone()
    if not comp or not msg:
        return None
    t = LLMTask(
        name="synthetic_reply",
        system=("Je speelt een Nederlands bedrijf dat koude outreach ontving. Genereer een realistische, korte "
                "reactie met een willekeurige houding (enthousiast, vraag, geen tijd, of afwijzing). "
                "JSON: {intent:str, body:str}."),
        user=f"Bedrijf: {dict(comp)['name']}. Ontvangen mail: {dict(msg)['body'][:400]}",
        prefer_cheap=True,
    )
    r = router.run(t)
    j = r.get("json") or {"body": "Bedankt voor jullie bericht."}
    body = j.get("body", "Bedankt voor jullie bericht.")
    return classify_reply(company_id, dict(msg)["id"], body)
