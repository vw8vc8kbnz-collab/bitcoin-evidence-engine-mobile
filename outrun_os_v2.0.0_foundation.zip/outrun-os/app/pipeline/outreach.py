"""
MODULE 5+6 - Personalised Outreach + Founder Approval.

Generator -> Verifier, cross-model:
  - GPT writes the outreach (tone matters; goes to real humans).
  - DeepSeek verifies every claim against the collected evidence and flags any
    that isn't supported. A fabricated fact in a cold B2B mail is fatal; this
    catches it before it can be sent.

Nothing is ever auto-sent. Every draft lands in the approval queue.
"""
import time
import json
from .. import db, config
from ..llm.base import LLMTask
from ..llm import router

TONE_RULES = (
    "Toon: professioneel, rustig, eerlijk, niet arrogant. Nooit doen alsof het platform al gigantisch is. "
    "Gebruik de framing: 'we bouwen momenteel aan een nieuw gespecialiseerd outletplatform en denken dat jullie "
    "hier goed bij zouden kunnen passen.' Kort en concreet. Nederlands."
)


def _evidence_text(company_id):
    with db.get_conn() as c:
        rows = c.execute("SELECT axis,label,detail FROM evidence WHERE company_id=? AND tenant_id=?",
                         (company_id, config.TENANT)).fetchall()
    return "\n".join(f"- [{r['axis']}] {r['label']}: {r['detail']}" for r in rows)



def _safe_foundation_draft(company, evidence_text: str, reason: str = "truth_first"):
    """Fallback draft that does not make company-specific factual claims.

    Used when there is no validated evidence yet or when the verifier flags
    unsupported claims. This prevents hallucinated outreach from landing in the
    approval queue.
    """
    brand = config.SENDER_BRAND
    sender = config.SENDER_NAME
    first = (company.get("name") or "jullie bedrijf").split(" ")[0]
    subject = f"Vraag over outlet- en restvoorraad · {first}"
    body = (
        f"Beste team van {first},\n\n"
        f"Mijn naam is {sender} van {brand}. We bouwen momenteel aan een gespecialiseerd outletplatform voor bedrijven die op een gecontroleerde manier outlet-, rest-, retour- of showroomvoorraad willen aanbieden.\n\n"
        f"Ik stuur bewust nog geen harde aannames over jullie voorraad of werkwijze, omdat ik dat eerst graag netjes wil verifiëren. Het idee achter {brand} is simpel: een aanvullend verkoopkanaal naast de reguliere webshop, zonder vaste kosten en zonder dat het bestaande verkoopkanaal verstoord hoeft te worden.\n\n"
        f"Zou het zinvol zijn om kort te verkennen of dit voor jullie bedrijf relevant kan zijn?\n\n"
        f"Met vriendelijke groet,\n"
        f"{sender}\n"
        f"Founder · {brand}"
    )
    return subject, body, {"flags": [], "mode": reason, "note": "Waarheidsveilige fallback: geen bedrijfsspecifieke claims zonder evidence."}

def generate_draft(company_id):
    with db.get_conn() as c:
        row = c.execute("SELECT * FROM companies WHERE id=? AND tenant_id=?",
                        (company_id, config.TENANT)).fetchone()
        if not row:
            return None
        company = dict(row)
    ev_text = _evidence_text(company_id)

    # Truth First: without evidence, do not ask AI to invent context.
    if not ev_text.strip():
        subject, body, verifier = _safe_foundation_draft(company, ev_text, "no_evidence_yet")
        now = time.time()
        with db.get_conn() as c:
            cur = c.execute("""INSERT INTO drafts(company_id, tenant_id, subject, body, status, verifier_json, created_at)
                         VALUES(?,?,?,?,?,?,?)""",
                      (company_id, config.TENANT, subject, body, "awaiting",
                       json.dumps(verifier, ensure_ascii=False), now))
            draft_id = cur.lastrowid
            c.execute("UPDATE companies SET stage='drafted' WHERE id=?", (company_id,))
        db.log_event(company_id, "draft_generated", {"writer": "safe-local", "verifier": "safe-local", "flags": 0, "mode": "no_evidence_yet"})
        return {"draft_id": draft_id, "subject": subject, "body": body, "verifier": verifier}

    # 1) GPT writes (quality)
    wt = LLMTask(
        name="write_outreach",
        system=("Je schrijft koude B2B-outreach voor een outletmarktplaats. " + TONE_RULES +
                " Baseer je alleen op het bewijs. JSON: {subject:str, body:str}."),
        user=f"Bedrijf: {company['name']} ({company.get('sector')}, {company.get('city')}).\nBewijs:\n{ev_text}",
        prefer_quality=True, prefer_cheap=False,
        meta={"brand": config.SENDER_BRAND, "company": company["name"],
              "commission": config.COMMISSION_PCT, "sender": config.SENDER_NAME},
    )
    w = router.run(wt)
    draft = w.get("json") or {}
    subject = draft.get("subject", f"Nieuw outletplatform \u2014 samenwerken?")
    body = draft.get("body", "")

    # 2) DeepSeek verifies claims (cheap analyst as fact-checker)
    vt = LLMTask(
        name="verify_claims",
        system=("Je controleert een concept-mail tegen het bewijs. Markeer ELKE feitelijke claim in de mail die "
                "NIET door het bewijs wordt gedekt. JSON: {flags:[{quote:str, reason:str}]}. Lege lijst als alles klopt."),
        user=f"Bewijs:\n{ev_text}\n\nMail:\n{body}",
        prefer_cheap=True,
    )
    v = router.run(vt)
    verifier = v.get("json") or {"flags": []}
    if verifier.get("flags"):
        subject, body, verifier = _safe_foundation_draft(company, ev_text, "verifier_flagged_unsupported_claims")

    now = time.time()
    with db.get_conn() as c:
        cur = c.execute("""INSERT INTO drafts(company_id, tenant_id, subject, body, status, verifier_json, created_at)
                     VALUES(?,?,?,?,?,?,?)""",
                  (company_id, config.TENANT, subject, body, "awaiting",
                   json.dumps(verifier, ensure_ascii=False), now))
        draft_id = cur.lastrowid
        c.execute("UPDATE companies SET stage='drafted' WHERE id=?", (company_id,))
    db.log_event(company_id, "draft_generated",
                 {"writer": w.get("provider"), "verifier": v.get("provider"),
                  "flags": len(verifier.get("flags", []))})
    return {"draft_id": draft_id, "subject": subject, "body": body, "verifier": verifier}


def latest_draft(company_id):
    with db.get_conn() as c:
        r = c.execute("SELECT * FROM drafts WHERE company_id=? AND tenant_id=? ORDER BY created_at DESC LIMIT 1",
                      (company_id, config.TENANT)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["verifier"] = json.loads(d["verifier_json"] or '{"flags":[]}')
    return d
