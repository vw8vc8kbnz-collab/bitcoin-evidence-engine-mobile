"""
Background worker. Advances the pipeline one small step per tick so the system
visibly 'flows' (Discovery -> Scan -> Score -> Draft) without a burst. Drafts
stop at the approval queue: nothing proceeds to contact without the founder.

In test mode it also occasionally synthesises a reply to a contacted company so
the reply/follow-up loop can be observed end to end.
"""
import threading
import time
from . import db, config
from .pipeline import discovery, scan, scoring, outreach, replies, followup

_stop = threading.Event()
_thread = None


def _next(stage):
    with db.get_conn() as c:
        r = c.execute("SELECT id FROM companies WHERE tenant_id=? AND stage=? ORDER BY created_at ASC LIMIT 1",
                      (config.TENANT, stage)).fetchone()
    return r["id"] if r else None


def tick():
    """One unit of work. Returns a short label of what happened."""
    # 1) keep the funnel fed
    cid = _next("discovered")
    if cid:
        scan.scan_company(cid)
        return f"scanned #{cid}"
    cid = _next("scanned")
    if cid:
        scoring.score_company(cid)
        return f"scored #{cid}"
    # 2) build drafts for scored A/B leads that have none yet
    with db.get_conn() as c:
        r = c.execute("""SELECT c.id FROM companies c
                         WHERE c.tenant_id=? AND c.stage='scored'
                         AND NOT EXISTS(SELECT 1 FROM drafts d WHERE d.company_id=c.id)
                         ORDER BY c.created_at ASC LIMIT 1""", (config.TENANT,)).fetchone()
    if r:
        s = scoring.latest_score(r["id"])
        if s and s["priority"] in ("A", "B"):
            outreach.generate_draft(r["id"])
            return f"drafted #{r['id']}"
        with db.get_conn() as c:
            c.execute("UPDATE companies SET stage='nurture' WHERE id=?", (r["id"],))
        return f"nurtured #{r['id']}"
    # 3) discover more if the funnel is empty
    added = discovery.run_discovery()
    if added:
        return f"discovered {len(added)}"
    # 4) test loop: synthesise a reply for a contacted company without one
    if config.TEST_MODE:
        with db.get_conn() as c:
            r = c.execute("""SELECT c.id FROM companies c
                             WHERE c.tenant_id=? AND c.stage='contacted'
                             AND NOT EXISTS(SELECT 1 FROM replies rp WHERE rp.company_id=c.id)
                             ORDER BY c.created_at ASC LIMIT 1""", (config.TENANT,)).fetchone()
        if r:
            res = replies.synthesize_reply(r["id"])
            if res and res["intent"] not in ("NO",):
                followup.cancel_for(r["id"])
            return f"reply #{r['id']} ({res['intent'] if res else '?'})"
    return "idle"


def _loop():
    # prime the funnel on startup
    try:
        discovery.run_discovery()
    except Exception:
        pass
    while not _stop.is_set():
        try:
            tick()
        except Exception as e:
            db.log_event(None, "worker_error", {"error": str(e)})
        _stop.wait(config.WORKER_INTERVAL_SEC)


def start():
    global _thread
    if not config.WORKER_ENABLED:
        return
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(target=_loop, daemon=True, name="outrun-worker")
    _thread.start()


def stop():
    _stop.set()
