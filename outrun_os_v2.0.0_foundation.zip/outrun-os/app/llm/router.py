"""
Router: given a task's declared needs, choose the right provider.

Rules (the "giga slim" division of labour):
  - needs_vision            -> GPT only (DeepSeek cannot see images)
  - prefer_quality          -> GPT (tone, nuance, judgement)
  - prefer_cheap (default)  -> DeepSeek (bulk analysis)
If the chosen provider has no key, fall back to mock so the app always runs.
"""
from .base import LLMTask
from .mock import MockProvider
from .deepseek import DeepSeekProvider
from .openai import OpenAIProvider
from .. import config

_mock = MockProvider()


def _deepseek():
    return DeepSeekProvider() if config.DEEPSEEK_API_KEY else _mock


def _openai():
    return OpenAIProvider() if config.OPENAI_API_KEY else _mock


def route(task: LLMTask):
    if task.needs_vision:
        return _openai()               # hard rule: images -> GPT (or mock)
    if task.prefer_quality:
        return _openai()
    return _deepseek()


def run(task: LLMTask) -> dict:
    provider = route(task)
    result = provider.complete(task)
    result.setdefault("provider", provider.name)
    return result
