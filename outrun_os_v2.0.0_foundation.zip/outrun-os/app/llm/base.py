"""
LLM abstraction. Every task declares what it NEEDS (cheap / quality / vision),
and the router picks a provider. This is what lets DeepSeek and GPT each do what
they are good at, and lets you swap models later without touching the pipeline.
"""
from dataclasses import dataclass, field
import json
import re


@dataclass
class LLMTask:
    name: str                       # e.g. "score", "write_outreach"
    system: str                     # system prompt
    user: str                       # user prompt
    needs_vision: bool = False      # image input -> must go to GPT (DeepSeek can't)
    prefer_quality: bool = False    # nuance/tone/judgement -> GPT
    prefer_cheap: bool = True       # bulk analysis -> DeepSeek
    want_json: bool = True
    image_b64: str = None
    meta: dict = field(default_factory=dict)


class LLMProvider:
    name = "base"
    kind = "mock"   # live|mock

    def complete(self, task: LLMTask) -> dict:
        """Return {'text': str, 'json': dict|None, 'provider': str}."""
        raise NotImplementedError


def extract_json(text: str):
    """Best-effort JSON extraction from a model reply (strips code fences)."""
    if not text:
        return None
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?", "", cleaned).strip()
    cleaned = re.sub(r"```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except Exception:
        # try to find the first {...} block
        m = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                return None
    return None
