"""
OpenAI (GPT) provider.
Role: the writer + eyes + judge. Final outreach copy (tone matters), vision
scanning of screenshots (DeepSeek can't do images), and second-guessing the
DeepSeek score on the expensive Priority-A decisions.
"""
import httpx
from .base import LLMProvider, LLMTask, extract_json
from .. import config

ENDPOINT = "https://api.openai.com/v1/chat/completions"


class OpenAIProvider(LLMProvider):
    name = "openai"
    kind = "live"

    def complete(self, task: LLMTask) -> dict:
        headers = {
            "Authorization": f"Bearer {config.OPENAI_API_KEY}",
            "Content-Type": "application/json",
        }
        if task.needs_vision and task.image_b64:
            model = config.OPENAI_VISION_MODEL
            content = [
                {"type": "text", "text": task.user},
                {"type": "image_url",
                 "image_url": {"url": f"data:image/png;base64,{task.image_b64}"}},
            ]
            user_msg = {"role": "user", "content": content}
        else:
            model = config.OPENAI_MODEL
            user_msg = {"role": "user", "content": task.user}

        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": task.system},
                user_msg,
            ],
            "temperature": 0.5,
        }
        if task.want_json:
            payload["response_format"] = {"type": "json_object"}
        try:
            with httpx.Client(timeout=90) as client:
                r = client.post(ENDPOINT, headers=headers, json=payload)
                r.raise_for_status()
                text = r.json()["choices"][0]["message"]["content"]
        except Exception as e:
            return {"text": f"[openai error: {e}]", "json": None, "provider": "openai(error)"}
        return {"text": text, "json": extract_json(text) if task.want_json else None, "provider": "openai"}
