"""
DeepSeek provider (OpenAI-compatible /chat/completions).
Role: the cheap analyst/verifier. Bulk scoring, claim verification, reply
classification. DeepSeek-chat CANNOT process images, so vision tasks never
reach this provider (enforced by the router).
"""
import httpx
from .base import LLMProvider, LLMTask, extract_json
from .. import config

ENDPOINT = "https://api.deepseek.com/chat/completions"


class DeepSeekProvider(LLMProvider):
    name = "deepseek"
    kind = "live"

    def complete(self, task: LLMTask) -> dict:
        headers = {
            "Authorization": f"Bearer {config.DEEPSEEK_API_KEY}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": config.DEEPSEEK_MODEL,
            "messages": [
                {"role": "system", "content": task.system},
                {"role": "user", "content": task.user},
            ],
            "temperature": 0.3,
        }
        if task.want_json:
            payload["response_format"] = {"type": "json_object"}
        try:
            with httpx.Client(timeout=60) as client:
                r = client.post(ENDPOINT, headers=headers, json=payload)
                r.raise_for_status()
                text = r.json()["choices"][0]["message"]["content"]
        except Exception as e:
            return {"text": f"[deepseek error: {e}]", "json": None, "provider": "deepseek(error)"}
        return {"text": text, "json": extract_json(text) if task.want_json else None, "provider": "deepseek"}
