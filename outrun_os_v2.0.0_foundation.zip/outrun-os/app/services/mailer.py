"""
The single choke point for sending. TEST_MODE is enforced HERE, server-side, so
no browser action can ever cause a real send. This is deliberate: a past project
shipped a "test mode" that was client-toggleable and publicly reachable. Not here.

  TEST_MODE = True  -> write to the Outbox (messages.status = 'outbox'). Inspect it.
  TEST_MODE = False -> attempt real SMTP send (only if SMTP is configured).
"""
import time
import smtplib
from email.mime.text import MIMEText
from .. import db, config


def send(company_id, subject, body, to_addr=None):
    now = time.time()
    if config.TEST_MODE or not config.SMTP_HOST:
        with db.get_conn() as c:
            cur = c.execute("""INSERT INTO messages(company_id, tenant_id, direction, channel, subject, body, status, created_at)
                         VALUES(?,?,?,?,?,?,?,?)""",
                      (company_id, config.TENANT, "out", "email", subject, body, "outbox", now))
            mid = cur.lastrowid
        db.log_event(company_id, "queued_outbox", {"subject": subject})
        return {"status": "outbox", "message_id": mid, "sent": False}

    # --- live send path (never runs in test mode) ---
    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = config.SMTP_FROM or config.SMTP_USER
    msg["To"] = to_addr or ""
    try:
        with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=30) as s:
            s.starttls()
            if config.SMTP_USER:
                s.login(config.SMTP_USER, config.SMTP_PASS)
            s.send_message(msg)
        status = "sent"
    except Exception as e:
        db.log_event(company_id, "send_error", {"error": str(e)})
        status = "error"
    with db.get_conn() as c:
        cur = c.execute("""INSERT INTO messages(company_id, tenant_id, direction, channel, subject, body, status, created_at)
                     VALUES(?,?,?,?,?,?,?,?)""",
                  (company_id, config.TENANT, "out", "email", subject, body, status, now))
        mid = cur.lastrowid
    return {"status": status, "message_id": mid, "sent": status == "sent"}
