# Outrun OS v1.3.5 — Debug Center

Standalone acquisition intelligence cockpit voor Outrun IQ.

## Veiligheid
- Testmodus staat standaard aan.
- Worker staat standaard uit.
- Geen automatische 24/7 AI-scans.
- Geen verzending zonder server-side live-config.

## Debug endpoints
- `/health`
- `/api/debug`
- `/api/jobs`

## VPS
Service: `outrun-os`
Default poort: `8700`
