"""
Outrun OS entrypoint. Run: python run.py
"""
import uvicorn
from app import config

if __name__ == "__main__":
    print("=" * 60)
    print(" OUTRUN OS")
    print(f"  test_mode : {config.TEST_MODE}  (niets wordt verzonden)" if config.TEST_MODE
          else "  test_mode : False  ** LIVE - er wordt echt verzonden **")
    print(f"  deepseek  : {'live' if config.DEEPSEEK_API_KEY else 'mock (geen key)'}")
    print(f"  openai    : {'live' if config.OPENAI_API_KEY else 'mock (geen key)'}")
    print(f"  listening : http://{config.HOST}:{config.PORT}")
    print("=" * 60)
    uvicorn.run("app.api:app", host=config.HOST, port=config.PORT, reload=False, workers=1)
