# Outrun OS v2.0.0 Foundation — overdracht

## Doel van deze release
Deze release is een stabiliteits- en funderingsrelease. De focus ligt niet op extra AI-features, maar op een betrouwbare basis waarin knoppen zichtbaar werken, jobs live voortgang tonen en fouten niet meer stil verdwijnen.

## Belangrijkste wijzigingen

### 1. Stability Foundation
- Versie verhoogd naar `2.0.0-foundation`.
- `/health` werkt en geeft service-, database-, port- en uptime-status terug.
- `/api/debug` bevat nu database-status, jobs, routes, recente bedrijven, events en request-log.
- `/api/routes` en `/api/ping` toegevoegd voor snelle diagnose.
- Request middleware toegevoegd: elke API-call wordt geregistreerd met route, statuscode en duur.
- Browser-side API-wrapper toont nu fouten in een toast in plaats van stil falen.

### 2. Live Jobs / Progress
- Master vullen, basic analyse en deep search blijven job-based.
- Jobs tonen status, current/total, percentage, ETA en error.
- Basic analyse deadlock opgelost: job-progress schrijft niet meer naar SQLite terwijl een lange transactie open staat.

### 3. Company Master Database
- `bootstrap_generated()` is uitgefaseerd naar `bootstrap_local_sample()`.
- De knop “master vullen 10k” vult nog steeds een lokale samplebasis zonder AI/API-kosten, maar deze wordt eerlijk gemarkeerd als `source=local-sample`.
- Voor echte KvK/bedrijfsdata blijft CSV-import de juiste route.
- Endpoint `/api/master/status` toegevoegd.
- Aliassen toegevoegd voor robuustheid: `/api/master/fill` en `/api/master/bootstrap10k`.

### 4. Truth-first Mail Engine
- Als er nog geen evidence is, wordt er geen AI-context verzonnen.
- De mailgenerator gebruikt dan een veilige foundation-mail zonder bedrijfsspecifieke claims.
- Als de verifier unsupported claims vindt, valt het systeem terug op een veilige mail.
- Mock LLM is aangepast: geen bewust ingeplante hallucinaties meer.

### 5. UX / Debug
- Toastmeldingen toegevoegd voor succes/fout.
- Debug dashboard toont nu laatste backend API-calls en laatste frontend API-call.
- Knoppen zoals master vullen, basic analyse, deep search, regenerate, approve en reject hebben foutafhandeling.

## Wat bewust nog niet is opgelost
- Er is nog geen echte KvK bulk-koppeling ingebouwd. De tool ondersteunt CSV-import, maar haalt niet zelfstandig alle KvK’s op.
- Deep Search blijft afhankelijk van de websitebereikbaarheid van een bedrijf.
- Social search is alleen via links die vanaf de website gevonden worden; er is nog geen externe Google/social API search ingebouwd.
- Echte mailverzending blijft veilig achter testmodus/SMTP-config.

## Testresultaten lokaal in container
- Python compile: OK.
- Frontend JavaScript syntaxcheck met Node: OK.
- `/health`: OK.
- `/api/master/bootstrap?limit=250`: OK.
- `/api/master/basic-analyze`: OK, job eindigt op complete.
- `/api/jobs`: OK.
- `/api/stats`: OK.
- `/api/master/status`: OK.
- `/api/lead/{id}/regenerate` zonder evidence: veilige truth-first mail, geen hallucinerende claims.

## Aanbevolen volgende build
v2.1 zou moeten focussen op echte data-import:
- CSV upload in UI in plaats van prompt.
- Import van grote KvK/open-data exports.
- Betere mapping van kolommen.
- Filters voor grootte/sector/regio/website/source.
- Deep Search queue vanuit echte company master.
