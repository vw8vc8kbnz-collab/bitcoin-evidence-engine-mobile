# Deploy — GitHub → VPS → Termius

## 0. Eenmalig: naar GitHub

Op je machine (of upload de map):

```bash
cd outrun-os
git init && git add . && git commit -m "Outrun OS v1.0"
git branch -M main
git remote add origin git@github.com:<jouw-user>/outrun-os.git
git push -u origin main
```

## 1. Eerste deploy op de VPS (Termius — plak dit blok één keer)

```bash
cd /home/ubuntu && \
git clone https://github.com/<jouw-user>/outrun-os.git && \
cd outrun-os && \
python3 -m venv .venv && \
./.venv/bin/pip install -r requirements.txt && \
cp .env.example .env && \
sudo cp deploy/outrun-os.service /etc/systemd/system/ && \
sudo systemctl daemon-reload && sudo systemctl enable outrun-os
```

## 2. De ENIGE twee dingen die je zet — de keys in Termius

Open `.env` en vul je twee keys in (verder niets nodig):

```bash
nano /home/ubuntu/outrun-os/.env
```
```
DEEPSEEK_API_KEY=sk-...          # jouw DeepSeek key
OPENAI_API_KEY=sk-...            # jouw OpenAI key
```

Start:
```bash
sudo systemctl start outrun-os
```

Bereik de tool op `http://<vps-ip>:8700` (zet er een reverse proxy + auth voor
als hij publiek moet — doe dat niet zonder auth).

> Testmodus staat AAN. Er wordt niets verzonden. Zo hoort het tot je klaar bent.

## 3. Update-regel (Termius — dit is je terugkerende one-liner)

```bash
cd /home/ubuntu/outrun-os && git pull && ./.venv/bin/pip install -r requirements.txt --quiet && sudo systemctl restart outrun-os && sudo systemctl status outrun-os --no-pager -l | head -8
```

Geen build, geen npm, `.env` blijft ongemoeid — je keys hoef je maar één keer te
zetten.

## 4. Live gaan (pas als je er klaar voor bent — bewuste stap)

1. Regel deliverability eerst: apart verzendsubdomein, SPF/DKIM/DMARC, warmup.
2. Vul de SMTP-velden in `.env` in.
3. Zet `OUTRUN_TEST_MODE=false` in `.env`.
4. `sudo systemctl restart outrun-os`

De topbalk kleurt rood: **LIVE**. Vanaf dat moment gaat goedkeuren écht de deur uit.
