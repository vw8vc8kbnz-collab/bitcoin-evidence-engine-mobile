import os, json, time, threading, sqlite3, re
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

import requests
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

ROOT = Path('/home/ubuntu/stock-gem-engine') if Path('/home/ubuntu/stock-gem-engine').exists() else Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'; LOGS = ROOT / 'logs'
DATA.mkdir(parents=True, exist_ok=True); LOGS.mkdir(parents=True, exist_ok=True)
load_dotenv(ROOT / '.env')

APP_VERSION = '1.0.2-no-api-global-charts'
PORT = int(os.getenv('APP_PORT','8791'))
NTFY_TOPIC = os.getenv('NTFY_TOPIC','Stijn-Tradifi-2026')
SCAN_INTERVAL_MINUTES = int(os.getenv('SCAN_INTERVAL_MINUTES','60'))
AUTO_SCAN_ENABLED = os.getenv('AUTO_SCAN_ENABLED','true').lower() == 'true'
DB = DATA / 'stock_gems.sqlite3'

AI_ENABLED = os.getenv('AI_ENABLED','false').lower() == 'true'
AI_PROVIDER = os.getenv('AI_PROVIDER','none').lower()
AI_FALLBACK_PROVIDER = os.getenv('AI_FALLBACK_PROVIDER','none').lower()
AI_MAX_PER_SCAN = int(os.getenv('AI_MAX_PER_SCAN','0'))
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY','').strip()
OPENAI_MODEL = os.getenv('OPENAI_MODEL','gpt-4.1-mini')
OPENAI_BASE_URL = os.getenv('OPENAI_BASE_URL','https://api.openai.com/v1').rstrip('/')
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY','').strip()
DEEPSEEK_MODEL = os.getenv('DEEPSEEK_MODEL','deepseek-reasoner')
DEEPSEEK_BASE_URL = os.getenv('DEEPSEEK_BASE_URL','https://api.deepseek.com').rstrip('/')

app = FastAPI(title='Stijn-Tradifi-2026 Stock Gem Engine', version=APP_VERSION)
state = {'running': False, 'last_scan': None, 'last_alerts': 0, 'last_ai_used': 0, 'error': None}

# ----------------------- basic infra -----------------------
def log(msg: str):
    try:
        LOGS.mkdir(parents=True, exist_ok=True)
        with open(LOGS / 'app.log', 'a', encoding='utf-8') as f:
            f.write(f"{datetime.now(timezone.utc).isoformat()} {msg}\n")
    except Exception:
        pass

def _ensure_columns(con: sqlite3.Connection):
    existing = {r[1] for r in con.execute('PRAGMA table_info(gems)').fetchall()}
    add = {
        'hidden_score':'REAL', 'accumulation_score':'REAL', 'narrative_score':'REAL',
        'dilution_risk_score':'REAL', 'conviction_score':'REAL',
        'conviction_label':'TEXT', 'scam_risk_label':'TEXT', 'ai_source':'TEXT',
        'ai_verdict':'TEXT', 'ai_confidence':'REAL', 'timeline_json':'TEXT',
        'ai_json':'TEXT', 'next_level_json':'TEXT'
    }
    for col, typ in add.items():
        if col not in existing:
            try: con.execute(f'ALTER TABLE gems ADD COLUMN {col} {typ}')
            except Exception as e: log(f'migration_column_error {col} {e}')

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute('''CREATE TABLE IF NOT EXISTS gems (
      ticker TEXT PRIMARY KEY, name TEXT, sector TEXT, country TEXT, exchange TEXT,
      mcap_usd REAL, mcap_source TEXT, mcap_confidence TEXT,
      gem_score REAL, early_signal REAL, hype_risk REAL, risk_score REAL,
      hidden_score REAL, accumulation_score REAL, narrative_score REAL,
      dilution_risk_score REAL, conviction_score REAL,
      conviction_label TEXT, scam_risk_label TEXT, ai_source TEXT,
      ai_verdict TEXT, ai_confidence REAL,
      company_short TEXT, why_attractive TEXT, risk_plain TEXT, catalyst_plain TEXT,
      broker_json TEXT, news_json TEXT, timeline_json TEXT, ai_json TEXT, next_level_json TEXT,
      first_seen TEXT, last_seen TEXT, alerted INTEGER DEFAULT 0
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS scan_runs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, count INTEGER, alerts INTEGER, note TEXT, ai_used INTEGER DEFAULT 0
    )''')
    _ensure_columns(con)
    return con

# ----------------------- universe / signals -----------------------
UNIVERSE: List[Dict[str, Any]] = [
 {'ticker':'DPRO','name':'Draganfly','sector':'Drones / Defense Tech','country':'Canada/US','exchange':'NASDAQ/CSE','mcap':187_000_000,'news':['Defense drone integration deals','Autonomous counter-UAS platform mentions','Slowly rising defense-drone narrative'],'price_30d':18,'volume_trend':1.35,'mentions':'low','dilution':'medium','reverse_splits':1,'offerings_24m':2},
 {'ticker':'PRZO','name':'ParaZero Technologies','sector':'Drone safety / Defense','country':'Israel/US','exchange':'NASDAQ','mcap':38_000_000,'news':['DefendAir net pod integration deal','Autonomous counter-UAS platform','Small contract/news cadence increasing'],'price_30d':-3,'volume_trend':1.65,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'QBTS','name':'D-Wave Quantum','sector':'Quantum computing','country':'Canada/US','exchange':'NYSE','mcap':1_900_000_000,'news':['Quantum adoption narrative','Enterprise optimization pilots'],'price_30d':42,'volume_trend':2.4,'mentions':'high','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'RGTI','name':'Rigetti Computing','sector':'Quantum computing','country':'US','exchange':'NASDAQ','mcap':2_100_000_000,'news':['Quantum hardware roadmap','Government research funding'],'price_30d':35,'volume_trend':2.1,'mentions':'high','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'KULR','name':'KULR Technology','sector':'Battery safety / Energy storage','country':'US','exchange':'NYSE American','mcap':410_000_000,'news':['Battery safety contracts','Defense/space thermal management','Revenue narrative improving'],'price_30d':21,'volume_trend':1.8,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'OPTT','name':'Ocean Power Technologies','sector':'Marine energy / Defense','country':'US','exchange':'NYSE American','mcap':34_000_000,'news':['Maritime surveillance buoys','Defense ocean monitoring','Tiny cap with defense/maritime optionality'],'price_30d':5,'volume_trend':1.25,'mentions':'low','dilution':'high','reverse_splits':2,'offerings_24m':4},
 {'ticker':'ONDS','name':'Ondas Holdings','sector':'Autonomous drones / Networks','country':'US','exchange':'NASDAQ','mcap':92_000_000,'news':['Autonomous drone platform','Industrial private wireless','Multi-unit drone opportunity'],'price_30d':11,'volume_trend':1.45,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'LIDR','name':'AEye','sector':'LiDAR / Autonomy','country':'US','exchange':'NASDAQ','mcap':45_000_000,'news':['Automotive lidar pipeline','Industrial sensing applications'],'price_30d':-8,'volume_trend':1.1,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':3},
 {'ticker':'MVIS','name':'MicroVision','sector':'LiDAR / Automotive sensors','country':'US','exchange':'NASDAQ','mcap':260_000_000,'news':['ADAS sensor narrative','Strategic alternatives discussion'],'price_30d':14,'volume_trend':1.4,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'ASTI','name':'Ascent Solar Technologies','sector':'Thin-film solar / Space','country':'US','exchange':'NASDAQ','mcap':55_000_000,'news':['Lightweight solar modules','Aerospace/space application potential','Solar-space narrative still early'],'price_30d':9,'volume_trend':1.3,'mentions':'low','dilution':'high','reverse_splits':3,'offerings_24m':5},
 {'ticker':'BBAI','name':'BigBear.ai','sector':'AI / Defense analytics','country':'US','exchange':'NYSE','mcap':1_200_000_000,'news':['AI defense analytics','Government contract narrative'],'price_30d':28,'volume_trend':1.9,'mentions':'high','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'SOUN','name':'SoundHound AI','sector':'Voice AI','country':'US','exchange':'NASDAQ','mcap':3_100_000_000,'news':['Enterprise voice AI adoption','Automotive assistant traction'],'price_30d':39,'volume_trend':2.2,'mentions':'high','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'REKR','name':'Rekor Systems','sector':'AI infrastructure / Public safety','country':'US','exchange':'NASDAQ','mcap':180_000_000,'news':['Roadway intelligence platform','Public sector AI analytics','AI infrastructure laggard vs bigger AI names'],'price_30d':6,'volume_trend':1.28,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'KSCP','name':'Knightscope','sector':'Security robotics','country':'US','exchange':'NASDAQ','mcap':30_000_000,'news':['Autonomous security robots','Recurring security contracts','Robotics narrative but execution risk high'],'price_30d':-12,'volume_trend':0.95,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':4},
 {'ticker':'AISP','name':'Airship AI','sector':'AI video analytics','country':'US','exchange':'NASDAQ','mcap':140_000_000,'news':['Edge AI surveillance','Government/enterprise analytics','AI video analytics narrative early'],'price_30d':16,'volume_trend':1.55,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'GEVO','name':'Gevo','sector':'Sustainable aviation fuel','country':'US','exchange':'NASDAQ','mcap':420_000_000,'news':['SAF plant financing','Airline offtake agreements'],'price_30d':-2,'volume_trend':1.05,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'UUUU','name':'Energy Fuels','sector':'Uranium / Rare earths','country':'US/Canada','exchange':'NYSE American/TSX','mcap':1_050_000_000,'news':['Uranium cycle strength','Rare earth processing'],'price_30d':13,'volume_trend':1.3,'mentions':'medium','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'UEC','name':'Uranium Energy','sector':'Uranium','country':'US/Canada','exchange':'NYSE American','mcap':2_600_000_000,'news':['Uranium restart optionality','US nuclear fuel narrative'],'price_30d':15,'volume_trend':1.35,'mentions':'medium','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'HYSR','name':'SunHydrogen','sector':'Hydrogen research','country':'US','exchange':'OTC','mcap':65_000_000,'news':['Green hydrogen prototype','Research milestone watch'],'price_30d':4,'volume_trend':1.15,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':4},
 {'ticker':'CYBN','name':'Cybin','sector':'Biotech / Neuropsychiatry','country':'Canada/US','exchange':'NYSE American/NEO','mcap':370_000_000,'news':['Clinical-stage neuropsychiatry pipeline','Trial catalyst watch'],'price_30d':7,'volume_trend':1.25,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ATOS','name':'Atossa Therapeutics','sector':'Biotech / Oncology','country':'US','exchange':'NASDAQ','mcap':150_000_000,'news':['Breast cancer therapy trials','Clinical catalyst watch'],'price_30d':3,'volume_trend':1.1,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'TNYA','name':'Tenaya Therapeutics','sector':'Biotech / Gene therapy','country':'US','exchange':'NASDAQ','mcap':220_000_000,'news':['Cardiac gene therapy pipeline','Clinical readout watch'],'price_30d':-6,'volume_trend':1.05,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'EOSE','name':'Eos Energy Enterprises','sector':'Grid storage','country':'US','exchange':'NASDAQ','mcap':1_400_000_000,'news':['Long-duration storage demand','US manufacturing support'],'price_30d':26,'volume_trend':1.75,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'ABAT','name':'American Battery Technology','sector':'Battery recycling / Lithium','country':'US','exchange':'NASDAQ','mcap':120_000_000,'news':['Battery recycling ramp','Lithium resource development','Circular battery supply chain narrative'],'price_30d':10,'volume_trend':1.32,'mentions':'low','dilution':'medium','reverse_splits':1,'offerings_24m':2},
]


# Extra global nano/microcap universe: Canada/CSE/TSXV, UK AIM/LSE, Australia ASX, Europe/Euronext.
# These are not recommendations. They exist to force the scanner outside US/NASDAQ and surface lower-mcap research candidates.
UNIVERSE.extend([
 {'ticker':'FLT','name':'Volatus Aerospace','sector':'Drones / Defense services','country':'Canada','exchange':'TSXV','yahoo':['FLT.V','FLT.TO'],'mcap':42_000_000,'news':['Drone services and defense/security demand','Canadian listed smallcap drone exposure','Potential contracts can move a small valuation fast'],'price_30d':4,'volume_trend':1.22,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'NILI','name':'Surge Battery Metals','sector':'Lithium exploration','country':'Canada','exchange':'TSXV/OTC','yahoo':['NILI.V','NILIF'],'mcap':86_000_000,'news':['Lithium resource development','Battery supply chain narrative','Exploration/resource update optionality'],'price_30d':-2,'volume_trend':1.08,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'GRID','name':'Tantalus Systems','sector':'Grid intelligence / Utilities software','country':'Canada','exchange':'TSX','yahoo':['GRID.TO'],'mcap':58_000_000,'news':['Smart grid modernization','Utility software adoption','Tiny Canadian grid-tech candidate'],'price_30d':3,'volume_trend':1.16,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'QNC','name':'Quantum eMotion','sector':'Quantum cybersecurity','country':'Canada','exchange':'TSXV/OTC','yahoo':['QNC.V','QNCCF'],'mcap':30_000_000,'news':['Quantum cybersecurity narrative','Low coverage Canadian quantum exposure','Potential IP/cybersecurity catalyst'],'price_30d':6,'volume_trend':1.18,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'TAU','name':'Thesis Gold','sector':'Gold exploration','country':'Canada','exchange':'TSXV/OTC','yahoo':['TAU.V','THSGF'],'mcap':88_000_000,'news':['Resource expansion drilling','Gold cycle optionality','Explorer re-rating possible on strong drill results'],'price_30d':1,'volume_trend':1.06,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ARCM','name':'Arc Minerals','sector':'Copper exploration','country':'UK/Zambia','exchange':'AIM','yahoo':['ARCM.L'],'mcap':30_000_000,'news':['Copper exploration optionality','Major-partner/resource catalyst watch','Very low UK AIM coverage'],'price_30d':-4,'volume_trend':1.05,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'KOD','name':'Kodal Minerals','sector':'Lithium / Mining development','country':'UK/Mali','exchange':'AIM','yahoo':['KOD.L'],'mcap':120_000_000,'news':['Lithium development project','Project financing/development milestones','AIM battery-materials exposure'],'price_30d':8,'volume_trend':1.2,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'ATM','name':'Andrada Mining','sector':'Tin / Lithium / Tantalum','country':'UK/Namibia','exchange':'AIM','yahoo':['ATM.L'],'mcap':70_000_000,'news':['Critical minerals narrative','Tin/lithium/tantalum optionality','Production ramp and resource update watch'],'price_30d':2,'volume_trend':1.12,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'GGP','name':'Greatland Gold','sector':'Gold / Copper development','country':'UK/Australia','exchange':'AIM','yahoo':['GGP.L'],'mcap':410_000_000,'news':['Gold/copper project development','Resource and development milestones','UK retail attention moderate but not US-pumped'],'price_30d':6,'volume_trend':1.18,'mentions':'medium','dilution':'medium','reverse_splits':0,'offerings_24m':1},
 {'ticker':'LKE','name':'Lake Resources','sector':'Lithium development','country':'Australia/Argentina','exchange':'ASX/OTC','yahoo':['LKE.AX','LLKKF'],'mcap':85_000_000,'news':['Direct lithium extraction narrative','Project financing/offtake catalyst watch','ASX lithium smallcap turnaround candidate'],'price_30d':-5,'volume_trend':1.1,'mentions':'medium','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'ASN','name':'Anson Resources','sector':'Lithium / Brine development','country':'Australia/US','exchange':'ASX/OTC','yahoo':['ASN.AX','ANSNF'],'mcap':95_000_000,'news':['US lithium brine project','Battery minerals optionality','Permitting/resource catalyst watch'],'price_30d':3,'volume_trend':1.14,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'IXR','name':'Ionic Rare Earths','sector':'Rare earths / Recycling','country':'Australia/UK/Uganda','exchange':'ASX','yahoo':['IXR.AX'],'mcap':62_000_000,'news':['Rare earth supply chain narrative','Magnet recycling optionality','Western critical minerals theme'],'price_30d':2,'volume_trend':1.12,'mentions':'low','dilution':'medium','reverse_splits':0,'offerings_24m':2},
 {'ticker':'4DS','name':'4DS Memory','sector':'Semiconductor memory','country':'Australia','exchange':'ASX','yahoo':['4DS.AX'],'mcap':52_000_000,'news':['Next-gen memory R&D','Semiconductor optionality','High-risk IP milestone candidate'],'price_30d':7,'volume_trend':1.24,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'ALM','name':'Alma Gold','sector':'Gold exploration','country':'Europe/Canada','exchange':'CSE','yahoo':['ALMA.CN'],'mcap':12_000_000,'news':['Very low mcap gold explorer','Resource/drill-result optionality','Microcap exploration risk very high'],'price_30d':0,'volume_trend':0.95,'mentions':'low','dilution':'high','reverse_splits':0,'offerings_24m':3},
 {'ticker':'MGA','name':'Mega Uranium','sector':'Uranium holdings / Exploration','country':'Canada/Australia','exchange':'TSX','yahoo':['MGA.TO'],'mcap':150_000_000,'news':['Uranium cycle exposure','Asset/holding revaluation potential','Not NASDAQ, lower coverage uranium angle'],'price_30d':5,'volume_trend':1.14,'mentions':'low','dilution':'low','reverse_splits':0,'offerings_24m':0},
 {'ticker':'POND','name':'Pond Technologies','sector':'Carbon capture / Algae biotech','country':'Canada','exchange':'TSXV','yahoo':['POND.V'],'mcap':9_000_000,'news':['Carbon capture / algae platform','Very low valuation optionality','Needs funding and commercial validation'],'price_30d':-7,'volume_trend':1.02,'mentions':'low','dilution':'high','reverse_splits':1,'offerings_24m':4},
])

MCAP_CACHE: Dict[str, Any] = {}
BROKER_CACHE: Dict[str, Any] = {}

# ----------------------- helpers -----------------------
def _safe_num(v):
    try:
        if v is None: return None
        x = float(v)
        return x if x > 0 else None
    except Exception:
        return None

def fmt_mcap(m):
    if not m: return 'Onbekend'
    if m >= 1_000_000_000: return f"${m/1_000_000_000:.2f}B"
    return f"${m/1_000_000:.1f}M"

def classify_mcap(m):
    if not m: return 'onbekend'
    if m < 50_000_000: return 'nano/microcap'
    if m < 300_000_000: return 'microcap'
    if m < 2_000_000_000: return 'smallcap'
    return 'groter dan echte microcap'

def clamp(x, lo=0, hi=100): return max(lo, min(hi, float(x)))

def yahoo_market_cap(ticker: str):
    if os.getenv('MCAP_LIVE_ENABLED','true').lower() != 'true': return None
    t = ticker.upper().strip(); cached = MCAP_CACHE.get(t)
    if cached and time.time() - cached.get('ts',0) < 15*60: return cached.get('value')
    try:
        r = requests.get('https://query1.finance.yahoo.com/v7/finance/quote', params={'symbols':t}, headers={'User-Agent':'Mozilla/5.0 StockGemEngine/1.0'}, timeout=8)
        if r.status_code != 200:
            log(f'mcap_yahoo_http ticker={t} status={r.status_code}'); return None
        data = r.json().get('quoteResponse',{}).get('result',[])
        if not data: return None
        row = data[0]
        mcap = _safe_num(row.get('marketCap'))
        price = _safe_num(row.get('regularMarketPrice'))
        shares = _safe_num(row.get('sharesOutstanding') or row.get('impliedSharesOutstanding'))
        if mcap is None and price and shares: mcap = price * shares
        if mcap and mcap > 500_000:
            MCAP_CACHE[t] = {'ts': time.time(), 'value': mcap}
            return mcap
    except Exception as e:
        log(f'mcap_yahoo_error ticker={t} err={str(e)[:150]}')
    return None

def live_market_cap(item):
    curated = _safe_num(item.get('mcap'))
    live = None
    yahoo_symbols = item.get('yahoo') or [item['ticker']]
    if isinstance(yahoo_symbols, str): yahoo_symbols = [yahoo_symbols]
    for ysym in yahoo_symbols:
        live = yahoo_market_cap(ysym)
        if live: break
    if live:
        if curated and (live > curated*1.8 or live < curated*0.55): log(f'mcap_override ticker={item["ticker"]} curated={curated:.0f} live={live:.0f}')
        return float(live), 'yahoo_live_marketcap', 'high'
    if curated: return float(curated), 'curated_fallback_no_live', 'low'
    return None, 'missing', 'low'

# ----------------------- broker checks -----------------------
def ibkr_check(ticker, exchange):
    url = os.getenv('IBKR_GATEWAY_URL','').rstrip('/')
    if not url: return {'status':'not_configured','label':'IBKR API nog niet gekoppeld','route':None,'detail':'Zodra Client Portal Gateway draait, vult de tool dit live.'}
    try:
        verify = os.getenv('IBKR_VERIFY_SSL','false').lower() == 'true'
        r = requests.get(f"{url}/iserver/secdef/search", params={'symbol':ticker}, timeout=6, verify=verify)
        if r.status_code == 200:
            rows = r.json() if isinstance(r.json(), list) else []
            for row in rows:
                if str(row.get('symbol','')).upper() == ticker.upper():
                    return {'status':'verified','label':'IBKR verified','route':f"{ticker} / conid {row.get('conid','?')}", 'detail':row.get('companyName') or row.get('description') or 'gevonden via IBKR'}
            return {'status':'not_found','label':'Niet gevonden op IBKR','route':None,'detail':'Geen exacte ticker-match.'}
        return {'status':'api_error','label':'IBKR API fout','route':None,'detail':f'HTTP {r.status_code}'}
    except Exception as e: return {'status':'api_error','label':'IBKR niet bereikbaar','route':None,'detail':str(e)[:120]}

def saxo_check(ticker, exchange):
    token = os.getenv('SAXO_ACCESS_TOKEN','')
    base = os.getenv('SAXO_BASE_URL','https://gateway.saxobank.com/sim/openapi').rstrip('/')
    if not token: return {'status':'not_configured','label':'Saxo API nog niet gekoppeld','route':None,'detail':'Vul SAXO_ACCESS_TOKEN in na OpenAPI setup.'}
    try:
        r = requests.get(f"{base}/ref/v1/instruments", params={'Keywords':ticker,'AssetTypes':'Stock','$top':10}, headers={'Authorization':f'Bearer {token}'}, timeout=8)
        if r.status_code == 200:
            for row in r.json().get('Data', []):
                sym = str(row.get('Symbol','')).upper()
                if sym == ticker.upper() or ticker.upper() in sym:
                    exch = row.get('ExchangeId') or row.get('Exchange') or ''
                    return {'status':'verified','label':'Saxo verified','route':f"{sym}:{exch}" if exch else sym, 'detail':row.get('Description') or 'gevonden via Saxo'}
            return {'status':'not_found','label':'Niet gevonden op Saxo','route':None,'detail':'Geen exacte ticker-match.'}
        return {'status':'api_error','label':'Saxo API fout','route':None,'detail':f'HTTP {r.status_code}'}
    except Exception as e: return {'status':'api_error','label':'Saxo niet bereikbaar','route':None,'detail':str(e)[:120]}

def broker_availability(ticker, exchange):
    key = ticker+'|'+exchange; now = time.time(); cached = BROKER_CACHE.get(key)
    if cached and now - cached['ts'] < 900: return cached['data']
    data = {
        'ibkr': ibkr_check(ticker, exchange),
        'saxo': saxo_check(ticker, exchange),
        'degiro': {'status':'unsupported','label':'Geen officiële DEGIRO API','route':None,'detail':'Niet als exact koopbaar tonen zonder officiële API.'},
        'trading212': {'status':'planned','label':'Trading 212 later','route':None,'detail':'Later via officiële instrument list/API.'}
    }
    BROKER_CACHE[key] = {'ts':now,'data':data}; return data

# ----------------------- alpha engines -----------------------
def sector_heat(item):
    s = (item['sector'] + ' ' + ' '.join(item.get('news',[]))).lower()
    heat = 45
    for kw, pts in [('defense',20),('drone',18),('ai',18),('quantum',18),('uranium',14),('battery',13),('space',16),('robot',16),('clinical',12),('biotech',10),('lithium',11),('grid storage',12)]:
        if kw in s: heat += pts
    return clamp(heat,0,100)

def hype_score(item, mcap):
    mentions = item.get('mentions','low')
    mention_pts = {'low':5,'medium':22,'high':45}.get(mentions,15)
    price_pts = max(0, min(35, item.get('price_30d',0) * 0.8))
    bigcap_pts = 12 if mcap and mcap > 1_000_000_000 else 0
    return clamp(mention_pts + price_pts + bigcap_pts,0,100)

def accumulation_score(item):
    vt = float(item.get('volume_trend',1.0)); p = float(item.get('price_30d',0))
    score = 42 + (vt-1.0)*38
    if -10 <= p <= 18: score += 18
    if p > 35: score -= 22
    if item.get('mentions') == 'low': score += 10
    return clamp(score)

def dilution_risk_score(item):
    base = {'low':18,'medium':48,'high':78}.get(item.get('dilution','medium'),48)
    base += int(item.get('reverse_splits',0))*8 + int(item.get('offerings_24m',0))*5
    return clamp(base)

def scam_label(dilution, hype, mcap):
    if dilution >= 82 and (mcap or 0) < 100_000_000: return 'HIGH - dilution/penny-stock risk'
    if dilution >= 65 or hype >= 70: return 'MEDIUM/HIGH - streng controleren'
    if dilution >= 45: return 'MEDIUM - financing controleren'
    return 'LOW/MED - geen obvious red flag in scan'

def catalyst_timeline(item):
    news = item.get('news',[])
    return [
        {'when':'6m-3m geleden','event':'Sector/narrative begint te bewegen', 'why':'De tool ziet dit als achtergrondwind, nog geen koopreden op zichzelf.'},
        {'when':'1m geleden','event':news[0] if news else 'Eerste signaal zichtbaar', 'why':'Eerste materiaal signaal om verder te onderzoeken.'},
        {'when':'Nu','event':news[1] if len(news)>1 else 'Gem score wordt opnieuw berekend', 'why':'Combinatie van lage mcap, narrative en hype-filter wordt gemeten.'},
        {'when':'Volgende check','event':'Filings, cash runway, broker availability en echte contractwaarde controleren', 'why':'Hiermee scheid je echte gems van PR/pump rommel.'},
    ]

def score_item(item):
    mcap, src, conf = live_market_cap(item)
    cap_factor = 0.45 if not mcap else clamp((650_000_000 - min(mcap,650_000_000)) / 650_000_000 * 100) / 100
    # Global edge: non-US/non-NASDAQ low-coverage names get a small discovery boost so the list is not NASDAQ-only.
    global_boost = 8 if ('NASDAQ' not in item.get('exchange','').upper() and item.get('mentions') == 'low') else 0
    nano_boost = 10 if (mcap and mcap < 75_000_000 and 'NASDAQ' not in item.get('exchange','').upper()) else 0
    narrative = sector_heat(item)
    accum = accumulation_score(item)
    hype = hype_score(item, mcap)
    dilution = dilution_risk_score(item)
    early = clamp(0.42*narrative + 0.38*accum + 20*cap_factor + global_boost + nano_boost)
    hidden = clamp(0.40*early + 0.35*(100-hype) + 0.25*(100-dilution))
    risk = clamp(0.55*dilution + 0.30*hype + (15 if (mcap and mcap < 75_000_000) else 5))
    gem = clamp(0.48*hidden + 0.35*early + 0.17*(100-risk))
    conviction = clamp(0.40*gem + 0.30*hidden + 0.20*accum + 0.10*(100-hype) - max(0,dilution-70)*0.25) / 10
    if conviction >= 8.5: clabel='Extreme asymmetric candidate'
    elif conviction >= 7.4: clabel='High conviction watchlist'
    elif conviction >= 6.2: clabel='Medium conviction'
    else: clabel='Low / too early'
    return {
        'mcap':mcap, 'mcap_source':src, 'mcap_confidence':conf,
        'gem_score':round(gem,1), 'early_signal':round(early,1), 'hype_risk':round(hype,1), 'risk_score':round(risk,1),
        'hidden_score':round(hidden,1), 'accumulation_score':round(accum,1), 'narrative_score':round(narrative,1),
        'dilution_risk_score':round(dilution,1), 'conviction_score':round(conviction,1),
        'conviction_label':clabel, 'scam_risk_label':scam_label(dilution,hype,mcap)
    }

# ----------------------- AI analyst -----------------------
def _ai_provider_config(provider: str):
    provider = (provider or '').lower()
    if provider == 'openai': return {'provider':'openai','key':OPENAI_API_KEY,'base':OPENAI_BASE_URL,'model':OPENAI_MODEL,'missing':'openai_not_configured'}
    if provider == 'deepseek': return {'provider':'deepseek','key':DEEPSEEK_API_KEY,'base':DEEPSEEK_BASE_URL,'model':DEEPSEEK_MODEL,'missing':'deepseek_not_configured'}
    return {'provider':provider or 'none','key':'','base':'','model':'','missing':'ai_provider_unknown'}

def _parse_ai_json(content: str):
    content = (content or '').strip()
    if content.startswith('```'):
        content = content.strip('`').strip()
        if content.lower().startswith('json'): content = content[4:].strip()
    start = content.find('{'); end = content.rfind('}')
    if start >= 0 and end > start: content = content[start:end+1]
    return json.loads(content)

def _call_ai_provider(provider: str, prompt: str, ticker: str):
    cfg = _ai_provider_config(provider)
    if not cfg['key']: return None, cfg['missing']
    payload = {
        'model': cfg['model'],
        'messages': [
            {'role':'system','content':'Je bent een strenge smallcap hedge-fund analyst. Geen koopadvies. Antwoord uitsluitend als geldige JSON in makkelijke Nederlandse taal.'},
            {'role':'user','content':prompt}
        ],
        'temperature': 0.15,
        'max_tokens': 1400
    }
    r = requests.post(f"{cfg['base']}/chat/completions", headers={'Authorization':f"Bearer {cfg['key']}", 'Content-Type':'application/json'}, json=payload, timeout=55)
    if r.status_code != 200:
        log(f'ai_http_error provider={cfg["provider"]} ticker={ticker} status={r.status_code} body={r.text[:220]}')
        return None, f'{cfg["provider"]}_http_{r.status_code}'
    return _parse_ai_json(r.json()['choices'][0]['message']['content']), f'{cfg["provider"]}_{cfg["model"]}'

def ai_investor_analysis(item, scores, timeline):
    if not AI_ENABLED: return None, 'ai_disabled'
    prompt = f'''
Analyseer dit aandeel alsof je Stijn helpt hidden gems te vinden VOOR de hype/pump.
Geen koopadvies. Wees streng. Gebruik makkelijke taal. Hallucineer geen feiten; als iets onzeker is, zeg dat het gecontroleerd moet worden.

Ticker: {item['ticker']}
Naam: {item['name']}
Sector: {item['sector']}
Land/beurs: {item['country']} / {item['exchange']}
Market cap: {fmt_mcap(scores['mcap'])}, bron {scores['mcap_source']}, confidence {scores['mcap_confidence']}
Signals: price_30d={item.get('price_30d')}%, volume_trend={item.get('volume_trend')}x, social_mentions={item.get('mentions')}, dilution={item.get('dilution')}, reverse_splits={item.get('reverse_splits')}, offerings_24m={item.get('offerings_24m')}
Scores: Gem {scores['gem_score']}/100, Hidden {scores['hidden_score']}/100, Accumulation {scores['accumulation_score']}/100, Narrative {scores['narrative_score']}/100, Hype Risk {scores['hype_risk']}/100, Dilution Risk {scores['dilution_risk_score']}/100, Conviction {scores['conviction_score']}/10
Nieuws/signalen: {'; '.join(item.get('news', []))}
Timeline: {json.dumps(timeline, ensure_ascii=False)}

Geef JSON met exact deze keys:
company_plain: 2 zinnen wat het bedrijf doet.
hidden_gem_thesis: waarom dit vóór hype interessant kan zijn.
bull_case: concrete bull-case, inclusief welke katalysator rerating kan geven.
bear_case: concrete bear-case, vooral dilution, cash runway, liquiditeit, reverse split, offering/pump risk.
scam_dilution_check: duidelijke rode vlaggen/checklist.
catalyst_map: lijst met 3-5 concrete katalysatoren of bewijsstukken die Stijn moet volgen.
what_to_verify_next: lijst met 5 concrete checks vóór hij geld riskeert.
verdict: Strong Gem Candidate, High-Risk Watchlist, Too Early, Avoid.
confidence: getal 0-100 voor betrouwbaarheid van deze analyse op basis van data.
plain_reason: 1 korte zin waarom aantrekkelijk óf waarom oppassen.
'''
    last = 'ai_not_configured'; tried=[]
    for provider in [AI_PROVIDER, AI_FALLBACK_PROVIDER]:
        if not provider or provider == 'none' or provider in tried: continue
        tried.append(provider)
        try:
            data, source = _call_ai_provider(provider, prompt, item['ticker'])
            if data: return data, source
            last = source
        except Exception as e:
            last = f'{provider}_error'; log(f'ai_error provider={provider} ticker={item.get("ticker")} err={str(e)[:180]}')
    return None, last

def fallback_analysis(item, scores, timeline):
    return {
      'company_plain': f"{item['name']} ({item['ticker']}) is een {classify_mcap(scores['mcap'])} binnen {item['sector']}. De tool ziet dit als vroeg research-aandeel: interessant om te onderzoeken, niet automatisch koopwaardig.",
      'hidden_gem_thesis': f"De combinatie van {fmt_mcap(scores['mcap'])} market cap, Hidden Score {scores['hidden_score']}/100 en Hype Risk {scores['hype_risk']}/100 suggereert dat het aandeel mogelijk nog vóór brede hype zit.",
      'bull_case': 'Bull case: als de genoemde katalysatoren echte omzet/contractwaarde opleveren, kan de markt het aandeel opnieuw waarderen.',
      'bear_case': 'Bear case: microcaps kunnen verwateren, lage liquiditeit hebben of vooral PR maken zonder harde omzet. Controleer filings en cash runway.',
      'scam_dilution_check': f"Dilution risk {scores['dilution_risk_score']}/100; reverse splits {item.get('reverse_splits')}; offerings 24m {item.get('offerings_24m')}.",
      'catalyst_map': item.get('news', [])[:5],
      'what_to_verify_next': ['Laatste 10-Q/10-K cash runway', 'Aantal shares outstanding', 'Recente offerings/S-3/ATM', 'Echte contractwaarde', 'Gemiddeld volume/liquiditeit'],
      'verdict': 'High-Risk Watchlist' if scores['dilution_risk_score'] > 65 else ('Strong Gem Candidate' if scores['conviction_score'] >= 7.5 else 'Too Early'),
      'confidence': 55,
      'plain_reason': 'Interessant als vroege watchlist, maar eerst filings en dilution controleren.'
    }

def build_texts(ai, scores, source):
    company = ai.get('company_plain','')
    why = f"{ai.get('hidden_gem_thesis','')}\n\nBull case: {ai.get('bull_case','')}"
    catalyst = 'Catalyst map: ' + '; '.join(ai.get('catalyst_map',[]) if isinstance(ai.get('catalyst_map'), list) else [str(ai.get('catalyst_map',''))])
    verify = ai.get('what_to_verify_next', [])
    if isinstance(verify, list): catalyst += '\n\nVolgende checks: ' + '; '.join(verify)
    risk = f"Bear case: {ai.get('bear_case','')}\n\nScam/dilution check: {ai.get('scam_dilution_check','')}\n\nVerdict: {ai.get('verdict','Watchlist')} · AI confidence {ai.get('confidence',0)} · Bron: {source}. Geen koopadvies."
    return company, why, catalyst, risk

# ----------------------- scan runtime -----------------------
def send_ntfy(gem):
    try:
        title = f"🚨 New Gem: {gem['ticker']} · {gem['conviction_score']:.1f}/10"
        msg = f"{gem['ticker']} · {gem['name']}\nMCap: {fmt_mcap(gem['mcap_usd'])}\nConviction: {gem['conviction_label']}\nVerdict: {gem.get('ai_verdict') or 'Watchlist'}\nWaarom: {gem['why_attractive'][:260]}\nhttp://51.195.102.180:8791"
        requests.post(f'https://ntfy.sh/{NTFY_TOPIC}', data=msg.encode('utf-8'), headers={'Title':title, 'Priority':'default'}, timeout=5)
        return True
    except Exception as e: log(f'ntfy_error {e}'); return False

def run_scan(manual=False):
    if state['running']: return {'ok':False,'message':'scan draait al'}
    state['running'] = True; state['error'] = None
    alerts = 0; count = 0; ai_used = 0
    try:
        con = db(); now = datetime.now(timezone.utc).isoformat()
        scored = []
        for item in UNIVERSE:
            scores = score_item(item)
            scored.append((item, scores))
        scored.sort(key=lambda x: (x[1]['conviction_score'], x[1]['gem_score']), reverse=True)
        ai_budget = AI_MAX_PER_SCAN
        for item, scores in scored:
            timeline = catalyst_timeline(item)
            use_ai = False  # v1.0.1 safe mode: no paid AI/API calls
            if use_ai:
                ai, ai_source = ai_investor_analysis(item, scores, timeline)
                if ai: ai_used += 1; ai_budget -= 1
                else: ai, ai_source = fallback_analysis(item, scores, timeline), ai_source
            else:
                ai, ai_source = fallback_analysis(item, scores, timeline), 'rule_engine_not_ai_priority'
            company, why, catalyst, risk_txt = build_texts(ai, scores, ai_source)
            brokers = broker_availability(item['ticker'], item['exchange'])
            existing = con.execute('SELECT alerted FROM gems WHERE ticker=?',(item['ticker'],)).fetchone()
            should_alert = (not existing or existing['alerted']==0) and scores['conviction_score'] >= 7.6 and scores['hype_risk'] <= 55 and scores['dilution_risk_score'] < 85
            if should_alert: alerts += 1
            next_level = {
                'hidden_gem': scores['hidden_score'], 'accumulation': scores['accumulation_score'], 'narrative': scores['narrative_score'],
                'dilution': scores['dilution_risk_score'], 'price_30d': item.get('price_30d'), 'volume_trend': item.get('volume_trend'),
                'mentions': item.get('mentions'), 'reverse_splits': item.get('reverse_splits'), 'offerings_24m': item.get('offerings_24m'),
                'plain_reason': ai.get('plain_reason','')
            }
            con.execute('''INSERT INTO gems(
              ticker,name,sector,country,exchange,mcap_usd,mcap_source,mcap_confidence,gem_score,early_signal,hype_risk,risk_score,
              hidden_score,accumulation_score,narrative_score,dilution_risk_score,conviction_score,conviction_label,scam_risk_label,ai_source,ai_verdict,ai_confidence,
              company_short,why_attractive,risk_plain,catalyst_plain,broker_json,news_json,timeline_json,ai_json,next_level_json,first_seen,last_seen,alerted)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(ticker) DO UPDATE SET
              name=excluded.name,sector=excluded.sector,country=excluded.country,exchange=excluded.exchange,mcap_usd=excluded.mcap_usd,mcap_source=excluded.mcap_source,mcap_confidence=excluded.mcap_confidence,
              gem_score=excluded.gem_score,early_signal=excluded.early_signal,hype_risk=excluded.hype_risk,risk_score=excluded.risk_score,hidden_score=excluded.hidden_score,accumulation_score=excluded.accumulation_score,narrative_score=excluded.narrative_score,dilution_risk_score=excluded.dilution_risk_score,conviction_score=excluded.conviction_score,conviction_label=excluded.conviction_label,scam_risk_label=excluded.scam_risk_label,ai_source=excluded.ai_source,ai_verdict=excluded.ai_verdict,ai_confidence=excluded.ai_confidence,company_short=excluded.company_short,why_attractive=excluded.why_attractive,risk_plain=excluded.risk_plain,catalyst_plain=excluded.catalyst_plain,broker_json=excluded.broker_json,news_json=excluded.news_json,timeline_json=excluded.timeline_json,ai_json=excluded.ai_json,next_level_json=excluded.next_level_json,last_seen=excluded.last_seen,alerted=CASE WHEN gems.alerted=1 THEN 1 ELSE excluded.alerted END''',
              (item['ticker'],item['name'],item['sector'],item['country'],item['exchange'],scores['mcap'],scores['mcap_source'],scores['mcap_confidence'],scores['gem_score'],scores['early_signal'],scores['hype_risk'],scores['risk_score'],scores['hidden_score'],scores['accumulation_score'],scores['narrative_score'],scores['dilution_risk_score'],scores['conviction_score'],scores['conviction_label'],scores['scam_risk_label'],ai_source,ai.get('verdict'),_safe_num(ai.get('confidence')),company,why,risk_txt,catalyst,json.dumps(brokers,ensure_ascii=False),json.dumps(item.get('news',[]),ensure_ascii=False),json.dumps(timeline,ensure_ascii=False),json.dumps(ai,ensure_ascii=False),json.dumps(next_level,ensure_ascii=False),now,now,1 if should_alert else 0))
            count += 1
        con.execute('INSERT INTO scan_runs(ts,count,alerts,note,ai_used) VALUES(?,?,?,?,?)',(now,count,alerts,'manual' if manual else 'auto',ai_used))
        con.commit(); con.close()
        state.update({'last_scan':now,'last_alerts':alerts,'last_ai_used':ai_used})
        if alerts:
            con = db()
            for row in con.execute('SELECT * FROM gems WHERE alerted=1 ORDER BY conviction_score DESC LIMIT 3').fetchall(): send_ntfy(dict(row))
            con.close()
        log(f'scan_complete count={count} alerts={alerts} ai_used={ai_used} manual={manual}')
        return {'ok':True,'count':count,'alerts':alerts,'ai_used':ai_used}
    except Exception as e:
        state['error'] = str(e); log(f'scan_error {e}'); return {'ok':False,'error':str(e)}
    finally:
        state['running'] = False

def scheduler_loop():
    log(f'scheduler_started enabled={AUTO_SCAN_ENABLED} interval={SCAN_INTERVAL_MINUTES}')
    while True:
        try:
            if AUTO_SCAN_ENABLED:
                con = db(); n = con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; con.close()
                if n == 0: run_scan(False)
                time.sleep(SCAN_INTERVAL_MINUTES*60); run_scan(False)
            else: time.sleep(60)
        except Exception as e: log(f'scheduler_error {e}'); time.sleep(60)

@app.on_event('startup')
def startup(): threading.Thread(target=scheduler_loop, daemon=True).start()

# ----------------------- API -----------------------
@app.get('/api/ai/test')
def api_ai_test():
    cfg = _ai_provider_config(AI_PROVIDER)
    if not AI_ENABLED: return {'ok':False,'provider':AI_PROVIDER,'message':'AI_ENABLED=false'}
    if not cfg.get('key'): return {'ok':False,'provider':AI_PROVIDER,'message':cfg.get('missing')}
    try:
        data, source = _call_ai_provider(AI_PROVIDER, 'Antwoord uitsluitend als JSON: {"ok": true, "message": "AI koppeling werkt"}', 'TEST')
        return {'ok':True,'provider':AI_PROVIDER,'source':source,'response':data}
    except Exception as e: return {'ok':False,'provider':AI_PROVIDER,'message':str(e)[:220]}

@app.get('/api/status')
def api_status():
    con = db(); n = con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; con.close()
    return {'version':APP_VERSION,'gems':n,'ntfy_topic':NTFY_TOPIC,'scan_interval_minutes':SCAN_INTERVAL_MINUTES,'auto_scan':AUTO_SCAN_ENABLED,'ai_enabled':AI_ENABLED,'ai_provider':AI_PROVIDER,'ai_fallback_provider':AI_FALLBACK_PROVIDER,'openai_configured':bool(OPENAI_API_KEY),'deepseek_configured':bool(DEEPSEEK_API_KEY),'ai_configured':bool(OPENAI_API_KEY or DEEPSEEK_API_KEY),'ai_model':OPENAI_MODEL if AI_PROVIDER=='openai' else DEEPSEEK_MODEL,**state}

@app.get('/api/gems')
def api_gems():
    con = db(); rows = [dict(r) for r in con.execute('SELECT * FROM gems ORDER BY conviction_score DESC, gem_score DESC').fetchall()]; con.close()
    for r in rows:
        for key, default in [('broker_json',{}),('news_json',[]),('timeline_json',[]),('ai_json',{}),('next_level_json',{})]:
            val = r.pop(key, None)
            r[key.replace('_json','')] = json.loads(val or json.dumps(default))
    return rows

@app.post('/api/scan')
def api_scan(): return run_scan(manual=True)

@app.get('/', response_class=HTMLResponse)
def index(): return HTML

HTML = r'''<!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Stijn-Tradifi-2026</title><style>
:root{--bg:#f6f7fb;--ink:#111827;--muted:#667085;--panel:#fff;--line:#e5e7eb;--dark:#0b1020;--gold:#b7791f;--green:#0f9f6e;--red:#d92d20;--blue:#2563eb;--purple:#7c3aed}*{box-sizing:border-box}body{margin:0;background:linear-gradient(180deg,#f6f7fb,#eef2f7);color:var(--ink);font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif}.top{position:sticky;top:0;z-index:10;background:rgba(246,247,251,.86);backdrop-filter:blur(18px);border-bottom:1px solid var(--line)}.wrap{max-width:1240px;margin:0 auto;padding:18px 14px 70px}.head{display:grid;grid-template-columns:1fr auto;gap:16px;align-items:center}.eyebrow{font-size:12px;text-transform:uppercase;letter-spacing:.18em;font-weight:900;color:var(--gold)}h1{margin:.1em 0;font-size:clamp(30px,5vw,56px);letter-spacing:-.06em;line-height:.94}.sub{color:var(--muted);line-height:1.45}.actions{display:flex;gap:10px;flex-wrap:wrap}button{background:#111827;color:white;border:0;border-radius:14px;padding:13px 17px;font-weight:900;font-size:15px}.ghost{background:white;color:#111827;border:1px solid var(--line)}.dash{display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin:16px 0}.stat{background:white;border:1px solid var(--line);box-shadow:0 8px 24px rgba(16,24,40,.05);border-radius:20px;padding:15px}.stat b{font-size:23px;letter-spacing:-.04em}.panel{background:white;border:1px solid var(--line);box-shadow:0 8px 24px rgba(16,24,40,.05);border-radius:24px;padding:18px;margin:14px 0}.panel h2{margin:0 0 6px;font-size:24px;letter-spacing:-.04em}.list{display:grid;gap:16px}.gem{background:white;border:1px solid var(--line);border-radius:26px;overflow:hidden;box-shadow:0 14px 36px rgba(16,24,40,.07)}.gemHead{display:grid;grid-template-columns:1fr auto;gap:18px;padding:22px;background:linear-gradient(180deg,#fff,#fbfcff);border-bottom:1px solid var(--line)}.ticker{font-size:48px;font-weight:1000;letter-spacing:-.08em}.name{font-size:17px;color:var(--muted);line-height:1.35}.sector{font-size:18px;font-weight:900;margin:13px 0 10px}.mcap{display:flex;gap:8px;align-items:center;flex-wrap:wrap;font-size:27px;font-weight:1000}.pill{font-size:12px;font-weight:900;text-transform:uppercase;letter-spacing:.08em;border:1px solid var(--line);border-radius:999px;padding:6px 9px;background:#fff;color:var(--muted)}.scoreBox{text-align:right}.score{font-size:52px;font-weight:1000;color:#111827;letter-spacing:-.07em;line-height:.9}.scoreLabel{color:var(--muted);font-weight:800}.conv{display:inline-block;background:#ecfdf3;color:#027a48;border:1px solid #abefc6;border-radius:999px;padding:8px 11px;font-weight:900;margin-top:12px}.avoid{background:#fff1f3;color:#c01048;border-color:#fecdd6}.mid{background:#fffaeb;color:#b54708;border-color:#fedf89}.metrics{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;padding:16px 22px;border-bottom:1px solid var(--line)}.metric{background:#f8fafc;border:1px solid var(--line);border-radius:16px;padding:11px}.metric span{display:block;color:var(--muted);font-size:12px;font-weight:800}.metric b{font-size:21px}.bar{height:9px;border-radius:999px;background:#e5e7eb;overflow:hidden;margin-top:8px}.fill{height:100%;border-radius:999px;background:linear-gradient(90deg,#2563eb,#f7c948)}.fill.badfill{background:linear-gradient(90deg,#22c55e,#f97316,#ef4444)}.miniChart{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}.chartRow{background:#f8fafc;border:1px solid var(--line);border-radius:16px;padding:10px}.chartRow label{display:flex;justify-content:space-between;color:#475467;font-weight:900;font-size:12px}.body{display:grid;grid-template-columns:1.25fr .75fr;gap:16px;padding:20px}.section{background:#fbfcff;border:1px solid var(--line);border-radius:20px;padding:16px}.section h3{margin:0 0 9px;font-size:19px;letter-spacing:-.02em}.section p{margin:0 0 14px;color:#344054;line-height:1.6;font-size:15.7px;white-space:pre-line}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.timeline{display:grid;gap:9px}.time{border-left:3px solid #111827;padding-left:11px}.time b{display:block}.brokerline{display:grid;grid-template-columns:86px 1fr;gap:8px;padding:10px 0;border-bottom:1px solid var(--line)}.ok{color:var(--green);font-weight:900}.warn{color:var(--gold);font-weight:800}.bad{color:var(--red);font-weight:800}.muted{color:var(--muted)}small{display:block;color:var(--muted);line-height:1.35;margin-top:2px}ul{margin:6px 0 0;padding-left:19px;color:#344054;line-height:1.55}.dot{display:inline-block;width:9px;height:9px;border-radius:99px;background:var(--red);margin-right:7px}.dot.on{background:var(--green)}@media(max-width:980px){.dash{grid-template-columns:1fr 1fr}.metrics{grid-template-columns:1fr 1fr}.body,.grid2,.gemHead{grid-template-columns:1fr}.scoreBox{text-align:left}.head{grid-template-columns:1fr}.wrap{padding:14px 10px 50px}}
</style></head><body><div class="top"><div class="wrap"><div class="head"><div><div class="eyebrow">No-API Safe Mode · Global Alpha Engine</div><h1>Stijn-Tradifi-2026</h1><div class="sub">Hidden gems vóór de hype: wereldwijde microcaps, live/curated market caps, grafische score-analyse, catalyst timeline en dilution/scam detector.</div></div><div class="actions"><button onclick="scan()">Nieuwe scan</button><button class="ghost" onclick="load()">Vernieuwen</button></div></div></div></div><main class="wrap"><div class="dash"><div class="stat"><b id="count">0</b><div class="sub">Gems</div></div><div class="stat"><b id="last">...</b><div class="sub">Laatste scan</div></div><div class="stat"><b id="interval">...</b><div class="sub">Auto scan</div></div><div class="stat"><b id="topic">...</b><div class="sub">ntfy</div></div><div class="stat"><b id="ai">...</b><div class="sub">AI</div></div><div class="stat"><b id="aiused">...</b><div class="sub">AI analyses</div></div></div><div class="panel"><h2>Top Gems Ranking</h2><div class="sub" id="status">Laden...</div><br><span class="pill"><span id="aiDot" class="dot"></span><span id="aiLine">AI laden...</span></span></div><div class="list" id="list"></div></main><script>
function money(v){if(!v)return 'Onbekend'; if(v>=1e9)return '$'+(v/1e9).toFixed(2)+'B'; return '$'+(v/1e6).toFixed(1)+'M'}
function clsLabel(g){if(g.conviction_score>=8.5)return 'conv'; if(g.dilution_risk_score>=75||g.hype_risk>=70)return 'conv avoid'; if(g.conviction_score>=6.2)return 'conv mid'; return 'conv mid'}
function brokerStatus(b){let cls='muted'; if(b.status==='verified')cls='ok'; else if(['api_error','not_found'].includes(b.status))cls='bad'; else if(['not_configured','planned','unsupported'].includes(b.status))cls='warn'; return `<span class="${cls}">${b.label||b.status}${b.route?' · '+b.route:''}</span><small>${b.detail||''}</small>`}
function metric(label,val,bad=false){let v=Math.max(0,Math.min(100,Number(val)||0));return `<div class="metric"><span>${label}</span><b>${v.toFixed(0)}</b><div class="bar"><div class="fill ${bad?'badfill':''}" style="width:${v}%"></div></div></div>`}
function chartRow(label,val,bad=false){let v=Math.max(0,Math.min(100,Number(val)||0));return `<div class="chartRow"><label><span>${label}</span><b>${v.toFixed(0)}</b></label><div class="bar"><div class="fill ${bad?'badfill':''}" style="width:${v}%"></div></div></div>`}
async function load(){let s=await fetch('/api/status').then(r=>r.json()); count.textContent=s.gems; topic.textContent=s.ntfy_topic; interval.textContent='elk '+s.scan_interval_minutes+'m'; last.textContent=s.last_scan?new Date(s.last_scan).toLocaleTimeString():'geen'; ai.textContent='geen API'; aiused.textContent=s.last_ai_used||0; aiDot.className='dot'; aiLine.textContent='No-API safe mode · grafische rule engine · globale universe'; status.textContent=(s.running?'Scan draait...':'running: nee')+' · alerts '+(s.last_alerts||0)+' · versie '+s.version; let gems=await fetch('/api/gems').then(r=>r.json()); render(gems)}
async function scan(){status.textContent='Scan draait... Rule engine analyseert kandidaten zonder betaalde AI API.'; await fetch('/api/scan',{method:'POST'}); await load()}
function render(gems){let root=document.getElementById('list'); if(!gems.length){root.innerHTML='<div class="panel"><b>Nog geen scan.</b><div class="sub">Klik op Nieuwe scan.</div></div>';return} root.innerHTML=gems.map(g=>{let n=g.next_level||{}, broker=g.broker||{}, ai=g.ai||{}; return `<div class="gem"><div class="gemHead"><div><div class="ticker">${g.ticker}</div><div class="name">${g.name}<br>${g.country} · ${g.exchange}</div><div class="sector">${g.sector}</div><div class="mcap">${money(g.mcap_usd)} <span class="pill">${g.mcap_source} · ${g.mcap_confidence}</span></div><span class="${clsLabel(g)}">${g.conviction_label}</span></div><div class="scoreBox"><div class="score">${Number(g.conviction_score||0).toFixed(1)}</div><div class="scoreLabel">Conviction /10</div><div class="scoreLabel">Gem ${Number(g.gem_score||0).toFixed(1)}/100</div></div></div><div class="metrics">${metric('Hidden',Number(g.hidden_score||0).toFixed(0))}${metric('Accum.',Number(g.accumulation_score||0).toFixed(0))}${metric('Narrative',Number(g.narrative_score||0).toFixed(0))}${metric('Hype',g.hype_risk,true)}${metric('Dilution',g.dilution_risk_score,true)}${metric('AI conf.',g.ai_confidence)}</div><div class="body"><div class="section"><h3>Score-grafiek</h3><div class="miniChart">${chartRow('Hidden Gem',g.hidden_score)}${chartRow('Accumulation',g.accumulation_score)}${chartRow('Narrative',g.narrative_score)}${chartRow('Hype Risk',g.hype_risk,true)}${chartRow('Dilution Risk',g.dilution_risk_score,true)}${chartRow('Gem Score',g.gem_score)}</div><br><h3>Wat doet dit bedrijf?</h3><p>${g.company_short||''}</p><div class="grid2"><div><h3>Waarom aantrekkelijk?</h3><p>${g.why_attractive||''}</p></div><div><h3>Risico / scam-dilution</h3><p>${g.risk_plain||''}</p></div></div><h3>Catalyst map + volgende checks</h3><p>${g.catalyst_plain||''}</p></div><div class="section"><h3>AI verdict</h3><p><b>${g.ai_verdict||'Watchlist'}</b><br>${n.plain_reason||''}<br><span class="muted">AI bron: ${g.ai_source||'rule engine'}</span></p><h3>Timeline</h3><div class="timeline">${(g.timeline||[]).map(t=>`<div class="time"><b>${t.when}</b><span>${t.event}</span><small>${t.why}</small></div>`).join('')}</div><h3 style="margin-top:16px">Brokerroute Nederland</h3><div class="brokerline"><b>IBKR</b><div>${brokerStatus(broker.ibkr||{})}</div></div><div class="brokerline"><b>Saxo</b><div>${brokerStatus(broker.saxo||{})}</div></div><div class="brokerline"><b>DEGIRO</b><div>${brokerStatus(broker.degiro||{})}</div></div><div class="brokerline"><b>T212</b><div>${brokerStatus(broker.trading212||{})}</div></div></div></div></div>`}).join('')}
load(); setInterval(load,30000)
</script></body></html>'''
