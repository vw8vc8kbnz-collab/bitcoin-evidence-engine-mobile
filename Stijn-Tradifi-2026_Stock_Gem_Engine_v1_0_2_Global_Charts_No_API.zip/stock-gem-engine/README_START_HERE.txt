Stijn-Tradifi-2026 Stock Gem Engine v1.0.1 No-API Safe Mode

Belangrijk:
- DeepSeek/OpenAI staat uit.
- De tool gebruikt geen betaalde AI API-calls.
- Scans, ranking, market cap, brokerstatus-indicatie, ntfy en dashboard blijven werken.
- Uitleg komt uit de interne rule/alpha engine in plaats van betaalde AI.

Start/update:
bash scripts/install_or_update.sh

Dashboard:
http://SERVER-IP:8791
