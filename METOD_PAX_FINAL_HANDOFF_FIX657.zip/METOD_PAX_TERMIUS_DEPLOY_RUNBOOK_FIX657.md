# METOD/PAX FIX657 — Termius production deploy

Releasebestand: `METOD_PAX_FIX657_PRODUCTION_HARDENING_VAT_TRUTH.zip`  
SHA-256: `f13374b5289264d12ba8a247525eef5009c8abdf97a1598d633a6c310b06ace0`

## Voorwaarde

FIX657 is bewust **geen HTTP-acceptatierelease**. De installer weigert live deployment
zonder een echte HTTPS-origin en bestaande TLS-bestanden.

Zet in je Termius-shell vóór de one-shot:

```bash
export PUBLIC_ORIGIN='https://JOUW-ECHTE-PRODUCTIEHOST.NL'
export ADMIN_ORIGIN="$PUBLIC_ORIGIN"
export TLS_CERT_FILE='/pad/naar/fullchain.pem'
export TLS_KEY_FILE='/pad/naar/privkey.pem'
# Alleen nodig als je van het bestaande standaardpad afwijkt:
export ADMIN_CREDENTIALS_FILE='/etc/adzaagt/metod-pax/admin_credentials.live.json'
```

Upload daarna exact `METOD_PAX_FIX657_PRODUCTION_HARDENING_VAT_TRUTH.zip` naar dezelfde
GitHub Raw-locatie als eerdere releases, of zet:

```bash
export FIX657_URL='https://.../METOD_PAX_FIX657_PRODUCTION_HARDENING_VAT_TRUTH.zip'
```

Voer vervolgens de inhoud van `METOD_PAX_FIX657_TERMIUS_PRODUCTION_ONE_SHOT.txt` uit.

## Wat de one-shot beschermt

- controleert exacte ZIP SHA-256 vóór extractie;
- blokkeert ZIP-slip/symlinks/CSV/pyc/bak/runtime-data;
- voert regressie + production preflight uit vóór live bestanden worden aangeraakt;
- maakt een volledige appbackup;
- maakt een tarbackup van externe credentials/env/systemd/Nginx-config;
- bewaart live jobs, requests, queue, archive, backups, system, decor_media, catalogus,
  pricing en managed DXF-state via rsync-excludes;
- roept daarna pas `DEPLOY_FIX657.sh` aan;
- doet HTTPS/backend smokechecks;
- probeert bij elke fout automatisch code én externe config terug te rollen;
- draait in een aparte `bash -lc`-shell en sluit je Termius-sessie niet af bij een fout.

De echte productiehost/certificaatpaden zijn bewust niet in de release verzonnen.
