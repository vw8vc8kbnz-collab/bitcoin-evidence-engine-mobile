# Deploy v0.4.3 — port 9999 fix

Deze versie bevat een nginx-config voor poort `9999`.
Gebruik dit wanneer Safari/iPhone vraagt om `51.195.102.180` te downloaden in plaats van de app te openen.
Dat betekent dat de server op `:9999` geen normale `text/html` SPA serveert.

## Snelste server-fix

```bash
cd ~/apps/bitcoin-evidence-engine-mobile && git pull && \
rm -rf configurator-studio-v0.4.3 && unzip -o configurator-studio-v0.4.3.zip && \
cd configurator-studio-v0.4.3 && bash deploy/deploy-9999.sh && \
curl -I http://127.0.0.1:9999/ && \
curl -I http://127.0.0.1:9999/src/app.js?v=0.4.3
```

Open daarna exact:

```text
http://51.195.102.180:9999/
```

## Diagnose

```bash
sudo ss -ltnp | grep ':9999' || true
curl -I http://127.0.0.1:9999/
curl -I http://127.0.0.1:9999/index.html
curl -I http://127.0.0.1:9999/src/app.js?v=0.4.3
sudo nginx -t
sudo journalctl -u nginx -n 80 --no-pager
```

Correcte headers:

- `/` en `/index.html` moeten `Content-Type: text/html` tonen.
- `/src/app.js` moet `Content-Type: application/javascript` of `text/javascript` tonen.
