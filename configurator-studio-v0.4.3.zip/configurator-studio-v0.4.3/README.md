# Configurator Studio v0.4.3

AI-first proof-of-concept voor een no-code 3D configurator SaaS.

Belangrijkste wijzigingen in v0.4.3:

- Mobile dashboard UX/professional polish.
- Compacte sticky header met horizontale actiechips op iPhone.
- Nieuwe premium hero-sectie met duidelijkere propositie.
- Prompt-to-3D en productfoto’s-to-3D zijn nu twee professionele routekaarten.
- Minder rommelige typografie, betere spacing, betere touch targets.
- Port `9999` deploy-fix via nginx blijft aanwezig.

Gebruik `deploy/deploy-9999.sh` op de VPS.
