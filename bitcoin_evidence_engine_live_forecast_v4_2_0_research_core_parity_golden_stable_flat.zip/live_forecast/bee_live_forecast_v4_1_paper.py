#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, os, sys, time, math, tempfile, shutil, zipfile, logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional
import requests

from bee_research_core_v4_0 import decide_all, VERSION as RESEARCH_CORE_VERSION

VERSION = "v4.2.0_live_research_core_parity_golden"

ROOT = Path(__file__).resolve().parent
STATE_DIR = ROOT / "state"
EXPORT_DIR = ROOT / "debug_exports"
LOG_DIR = ROOT / "logs"
for d in [STATE_DIR, EXPORT_DIR, LOG_DIR]:
    d.mkdir(parents=True, exist_ok=True)

STATUS_PATH = STATE_DIR / "bee_status.json"
HISTORY_PATH = STATE_DIR / "bee_history.csv"
SIGNALS_PATH = STATE_DIR / "bee_signals.csv"
STATE_PATH = STATE_DIR / "bee_state.json"
LOG_PATH = LOG_DIR / "bee_live.log"

logger = logging.getLogger("bee_live")
logger.setLevel(logging.INFO)
handler = RotatingFileHandler(LOG_PATH, maxBytes=1_000_000, backupCount=3)
handler.setFormatter(logging.Formatter("%(asctime)sZ %(levelname)s %(message)s"))
logger.addHandler(handler)

def utcnow():
    return datetime.now(timezone.utc).replace(microsecond=0)

def iso(dt=None):
    return (dt or utcnow()).isoformat().replace("+00:00","Z")

def atomic_write(path: Path, data: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.remove(tmp)
        except OSError: pass
        raise

def load_json(path:Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def save_json(path:Path, obj):
    atomic_write(path, json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False))

def load_config():
    cfg=load_json(ROOT/"bee_live_config.json", {})
    if not cfg:
        cfg=load_json(ROOT/"bee_live_config.example.json", {})
    return cfg

def disk_guard(cfg):
    usage=shutil.disk_usage(str(ROOT))
    free_mb=usage.free/1024/1024
    min_mb=float(cfg.get("disk_guard_min_mb",500))
    if free_mb < min_mb:
        raise RuntimeError(f"LOW_DISK_SPACE free_mb={free_mb:.1f} min_mb={min_mb}")
    return free_mb

def validate_ntfy_topic(cfg):
    topic=str(cfg.get("ntfy_topic","")).strip()
    bad = (not topic or "PASTE" in topic or "your-secret-topic" in topic or "YOUR" in topic)
    if bad:
        raise RuntimeError("ntfy_topic missing/placeholder")
    return topic

def fetch_binance_klines(interval="1h", limit=999):
    url="https://api.binance.com/api/v3/klines"
    r=requests.get(url, params={"symbol":"BTCUSDT","interval":interval,"limit":limit}, timeout=15)
    r.raise_for_status()
    rows=[]
    for k in r.json():
        rows.append({
            "dt": datetime.fromtimestamp(k[0]/1000, timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z"),
            "open": float(k[1]), "high": float(k[2]), "low": float(k[3]), "close": float(k[4]),
            "volume": float(k[5]), "open_time_ms": int(k[0])
        })
    return rows

def fetch_fear_greed():
    r=requests.get("https://api.alternative.me/fng/", params={"limit":1}, timeout=15)
    r.raise_for_status()
    d=r.json()["data"][0]
    return {"value": float(d["value"]), "label": d.get("value_classification"), "cached": False}

def fetch_coinbase_premium(binance_price):
    try:
        r=requests.get("https://api.coinbase.com/v2/prices/BTC-USD/spot", timeout=10)
        r.raise_for_status()
        cb=float(r.json()["data"]["amount"])
        return {"coinbase_price": cb, "coinbase_premium_pct": (cb/binance_price-1)*100, "missing": False, "source": "coinbase_ticker"}
    except Exception as e:
        return {"coinbase_price": None, "coinbase_premium_pct": None, "missing": True, "error": str(e), "source": "coinbase_ticker"}

def fetch_funding():
    try:
        r=requests.get("https://fapi.binance.com/fapi/v1/premiumIndex", params={"symbol":"BTCUSDT"}, timeout=10)
        r.raise_for_status()
        return {"funding_rate": float(r.json().get("lastFundingRate",0.0)), "missing": False}
    except Exception as e:
        return {"funding_rate": None, "missing": True, "error": str(e)}

def fetch_macro_stub():
    return {"safe": True, "source": "macro_optional_stub", "spx_ret_1w_calc": None}

def sma(vals, n):
    if len(vals)<n: return None
    return sum(vals[-n:])/n

def rsi(vals, n=14):
    if len(vals)<n+1: return None
    gains=[]; losses=[]
    for a,b in zip(vals[-n-1:-1], vals[-n:]):
        ch=b-a
        gains.append(max(ch,0)); losses.append(max(-ch,0))
    ag=sum(gains)/n; al=sum(losses)/n
    if al==0: return 100.0
    return 100 - (100/(1+ag/al))

def build_features(c1h, c1d, fg, funding, premium, macro):
    closes=[x["close"] for x in c1h]
    dcloses=[x["close"] for x in c1d]
    last=c1h[-1]
    close=last["close"]
    ath=max(dcloses) if dcloses else close
    ret4=(close/closes[-5]-1) if len(closes)>=5 else None
    ret24=(close/closes[-25]-1) if len(closes)>=25 else None
    ret1=(close/closes[-2]-1) if len(closes)>=2 else None
    dd=(close/ath-1)*100 if ath else None
    row={
        "dt": last["dt"],
        "close": close, "price": close,
        "fear_greed": fg.get("value"),
        "fear_greed_label": fg.get("label"),
        "funding_rate": funding.get("funding_rate"),
        "coinbase_premium_pct": premium.get("coinbase_premium_pct"),
        "coinbase_premium_missing": premium.get("missing"),
        "ma_50": sma(closes,50),
        "ma_200": sma(closes,200),
        "return_1": ret1,
        "return_4": ret4,
        "mom_4h": ret4,
        "return_24": ret24,
        "rsi_14": rsi(closes,14),
        "drawdown_from_ath": dd,
        "spx_ret_1w_calc": macro.get("spx_ret_1w_calc"),
        "risk_on": (macro.get("spx_ret_1w_calc") or 0) > 0,
    }
    # Conservative regime labels
    fgval=row["fear_greed"]; r=row["rsi_14"]; ret=row["return_24"]
    if fgval is not None and fgval < 18 and r is not None and r < 40 and ret is not None and ret < -0.02:
        regime="capitulation"
    elif fgval is not None and fgval < 30:
        regime="fear"
    elif row["ma_50"] and row["ma_200"] and close > row["ma_50"] > row["ma_200"]:
        regime="bull"
    else:
        regime="neutral"
    row["regime"]=regime
    return row

def inspect_live_data(cfg):
    c1h=fetch_binance_klines("1h",999)
    c1d=fetch_binance_klines("1d",999)
    fg=fetch_fear_greed()
    funding=fetch_funding()
    prem=fetch_coinbase_premium(c1h[-1]["close"])
    macro=fetch_macro_stub()
    row=build_features(c1h,c1d,fg,funding,prem,macro)
    dec=decide_all(row, cfg.get("active_models"))
    return {"ok": True, "version": VERSION, "research_core_version": RESEARCH_CORE_VERSION,
            "btc_1h": {"count": len(c1h), "last": c1h[-1]},
            "btc_1d": {"count": len(c1d), "last": c1d[-1]},
            "fear_greed": fg, "funding": funding, "coinbase": prem, "macro": macro,
            "features": row, "decision": dec}

def ntfy_post(topic, title, message, priority="default", tags="chart_with_upwards_trend"):
    url=f"https://ntfy.sh/{topic}"
    r=requests.post(url, data=message.encode("utf-8"), headers={"Title":title,"Priority":priority,"Tags":tags}, timeout=15)
    r.raise_for_status()
    return {"status_code": r.status_code, "text": r.text[:200]}

def format_trade(dec, test=False):
    prefix="TEST ONLY — " if test else ""
    return (
        f"{prefix}BEE PAPER TRADE\n"
        f"Model: {dec.get('model')}\nAction: {dec.get('action')}\nTier: {dec.get('tier')}\n"
        f"Timeframe: {dec.get('horizon')}\nEntry: ${dec.get('entry_price')}\n"
        f"Take profit / monitor target: ${dec.get('take_profit')}\n"
        f"Stoploss / initial invalidation: ${dec.get('stop_loss')}\n"
        f"Exit: {dec.get('exit_policy')} ({dec.get('levels_label')})\n"
        f"Prob: {dec.get('prob')}\nReason: {dec.get('reason')}\n\n"
        "PAPER ONLY — geen automatische trade."
    )

def append_csv(path:Path, header:List[str], row:Dict[str,Any]):
    new=not path.exists()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=header)
        if new: w.writeheader()
        w.writerow({k: row.get(k,"") for k in header})

HIST_HEADER="timestamp_utc,candle_dt,price,fear_greed,drawdown_from_ath,return_4,return_24,rsi_14,regime,specialist,prob,cycle_prob_raw,tier,decision,notify,reason,last_notify_status,notify_skip_reason".split(",")
SIG_HEADER="signal_ts,candle_dt,specialist,decision,tier,prob,entry_price,take_profit,stop_loss,horizon,fear_greed,regime,reason,outcome_price_30d,outcome_pct_30d,outcome_filled_at".split(",")

def trim_history(max_rows=8760):
    if not HISTORY_PATH.exists(): return
    lines=HISTORY_PATH.read_text(encoding="utf-8").splitlines()
    if len(lines) <= max_rows+1: return
    out="\n".join([lines[0]] + lines[-max_rows:]) + "\n"
    atomic_write(HISTORY_PATH, out)

def write_run_records(snapshot, notify=False, notify_status="SKIPPED", notify_skip_reason="NO_TRADE", force=False):
    row=snapshot["features"]; dec=snapshot["decision"]
    outputs=dec.get("all_engine_outputs",[])
    cycle=next((o for o in outputs if o.get("model")=="cycle_reversal"), {})
    hist={
        "timestamp_utc": iso(),
        "candle_dt": row.get("dt"),
        "price": row.get("close"),
        "fear_greed": row.get("fear_greed"),
        "drawdown_from_ath": row.get("drawdown_from_ath"),
        "return_4": row.get("return_4"),
        "return_24": row.get("return_24"),
        "rsi_14": row.get("rsi_14"),
        "regime": row.get("regime"),
        "specialist": dec.get("specialist"),
        "prob": dec.get("prob"),
        "cycle_prob_raw": cycle.get("cycle_prob_raw"),
        "tier": dec.get("tier"),
        "decision": dec.get("action"),
        "notify": notify,
        "reason": dec.get("reason"),
        "last_notify_status": notify_status,
        "notify_skip_reason": notify_skip_reason
    }
    append_csv(HISTORY_PATH,HIST_HEADER,hist)
    if notify and not force and dec.get("action") in ("LONG","SHORT"):
        sig={
            "signal_ts": iso(), "candle_dt": row.get("dt"), "specialist": dec.get("specialist"),
            "decision": dec.get("action"), "tier": dec.get("tier"), "prob": dec.get("prob"),
            "entry_price": dec.get("entry_price"), "take_profit": dec.get("take_profit"), "stop_loss": dec.get("stop_loss"),
            "horizon": dec.get("horizon"), "fear_greed": row.get("fear_greed"), "regime": row.get("regime"), "reason": dec.get("reason")
        }
        append_csv(SIGNALS_PATH,SIG_HEADER,sig)
    status=dict(snapshot)
    status["last_notify_status"]=notify_status
    status["notify_skip_reason"]=notify_skip_reason
    status["last_run_time"]=iso()
    save_json(STATUS_PATH,status)

def run_once(cfg, force_notify=False):
    topic=validate_ntfy_topic(cfg)
    disk_guard(cfg)
    snap=inspect_live_data(cfg)
    dec=snap["decision"]
    state=load_json(STATE_PATH, {"last_notified":{}})
    notify=False; status="SKIPPED"; skip="NO_TRADE"
    if force_notify:
        # Force sends current best if no long, use cycle test decision from current row but clearly TEST ONLY
        test_dec=dec
        if dec.get("action")!="LONG":
            row=snap["features"].copy()
            row["fear_greed"]=12; row["drawdown_from_ath"]=-38; row["rsi_14"]=27; row["return_4"]=0.02; row["mom_4h"]=0.02; row["return_24"]=-0.058; row["regime"]="capitulation"
            test_dec=decide_all(row, cfg.get("active_models"))
        ntfy_post(topic, "⚠️📈 BEE PAPER TRADE TEST", format_trade(test_dec, test=True), priority="high", tags="warning,chart_with_upwards_trend")
        notify=True; status="SENT"; skip="FORCE_TEST_ONLY"
        snap["decision"]=test_dec
        write_run_records(snap, notify=False, notify_status=status, notify_skip_reason=skip, force=True)
        return snap
    if dec.get("action") in ("LONG","SHORT") and dec.get("tier") in ("push","strong","elite"):
        sig_id=f"{dec.get('model')}|{dec.get('action')}|{dec.get('horizon')}|{snap['features'].get('dt')}"
        if state.get("last_notified",{}).get(sig_id):
            status="SKIPPED"; skip="DUPLICATE"
        else:
            try:
                ntfy_post(topic, f"📈 BEE {dec.get('action')} {dec.get('model')}", format_trade(dec, test=False), priority="high")
                state.setdefault("last_notified",{})[sig_id]=iso()
                save_json(STATE_PATH,state)
                notify=True; status="SENT"; skip=""
            except Exception as e:
                status="FAILED"; skip=f"NTFY_ERROR:{e}"
    else:
        skip="NO_TRADE_OR_TIER_TOO_LOW"
    write_run_records(snap, notify=notify, notify_status=status, notify_skip_reason=skip, force=False)
    trim_history(int(cfg.get("history_max_rows",8760)))
    return snap

def golden_test():
    rows=[
        {"name":"cycle_positive","close":64000,"fear_greed":20,"mom_4h":0.015,"return_4":0.015,"return_24":0.01,"drawdown_from_ath":-35,"rsi_14":45,"risk_on":True,"regime":"fear"},
        {"name":"no_trade_fear_momentum_fail","close":64000,"fear_greed":20,"mom_4h":-0.01,"return_4":-0.01,"return_24":0.0,"drawdown_from_ath":-35,"rsi_14":45,"risk_on":True,"regime":"fear"},
        {"name":"elite_panic","close":64000,"fear_greed":12,"mom_4h":0.01,"return_4":0.01,"return_24":-0.05,"drawdown_from_ath":-40,"rsi_14":27,"funding_rate":-0.0001,"regime":"capitulation"},
        {"name":"reversal_broad","close":64000,"fear_greed":26,"mom_4h":-0.005,"return_4":-0.005,"return_24":0.01,"drawdown_from_ath":-25,"rsi_14":42,"regime":"fear"},
        {"name":"neutral","close":64000,"fear_greed":50,"mom_4h":0.01,"return_4":0.01,"return_24":0.01,"drawdown_from_ath":-5,"rsi_14":55,"regime":"neutral"},
    ]
    # Since live decide imports same core, parity must be exact between direct core call and live call.
    results=[]
    ok=True
    from bee_research_core_v4_0 import decide_all as core_decide
    for row in rows:
        direct=core_decide(row, ["cycle_reversal","elite_reversal","reversal"])
        live=decide_all(row, ["cycle_reversal","elite_reversal","reversal"])
        match=(direct.get("model"),direct.get("action"),direct.get("prob"),direct.get("tier")) == (live.get("model"),live.get("action"),live.get("prob"),live.get("tier"))
        ok=ok and match
        results.append({"row":row["name"],"match":match,"direct":direct,"live":live})
    out={"ok":ok,"tested":len(rows),"matched":sum(1 for r in results if r["match"]),"results":results,"version":VERSION,"research_core_version":RESEARCH_CORE_VERSION}
    return out

def export_debug():
    snap=None
    try:
        cfg=load_config()
        snap=inspect_live_data(cfg)
        write_run_records(snap, notify=False, notify_status="SKIPPED", notify_skip_reason="EXPORT_INSPECT", force=True)
    except Exception as e:
        snap={"error":str(e),"version":VERSION}
    tmp=Path("/home/ubuntu/bee_latest_export.zip")
    try:
        tmp.unlink()
    except FileNotFoundError:
        pass
    with zipfile.ZipFile(tmp,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps({"created_at":iso(),"version":VERSION,"research_core_version":RESEARCH_CORE_VERSION},indent=2))
        for p in [ROOT/"bee_live_config.json", STATUS_PATH, HISTORY_PATH, SIGNALS_PATH, STATE_PATH, LOG_PATH, ROOT/"bee_research_core_v4_0.py"]:
            if p.exists(): z.write(p, p.name if p.parent==ROOT else str(p.relative_to(ROOT)))
        z.writestr("live_inspect_snapshot.json", json.dumps(snap, indent=2, default=str))
        z.writestr("golden_test.json", json.dumps(golden_test(), indent=2, default=str))
    print(f"EXPORT READY: {tmp}")
    return str(tmp)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--inspect-live-data", action="store_true")
    ap.add_argument("--test-ntfy", action="store_true")
    ap.add_argument("--test-trade-ntfy", action="store_true")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--force-notify", action="store_true")
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--daemon", action="store_true")
    ap.add_argument("--golden-test", action="store_true")
    ap.add_argument("--export-debug", action="store_true")
    args=ap.parse_args()
    cfg=load_config()
    if args.golden_test:
        print(json.dumps(golden_test(), indent=2)); sys.exit(0)
    if args.inspect_live_data:
        print(json.dumps(inspect_live_data(cfg), indent=2, default=str)); sys.exit(0)
    if args.test_ntfy:
        topic=validate_ntfy_topic(cfg)
        print(ntfy_post(topic, "✅ BEE ntfy test", f"BEE ntfy werkt. {iso()} version={VERSION}", tags="white_check_mark"))
        sys.exit(0)
    if args.test_trade_ntfy:
        cfg=load_config()
        run_once(cfg, force_notify=True); sys.exit(0)
    if args.once:
        print(json.dumps(run_once(cfg, force_notify=args.force_notify), indent=2, default=str)); sys.exit(0)
    if args.export_debug:
        export_debug(); sys.exit(0)
    if args.loop or args.daemon:
        while True:
            try: run_once(cfg, force_notify=False)
            except Exception as e:
                logger.exception("loop failed: %s", e)
            time.sleep(int(cfg.get("check_interval_hours",1))*3600)
    ap.print_help()

if __name__ == "__main__":
    main()
