#!/usr/bin/env python3
from pathlib import Path
import csv, requests, datetime, tempfile, os
ROOT=Path(__file__).resolve().parent
SIG=ROOT/"state"/"bee_signals.csv"
def btc_price():
    r=requests.get("https://api.binance.com/api/v3/ticker/price", params={"symbol":"BTCUSDT"}, timeout=10); r.raise_for_status()
    return float(r.json()["price"])
def main():
    if not SIG.exists():
        print("No bee_signals.csv yet"); return
    price=btc_price()
    rows=list(csv.DictReader(SIG.open()))
    changed=0
    now=datetime.datetime.now(datetime.timezone.utc)
    for row in rows:
        if row.get("outcome_pct_30d"): continue
        ts=row.get("signal_ts","").replace("Z","+00:00")
        try: dt=datetime.datetime.fromisoformat(ts)
        except Exception: continue
        if (now-dt).days >= 30:
            entry=float(row["entry_price"])
            row["outcome_price_30d"]=round(price,2)
            row["outcome_pct_30d"]=round((price/entry-1)*100,4)
            row["outcome_filled_at"]=now.isoformat().replace("+00:00","Z")
            changed+=1
    if changed:
        header=rows[0].keys()
        fd,tmp=tempfile.mkstemp(dir=str(SIG.parent),suffix=".tmp")
        with os.fdopen(fd,"w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=header); w.writeheader(); w.writerows(rows); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,SIG)
    print(f"evaluated={changed} current_price={price}")
if __name__=="__main__": main()
