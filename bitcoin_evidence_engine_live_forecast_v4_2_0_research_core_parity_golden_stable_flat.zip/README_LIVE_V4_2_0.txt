Bitcoin Evidence Engine Live Forecast v4.2.0

Highlights:
- Live decision imports bee_research_core_v4_0.py directly.
- cycle_reversal, elite_reversal and reversal all exist in the live code.
- Golden parity test included: python bee_live_forecast_v4_1_paper.py --golden-test
- ntfy topic hardwired in config as requested.
- status/history/signals logging included.
- export always writes /home/ubuntu/bee_latest_export.zip.

One-line after GitHub upload:
cd /home/ubuntu/bitcoin-engine-deploy/current && rm -rf github_latest && git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git github_latest && unzip -o github_latest/bitcoin_evidence_engine_live_forecast_v4_2_0_research_core_parity_golden_stable_flat.zip && chmod +x scripts/bee_one_line_live_update_test_export.sh && ./scripts/bee_one_line_live_update_test_export.sh
