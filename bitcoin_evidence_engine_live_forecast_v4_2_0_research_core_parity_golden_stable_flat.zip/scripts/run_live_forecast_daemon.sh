#!/usr/bin/env bash
cd /home/ubuntu/bitcoin-engine-deploy/current
source .venv/bin/activate
cd live_forecast
python bee_live_forecast_v4_1_paper.py --daemon
