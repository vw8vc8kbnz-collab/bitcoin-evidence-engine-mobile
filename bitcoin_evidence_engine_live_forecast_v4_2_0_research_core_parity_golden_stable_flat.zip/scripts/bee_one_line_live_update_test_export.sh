#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/bitcoin-engine-deploy/current
echo "[1/9] Installing live forecast..."
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh
source .venv/bin/activate
cd live_forecast
echo "[2/9] Version/help..."
python bee_live_forecast_v4_1_paper.py --help >/dev/null
echo "[3/9] Golden test parity..."
python bee_live_forecast_v4_1_paper.py --golden-test | tee /tmp/bee_golden_test.json
grep -q '"ok": true' /tmp/bee_golden_test.json
echo "[4/9] Inspect live data..."
python bee_live_forecast_v4_1_paper.py --inspect-live-data >/tmp/bee_inspect.json
echo "[5/9] Basic ntfy test..."
python bee_live_forecast_v4_1_paper.py --test-ntfy
echo "[6/9] Paper trade ntfy TEST_ONLY..."
python bee_live_forecast_v4_1_paper.py --test-trade-ntfy
echo "[7/9] One real once-run (no force)..."
python bee_live_forecast_v4_1_paper.py --once >/tmp/bee_once.json
echo "[8/9] Export debug to /home/ubuntu/bee_latest_export.zip..."
rm -f /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export*.zip || true
python bee_live_forecast_v4_1_paper.py --export-debug
ls -lah /home/ubuntu/bee_latest_export.zip
echo "[9/9] DONE. Download in Termius SFTP: home > ubuntu > bee_latest_export.zip"
