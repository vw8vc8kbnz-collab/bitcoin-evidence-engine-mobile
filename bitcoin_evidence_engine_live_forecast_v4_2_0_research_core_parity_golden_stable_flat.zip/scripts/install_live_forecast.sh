#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/bitcoin-engine-deploy/current
mkdir -p live_forecast/state live_forecast/logs live_forecast/debug_exports
if [ ! -d .venv ]; then python3 -m venv .venv; fi
source .venv/bin/activate
pip install -r live_forecast/requirements.txt
echo "✅ Live forecast install OK."
