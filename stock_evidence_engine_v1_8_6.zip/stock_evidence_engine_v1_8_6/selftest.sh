#!/usr/bin/env bash
set -euo pipefail
for f in server.py engine.py install.sh run_backtest.sh requirements.txt deepseek_prompt.md VERSION; do
  test -f "$f" || { echo "missing $f"; exit 1; }
done
python3 -m py_compile server.py engine.py
python3 - <<'PYSELF'
import re, pathlib, importlib.util
expected=pathlib.Path('VERSION').read_text().strip()
for file in ['server.py','engine.py']:
    txt=pathlib.Path(file).read_text()
    m=re.search(r"VERSION=['\"]([^'\"]+)['\"]", txt)
    if not m or m.group(1)!=expected:
        raise SystemExit(f"VERSION mismatch in {file}: {m.group(1) if m else 'missing'} != {expected}")
spec=importlib.util.spec_from_file_location('engine','engine.py')
engine=importlib.util.module_from_spec(spec); spec.loader.exec_module(engine)
assert engine.normalize_score(8)==80
assert engine.normalize_score(8.5)==85
assert engine.normalize_score(75)==75
row=engine.normalize_ai_row({'final_score':8,'materiality':9,'market_confirmation':7.5,'priced_in_risk':6})
assert row['ai_final_score']==80 and row['materiality']==90 and row['market_confirmation']==75 and row['priced_in_risk']==60
assert row['ai_tier']=='AI_ELITE'
print('[SEE selftest] version markers + AI normalization OK')
PYSELF
echo '[SEE selftest] OK'
