#!/usr/bin/env python3
import os, sys, json, math, time, zipfile, csv
from pathlib import Path
from datetime import datetime, timezone
import requests
import pandas as pd
import numpy as np
from dotenv import load_dotenv

VERSION='v1.8.6'
BASE=Path(__file__).resolve().parent
OUT=BASE/'output'; OUT.mkdir(exist_ok=True)
load_dotenv(BASE/'.env')
BLACKLIST_DEFAULT={'LAZR'}
HEALTH_FILE=OUT/'ticker_health.json'
FAIL_LOG=OUT/'download_failures.log'

DEFAULT_UNIVERSE = "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN,RGTI,QBTS,OKLO,ASTS,LUNR,OUST,PATH,SOFI,AFRM,ROKU,SHOP,NET,CRWD,DDOG,SNOW,ARM,MU,AVGO,TSM,SMCI,APP,MRVL,INTC,ORCL,MSFT,GOOGL,META,AMZN,CRSP,BEAM,EDIT,NTLA,PLUG,ENPH,FSLR,CCJ,UEC,UUUU,ACHR,EVGO,CHPT,QS,OPEN,DKNG,TDOC,SPCE,ENVX,STEM,SERV,TER,ISRG,IRDM,KTOS,AVAV,HIMS,NU,SE,GRAB,TOST,U,LMND,ROOT,CVNA"
THEME_MAP={
 'AI':['SOUN','BBAI','AI','PLTR','NVDA','AMD','SMCI','ARM','AVGO','MRVL','ORCL','MSFT','GOOGL','META'],
 'QUANTUM':['IONQ','RGTI','QBTS'], 'SPACE':['RKLB','LUNR','ASTS','SPCE','IRDM'],
 'NUCLEAR':['SMR','OKLO','CCJ','UEC','UUUU'], 'CRYPTO':['COIN','MARA','RIOT'],
 'EV_ROBOTICS':['ACHR','JOBY','LCID','RIVN','TSLA','OUST','SERV'],
 'FINTECH':['HOOD','SOFI','AFRM','NU','TOST'], 'CYBER_CLOUD':['CRWD','NET','DDOG','SNOW','PATH'],
 'BIOTECH':['CRSP','BEAM','EDIT','NTLA'], 'DEFENSE':['KTOS','AVAV','PLTR']
}
SPECIAL={t:theme for theme,arr in THEME_MAP.items() for t in arr}

def env_float(k,d):
    try: return float(os.getenv(k,d))
    except: return d

def env_int(k,d):
    try: return int(os.getenv(k,d))
    except: return d

def clean_universe(tickers):
    seen=[]
    for raw in tickers:
        t=str(raw).strip().upper()
        if not t or t in seen or t in BLACKLIST_DEFAULT:
            continue
        seen.append(t)
    return seen

def _load_health():
    try:
        return json.loads(HEALTH_FILE.read_text())
    except Exception:
        return {}

def _save_health(h):
    HEALTH_FILE.write_text(json.dumps(h, indent=2, sort_keys=True))

def _mark_fail(ticker, reason):
    h=_load_health(); rec=h.get(ticker, {'fails':0,'last_error':''})
    rec['fails']=int(rec.get('fails',0))+1; rec['last_error']=str(reason)[:300]; rec['last_failed_at']=datetime.now(timezone.utc).isoformat()
    if rec['fails']>=3: rec['auto_blacklisted']=True
    h[ticker]=rec; _save_health(h)
    with FAIL_LOG.open('a', encoding='utf-8') as f:
        f.write(f"{datetime.now(timezone.utc).isoformat()} {ticker} {str(reason)[:300]}\n")

def _mark_ok(ticker, rows):
    h=_load_health(); rec=h.get(ticker, {})
    rec.update({'fails':0,'last_ok_at':datetime.now(timezone.utc).isoformat(),'rows':int(rows),'auto_blacklisted':False})
    h[ticker]=rec; _save_health(h)

def fetch_hist(tickers, period='2y'):
    import yfinance as yf
    data={}; health=_load_health()
    for t in clean_universe(tickers):
        if health.get(t,{}).get('auto_blacklisted'):
            print(f'[SKIP] {t} auto-blacklisted after repeated data failures')
            continue
        last_err=None
        for attempt in range(1,4):
            try:
                df=yf.download(t, period=period, interval='1d', auto_adjust=True, progress=False, threads=False)
                if df is None or df.empty or len(df)<80:
                    raise RuntimeError(f'no usable price data rows={0 if df is None else len(df)}')
                if isinstance(df.columns, pd.MultiIndex): df.columns=[c[0] for c in df.columns]
                df=df.dropna().copy()
                if df.empty or 'Close' not in df or 'Volume' not in df:
                    raise RuntimeError('missing OHLCV columns after cleanup')
                data[t]=df; _mark_ok(t,len(df)); break
            except Exception as e:
                last_err=e
                time.sleep(0.6*attempt)
        if t not in data:
            print(f'[WARN] {t} skipped after retries: {last_err}')
            _mark_fail(t,last_err)
    return data

def metrics_for(df, bench=None):
    close=df['Close']; vol=df['Volume']
    ret1=(close.iloc[-1]/close.iloc[-2]-1)*100 if len(close)>2 else 0
    ret3=(close.iloc[-1]/close.iloc[-4]-1)*100 if len(close)>4 else ret1
    ret20=(close.iloc[-1]/close.iloc[-21]-1)*100 if len(close)>21 else ret3
    ma20=close.rolling(20).mean().iloc[-1]; ma50=close.rolling(50).mean().iloc[-1]
    rv=float(vol.iloc[-1]/max(1,vol.rolling(20).mean().iloc[-1])) if len(vol)>20 else 1
    high52=float(close.tail(252).max()) if len(close)>20 else float(close.max())
    pos52=float(close.iloc[-1]/high52*100) if high52 else 0
    rs=0
    if bench is not None and len(bench)>21:
        b=bench['Close']; br=(b.iloc[-1]/b.iloc[-21]-1)*100
        rs=ret20-br
    score=max(0,min(100, 45 + ret20*1.8 + (rv-1)*8 + rs*1.2 + (5 if close.iloc[-1]>ma50 else -5)))
    return dict(price=float(close.iloc[-1]),ret1=ret1,ret3=ret3,ret20=ret20,relative_volume=rv,position_52w=pos52,rs_vs_bench=rs,technical_score=score,above_ma50=bool(close.iloc[-1]>ma50),above_ma20=bool(close.iloc[-1]>ma20))

def setup_rows(ticker, df, m):
    holds=[3,5,10,20]
    rows=[]; trades=[]
    close=df['Close']; vol=df['Volume']; ma20=close.rolling(20).mean(); ma50=close.rolling(50).mean(); avgvol=vol.rolling(20).mean()
    engines=['momentum_continuation_legacy','relative_strength_leader','momentum_rs_continuation','theme_momentum_leader','catalyst_momentum_proxy','price_reaction_confirmed']
    for eng in engines:
        dates=[]
        for i in range(60,len(df)-21):
            r20=(close.iloc[i]/close.iloc[i-20]-1)*100; rv=vol.iloc[i]/max(1,avgvol.iloc[i])
            cond=False
            if eng=='momentum_continuation_legacy': cond=r20>8 and rv>1.1 and close.iloc[i]>ma50.iloc[i]
            elif eng=='relative_strength_leader': cond=r20>12 and close.iloc[i]>ma20.iloc[i]
            elif eng=='momentum_rs_continuation': cond=r20>10 and rv>1.25
            elif eng=='theme_momentum_leader': cond=ticker in SPECIAL and r20>8
            elif eng=='catalyst_momentum_proxy': cond=ticker in SPECIAL and r20>5 and rv>1.2
            elif eng=='price_reaction_confirmed': cond=(close.iloc[i]/close.iloc[i-3]-1)*100>5 and rv>1.5
            if cond: dates.append(i)
        for h in holds:
            rets=[]
            for i in dates:
                if i+h < len(df):
                    r=(close.iloc[i+h]/close.iloc[i]-1)*100-0.20
                    rets.append(r); trades.append(dict(ticker=ticker,setup=eng,hold_days=h,entry_date=str(df.index[i].date()),exit_date=str(df.index[i+h].date()),return_pct=r))
            n=len(rets); avg=float(np.mean(rets)) if n else 0; win=float(np.mean([x>0 for x in rets])*100) if n else 0
            fake=1 if n<15 else 0
            evidence=avg*3 + (win-50)*0.8 + min(n,60)*0.8 + m['technical_score']*0.15
            if ticker in SPECIAL: evidence += 8
            elite = n>=25 and avg>3.5 and win>=55 and evidence>=82
            good = n>=18 and avg>2 and win>=52 and evidence>=55
            usable = n>=15 and avg>0
            rows.append(dict(ticker=ticker,theme=SPECIAL.get(ticker,'GENERAL'),setup=eng,hold_days=h,trades=n,avg_return_pct=round(avg,3),winrate_pct=round(win,2),evidence_score=round(evidence,2),fake_alpha_warning=fake,usable=int(usable),good_candidate=int(good),elite=int(elite),price=round(m['price'],3),ret3=round(m['ret3'],2),ret20=round(m['ret20'],2),relative_volume=round(m['relative_volume'],2),rs_vs_bench=round(m['rs_vs_bench'],2),position_52w=round(m['position_52w'],1),technical_score=round(m['technical_score'],1)))
    return rows,trades

def get_news(ticker, maxn=20):
    import yfinance as yf
    items=[]
    try:
        news=yf.Ticker(ticker).news or []
        for n in news[:maxn]:
            title=n.get('title') or n.get('content',{}).get('title') or ''
            pub=n.get('publisher') or n.get('content',{}).get('provider',{}).get('displayName') or ''
            link=n.get('link') or n.get('content',{}).get('canonicalUrl',{}).get('url') or ''
            ts=n.get('providerPublishTime') or n.get('content',{}).get('pubDate') or ''
            items.append(dict(ticker=ticker,title=title,publisher=pub,link=link,published=ts))
    except Exception as e:
        pass
    return [x for x in items if x['title']]

def local_event_score(ticker, news, m):
    text=' '.join([x['title'] for x in news]).lower()
    bull=['partnership','contract','deal','upgrade','beats','beat','guidance','approval','launch','merger','acquisition','ai','nvidia','government','billion']
    bear=['offering','dilution','downgrade','lawsuit','misses','miss','bankruptcy','investigation']
    b=sum(text.count(w) for w in bull); r=sum(text.count(w) for w in bear)
    catalyst=max(0,min(100,45+b*7-r*12 + (10 if ticker in SPECIAL else 0)))
    reaction=max(0,min(100,45+m['ret3']*2+(m['relative_volume']-1)*10+m['rs_vs_bench']*1.5))
    return catalyst,reaction


AI_SCORE_FIELDS = ['ai_final_score','final_score','materiality','market_confirmation','priced_in_risk','continuation_3d','continuation_10d','rarity','repricing_potential','volume_confirmation','relative_strength_confirmation','fade_risk']

def normalize_score(x, default=0):
    """Normalize DeepSeek/local scores to a strict 0-100 scale.
    DeepSeek sometimes returns 0-10 and sometimes 0-100; downstream code must never see mixed scales.
    """
    if x is None or x == '':
        return float(default)
    try:
        v=float(x)
    except Exception:
        return float(default)
    if 0 <= v <= 10:
        v *= 10.0
    return round(max(0.0, min(100.0, v)), 2)

def ai_tier(score):
    s=normalize_score(score)
    if s>=90: return 'AI_EXTREME'
    if s>=80: return 'AI_ELITE'
    if s>=70: return 'AI_HIGH'
    if s>=55: return 'AI_GOOD'
    return 'AI_LOW'

def normalize_ai_row(row):
    row=dict(row or {})
    # Accept both older and new DeepSeek key names.
    if 'ai_final_score' not in row and 'final_score' in row:
        row['ai_final_score']=row.get('final_score')
    if 'market_confirmation' not in row and 'market_reaction_confirmation' in row:
        row['market_confirmation']=row.get('market_reaction_confirmation')
    if 'materiality' not in row and 'news_importance' in row:
        row['materiality']=row.get('news_importance')
    for k in AI_SCORE_FIELDS:
        if k in row:
            row[k]=normalize_score(row.get(k), 0)
    # final_score and ai_final_score should mirror one another after normalization.
    if 'ai_final_score' in row:
        row['final_score']=normalize_score(row.get('ai_final_score'), 0)
    else:
        row['ai_final_score']=normalize_score(row.get('final_score'), 0)
        row['final_score']=row['ai_final_score']
    row['ai_tier']=ai_tier(row.get('ai_final_score'))
    # Keep conviction coherent but do not overwrite a stronger semantic conviction if present.
    if not row.get('conviction') or str(row.get('conviction')).upper() in ('', 'WATCH', 'GOOD', 'HIGH', 'ELITE', 'EXTREME'):
        row['conviction']={'AI_EXTREME':'EXTREME','AI_ELITE':'ELITE','AI_HIGH':'HIGH','AI_GOOD':'GOOD','AI_LOW':'WATCH'}[row['ai_tier']]
    row['normalization_version']='v1.8.6_0_100'
    return row

def safe_float(x, default=0):
    try: return float(x)
    except Exception: return default

def summarize_setups_for_ticker(summary_rows, ticker, limit=6):
    rows=[r for r in summary_rows if r.get('ticker')==ticker]
    rows=sorted(rows, key=lambda r: (int(r.get('elite',0)), safe_float(r.get('evidence_score')), safe_float(r.get('avg_return_pct'))), reverse=True)[:limit]
    return [{
        'setup':r.get('setup'), 'hold_days':r.get('hold_days'), 'trades':r.get('trades'),
        'avg_return_pct':r.get('avg_return_pct'), 'winrate_pct':r.get('winrate_pct'),
        'evidence_score':r.get('evidence_score'), 'quant_elite':int(r.get('elite',0)),
        'usable':int(r.get('usable',0))
    } for r in rows]

def deepseek_analyze(ticker, theme, news, m, cost_rows, setup_context=None, consensus=None, reaction=None, analog=None):
    key=os.getenv('DEEPSEEK_API_KEY','').strip(); use=os.getenv('USE_DEEPSEEK','1')=='1'
    if not key or not use:
        return None
    prompt_path=BASE/'deepseek_prompt.md'
    system=prompt_path.read_text() if prompt_path.exists() else 'Return JSON only.'
    headlines=[{'title':n.get('title',''), 'publisher':n.get('publisher',''), 'published':n.get('published',''), 'link':n.get('link','')} for n in news[:env_int('DEEPSEEK_MAX_HEADLINES',50)]]
    payload={
        'ticker':ticker,
        'theme':theme,
        'market_data':m,
        'quant_setup_context':setup_context or [],
        'news_consensus':consensus or {},
        'price_reaction_context':reaction or {},
        'historical_analog_context':analog or {},
        'headlines':headlines,
        'scoring_rules':'Return all numeric scores on 0-100 scale. If uncertain, use 45-60, not 8/10. ai_final_score is the final catalyst-continuation score.',
        'instruction':'Act as an institutional catalyst analyst. Connect headlines to market reaction, volume, relative strength, theme relevance, priced-in risk, and quant setup evidence. Be strict but do not block a confirmed high-quality setup just because it is not perfect. Return JSON only.'
    }
    try:
        res=requests.post('https://api.deepseek.com/chat/completions',headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'},json={
            'model':os.getenv('DEEPSEEK_MODEL','deepseek-chat'),
            'messages':[{'role':'system','content':system},{'role':'user','content':json.dumps(payload, default=str)[:32000]}],
            'temperature':0.12,'max_tokens':env_int('DEEPSEEK_MAX_OUTPUT_TOKENS',4000),'response_format':{'type':'json_object'}
        },timeout=60)
        data=res.json(); content=data['choices'][0]['message']['content']; out=json.loads(content)
        usage=data.get('usage',{}); inp=usage.get('prompt_tokens',0); opt=usage.get('completion_tokens',0)
        cost=inp/1_000_000*env_float('DEEPSEEK_INPUT_USD_PER_M',0.14)+opt/1_000_000*env_float('DEEPSEEK_OUTPUT_USD_PER_M',0.28)
        cost_rows.append(dict(timestamp=datetime.now(timezone.utc).isoformat(),ticker=ticker,input_tokens=inp,output_tokens=opt,estimated_cost_usd=round(cost,6),provider='deepseek'))
        out=normalize_ai_row(out); out['provider']='deepseek'; return out
    except Exception as e:
        cost_rows.append(dict(timestamp=datetime.now(timezone.utc).isoformat(),ticker=ticker,input_tokens=0,output_tokens=0,estimated_cost_usd=0,provider='local_fallback_after_error',error=str(e)[:160]))
        return None

def apply_final_ranking(summary, ai_rows):
    ai_map={r['ticker']:normalize_ai_row(r) for r in ai_rows}
    for r in summary:
        old_quant_elite=int(r.get('elite',0))
        ai=ai_map.get(r['ticker'],{})
        ai_score=normalize_score(ai.get('ai_final_score') or ai.get('final_score'),0) if ai else 0
        materiality=normalize_score(ai.get('materiality'),0) if ai else 0
        market_conf=normalize_score(ai.get('market_confirmation'),0) if ai else 0
        priced_risk=normalize_score(ai.get('priced_in_risk'),50) if ai else 50
        quant_score=normalize_score(r.get('evidence_score'),0)
        final_score=round(quant_score*0.40 + ai_score*0.40 + materiality*0.10 + market_conf*0.10,2)
        tier=ai_tier(ai_score)
        final_elite = bool(old_quant_elite and ai_score>=70)
        final_extreme = bool(old_quant_elite and ai_score>=80 and materiality>=80 and market_conf>=75)
        r['quant_elite']=old_quant_elite
        r['ai_final_score']=ai_score
        r['ai_tier']=tier
        r['ai_conviction']=ai.get('conviction','') if ai else ''
        r['ai_good']=int(ai_score>=55)
        r['ai_high']=int(ai_score>=70)
        r['ai_elite']=int(ai_score>=80)
        r['ai_extreme']=int(ai_score>=90)
        r['materiality']=materiality
        r['market_confirmation']=market_conf
        r['priced_in_risk']=priced_risk
        r['combined_score']=final_score
        r['final_score']=final_score
        r['final_elite']=int(final_elite)
        r['final_extreme']=int(final_extreme)
        r['elite']=int(final_elite or final_extreme)
        r['good_candidate']=1 if (int(r.get('good_candidate',0)) or ai_score>=55 or final_score>=55) else 0
    return summary

def run(tickers, period):
    import yfinance as yf
    bench=fetch_hist(['QQQ'],period).get('QQQ')
    data=fetch_hist(tickers,period)
    summary=[]; trades=[]; news_items=[]; ai_rows=[]; reaction_rows=[]; consensus_rows=[]; analog_rows=[]; cost_rows=[]
    metrics={}
    for t,df in data.items(): metrics[t]=metrics_for(df,bench)
    shortlist=sorted(metrics.keys(), key=lambda t: metrics[t]['technical_score'] + abs(metrics[t]['ret3'])*1.5 + (12 if t in SPECIAL else 0), reverse=True)[:env_int('DEEPSEEK_MAX_TICKERS',30)]
    for t,df in data.items():
        rows,tr=setup_rows(t,df,metrics[t]); summary+=rows; trades+=tr
    for t in shortlist:
        news=get_news(t, env_int('DEEPSEEK_MAX_HEADLINES',50)); news_items += news
        cat,react=local_event_score(t,news,metrics[t])
        consensus=dict(ticker=t,headline_count=len(news),consensus_score=cat,theme=SPECIAL.get(t,'GENERAL'),headline_titles=' | '.join([n.get('title','') for n in news[:8]]))
        reaction=dict(ticker=t,price_reaction_score=react,ret1=metrics[t]['ret1'],ret3=metrics[t]['ret3'],ret20=metrics[t]['ret20'],relative_volume=metrics[t]['relative_volume'],rs_vs_bench=metrics[t]['rs_vs_bench'],position_52w=metrics[t]['position_52w'],above_ma20=metrics[t]['above_ma20'],above_ma50=metrics[t]['above_ma50'])
        analog=dict(ticker=t,closest_analog_theme=SPECIAL.get(t,'GENERAL'),analog_quality=round((cat+react)/2,2),expected_3d=round((cat+react)/22,2),expected_10d=round((cat+react)/14,2))
        consensus_rows.append(consensus); reaction_rows.append(reaction); analog_rows.append(analog)
        setup_ctx=summarize_setups_for_ticker(summary,t,limit=8)
        ai=deepseek_analyze(t,SPECIAL.get(t,'GENERAL'),news,metrics[t],cost_rows,setup_ctx,consensus,reaction,analog)
        if not ai:
            fs=round(cat*.35+react*.35+metrics[t]['technical_score']*.20+(10 if any(x.get('quant_elite') for x in setup_ctx) else 0),2)
            conv='EXTREME' if fs>=90 else 'ELITE' if fs>=80 else 'HIGH' if fs>=70 else 'GOOD' if fs>=55 else 'WATCH'
            ai=dict(ticker=t,event_type='local_catalyst',event_quality=conv,materiality=cat,market_confirmation=react,continuation_3d=min(95,fs),continuation_10d=max(0,min(95,fs-7)),ai_final_score=fs,final_score=fs,conviction=conv,reasoning='Local fallback: catalyst proxy linked with price reaction, relative strength, volume and quant setup context.',provider='local_fallback')
        ai=normalize_ai_row(ai); ai['ticker']=t; ai['theme']=SPECIAL.get(t,'GENERAL'); ai['quant_setup_count']=len(setup_ctx); ai_rows.append(ai)
    summary=apply_final_ranking(summary, ai_rows)
    write_outputs(summary,trades,news_items,ai_rows,reaction_rows,consensus_rows,analog_rows,cost_rows)
    send_ntfy(summary, ai_rows)
    print(f"Done. trades={len(trades)} summary_rows={len(summary)} final_elite={sum(int(r.get('final_elite',0)) for r in summary)} final_extreme={sum(int(r.get('final_extreme',0)) for r in summary)} ai_high={sum(1 for r in ai_rows if normalize_score(r.get('ai_final_score'))>=70)} ai_elite={sum(1 for r in ai_rows if normalize_score(r.get('ai_final_score'))>=80)} quant_elite={sum(int(r.get('quant_elite',0)) for r in summary)} deepseek_rows={len(ai_rows)}")

def write_csv(name, rows):
    p=OUT/name
    if not rows:
        p.write_text('empty\n'); return
    keys=sorted(set().union(*[r.keys() for r in rows]))
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)

def write_outputs(summary,trades,news,ai,reaction,consensus,analog,cost):
    write_csv(f'see_summary_{VERSION}.csv',summary); write_csv(f'see_trades_{VERSION}.csv',trades)
    write_csv(f'see_elite_{VERSION}.csv',[r for r in summary if int(r.get('elite',0))])
    write_csv(f'see_final_elite_{VERSION}.csv',[r for r in summary if int(r.get('final_elite',0))])
    write_csv(f'see_final_extreme_{VERSION}.csv',[r for r in summary if int(r.get('final_extreme',0))])
    write_csv(f'see_ai_elite_{VERSION}.csv',[r for r in summary if int(r.get('ai_elite',0)) or int(r.get('ai_extreme',0))])
    write_csv(f'see_ai_high_{VERSION}.csv',[r for r in summary if int(r.get('ai_high',0))])
    write_csv(f'see_quant_elite_{VERSION}.csv',[r for r in summary if int(r.get('quant_elite',0))])
    write_csv(f'see_usable_{VERSION}.csv',[r for r in summary if int(r.get('usable',0)) or int(r.get('good_candidate',0))])
    df=pd.DataFrame(summary) if summary else pd.DataFrame()
    by_setup=[]
    if not df.empty:
        for s,g in df.groupby('setup'):
            by_setup.append(dict(setup=s,rows=len(g),trades=int(g['trades'].sum()),quant_elite=int(g['quant_elite'].sum()),final_elite=int(g['final_elite'].sum()),final_extreme=int(g['final_extreme'].sum()),avg_expectancy=round(g['avg_return_pct'].mean(),3),avg_final_score=round(g['final_score'].mean(),2)))
    by_ticker=[]
    if not df.empty:
        for s,g in df.groupby('ticker'):
            by_ticker.append(dict(ticker=s,theme=SPECIAL.get(s,'GENERAL'),rows=len(g),trades=int(g['trades'].sum()),quant_elite=int(g['quant_elite'].sum()),final_elite=int(g['final_elite'].sum()),final_extreme=int(g['final_extreme'].sum()),avg_expectancy=round(g['avg_return_pct'].mean(),3),max_final_score=round(g['final_score'].max(),2),max_ai_score=round(g['ai_final_score'].max(),2)))
    write_csv(f'see_by_setup_{VERSION}.csv',by_setup); write_csv(f'see_by_ticker_{VERSION}.csv',by_ticker)
    write_csv(f'see_news_items_{VERSION}.csv',news); write_csv(f'see_ai_analyst_{VERSION}.csv',ai)
    write_csv(f'see_price_reaction_{VERSION}.csv',reaction); write_csv(f'see_news_consensus_{VERSION}.csv',consensus); write_csv(f'see_historical_analog_memory_{VERSION}.csv',analog); write_csv(f'see_deepseek_costs_{VERSION}.csv',cost)
    health_rows=[]
    try:
        health=json.loads(HEALTH_FILE.read_text())
        health_rows=[dict(ticker=k, **v) for k,v in health.items()]
    except Exception: pass
    write_csv(f'see_ticker_health_{VERSION}.csv',health_rows)
    total_cost=sum(float(r.get('estimated_cost_usd',0) or 0) for r in cost); scans=env_int('DEEPSEEK_SCANS_PER_DAY',4)
    ai_scores=[normalize_score(r.get('ai_final_score'),0) for r in ai]
    monitor=[dict(version=VERSION,run_cost_usd=round(total_cost,6),monthly_estimate_usd=round(total_cost*scans*30,4),budget_usd=env_float('DEEPSEEK_MONTHLY_BUDGET_USD',5),deepseek_rows=len(ai),ai_good=sum(1 for s in ai_scores if s>=55),ai_high=sum(1 for s in ai_scores if s>=70),ai_elite=sum(1 for s in ai_scores if s>=80),ai_extreme=sum(1 for s in ai_scores if s>=90),usable=sum(int(r.get('usable',0)) for r in summary),quant_elite=sum(int(r.get('quant_elite',0)) for r in summary),final_elite=sum(int(r.get('final_elite',0)) for r in summary),final_extreme=sum(int(r.get('final_extreme',0)) for r in summary),generated_at=datetime.now(timezone.utc).isoformat())]
    write_csv(f'see_cost_monitor_{VERSION}.csv',monitor)
    with zipfile.ZipFile(OUT/'all.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in OUT.glob(f'*{VERSION}*.csv'): z.write(f,f.name)
        if HEALTH_FILE.exists(): z.write(HEALTH_FILE, HEALTH_FILE.name)
        if FAIL_LOG.exists(): z.write(FAIL_LOG, FAIL_LOG.name)

def send_ntfy(summary_rows, ai_rows):
    if os.getenv('NTFY_ENABLED','0')!='1': return
    topic=os.getenv('NTFY_TOPIC','stock-signals-Stijn-2026'); maxn=env_int('NTFY_MAX_ALERTS',5)
    # Alert only on AI_ELITE, FINAL_ELITE or FINAL_EXTREME. Deduplicate by ticker and rank by final_score.
    candidates=[]; seen=set()
    top_by_ticker={}
    for r in summary_rows:
        t=r.get('ticker')
        if not t: continue
        if int(r.get('final_extreme',0)) or int(r.get('final_elite',0)) or int(r.get('ai_elite',0)):
            cur=top_by_ticker.get(t)
            if cur is None or safe_float(r.get('final_score'))>safe_float(cur.get('final_score')):
                top_by_ticker[t]=r
    ai_map={r.get('ticker'):r for r in ai_rows}
    rows=sorted(top_by_ticker.values(), key=lambda r: safe_float(r.get('final_score')), reverse=True)
    sent=0
    for r in rows:
        t=r.get('ticker'); ai=ai_map.get(t,{})
        score=safe_float(r.get('final_score')); ai_score=safe_float(r.get('ai_final_score'))
        signal='FINAL_EXTREME' if int(r.get('final_extreme',0)) else 'FINAL_ELITE' if int(r.get('final_elite',0)) else 'AI_ELITE'
        title=f"🚨 {signal} {t} | score {score:.1f}"
        msg=f"AI {ai_score:.1f} ({r.get('ai_tier')}) | Quant {r.get('evidence_score')} | Materiality {r.get('materiality')} | Market {r.get('market_confirmation')}\nSetup: {r.get('setup')} {r.get('hold_days')}d | avg {r.get('avg_return_pct')}% | win {r.get('winrate_pct')}%\nEvent: {ai.get('event_type','?')}\n{ai.get('reasoning','')}"
        try: requests.post(f'https://ntfy.sh/{topic}',data=msg.encode('utf-8'),headers={'Title':title,'Tags':'chart_with_upwards_trend'},timeout=8)
        except Exception: pass
        sent+=1
        if sent>=maxn: break

if __name__=='__main__':
    tickers=(sys.argv[1] if len(sys.argv)>1 else DEFAULT_UNIVERSE).replace(' ','').split(',')
    period=sys.argv[2] if len(sys.argv)>2 else '2y'
    run(clean_universe([t for t in tickers if t]), period)
