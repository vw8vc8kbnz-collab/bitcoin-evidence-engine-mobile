# Stock Evidence Engine v1.8.6

Focus build: DeepSeek-led ranking calibration and richer catalyst analysis.

## Core fixes
- Normalizes all DeepSeek numeric scores to 0-100 immediately after API response.
- Fixes 0-10 vs 0-100 scale bug for ai_final_score/final_score, materiality, market_confirmation, priced_in_risk, continuation_3d, continuation_10d and related fields.
- Adds AI tiers: AI_GOOD >=55, AI_HIGH >=70, AI_ELITE >=80, AI_EXTREME >=90.
- Replaces over-strict AI gate with calibrated final signal logic:
  - FINAL_ELITE = QUANT_ELITE + AI_HIGH.
  - FINAL_EXTREME = QUANT_ELITE + AI_ELITE + materiality >=80 + market_confirmation >=75.
- Adds composite final_score: 40% quant, 40% AI, 10% materiality, 10% market confirmation.

## DeepSeek analysis upgrade
- DeepSeek now receives richer context: market data, quant setup evidence, news consensus, price reaction, historical analog context and structured headlines.
- Prompt updated to v1.8.6 and explicitly forces 0-100 scoring.
- More institutional catalyst reasoning: materiality, repricing potential, market confirmation, priced-in risk and continuation probability.

## Dashboard
- Adds AI Overview: rows, AI Good, AI High, AI Elite, AI Extreme, run cost.
- Adds Quant Overview: summary rows, usable/good, quant elite.
- Adds Final Signals: final elite and final extreme.
- Adds separate Top Final Signals and Top AI Signals sections.

## NTFY
- Alerts only for AI_ELITE, FINAL_ELITE or FINAL_EXTREME.
- Deduplicates by ticker and sorts by final_score.

## Safety/selftest
- Selftest now verifies version markers and AI score normalization with mock 0-10 payload.
- Dashboard service now runs through venv python for dependency consistency.
