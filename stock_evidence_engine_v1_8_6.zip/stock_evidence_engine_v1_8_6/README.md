# Stock Evidence Engine v1.8.6

SEE is an AI + quant driven stock opportunity engine. It scans a large stock universe, combines local quant evidence, market reaction, Yahoo news, catalyst detection and DeepSeek analysis, then ranks institutional-style repricing opportunities.

Dashboard: port 8798.

Main commands on VPS:

```bash
cd /home/ubuntu/stock_evidence_latest
./selftest.sh
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN,RGTI,QBTS,OKLO,ASTS,LUNR,OUST,PATH,SOFI,AFRM,ROKU,SHOP,NET,CRWD,DDOG,SNOW,ARM,MU,AVGO,TSM,SMCI,APP,MRVL,INTC,ORCL,MSFT,GOOGL,META,AMZN,CRSP,BEAM,EDIT,NTLA,PLUG,ENPH,FSLR,CCJ,UEC,UUUU,EVGO,CHPT,QS,OPEN,DKNG,TDOC,SPCE,ENVX,STEM,SERV,TER,ISRG,IRDM,KTOS,AVAV,HIMS,NU,SE,GRAB,TOST,U,LMND,ROOT,CVNA" "2y"
```

Required `.env` examples:

```env
USE_DEEPSEEK=1
DEEPSEEK_API_KEY=...
DEEPSEEK_MODEL=deepseek-chat
DEEPSEEK_MAX_TICKERS=30
DEEPSEEK_MAX_HEADLINES=50
DEEPSEEK_MAX_OUTPUT_TOKENS=4000
DEEPSEEK_SCANS_PER_DAY=4
DEEPSEEK_MONTHLY_BUDGET_USD=5
NTFY_ENABLED=1
NTFY_TOPIC=stock-signals-Stijn-2026
NTFY_MIN_PROB=82
NTFY_MAX_ALERTS=5
```
