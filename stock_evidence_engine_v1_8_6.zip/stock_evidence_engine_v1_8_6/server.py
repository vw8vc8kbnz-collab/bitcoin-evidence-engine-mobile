#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, csv, zipfile, html
VERSION='v1.8.6'; BASE=Path(__file__).resolve().parent; OUT=BASE/'output'; PORT=8798

def read_csv(name):
    files=list(OUT.glob(name))
    if not files: return []
    try:
        with files[0].open(encoding='utf-8') as f: return list(csv.DictReader(f))
    except Exception: return []

def fnum(x):
    try: return float(x or 0)
    except Exception: return 0.0

def metric(label, value, sub=''):
    return f"<div class='metric'><b>{html.escape(str(value))}</b><br><span>{html.escape(label)}</span>{('<em>'+html.escape(str(sub))+'</em>') if sub else ''}</div>"

def card(r, ai_map=None):
    ai_map=ai_map or {}; ai=ai_map.get(r.get('ticker'), r)
    t=html.escape(r.get('ticker','?'))
    tier=html.escape(str(r.get('ai_tier') or ai.get('ai_tier') or r.get('conviction') or ''))
    score=r.get('final_score') or r.get('ai_final_score') or r.get('combined_score') or '0'
    ais=r.get('ai_final_score') or ai.get('ai_final_score') or '0'
    ev=html.escape(str(ai.get('event_type') or r.get('setup') or ''))
    reason=html.escape(str(ai.get('reasoning') or r.get('reasoning') or ''))[:340]
    setup=html.escape(str(r.get('setup','')))
    sig='FINAL_EXTREME' if str(r.get('final_extreme','0'))=='1' else 'FINAL_ELITE' if str(r.get('final_elite','0'))=='1' else tier
    return f"""<div class='card'><div class='top'><b>{t}</b><span>{html.escape(sig)}</span></div><div class='score'>{score}</div><div class='muted'>AI {ais} · {ev} · {setup}</div><p>{reason}</p></div>"""

def dashboard():
    ai=read_csv(f'see_ai_analyst_{VERSION}.csv')
    summary=read_csv(f'see_summary_{VERSION}.csv')
    final_elite=read_csv(f'see_final_elite_{VERSION}.csv')
    final_extreme=read_csv(f'see_final_extreme_{VERSION}.csv')
    qelite=read_csv(f'see_quant_elite_{VERSION}.csv')
    usable=read_csv(f'see_usable_{VERSION}.csv')
    cost=read_csv(f'see_cost_monitor_{VERSION}.csv')
    cm=cost[0] if cost else {}
    ai_map={r.get('ticker'):r for r in ai}
    ai_good=sum(1 for r in ai if fnum(r.get('ai_final_score') or r.get('final_score'))>=55)
    ai_high=sum(1 for r in ai if fnum(r.get('ai_final_score') or r.get('final_score'))>=70)
    ai_elite=sum(1 for r in ai if fnum(r.get('ai_final_score') or r.get('final_score'))>=80)
    ai_extreme=sum(1 for r in ai if fnum(r.get('ai_final_score') or r.get('final_score'))>=90)
    final_sorted=sorted(final_elite+final_extreme, key=lambda r: fnum(r.get('final_score')), reverse=True)[:30]
    ai_sorted=sorted(ai,key=lambda r: fnum(r.get('ai_final_score') or r.get('final_score')), reverse=True)[:30]
    cards=''.join(card(r, ai_map) for r in final_sorted) or '<div class="card">Nog geen final signals. Run backtest.</div>'
    aicards=''.join(card(r, ai_map) for r in ai_sorted) or '<div class="card">Nog geen AI data. Run backtest.</div>'
    return f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>SEE {VERSION}</title><style>
body{{margin:0;background:#f4f6fb;color:#111827;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif}}.wrap{{padding:16px;max-width:1120px;margin:auto}}.hero{{background:linear-gradient(135deg,#0f172a,#334155);color:white;border-radius:28px;padding:24px;margin:10px 0 16px;box-shadow:0 18px 40px #0002}}h1{{margin:6px 0 4px;font-size:32px;letter-spacing:-.04em}}.pill{{display:inline-block;background:#ffffff22;border:1px solid #ffffff33;padding:7px 11px;border-radius:999px;font-size:13px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px;margin-bottom:12px}}.metric,.card{{background:white;border-radius:22px;padding:16px;box-shadow:0 10px 26px #0f172a12;border:1px solid #e5e7eb}}.metric b{{font-size:26px}}.metric span{{color:#64748b;font-size:13px}}.metric em{{display:block;color:#94a3b8;font-style:normal;font-size:12px;margin-top:4px}}.section{{font-size:22px;margin:24px 2px 10px;letter-spacing:-.03em}}.top{{display:flex;justify-content:space-between;gap:10px;align-items:center}}.top b{{font-size:22px}}.top span{{background:#dcfce7;color:#166534;padding:6px 10px;border-radius:999px;font-weight:800;font-size:12px}}.score{{font-size:36px;font-weight:950;margin:8px 0;color:#0f172a}}.muted{{color:#64748b;font-size:13px}}p{{line-height:1.35}}a.btn{{display:inline-block;text-decoration:none;background:white;color:#111827;padding:12px 14px;border-radius:14px;font-weight:900;margin-top:12px}}.cols{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}@media(max-width:760px){{.wrap{{padding:10px}}.hero{{padding:18px;border-radius:22px}}.card{{padding:14px}}.cols{{grid-template-columns:1fr}}}}
</style></head><body><div class='wrap'><div class='hero'><span class='pill'>Stock Evidence Engine {VERSION}</span><h1>Institutional Catalyst Intelligence</h1><div>DeepSeek analyseert nu headlines + market data + quant setups + reaction/consensus/analogs, met 0-100 normalisatie en nieuwe final signal logic.</div><a class='btn' href='/exports/all.zip'>Download audit ZIP</a></div>
<h2 class='section'>AI Overview</h2><div class='grid'>{metric('AI rows',len(ai))}{metric('AI Good ≥55',ai_good)}{metric('AI High ≥70',ai_high)}{metric('AI Elite ≥80',ai_elite)}{metric('AI Extreme ≥90',ai_extreme)}{metric('Run cost','$'+str(cm.get('run_cost_usd','0')), 'monthly $'+str(cm.get('monthly_estimate_usd','0')))}</div>
<h2 class='section'>Quant Overview</h2><div class='grid'>{metric('Summary rows',len(summary))}{metric('Usable / good',len(usable))}{metric('Quant elite',len(qelite))}</div>
<h2 class='section'>Final Signals</h2><div class='grid'>{metric('Final elite',len(final_elite))}{metric('Final extreme',len(final_extreme))}</div>
<div class='cols'><div><h2 class='section'>Top Final Signals</h2>{cards}</div><div><h2 class='section'>Top AI Signals</h2>{aicards}</div></div></div></body></html>"""
class H(BaseHTTPRequestHandler):
    def do_HEAD(self): self.send_response(200); self.end_headers()
    def do_GET(self):
        if self.path.startswith('/health'):
            b=json.dumps({'ok':True,'version':VERSION}).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        if self.path.startswith('/exports/all.zip'):
            p=OUT/'all.zip'
            if not p.exists(): self.send_error(404); return
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','application/zip'); self.send_header('Content-Disposition',f'attachment; filename="see_audit_export_{VERSION}.zip"'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        b=dashboard().encode('utf-8'); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
if __name__=='__main__': ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
