const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const vehicles = [
  { id:'bus-01', label:'V-01', driver:'Jan de Vries', plate:'V-123-AB', model:'Mercedes Sprinter', status:'Actief', next:'Klant A - Utrecht', eta:'10:45', speed:'60 km/h', stops:'7/12', pallets:6, rolls:8, load:85 },
  { id:'bus-02', label:'V-02', driver:'Pieter Smit', plate:'V-456-CD', model:'Volkswagen Crafter', status:'Actief', next:'Klant B - Breda', eta:'11:20', speed:'48 km/h', stops:'4/10', pallets:7, rolls:10, load:72 },
  { id:'bus-03', label:'V-03', driver:'Marco Jansen', plate:'V-789-EF', model:'Ford Transit', status:'Onderhoud', next:'Onderhoud tot vrijdag', eta:'-', speed:'0 km/h', stops:'0/0', pallets:5, rolls:6, load:30 },
];
const stops = [
  ['done','Amsterdam','09:05'],['done','Utrecht','10:10'],['current','Rotterdam','14:28'],['planned','Delft','15:05'],['planned','Den Haag','15:42'],['planned','Leiden','16:18']
];
const fields = [
 ['#','Ordernummer','Unieke orderreferentie'],['👤','Klantnaam','Naam van klant of bedrijf'],['⌂','Volledig adres','Straat, postcode en plaats in één veld'],['⌖','Postcode','Nederlandse postcode'],['◷','Tijdvenster start','Eerste toegestane levertijd'],['◴','Tijdvenster eind','Laatste toegestane levertijd'],['▰','Aantal Europallets','Aantal palletplaatsen voor load check'],['▥','Aantal rolcontainers','Rolcontainer capaciteit'],['⚖','Totaalgewicht','Ordergewicht in kg of gram'],['⏱','Lostijd minuten','Service- en lostijd per stop'],['✆','Tracking telefoon','Mobiele klanttracking'],['✉','Tracking e-mail','E-mail voor ETA updates'],['+','Custom veld','Eigen veld aanmaken'],['×','Negeren','Kolom niet importeren']
];
const csvCols = [
 ['Kolom A','order_id','ORD-10029'],['Kolom B','customer_name','De Vries Interieur'],['Kolom C','postcode','3511 AA'],['Kolom D','weight_kg','1240'],['Kolom E','euro_pallets','2'],['Kolom F','time_window','08:00-12:00']
];

function switchView(id){
  $$('.view').forEach(v=>v.classList.toggle('active', v.id===id));
  $$('.nav').forEach(n=>n.classList.toggle('active', n.dataset.view===id));
}

$$('.nav').forEach(btn=>btn.addEventListener('click',()=>switchView(btn.dataset.view)));
$('#toggleSidebar')?.addEventListener('click',()=>$('#sidebar').classList.toggle('compact'));
$('#mobileMenu')?.addEventListener('click',()=>$('#sidebar').classList.toggle('open'));

function renderFleetRows(){
  const target = $('#fleetRows'); if(!target) return;
  target.innerHTML = vehicles.map(v=>`<div class="fleet-row"><div class="truck-img"></div><div><b>${v.label}</b><small>${v.model}<br><span class="${v.status==='Onderhoud'?'err':'ok'}">${v.status}</span></small></div><div class="ring" style="--pct:${v.load}%">${v.load}%</div></div>`).join('');
}
function renderFleetCards(){
  const target = $('#fleetCards'); if(!target) return;
  target.innerHTML = vehicles.map(v=>`<article class="card vehicle-card"><div class="top"><div class="truck-img"></div><div><h3>${v.label} · ${v.plate}</h3><p>${v.model}</p><p><span class="${v.status==='Onderhoud'?'err':'ok'}">${v.status}</span> · ${v.driver}</p></div></div><div class="capacity"><span><b>${v.pallets}</b><br>Europallets</span><span><b>${v.rolls}</b><br>Rolcontainers</span><span><b>${v.load}%</b><br>Laadcapaciteit</span></div></article>`).join('');
}
function renderVehiclePanel(vehicle = vehicles[0]){
  const panel = $('#vehiclePanel'); if(!panel) return;
  panel.innerHTML = `<div class="vehicle-detail"><h4>${vehicle.label} — ${vehicle.driver}</h4><p class="${vehicle.status==='Onderhoud'?'err':'ok'}">${vehicle.status}</p><p>${vehicle.speed} · volgende stop: ${vehicle.next}</p><p>ETA: <b>${vehicle.eta}</b> · Stops: <b>${vehicle.stops}</b></p><div class="stop-list">${stops.map(([st,city,eta],i)=>`<div class="stop-item ${st}"><span class="stop-status">${st==='done'?'✓':st==='current'?'→':'○'}</span><span>${city}</span><time>${eta}</time></div>`).join('')}</div></div>`;
}
function renderCsv(){
  const grid = $('#csvGrid'); if(!grid) return;
  grid.innerHTML = csvCols.map((c,i)=>`<div class="csv-col"><b>${c[0]} · ${c[1]}</b><p>Preview: ${c[2]}</p><button class="pick-field" data-col="${i}">Kies veld…</button></div>`).join('');
  $$('.pick-field', grid).forEach(b=>b.addEventListener('click',()=>openPicker(b)));
}
function openPicker(btn){
  const picker = $('#fieldPicker'); picker.classList.remove('hidden'); renderFields('');
  $('#fieldSearch').value=''; $('#fieldSearch').focus();
}
function renderFields(q=''){
  const res = $('#fieldResults'); if(!res) return;
  const f = fields.filter(x=>(x[1]+x[2]).toLowerCase().includes(q.toLowerCase()));
  res.innerHTML = f.map(x=>`<div class="field-option"><span>${x[0]}</span><div><b>${x[1]}</b><p>${x[2]}</p></div></div>`).join('');
}
$('#fieldSearch')?.addEventListener('input',e=>renderFields(e.target.value));
$('#closePicker')?.addEventListener('click',()=>$('#fieldPicker').classList.add('hidden'));

$$('.vehicle-live').forEach(btn=>btn.addEventListener('click',()=>renderVehiclePanel(vehicles.find(v=>v.id===btn.dataset.vehicle)||vehicles[0])));

renderFleetRows(); renderFleetCards(); renderVehiclePanel(); renderCsv();
