from datetime import datetime, timezone
from typing import Literal
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

APP_VERSION = "0.1.0-foundation"

app = FastAPI(title="AlgoRoute API", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Vehicle(BaseModel):
    id: str
    label: str
    license_plate: str
    driver: str
    status: Literal["available", "on_route", "maintenance", "unavailable"]
    lat: float
    lng: float
    heading: int = Field(ge=0, le=359)
    stops_total: int
    stops_done: int
    next_stop: str
    eta_next: str
    max_europallets: int
    max_roll_containers: int

class RouteStop(BaseModel):
    sequence: int
    customer: str
    city: str
    status: Literal["done", "current", "planned", "delayed"]
    eta: str
    pallets: int = 0
    roll_containers: int = 0

MOCK_VEHICLES = [
    Vehicle(id="bus-01", label="Bus 01", license_plate="V-123-AB", driver="Jan", status="on_route", lat=52.0907, lng=5.1214, heading=218, stops_total=18, stops_done=7, next_stop="Rotterdam", eta_next="14:28", max_europallets=6, max_roll_containers=8),
    Vehicle(id="bus-02", label="Bus 02", license_plate="V-456-CD", driver="Sven", status="on_route", lat=52.3676, lng=4.9041, heading=102, stops_total=21, stops_done=13, next_stop="Almere", eta_next="14:42", max_europallets=8, max_roll_containers=10),
    Vehicle(id="bus-03", label="Bus 03", license_plate="V-789-EF", driver="Milan", status="maintenance", lat=51.4416, lng=5.4697, heading=15, stops_total=0, stops_done=0, next_stop="Onderhoud", eta_next="-", max_europallets=5, max_roll_containers=6),
]

MOCK_STOPS = [
    RouteStop(sequence=1, customer="Klant Amsterdam", city="Amsterdam", status="done", eta="09:05", pallets=1),
    RouteStop(sequence=2, customer="Klant Utrecht", city="Utrecht", status="done", eta="10:10", roll_containers=2),
    RouteStop(sequence=3, customer="Klant Rotterdam", city="Rotterdam", status="current", eta="14:28", pallets=2),
    RouteStop(sequence=4, customer="Klant Delft", city="Delft", status="planned", eta="15:05", roll_containers=1),
    RouteStop(sequence=5, customer="Klant Den Haag", city="Den Haag", status="planned", eta="15:42", pallets=1),
]

@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": APP_VERSION, "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/fleet/live", response_model=list[Vehicle])
def fleet_live():
    return MOCK_VEHICLES

@app.get("/api/routes/{vehicle_id}/stops", response_model=list[RouteStop])
def route_stops(vehicle_id: str):
    return MOCK_STOPS

@app.get("/api/import/fields")
def import_fields():
    return {
        "categories": [
            {"name": "Order", "fields": ["Ordernummer", "Extern order ID", "Leverdatum", "Opmerking intern"]},
            {"name": "Klant", "fields": ["Klantnaam", "Bedrijfsnaam", "Contactpersoon", "Telefoonnummer", "E-mailadres"]},
            {"name": "Adres", "fields": ["Volledig adres", "Straat", "Huisnummer", "Postcode", "Plaats", "Land", "Latitude", "Longitude"]},
            {"name": "Tijdvenster", "fields": ["Tijdvenster start", "Tijdvenster eind", "Niet leveren vóór", "Niet leveren na"]},
            {"name": "Load", "fields": ["Aantal europallets", "Aantal rolcontainers", "Rolcontainer type", "Totaalgewicht", "Totaalvolume"]},
            {"name": "Service", "fields": ["Lostijd minuten", "Twee personen nodig", "Lift aanwezig", "Verdieping", "Montage nodig"]},
            {"name": "Tracking", "fields": ["Tracking telefoon", "Tracking e-mail", "Tracking toegestaan"]},
            {"name": "Custom", "fields": ["Custom veld", "Negeren"]},
        ]
    }
