# AlgoRoute C++ Optimization Core

All optimization-like calculations belong here, not in frontend or Node/Python glue.

Planned modules:
- VRPTW route solving
- scenario scoring
- Customer Promise Guard
- traffic micro-reroute / local resequence / controlled replanning
- pallet and roll-container capacity checks
- reverse-route LIFO load sequence
- future 2D/3D loading optimizer

This foundation build includes stubs only. OR-Tools C++ integration is planned for Build 5.
