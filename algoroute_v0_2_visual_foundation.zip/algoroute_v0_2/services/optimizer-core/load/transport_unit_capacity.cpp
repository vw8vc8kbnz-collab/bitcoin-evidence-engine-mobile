// Future: pallet/roll-container capacity checker.
// V1 load model: europallets + configured roll-container types per vehicle.
