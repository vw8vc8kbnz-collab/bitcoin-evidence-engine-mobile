// AlgoRoute v0.1 stub
// Future: OR-Tools C++ VRPTW solver entrypoint.
int main() { return 0; }
