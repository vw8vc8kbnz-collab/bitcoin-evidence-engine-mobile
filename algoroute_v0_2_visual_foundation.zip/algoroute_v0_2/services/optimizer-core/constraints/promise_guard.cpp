// Future: Customer Promise Guard.
// Rule concept: route changes may not break customer ETA promise beyond configured threshold.
