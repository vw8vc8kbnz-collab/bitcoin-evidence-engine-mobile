# AlgoRoute Worker

Python orchestration layer for future async jobs:
- import processing
- geocoding provider calls
- OSRM/Google/TomTom/HERE adapter calls
- optimizer-core execution
- report/export generation

Heavy optimization must stay in C++.
