# AlgoRoute v0.2 Visual Foundation

**AlgoRoute** — Route & Load Intelligence for Complex Deliveries.

Deze versie verwerkt de gekozen AlgoRoute-huisstijl: donker premium dashboard, blauw/navy kleurstelling, echte app-indeling met desktop cockpit, live tracking kaart, Import Studio, Wagenpark en mobiele driver/klant interfaces.

## Belangrijk
Dit is geen mockup-afbeelding maar een werkende frontend foundation met echte HTML/CSS/JS-structuur binnen de bestaande modulaire projectopzet.

## Inbegrepen
- AlgoRoute logo/mark assets in de nieuwe stijl
- Desktop dashboard zoals afgesproken: linker Apple-achtige toolbar, live map, KPI's, meldingen, planning, import en wagenpark panels
- Live Tracking pagina met rijdende voertuigmarkers en route-overlay
- Import Studio met Smart Field Picker basis
- Wagenpark cards met laadcapaciteit/europallets/rolcontainers
- Driver PWA in dezelfde stijl
- Klanttracking pagina in dezelfde stijl
- FastAPI backend blijft aanwezig
- C++ optimizer-core structuur blijft aanwezig
- Docker/VPS/Termius basis blijft aanwezig

## Nog niet inbegrepen
- Echte OSRM routing
- Echte Google/TomTom/HERE traffic
- Echte native GPS background tracking
- Echte database/auth
- Echte C++ OR-Tools solver
