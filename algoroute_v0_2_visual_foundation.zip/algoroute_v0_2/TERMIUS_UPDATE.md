# AlgoRoute v0.2 Termius update

Gebruik straks na GitHub upload dezelfde standaardroute:

```bash
cd /home/ubuntu
rm -rf algoroute_latest algoroute_v0_2_visual_foundation.zip
wget -O algoroute_v0_2_visual_foundation.zip "<GITHUB_RAW_ZIP_URL>"
unzip -o algoroute_v0_2_visual_foundation.zip -d algoroute_latest
cd algoroute_latest/algoroute_v0_2
chmod +x scripts/*.sh
sudo bash scripts/install.sh
sudo docker ps --filter "name=algoroute"
curl -fsS http://127.0.0.1:8080/api/health && echo
```

Dashboard standaard: `http://SERVER_IP:8787`
API health: `http://SERVER_IP:8080/api/health`
```
