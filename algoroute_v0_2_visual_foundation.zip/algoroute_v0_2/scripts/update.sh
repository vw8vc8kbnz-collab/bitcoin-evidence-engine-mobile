#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/algoroute"
cd "$APP_DIR"
sudo docker compose down
sudo docker compose up -d --build
echo "AlgoRoute updated."
