#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/algoroute"
echo "Installing AlgoRoute to $APP_DIR"
sudo mkdir -p "$APP_DIR"
sudo cp -R . "$APP_DIR/"
cd "$APP_DIR"
if [ ! -f .env ]; then sudo cp .env.example .env; fi
sudo docker compose up -d --build
echo "AlgoRoute installed. Web: http://SERVER_IP:8787 | API: http://SERVER_IP:8080/api/health"
