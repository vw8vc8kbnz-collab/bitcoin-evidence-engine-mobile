#!/usr/bin/env bash
set -euo pipefail
curl -fsS http://127.0.0.1:8080/api/health && echo
sudo docker ps --filter "name=algoroute"
