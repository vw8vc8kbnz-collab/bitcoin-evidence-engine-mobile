# AlgoRoute Scope Lock

AlgoRoute is not an ERP. It is a route + load planning and execution platform for complex deliveries.

Primary niche:
- heavy / complex deliveries
- furniture, kitchens, sanitary, white goods, building materials, custom goods
- time windows, service time, installation, floor/lift/access notes
- load units: europallets and roll containers first

Core differentiator:
- route planning + load feasibility coupled together
- reverse-route/LIFO-aware load sequence
- Customer Promise Guard for live changes
