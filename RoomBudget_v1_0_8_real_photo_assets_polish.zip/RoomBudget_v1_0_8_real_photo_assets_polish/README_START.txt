RoomBudget v1.0.8 - real photo assets, hero/photo tile polish, spacing scan, stable PWA installer. AI provider remains mock by default.
