ROOM_PRESETS = {
    "woonkamer": {"area": 35, "wall": 78},
    "keuken": {"area": 18, "wall": 42},
    "badkamer": {"area": 8, "wall": 32},
    "slaapkamer": {"area": 16, "wall": 44},
}
STYLE_FACTOR = {"japandi": 1.15, "modern_warm": 1.05, "hotel_chic": 1.3, "scandinavisch": 1.0, "industrieel": 1.08, "luxe_minimal": 1.35, "landelijk_modern": 1.12}
BUDGET_FACTOR = {"slim": 0.85, "midden": 1.0, "premium": 1.35, "luxe": 1.75}

def calculate_room_budget(room_type: str, style: str, budget_class: str):
    preset = ROOM_PRESETS.get(room_type, ROOM_PRESETS["woonkamer"])
    f = STYLE_FACTOR.get(style, 1.0) * BUDGET_FACTOR.get(budget_class, 1.0)
    area, wall = preset["area"], preset["wall"]
    items = []
    if room_type == "badkamer":
        items = [
            ("sloop", "Voorbereiding en sloopwerk", 1, "post", 650, 1600, 0),
            ("tegelwerk", "Tegelwerk vloer en wanden", area + wall, "m²", 95*f, 185*f, 0),
            ("sanitair", "Sanitair en kranen", 1, "set", 2200*f, 6200*f, 0),
            ("installatie", "Leidingwerk en montage", 1, "post", 2400*f, 6500*f, 0),
        ]
    elif room_type == "keuken":
        items = [
            ("keuken", "Keukenopstelling en werkblad", 1, "set", 4500*f, 15500*f, 0),
            ("vloer", "Nieuwe vloerafwerking", area, "m²", 55*f, 130*f, 1),
            ("elektra", "Elektra/lichtpunten aanpassen", 1, "post", 700*f, 2300*f, 0),
            ("schilderwerk", "Wanden/plafond afwerken", wall, "m²", 18*f, 42*f, 1),
        ]
    else:
        custom = 1800*f if room_type == "slaapkamer" else 2400*f
        items = [
            ("vloer", "Nieuwe vloerafwerking", area, "m²", 45*f, 120*f, 1),
            ("schilderwerk", "Wanden en plafond schilderen", wall, "m²", 16*f, 38*f, 1),
            ("verlichting", "Verlichting en elektra accenten", 1, "post", 450*f, 1800*f, 0),
            ("maatwerk", "Maatwerk/meubel/styling indicatie", 1, "post", custom, custom*3.2, 0),
        ]
    total_min = sum(q*mn for _,_,q,_,mn,_,_ in items)
    total_max = sum(q*mx for _,_,q,_,_,mx,_ in items)
    materials_min, materials_max = total_min*0.52, total_max*0.58
    labor_min, labor_max = total_min-materials_min, total_max-materials_max
    return {
        "total_min": round(total_min), "total_max": round(total_max),
        "materials_min": round(materials_min), "materials_max": round(materials_max),
        "labor_min": round(labor_min), "labor_max": round(labor_max),
        "items": [dict(category=c,title=t,quantity=q,unit=u,min_price=round(q*mn),max_price=round(q*mx),diy_possible=d) for c,t,q,u,mn,mx,d in items]
    }

def build_plan(room_type: str):
    common = [
        (1, "Voorbereiden", "Meet na, leg keuzes vast en bestel materialen op tijd.", 1, "Startpunt."),
        (2, "Demonteren / vrijmaken", "Maak de ruimte leeg en verwijder oude onderdelen waar nodig.", 1, "Pas starten na definitieve keuzes."),
        (3, "Installatiepunten", "Controleer elektra, leidingwerk en lichtpunten vóór afwerking.", 2, "Moet vóór stuc/schilder/vloer."),
        (4, "Wanden en plafond", "Stuc/schilderwerk uitvoeren met droogtijd.", 4, "Droogtijd respecteren."),
        (5, "Vloer", "Plaats vloer pas na natte/stoffige werkzaamheden.", 2, "Na wandafwerking."),
        (6, "Inrichten en opleveren", "Meubels, verlichting, styling en eindcontrole.", 1, "Laatste stap."),
    ]
    if room_type == "badkamer":
        common.insert(3, (4, "Waterdichting en tegelwerk", "Kimband, afdichting en tegelwerk zorgvuldig uitvoeren.", 5, "Na leidingwerk."))
    return common
