from datetime import datetime, date
from app.core.config import AI_ENABLED, FREE_RENDERS_PER_USER, MAX_DAILY_RENDERS_GLOBAL, MAX_MONTHLY_AI_EUR
from app.core.db import db

def can_generate(user_id: int):
    if not AI_ENABLED:
        return False, "AI-generatie staat uit via kill switch."
    today = date.today().isoformat()
    month = today[:7]
    with db() as conn:
        user_done = conn.execute("SELECT COUNT(*) c FROM render_jobs WHERE user_id=? AND status='completed'", (user_id,)).fetchone()["c"]
        daily = conn.execute("SELECT COUNT(*) c FROM render_jobs WHERE date(created_at)=? AND status IN ('processing','completed')", (today,)).fetchone()["c"]
        monthly_cost = conn.execute("SELECT COALESCE(SUM(cost_estimate),0) c FROM render_jobs WHERE substr(created_at,1,7)=? AND status='completed'", (month,)).fetchone()["c"]
        if user_done >= FREE_RENDERS_PER_USER:
            # In v1 premium payments are not active; keep strict free limit.
            return False, "Gratis renderlimiet bereikt. Ontgrendelen komt in de volgende betaalversie."
        if daily >= MAX_DAILY_RENDERS_GLOBAL:
            return False, "Daglimiet voor AI-generatie bereikt."
        if float(monthly_cost) >= MAX_MONTHLY_AI_EUR:
            return False, "Maandbudget voor AI-generatie bereikt."
    return True, "ok"
