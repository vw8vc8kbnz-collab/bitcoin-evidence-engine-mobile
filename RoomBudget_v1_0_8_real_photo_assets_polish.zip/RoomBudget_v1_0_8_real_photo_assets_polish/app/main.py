from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
import shutil, uuid

from app.core.db import init_db, db
from app.core.security import hash_password, verify_password, make_session, read_session
from app.core.config import APP_NAME, APP_TAGLINE, UPLOAD_DIR, AI_PROVIDER
from app.budget.engine import calculate_room_budget, build_plan
from app.ai.safety import can_generate
from app.ai.provider import mock_generate

app = FastAPI(title=APP_NAME)
BASE = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE / "templates"))

@app.on_event("startup")
def startup():
    init_db()


def current_user(request: Request):
    token = request.cookies.get("rb_session")
    if not token:
        return None
    uid = read_session(token)
    if not uid:
        return None
    with db() as conn:
        return conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()

def require_user(request: Request):
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401)
    return user

@app.get("/health")
def health():
    return {"ok": True, "app": APP_NAME, "ai_provider": AI_PROVIDER}

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    user = current_user(request)
    if user:
        return RedirectResponse("/app", status_code=303)
    return templates.TemplateResponse("landing.html", {"request": request, "tagline": APP_TAGLINE})

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/signup")
def signup(email: str = Form(...), password: str = Form(...)):
    with db() as conn:
        existing = conn.execute("SELECT id FROM users WHERE email=?", (email.lower(),)).fetchone()
        if existing:
            return RedirectResponse("/login?error=exists", status_code=303)
        cur = conn.execute("INSERT INTO users(email,password_hash) VALUES(?,?)", (email.lower(), hash_password(password)))
        uid = cur.lastrowid
    resp = RedirectResponse("/app", status_code=303)
    resp.set_cookie("rb_session", make_session(uid), httponly=True, samesite="lax", max_age=60*60*24*30)
    return resp

@app.post("/login")
def login(email: str = Form(...), password: str = Form(...)):
    with db() as conn:
        user = conn.execute("SELECT * FROM users WHERE email=?", (email.lower(),)).fetchone()
    if not user or not verify_password(password, user["password_hash"]):
        return RedirectResponse("/login?error=bad", status_code=303)
    resp = RedirectResponse("/app", status_code=303)
    resp.set_cookie("rb_session", make_session(user["id"]), httponly=True, samesite="lax", max_age=60*60*24*30)
    return resp

@app.post("/logout")
def logout():
    resp = RedirectResponse("/", status_code=303)
    resp.delete_cookie("rb_session")
    return resp

@app.get("/app", response_class=HTMLResponse)
def dashboard(request: Request):
    user = require_user(request)
    with db() as conn:
        projects = conn.execute("SELECT * FROM projects WHERE user_id=? ORDER BY created_at DESC", (user["id"],)).fetchall()
        latest = conn.execute("""SELECT rooms.*, render_jobs.output_image_path FROM rooms
            LEFT JOIN render_jobs ON render_jobs.room_id=rooms.id AND render_jobs.status='completed'
            JOIN projects ON projects.id=rooms.project_id
            WHERE projects.user_id=? ORDER BY rooms.created_at DESC LIMIT 1""", (user["id"],)).fetchone()
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user, "projects": projects, "latest": latest})

@app.get("/studio", response_class=HTMLResponse)
def studio(request: Request):
    user = require_user(request)
    return templates.TemplateResponse("studio.html", {"request": request, "user": user})

@app.post("/studio/create")
def create_room(request: Request, room_type: str = Form(...), style: str = Form(...), budget_class: str = Form(...), photo: UploadFile = File(...)):
    user = require_user(request)
    suffix = Path(photo.filename or "room.jpg").suffix.lower() or ".jpg"
    if suffix not in [".jpg", ".jpeg", ".png", ".webp"]:
        return RedirectResponse("/studio?error=filetype", status_code=303)
    fname = f"room_{uuid.uuid4().hex}{suffix}"
    dest = UPLOAD_DIR / fname
    with dest.open("wb") as f:
        shutil.copyfileobj(photo.file, f)
    with db() as conn:
        cur = conn.execute("INSERT INTO projects(user_id,title,status) VALUES(?,?,?)", (user["id"], f"{room_type.title()} project", "design"))
        project_id = cur.lastrowid
        cur = conn.execute("INSERT INTO rooms(project_id,room_type,style,budget_class,original_image_path) VALUES(?,?,?,?,?)", (project_id, room_type, style, budget_class, str(dest)))
        room_id = cur.lastrowid
    return RedirectResponse(f"/room/{room_id}", status_code=303)

@app.get("/room/{room_id}", response_class=HTMLResponse)
def room_view(room_id: int, request: Request):
    user = require_user(request)
    with db() as conn:
        room = conn.execute("""SELECT rooms.*, projects.user_id FROM rooms JOIN projects ON projects.id=rooms.project_id WHERE rooms.id=?""", (room_id,)).fetchone()
        if not room or room["user_id"] != user["id"]:
            raise HTTPException(404)
        job = conn.execute("SELECT * FROM render_jobs WHERE room_id=? ORDER BY created_at DESC LIMIT 1", (room_id,)).fetchone()
        budget = conn.execute("SELECT * FROM budgets WHERE room_id=? ORDER BY created_at DESC LIMIT 1", (room_id,)).fetchone()
        items = []
        steps = []
        if budget:
            items = conn.execute("SELECT * FROM budget_items WHERE budget_id=?", (budget["id"],)).fetchall()
        steps = conn.execute("SELECT * FROM plan_steps WHERE room_id=? ORDER BY order_index", (room_id,)).fetchall()
    return templates.TemplateResponse("room.html", {"request": request, "user": user, "room": room, "job": job, "budget": budget, "items": items, "steps": steps})

@app.post("/room/{room_id}/generate")
def generate(room_id: int, request: Request):
    user = require_user(request)
    allowed, reason = can_generate(user["id"])
    if not allowed:
        return RedirectResponse(f"/room/{room_id}?blocked={reason}", status_code=303)
    idem = f"{user['id']}:{room_id}:free-v1"
    with db() as conn:
        room = conn.execute("""SELECT rooms.*, projects.user_id FROM rooms JOIN projects ON projects.id=rooms.project_id WHERE rooms.id=?""", (room_id,)).fetchone()
        if not room or room["user_id"] != user["id"]:
            raise HTTPException(404)
        existing = conn.execute("SELECT * FROM render_jobs WHERE idempotency_key=?", (idem,)).fetchone()
        if existing:
            return RedirectResponse(f"/room/{room_id}", status_code=303)
        cur = conn.execute("INSERT INTO render_jobs(user_id,room_id,status,provider,model,input_image_path,idempotency_key) VALUES(?,?,?,?,?,?,?)", (user["id"], room_id, "processing", AI_PROVIDER, "mock-v1", room["original_image_path"], idem))
        job_id = cur.lastrowid
    try:
        output, cost = mock_generate(room["original_image_path"], room["style"], room["budget_class"])
        calc = calculate_room_budget(room["room_type"], room["style"], room["budget_class"])
        steps = build_plan(room["room_type"])
        with db() as conn:
            conn.execute("UPDATE render_jobs SET status='completed', output_image_path=?, cost_estimate=?, completed_at=CURRENT_TIMESTAMP WHERE id=?", (output, cost, job_id))
            cur = conn.execute("INSERT INTO budgets(room_id,total_min,total_max,materials_min,materials_max,labor_min,labor_max) VALUES(?,?,?,?,?,?,?)", (room_id, calc["total_min"], calc["total_max"], calc["materials_min"], calc["materials_max"], calc["labor_min"], calc["labor_max"]))
            bid = cur.lastrowid
            for item in calc["items"]:
                conn.execute("INSERT INTO budget_items(budget_id,category,title,quantity,unit,min_price,max_price,diy_possible) VALUES(?,?,?,?,?,?,?,?)", (bid, item["category"], item["title"], item["quantity"], item["unit"], item["min_price"], item["max_price"], item["diy_possible"]))
            for step in steps:
                conn.execute("INSERT INTO plan_steps(room_id,order_index,title,description,duration_days,dependency_notes) VALUES(?,?,?,?,?,?)", (room_id, *step))
    except Exception as e:
        with db() as conn:
            conn.execute("UPDATE render_jobs SET status='failed', error_message=? WHERE id=?", (str(e), job_id))
    return RedirectResponse(f"/room/{room_id}", status_code=303)

@app.get("/admin/safety", response_class=HTMLResponse)
def admin_safety(request: Request):
    user = require_user(request)
    with db() as conn:
        stats = conn.execute("SELECT COUNT(*) renders, COALESCE(SUM(cost_estimate),0) cost FROM render_jobs WHERE status='completed'").fetchone()
        jobs = conn.execute("SELECT * FROM render_jobs ORDER BY created_at DESC LIMIT 30").fetchall()
    return templates.TemplateResponse("admin_safety.html", {"request": request, "user": user, "stats": stats, "jobs": jobs})

@app.get("/media/{name}")
def media(name: str):
    path = UPLOAD_DIR / name
    if not path.exists():
        raise HTTPException(404)
    from fastapi.responses import FileResponse
    return FileResponse(path)
