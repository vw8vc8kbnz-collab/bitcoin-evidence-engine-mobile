document.addEventListener('DOMContentLoaded',()=>{
  const prefersReduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  document.querySelectorAll('[data-compare]').forEach(c=>{
    const input=c.querySelector('input');
    const wrap=c.querySelector('.after-wrap');
    const handle=c.querySelector('.handle-plus');
    if(!input || !wrap) return;
    const set=()=>{
      const v=Math.max(0,Math.min(100,Number(input.value)||58));
      wrap.style.width=v+'%';
      if(handle) handle.style.left=v+'%';
    };
    input.addEventListener('input',set,{passive:true}); set();
  });

  document.querySelectorAll('.wizard').forEach(w=>{
    let step=0;
    const slides=[...w.querySelectorAll('.wizard-slide')];
    const dots=[...w.querySelectorAll('.dots i')];
    const safeScroll=()=>{try{window.scrollTo({top:0,behavior:prefersReduced?'auto':'smooth'});}catch(e){window.scrollTo(0,0)}};
    const show=i=>{
      step=Math.max(0,Math.min(i,slides.length-1));
      slides.forEach((s,n)=>{s.classList.toggle('active',n===step);s.setAttribute('aria-hidden',n===step?'false':'true');});
      dots.forEach((d,n)=>d.classList.toggle('active',n===step-1));
      safeScroll();
    };
    w.querySelectorAll('.next').forEach(b=>b.addEventListener('click',()=>show(step+1)));
    w.querySelectorAll('.prev').forEach(b=>b.addEventListener('click',()=>show(step-1)));
    w.addEventListener('submit',e=>{
      const file=w.querySelector('input[type=file]');
      if(file && !file.files.length){e.preventDefault();file.closest('.upload-zone')?.classList.add('needs-file');return;}
      const submit=w.querySelector('button[type=submit]');
      if(submit){submit.disabled=true;const span=submit.querySelector('span');if(span) span.textContent='Project wordt voorbereid…';}
    });
    show(0);
  });

  document.querySelectorAll('input[type=file]').forEach(inp=>inp.addEventListener('change',()=>{
    const z=inp.closest('label');
    const e=z&&z.querySelector('.file-name');
    z&&z.classList.remove('needs-file');
    if(e&&inp.files[0]) e.textContent=inp.files[0].name;
  }));

  const g=document.getElementById('generateBtn');
  if(g){
    g.addEventListener('click',ev=>{
      if(g.dataset.busy==='1'){ev.preventDefault();return;}
      g.dataset.busy='1';g.disabled=true;g.style.opacity=.72;
      const span=g.querySelector('span');if(span) span.textContent='Render job gestart…';
    });
  }

  // Prevent accidental double submits globally without blocking normal links/buttons.
  document.querySelectorAll('form').forEach(f=>f.addEventListener('submit',()=>{
    if(f.dataset.submitting==='1') return false;
    f.dataset.submitting='1';
  }));
});


// v1.0.6: global smooth-control guard + bottom-nav stability
(function(){
  const bindSmoothControls=()=>{
    document.querySelectorAll('button,a,.module-card,.image-tile,.style-card,.budget-options label,.upload-zone').forEach(el=>{
      if(el.dataset.smoothBound==='1') return;
      el.dataset.smoothBound='1';
      el.addEventListener('pointerdown',()=>{el.classList.add('is-pressing')},{passive:true});
      const clear=()=>el.classList.remove('is-pressing');
      el.addEventListener('pointerup',clear,{passive:true});
      el.addEventListener('pointercancel',clear,{passive:true});
      el.addEventListener('pointerleave',clear,{passive:true});
    });
  };
  bindSmoothControls();
  window.addEventListener('pageshow',bindSmoothControls);
  // Keep fixed nav stable when iOS Safari URL bar changes height.
  const setVh=()=>document.documentElement.style.setProperty('--vvh',(window.visualViewport?window.visualViewport.height:window.innerHeight)+'px');
  setVh();
  window.visualViewport&&window.visualViewport.addEventListener('resize',setVh,{passive:true});
})();
