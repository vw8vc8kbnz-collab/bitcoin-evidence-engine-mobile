import os
from pathlib import Path

APP_NAME = "RoomBudget"
APP_TAGLINE = "See it. Budget it. Build it."
BASE_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = Path(os.getenv("ROOMBUDGET_DATA_DIR", BASE_DIR / "data"))
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = Path(os.getenv("ROOMBUDGET_DB", DATA_DIR / "roombudget.sqlite3"))
SECRET_KEY = os.getenv("ROOMBUDGET_SECRET_KEY", "change-this-before-production")
AI_PROVIDER = os.getenv("ROOMBUDGET_AI_PROVIDER", "mock")
AI_ENABLED = os.getenv("ROOMBUDGET_AI_ENABLED", "true").lower() == "true"
FREE_RENDERS_PER_USER = int(os.getenv("ROOMBUDGET_FREE_RENDERS_PER_USER", "1"))
MAX_DAILY_RENDERS_GLOBAL = int(os.getenv("ROOMBUDGET_MAX_DAILY_RENDERS_GLOBAL", "100"))
MAX_MONTHLY_AI_EUR = float(os.getenv("ROOMBUDGET_MAX_MONTHLY_AI_EUR", "100"))
MOCK_RENDER_COST_EUR = float(os.getenv("ROOMBUDGET_MOCK_RENDER_COST_EUR", "0"))
PORT = int(os.getenv("ROOMBUDGET_PORT", "8899"))

for p in (DATA_DIR, UPLOAD_DIR):
    p.mkdir(parents=True, exist_ok=True)
