import hashlib, hmac, os, base64
from itsdangerous import URLSafeSerializer, BadSignature
from .config import SECRET_KEY

serializer = URLSafeSerializer(SECRET_KEY, salt="roombudget-session")

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
    return base64.b64encode(salt + digest).decode()

def verify_password(password: str, stored: str) -> bool:
    raw = base64.b64decode(stored.encode())
    salt, digest = raw[:16], raw[16:]
    check = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
    return hmac.compare_digest(digest, check)

def make_session(user_id: int) -> str:
    return serializer.dumps({"uid": user_id})

def read_session(token: str):
    try:
        return serializer.loads(token).get("uid")
    except BadSignature:
        return None
