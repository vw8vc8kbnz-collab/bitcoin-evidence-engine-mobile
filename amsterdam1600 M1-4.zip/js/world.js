// M1.2-wereld: Amsterdam 1599 op 512×512, met dichte bebouwing.
// Opbouwvolgorde: platteland → stad (bebouwing) → IJ → kade+pieren →
// wal+bastions → straten → pleinen → grachten → paalwerk →
// kades langs het water → binnenhoven.
import { GRID, T, OBJ, SEED } from './config.js';
import { fnoise, hash2d } from './rng.js';
import { strokePolyline, fillPolygon, fillRect } from './mapbuild.js';
import MAP from './maps/amsterdam1599.js';

function shoreLinear(x) {
  const s = MAP.ijShore;
  return s.y0 + ((s.y1 - s.y0) * (x - s.x0)) / (s.x1 - s.x0);
}

function shoreY(x) {
  return shoreLinear(x) + 6 * fnoise(x / 16, 3.7, SEED ^ 0x11);
}

export function generateWorld() {
  const tiles = new Uint8Array(GRID * GRID);

  // 1. Platteland: veenweide met onregelmatige sloten
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const n = fnoise(x / 26, y / 26, SEED);
      const band = (y / 26) | 0;
      const offset = (hash2d(band, 0, SEED ^ 0x44) * 26) | 0;
      const sloot = ((y + offset) % 26) < 1;
      tiles[y * GRID + x] = sloot ? T.CANAL : (n > 0.56 ? T.GRASS : T.MARSH);
    }
  }

  // 2. De stad: dichte bebouwing (zoals op de Bast-kaart — vrijwel
  //    alles binnen de wallen was bebouwd)
  fillPolygon(tiles, MAP.cityBounds, () => T.BLOCK);

  // 3. Het IJ
  for (let x = 0; x < GRID; x++) {
    const edge = shoreY(x);
    for (let y = 0; y < edge; y++) tiles[y * GRID + x] = T.IJ;
  }

  // 4. IJ-kade + havenhoofden (pieren het water in)
  for (let x = MAP.harbor.x0; x <= MAP.harbor.x1; x++) {
    const edge = Math.floor(shoreY(x));
    for (let y = edge; y < edge + 4; y++) {
      const i = y * GRID + x;
      if (tiles[i] !== T.IJ) tiles[i] = T.QUAY;
    }
  }
  for (const p of MAP.piers) {
    const edge = Math.floor(shoreY(p.x)) + 1;
    for (let y = edge - p.len; y < edge; y++) {
      for (let x = p.x - 1; x <= p.x + 1; x++) {
        if (y >= 0) tiles[y * GRID + x] = T.QUAY;
      }
    }
  }

  // 5. Omwalling met puntbastions
  strokePolyline(tiles, MAP.wall.pts, 3, T.WALL);
  for (let i = 0; i < MAP.wall.pts.length; i += MAP.wall.bastionEvery) {
    const [bx, by] = MAP.wall.pts[i];
    strokePolyline(tiles, [[bx, by], [bx, by]], MAP.wall.bastionR * 2, T.WALL);
  }

  // 6. Straten en pleinen door de bebouwing snijden
  for (const s of MAP.streets) strokePolyline(tiles, s.pts, s.w, T.STREET);
  for (const p of MAP.plazas) fillRect(tiles, ...p.rect, T.STREET);

  // 7. Waterlopen (bruggen zijn M9; grachten snijden nu nog door straten)
  for (const c of MAP.canals) strokePolyline(tiles, c.pts, c.w, T.CANAL);

  // 7b. Steegjes: oost-west stegen om de ~10 rijen door de bebouwing,
  //     verspringend per blok. Grachten breken ze vanzelf (geen bruggen).
  for (let row = 0; row < GRID; row += 10) {
    for (let x = 1; x < GRID - 1; x++) {
      const jitter = (hash2d((x / 22) | 0, row, SEED ^ 0x66) * 5) | 0;
      const y = row + jitter;
      if (y < 1 || y >= GRID - 1) continue;
      const i = y * GRID + x;
      if (tiles[i] === T.BLOCK) tiles[i] = T.STREET;
    }
  }

  // 8. Paalwerk in het IJ
  for (const p of MAP.palisade) {
    for (let x = p.x0; x <= p.x1; x++) {
      const period = p.dash + p.gap;
      if ((x - p.x0) % period >= p.dash) continue;
      const y = Math.floor(shoreLinear(x)) + p.yOffset;
      if (y >= 0 && tiles[y * GRID + x] === T.IJ) tiles[y * GRID + x] = T.WALL;
    }
  }

  // 9. Kades: bebouwing die direct aan grachtwater grenst wordt kade
  //    (één rand van kade + straat langs elke gracht, zoals in het echt)
  const withQuays = new Uint8Array(tiles);
  for (let y = 1; y < GRID - 1; y++) {
    for (let x = 1; x < GRID - 1; x++) {
      const i = y * GRID + x;
      if (tiles[i] !== T.BLOCK) continue;
      if (
        tiles[i - 1] === T.CANAL || tiles[i + 1] === T.CANAL ||
        tiles[i - GRID] === T.CANAL || tiles[i + GRID] === T.CANAL
      ) {
        withQuays[i] = T.QUAY;
      }
    }
  }

  // 10. Binnenhoven: bebouwing die diep in een bouwblok ligt (ver van
  //     straat, kade of water) wordt hof of tuin — precies het beeld
  //     van de Bast-kaart met groene blokkernen.
  const depth = new Uint8Array(GRID * GRID);
  const isOpen = (t) => t !== T.BLOCK;
  // pass 1: blok-tegels die aan open ruimte grenzen krijgen diepte 1;
  // daarna 4 dilatatie-passes
  for (let d = 1; d <= 4; d++) {
    for (let y = 1; y < GRID - 1; y++) {
      for (let x = 1; x < GRID - 1; x++) {
        const i = y * GRID + x;
        if (withQuays[i] !== T.BLOCK || depth[i] !== 0) continue;
        const nb = [i - 1, i + 1, i - GRID, i + GRID];
        for (const j of nb) {
          if ((d === 1 && isOpen(withQuays[j])) || (d > 1 && depth[j] === d - 1)) {
            depth[i] = d;
            break;
          }
        }
      }
    }
  }
  const out = withQuays;
  for (let i = 0; i < out.length; i++) {
    if (out[i] === T.BLOCK && depth[i] === 0) {
      // dieper dan 4 tegels van open ruimte → binnenhof
      out[i] = hash2d(i % GRID, (i / GRID) | 0, SEED ^ 0x88) < 0.7 ? T.GRASS : T.DIRT;
    }
  }

  // 11. Objectlaag: pandjes, landmarks, molens, schepen en bomen
  const objects = new Uint8Array(GRID * GRID);
  const openTypes = new Set([T.STREET, T.QUAY]);
  for (let y = 1; y < GRID - 1; y++) {
    for (let x = 1; x < GRID - 1; x++) {
      const i = y * GRID + x;
      const t = out[i];
      // pandjes: bebouwing die aan straat, plein of kade grenst
      if (t === T.BLOCK) {
        if (
          openTypes.has(out[i - 1]) || openTypes.has(out[i + 1]) ||
          openTypes.has(out[i - GRID]) || openTypes.has(out[i + GRID])
        ) {
          objects[i] = OBJ.HOUSE;
        }
        continue;
      }
      // bomen: vol in de stadshoven, spaarzaam in het open veenweidegebied
      if (t === T.GRASS) {
        const inCity = x > 120 && x < 414 && y > 70 && y < 300;
        if (hash2d(x, y, SEED ^ 0xA1) < (inCity ? 0.13 : 0.025)) {
          objects[i] = OBJ.TREE;
        }
      }
    }
  }

  // schepen op het IJ (tussen paalwerk en kade, en enkele in het Damrak)
  for (let y = 4; y < GRID; y++) {
    for (let x = 4; x < GRID - 4; x++) {
      const i = y * GRID + x;
      if (out[i] !== T.IJ && out[i] !== T.CANAL) continue;
      const edge = shoreY(x);
      const h = hash2d(x, y, SEED ^ 0xB2);
      if (out[i] === T.IJ && y > edge - 26 && y < edge - 3 && h < 0.012) {
        objects[i] = h < 0.007 ? OBJ.SHIP_L : OBJ.SHIP_S;
      } else if (out[i] === T.CANAL && h < 0.006) {
        objects[i] = OBJ.SHIP_S;
      }
    }
  }

  // molens op de bastions van de omwalling (om en om)
  for (let i = 0; i < MAP.wall.pts.length; i += MAP.wall.bastionEvery * 2) {
    const [bx, by] = MAP.wall.pts[i];
    objects[by * GRID + bx] = OBJ.MILL;
  }

  // landmarks uit de kaartdata (kerken, torens, poorten)
  const OBJ_BY_NAME = { tower: OBJ.TOWER, church: OBJ.CHURCH, mill: OBJ.MILL };
  for (const lm of MAP.landmarks) {
    objects[lm.y * GRID + lm.x] = OBJ_BY_NAME[lm.obj] || OBJ.TOWER;
  }

  return { tiles: out, objects };
}

export function tileAt(tiles, x, y) {
  if (x < 0 || y < 0 || x >= GRID || y >= GRID) return -1;
  return tiles[y * GRID + x];
}

// Deterministische visuele variant per tegel (spriteselectie, 3 tinten)
export function variantAt(x, y) {
  return (hash2d(x, y, SEED ^ 0x77) * 3) | 0;
}
